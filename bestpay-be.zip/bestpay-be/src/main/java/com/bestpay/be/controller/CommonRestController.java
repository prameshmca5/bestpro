/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.RefCountry;
import com.bestpay.be.model.RefPaymentType;
import com.bestpay.be.model.RefStatus;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.model.Country;
import com.bestpay.be.sdk.model.PaymentType;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.service.CountryService;
import com.bestpay.be.service.RefPaymentTypeService;
import com.bestpay.be.service.RefStatusService;

/**
 * @author Ilhomjon
 * @since Feb 22, 2018
 */
@RestController
public class CommonRestController extends AbstractRestController {

	@Autowired
	private CountryService countryService;

	@Autowired
	private RefPaymentTypeService paymentTypeService;

	@Autowired
	private RefStatusService refStatusSvc;

	@GetMapping(value = BeUrlConstants.COUNTRIES, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<Country> getCountryList(HttpServletRequest request) {
		List<Country> resList = new ArrayList<>();
		List<RefCountry> countryList = countryService.allCountries();

		for (RefCountry cnt : countryList) {
			Country country = dozerMapper.map(cnt, Country.class);
			resList.add(country);
		}
		return resList;
	}

	@GetMapping(value = BeUrlConstants.REF_PAYMENT_TYPES, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<PaymentType> getRefPaymentTypes(HttpServletRequest request) {
		List<PaymentType> resList = new ArrayList<>();
		List<RefPaymentType> paymentTypeList = paymentTypeService.getAllPaymentTypes();

		PaymentType paymentType;
		for (RefPaymentType cnt : paymentTypeList) {
			paymentType = dozerMapper.map(cnt, PaymentType.class);
			resList.add(paymentType);
		}
		return resList;
	}

	@GetMapping(value = BeUrlConstants.REF_PAYMENT_STATUS_CODE, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Status> getRefStatusLst() {
		List<RefStatus> refStatusLst = refStatusSvc.primaryDao().findAll();
		List<Status> refStatSdk = new ArrayList<>();
		for (RefStatus r : refStatusLst) {
			refStatSdk.add(dozerMapper.map(r, Status.class));
		}
		return refStatSdk;
	}

	@GetMapping(value = BeUrlConstants.REF_PAYMENT_STATUS_CODE + "/nextItem", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public Status getRefStatusLst(@RequestParam String statusCode) {
		List<RefStatus> refStatusLst = refStatusSvc.primaryDao().findAll();
		Status refStatSdk = new Status();
		boolean controller = false;
		for (RefStatus r : refStatusLst) {
			if (controller) {
				refStatSdk = dozerMapper.map(r, Status.class);
				controller = false;
			}
			if (r.getStatusCode().equals(statusCode)) {
				controller = true;
			}
		}
		return refStatSdk;
	}
}