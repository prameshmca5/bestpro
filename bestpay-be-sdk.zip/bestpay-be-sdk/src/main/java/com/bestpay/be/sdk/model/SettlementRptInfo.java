/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import com.bestpay.be.sdk.constants.BaseConstants;
import com.bstsb.util.serializer.JsonDateSerializer;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;


/**
 * @author Afif Saman
 * @since June 6, 2018
 */
public class SettlementRptInfo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -7480962350918069669L;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH)
	private Date settleDate;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH)
	private Date sttleDateFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH)
	private Date sttleDateTo;

	private Integer settlementId;

	private String chequeNo;

	private Double amount;

	private Double actualAmount;

	private Double costPenalty;

	private Double extraFee;

	private Double chargeback;

	private Integer merProfId;

	private Timestamp createDt;

	private Double currencyRate;

	private String channel;


	public Double getCurrencyRate() {
		return currencyRate;
	}


	public void setCurrencyRate(Double currencyRate) {
		this.currencyRate = currencyRate;
	}


	public Date getSettleDate() {
		return settleDate;
	}


	public void setSettleDate(Date settleDate) {
		this.settleDate = settleDate;
	}


	public Date getSttleDateFrom() {
		return sttleDateFrom;
	}


	public void setSttleDateFrom(Date sttleDateFrom) {
		this.sttleDateFrom = sttleDateFrom;
	}


	public Date getSttleDateTo() {
		return sttleDateTo;
	}


	public void setSttleDateTo(Date sttleDateTo) {
		this.sttleDateTo = sttleDateTo;
	}


	public Integer getSettlementId() {
		return settlementId;
	}


	public void setSettlementId(Integer settlementId) {
		this.settlementId = settlementId;
	}


	public String getChequeNo() {
		return chequeNo;
	}


	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public Double getActualAmount() {
		return actualAmount;
	}


	public void setActualAmount(Double actualAmount) {
		this.actualAmount = actualAmount;
	}


	public Double getCostPenalty() {
		return costPenalty;
	}


	public void setCostPenalty(Double costPenalty) {
		this.costPenalty = costPenalty;
	}


	public Double getExtraFee() {
		return extraFee;
	}


	public void setExtraFee(Double extraFee) {
		this.extraFee = extraFee;
	}


	public Double getChargeback() {
		return chargeback;
	}


	public void setChargeback(Double chargeback) {
		this.chargeback = chargeback;
	}


	public Integer getMerProfId() {
		return merProfId;
	}


	public void setMerProfId(Integer merProfId) {
		this.merProfId = merProfId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	
	public String getChannel() {
		return channel;
	}


	
	public void setChannel(String channel) {
		this.channel = channel;
	}

}
