/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.constants;

import java.util.HashMap;
import java.util.Map;

import com.util.BaseUtil;

/**
 * @author Ramesh Pongiannan
 */
public class CryptoChangePwdSms {

	public static String ToUrlStringEncrypt(String encrpt) {
		return encrpt.replaceAll("passcode","zGGFw");
	}

	public static String FromUrlStringDecrypt(String decrpt) {
		return decrpt.replaceAll("zGGFw", "passcode");
	}
 
	 public static String ToUrlPassCodeEncrypt(String data) {
		 String[] datasplit = data.split("");
		 StringBuilder builder = new StringBuilder();
		 Map<Integer, Character> charPasscode = new HashMap<>();
			charPasscode.put(0, 'Q');
			charPasscode.put(1, 'f');
			charPasscode.put(2, 'M');
			charPasscode.put(3, 'L');
			charPasscode.put(4, 'r');
			charPasscode.put(5, 'p');
			charPasscode.put(6, 't');
			charPasscode.put(7, 'Y');
			charPasscode.put(8, 'e');
			charPasscode.put(9, 'V');
		 for (int i=0; i<datasplit.length;i++) {
			 Integer intPass = new Integer(datasplit[i]);
			 char getEnc = charPasscode.get(intPass);
			 builder.append(getEnc);
		}
		 String ss = builder.toString();
		 return ss;
	}
	 
	 public static String FromUrlPassCodeDecrypt(String data) {
		 char[] datasplit = data.toCharArray();
		 StringBuilder builder = new StringBuilder();
		 Map<Character, Integer> charPasscode = new HashMap<>();
			charPasscode.put('Q', 0);
			charPasscode.put('f', 1);
			charPasscode.put('M', 2);
			charPasscode.put('L', 3);
			charPasscode.put('r', 4);
			charPasscode.put('p', 5);
			charPasscode.put('t', 6);
			charPasscode.put('Y', 7);
			charPasscode.put('e', 8);
			charPasscode.put('V', 9);
		 for (char csplt : datasplit) {
			// System.out.println("Result String ==> "+csplt);
			 Integer getEnc = charPasscode.get(csplt);
			 builder.append(getEnc);
		}
		 String ss = builder.toString();
		 return ss;
	}
	 
	 public static String urlStringPasscodeEncryption(String inputString) {
			StringBuilder sb = new StringBuilder();
			String[] splitdata = inputString.split("=");
			String sptStr1 = splitdata[0];
			String sptStr2 = splitdata[1];
			sb.append(ToUrlStringEncrypt(sptStr1));
			sb.append(ToUrlPassCodeEncrypt(sptStr2));
			return sb.toString();
		}
	 
	 public static String urlStringPasscodeDecryption(String inputString) {
			StringBuilder sb = new StringBuilder();
			String sptStr1 = inputString.substring(0, 5);
			String sptStr2 = inputString.substring(5,11);
			if(BaseUtil.isEquals("zGGFw", sptStr1)) {
				sb.append("?passcode=");
			}
			//System.out.println("sptStr1==> "+sptStr1);
			//System.out.println("sptStr2==> "+sptStr2);
			String apdStr = FromUrlPassCodeDecrypt(sptStr2);
			sb.append(apdStr);
			return sb.toString();
		}
}
