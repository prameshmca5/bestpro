/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;
import java.util.List;

/**
 * @author michelle.angela
 *
 */
public class McProfile implements Serializable, IQfCriteria<McProfile> {

	private static final long serialVersionUID = 5423830452247264132L;

	private Integer mcProfId;

	private Metadata orgTypeMtdt;
	 
	private Metadata mcTypeMtdt;
		
	private String mcRegNo;
	
	private String mcName;
	
	private String contactNo;
	
	private String contactNo2;
	
	private String faxNo;
	
	private String email;
	
	private String website;
	
	private String docRefNo;
	
	private List<McOwner> mcOwners;
	
	private List<McPic> mcPics;
	
	private List<McAddress> mcAddresses;
	
	private List<TrxnDocuments> trxnDocuments;
	
	private boolean embedOwners;
	
	private boolean embedPICs;
	
	private boolean embedAddresses;
	
	private String orgTypeMtdtCd;
	 
	private String mcTypeMtdtCd;
	
	private String cntryCd;
	
	private String cntryDesc;
	
	private String systemType;

	public Integer getMcProfId() {
		return mcProfId;
	}

	public void setMcProfId(Integer mcProfId) {
		this.mcProfId = mcProfId;
	}

	public Metadata getOrgTypeMtdt() {
		return orgTypeMtdt;
	}

	public void setOrgTypeMtdt(Metadata orgTypeMtdt) {
		this.orgTypeMtdt = orgTypeMtdt;
	}

	public Metadata getMcTypeMtdt() {
		return mcTypeMtdt;
	}

	public void setMcTypeMtdt(Metadata mcTypeMtdt) {
		this.mcTypeMtdt = mcTypeMtdt;
	}

	public String getMcRegNo() {
		return mcRegNo;
	}

	public void setMcRegNo(String mcRegNo) {
		this.mcRegNo = mcRegNo;
	}

	public String getMcName() {
		return mcName;
	}

	public void setMcName(String mcName) {
		this.mcName = mcName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getContactNo2() {
		return contactNo2;
	}

	public void setContactNo2(String contactNo2) {
		this.contactNo2 = contactNo2;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getDocRefNo() {
		return docRefNo;
	}

	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}

	public List<McOwner> getMcOwners() {
		return mcOwners;
	}

	public void setMcOwners(List<McOwner> mcOwners) {
		this.mcOwners = mcOwners;
	}

	public List<McPic> getMcPics() {
		return mcPics;
	}

	public void setMcPics(List<McPic> mcPics) {
		this.mcPics = mcPics;
	}


	public List<McAddress> getMcAddresses() {
		return mcAddresses;
	}

	public void setMcAddresses(List<McAddress> mcAddresses) {
		this.mcAddresses = mcAddresses;
	}

	public List<TrxnDocuments> getTrxnDocuments() {
		return trxnDocuments;
	}

	public void setTrxnDocuments(List<TrxnDocuments> trxnDocuments) {
		this.trxnDocuments = trxnDocuments;
	}

	public boolean isEmbedOwners() {
		return embedOwners;
	}

	public void setEmbedOwners(boolean embedOwners) {
		this.embedOwners = embedOwners;
	}

	public boolean isEmbedPICs() {
		return embedPICs;
	}

	public void setEmbedPICs(boolean embedPICs) {
		this.embedPICs = embedPICs;
	}

	public boolean isEmbedAddresses() {
		return embedAddresses;
	}

	public void setEmbedAddresses(boolean embedAddresses) {
		this.embedAddresses = embedAddresses;
	}

	public String getOrgTypeMtdtCd() {
		return orgTypeMtdtCd;
	}

	public void setOrgTypeMtdtCd(String orgTypeMtdtCd) {
		this.orgTypeMtdtCd = orgTypeMtdtCd;
	}

	public String getMcTypeMtdtCd() {
		return mcTypeMtdtCd;
	}

	public void setMcTypeMtdtCd(String mcTypeMtdtCd) {
		this.mcTypeMtdtCd = mcTypeMtdtCd;
	}

	public String getCntryCd() {
		return cntryCd;
	}

	public void setCntryCd(String cntryCd) {
		this.cntryCd = cntryCd;
	}

	public String getSystemType() {
		return systemType;
	}

	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}

	public String getCntryDesc() {
		return cntryDesc;
	}

	public void setCntryDesc(String cntryDesc) {
		this.cntryDesc = cntryDesc;
	}
	
}
