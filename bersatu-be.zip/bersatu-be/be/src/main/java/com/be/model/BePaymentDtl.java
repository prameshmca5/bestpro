package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "BE_PAYMENT_DTL")
public class BePaymentDtl extends AbstractEntity implements Serializable, IQfCriteria<BePaymentDtl> {

	/**
	 *
	 */
	private static final long serialVersionUID = 6723281272583273849L;

	@Id
	@Column(name = "PMT_DTL_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer pmtDtlId;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "PMT_ID")
	private BePayment payment;

	@Column(name = "PMT_DTL_REF_NO")
	private String pmtDtlRefNo;

	@Column(name = "ITEM_ID")
	private String itemId;

	@Column(name = "CURRENCY")
	private String currency;

	@Column(name = "ITEM_AMOUNT")
	private Double itemAmount;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getPmtDtlId() {
		return pmtDtlId;
	}


	public void setPmtDtlId(Integer pmtDtlId) {
		this.pmtDtlId = pmtDtlId;
	}


	public BePayment getPayment() {
		return payment;
	}


	public void setPayment(BePayment payment) {
		this.payment = payment;
	}


	public String getItemId() {
		return itemId;
	}


	public void setItemId(String itemId) {
		this.itemId = itemId;
	}


	public Double getItemAmount() {
		return itemAmount;
	}


	public void setItemAmount(Double itemAmount) {
		this.itemAmount = itemAmount;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public String getPmtDtlRefNo() {
		return pmtDtlRefNo;
	}


	public void setPmtDtlRefNo(String pmtDtlRefNo) {
		this.pmtDtlRefNo = pmtDtlRefNo;
	}

}
