/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.sdk.model.TransactionRptInfo;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.report.sdk.constants.ReportTypeEnum;
import com.bestpay.report.sdk.model.Report;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ReportUtil;
import com.bestpay.web.util.WebUtil;
import com.bstsb.util.DateUtil;
import com.google.gson.Gson;


/**
 * @author Afif Saman
 * @since June 20, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_DAILY_RPT)
public class DailyReportController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(DailyReportController.class);

	private static final String ADDFIELD = "addField";

	private static final String STATUS = "status";


	@GetMapping
	public ModelAndView view(@ModelAttribute("transRptInfo") TransactionRptInfo transRptInfo, BindingResult result,
			HttpSession session) {
		// Removing session attributes if any
		session.removeAttribute(STATUS);
		session.removeAttribute(ADDFIELD);

		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_DAILY_RPT, "report", null, "daily-report-script");
		List<Status> status;
		try {
			status = staticData.status("TRANSTAT");
			mav.addObject("statusList", status);
		} catch (BeException e) {
			LOGGER.error("Error view daily report {}", e);
		}
		return mav;
	}


	@PostMapping(params = "search")
	public ModelAndView search(@ModelAttribute("transRptInfo") TransactionRptInfo transRptInfo, BindingResult result,
			HttpServletRequest request, HttpSession session) {
		// Set session attributes
		session.setAttribute(STATUS, transRptInfo.getStatus());
		session.setAttribute(ADDFIELD, transRptInfo.getAddField());

		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_DAILY_RPT, "report", null, "daily-report-script");
		List<Status> status;
		try {
			status = staticData.status("TRANSTAT");
			mav.addObject("statusList", status);
		} catch (BeException e) {
			LOGGER.error("Error search daily report {}", e);
		}
		mav.addObject("transRptInfo", transRptInfo);
		return mav;
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String getTransactionRptInfoPaginated(
			@ModelAttribute("transRptInfo") TransactionRptInfo transRptInfo, BindingResult result,
			HttpServletRequest request) {
		LOGGER.info("GET PAGINATED DATE RANGE REPORT LIST....");
		UserProfile authUser = getCurrentUser();
		if (LOGGER.isDebugEnabled()) {
			LOGGER.info("User ID = {}", authUser);
		}
		DataTableResults<TransactionRptInfo> reports = null;
		new SimpleDateFormat("yyyy-mm-dd");
		Date date = new Date();
		transRptInfo.setCreateDt(DateUtil.convertDate2SqlTimeStamp(date));
		try {
			reports = getBeService().searchTransactionReport(transRptInfo, getPaginationRequest(request, true));
		} catch (Exception e) {
			if (WebUtil.checkSystemDown(e)) {
				LOGGER.error(e.getMessage());
			}
			LOGGER.error(e.getMessage());
		}

		return new Gson().toJson(reports);
	}


	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute("transRptInfo") @Validated TransactionRptInfo transRptInfo,
			BindingResult result, HttpServletRequest request, HttpSession session) {
		TransactionRptInfo transactionRptInfo = new TransactionRptInfo();
		return view(transactionRptInfo, result, session);
	}


	@GetMapping(value = "print/genDailyReport")
	public @ResponseBody Report genDailyTransReport(
			@ModelAttribute("transactionRptInfo") TransactionRptInfo transactionRptInfo,
			@RequestParam(value = STATUS, required = false) String status,
			@RequestParam(value = ADDFIELD, required = false) String addField, BindingResult result,
			HttpServletRequest request, HttpSession session) {

		Report report = null;
		try {
			report = getReportService().genDailyRpt(status, addField, ReportTypeEnum.PDF, true, 0);
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.debug("Context {}", e);
		}
		return report;
	}


	@GetMapping(value = "print/dailyCsvReport.xls")
	public @ResponseBody ResponseEntity<byte[]> genCSVDataReport(
			@ModelAttribute("transactionRptInfo") TransactionRptInfo transactionRptInfo, BindingResult result,
			HttpServletRequest request, HttpSession session) {

		String status = (String) request.getSession(true).getAttribute(STATUS);
		String addField = (String) request.getSession(true).getAttribute(ADDFIELD);
		if (!StringUtils.hasText(status)) {
			status = "";
		}
		if (!StringUtils.hasText(addField)) {
			addField = "";
		}
		try {
			Report report = getReportService().genDailyRpt(status, addField, ReportTypeEnum.CSV, true, 0);
			if (!BaseUtil.isObjNull(report)) {
				byte[] fb = report.getReportBytes();
				return new ResponseEntity<>(fb, ReportUtil.getHttpHeadersCSV("DailyReport", fb.length),
						HttpStatus.OK);
			}

		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.debug("Context {}", e);
		}
		return null;
	}
}