/**
 * Copyright 2019. Bestinet Sdn Bhd
 */
package com.bestid.be.qf;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidConfig;
import com.bestid.be.repo.BidConfigRepository;
import com.bestid.be.sdk.model.RefBidConfig;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.pagination.DataTableRequest;
import com.bstsb.util.pagination.DataTableResults;
import com.bstsb.util.pagination.PaginationCriteria;


/**
 * @author mohd.faisal
 * @since Mar 6, 2019
 */
@Service(QualifierConstants.BID_CONFIG_QF)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_CONFIG_QF)
@Transactional
public class BidConfigQf {

	private static final Logger LOGGER = LoggerFactory.getLogger(BidConfigQf.class);

	@PersistenceContext
	private EntityManager em;

	@Autowired
	@Qualifier(QualifierConstants.BID_CONFIG_REPOSITORY)
	BidConfigRepository bidConfigRepository;


	@SuppressWarnings("unchecked")
	public DataTableResults<BidConfig> getBidConfigPaginated(DataTableRequest<BidConfig> dataTableRequest,
			RefBidConfig config) {
		DataTableResults<BidConfig> dataTableResult = new DataTableResults<>();

		try {

			StringBuilder sb = new StringBuilder("select u from BidConfig u");
			sb.append(" where 1=1 ");

			if (!BaseUtil.isObjNull(config.getConfigId()) && (config.getConfigId() != 0)) {
				sb.append(" and u.configId=:configId ");
			}
			if (!BaseUtil.isObjNull(config.getConfigCd())) {
				sb.append(" and u.configCd like :configCd ");
			}
			if (!BaseUtil.isObjNull(config.getConfigDesc())) {
				sb.append(" and u.configDesc like :configDesc ");
			}
			if (!BaseUtil.isObjNull(config.getConfigVal())) {
				sb.append(" and u.configVal like :configVal ");
			}

			Query query = em.createQuery(sb.toString());
			Query query2 = em.createQuery(sb.toString());

			if (!BaseUtil.isObjNull(config.getConfigId()) && (config.getConfigId() != 0)) {
				LOGGER.info("ID REQUESTED : {}", config.getConfigId());
				query.setParameter("configId", config.getConfigId());
				query2.setParameter("configId", config.getConfigId());
			}
			if (!BaseUtil.isObjNull(config.getConfigCd())) {
				LOGGER.info("CONFIGCODE REQUESTED : {}", config.getConfigCd());
				query.setParameter("configCd", "%" + config.getConfigCd() + "%");
				query2.setParameter("configCd", config.getConfigCd());
			}
			if (!BaseUtil.isObjNull(config.getConfigDesc())) {
				LOGGER.info("CONFIGDESC REQUESTED : {}", config.getConfigDesc());
				query.setParameter("configDesc", "%" + config.getConfigDesc() + "%");
				query2.setParameter("configDesc", config.getConfigDesc());
			}
			if (!BaseUtil.isObjNull(config.getConfigVal())) {
				LOGGER.info("CONFIGVAL REQUESTED : {}", config.getConfigVal());
				query.setParameter("configVal", "%" + config.getConfigVal() + "%");
				query2.setParameter("configVal", config.getConfigVal());
			}

			PaginationCriteria pagination = dataTableRequest.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}

			dataTableResult = new DataTableResults<>();
			List<BidConfig> objList = query.getResultList();
			List<BidConfig> objList2 = query2.getResultList();
			int totalRecords = dataTableRequest.isInitSearch() ? objList2.size()
					: bidConfigRepository.totalRecords();

			dataTableResult.setDraw(dataTableRequest.getDraw());
			dataTableResult.setData(objList);
			dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
			if (dataTableRequest.getPaginationRequest().isFilterByEmpty()) {
				dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
			} else {
				dataTableResult.setRecordsFiltered(Integer.toString(objList2.size()));
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		return dataTableResult;
	}


	public Map<String, Serializable> countRecord(String configCd) {

		Map<String, Serializable> data = new HashMap<>();

		StringBuilder sb = new StringBuilder("select count(u.configCd) as total from BidConfig u");
		sb.append(" where 1=1 ");
		sb.append(" and u.configCd= ?1 ");

		Query query = em.createQuery(sb.toString());
		query.setParameter(1, configCd);

		Long u = (Long) query.getSingleResult();
		data.put("total", u.intValue());
		if (u.intValue() == 1) {
			StringBuilder sb2 = new StringBuilder("select u from BidConfig u");
			sb2.append(" where 1=1 ");
			sb2.append(" and u.configCd= ?1 ");

			TypedQuery<BidConfig> query2 = em.createQuery(sb2.toString(), BidConfig.class);
			query2.setParameter(1, configCd);
			BidConfig config = query2.getSingleResult();
			data.put("bidConfig", config);
		} else {
			BidConfig config = new BidConfig();
			data.put("bidConfig", config);
		}

		return data;
	}
}
