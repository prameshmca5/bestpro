package com.bestpay.be.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.RefDocumentRepository;
import com.bestpay.be.model.RefDocument;
import com.bestpay.be.util.QualifierConstants;


@Transactional
@Service(QualifierConstants.REF_DOCUMENT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_DOCUMENT_SVC)
public class RefDocumentService extends AbstractService<RefDocument> {

	@Autowired
	private RefDocumentRepository refDocumentDao;


	@Override
	public GenericRepository<RefDocument> primaryDao() {
		return refDocumentDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<RefDocument> findAllByTrxnNo(@Param("trxnNo") String trxnNo) {
		return refDocumentDao.findAllByTrxnNo(trxnNo);
	}

}