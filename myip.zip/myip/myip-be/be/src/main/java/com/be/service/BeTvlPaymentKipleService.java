/**
 * 
 */
package com.be.service;

import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTvlPaymentKipleRepository;
import com.be.dao.BeTvlPaymentQf;
import com.be.model.BeTvlPayment;
import com.be.model.BeTvlPaymentKiple;
import com.be.model.RefPymntMsgCode;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Payment;
import com.be.sdk.model.PaymentKiple;
import com.util.BaseUtil;
import com.util.JsonUtil;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_PAYMENT_KIPLE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_PAYMENT_KIPLE_SVC)
public class BeTvlPaymentKipleService extends AbstractService<BeTvlPaymentKiple> {

	@Autowired
	private BeTvlPaymentKipleRepository beTvlPaymentKipleDao;
	
	@Autowired
	private BeTvlPaymentQf beTvlPaymentQf;
	
	@Override
	public GenericRepository<BeTvlPaymentKiple> primaryDao() {
		return beTvlPaymentKipleDao;
	}

	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class })
	public BeTvlPaymentKiple addPaymentKipleInfo(PaymentKiple dto, String userId) throws IOException {
		
		Payment paymnt = new Payment();
		paymnt.setPmtRefNo(dto.getPmtRefNo());
		BeTvlPayment beTvlPayment =  beTvlPaymentQf.searchPayment(paymnt);
	 	
		String respcode = beTvlPayment.getStatusPymntMsgCode().getRespCd();
		Integer stscode = beTvlPayment.getStatusPymntMsgCode().getStatusCd();
		Integer refpmtcode = beTvlPayment.getStatusPymntMsgCode().getPymntMsgCodeId();
		
		dto = JsonUtil.transferToObject(beTvlPayment, PaymentKiple.class);
		RefPymntMsgCode refPymntMsgCode = new RefPymntMsgCode();
		refPymntMsgCode.setStatusCd(beTvlPayment.getRespPymntMsgCode().getStatusCd());
		refPymntMsgCode.setRespCd(respcode);
		refPymntMsgCode.setPymntMsgCodeId(refpmtcode);
		refPymntMsgCode.setPymntMsgCodeId(stscode); 
		dto.setMessageId(dto.getMessageId());
		dto.setReqData(dto.getReqData());
		BeTvlPaymentKiple beTvlPaymentKiple = JsonUtil.transferToObject(dto, BeTvlPaymentKiple.class);
		beTvlPaymentKiple.setCreateId(userId);
		beTvlPaymentKiple.setUpdateId(userId);
		beTvlPaymentKiple.setStatusPymntMsgCode(refPymntMsgCode);
		beTvlPaymentKiple.setRespPymntMsgCode(refPymntMsgCode);
		
		beTvlPaymentKiple = update(beTvlPaymentKiple);
		return beTvlPaymentKiple;
	}
	
	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beTvlPaymentQf.generateCriteria(cb, from, criteria);
	}
	
	public BeTvlPaymentKiple addPaymentKipleInfo(BeTvlPayment beTvlPayment, String userId) 
			throws IOException {
		
		BeTvlPaymentKiple beTvlPaymentKiple = null;
		if(!BaseUtil.isObjNull(beTvlPayment)) {
			beTvlPaymentKiple = JsonUtil.transferToObject(beTvlPayment, BeTvlPaymentKiple.class);
			beTvlPaymentKiple.setCreateId(userId);
			beTvlPaymentKiple.setUpdateId(userId);
			beTvlPaymentKiple = update(beTvlPaymentKiple);
		}
		return beTvlPaymentKiple;
	}
}
