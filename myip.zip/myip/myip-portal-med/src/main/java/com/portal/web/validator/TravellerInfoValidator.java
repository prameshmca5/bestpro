/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.portal.web.validator;



import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.be.sdk.model.AcctTraveller;
import com.portal.constants.MessageConstants;
import com.portal.core.AbstractController;
import com.portal.web.util.ValidationUtil;
import com.util.BaseUtil;


/**
 * @author Amirah Ibrahim
 * @since August 18, 2020
 */
@Component("travellerInfoValidator")
public class TravellerInfoValidator extends AbstractController implements Validator {

	private static final String FULLNAME = "fullName";
	
	private static final String GENDER = "gender";

	private static final String PASSPORT = "acctPassport.passportNo";

	private static final String NATIONALITY = "acctPassport.nationality.cntryCd";

	private static final String DOB = "dobStr";
	
	private static final String BIRTH_PLACE = "birthPlace.cntryCd";
	
	private static final String EC_NAME = "emrgncyCntctName";
	
	private static final String EC_MOBILE_NO = "emrgncyCntctNo";
	
	private static final String EC_EMAIL = "ecEmail";


	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}

	@Override
	public void validate(Object target, Errors errors) {
		AcctTraveller acctTraveller = (AcctTraveller) target;
        if (target instanceof AcctTraveller) {
        	
        	ValidationUtil.rejectIfEmptyOrWhitespace(errors, FULLNAME, MessageConstants.ERROR_FIELDS_FULLNAME);
        	
        	ValidationUtil.rejectIfEmptyOrWhitespace(errors, NATIONALITY, MessageConstants.ERROR_FIELDS_NATIONALITY);
        	ValidationUtil.rejectIfEmptyOrWhitespace(errors, PASSPORT, MessageConstants.ERROR_FIELDS_PSPORT_REQ);
        	ValidationUtil.rejectIfLengthIsInvalid(errors, PASSPORT, MessageConstants.ERROR_MAX_LENGTH_PASSPORT, 1, 11);
        	ValidationUtil.rejectIfEmptyOrWhitespace(errors, GENDER, MessageConstants.ERROR_FIELDS_GENDER);
        	ValidationUtil.rejectIfEmptyOrWhitespace(errors, "contactNo", MessageConstants.ERROR_CONTACT_PHONE_REQUIRED);
    		ValidationUtil.rejectIfEmptyOrWhitespace(errors, DOB, MessageConstants.ERROR_DOB);
    		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "passportExpStr", MessageConstants.DATE_REQ);
    		ValidationUtil.rejectIfEmptyOrWhitespace(errors, BIRTH_PLACE, MessageConstants.ERROR_FIELDS_DOB_PLACE);
    		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "addr1", MessageConstants.ERROR_FIELDS_ADD1);
    		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "addr2", MessageConstants.ERROR_FIELDS_ADDRESS);
    		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "stateDesc", MessageConstants.ERROR_FIELDS_STATE);
    		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "cityDesc", MessageConstants.ERROR_CITY);
    		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "zipcode", MessageConstants.ERROR_FIELDS_ZIPCODE_ACCOMMD);
    		
        	ValidationUtil.rejectIfEmptyOrWhitespace(errors, "country.cntryCd", MessageConstants.ERROR_FIELDS_CNTRY);
        	ValidationUtil.rejectIfEmptyOrWhitespace(errors, "photoId", MessageConstants.ERROR_FIELDS_PHOTO_PROFILE_REQ);
        	ValidationUtil.rejectIfEmptyOrWhitespace(errors, "passportPhotoId", MessageConstants.ERROR_FIELDS_PHOTO_PSSPORT_REQ);
    		
    		
        	if( BaseUtil.isEqualsCaseIgnore(acctTraveller.getRelationMtdt().getMtdtCd(), "SLF") ) {
        		ValidationUtil.rejectIfEmptyOrWhitespace(errors, EC_NAME, MessageConstants.ERROR_FIELDS_EC_NAME);
        		ValidationUtil.rejectIfEmptyOrWhitespace(errors, EC_MOBILE_NO, MessageConstants.ERROR_FIELDS_EC_MOBILE);
        		ValidationUtil.rejectIfEmptyOrWhitespace(errors, EC_EMAIL, MessageConstants.ERROR_FIELDS_EC_EMAIL);
        	}
        }
		
	}

}