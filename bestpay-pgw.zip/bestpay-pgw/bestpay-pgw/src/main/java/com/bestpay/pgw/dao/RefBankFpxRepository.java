/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.RefBank;
import com.bestpay.pgw.util.QualifierConstants; 
/**
 * @author Sridhar Kapidi
 * @since 20/11/2017
 */
@Repository
@RepositoryDefinition(domainClass=RefBank.class, idClass=String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_BANK_FPX_DAO)
public interface RefBankFpxRepository extends GenericRepository<RefBank>{
	
	@Query("select u from RefBank u where u.bankCode = :bankCode ")
	public List<RefBank> findByBankCode(@Param("bankCode") String bankCode);
	
	@Query("select u from RefBank u where u.bankCode in :bankCode and u.type =:type order by displayName ")
    public List<RefBank> findByBankCodeList(@Param("bankCode") List<String> bankCode, @Param("type") String type);
	

}