/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 * @author Atiqah Khairuddin
 *
 */
public class TvlTestResult implements Serializable {

	private static final long serialVersionUID = 4484528769852221123L;

	private Integer tvlTestResultId;

	private String mcRefNo;

	private Integer mcProfId;

	private TvlProfile tvlProfile;

//	@JsonSerialize(using = JsonDateSerializer.class)
//	@JsonDeserialize(using = JsonDateDeserializer.class)
//	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Timestamp medTestDt;

	private Integer doctorProfId;

	private String cntryCd;

	private Integer medicalResult;

	private String remarks;

	private String doctorRemarks;

	private Integer statusId;

	private String docRefNo;

	private List<McCollate> mcCollates;

	private List<TrxnDocuments> trxnDocumentList;

	private Integer tvlProfId;

	private McProfile mcProfile;
	
	private Status status;

	public Integer getTvlTestResultId() {
		return tvlTestResultId;
	}


	public void setTvlTestResultId(Integer tvlTestResultId) {
		this.tvlTestResultId = tvlTestResultId;
	}


	public String getMcRefNo() {
		return mcRefNo;
	}


	public void setMcRefNo(String mcRefNo) {
		this.mcRefNo = mcRefNo;
	}


	public Integer getMcProfId() {
		return mcProfId;
	}


	public void setMcProfId(Integer mcProfId) {
		this.mcProfId = mcProfId;
	}


	public TvlProfile getTvlProfile() {
		return tvlProfile;
	}


	public void setTvlProfile(TvlProfile tvlProfile) {
		this.tvlProfile = tvlProfile;
	}


	public Timestamp getMedTestDt() {
		return medTestDt;
	}


	public void setMedTestDt(Timestamp medTestDt) {
		this.medTestDt = medTestDt;
	}


	public Integer getDoctorProfId() {
		return doctorProfId;
	}


	public void setDoctorProfId(Integer doctorProfId) {
		this.doctorProfId = doctorProfId;
	}


	public String getCntryCd() {
		return cntryCd;
	}


	public void setCntryCd(String cntryCd) {
		this.cntryCd = cntryCd;
	}


	public Integer getMedicalResult() {
		return medicalResult;
	}


	public void setMedicalResult(Integer medicalResult) {
		this.medicalResult = medicalResult;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public String getDoctorRemarks() {
		return doctorRemarks;
	}


	public void setDoctorRemarks(String doctorRemarks) {
		this.doctorRemarks = doctorRemarks;
	}


	public Integer getStatusId() {
		return statusId;
	}


	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public List<McCollate> getMcCollates() {
		return mcCollates;
	}


	public void setMcCollates(List<McCollate> mcCollates) {
		this.mcCollates = mcCollates;
	}


	public Integer getTvlProfId() {
		return tvlProfId;
	}


	public void setTvlProfId(Integer tvlProfId) {
		this.tvlProfId = tvlProfId;
	}


	public List<TrxnDocuments> getTrxnDocumentList() {
		return trxnDocumentList;
	}


	public void setTrxnDocumentList(List<TrxnDocuments> trxnDocumentList) {
		this.trxnDocumentList = trxnDocumentList;
	}


	public McProfile getMcProfile() {
		return mcProfile;
	}


	public void setMcProfile(McProfile mcProfile) {
		this.mcProfile = mcProfile;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}

}
