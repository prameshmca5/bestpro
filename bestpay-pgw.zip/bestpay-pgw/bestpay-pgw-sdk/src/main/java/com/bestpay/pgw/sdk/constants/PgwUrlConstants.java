/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class PgwUrlConstants {

	private PgwUrlConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String SERVICE_CHECK = "/serviceCheck";

	public static final String REFERENCE = "/references";

	public static final String APJ_CONFIG = REFERENCE + "/config";

	public static final String SST_BLK_TRAN = REFERENCE + "/blktran";

	public static final String REF_REF_COUNTRY = REFERENCE + "/references/getRefCountry";

	public static final String COUNTRIES = REFERENCE + "/countries";

	public static final String STATES = REFERENCE + "/states";

	public static final String STATUS = REFERENCE + "/status";

	public static final String REF_PAYMENT_TYPES = "/refPaymentTypes";

	public static final String REF_PAYMENT_TYPES_CODE = "/refPaymentCode";

	public static final String REF_PAYMENT_STATUS_CODE = "/refStatusCode";

	public static final String CITY = "/cities";

	public static final String RELATIONSHIP = "/relationship";

	public static final String GET_ALL_RELATIONSHIP = "/getAllRelationship";

	public static final String GET_ALL_STATE = "/getAllState";

	public static final String GET_ALL_COUNTRY = "/getAllCountry";

	public static final String GET_ALL_NATIONALITY = "/getAllNationality";

	public static final String GET_ALL_NATIONALITY_CODE = "/findByNationalityCode";

	public static final String GET_ALL_NATIONALITY_DESC = "/findNationalityByDesc";

	public static final String GET_ALL_STAUS = "/getAllStatus";

	public static final String FIND_BY_BANK_CODE_LIST = "/findByBankCodeList";

	public static final String FIND_BY_ORDER_ID_TRANSID = "/findByTransIdAndOrderId";

	public static final String FIND_BY_MERCHANT_ID_ORDER_ID = "/findByMerchantIdAndOrderId";

	public static final String REF_TYPE_FPX_RES_CODE = "fpxResponseCode";

	public static final String ADD_FPX_RESPONSE = "/addFpxResponse";

	public static final String SAVE_PGW_AUDIT_AUDIT = "/savePgwAuditTrail";

	public static final String PAGE_SCHEDULER_PAYMENT = "/schedulerBestPay";

	public static final String PGW_PAYMENT_REQHASH_KEY = "reqhash";

	public static final String PGW_PAYMENT_REQHASH_PATTERN = "(?:^|[?&])reqhash=([^&]*)";

	public static final String PGW_PAYMENT_RESHASH_KEY = "reshash";

	public static final String PGW_PAYMENT_RESHASH_PATTERN = "(?:^|[?&])reshash=([^&]*)";

	public static final String CREATE_PGW_TRANSACTION = "/createPgwTransaction";

	public static final String UPDATE_CHANNEL_AND_BANK = "/updateChannelandBank";

	public static final String UPDATE_PGW_TRANSACTION = "/updatePgwTransaction";

	public static final String PAYMENT_SETTING = "/paymentSetting";

	public static final String FIND_BY_MERCHANT_ID = "/findByMerchantId";

	public static final String MULTI_CHANNEL_SETTING = "/multiChannel";

	public static final String FIND_FPX_PENDING_TRANS = "/findFpxPendingTransactions";

	public static final String MERCHANT_PROFILE = "/merchantProfile";

	public static final String REF_TYPE_CHANNEL_LIST = "refChannelList";

	public static final String REF_TYPE_FPX_BESTPAY_CODE = "fpxBestpayCode";

	public static final String SAVE_APS_PROFILE = "/saveApsProfile";

	public static final String MAXMONEY_SERVICE = "/maxmoney";

	public static final String GET_MAXMONEY_RATE = "/getMaxMoneyTransferRate";

	public static final String GET_KYC_STATUS = "/getKYCStatus";

	public static final String GET_SESSION_WITH_PID = "/getSessionWithPID";

	public static final String GET_SESSION_WITH_MMPID = "/getSessionWithMMPID";

	public static final String REQUEST_PAYLOAD = "/requestPayload";

	public static final String UPD_CUSTOMER = "/updateCustomer";

	public static final String UPLOAD_DOCS = "/uploadDocs";

	public static final String APPROVE_CUSTOMER = "/approveCustomer";

	public static final String VALIDATE_CUSTOMER = "/validateCustomer";

	public static final String CREATE_USER = "/createUser";

	public static final String MMORDERSTATUS = "/maxmoneyOrderStatus";

	public static final String GET_MAXMONEY_PAYLOAD = "/getMaxmoneyRquestPayload";

	public static final String GET_BENFI_DETAILS = "/getBeneficiaryToOrder";

	public static final String SUBMIT_MAXMONEY_ORDER = "/maxmoneySubmitToOrder";

	public static final String FIND_MERCHANT_PID = "/findMerchantPid";

	public static final String MTO_MERCHANT_PROFILE = "/mtomerchantProfile";

	public static final String ENQUIRE_ORDER_STATUS = "/enquireMaxmoneyOrderStatus";

	public static final String FIND_BY_MERCHANT_ID_REFID = "/findByMerchantIdByRefId";

	public static final String UPDATE_TRANS_STATUS_MAXMONEY = "/updateTransStatus";

	public static final String CHKORDER_STATUS_FROM_MAXMONEY = "/orderenquirefrommaxmoney";

	public static final String FIND_REMIT_PENDING_TRANS = "/findRemitPendingTransactions";

	public static final String CHKORDER_STATUS_CHK = "/mmorderenquire";

	public static final String FIND_BY_ORDER_DET_HIST = "/findByDetailsOrder";

	public static final String TRANS_HISTROY = "/transhistory";

	public static final String INCENTIVEREMIT_SERVICE = "/incentiveremit";

	public static final String SAVE_IR_PROFILE = "/saveIRProfile";
	
	public static final String UPDATE_TRANS_STATUS_IRBILLPLZ = "/updateTransStatusIRBillPlz";
	
	public static final String FIND_BY_MERCHANT_ID_SUBMERID = "/findByMerchantIdBySubmerId";
	
	public static final String FIND_MERCHANT_IRCUSID = "/findMerchantIRCusid";
	
	public static final String MERCHANT_BENEFICIARY = "/merchantBeneficiary";
	
	public static final String FIND_MERCHANT_BENID = "/findMerchantBenid";
	
	public static final String IRORDERSTATUS = "/incentiveOrderStatus";
	
	public static final String FIND_INCENT_BENEF_DETAILS = "/beneficiaryDetails";
	
	public static final String MER_COMP_BANK_DETAILS = "/merCompBankDetails";
	
	public static final String GET_BANK_DETAILS_BY_COMPBANKID = "/getBankDetailsByCompBankId";
	
	public static final String MERCHANT_COMPANY = "/merchantCompany";
	
	public static final String MERCHANT_COMPANY_DETAILS = "/findCompanyDetails";
	
	public static final String PROVIDER = "/provider";
	
	public static final String FIND_BY_TRANSACTION_ID_ORDERID = "/findByMerchantIdByOrderId";
	
	public static final String UPDATE_TRANS_STATUS_IPAY = "/transactionUpdateOrder";
	
	public static final String REF_TYPE_FPX_RES_DESC = "/fpxResponseDesc";
	
	public static final String IPAY_ORDER_SERVICE = "/ipay";

	public static final String IPAY_ORDER_ENQUIRE_STATUS = "/enquireIpayOrderStatus";
	
	public static final String IPAY_STATUS_SCHEDULER = "/ipayStatusScheduler";
}
