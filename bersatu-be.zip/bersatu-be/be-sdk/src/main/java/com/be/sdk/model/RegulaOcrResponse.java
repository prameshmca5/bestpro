/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.util.Date;


/**
 * @author nurul.naimma
 *
 * @since Jun 2, 2021
 */
public class RegulaOcrResponse implements Serializable {

	private static final long serialVersionUID = -2290365963783482240L;

	private String fullName;

	private String idNo;

	private String gender;

	private String religion;

	private Date dob;

	private String address;

	private byte[] image;

	private String format;

	private String address1;

	private String address2;

	private String address3;

	private String postcode;

	private String cityDesc;

	private String stateDesc;


	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}


	/**
	 * @param fullName
	 *             the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	/**
	 * @return the idNo
	 */
	public String getIdNo() {
		return idNo;
	}


	/**
	 * @param idNo
	 *             the idNo to set
	 */
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}


	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}


	/**
	 * @param gender
	 *             the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}


	/**
	 * @return the religion
	 */
	public String getReligion() {
		return religion;
	}


	/**
	 * @param religion
	 *             the religion to set
	 */
	public void setReligion(String religion) {
		this.religion = religion;
	}


	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}


	/**
	 * @param dob
	 *             the dob to set
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}


	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}


	/**
	 * @param address
	 *             the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}


	/**
	 * @return the image
	 */
	public byte[] getImage() {
		return image;
	}


	/**
	 * @param image
	 *             the image to set
	 */
	public void setImage(byte[] image) {
		this.image = image;
	}


	/**
	 * @return the format
	 */
	public String getFormat() {
		return format;
	}


	/**
	 * @param format
	 *             the format to set
	 */
	public void setFormat(String format) {
		this.format = format;
	}


	/**
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}


	/**
	 * @param address1
	 *             the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}


	/**
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}


	/**
	 * @param address2
	 *             the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	/**
	 * @return the address3
	 */
	public String getAddress3() {
		return address3;
	}


	/**
	 * @param address3
	 *             the address3 to set
	 */
	public void setAddress3(String address3) {
		this.address3 = address3;
	}


	/**
	 * @return the postcode
	 */
	public String getPostcode() {
		return postcode;
	}


	/**
	 * @param postcode
	 *             the postcode to set
	 */
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	/**
	 * @return the cityDesc
	 */
	public String getCityDesc() {
		return cityDesc;
	}


	/**
	 * @param cityDesc
	 *             the cityDesc to set
	 */
	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc;
	}


	/**
	 * @return the stateDesc
	 */
	public String getStateDesc() {
		return stateDesc;
	}


	/**
	 * @param stateDesc
	 *             the stateDesc to set
	 */
	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc;
	}

}
