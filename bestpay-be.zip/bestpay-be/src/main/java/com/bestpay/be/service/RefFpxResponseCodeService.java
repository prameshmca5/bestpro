/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.config.ConfigConstants;
import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.FpxResponseCodeRepository;
import com.bestpay.be.model.RefFpxResponseCode;
import com.bestpay.be.sdk.constants.BeCacheConstants;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author
 * @since 27/09/2018
 */
@Service(QualifierConstants.FPX_RESPONSE_CODE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.FPX_RESPONSE_CODE_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
@Transactional
public class RefFpxResponseCodeService extends AbstractService<RefFpxResponseCode> {

	@Autowired
	private FpxResponseCodeRepository fpxResponseCodeDao;


	@Override
	public GenericRepository<RefFpxResponseCode> primaryDao() {
		return fpxResponseCodeDao;
	}


	@Override
	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_FPX_RESPONSE_CODE_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<RefFpxResponseCode> findAll() {
		return fpxResponseCodeDao.findAll();
	}

}