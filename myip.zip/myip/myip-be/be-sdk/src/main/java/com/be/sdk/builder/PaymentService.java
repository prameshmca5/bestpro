/**
 * 
 */
package com.be.sdk.builder;

import java.util.Map;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.ConfigPaymentStage;
import com.be.sdk.model.Payment;
import com.util.pagination.DataTableResults;

/**
 * @author Ramesh Pongiannan
 *
 */
public class PaymentService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;
	
	public PaymentService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}
	
	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}

	@Override
	public String url() {
		return url;
	}

	@SuppressWarnings("unchecked")
	public DataTableResults<Payment> searchPaymentPagination(Payment dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}
	
	public Payment getPayment(Payment dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.GET_DETAIL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Payment.class);
	}

 	public Payment addPaymentInfo(Payment dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.INFO_ADD);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Payment.class);
	}
 	
 	public ConfigPaymentStage getConfigPayment(ConfigPaymentStage dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT).append(BeUrlConstants.CONFIG);
		sb.append(BeUrlConstants.GET_DETAIL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, ConfigPaymentStage.class);
	}
 	
 	public ConfigPaymentStage updatePayment(Payment dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.UPDATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, ConfigPaymentStage.class);
	}
}
