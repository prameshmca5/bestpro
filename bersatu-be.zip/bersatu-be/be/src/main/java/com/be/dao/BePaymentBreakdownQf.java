/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BePaymentBreakdown;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.PaymentBreakdown;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;


/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_PAYMENT_BREAKDOWN_QF)
public class BePaymentBreakdownQf extends QueryFactory<BePaymentBreakdown> {

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BePaymentBreakdown> searchByProperty(BePaymentBreakdown t) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<BePaymentBreakdown> searchAllByProperty(BePaymentBreakdown t) {
		CriteriaQuery<BePaymentBreakdown> cq = cb.createQuery(BePaymentBreakdown.class);
		Root<BePaymentBreakdown> root = cq.from(BePaymentBreakdown.class);
		List<Predicate> predicates = generateCriteria(cb, root, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public List<BePaymentBreakdown> searchAllByProperty(PaymentBreakdown dto, DataTableRequest<?> dataTableInRQ) {

		List<BePaymentBreakdown> result = new ArrayList<>();
		CriteriaQuery<BePaymentBreakdown> cq = cb.createQuery(BePaymentBreakdown.class);
		List<Predicate> predicates = new ArrayList<>();
		if (cq != null) {
			Root<BePaymentBreakdown> root = cq.from(BePaymentBreakdown.class);
			predicates.addAll(generateCriteria(cb, root, dto));

			cq.select(root);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					List<Order> orders = getOrderByClause(cb, root, pagination);
					cq.orderBy(orders);
				}
			}

			TypedQuery<BePaymentBreakdown> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			PaymentBreakdown dto = JsonUtil.transferToObject(criteria, PaymentBreakdown.class);

			if (!BaseUtil.isObjNull(dto.getBatchId())) {
				predicates.add(cb.equal(from.get("batchId"), dto.getBatchId()));
			}

			if (!BaseUtil.isObjNull(dto.getPmtBreakdownMtDtId())) {
				predicates.add(cb.equal(from.get("pmtBreakdownMtDtId"), dto.getPmtBreakdownMtDtId()));
			}

			if (!BaseUtil.isObjNull(dto.getStatus())) {
				predicates.add(cb.equal(from.get("status"), dto.getStatus()));
			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

}
