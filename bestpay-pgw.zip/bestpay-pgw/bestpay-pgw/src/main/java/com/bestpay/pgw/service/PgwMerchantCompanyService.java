package com.bestpay.pgw.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.PgwMerchantCompanyRepository;
import com.bestpay.pgw.model.PgwMerchantCompany;
import com.bestpay.pgw.util.QualifierConstants;


@Service(QualifierConstants.PGW_MERCHANT_COMPANY_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_COMPANY_SVC)
@Transactional
public class PgwMerchantCompanyService extends AbstractService<PgwMerchantCompany> {

	@Autowired
	private PgwMerchantCompanyRepository pgwMerchantCompanyDao;


	@Override
	public GenericRepository<PgwMerchantCompany> primaryDao() {
		return pgwMerchantCompanyDao;
	}
	
	public PgwMerchantCompany findCompanyByCompId(Integer companyId){
		return pgwMerchantCompanyDao.findCompanyByCompanyId(companyId);
	}
 
	public PgwMerchantCompany findCompanyByCompRefId(String compRefId){
		return pgwMerchantCompanyDao.findCompanyByCompRefId(compRefId);
	}

	 
}
