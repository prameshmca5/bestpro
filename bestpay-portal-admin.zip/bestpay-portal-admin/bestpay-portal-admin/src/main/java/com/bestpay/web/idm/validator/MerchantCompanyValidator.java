/**
 * Copyright 2018 Bestinet Sdn Bhd
 */
package com.bestpay.web.idm.validator;


import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.be.sdk.model.MerCompany;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ValidationUtil;


/**
 * @author Atiqah Khairuddin
 * @since Apr 11, 2019
 */
@Component("merchantCompanyValidator")
public class MerchantCompanyValidator extends AbstractController implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}


	// @SuppressWarnings("null")
	@Override
	public void validate(Object object, Errors errors) {
		if (object instanceof MerCompany) {
			// Validate if fields are empty or a whitespace
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "callbackUrl",
					MessageConstants.ERROR_FIELDS_CALLBACK_URL);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "companyName", MessageConstants.ERROR_FIELDS_COMPANY);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "email", MessageConstants.ERROR_APPLCNT_EML);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "phone", MessageConstants.ERROR_PHONE_REQUIRED);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "country", MessageConstants.ERROR_FIELDS_COUNTRY);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "address1", MessageConstants.ERROR_FIELDS_ADDRESS);
			Object countryValue = errors.getFieldValue("country");
			if ((!BaseUtil.isObjNull(countryValue) && BaseUtil.isEqualsCaseIgnore(countryValue.toString(), "MYS"))) {
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "stateMy", MessageConstants.ERROR_FIELDS_STATE);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "cityMy", MessageConstants.ERROR_FIELDS_CITY);
			} else {
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "stateNonMy", MessageConstants.ERROR_FIELDS_STATE);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "cityNonMy", MessageConstants.ERROR_FIELDS_CITY);
			}
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "postcode", MessageConstants.ERROR_FIELD_POSTCODE);
			ValidationUtil.rejectIfInvalidEmailFormat(errors, "email", MessageConstants.ERROR_EMAIL_FORMAT);
			ValidationUtil.rejectIfInvalidEmailFormat(errors, "picEmail", MessageConstants.ERROR_EMAIL_FORMAT);
		}

		// if (object instanceof MerCompBankDetails) {
		// ValidationUtil.rejectIfEmptyOrWhitespace(errors, "bankName",
		// MessageConstants.ERROR_FIELDS_BANK_NM);
		// ValidationUtil.rejectIfEmptyOrWhitespace(errors, "bankAccName",
		// MessageConstants.ERROR_FIELDS_ACC_NM);
		// ValidationUtil.rejectIfEmptyOrWhitespace(errors, "bankAccNo",
		// MessageConstants.ERROR_FIELDS_ACC_NO);
		// ValidationUtil.rejectIfEmptyOrWhitespace(errors, "bankBranch",
		// MessageConstants.ERROR_USER_BRANCH);
		// ValidationUtil.rejectIfEmptyOrWhitespace(errors, "bankLocation",
		// MessageConstants.ERROR_FIELD_LOCATION);
		// ValidationUtil.rejectIfEmptyOrWhitespace(errors, "bankCountry",
		// MessageConstants.ERROR_FIELDS_COUNTRY);
		// }
	}
}
