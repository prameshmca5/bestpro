/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.report.controller;


import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestid.report.config.cache.RedisCacheWrapper;
import com.bestid.report.core.AbstractRestController;
import com.bestid.report.sdk.constants.ReportUrlConstants;
import com.bestid.report.sdk.constants.RptCacheConstants;
import com.bestid.report.sdk.model.ServiceCheck;
import com.bestid.report.util.ConfigConstants;
import com.bstsb.util.BaseUtil;


/**
 * @author Mary Jane Buenaventura
 * @since May 8, 2018
 */
@RestController
public class ServiceCheckRestController extends AbstractRestController {

	@Autowired
	private CacheManager cacheManager;

	private static final String SERVICE_NAME = "REPORT Service";

	private static final String SUCCESS = "SUCCESS";

	private static final String FAILED = "FAILED";


	@GetMapping(value = ReportUrlConstants.SERVICE_CHECK + "/test", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public String serviceCheck() {
		return SERVICE_NAME;
	}


	@GetMapping(value = ReportUrlConstants.SERVICE_CHECK, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public ServiceCheck serviceCheck(HttpServletRequest request) {
		StringBuffer url = request.getRequestURL();
		String uri = request.getRequestURI();
		ServiceCheck svcTest = new ServiceCheck(SERVICE_NAME, url.substring(0, url.indexOf(uri)), SUCCESS);

		// IDM Service
		String idmUrl = messageSource.getMessage(ConfigConstants.SVC_IDM_URL, null, Locale.getDefault());
		try {
			String str = getIdmService(request).checkConnection();
			svcTest.setIdm(new ServiceCheck(str, idmUrl, SUCCESS));
		} catch (Exception e) {
			svcTest.setIdm(new ServiceCheck("IDM Service", idmUrl, FAILED + " [" + e.getMessage() + "]"));
			svcTest.setServiceResponse(FAILED);
		}

		return svcTest;
	}


	@GetMapping(value = ReportUrlConstants.REPORT_CACHE_EVICT, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public boolean refresh(@RequestParam(value = "prefixKey", required = false) String prefixKey) {
		RedisCacheWrapper cache = (RedisCacheWrapper) cacheManager.getCache(RptCacheConstants.CACHE_BUCKET);
		if (!BaseUtil.isObjNull(prefixKey)) {
			cache.evictByPrefix(prefixKey);
		} else {
			cache.clear();
		}
		return true;
	}

}