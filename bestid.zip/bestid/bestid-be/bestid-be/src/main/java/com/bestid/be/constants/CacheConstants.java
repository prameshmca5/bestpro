/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.constants;


/**
 * @author Mary Jane Buenaventura
 * @since May 8, 2018
 */
public class CacheConstants {

	private CacheConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String CACHE_PREFIX = "BESTID";

	public static final String CACHE_BUCKET = CACHE_PREFIX + "_BE_BUCKET";

	// CACHE DURATION in seconds
	public static final int CACHE_DURATION_MINUTE = 900;

	public static final int CACHE_DURATION_HOURLY = 3600;

	public static final int CACHE_DURATION_DAILY = 86400;

	// CACHE KEY
	public static final String CACHE_KEY_MENU_ALL = CACHE_PREFIX + "_IDM_MENU_ALL";

	public static final String CACHE_KEY_MENU_LST = CACHE_PREFIX + "_IDM_MENU_LST";

	public static final String CACHE_KEY_MENU = CACHE_PREFIX + "_IDM_MENU_";

	public static final String CACHE_KEY_ROLE_ALL = CACHE_PREFIX + "_IDM_ROLE_ALL";

	public static final String CACHE_KEY_ROLE = CACHE_PREFIX + "_IDM_ROLE_";

	public static final String CACHE_KEY_ROLE_MENU_ALL = CACHE_PREFIX + "_IDM_ROLE_MENU_ALL";

	public static final String CACHE_KEY_ROLE_MENU = CACHE_PREFIX + "_IDM_ROLE_MENU_";

	public static final String CACHE_KEY_ROLE_MENU_GR = CACHE_PREFIX + "_IDM_ROLE_MENU_GR_";

	public static final String CACHE_KEY_USR_GRP_ALL = CACHE_PREFIX + "_IDM_USER_GROUP_ALL";

	public static final String CACHE_KEY_USR_GRP = CACHE_PREFIX + "_IDM_USER_GROUP_";

	public static final String CACHE_KEY_USR_GRP_RG = CACHE_PREFIX + "_IDM_USER_GROUP_RG_";

	public static final String CACHE_KEY_USR_GRP_ROLE_ALL = CACHE_PREFIX + "_IDM_USER_GROUP_ROLE_ALL";

	public static final String CACHE_KEY_USR_GRP_ROLE = CACHE_PREFIX + "_IDM_USER_GROUP_ROLE_";

	public static final String CACHE_KEY_USR_GRP_ROLE_RG = CACHE_PREFIX + "_IDM_USER_GROUP_ROLE_RG_";

	public static final String CACHE_KEY_USER_TYPE_ALL = CACHE_PREFIX + "_IDM_REF_USER_TYPE_ALL";

	public static final String CACHE_KEY_USER_TYPE = CACHE_PREFIX + "_IDM_REF_USER_TYPE_";

	public static final String CACHE_KEY_API_QR = "__API_QR_";
}