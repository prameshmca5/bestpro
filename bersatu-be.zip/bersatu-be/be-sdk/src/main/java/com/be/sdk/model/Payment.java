package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonTimestampDeserializer;
import com.util.serializer.JsonTimestampSerializer;


public class Payment implements Serializable, IQfCriteria<Payment> {

	/**
	 *
	 */
	private static final long serialVersionUID = 6723281272583273849L;

	private Integer pmtId;

	private String txnId;

	private Integer pmtTypeMtdtId;

	private String pmtRefNo;

	private Integer totalItem;

	private String currency;

	private Double totalAmount;

	private String pmtBy;

	@JsonSerialize(using = JsonTimestampSerializer.class)
	@JsonDeserialize(using = JsonTimestampDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH_TIME_S)
	private Timestamp pmtDt;

	private String pmtByLevel;

	private Timestamp pmtGwDt;

	private String pmtStateCd;

	private String pmtDivisionCd;

	private String pmtBranchCd;

	private Integer statusId;

	private String statusCd;

	private String statusDesc;

	private Timestamp pmtDtFrom;

	private Timestamp pmtDtTo;

	private List<PaymentDtl> paymentDtlList;

	private Integer batchId;

	private PaymentGateway paymentGateway;

	private List<PaymentGateway> paymentGatewayList;

	private Integer channelMtdtId;

	private String regType;

	private String cbsRefNo;

	private PmtGatewayResp pmtGatewayResp;

	private PmtGatewayResp statusPymntMsgCode;

	private String userPayId;

	private Status status;

	private boolean embedDtls;

	private List<MemberProfile> memberProfileList;

	private List<PreReg> preRegList;
	
	private String profiType;

	private KiplePaymentRequest kiplePaymentRequest;
	
	@JsonSerialize(using = JsonTimestampSerializer.class)
	@JsonDeserialize(using = JsonTimestampDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH_TIME_S)
	private Timestamp pmtSchdulerDt;
	
	private int enquirySchedularMinuts;
	
	private String abortPmtStatus;


	public Integer getPmtId() {
		return pmtId;
	}


	public void setPmtId(Integer pmtId) {
		this.pmtId = pmtId;
	}


	public String getTxnId() {
		return txnId;
	}


	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}


	public Integer getPmtTypeMtdtId() {
		return pmtTypeMtdtId;
	}


	public void setPmtTypeMtdtId(Integer pmtTypeMtdtId) {
		this.pmtTypeMtdtId = pmtTypeMtdtId;
	}


	public String getPmtRefNo() {
		return pmtRefNo;
	}


	public void setPmtRefNo(String pmtRefNo) {
		this.pmtRefNo = pmtRefNo;
	}


	public Integer getTotalItem() {
		return totalItem;
	}


	public void setTotalItem(Integer totalItem) {
		this.totalItem = totalItem;
	}


	public Double getTotalAmount() {
		return totalAmount;
	}


	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}


	public String getPmtBy() {
		return pmtBy;
	}


	public void setPmtBy(String pmtBy) {
		this.pmtBy = pmtBy;
	}


	public Timestamp getPmtDt() {
		return pmtDt;
	}


	public void setPmtDt(Timestamp pmtDt) {
		this.pmtDt = pmtDt;
	}


	public String getPmtStateCd() {
		return pmtStateCd;
	}


	public void setPmtStateCd(String pmtStateCd) {
		this.pmtStateCd = pmtStateCd;
	}


	public String getPmtDivisionCd() {
		return pmtDivisionCd;
	}


	public void setPmtDivisionCd(String pmtDivisionCd) {
		this.pmtDivisionCd = pmtDivisionCd;
	}


	public String getPmtBranchCd() {
		return pmtBranchCd;
	}


	public void setPmtBranchCd(String pmtBranchCd) {
		this.pmtBranchCd = pmtBranchCd;
	}


	public Integer getStatusId() {
		return statusId;
	}


	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public Timestamp getPmtDtFrom() {
		return pmtDtFrom;
	}


	public void setPmtDtFrom(Timestamp pmtDtFrom) {
		this.pmtDtFrom = pmtDtFrom;
	}


	public Timestamp getPmtDtTo() {
		return pmtDtTo;
	}


	public void setPmtDtTo(Timestamp pmtDtTo) {
		this.pmtDtTo = pmtDtTo;
	}


	public List<PaymentDtl> getPaymentDtlList() {
		return paymentDtlList;
	}


	public void setPaymentDtlList(List<PaymentDtl> paymentDtlList) {
		this.paymentDtlList = paymentDtlList;
	}


	public Integer getBatchId() {
		return batchId;
	}


	public void setBatchId(Integer batchId) {
		this.batchId = batchId;
	}


	public Timestamp getPmtGwDt() {
		return pmtGwDt;
	}


	public void setPmtGwDt(Timestamp pmtGwDt) {
		this.pmtGwDt = pmtGwDt;
	}


	public PaymentGateway getPaymentGateway() {
		return paymentGateway;
	}


	public void setPaymentGateway(PaymentGateway paymentGateway) {
		this.paymentGateway = paymentGateway;
	}


	public List<PaymentGateway> getPaymentGatewayList() {
		return paymentGatewayList;
	}


	public void setPaymentGatewayList(List<PaymentGateway> paymentGatewayList) {
		this.paymentGatewayList = paymentGatewayList;
	}


	public String getStatusCd() {
		return statusCd;
	}


	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}


	public String getStatusDesc() {
		return statusDesc;
	}


	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}


	public Integer getChannelMtdtId() {
		return channelMtdtId;
	}


	public void setChannelMtdtId(Integer channelMtdtId) {
		this.channelMtdtId = channelMtdtId;
	}


	/**
	 * @return the regType
	 */
	public String getRegType() {
		return regType;
	}


	/**
	 * @param regType
	 *             the regType to set
	 */
	public void setRegType(String regType) {
		this.regType = regType;
	}


	public String getPmtByLevel() {
		return pmtByLevel;
	}


	public void setPmtByLevel(String pmtByLevel) {
		this.pmtByLevel = pmtByLevel;
	}


	public String getCbsRefNo() {
		return cbsRefNo;
	}


	public void setCbsRefNo(String cbsRefNo) {
		this.cbsRefNo = cbsRefNo;
	}


	public PmtGatewayResp getPmtGatewayResp() {
		return pmtGatewayResp;
	}


	public void setPmtGatewayResp(PmtGatewayResp pmtGatewayResp) {
		this.pmtGatewayResp = pmtGatewayResp;
	}


	public PmtGatewayResp getStatusPymntMsgCode() {
		return statusPymntMsgCode;
	}


	public void setStatusPymntMsgCode(PmtGatewayResp statusPymntMsgCode) {
		this.statusPymntMsgCode = statusPymntMsgCode;
	}


	public String getUserPayId() {
		return userPayId;
	}


	public void setUserPayId(String userPayId) {
		this.userPayId = userPayId;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}


	public boolean isEmbedDtls() {
		return embedDtls;
	}


	public void setEmbedDtls(boolean embedDtls) {
		this.embedDtls = embedDtls;
	}


	/**
	 * @return the memberProfileList
	 */
	public List<MemberProfile> getMemberProfileList() {
		return memberProfileList;
	}


	/**
	 * @param memberProfileList
	 *             the memberProfileList to set
	 */
	public void setMemberProfileList(List<MemberProfile> memberProfileList) {
		this.memberProfileList = memberProfileList;
	}


	/**
	 * @return the preRegList
	 */
	public List<PreReg> getPreRegList() {
		return preRegList;
	}


	/**
	 * @param preRegList
	 *             the preRegList to set
	 */
	public void setPreRegList(List<PreReg> preRegList) {
		this.preRegList = preRegList;
	}


	public String getProfiType() {
		return profiType;
	}


	public void setProfiType(String profiType) {
		this.profiType = profiType;
	}


	public KiplePaymentRequest getKiplePaymentRequest() {
		return kiplePaymentRequest;
	}


	public void setKiplePaymentRequest(KiplePaymentRequest kiplePaymentRequest) {
		this.kiplePaymentRequest = kiplePaymentRequest;
	}


	public Timestamp getPmtSchdulerDt() {
		return pmtSchdulerDt;
	}


	public void setPmtSchdulerDt(Timestamp pmtSchdulerDt) {
		this.pmtSchdulerDt = pmtSchdulerDt;
	}


	public int getEnquirySchedularMinuts() {
		return enquirySchedularMinuts;
	}


	public void setEnquirySchedularMinuts(int enquirySchedularMinuts) {
		this.enquirySchedularMinuts = enquirySchedularMinuts;
	}


	public String getAbortPmtStatus() {
		return abortPmtStatus;
	}


	public void setAbortPmtStatus(String abortPmtStatus) {
		this.abortPmtStatus = abortPmtStatus;
	}
	
}
