/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwBankDetails;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerAccSet;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.MER_ACC_SET)
public class AccountSetRestController extends AbstractRestController {

	@GetMapping(value = "/{merchantId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerAccSet findAccSettingByMerchantId(@PathVariable String merchantId) {

		PgwBankDetails bankDetails = super.pgwBankDetailsService.findBankDetailsByMerchantId(merchantId);

		MerAccSet merAccSet = new MerAccSet();
		if (!BaseUtil.isObjNull(bankDetails)) {
			merAccSet = dozerMapper.map(bankDetails, MerAccSet.class);
		}
		return merAccSet;
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerAccSet updateAccountSetting(@Valid @RequestBody MerAccSet merAccSet, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		if (merAccSet == null) {// accountSetting null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		if (StringUtils.isBlank(merAccSet.getMerchantId())) {// no merchant
			// name
			throw new BeException(BeErrorCodeEnum.I400IDM137, new String[] { "Merchant Name", "Merchant Profile" });
		}

		PgwBankDetails accountSetting = new PgwBankDetails();
		PgwBankDetails accSet = super.pgwBankDetailsService.findBankDetailsByMerchantId(merAccSet.getMerchantId());

		if (BaseUtil.isObjNull(accSet)) {
			accountSetting.setMerchantId(merAccSet.getMerchantId());
			accountSetting.setBankId(merAccSet.getBankId());
			accountSetting.setAccountName(merAccSet.getAccountName());
			accountSetting.setAccountNum(merAccSet.getAccountNum());
			accountSetting.setSettlementFee(merAccSet.getSettlementFee());
			accountSetting.setMinSettleAmt(merAccSet.getMinSettleAmt());
			accountSetting.setTransactionRate(merAccSet.getTransactionRate());
			accountSetting.setTransactionFee(merAccSet.getTransactionFee());
			accountSetting.setPsa(merAccSet.getPsa());
			accountSetting.setCreateId(merAccSet.getUserId());
			super.pgwBankDetailsService.create(accountSetting);
		} else {
			accSet.setMerchantId(merAccSet.getMerchantId());
			accSet.setBankId(merAccSet.getBankId());
			accSet.setAccountName(merAccSet.getAccountName());
			accSet.setAccountNum(merAccSet.getAccountNum());
			accSet.setSettlementFee(merAccSet.getSettlementFee());
			accSet.setMinSettleAmt(merAccSet.getMinSettleAmt());
			accSet.setTransactionRate(merAccSet.getTransactionRate());
			accSet.setTransactionFee(merAccSet.getTransactionFee());
			accSet.setPsa(merAccSet.getPsa());
			accSet.setUpdateId(merAccSet.getUserId());
			super.pgwBankDetailsService.update(accSet);
		}

		MerAccSet accSetting = new MerAccSet();
		PgwBankDetails updatAccSet = super.pgwBankDetailsService
				.findBankDetailsByMerchantId(merAccSet.getMerchantId());
		if (!BaseUtil.isObjNull(updatAccSet)) {
			accSetting = dozerMapper.map(updatAccSet, MerAccSet.class);
		}
		return accSetting;
	}


	@PostMapping(value = BeUrlConstants.EXISTS, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Boolean isAccSetExistsByAccTypeAndAccNum(@Valid @RequestBody MerAccSet merAccSet,
			HttpServletRequest request, HttpServletResponse response) throws BeException {
		if (merAccSet == null) {// accountSetting null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		if (StringUtils.isBlank(merAccSet.getMerchantId())) {// no merchant
			// name
			throw new BeException(BeErrorCodeEnum.I400IDM137, new String[] { "Merchant Name", "Merchant Profile" });
		}
		List<PgwBankDetails> list = super.pgwBankDetailsService.findBankDetailsByIcTypeAndIcNum(merAccSet.getIcType(),
				merAccSet.getIcNumber());
		if (list.isEmpty()) {
			return false;
		} else {
			return true;
		}
	}

}
