/**
 *
 */
package com.be.sdk.builder;


import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.ElectionNot;
import com.be.sdk.model.ElectionNotDtl;
import com.util.pagination.DataTableResults;


/**
 * @author mohd.naem
 *
 */
public class ElectionService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public ElectionService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<ElectionNot> searchPaginated(ElectionNot dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.ELECTION);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}


	// use to search for unique column only, or else return latest data in db
	public ElectionNot searchElectionNot(ElectionNot dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.ELECTION);
		sb.append(BeUrlConstants.SEARCH);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, ElectionNot.class);
	}


	public ElectionNot createElectionNot(ElectionNot dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.ELECTION);
		sb.append(BeUrlConstants.CREATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, ElectionNot.class);
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<ElectionNotDtl> searchElectionNotDtlPaginated(ElectionNotDtl dto,
			Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.ELECTION);
		sb.append(BeUrlConstants.DETAIL);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}


	public List<ElectionNotDtl> searchElectionNotDtlList(ElectionNotDtl dto) {
		List<ElectionNotDtl> electionNotDtlList = null;
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.ELECTION);
		sb.append(BeUrlConstants.DETAIL);
		sb.append(BeUrlConstants.SEARCH_LIST);
		ElectionNotDtl[] array = restTemplate().postForObject(getServiceURI(sb.toString()), dto,
				ElectionNotDtl[].class);
		if (array != null && array.length > 0) {
			electionNotDtlList = Arrays.asList(array);
		}
		return electionNotDtlList;
	}
}