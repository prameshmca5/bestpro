/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.pagination.PaginationCriteria;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Afif Saman
 * @since June 6, 2018
 */
@Repository
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MER_PROFILE_DAO)
public class MerchantProfileCustomDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(MerchantProfileCustomDao.class);

	@Autowired
	private PgwMerchantProfileRepository merchantProfileDao;

	@PersistenceContext
	private EntityManager entityManager;


	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}


	public DataTableResults<PgwMerchantProfile> searchByPagination(MerAccInfo merAccInfo,
			DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append("from PgwMerchantProfile r ");
		sb.append(" where 1=1 ");

		if (!BaseUtil.isObjNull(merAccInfo.getMerchantId())) {
			sb.append(" and r.merchantId = :merchantId ");
		}

		if (!BaseUtil.isObjNull(merAccInfo.getCompany())) {
			sb.append(" and r.company like :company ");
		}

		if (!BaseUtil.isObjNull(merAccInfo.getAcStatus())) {
			sb.append(" and r.acStatus = :acStatus ");
		}

		sb.append(" order by r.createDt desc");

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause("r"));
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<PgwMerchantProfile> query = entityManager.createQuery(sb.toString(), PgwMerchantProfile.class);
		// Original Query
		TypedQuery<PgwMerchantProfile> query2 = entityManager.createQuery(sb.toString(), PgwMerchantProfile.class);

		if (!BaseUtil.isObjNull(merAccInfo.getMerchantId())) {
			query.setParameter("merchantId", merAccInfo.getMerchantId());
			query2.setParameter("merchantId", merAccInfo.getMerchantId());
		}

		if (!BaseUtil.isObjNull(merAccInfo.getCompany())) {
			query.setParameter("company", "%" + merAccInfo.getCompany() + "%");
			query2.setParameter("company", "%" + merAccInfo.getCompany() + "%");
		}

		if (!BaseUtil.isObjNull(merAccInfo.getAcStatus())) {
			query.setParameter("acStatus", merAccInfo.getAcStatus());
			query2.setParameter("acStatus", merAccInfo.getAcStatus());
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwMerchantProfile> dataTableResult = new DataTableResults<>();
		List<PgwMerchantProfile> svcResp = query.getResultList();
		List<PgwMerchantProfile> svcResp2 = query2.getResultList();
		LOGGER.debug("Filtered Size: {}", svcResp.size());
		LOGGER.debug("Original Size: {}", svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : merchantProfileDao.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		LOGGER.debug("isFilterByEmpty: {}", dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}
		return dataTableResult;
	}

}