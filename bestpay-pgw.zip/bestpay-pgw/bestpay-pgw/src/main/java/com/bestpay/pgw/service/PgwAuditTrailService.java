 
package com.bestpay.pgw.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.PgwAuditTrailRepository;
import com.bestpay.pgw.model.PgwAuditTrail;
import com.bestpay.pgw.util.QualifierConstants;
 
/**
 * @author Chaithanya
 * @since 11/07/2018
 */
@Service(QualifierConstants.PGW_TRAIL_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_TRAIL_SVC)
@Transactional
public class PgwAuditTrailService extends AbstractService<PgwAuditTrail>{

	@Autowired
	private PgwAuditTrailRepository bestpayAuditTrailDao;
	
	@Override
	public GenericRepository<PgwAuditTrail> primaryDao() {
		return bestpayAuditTrailDao;
	}

}