/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.controller;


import java.util.Locale;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.util.StringUtils;

import com.bestid.be.constants.ConfigConstants;
import com.bestid.be.constants.ProjectEnum;
import com.bestid.be.service.MessageService;
import com.bstsb.dm.sdk.client.DmServiceClient;
import com.bstsb.idm.sdk.client.IdmServiceClient;
import com.bstsb.notify.sdk.client.NotServiceClient;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.UidGenerator;
import com.bstsb.util.constants.BaseConfigConstants;
import com.bstsb.util.constants.BaseConstants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 12, 2018
 *
 *        Updates
 * @author mohd.faisal
 * @since Feb 14, 2019
 */
public abstract class AbstractRestController {

	@Autowired
	protected Mapper dozerMapper;

	@Autowired
	protected IdmServiceClient idmService;

	@Autowired
	protected MessageService messageService;

	@Autowired
	private NotServiceClient notifyService;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private DmServiceClient dmService;


	protected String getRealPath() {
		return this.getClass().getResource(BaseConstants.SLASH).getPath();
	}


	protected String getCurrUserId(HttpServletRequest request) {
		String currUser = BaseUtil.getStr(request.getAttribute("currUserId"));
		return !BaseUtil.isObjNull(currUser) ? currUser : "superuser";
	}


	protected IdmServiceClient getIdmService(HttpServletRequest request) {
		idmService.setAuthToken(request.getHeader(BaseConstants.HEADER_AUTHORIZATION));
		idmService.setMessageId(StringUtils.hasText(request.getHeader(BaseConstants.HEADER_MESSAGE_ID))
				? request.getHeader(BaseConstants.HEADER_MESSAGE_ID) : String.valueOf(UUID.randomUUID()));
		return idmService;
	}


	public String getPwordEkey() {
		return messageService.getMessage(ConfigConstants.SVC_IDM_EKEY);
	}


	public NotServiceClient getNotifyService() {
		notifyService.setToken(messageSource.getMessage(BaseConfigConstants.SVC_IDM_SKEY, null, Locale.getDefault()));
		notifyService.setClientId(
				messageSource.getMessage(BaseConfigConstants.SVC_IDM_CLIENT, null, Locale.getDefault()));
		notifyService.setMessageId(UidGenerator.getMessageId());
		return notifyService;
	}


	public DmServiceClient getDmService(ProjectEnum project) {
		if (project != null) {
			dmService.setProjId(project.getName());
		}
		dmService.setToken(messageService.getMessage(BaseConfigConstants.SVC_IDM_SKEY));
		dmService.setClientId(messageService.getMessage(BaseConfigConstants.SVC_IDM_CLIENT));
		dmService.setMessageId(UidGenerator.getMessageId());
		return dmService;
	}
}