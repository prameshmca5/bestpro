package com.bestpay.pgw.service;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.PgwMerchantContactRepository;
import com.bestpay.pgw.model.PgwMerchantContact;
import com.bestpay.pgw.util.QualifierConstants;

@Service(QualifierConstants.PGW_MERCHANT_CONTACT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_CONTACT_SVC)
@Transactional
public class PgwMerchantContactService extends AbstractService<PgwMerchantContact> {
	
	@Autowired
	private PgwMerchantContactRepository pgwMerchantContactDao;
	
	@Override
	public GenericRepository<PgwMerchantContact> primaryDao() {
		return pgwMerchantContactDao;
	}
	
	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantContact findbyMerchantId(String merchantId) {
		return pgwMerchantContactDao.findbyMerchantId(merchantId);
	}

}
