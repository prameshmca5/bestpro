/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.config;


import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
@Component
public class StaticData implements InitializingBean {

	@Autowired
	CacheManager cacheManager;

	@Autowired
	MessageSource messageSource;


	public StaticData() {
		// default constructor
	}


	@Override
	public void afterPropertiesSet() throws Exception {
		// implement inherit function
	}

}