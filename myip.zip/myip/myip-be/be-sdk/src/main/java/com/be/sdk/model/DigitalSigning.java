/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.serializer.ByteArraySerializer;

/**
 * @author michelle.angela
 *
 */
public class DigitalSigning implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1869391184239240349L;

	@JsonProperty("ErrMsg")
	private String errMsg;

	@JsonProperty("FileName")
	private String fileName;

	@JsonProperty("DocType")
	private String docType;

	@JsonProperty("IsSigningSuccess")
	private boolean signingSuccess;

	@JsonProperty("PDFByte")
	@JsonSerialize(using = ByteArraySerializer.class)
	private byte[] content;

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public boolean isSigningSuccess() {
		return signingSuccess;
	}

	public void setSigningSuccess(boolean signingSuccess) {
		this.signingSuccess = signingSuccess;
	}

	public byte[] getContent() {
		return content;
	}

	public void setContent(byte[] content) {
		this.content = content;
	}

}
