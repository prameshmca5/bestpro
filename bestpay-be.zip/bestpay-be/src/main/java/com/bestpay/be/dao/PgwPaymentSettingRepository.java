package com.bestpay.be.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.model.PgwPaymentSetting;
import com.bestpay.be.util.QualifierConstants;

/**
 * @author Afif Saman
 * @since July 13, 2018
 */

@Repository
@RepositoryDefinition(domainClass = PgwMerchantProfile.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_PAY_SET_DAO)
public interface PgwPaymentSettingRepository extends GenericRepository<PgwPaymentSetting> {

	@Query("select u from PgwPaymentSetting u where u.merchantId = :merchantId ")
	public PgwPaymentSetting findPaymentSettingMerchantId(@Param("merchantId") String merchantId);

	@Query("select count(u) from PgwPaymentSetting u ")
	public int totalRecords();
	
	@Query("select u from PgwPaymentSetting u ")
	public List<PgwPaymentSetting> findAllMerchantpaymentList();
	
	@Query("select u from PgwPaymentSetting u ")
	public List<PgwPaymentSetting> findAllMerchantpaymentList1(@Param("merchantId") String merchantId);

}