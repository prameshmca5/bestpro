/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Country;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.model.MerAccSet;
import com.bestpay.be.sdk.model.MerGenInfo;
import com.bestpay.be.sdk.model.MerPayPageSet;
import com.bestpay.be.sdk.model.SettlementInfo;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.sdk.model.Transaction;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.report.sdk.constants.ReportTypeEnum;
import com.bestpay.report.sdk.model.Report;
import com.bestpay.web.config.iam.CustomUserDetails;
import com.bestpay.web.constants.AppConstants;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.WebUtil;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;

/**
 * @author Ramesh Pongiannan
 * @since June 1, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_STTLMNT)
public class SettlementController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(SettlementController.class);

	private static final String SET_VIEW = "setview";

	private static final String SETTLEMENT = "settlement";

	private static final String STLMNTSTAT = "STLMNTSTAT";

	private static final String STATUSLIST = "statusList";

	@GetMapping
	public ModelAndView view(SettlementInfo settlementInfo, MerPayPageSet merPayPageSet, BindingResult result,
			HttpSession session) throws BeException {
		LOGGER.info("Welcome Admin SETTLEMENT PAGE");
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_SETTLEMENT, SETTLEMENT, null, "settlement-script");
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.pgw.sttl.lst"));
		List<Status> status = staticData.status(STLMNTSTAT);
		List<MerPayPageSet> merchantList = getBeService().getAllMerChantpaymentList(merPayPageSet);
		mav.addObject("merchantList", merchantList);
		mav.addObject(STATUSLIST, status);
		settlementInfo.setUserType(getCurrentUser().getUserRoleGroupCode());
		mav.addObject("settlementInfo", settlementInfo);
		return mav;
	}

	// Search settlement
	@PostMapping(params = "search")
	public ModelAndView search(SettlementInfo settlementInfo, MerPayPageSet merPayPageSet, BindingResult result,
			HttpSession session) throws BeException {
		LOGGER.info("Welcome Admin SETTLEMENT PAGE");
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_SETTLEMENT, SETTLEMENT, null, "settlement-script");
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.pgw.sttl.lst"));
		List<Status> status = staticData.status(STLMNTSTAT);
		List<MerPayPageSet> merchantList1 = getBeService().getAllMerChantpaymentList(merPayPageSet);
		mav.addObject("merchantList", merchantList1);
		mav.addObject(STATUSLIST, status);
		mav.addObject("settlementInfo", settlementInfo);
		LOGGER.info("Search date {}", settlementInfo.getSettleDate());
		return mav;
	}

	// Reset searching settlement
	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute("settlementInfo") @Validated SettlementInfo settlementInfo,
			BindingResult result, HttpServletRequest request, HttpSession session) throws BeException {
		SettlementInfo settleInfo = new SettlementInfo();
		MerPayPageSet merPayPageSet = new MerPayPageSet();
		LOGGER.info("--reset--");
		return view(settleInfo, merPayPageSet, result, session);
	}

	@GetMapping(value = "/paginated")
	public @ResponseBody String getApplicationInfoPaginated(
			@ModelAttribute("settlementInfo") SettlementInfo settlementInfo, HttpServletRequest request) {
		LOGGER.info("GET PAGINATED SETTLEMENT LIST....");
		DataTableResults<SettlementInfo> tasks = new DataTableResults<>();
		try {
			LOGGER.info("Search settlement status {}", settlementInfo.getStatus());
			tasks = getBeService().searchsettlement(settlementInfo, getPaginationRequest(request, true));
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(e.getMessage());
			tasks.setError(e.getMessage());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			tasks.setError(e.getMessage());
		}

		return new Gson().toJson(tasks);
	}

	@GetMapping(value = "/{setId}")
	public ModelAndView viewlisttrasaction(@PathVariable("setId") Integer setId,
			@ModelAttribute("transactionList") Transaction transactionList, HttpServletRequest request)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_SEMT_TRANS_VIEW, SET_VIEW, null);
		transactionList.setSetId(setId);
		try {
			List<Transaction> resList = getBeService().getTransSettleList(transactionList);
			if (BaseUtil.isListNullAndZero(resList)) {
				mav.addObject("setlmtTransList", "No Record Found");
			}
			mav.addObject("setlmtTransList", resList);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return mav;
	}

	@GetMapping(value = "/receipt/{setId}")
	public ModelAndView viewlistreceipt(@PathVariable("setId") Integer setId,
			@ModelAttribute("settlementDetails") SettlementInfo settlementInfo, HttpServletRequest request)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_SEMT_TRANS_RECEIPT, SET_VIEW, null);
		try {
			SettlementInfo resList = getBeService().getSettlementInfoById(setId);
			MerGenInfo merGenInfo = getBeService().getGenInfoById(resList.getMerchantId());
			MerAccSet merAccSet = getBeService().getAccSetById(resList.getMerchantId());
			MerAccInfo merAccInfo = getBeService().getAccInfoById(resList.getMerchantId());
			Country country = getBeService().getCountryDescByCountryCode(merGenInfo.getCountry());
			String cityDesc = staticData.cityDesc(merGenInfo.getCity());
			String stateDesc = staticData.stateDesc(merGenInfo.getState());

			LOGGER.info("EMAIL DETAILS ==> {}", merGenInfo.getEmail());
			mav.addObject("settlementDetails", resList);
			mav.addObject("merGenInfo", merGenInfo);
			mav.addObject("merAccSet", merAccSet);
			mav.addObject("merAccInfo", merAccInfo);
			mav.addObject("country", country);
			mav.addObject("city", cityDesc);
			mav.addObject("state", stateDesc);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return mav;

	}

	@GetMapping(value = "/invoice/{setId}")
	public ModelAndView viewlistinvoice(@PathVariable("setId") Integer setId,
			@ModelAttribute("settlementDetails") SettlementInfo settlementInfo, HttpServletRequest request)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_SEMT_TRANS_INVOCE, SET_VIEW, null);
		try {
			SettlementInfo resList = getBeService().getSettlementInfoById(setId);
			MerGenInfo merGenInfo = getBeService().getGenInfoById(resList.getMerchantId());
			Country country = getBeService().getCountryDescByCountryCode(merGenInfo.getCountry());
			String cityDesc = staticData.cityDesc(merGenInfo.getCity());
			String stateDesc = staticData.stateDesc(merGenInfo.getState());
			LOGGER.info("EMAIL DETAILS ==> {}", merGenInfo.getEmail());
			mav.addObject("settlementDetails", resList);
			mav.addObject("merGenInfo", merGenInfo);
			mav.addObject("country", country);
			mav.addObject("city", cityDesc);
			mav.addObject("state", stateDesc);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return mav;

	}

	@GetMapping(value = "/update/{settlementId}")
	public ModelAndView viewUpdate(@PathVariable("settlementId") Integer settlementId,
			@ModelAttribute("settlementInfo") SettlementInfo settlementInfo, HttpServletRequest request)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.UPDT_SETTLEMENT_STATUS, "update-settlement-status", null);
		SettlementInfo settlement = getBeService().getSettlementInfoById(settlementId);
		mav.addObject(SETTLEMENT, settlement);
		mav.addObject(STATUSLIST, staticData.status(STLMNTSTAT));
		return mav;
	}

	@PostMapping(value = "/update/{settlementId}", params = "update")
	public ModelAndView updateSettlement(@PathVariable Integer settlementId,
			@ModelAttribute("settlementInfo") SettlementInfo settlementInfo, BindingResult result) {
		ModelAndView mav = getDefaultMav(PageTemplate.UPDT_SETTLEMENT_STATUS, "update-settlement-status", null);
		UserProfile authUser = getCurrentUser();
		settlementInfo.setUserId(authUser.getUserId());
		settlementInfo.setSettlementId(settlementId);
		LOGGER.info("Result = {}", result);
		String listSettlement = "";
		if (!result.hasErrors()) {
			try {
				getBeService().updateSettlementStatus(settlementInfo);
				SettlementInfo settleInfo = getBeService().getSettlementInfoById(settlementId);
				settlementInfo = dozerMapper.map(settleInfo, SettlementInfo.class);
				mav.addAllObjects(PopupBox.success(SETTLEMENT, null,
						messageService.getMessage(MessageConstants.SUCC_UPD_SETTLEMENT_STATUS)));
				LOGGER.info("Successfully update settlement status");
				mav.addAllObjects(PopupBox.success(null, null,
						listSettlement + messageService.getMessage(MessageConstants.SUCC_UPD_SETTLEMENT_STATUS),
						PageConstants.PAGE_STTLMNT));
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
		mav.addObject(SETTLEMENT, settlementInfo);
		return mav;
	}

	@GetMapping(value = "print/genSettlementInvoice")
	public @ResponseBody Report genSettlementInvoice(@ModelAttribute("SettlementInfo") SettlementInfo settlementInfo,
			@RequestParam(value = "settlementId", required = true) Integer settlementId, BindingResult result,
			HttpServletRequest request, HttpSession session) {

		Report report = null;
		try {
			report = getReportService().genSettlementInvoice(settlementId, ReportTypeEnum.PDF, true);
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.debug("Error {}", e);
		}
		return report;
	}

	@GetMapping(value = "print/genSettlementReceipt")
	public @ResponseBody Report genSettlementReceipt(@ModelAttribute("SettlementInfo") SettlementInfo settlementInfo,
			@RequestParam(value = "settlementId", required = true) Integer settlementId, BindingResult result,
			HttpServletRequest request, HttpSession session) {

		Report report = null;
		try {
			report = getReportService().genSettlementReceipt(settlementId, ReportTypeEnum.PDF, true);
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.debug("Error {}", e);
		}
		return report;
	}

	@Override
	public UserProfile getCurrentUser() {
		UserProfile userProfile = null;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth.isAuthenticated()) {
			CustomUserDetails cud = (CustomUserDetails) auth.getPrincipal();
			userProfile = cud.getProfile();
		}
		return userProfile;
	}

}