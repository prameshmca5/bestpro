/**
 * 
 */
package com.be.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeMcAddressQf;
import com.be.dao.BeMcAddressRepository;
import com.be.model.BeMcAddress;
import com.be.model.BeMcProfile;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.McAddress;
import com.be.sdk.model.McProfile;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_MC_ADDRESS_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_MC_ADDRESS_SVC)
public class BeMcAddressService extends AbstractService<BeMcAddress> {

	@Autowired
	BeMcAddressRepository beMcAddressDao;
	
	@Autowired
	BeMcAddressQf beMcAddressQf;
	
	@Override
	public GenericRepository<BeMcAddress> primaryDao() {
		return beMcAddressDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beMcAddressQf.generateCriteria(cb, from, criteria);
	}

	public Set<BeMcAddress> createUpdate(Set<BeMcAddress> set, BeMcProfile mcProfile, String userId){
		
		List<BeMcAddress> beMcAddresses = new ArrayList<>();
		set.stream().forEach(address -> {
			if(BaseUtil.isObjNull(address.getMcAddrId())) {
				address.setCreateId(userId);
				address.setMcProfile(mcProfile);
			}else {
				BeMcAddress addressOri = find(address.getMcAddrId());
				address.setMcProfile(addressOri.getMcProfile());
				address.setCreateId(addressOri.getCreateId());
				address.setCreateDt(addressOri.getCreateDt());
			}
			address.setUpdateId(userId);
			beMcAddresses.add(address);
		});		
		beMcAddressDao.save(beMcAddresses);
		return set;
	}
	
	public McAddress searchMcAddress(McAddress dto) throws IOException {
		return JsonUtil.transferToObject(beMcAddressQf.searchBeMcAddress(dto), McAddress.class);
	}
	
	@SuppressWarnings("unchecked")
	public List<McAddress> searchMcAddressPagination(McAddress dto, DataTableRequest<?> dataTableInRQ) 
			throws IOException {
		return JsonUtil.transferToList(beMcAddressQf.searchBeMcAddressPagination(dto, dataTableInRQ), 
				McAddress.class);
	}
	
	public long getCount(McAddress dto) {
		return beMcAddressQf.getCount(dto);
	}
}
