package com.be.controller;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.dao.BeTvlPaymentQf;
import com.be.model.BeTvlPayment;
import com.be.model.RefDocument;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.constants.FileUploadConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.ConfigPaymentStage;
import com.be.sdk.model.Payment;
import com.be.service.BeConfigPaymentStageService;
import com.be.service.BeTrxnDocumentService;
import com.be.service.BeTvlPaymentService;
import com.be.service.RefDocumentService;
import com.dm.sdk.exception.DmException;
import com.dm.sdk.model.Documents;
import com.report.sdk.constants.ReportTypeEnum;
import com.report.sdk.model.Report;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;
import com.util.pagination.DataTableRequest;
import com.util.pagination.DataTableResults;


/**
 * @author Ramesh Pongianann
 *
 */
@Lazy
@RestController
@RequestMapping(BeUrlConstants.PAYMENT)
public class PaymentRestController extends AbstractRestController {

	@Autowired
	private BeTvlPaymentService beTvlPaymentSvc;

	// @Autowired
	// private BeTvlPaymentDtlService beTvlPaymentDtlSvc;

	@Autowired
	BeConfigPaymentStageService beConfigPaymentStageSvc;

	@Autowired
	RefDocumentService documentSvc;

	@Autowired
	BeTrxnDocumentService trxnDocumentSvc;

	@Autowired
	BeTvlPaymentQf beTvlPaymentQf;


	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<Payment> searchPaymentPaginated(@RequestBody Payment dto, HttpServletRequest request)
			throws IOException {

		DataTableRequest<Payment> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) beTvlPaymentSvc.getCount(dto);
		List<Payment> filtered = beTvlPaymentSvc.searchBeTvlPaymentPagination(dto, dataTableInRQ);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("ALL DATA: {}", totalCount);
			LOGGER.debug("ALL filtered DATA : {}", filtered);
		}

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.GET_DETAIL, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Payment getPaymentDetail(@RequestBody Payment dto, HttpServletRequest request) throws IOException {
		return JsonUtil.transferToObject(beTvlPaymentSvc.searchBeTvlPayment(dto), Payment.class);
	}


	@PostMapping(value = BeUrlConstants.INFO_ADD, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Payment addPaymentfo(@RequestBody Payment dto, HttpServletRequest request) throws IOException {

		BeTvlPayment beTvlPayment = null;

		try {

			if (BaseUtil.isObjNull(dto) || BaseUtil.isListNull(dto.getBeTvlPaymentDtls())) {
				throw new BeException(BeErrorCodeEnum.I409C001);
			}

			beTvlPayment = beTvlPaymentSvc.addPaymentInfo(dto, getCurrUserId(request), request);

		} catch (BeException e) {
			e.printStackTrace();
			throw new BeException(BeErrorCodeEnum.E500C001);
		} catch (DmException e) {
			throw new BeException(BeErrorCodeEnum.E500C010);
		} catch (Exception e) {
			throw new BeException(BeErrorCodeEnum.E500C011);
		}

		return JsonUtil.transferToObject(beTvlPayment, Payment.class);
	}


	@PostMapping(value = BeUrlConstants.CONFIG + BeUrlConstants.GET_DETAIL, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public ConfigPaymentStage getConfigPayment(@RequestBody ConfigPaymentStage dto, HttpServletRequest request)
			throws IOException {
		return JsonUtil.transferToObject(beConfigPaymentStageSvc.searchBeConfigPaymentStage(dto),
				ConfigPaymentStage.class);
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Payment updatePaymentfo(@RequestBody Payment dto, HttpServletRequest request) throws IOException {

		BeTvlPayment beTvlPayment = null;
		try {

			if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getPmtRefNo())) {
				throw new BeException(BeErrorCodeEnum.E400C913);
			}

			Payment searchDto = new Payment();
			searchDto.setPmtRefNo(dto.getPmtRefNo());
			searchDto.setEmbedDtls(true);
			BeTvlPayment tvlPayment = beTvlPaymentQf.searchPayment(searchDto);

			if (BaseUtil.isEquals("02", tvlPayment.getRespPymntMsgCode().getRespCd())) {
				beTvlPayment = beTvlPaymentSvc.updatePaymentInfo(dto, tvlPayment, request);

				tvlPayment = beTvlPayment;

				if (BaseUtil.isEquals("01", tvlPayment.getRespPymntMsgCode().getRespCd())) {
					List<Documents> docList = new ArrayList<>();
					List<RefDocument> invoiceDoc = documentSvc
							.findAllByTrxnNo(FileUploadConstants.DOC_TRXN_TAX_INVOICE);
					List<RefDocument> receiptDoc = documentSvc
							.findAllByTrxnNo(FileUploadConstants.DOC_TRXN_OFFICIAL_RECEIPT);
					Payment pmtDto = new Payment();
					pmtDto.setPmtRefNo(tvlPayment.getPmtRefNo());

					if (!BaseUtil.isListNull(invoiceDoc)) {
						Report invoice = getReportService(request).report().genTaxInvoice(pmtDto,
								ReportTypeEnum.PDF);
						if (!BaseUtil.isObjNull(invoice.getReportBytes())) {
							docList.add(trxnDocumentSvc.upload(invoiceDoc.get(0), invoice,
									tvlPayment.getPmtRefNo(), request));
						}
					}

					if (!BaseUtil.isListNull(invoiceDoc)) {
						Report receipt = getReportService(request).report().genOfficialReceipt(pmtDto,
								ReportTypeEnum.PDF);
						if (!BaseUtil.isObjNull(receipt.getReportBytes())) {
							docList.add(trxnDocumentSvc.upload(receiptDoc.get(0), receipt,
									tvlPayment.getPmtRefNo(), request));
						}
					}
					trxnDocumentSvc.createUpdateDoc(docList, tvlPayment.getCreateId(), tvlPayment.getDocRefNo());
				}

			}

			return JsonUtil.transferToObject(tvlPayment, Payment.class);

		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}
}
