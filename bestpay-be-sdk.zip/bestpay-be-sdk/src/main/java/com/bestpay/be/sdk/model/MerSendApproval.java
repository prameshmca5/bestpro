/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;


/**
 * @author Ramesh
 * @since Oct 21, 2019
 */
public class MerSendApproval implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1864073233598003483L;

	 

	private String merchantId;

	private Integer pdpa;
	
	private String msg;
	
	private String email;
	
	private String companyRefId;


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public Integer getPdpa() {
		return pdpa;
	}


	public void setPdpa(Integer pdpa) {
		this.pdpa = pdpa;
	}


	public String getMsg() {
		return msg;
	}


	public void setMsg(String msg) {
		this.msg = msg;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getCompanyRefId() {
		return companyRefId;
	}


	public void setCompanyRefId(String companyRefId) {
		this.companyRefId = companyRefId;
	}
	
	
}