/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.RefFpxResponseCode;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author
 * @since 29/11/2017
 */
@Repository
@RepositoryDefinition(domainClass = RefFpxResponseCode.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.FPX_RESPONSE_CODE_DAO)
public interface FpxResponseCodeRepository extends GenericRepository<RefFpxResponseCode> {

	@Query("select u from RefFpxResponseCode u where u.fpxCode = :fpxCode ")
	RefFpxResponseCode findByFpxCode(@Param("fpxCode") String fpxCode);

}