/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.model.Transaction;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.report.sdk.constants.ReportTypeEnum;
import com.bestpay.report.sdk.model.Report;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.WebUtil;

/**
 * @author N.N.Shuhada
 * @since June 12, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_TRANSACTION_DTLS)
public class TransactionDetailsController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionDetailsController.class);

	@GetMapping
	public ModelAndView transDtlInfo(Transaction transaction, HttpSession session) {
		return new ModelAndView(PageTemplate.TEMP_TRANSACTION_DTLS);
	}

	/**
	 * Transaction Details Page
	 *
	 * @param tranId
	 * @param Transaction
	 * @param result
	 * @return
	 */
	@GetMapping(value = "/{transId}")
	public ModelAndView viewTransDetails(@PathVariable String transId,
			@ModelAttribute("transaction") Transaction transaction, BindingResult result) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TRANSACTION_DTLS, "trans", null);

		try {
			Transaction transDtl = getBeService().getTransDtlsById(transId);
			MerAccInfo merAccInfo = getBeService().getAccInfoById(transDtl.getMerchantId());
			String desc= transDtl.getResMsg().replaceAll("_"," ");
			transDtl.setResMsg(desc);
			LOGGER.info("created_date = {}", transDtl.getCreateDt());
			mav.addObject("merInfo", merAccInfo);
			mav.addObject("transaction", transDtl);
		} catch (BeException e) {
			LOGGER.error("Transaction Details = {}", e);
		}

		return mav;
	}

	@PostMapping(value = "/{transId}", params = "reset")
	public ModelAndView reset(@RequestParam String reset, @PathVariable String transId,
			@ModelAttribute("transaction") Transaction transaction, BindingResult result, HttpSession session) {
		return viewTransDetails(transId, transaction, result);
	}

	@PostMapping(value = "/{transId}", params = "update=saveMemo")
	public ModelAndView updateMerMemo(@PathVariable String transId,
			@ModelAttribute("transaction") Transaction transaction, BindingResult result) {

		ModelAndView mav = new ModelAndView();
		boolean isUpdated = false;

		try {
			isUpdated = getBeService().updateMerTransDtls(transaction);
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		if (isUpdated) {
			mav = viewTransDetails(transId, new Transaction(), result);
		}

		return mav;

	}

	@GetMapping(value = "print/genTransDetailsReport")
	public @ResponseBody Report genTransDetailsReport(@ModelAttribute("transaction") Transaction transaction,
			@RequestParam(value = "transId", required = true) String transId, BindingResult result,
			HttpServletRequest request, HttpSession session) {

		Report report = null;
		try {
			report = getReportService().genTransDetailsRpt(transId, ReportTypeEnum.PDF, true);
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.debug("Exception {}", e);
		}
		return report;
	}

}