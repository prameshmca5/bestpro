/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.bestpay.be.model.PgwOfflineRequestPayment;
import com.bestpay.be.sdk.model.PgwOfflineRequestPaymentDto;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.pagination.PaginationCriteria;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;

/**
 * @author Ramesh Pongiannan
 * @since June 16, 2018
 */
@Repository
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_PAYLK_DAO)
public class PgwOfflineRequestPaymentCustomDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(PgwOfflineRequestPaymentCustomDao.class);

	@Autowired
	private PgwOfflineRequestPaymentRepository pgwOfflineRequestPaymentRepository;

	//
	@PersistenceContext
	private EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public DataTableResults<PgwOfflineRequestPayment> searchByPagination(
			PgwOfflineRequestPaymentDto pgwOfflineRequestPayment, DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append("from PgwOfflineRequestPayment r ");
		sb.append(" where 1=1 ");

		if (!BaseUtil.isObjNull(pgwOfflineRequestPayment.getMerchantId())) {
			sb.append(" and r.merchantId = :merchantId ");
		}

		sb.append(" ORDER BY r.createDt DESC");

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<PgwOfflineRequestPayment> query = entityManager.createQuery(sb.toString(),
				PgwOfflineRequestPayment.class);
		// Original Query
		TypedQuery<PgwOfflineRequestPayment> query2 = entityManager.createQuery(sb.toString(),
				PgwOfflineRequestPayment.class);

		if (!BaseUtil.isObjNull(pgwOfflineRequestPayment.getMerchantId())) {
			query.setParameter("merchantId", pgwOfflineRequestPayment.getMerchantId());
			query2.setParameter("merchantId", pgwOfflineRequestPayment.getMerchantId());
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwOfflineRequestPayment> dataTableResult = new DataTableResults<>();
		List<PgwOfflineRequestPayment> svcResp = query.getResultList();
		List<PgwOfflineRequestPayment> svcResp2 = query2.getResultList();
		LOGGER.debug("Filtered Size: {}", svcResp.size());
		LOGGER.debug("Original Size: {}", svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size()
				: pgwOfflineRequestPaymentRepository.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		LOGGER.debug("isFilterByEmpty: {}", dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}
		return dataTableResult;
	}
}