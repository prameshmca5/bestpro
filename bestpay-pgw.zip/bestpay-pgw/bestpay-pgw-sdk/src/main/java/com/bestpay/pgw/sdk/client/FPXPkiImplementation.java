/*
# These sample codes are provided for information purposes only. It does not imply any recommendation or endorsement by anyone.
  These sample codes are provided for FREE, and no additional support will be provided for these sample pages.
  There is no warranty and no additional document. USE AT YOUR OWN RISK.
*/

package com.bestpay.pgw.sdk.client;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bestpay.pgw.sdk.util.BaseUtil;


public class FPXPkiImplementation {

	private static final Logger logger = LoggerFactory.getLogger(FPXPkiImplementation.class);

	static {
		Security.addProvider(new BouncyCastleProvider());
	}

	static String errorCode = "ErrorCode : [03]";

	static int cerExpiryCount = 0;


	private FPXPkiImplementation() {
	}


	public static String signData(String pvtKeyFileName, String dataToSign, String signatureAlg) throws IOException,
			NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException, SignatureException {

		PrivateKey privateKey = getPrivateKey(pvtKeyFileName);
		Signature signature = Signature.getInstance(signatureAlg, "BC");
		signature.initSign(privateKey);

		signature.update(dataToSign.getBytes());
		byte[] signatureBytes = signature.sign();

		return byteArrayToHexString(signatureBytes);

	}


	public static String verifyData(String pubKeyFileName, String calcCheckSum, String checkSumFromMsg,
			String signatureAlg, String certFileName, String certCurrFileName)
			throws NoSuchAlgorithmException, NoSuchProviderException, IOException, InvalidKeyException,
			SignatureException, CertificateException, ParseException {

		boolean result = false;
		try {
			ArrayList<PublicKey> pubKeys = getFPXPublicKey(pubKeyFileName, certFileName, certCurrFileName);
			Signature verifier = Signature.getInstance(signatureAlg, "BC");

			if (pubKeys != null && !pubKeys.isEmpty()) {
				logger.info("public keys: {}", pubKeys.size());
				for (PublicKey pubKey : pubKeys) {
					verifier.initVerify(pubKey);
					verifier.update(calcCheckSum.getBytes());
					result = verifier.verify(hexStringToByteArray(checkSumFromMsg));
					logger.info("result [{}]:", result);
					if (result) {
						return "00";
					} else {
						return "Your Data cannot be verified against the Signature. ErrorCode :[09]";
					}

				}
			}
			if (!BaseUtil.isObjNull(pubKeys) && cerExpiryCount == 1) {
				return "One Certificate Found and Expired. ErrorCode : [07]";
			} else if (BaseUtil.isObjNull(pubKeys) && cerExpiryCount == 2) {
				return "Both Certificates Expired . ErrorCode : [08]";
			}
			if (BaseUtil.isObjNull(pubKeys)) {
				return "Invalid Certificates. ErrorCode : [06]";
			}
		} catch (Exception e) {
			return "ErrorCode : [03]" + e.getMessage();
		} finally {
			cerExpiryCount = 0;
		}

		return errorCode;
	}


	private static PublicKey getPublicKey(X509Certificate certificate) {
		return certificate.getPublicKey();
	}


	private static PrivateKey getPrivateKey(String pvtKeyFileName) throws IOException {
		FileReader pvtFileReader = getPVTKeyFile(new File(pvtKeyFileName));
		PEMReader pvtPemReader = getPvtPemReader(pvtFileReader);
		KeyPair keyPair = (KeyPair) pvtPemReader.readObject();
		if (pvtFileReader != null) {
			pvtFileReader.close();
		}

		pvtPemReader.close();

		if (keyPair == null) {
			return null;
		}
		return keyPair.getPrivate();
	}


	private static FileReader getPVTKeyFile(File pvtFile) {
		FileReader pvtFileReader = null;
		try {
			pvtFileReader = new FileReader(pvtFile);
		} catch (FileNotFoundException e) {

			logger.error("Error: getPVTKeyFile: ", e);
			pvtFileReader = null;
		}

		return pvtFileReader;
	}


	private static PEMReader getPvtPemReader(Reader pvtFile) {
		return new PEMReader(pvtFile);
	}


	static char[] hexChar = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };


	public static String byteArrayToHexString(byte[] b) {
		StringBuilder sb = new StringBuilder(b.length * 2);
		for (byte element : b) {
			sb.append(hexChar[(element & 0xf0) >>> 4]);
			sb.append(hexChar[element & 0x0f]);
		}
		return sb.toString();
	}


	public static byte[] hexStringToByteArray(String strHex) {
		byte[] bytKey = new byte[(strHex.length() / 2)];
		int y = 0;
		String strbyte;
		for (int x = 0; x < bytKey.length; x++) {
			strbyte = strHex.substring(y, (y + 2));
			if (strbyte.equals("FF")) {
				bytKey[x] = (byte) 0xFF;
			} else {
				bytKey[x] = (byte) Integer.parseInt(strbyte, 16);
			}
			y = y + 2;
		}
		return bytKey;
	}


	private static X509Certificate getX509Certificate(String pubKeyFileName) throws CertificateException, IOException {
		X509Certificate cert = null;
		try (InputStream inStream = new FileInputStream(pubKeyFileName);) {

			CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
			cert = (X509Certificate) certFactory.generateCertificate(inStream);
			return cert;
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage());
		}
		return null;
	}


	private static ArrayList<PublicKey> getFPXPublicKey(String path, String certFileName, String certCurrFileName)
			throws CertificateException, IOException, ParseException {
		try {
			Integer.parseInt(new SimpleDateFormat("yyyy").format(new Date()));

		} catch (NumberFormatException e) {
			logger.error(e.getMessage());
		}

		ArrayList<String> certFiles = new ArrayList<>();
		certFiles.add(path + File.separator + certCurrFileName);// Old
														// Certificate
		certFiles.add(path + File.separator + certFileName); // New
													// Certificate
		certFiles.add(path + File.separator + "bpay4u_wcssl.crt");
		ArrayList<PublicKey> publicKeys = null;

		for (String file : certFiles) {
			publicKeys = checkCertExpiry(file, certFileName, certCurrFileName);
			logger.info("{} <---> {}", file, publicKeys.size());
			if (!publicKeys.isEmpty()) {
				return publicKeys;
			}
		}

		return publicKeys;
	}


	private static ArrayList<PublicKey> checkCertExpiry(String file, String certFileName, String certCurrFileName)
			throws CertificateException, IOException, ParseException {
		ArrayList<PublicKey> publicKey = new ArrayList<>();
		X509Certificate x509Cert = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		int renamestatus;
		try {
			x509Cert = getX509Certificate(file);
		} catch (FileNotFoundException e) {
			logger.info("FileNotFoundException {}", e);
			return publicKey;
		}

		Calendar currentDate = Calendar.getInstance();
		currentDate.setTime(sdf.parse(sdf.format(new Date())));

		Calendar certExpiryDate = Calendar.getInstance();
		if (x509Cert != null) {
			certExpiryDate.setTime(sdf.parse(sdf.format(x509Cert.getNotAfter())));
		}
		certExpiryDate.add(Calendar.DAY_OF_MONTH, -1);

		SimpleDateFormat settleSdf = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss.SSS");
		String expdate = settleSdf.format(certExpiryDate.getTime());
		String currdate = settleSdf.format(currentDate.getTime());
		logger.info("{} <--> {}", expdate, currdate);
		logger.info("{} <--> {} <-> {} ", certExpiryDate.getTime(), currentDate.getTime(),
				certExpiryDate.compareTo(currentDate));
		if (certExpiryDate.compareTo(currentDate) == 0) // cert expiry and
												// current date is
												// same
												// day so check is
												// both
												// cert
		{
			logger.info("Same day do check with both cert");
			String nextFile = getNextCertFile(file, certFileName);
			File nextFileCheck = new File(nextFile);

			if (!file.contains(certCurrFileName) && nextFileCheck.exists()) {
				renamestatus = certRollOver(nextFile, certCurrFileName);
				logger.info("renstatus [{}] ", renamestatus);

			}
			logger.info("cert1 [{}] cert2 [{}]", nextFile, file);
			try {
				if (nextFileCheck.exists()) {
					publicKey.add(getPublicKey(getX509Certificate(nextFile)));
				}

				publicKey.add(getPublicKey(x509Cert));
			} catch (NullPointerException e) {
				logger.error(e.getMessage());
			}
		} else if (certExpiryDate.compareTo(currentDate) > 0) // Not
													// Expired(Still
													// valid)
		{
			if (file.contains(certFileName)) {

				renamestatus = certRollOver(file, certCurrFileName);
				logger.info("renstatus[{}]", renamestatus);

			}

			logger.info("Still valid [{}]", file);
			try {
				publicKey.add(getPublicKey(x509Cert));
			} catch (NullPointerException e) {
				logger.error(e.getMessage());
			}
		} else if (certExpiryDate.compareTo(currentDate) < 0) // Expired
		{

			cerExpiryCount = cerExpiryCount + 1;

			logger.info("Expired [{}]", file);
		}

		return publicKey;

	}


	private static int certRollOver(String file, String certCurrFileName) {
		File oldcrt = new File(file);

		File newcrt = new File(oldcrt.getParent() + File.separator + certCurrFileName);
		String timestamp = new java.text.SimpleDateFormat("yyyyMMddhmmss").format(new Date());

		File newfile = new File(oldcrt.getParent() + File.separator + certCurrFileName + timestamp);

		if (newcrt.exists()) {
			// FPX_CURRENT.cer to FPX_CURRENT.cer_<CURRENT TIMESTAMP>
			logger.info("{} old_crt is {}", newcrt, newfile);
			if (newcrt.renameTo(newfile)) {
				logger.info("File renamed");
			} else {
				logger.info("Sorry! the file can't be renamed");
				return 01;
			}
		}

		if (!newcrt.exists() && oldcrt.exists()) {
			// FPX.cer to FPX_CURRENT.cer
			logger.info("{} old_cer is {}", newcrt, oldcrt);
			if (oldcrt.renameTo(newcrt)) {
				logger.info("File renamed");
			} else {
				logger.info("Sorry! the file can't be renamed");
				return 01;
			}
		}

		return 00;
	}


	private static String getNextCertFile(String strFile, String certFileName) {
		File file = new File(strFile);
		return file.getParentFile() + File.separator + certFileName;
	}

}