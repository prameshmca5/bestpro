/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@Entity
@Table(name = "PGW_FRAUD_SETTING")
public class PgwFraudSetting extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "FRAUD_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer fraudId;

	@Column(name = "MERCHANT_ID")
	private String merchantId;

	@Column(name = "MAXALLOW_FRAUDSCORE")
	private Integer maxallowFraudscore;

	@Column(name = "ALLOW_MY_IP")
	private String allowMyIp;

	@Column(name = "ALLOW_MY_CC")
	private String allowMyCc;

	@Column(name = "ALLOW_IPCC_MATCH")
	private String allowIpccMatch;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public PgwFraudSetting() {
		// pgwFraudSetting backend model
	}


	public Integer getFraudId() {
		return fraudId;
	}


	public void setFraudId(Integer fraudId) {
		this.fraudId = fraudId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public Integer getMaxallowFraudscore() {
		return maxallowFraudscore;
	}


	public void setMaxallowFraudscore(Integer maxallowFraudscore) {
		this.maxallowFraudscore = maxallowFraudscore;
	}


	public String getAllowMyIp() {
		return allowMyIp;
	}


	public void setAllowMyIp(String allowMyIp) {
		this.allowMyIp = allowMyIp;
	}


	public String getAllowMyCc() {
		return allowMyCc;
	}


	public void setAllowMyCc(String allowMyCc) {
		this.allowMyCc = allowMyCc;
	}


	public String getAllowIpccMatch() {
		return allowIpccMatch;
	}


	public void setAllowIpccMatch(String allowIpccMatch) {
		this.allowIpccMatch = allowIpccMatch;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}