package com.be.controller;


import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.be.constants.ConfigConstants;
import com.be.core.AbstractRestController;
import com.be.model.BeConfig;
import com.be.model.BeMemberProfile;
import com.be.model.BePayment;
import com.be.model.BePaymentDtl;
import com.be.model.BePreReg;
import com.be.model.BePreRegAddress;
import com.be.model.BeTrxnDocument;
import com.be.model.BeTrxnDocumentPK;
import com.be.model.RefBranch;
import com.be.model.RefDivision;
import com.be.model.RefMetadata;
import com.be.model.RefState;
import com.be.model.RefStatus;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.constants.FileUploadConstants;
import com.be.sdk.constants.MailTemplateConstants;
import com.be.sdk.constants.ReferenceConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.AckSlip;
import com.be.sdk.model.KiplePaymentRequest;
import com.be.sdk.model.Metadata;
import com.be.sdk.model.Payment;
import com.be.sdk.model.PaymentDtl;
import com.be.sdk.model.PreReg;
import com.be.sdk.model.PreRegAddress;
import com.be.sdk.model.SenangPayResponds;
import com.be.sdk.model.Status;
import com.be.service.BeConfigService;
import com.be.service.BeMemberProfileService;
import com.be.service.BePaymentDtlService;
import com.be.service.BePaymentService;
import com.be.service.BePreRegService;
import com.be.service.BeTrxnDocumentsService;
import com.be.service.RefBranchService;
import com.be.service.RefDivisionService;
import com.be.service.RefDocumentService;
import com.be.service.RefMetadataService;
import com.be.service.RefStateService;
import com.be.service.RefStatusService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.notify.sdk.constants.MailTypeEnum;
import com.notify.sdk.model.Notification;
import com.notify.sdk.util.MailUtil;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.MediaType;
import com.util.UidGenerator;
import com.util.pagination.DataTableRequest;
import com.util.pagination.DataTableResults;


@RestController
@RequestMapping(BeUrlConstants.REGISTER)
public class RegistrationRestController extends AbstractRestController {

	@Autowired
	BePreRegService bePreRegSvc;

	@Autowired
	RefStatusService refStatusSvc;

	@Autowired
	BeConfigService beConfigSvc;

	@Autowired
	RefMetadataService refMetadataSvc;

	@Autowired
	BeMemberProfileService beMemberProfileSvc;

	@Autowired
	RefDivisionService refDivisionSvc;

	@Autowired
	RefMetadataService refMetaSvc;

	@Autowired
	RefBranchService refBranchSvc;

	@Autowired
	RefStateService RefStateSvc;

	@Autowired
	RefDocumentService documentSvc;

	@Autowired
	BeTrxnDocumentsService trxnDocumentSvc;

	@Autowired
	private BePaymentDtlService bePaymentDtlSvc;
	
	@Autowired
	private BePaymentService bePaymentSvc;
	
	@Value("${" + ConfigConstants.PORTAL_APP_URL + "}")
	private String portalAppUrl;

	@Value("${" + ConfigConstants.KIPLE_APP_URL + "}")
	private String kipleAppUrl;

	@Value("${" + ConfigConstants.SENANGPAY_APP_URL + "}")
	private String senangpayAppUrl;


	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<PreReg> searchPaginated(@Valid @RequestBody PreReg dto, HttpServletRequest request)
			throws IOException {
		DataTableRequest<PreReg> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) bePreRegSvc.getCount(dto);
		List<PreReg> filtered = bePreRegSvc.searchPagination(dto, dataTableInRQ);

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATIONS, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<PreReg> searchPaginatedList(@Valid @RequestBody PreReg dto, HttpServletRequest request)
			throws IOException {
		DataTableRequest<PreReg> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) bePreRegSvc.getCount(dto);
		List<PreReg> filtered = bePreRegSvc.searchPagination(dto, dataTableInRQ);

		for (PreReg task : filtered) {
			String currData = "-";

			if (!BaseUtil.isObjNull(task.getOrgStateCd())) {
				RefState refState = RefStateSvc.findByStateCode(task.getOrgStateCd());
				if (!BaseUtil.isObjNull(refState)) {
					task.setOrgStateDesc(refState.getStateDesc());
				} else {
					task.setOrgStateDesc(currData);
				}

			} else {

				task.setOrgStateDesc(currData);
			}

			if (!BaseUtil.isObjNull(task.getOrgDivisionCd())) {
				RefDivision refDiv = refDivisionSvc.findByDivisionCd(task.getOrgDivisionCd());
				if (!BaseUtil.isObjNull(refDiv)) {
					task.setOrgDivisionDesc(refDiv.getDivisionDesc());
				} else {
					task.setOrgDivisionDesc(currData);
				}
			} else {
				task.setOrgDivisionDesc(currData);

			}

			if (!BaseUtil.isObjNull(task.getOrgBranchCd())) {
				RefBranch refDiv = refBranchSvc.findByBranchCd(task.getOrgBranchCd());
				if (!BaseUtil.isObjNull(refDiv)) {
					task.setOrgBranchDesc(refDiv.getBranchDesc());
				} else {
					task.setOrgBranchDesc(currData);
				}
			} else {
				task.setOrgBranchDesc(currData);

			}

			if (!BaseUtil.isObjNull(task.getMemberCtrgyMtdtId())) {
				RefMetadata refMetaSearch = new RefMetadata();
				refMetaSearch.setMtdtId(task.getMemberCtrgyMtdtId());

				List<RefMetadata> refMetaResult = refMetaSvc.findMetadataByCriteria(refMetaSearch);
				if (BaseUtil.isObjNull(refMetaResult)) {
					task.setMemberCtrgyMtdtDesc(currData);
				} else {
					task.setMemberCtrgyMtdtDesc(refMetaResult.get(0).getMtdtDesc());

				}

			} else {
				task.setMemberCtrgyMtdtDesc(currData);
			}

		}
		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.SEARCH)
	public PreReg searchPreReg(@RequestBody PreReg dto, HttpServletRequest request) throws IOException {
		// PRE_REG_ID, TXN_ID, APP_REF_NO, PASSCODE
		PreReg preReg = bePreRegSvc.search(dto);
		if (!BaseUtil.isObjNull(preReg)) {
			Status status = preReg.getStatus();
			if (BaseUtil.isEquals(status.getStatusCd(), "PEND") || BaseUtil.isEquals(status.getStatusCd(), "IP_PD")) {
				Payment pmtDto = new Payment();
				pmtDto.setPmtBy(preReg.getIdNo());
				Payment pmtSearchResult = bePaymentSvc.search(pmtDto);
				if (!BaseUtil.isObjNull(pmtSearchResult)) {
					try {
						getRequestQuery(pmtSearchResult, request);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					preReg = bePreRegSvc.search(dto);
				}
			}
			// if(BaseUtil.isEquals(portalAppUrl, kipleAppUrl))
		}
		return preReg;
	}


	@PostMapping(value = BeUrlConstants.SEARCH_LIST)
	public List<PreReg> searchPreRegList(@RequestBody PreReg dto, HttpServletRequest request) throws IOException {
		// TXN_ID LIST
		return bePreRegSvc.searchPreRegList(dto);
	}


	@PostMapping(value = BeUrlConstants.CREATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public PreReg createPreReg(@RequestBody PreReg dto, HttpServletRequest request) {

		// check if id no valid for registration process, will throw exception
		// if not valid
		checkValidRegIdNo(dto.getIdNo());

		// check if contact no is exist or not
		BeConfig beConf = beConfigSvc.findByConfigCode(ConfigConstants.CONFIG_CONTACT_NO);
		if (BaseUtil.isEquals(beConf.getConfigVal(), "1")) {
			checkContactNo(dto.getContactNo());
		}

		BePreReg crtPreReg = dozerMapper.map(dto, BePreReg.class);
		String appRefNo = UidGenerator.generateUidYear("PRE");
		crtPreReg.setTxnId(UidGenerator.getMessageId());
		crtPreReg.setAppRefNo(appRefNo);
		crtPreReg.setPasscode(UidGenerator.generateRandomNoInStr());

		String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();

		RefStatus refStatus = refStatusSvc.findByStatusCodeStatusType("PEND", "REG_STATUS");
		crtPreReg.setStatusId(refStatus.getStatusId());
		if (!BaseUtil.isListNull(dto.getPreRegAddressList())) {
			List<BePreRegAddress> preRegAddList = dto.getPreRegAddressList().stream().map(address -> {
				BePreRegAddress preAdd = dozerMapper.map(address, BePreRegAddress.class);
				preAdd.setStatus(true);
				preAdd.setCreateId(userId);
				preAdd.setCreateDt(currDt);
				preAdd.setUpdateId(userId);
				preAdd.setUpdateDt(currDt);

				return preAdd;
			}).collect(Collectors.toList());

			crtPreReg.addBePreRegAddressList(preRegAddList);
		}

		List<BeTrxnDocument> beTrxnDocumentsList = null;
		if (!BaseUtil.isListNull(dto.getTrxnDocumentList())) {
			String docRefNo = UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC);
			crtPreReg.setDocRefNo(docRefNo);
			beTrxnDocumentsList = dto.getTrxnDocumentList().stream().map(doc -> {
				BeTrxnDocumentPK docPk = new BeTrxnDocumentPK();
				docPk.setDocRefNo(docRefNo);
				docPk.setDocId(doc.getDocId());
				docPk.setDocMgtId(doc.getDocMgtId());
				BeTrxnDocument trxnDoc = new BeTrxnDocument(docPk, appRefNo, doc.getDocContentType());
				trxnDoc.setCreateId(userId);
				trxnDoc.setCreateDt(currDt);
				trxnDoc.setUpdateId(userId);
				trxnDoc.setUpdateDt(currDt);
				return trxnDoc;
			}).collect(Collectors.toList());
		}
		crtPreReg.setPositionId(dto.getPositionId());
		crtPreReg.setApplyBy(userId);
		crtPreReg.setApplyDt(currDt);
		crtPreReg.setCreateId(userId);
		crtPreReg.setCreateDt(currDt);
		crtPreReg.setUpdateId(userId);
		crtPreReg.setUpdateDt(currDt);
		crtPreReg = bePreRegSvc.create(crtPreReg, beTrxnDocumentsList);
		return dozerMapper.map(crtPreReg, PreReg.class);
	}


	@PostMapping(value = BeUrlConstants.PUBLIC + BeUrlConstants.CREATE, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public PreReg createPreRegPublic(@RequestBody PreReg dto, HttpServletRequest request) throws IOException {

		Payment pmtDto = dto.getPayment();
		if (BaseUtil.isObjNull(pmtDto) || BaseUtil.isListNull(pmtDto.getPaymentDtlList())) {
			throw new BeException(BeErrorCodeEnum.E400C006);
		}

		PreReg preRegDto = new PreReg();
		preRegDto.setIdNo(dto.getIdNo());
		
		if (BaseUtil.isEquals(dto.getChannelMtdtCd(), ReferenceConstants.MTDT_CD_MOB_SELF)) {
			RefMetadata channelRefMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_REG_CHANNEL,
					ReferenceConstants.MTDT_CD_MOB_SELF);
			if (!BaseUtil.isObjNull(channelRefMtdt)) {
				preRegDto.setChannelMtdtId(channelRefMtdt.getMtdtId());
			}
		}
		
		PreReg preRegExist = bePreRegSvc.search(preRegDto);
		
		// check if id no valid for registration process, will throw
		// exception if not valid
		if (BaseUtil.isObjNull(preRegExist)) {
			checkValidRegIdNo(dto.getIdNo());
		
		} else {
			if (!BaseUtil.isObjNull(preRegExist)) {
				
				if(!BaseUtil.isObjNull(preRegExist) && !BaseUtil.isObjNull(preRegExist.getStatusId())) {
					RefStatus refStatus = refStatusSvc.findByStatusCodeStatusType("REJ", "REG_STATUS");
					if (!BaseUtil.isObjNull(refStatus) && 
							preRegExist.getStatusId().intValue() == refStatus.getStatusId().intValue()){
						
						checkValidRegIdNo(dto.getIdNo());
					} 
				}
			}
		}

		// check if contact no is exist or not
		BeConfig beConf = beConfigSvc.findByConfigCode(ConfigConstants.CONFIG_CONTACT_NO);
		if (BaseUtil.isEquals(beConf.getConfigVal(), "1")) {
			checkContactNo(dto.getContactNo());
		}

		// create registration
		BePreReg crtPreReg = dozerMapper.map(dto, BePreReg.class);
		String appRefNo = UidGenerator.generateUidYear("PRE");
		crtPreReg.setTxnId(UidGenerator.getMessageId());
		crtPreReg.setAppRefNo(appRefNo);
		crtPreReg.setPasscode(UidGenerator.generateRandomNoInStr());
		crtPreReg.setHqInd(0);

		// String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();

		RefStatus refStatus = refStatusSvc.findByStatusCodeStatusType("PEND", "REG_STATUS");
		crtPreReg.setStatusId(refStatus.getStatusId());
		if (!BaseUtil.isListNull(dto.getPreRegAddressList())) {

			Integer addressTypeMtdtId = null;
			if (BaseUtil.isEquals(dto.getChannelMtdtCd(), ReferenceConstants.MTDT_CD_MOB_SELF)) {
				RefMetadata addressTypeMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_ADDR_TYPE,
						ReferenceConstants.MTDT_CD_PRES);
				if (!BaseUtil.isObjNull(addressTypeMtdt)) {
					addressTypeMtdtId = addressTypeMtdt.getMtdtId();
				}
			}

			List<BePreRegAddress> preRegAddList = new ArrayList<>();
			for (PreRegAddress address : dto.getPreRegAddressList()) {
				BePreRegAddress preAdd = dozerMapper.map(address, BePreRegAddress.class);
				preAdd.setStatus(true);
				if (!BaseUtil.isObjNull(addressTypeMtdtId)) {
					preAdd.setAddressTypeMtdtId(addressTypeMtdtId);
				}
				preAdd.setCreateId(dto.getIdNo());
				preAdd.setCreateDt(currDt);
				preAdd.setUpdateId(dto.getIdNo());
				preAdd.setUpdateDt(currDt);
				preRegAddList.add(preAdd);
			}
			crtPreReg.addBePreRegAddressList(preRegAddList);
		}

		List<BeTrxnDocument> beTrxnDocumentsList = null;
		if (!BaseUtil.isListNull(dto.getTrxnDocumentList())) {
			String docRefNo = UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC);
			crtPreReg.setDocRefNo(docRefNo);
			beTrxnDocumentsList = dto.getTrxnDocumentList().stream().map(doc -> {
				BeTrxnDocumentPK docPk = new BeTrxnDocumentPK();
				docPk.setDocRefNo(docRefNo);
				docPk.setDocId(doc.getDocId());
				docPk.setDocMgtId(doc.getDocMgtId());
				BeTrxnDocument trxnDoc = new BeTrxnDocument(docPk, appRefNo, doc.getDocContentType());
				trxnDoc.setCreateId(dto.getIdNo());
				trxnDoc.setCreateDt(currDt);
				trxnDoc.setUpdateId(dto.getIdNo());
				trxnDoc.setUpdateDt(currDt);
				return trxnDoc;
			}).collect(Collectors.toList());
		}

		crtPreReg.setApplyBy(dto.getIdNo());
		crtPreReg.setApplyDt(currDt);
		crtPreReg.setCreateId(dto.getIdNo());
		crtPreReg.setCreateDt(currDt);
		crtPreReg.setUpdateId(dto.getIdNo());
		crtPreReg.setUpdateDt(currDt);

		// create payment (pre payment)
		BePayment crtPayment = dozerMapper.map(pmtDto, BePayment.class);
		String pmtRefNo = UidGenerator.generateUidYear("PMT");
		crtPayment.setTxnId(UidGenerator.getMessageId());
		crtPayment.setPmtRefNo(pmtRefNo);

		refStatus = refStatusSvc.findByStatusCodeStatusType("PEND", "PMT_STATUS");
		crtPayment.setStatusId(refStatus.getStatusId());
		crtPayment.setPmtBy(dto.getIdNo());
		crtPayment.setPmtDt(currDt);
		crtPayment.setCreateId(dto.getIdNo());
		crtPayment.setCreateDt(currDt);
		crtPayment.setUpdateId(dto.getIdNo());
		crtPayment.setUpdateDt(currDt);

		if (BaseUtil.isEquals(dto.getChannelMtdtCd(), ReferenceConstants.MTDT_CD_MOB_SELF)) {
			BeConfig beConfig = beConfigSvc.findByConfigCode(ConfigConstants.PAYMENT_BATCH_ID);
			if (!BaseUtil.isObjNull(beConfig)) {
				crtPayment.setBatchId(BaseUtil.getInt(beConfig.getConfigVal()));
			}

			RefMetadata pmtTypeMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_PMT_TYPE,
					ReferenceConstants.MTDT_CD_PMT_CC);
			if (!BaseUtil.isObjNull(pmtTypeMtdt)) {
				crtPayment.setPmtTypeMtdtId(pmtTypeMtdt.getMtdtId());
			}

			RefMetadata channelMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_REG_CHANNEL,
					ReferenceConstants.MTDT_CD_MOB_SELF);
			if (!BaseUtil.isObjNull(channelMtdt)) {
				crtPreReg.setChannelMtdtId(channelMtdt.getMtdtId());
				crtPayment.setChannelMtdtId(channelMtdt.getMtdtId());
			}
			
			// set type and category for mobile
			boolean nonMuslim = true;
			boolean nonBumi = false;
			
			RefMetadata religionMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_RELIGION,
					ReferenceConstants.MTDT_CD_MUSLIM);
			if (!BaseUtil.isObjNull(religionMtdt)) {
				if (religionMtdt.getMtdtId().equals(dto.getReligionMtdtId())) {
					nonMuslim = false;
				}
			}
			
			RefMetadata ethnicMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_ETHNIC,
					ReferenceConstants.MTDT_CD_NONBUMI);
			if (!BaseUtil.isObjNull(ethnicMtdt)) {
				if (ethnicMtdt.getMtdtId().equals(dto.getEthnicMtdtId())) {
					nonBumi = true;
				}
			}
			
			if (nonMuslim && nonBumi) {
				RefMetadata ahliBersekutuMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_MBR_TYPE,
						ReferenceConstants.MTDT_CD_CAT_ALLY);
				if (!BaseUtil.isObjNull(ahliBersekutuMtdt)) {
					// AHLI BERSEKUTU
					crtPreReg.setMemberTypeMtdtId(ahliBersekutuMtdt.getMtdtId());
				}
			} else {
				RefMetadata ahliBiasaMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_MBR_TYPE,
						ReferenceConstants.MTDT_CD_CAT_NRML);
				if (!BaseUtil.isObjNull(ahliBiasaMtdt)) {
					// AHLI BIASA
					crtPreReg.setMemberTypeMtdtId(ahliBiasaMtdt.getMtdtId());
				}
				
				RefMetadata genMale = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_GENDER, "M");
				RefMetadata genFemale = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_GENDER, "F");
				
				if (!BaseUtil.isObjNull(genMale) && !BaseUtil.isObjNull(genFemale)) {
					// to set Member Category
					if (dto.getGenderMtdtId().equals(genMale.getMtdtId())) {
						// armada
						new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
						Date firstDate = dto.getDob();
						Date secondDate = new Date();

						int age = Math.abs(secondDate.getYear() - firstDate.getYear());

						crtPreReg.setMemberCtrgyMtdtId(getCategoryByAge(age));

					}

					if (dto.getGenderMtdtId().equals(genFemale.getMtdtId())) {
						RefMetadata srikandi = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_MBR_CAT, "TYPE_SRI");
						if (!BaseUtil.isObjNull(srikandi)) {
							// srikandi
							crtPreReg.setMemberCtrgyMtdtId(srikandi.getMtdtId());
						}
					}					
				}
			}
			
		}
		
		if (BaseUtil.isEquals(dto.getChannelMtdtCd(), ReferenceConstants.MTDT_CD_MOB_SELF)) {
			
			if (!BaseUtil.isObjNull(preRegExist)) {
				crtPreReg = dozerMapper.map(preRegExist, BePreReg.class);
				
				PaymentDtl paymentDtl = bePaymentDtlSvc.searchDtl(BaseUtil.getStr(crtPreReg.getPreRegId()));
				
				List<BePaymentDtl> paymentDtlList = bePaymentDtlSvc.findByPreRegId(paymentDtl,null);
				
				if (BaseUtil.isListNull(paymentDtlList)) {
					throw new BeException(BeErrorCodeEnum.I404C001);
				}
				
				List<PaymentDtl> pmtDList = new ArrayList<PaymentDtl>();
				
				paymentDtlList.forEach(pmtDLst -> {
					PaymentDtl pd = new PaymentDtl();
					pd.setPmtId(pmtDLst.getPayment().getPmtId());
					pmtDList.add(pd);
				});
				
				Payment payment = new Payment();
				payment.setPaymentDtlList(pmtDList);
				
				payment = dozerMapper.map(bePaymentSvc.search(payment), Payment.class);
				
				crtPayment = dozerMapper.map(payment, BePayment.class); 
				
				crtPreReg.setPayment(crtPayment);
				
			} else {
				crtPreReg = bePreRegSvc.createPublic(crtPreReg, beTrxnDocumentsList, crtPayment, pmtDto.getPaymentDtlList());
			}
		} else {
			
			crtPreReg = bePreRegSvc.createPublic(crtPreReg, beTrxnDocumentsList, crtPayment, pmtDto.getPaymentDtlList());
		}

		/*
		 * Map<String, Object> map = new HashMap<>(); map.put("url",
		 * messageService.getMessage(ConfigConstants.PORTAL_APP_URL) +
		 * "/self-registration"); map.put("passcode",
		 * crtPreReg.getPasscode()); // sms if
		 * (!BaseUtil.isObjNull(crtPreReg.getContactNo())) { Notification
		 * notification = new Notification();
		 * notification.setNotifyTo(crtPreReg.getContactNo());
		 * notification.setMetaData(MailUtil.convertMapToJson(map));
		 * notification.setNotifyType(MailTypeEnum.SMS.getType());
		 * notification.setContent(crtPreReg.getIdNo());
		 * getNotifyService(request).addNotification(notification,
		 * MailTemplateConstants.PUBLIC_REG_RESULT_SMS); }
		 *
		 * // email if (!BaseUtil.isObjNull(crtPreReg.getEmail())) {
		 * Notification notification = new Notification();
		 * notification.setNotifyTo(crtPreReg.getEmail());
		 * notification.setMetaData(MailUtil.convertMapToJson(map));
		 * notification.setNotifyType(MailTypeEnum.MAIL.getType());
		 * notification.setContent(crtPreReg.getIdNo());
		 * getNotifyService(request).addNotification(notification,
		 * MailTemplateConstants.PUBLIC_REG_RESULT_EMAIL); }
		 *
		 * // fcm sendFcmNotification(crtPreReg.getIdNo(),
		 * crtPreReg.getIdNo(), map,
		 * MailTemplateConstants.PUBLIC_REG_RESULT_FCM, request);
		 */

		PreReg preRegPub = dozerMapper.map(crtPreReg, PreReg.class);

		if (BaseUtil.isEquals(dto.getChannelMtdtCd(), ReferenceConstants.MTDT_CD_MOB_SELF)) {

			KiplePaymentRequest kiplePaymentRequest = new KiplePaymentRequest();
			kiplePaymentRequest.setOrd_date(DateUtil.getCurrentDate());
			kiplePaymentRequest.setOrd_totalamt(crtPayment.getTotalAmount());
			kiplePaymentRequest.setOrd_gstamt(0.00);
			kiplePaymentRequest.setOrd_shipname(crtPreReg.getFullName());
			kiplePaymentRequest.setOrd_shipcountry(null);
			kiplePaymentRequest.setOrd_telephone(crtPreReg.getContactNo());
			kiplePaymentRequest.setOrd_email(crtPreReg.getEmail());

			kiplePaymentRequest.setOrd_delcharges("0.00");
			kiplePaymentRequest.setOrd_svccharges("0.00");
			kiplePaymentRequest.setOrd_mercref(crtPreReg.getPayment().getPmtRefNo());
			BeConfig beConfigMerchantId = beConfigSvc.findByConfigCode(ConfigConstants.MERCHANT_ID);
			kiplePaymentRequest.setOrd_mercID(beConfigMerchantId.getConfigVal());
			BeConfig beConfigMerchantSecret = beConfigSvc.findByConfigCode(ConfigConstants.MERCHANT_SECRET);
			String kiphash = convtRequstHash(beConfigMerchantSecret.getConfigVal(),
					beConfigMerchantId.getConfigVal(), crtPreReg.getPayment().getPmtRefNo(),
					crtPayment.getTotalAmount(), "");
			// kiplePaymentRequest.setMerchant_hashvalue("187d8cf8b17161772524c6288ecd69885c862dc1");
			kiplePaymentRequest.setMerchant_hashvalue(kiphash);
			kiplePaymentRequest.setPayment_code(ConfigConstants.CC);

			kiplePaymentRequest.setOrd_returnURL(portalAppUrl + ConfigConstants.PATH_REDIRECT_MOBILE);
			kiplePaymentRequest.setOrd_key(null);
			kiplePaymentRequest.setReturncode(null);
			kiplePaymentRequest.setOrd_customfield1(crtPayment.getCreateId());

			kiplePaymentRequest.setKipleUrl(kipleAppUrl);
			kiplePaymentRequest.setPmtType("KIPLEPAY");

			// SenangPay Request Params
			BeConfig payTypeSenang = beConfigSvc.findByConfigCode("SENANGPAY_PAYMENT");
			if (BaseUtil.isEquals(payTypeSenang.getConfigVal(), "Y")) {
				kiplePaymentRequest.setPmtType("SENANGPAY");
				kiplePaymentRequest.setSenangDesc("Membership Fees");
				// SenagPay Hash
				StringBuilder reqhashParam = new StringBuilder();
				String mercSecret = beConfigSvc.findByConfigCode("SENANGPAY_SECRET").getConfigVal();
				reqhashParam.append(mercSecret).append("Membership Fees").append(crtPayment.getTotalAmount())
						.append(crtPreReg.getPayment().getPmtRefNo());
				String convtHashKey = DigestUtils.md5Hex(reqhashParam.toString());
				kiplePaymentRequest.setMerchant_hashvalue(convtHashKey);
				BeConfig beConfigSenagMerchantId = beConfigSvc.findByConfigCode("SENANGPAY_MERCHANT_ID");
				kiplePaymentRequest.setOrd_mercID(beConfigSenagMerchantId.getConfigVal());
				kiplePaymentRequest.setOrd_returnURL(portalAppUrl + ConfigConstants.PATH_SENAG_REDIRECT_MOBILE);
				kiplePaymentRequest.setSenangUrl(senangpayAppUrl + beConfigSenagMerchantId.getConfigVal());
			}

			preRegPub.setKiplePaymentRequest(kiplePaymentRequest);
		}
			
		return preRegPub;
	}	
	
	
	@PostMapping(value = BeUrlConstants.PUBLIC + BeUrlConstants.CREATE + BeUrlConstants.NEW, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public PreReg createPreRegPublicNew(@RequestBody PreReg dto, HttpServletRequest request) throws IOException {
		
		PreReg preRegDto = new PreReg();
		preRegDto.setIdNo(dto.getIdNo());
		
		if (BaseUtil.isEquals(dto.getChannelMtdtCd(), ReferenceConstants.MTDT_CD_MOB_SELF)) {
			RefMetadata channelRefMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_REG_CHANNEL,
					ReferenceConstants.MTDT_CD_MOB_SELF);
			if (!BaseUtil.isObjNull(channelRefMtdt)) {
				preRegDto.setChannelMtdtId(channelRefMtdt.getMtdtId());
			}
		}
		
		PreReg preRegExist = bePreRegSvc.search(preRegDto);
		
		// check if id no valid for registration process, will throw
		// exception if not valid
		if (BaseUtil.isObjNull(preRegExist)) {
			checkValidRegIdNo(dto.getIdNo());
		
		} else {
			if (!BaseUtil.isObjNull(preRegExist)) {
				
				if(!BaseUtil.isObjNull(preRegExist) && !BaseUtil.isObjNull(preRegExist.getStatusId())) {
					RefStatus refStatus = refStatusSvc.findByStatusCodeStatusType("REJ", "REG_STATUS");
					if (!BaseUtil.isObjNull(refStatus) && 
							preRegExist.getStatusId().intValue() == refStatus.getStatusId().intValue()){
						
						checkValidRegIdNo(dto.getIdNo());
					} 
				}
			}
		}

		// check if contact no is exist or not
		BeConfig beConf = beConfigSvc.findByConfigCode(ConfigConstants.CONFIG_CONTACT_NO);
		if (BaseUtil.isEquals(beConf.getConfigVal(), "1")) {
			checkContactNo(dto.getContactNo());
		}
		
		// create registration
		BePreReg crtPreReg = dozerMapper.map(dto, BePreReg.class);
		String appRefNo = UidGenerator.generateUidYear("PRE");
		crtPreReg.setTxnId(UidGenerator.getMessageId());
		crtPreReg.setAppRefNo(appRefNo);
		crtPreReg.setPasscode(UidGenerator.generateRandomNoInStr());
		crtPreReg.setHqInd(0);

		// String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();

		RefStatus refStatus = refStatusSvc.findByStatusCodeStatusType("PEND", "REG_STATUS");
		crtPreReg.setStatusId(refStatus.getStatusId());
		if (!BaseUtil.isListNull(dto.getPreRegAddressList())) {

			Integer addressTypeMtdtId = null;
			if (BaseUtil.isEquals(dto.getChannelMtdtCd(), ReferenceConstants.MTDT_CD_MOB_SELF)) {
				RefMetadata addressTypeMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_ADDR_TYPE,
						ReferenceConstants.MTDT_CD_PRES);
				if (!BaseUtil.isObjNull(addressTypeMtdt)) {
					addressTypeMtdtId = addressTypeMtdt.getMtdtId();
				}
			}

			List<BePreRegAddress> preRegAddList = new ArrayList<>();
			for (PreRegAddress address : dto.getPreRegAddressList()) {
				BePreRegAddress preAdd = dozerMapper.map(address, BePreRegAddress.class);
				preAdd.setStatus(true);
				if (!BaseUtil.isObjNull(addressTypeMtdtId)) {
					preAdd.setAddressTypeMtdtId(addressTypeMtdtId);
				}
				preAdd.setCreateId(dto.getIdNo());
				preAdd.setCreateDt(currDt);
				preAdd.setUpdateId(dto.getIdNo());
				preAdd.setUpdateDt(currDt);
				preRegAddList.add(preAdd);
			}
			crtPreReg.addBePreRegAddressList(preRegAddList);
		}
		
		List<BeTrxnDocument> beTrxnDocumentsList = null;
		if (!BaseUtil.isListNull(dto.getTrxnDocumentList())) {
			String docRefNo = UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC);
			crtPreReg.setDocRefNo(docRefNo);
			beTrxnDocumentsList = dto.getTrxnDocumentList().stream().map(doc -> {
				BeTrxnDocumentPK docPk = new BeTrxnDocumentPK();
				docPk.setDocRefNo(docRefNo);
				docPk.setDocId(doc.getDocId());
				docPk.setDocMgtId(doc.getDocMgtId());
				BeTrxnDocument trxnDoc = new BeTrxnDocument(docPk, appRefNo, doc.getDocContentType());
				trxnDoc.setCreateId(dto.getIdNo());
				trxnDoc.setCreateDt(currDt);
				trxnDoc.setUpdateId(dto.getIdNo());
				trxnDoc.setUpdateDt(currDt);
				return trxnDoc;
			}).collect(Collectors.toList());
		}

		crtPreReg.setApplyBy(dto.getIdNo());
		crtPreReg.setApplyDt(currDt);
		crtPreReg.setCreateId(dto.getIdNo());
		crtPreReg.setCreateDt(currDt);
		crtPreReg.setUpdateId(dto.getIdNo());
		crtPreReg.setUpdateDt(currDt);
		
		if (BaseUtil.isEquals(dto.getChannelMtdtCd(), ReferenceConstants.MTDT_CD_MOB_SELF)) {
			
			RefMetadata channelMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_REG_CHANNEL,
					ReferenceConstants.MTDT_CD_MOB_SELF);
			if (!BaseUtil.isObjNull(channelMtdt)) {
				crtPreReg.setChannelMtdtId(channelMtdt.getMtdtId());
			}
			
			// set type and category for mobile
			boolean nonMuslim = true;
			boolean nonBumi = false;
			
			RefMetadata religionMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_RELIGION,
					ReferenceConstants.MTDT_CD_MUSLIM);
			if (!BaseUtil.isObjNull(religionMtdt)) {
				if (religionMtdt.getMtdtId().equals(dto.getReligionMtdtId())) {
					nonMuslim = false;
				}
			}
			
			RefMetadata ethnicMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_ETHNIC,
					ReferenceConstants.MTDT_CD_NONBUMI);
			if (!BaseUtil.isObjNull(ethnicMtdt)) {
				if (ethnicMtdt.getMtdtId().equals(dto.getEthnicMtdtId())) {
					nonBumi = true;
				}
			}
			
			if (nonMuslim && nonBumi) {
				RefMetadata ahliBersekutuMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_MBR_TYPE,
						ReferenceConstants.MTDT_CD_CAT_ALLY);
				if (!BaseUtil.isObjNull(ahliBersekutuMtdt)) {
					// AHLI BERSEKUTU
					crtPreReg.setMemberTypeMtdtId(ahliBersekutuMtdt.getMtdtId());
				}
			} else {
				RefMetadata ahliBiasaMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_MBR_TYPE,
						ReferenceConstants.MTDT_CD_CAT_NRML);
				if (!BaseUtil.isObjNull(ahliBiasaMtdt)) {
					// AHLI BIASA
					crtPreReg.setMemberTypeMtdtId(ahliBiasaMtdt.getMtdtId());
				}
				
				RefMetadata genMale = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_GENDER, "M");
				RefMetadata genFemale = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_GENDER, "F");
				
				if (!BaseUtil.isObjNull(genMale) && !BaseUtil.isObjNull(genFemale)) {
					// to set Member Category
					if (dto.getGenderMtdtId().equals(genMale.getMtdtId())) {
						// armada
						new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
						Date firstDate = dto.getDob();
						Date secondDate = new Date();

						int age = Math.abs(secondDate.getYear() - firstDate.getYear());

						crtPreReg.setMemberCtrgyMtdtId(getCategoryByAge(age));

					}

					if (dto.getGenderMtdtId().equals(genFemale.getMtdtId())) {
						RefMetadata srikandi = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_MBR_CAT, "TYPE_SRI");
						if (!BaseUtil.isObjNull(srikandi)) {
							// srikandi
							crtPreReg.setMemberCtrgyMtdtId(srikandi.getMtdtId());
						}
					}					
				}
			}
		}
		
		crtPreReg = bePreRegSvc.create(crtPreReg, beTrxnDocumentsList);
		
		if (!BaseUtil.isObjNull(crtPreReg)) {
			Map<String, Object> map = new HashMap<>();
			map.put("url", messageService.getMessage(ConfigConstants.PORTAL_APP_URL) + "/self-registration");
			map.put("passcode", crtPreReg.getPasscode());
			
			if (!BaseUtil.isObjNull(crtPreReg.getContactNo())) {
				Notification notification = new Notification();
				notification.setNotifyTo(crtPreReg.getContactNo());
				notification.setMetaData(MailUtil.convertMapToJson(map));
				notification.setNotifyType(MailTypeEnum.SMS.getType());
				notification.setContent(crtPreReg.getIdNo());
				getNotifyService(request).addNotification(notification, MailTemplateConstants.PUBLIC_REG_RESULT_SMS);
			}
			
			if (!BaseUtil.isObjNull(crtPreReg.getEmail())) {
				Notification notification = new Notification();
				notification.setNotifyTo(crtPreReg.getEmail());
				notification.setMetaData(MailUtil.convertMapToJson(map));
				notification.setNotifyType(MailTypeEnum.MAIL.getType());
				notification.setContent(crtPreReg.getIdNo());
				getNotifyService(request).addNotification(notification, MailTemplateConstants.PUBLIC_REG_RESULT_EMAIL);
			}
			
		}
		
		return dozerMapper.map(crtPreReg, PreReg.class);
	}	
	
	public int getCategoryByAge(int age) {

		RefMetadata armada = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_MBR_CAT, "TYPE_ARMDA");
		RefMetadata lelaki35 = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_MBR_CAT, "TYPE_ALL");

		Integer category = null;
		if (!BaseUtil.isObjNull(armada) && !BaseUtil.isObjNull(lelaki35)) {
			if (age > 18 && age <= 35) {
				category = armada.getMtdtId();
			} else {
				category = lelaki35.getMtdtId();
			}
		}

		return category;
	}


	public static String convtRequstHash(String mercSecret, String mercId, String paymtRefno, Double amount,
			String respods) {
		LOGGER.info("===================================================");
		LOGGER.info("Request info");
		LOGGER.info("PARAMS mercSecret {}", mercSecret);
		LOGGER.info("PARAMS mercId {}", mercId);
		LOGGER.info("PARAMS paymtRefno {}", paymtRefno);
		LOGGER.info("PARAMS amount {}", amount);
		LOGGER.info("PARAMS respods {}", respods);
		LOGGER.info("==================================================");

		StringBuilder reqhashParam = new StringBuilder();
		StringBuilder amountBuilder = new StringBuilder();
		// Remove (.) value
		String ctamt = amount.toString();
		String[] splitamt = ctamt.split("\\.", 0);
		String leftdigit = splitamt[0];
		String rightdigt = splitamt[1];
		String contwithoutspaceamt = leftdigit + rightdigt;
		if (rightdigt.length() == 1) {
			rightdigt = rightdigt + '0';
		}
		amountBuilder.append(leftdigit).append(rightdigt);
		LOGGER.info("=====================================================");
		LOGGER.info("Convertion info");
		LOGGER.info("PARAMS paymtRefno {}", paymtRefno);
		LOGGER.info("PARAMS amount {}", amount);
		LOGGER.info("PARAMS respods {}", respods);
		LOGGER.info("Convert mercSecret {}", mercSecret);
		LOGGER.info("Convert mercId {}", mercId);
		LOGGER.info("Convert convtamt {}", contwithoutspaceamt);
		LOGGER.info("======================================================");

		if (!BaseUtil.isEquals(respods, "")) {

			reqhashParam.append(mercSecret).append(mercId).append(paymtRefno).append(contwithoutspaceamt)
					.append(respods);
		} else {
			reqhashParam.append(mercSecret).append(mercId).append(paymtRefno).append(contwithoutspaceamt);
		}
		String hashCal = DigestUtils.sha1Hex(reqhashParam.toString());
		LOGGER.info("calculated hash value " + hashCal);
		return hashCal;
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public PreReg updateP(@RequestBody PreReg dto, HttpServletRequest request) throws IOException {

		try {
			if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getTxnId())) {
				throw new BeException(BeErrorCodeEnum.E400C913);
			}
			if(BaseUtil.isObjNull(dto.getStatus())) {
				RefStatus refStatus = refStatusSvc.findByStatusCodeStatusType("BLK", "REG_STATUS");
				dto.setStatusId(refStatus.getStatusId());
			}else {
				Status status = dto.getStatus();
				dto.setStatusId(status.getStatusId());
			}
			bePreRegSvc.updatepreReg(dto);
			return dto; // dozerMapper.map(crtPreReg, PreReg.class);

		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	@PostMapping(value = BeUrlConstants.UPDATE_REJ, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public PreReg updateRejStatus(@RequestBody PreReg dto, HttpServletRequest request) throws IOException {

		LOGGER.info("remarks ===>" + dto.getApproveRemarks());
		String remarks = dto.getApproveRemarks();
		Integer positionId = dto.getPositionId();

		try {
			if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getTxnId())) {
				throw new BeException(BeErrorCodeEnum.E400C913);
			}
			dto.setApproveRemarks(remarks);

			RefStatus refStatus = null;
			if (dto.getStatusId() == 4) {
				refStatus = refStatusSvc.findByStatusCodeStatusType("REJ", "REG_STATUS");
			} else if (dto.getStatusId() == 12) {
				refStatus = refStatusSvc.findByStatusCodeStatusType("PEND_APRV", "REG_STATUS");
				dto.setHqInd(1);
			} else if (dto.getStatusId() == 13) {
				refStatus = refStatusSvc.findByStatusCodeStatusType("KIV", "REG_STATUS");
			}
			if (BaseUtil.isEquals("", remarks)) {
				dto.setApproveRemarks(refStatus.getStatusDesc());
			}
			dto.setStatusId(refStatus.getStatusId());

			dto.setPositionId(positionId);
			bePreRegSvc.updatepreRegRej(dto);

			if (!BaseUtil.isObjNull(dto)) {
				Notification notification = new Notification();
				Map<String, Object> map = new HashMap<>();
				String statusDesc = refStatus.getStatusDesc();
				map.put("statusDesc", statusDesc);
				map.put("remarks", dto.getApproveRemarks());
				map.put("fullName", dto.getFullName());
				map.put("idNo", dto.getIdNo());

				RefDivision refDivision = refDivisionSvc.findByDivisionCd(dto.getOrgDivisionCd());
				if (!BaseUtil.isObjNull(refDivision)) {
					map.put("divisionDesc", refDivision.getDivisionDesc());
				}

				RefBranch refBranch = refBranchSvc.findByBranchCd(dto.getOrgBranchCd());
				if (!BaseUtil.isObjNull(refBranch)) {
					map.put("branchDesc", refBranch.getBranchDesc());
				}

				// sms
				if (!BaseUtil.isObjNull(dto.getContactNo())) {
					notification.setNotifyTo(dto.getContactNo());
					notification.setMetaData(MailUtil.convertMapToJson(map));
					notification.setContent(dto.getIdNo());
					notification.setNotifyType(MailTypeEnum.SMS.getType());

					if (dto.getStatusId() == 4) {
						getNotifyService(request).addNotification(notification,
								MailTemplateConstants.MEMBER_REG_RESULT_SMS_REJECT);
					} else if (dto.getStatusId() == 12) {
						getNotifyService(request).addNotification(notification,
								MailTemplateConstants.MEMBER_REG_RESULT_SMS_VERIFY);
					}
				}

				// email
				if (!BaseUtil.isObjNull(dto.getEmail())) {
					notification.setNotifyTo(dto.getEmail());
					notification.setMetaData(MailUtil.convertMapToJson(map));
					notification.setContent(dto.getIdNo());
					notification.setNotifyType(MailTypeEnum.MAIL.getType());

					if (dto.getStatusId() == 4) {
						getNotifyService(request).addNotification(notification,
								MailTemplateConstants.MEMBER_REG_RESULT_EMAIL_REJECT);
					} else if (dto.getStatusId() == 12) {
						getNotifyService(request).addNotification(notification,
								MailTemplateConstants.MEMBER_REG_RESULT_EMAIL_VERIFY);
					}
				}

				// generate ackSlip
//				if (dto.getStatusId() == 12) {
//					LOGGER.info("try save acknowledment slip");
//					Report report = null;
//					Documents documents = null;
//					List<RefDocument> bpDoc = documentSvc
//							.findTrxnDocumentsByDocTrxnNo(FileUploadConstants.DOC_TRXN_SLIP_PENGAKUAN);
//					report = getReportService(request).report().genAcknowledgmentSlip(dto, ReportTypeEnum.PDF);
//					if (!BaseUtil.isObjNull(report.getReportBytes())) {
//						documents = trxnDocumentSvc.upload(bpDoc.get(0), report, dto.getDocRefNo(), request);
//						if (!BaseUtil.isObjNull(documents)) {
//							BeTrxnDocument trxnDocument = new BeTrxnDocument();
//							trxnDocument.setId(new BeTrxnDocumentPK(dto.getDocRefNo(), documents.getDocid(),
//									documents.getId()));
//							trxnDocument.setDocContentType(documents.getContentType());
//							trxnDocumentSvc.create(trxnDocument);
//						}
//					}
//				}
			}
			return dto; // dozerMapper.map(crtPreReg, PreReg.class);

		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BeException(BeErrorCodeEnum.E500C001);
		}

	}


	@PostMapping(value = BeUrlConstants.PUBLIC + BeUrlConstants.CREATE + BeUrlConstants.COMBINE, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public PreReg createPreRegPublicComb(@RequestBody PreReg dto, HttpServletRequest request) throws IOException {

		Payment pmtDto = dto.getPayment();
		if (BaseUtil.isObjNull(pmtDto) || BaseUtil.isListNull(pmtDto.getPaymentDtlList())) {
			throw new BeException(BeErrorCodeEnum.E400C006);
		}

		// check if id no valid for registration process, will throw
		// exception if not valid
		checkValidRegIdNo(dto.getIdNo());

		// check if contact no is exist or not
		BeConfig beConf = beConfigSvc.findByConfigCode(ConfigConstants.CONFIG_CONTACT_NO);
		if (BaseUtil.isEquals(beConf.getConfigVal(), "1")) {
			checkContactNo(dto.getContactNo());
		}

		// create registration
		BePreReg crtPreReg = dozerMapper.map(dto, BePreReg.class);
		String appRefNo = UidGenerator.generateUidYear("PRE");
		crtPreReg.setTxnId(UidGenerator.getMessageId());
		crtPreReg.setAppRefNo(appRefNo);
		crtPreReg.setPasscode(UidGenerator.generateRandomNoInStr());

		// String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();

		RefStatus refStatus = refStatusSvc.findByStatusCodeStatusType("PD", "REG_STATUS");
		crtPreReg.setStatusId(refStatus.getStatusId());
		if (!BaseUtil.isListNull(dto.getPreRegAddressList())) {

			Integer addressTypeMtdtId = null;
			if (BaseUtil.isEquals(dto.getChannelMtdtCd(), ReferenceConstants.MTDT_CD_MOB_SELF)) {
				RefMetadata addressTypeMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_ADDR_TYPE,
						ReferenceConstants.MTDT_CD_PRES);
				if (!BaseUtil.isObjNull(addressTypeMtdt)) {
					addressTypeMtdtId = addressTypeMtdt.getMtdtId();
				}
			}

			List<BePreRegAddress> preRegAddList = new ArrayList<>();
			for (PreRegAddress address : dto.getPreRegAddressList()) {
				BePreRegAddress preAdd = dozerMapper.map(address, BePreRegAddress.class);
				preAdd.setStatus(true);
				if (!BaseUtil.isObjNull(addressTypeMtdtId)) {
					preAdd.setAddressTypeMtdtId(addressTypeMtdtId);
				}
				preAdd.setCreateId(dto.getIdNo());
				preAdd.setCreateDt(currDt);
				preAdd.setUpdateId(dto.getIdNo());
				preAdd.setUpdateDt(currDt);
				preRegAddList.add(preAdd);
			}
			crtPreReg.addBePreRegAddressList(preRegAddList);
		}

		List<BeTrxnDocument> beTrxnDocumentsList = null;
		if (!BaseUtil.isListNull(dto.getTrxnDocumentList())) {
			String docRefNo = UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC);
			crtPreReg.setDocRefNo(docRefNo);
			beTrxnDocumentsList = dto.getTrxnDocumentList().stream().map(doc -> {
				BeTrxnDocumentPK docPk = new BeTrxnDocumentPK();
				docPk.setDocRefNo(docRefNo);
				docPk.setDocId(doc.getDocId());
				docPk.setDocMgtId(doc.getDocMgtId());
				BeTrxnDocument trxnDoc = new BeTrxnDocument(docPk, appRefNo, doc.getDocContentType());
				trxnDoc.setCreateId(dto.getIdNo());
				trxnDoc.setCreateDt(currDt);
				trxnDoc.setUpdateId(dto.getIdNo());
				trxnDoc.setUpdateDt(currDt);
				return trxnDoc;
			}).collect(Collectors.toList());
		}

		crtPreReg.setApplyBy(dto.getIdNo());
		crtPreReg.setApplyDt(currDt);
		crtPreReg.setCreateId(dto.getIdNo());
		crtPreReg.setCreateDt(currDt);
		crtPreReg.setUpdateId(dto.getIdNo());
		crtPreReg.setUpdateDt(currDt);

		// create payment (pre payment)
		BePayment crtPayment = dozerMapper.map(pmtDto, BePayment.class);
		String pmtRefNo = UidGenerator.generateUidYear("PMT");
		crtPayment.setTxnId(UidGenerator.getMessageId());
		crtPayment.setPmtRefNo(pmtRefNo);

		refStatus = refStatusSvc.findByStatusCodeStatusType("PEND", "PMT_STATUS");
		crtPayment.setStatusId(refStatus.getStatusId());
		crtPayment.setPmtBy(dto.getIdNo());
		crtPayment.setPmtDt(currDt);
		crtPayment.setStatusId(6);
		crtPayment.setCreateId(dto.getIdNo());
		crtPayment.setCreateDt(currDt);
		crtPayment.setUpdateId(dto.getIdNo());
		crtPayment.setUpdateDt(currDt);

		if (BaseUtil.isEquals(dto.getChannelMtdtCd(), ReferenceConstants.MTDT_CD_MOB_SELF)) {
			BeConfig beConfig = beConfigSvc.findByConfigCode(ConfigConstants.PAYMENT_BATCH_ID);
			if (!BaseUtil.isObjNull(beConfig)) {
				crtPayment.setBatchId(BaseUtil.getInt(beConfig.getConfigVal()));
			}

			RefMetadata pmtTypeMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_PMT_TYPE,
					ReferenceConstants.MTDT_CD_PMT_CC);
			if (!BaseUtil.isObjNull(pmtTypeMtdt)) {
				crtPayment.setPmtTypeMtdtId(pmtTypeMtdt.getMtdtId());
			}

			RefMetadata channelMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_REG_CHANNEL,
					ReferenceConstants.MTDT_CD_MOB_SELF);
			if (!BaseUtil.isObjNull(channelMtdt)) {
				crtPreReg.setChannelMtdtId(channelMtdt.getMtdtId());
				crtPayment.setChannelMtdtId(channelMtdt.getMtdtId());
			}
		}

		crtPreReg = bePreRegSvc.createPublic(crtPreReg, beTrxnDocumentsList, crtPayment, pmtDto.getPaymentDtlList());

		Map<String, Object> map = new HashMap<>();
		map.put("url", messageService.getMessage(ConfigConstants.PORTAL_APP_URL) + "/self-registration");
		map.put("passcode", crtPreReg.getPasscode());
		// sms
		if (!BaseUtil.isObjNull(crtPreReg.getContactNo())) {
			Notification notification = new Notification();
			notification.setNotifyTo(crtPreReg.getContactNo());
			notification.setMetaData(MailUtil.convertMapToJson(map));
			notification.setNotifyType(MailTypeEnum.SMS.getType());
			notification.setContent(crtPreReg.getIdNo());
			getNotifyService(request).addNotification(notification, MailTemplateConstants.PUBLIC_REG_RESULT_SMS);
		}

		// email
		if (!BaseUtil.isObjNull(crtPreReg.getEmail())) {
			Notification notification = new Notification();
			notification.setNotifyTo(crtPreReg.getEmail());
			notification.setMetaData(MailUtil.convertMapToJson(map));
			notification.setNotifyType(MailTypeEnum.MAIL.getType());
			notification.setContent(crtPreReg.getIdNo());
			getNotifyService(request).addNotification(notification, MailTemplateConstants.PUBLIC_REG_RESULT_EMAIL);
		}

		// fcm
		sendFcmNotification(crtPreReg.getIdNo(), crtPreReg.getIdNo(), map,
				MailTemplateConstants.PUBLIC_REG_RESULT_FCM, request);

		PreReg preRegPub = dozerMapper.map(crtPreReg, PreReg.class);

		return preRegPub;
	}


	@PostMapping(value = BeUrlConstants.ACK_SLIP)
	public AckSlip searchAcknowledgementSlip(@RequestBody PreReg dto, HttpServletRequest request) throws IOException {

		AckSlip ackSlip = new AckSlip();
		// PRE_REG_ID, TXN_ID, APP_REF_NO, PASSCODE
		PreReg preReg = bePreRegSvc.search(dto);

		if (BaseUtil.isObjNull(preReg)) {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}

		ackSlip.setFullName(preReg.getFullName());
		ackSlip.setIdNo(preReg.getIdNo());
		ackSlip.setOrgDivisionCd(preReg.getOrgDivisionCd());
		RefDivision refDivision = refDivisionSvc.findByDivisionCd(preReg.getOrgDivisionCd());
		if (!BaseUtil.isObjNull(refDivision)) {
			ackSlip.setOrgDivisionDesc(refDivision.getDivisionDesc());
		}

		ackSlip.setOrgBranchCd(preReg.getOrgBranchCd());
		RefBranch refBranch = refBranchSvc.findByBranchCd(preReg.getOrgBranchCd());
		if (!BaseUtil.isObjNull(refBranch)) {
			ackSlip.setOrgBranchDesc(refBranch.getBranchDesc());
		}

		if (!BaseUtil.isObjNull(preReg.getPreRegAddressList())) {
			PreRegAddress preRegAddress = preReg.getPreRegAddressList().get(0);
			ackSlip.setAddress1(preRegAddress.getAddress1());
			ackSlip.setAddress2(preRegAddress.getAddress2());
			ackSlip.setAddress3(preRegAddress.getAddress3());
			ackSlip.setPostcode(preRegAddress.getPostcode());
			ackSlip.setCityCd(preRegAddress.getCityCd());
			ackSlip.setStateCd(preRegAddress.getStateCd());
			ackSlip.setCountryCd(preRegAddress.getCountryCd());

		}

		PaymentDtl paymentDtl = bePaymentDtlSvc.searchDtl(String.valueOf(preReg.getPreRegId()));

		if (!BaseUtil.isObjNull(paymentDtl)) {
			ackSlip.setTotalAmount(paymentDtl.getItemAmount());
		}

		return ackSlip;
	}
	
	private SenangPayResponds getRequestQuery(Payment payment, HttpServletRequest request) throws Exception {
		SenangPayResponds  respds = new SenangPayResponds();
		if(!BaseUtil.isStringNull(payment.getPmtRefNo())) {
			//SET PARAMS TO SENANGPAY ENQUERY
			 
			// GET MERCHANT ID
			BeConfig merchId = beConfigSvc.findByConfigCode(ConfigConstants.SENANGPAY_MERCHANT_ID);
			String merchnatId = merchId.getConfigVal();
			BeConfig segSecrt = beConfigSvc.findByConfigCode(ConfigConstants.SENANGPAY_SECRET);
			String secret = segSecrt.getConfigVal();
			String order_id = payment.getPmtRefNo();
			// GET KIPLE URL
			//RefMetadata klpUrl = refMetadataService.findByMtdtId(55);
			StringBuilder reqhashParam = new StringBuilder();
			reqhashParam.append(merchnatId).append(secret).append(order_id);
			String hashCal = DigestUtils.md5Hex(reqhashParam.toString());
			
			Map<String, String> params = new HashMap<String, String>();
			params.put("order_id", order_id);
			params.put("merchant_id", merchnatId);
			params.put("hash", hashCal);
			BeConfig enqUrl = beConfigSvc.findByConfigCode(ConfigConstants.SENANGPAY_ENQUERY_URL);
			String url = enqUrl.getConfigVal();
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
			for (Map.Entry<String, String> entry : params.entrySet()) {
			    builder.queryParam(entry.getKey(), entry.getValue());
			}
			System.out.println("builder==>"+builder.toUriString());
			RestTemplate restTemplate = new RestTemplate();
			String getjson = restTemplate.getForObject(builder.toUriString(), String.class);
			ObjectMapper objectMapper = new ObjectMapper();
			respds = objectMapper.readValue(getjson, SenangPayResponds.class);
 
			// UPDATE PAYMENT TABLE TO STATUS
			if(!BaseUtil.isObjNull(respds)) {
				paymentUpdate(payment, request);
			}
		}
		return respds;	
	}
	
	public Payment paymentUpdate(Payment dto, HttpServletRequest request) throws IOException {

		//BePayment bePayment = dozerMapper.map(dto, BePayment.class);
		BePayment bePayment = bePaymentSvc.find(dto.getPmtId());

		if (BaseUtil.isObjNull(bePayment)) {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}
		String statusCd = "FAILED";
		RefStatus pmtRefStatus = refStatusSvc.findByStatusCodeStatusType(statusCd, "PMT_STATUS");
		RefStatus preRefStatus = refStatusSvc.findByStatusCodeStatusType(statusCd, "REG_STATUS");

		String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();
 		bePayment.setStatusId(pmtRefStatus.getStatusId());
		bePayment.setPmtGwDt(currDt);
		bePayment.setUpdateId(userId);
		bePayment.setUpdateDt(currDt);
 
		List<Integer> preRegList = null;
		List<BeMemberProfile> beMemberProfileList = null;
		List<BePreReg> bePreRegs = new ArrayList<>();
		RefMetadata channelMtdt = new RefMetadata();
		if(BaseUtil.isEqualsCaseIgnore("FAILED", pmtRefStatus.getStatusCd())) {
			preRegList = bePayment.getPaymentDtlList().stream().map(paymentDtl -> {
				return BaseUtil.getInt(paymentDtl.getItemId());
			}).collect(Collectors.toList());

			PreReg preReg = new PreReg();
			preReg.setPreRegIdList(preRegList);
			List<BePreReg> bePreRegList = bePreRegSvc.searchBePreReg(preReg);
			if (BaseUtil.isListNull(bePreRegList)) {
				throw new BeException(BeErrorCodeEnum.E500C002);
			}

			channelMtdt = refMetadataSvc.find(bePayment.getChannelMtdtId());
			if (BaseUtil.isObjNull(channelMtdt)) {
				throw new BeException(BeErrorCodeEnum.E500C002);
			}
  
			for (BePreReg bePreReg : bePreRegList) {
				String Status = bePreReg.getStatusId().toString();
				if(BaseUtil.isEquals(Status, "1") || BaseUtil.isEquals(Status, "8")) {
					bePreReg.setStatus(new RefStatus());
					bePreReg.getStatus().setStatusId(preRefStatus.getStatusId());
					bePreReg.setStatusId(preRefStatus.getStatusId());	 
					bePreRegs.add(bePreReg);
				}
			}
		}
			return bePaymentSvc.updatePostPayment2(bePayment, preRefStatus.getStatusId(), beMemberProfileList, bePreRegs);
	}
	 
	
}
