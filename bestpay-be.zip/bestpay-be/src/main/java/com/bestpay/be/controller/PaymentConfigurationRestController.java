/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwConfig;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.PaymentConfig;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;


/**
 * @author Atiqah Khairuddin
 * @since Aug 22, 2019
 */
@RestController
@RequestMapping(BeUrlConstants.PAYMENT_CONFIG)
public class PaymentConfigurationRestController extends AbstractRestController {

	String skipValues = "[-+.^:,()*@/]";


	@PostMapping(value = BeUrlConstants.PAGINATED, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<PaymentConfig> searchPayConfigPaginated(@Valid @RequestBody PaymentConfig paymentConfig,
			HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwConfig> result = pgwConfigSvc.searchPgwConfigByPagination(paymentConfig, dataTableInRQ);
		DataTableResults<PaymentConfig> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			dataTableInResp.setDraw(result.getDraw());
			dataTableInResp.setError(result.getError());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<PaymentConfig> chLst = new ArrayList<>();
				for (PgwConfig bbp : result.getData()) {
					PaymentConfig chnl = dozerMapper.map(bbp, PaymentConfig.class);
					chLst.add(chnl);
				}
				dataTableInResp.setData(chLst);
			}
		}
		return dataTableInResp;
	}


	@PostMapping(value = BeUrlConstants.CREATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public PaymentConfig create(@Valid @RequestBody PaymentConfig paymentConfig, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		if (paymentConfig == null) {// restriction null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}

		PgwConfig pgwConfig = new PgwConfig();
		PgwConfig pgwConfigure = super.pgwConfigSvc.findPgwConfigById(paymentConfig.getId());

		if (paymentConfig.getId() == null) {
			pgwConfig.setConfigCode(paymentConfig.getConfigCode());
			pgwConfig.setConfigDesc(paymentConfig.getConfigDesc());
			pgwConfig.setConfigVal(paymentConfig.getConfigVal());
			pgwConfig.setCreateId(paymentConfig.getCreateId());
			super.pgwConfigSvc.create(pgwConfig);
		} else {
			pgwConfigure.setConfigCode(paymentConfig.getConfigCode());
			pgwConfigure.setConfigDesc(paymentConfig.getConfigDesc());
			pgwConfigure.setConfigVal(paymentConfig.getConfigVal());
			pgwConfigure.setCreateId(paymentConfig.getCreateId());
			super.pgwConfigSvc.update(pgwConfigure);
		}

		PaymentConfig restr = new PaymentConfig();
		PgwConfig pgwConfiguration = super.pgwConfigSvc.findPgwConfigById(pgwConfig.getId());
		if (!BaseUtil.isObjNull(pgwConfiguration)) {
			restr = dozerMapper.map(pgwConfiguration, PaymentConfig.class);
		}
		return restr;
	}


	@GetMapping(value = BeUrlConstants.GET_PAYMENT_CONFIG + "/{id}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public PaymentConfig getPaymentConfigById(@PathVariable Integer id, HttpServletRequest request)
			throws BeException {
		if (id == null) {
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		PgwConfig pgwConfig = super.pgwConfigSvc.findPgwConfigById(id);
		return dozerMapper.map(pgwConfig, PaymentConfig.class);
	}

}
