package com.bestid.web.idm.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bestid.web.util.constants.PageConstants;
import com.bestid.web.util.constants.PageTemplate;


@Controller
@RequestMapping(value = PageConstants.PAGE_HOME)
public class HomeController {

	@GetMapping()
	public ModelAndView home() {
		return new ModelAndView(PageTemplate.IDM_HOME);
	}

}
