package com.bestpay.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * The persistent class for the REF_COUNTRY database table.
 *
 * @author Mohana Vamsi
 * @since Feb 22, 2018
 */
@Entity
@Table(name = "REF_BANK")
public class RefBank extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -6510355585641387606L;

	@Id
	@Column(name = "BANK_ID")
	private Integer bankId;

	@Column(name = "BANK_CODE")
	private String bankCode;

	@Column(name = "BANK_NAME")
	private String bankName;

	@Column(name = "DISPLAY_NAME")
	private String displayName;

	@Column(name = "FEE")
	private Integer fee;

	@Column(name = "LOGO")
	private String logo;

	@Column(name = "TYPE")
	private String type;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getBankId() {
		return bankId;
	}


	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}


	public String getBankCode() {
		return bankCode;
	}


	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getDisplayName() {
		return displayName;
	}


	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}


	public Integer getFee() {
		return fee;
	}


	public void setFee(Integer fee) {
		this.fee = fee;
	}


	public String getLogo() {
		return logo;
	}


	public void setLogo(String logo) {
		this.logo = logo;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	@Override
	public String getCreateId() {
		return null;
	}


	@Override
	public void setCreateId(String createId) {
		// expect return nothing
	}


	@Override
	public Timestamp getCreateDt() {
		return null;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		// expect return nothing
	}


	@Override
	public String getUpdateId() {
		return null;
	}


	@Override
	public void setUpdateId(String updateId) {
		// expect return nothing
	}


	@Override
	public Timestamp getUpdateDt() {
		return null;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		// expect return nothing
	}

}