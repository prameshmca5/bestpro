/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.controller;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerCompBankDetails;
import com.bestpay.be.sdk.model.MerCompany;
import com.bestpay.be.sdk.model.MerPayPageSet;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwMerchantBeneficiary;
import com.bestpay.pgw.model.PgwMerchantCompanyBankDetails;
import com.bestpay.pgw.model.PgwMerchantPid;
import com.bestpay.pgw.model.RefCity;
import com.bestpay.pgw.model.RefCountry;
import com.bestpay.pgw.model.RefPaymentType;
import com.bestpay.pgw.model.RefState;
import com.bestpay.pgw.model.RefStatus;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.incentiveremit.model.RegisterBeneficiaryRequest;
import com.bestpay.pgw.sdk.incentiveremit.model.RegisterBeneficiaryResult;
import com.bestpay.pgw.sdk.incentiveremit.model.RegisterCustomerRequest;
import com.bestpay.pgw.sdk.incentiveremit.model.RegisterCustomerResult;
import com.bestpay.pgw.sdk.model.ApsProfile;
import com.bestpay.pgw.sdk.model.ApsProfileResponse;
import com.bestpay.pgw.sdk.model.BeneficiaryAccount;
import com.bestpay.pgw.sdk.model.BeneficiaryDetail;
import com.bestpay.pgw.sdk.model.Country;
import com.bestpay.pgw.sdk.model.CustomerDetail;
import com.bestpay.pgw.sdk.model.IRProfile;
import com.bestpay.pgw.sdk.model.IRProfileResponse;
import com.bestpay.pgw.sdk.model.PaymentType;
import com.bestpay.pgw.sdk.model.Status;
import com.bestpay.pgw.service.CountryService;
import com.bestpay.pgw.service.PgwMerchantPidService;
import com.bestpay.pgw.service.PgwTransactionService;
import com.bestpay.pgw.service.RefCityService;
import com.bestpay.pgw.service.RefPaymentTypeService;
import com.bestpay.pgw.service.RefStateService;
import com.bestpay.pgw.service.RefStatusService;
import com.bstsb.util.DateUtil;
import com.bstsb.util.constants.BaseConstants;


/**
 * @author Ilhomjon
 * @since Feb 22, 2018
 */
@RestController
public class CommonRestController extends AbstractRestController {

	private static final Logger logger = LoggerFactory.getLogger(MaxMoneyRestController.class);

	@Autowired
	private CountryService countryService;

	@Autowired
	private RefPaymentTypeService paymentTypeService;

	@Autowired
	private RefStatusService refStatusSvc;

	@Autowired
	protected MaxMoneyRestController maxMoneyRestController;

	@Autowired
	protected PgwTransactionService pgwTransactionService;

	@Autowired
	protected PgwMerchantPidService pgwMerchantPidService;

	@Autowired
	protected IncentiveRemitRestController incentiveRemitRestController;

	@Autowired
	protected RefStateService refStateService;

	@Autowired
	protected RefCityService refCityService;

	private static final String MALAYSIA = "MALAYSIA";


	@GetMapping(value = PgwUrlConstants.COUNTRIES, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<Country> getCountryList(HttpServletRequest request) {
		List<Country> resList = new ArrayList<>();
		List<RefCountry> countryList = countryService.allCountries();

		for (RefCountry cnt : countryList) {
			Country country = dozerMapper.map(cnt, Country.class);
			resList.add(country);
		}
		return resList;
	}


	@GetMapping(value = PgwUrlConstants.REF_PAYMENT_TYPES, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<PaymentType> getRefPaymentTypes(HttpServletRequest request) {
		List<PaymentType> resList = new ArrayList<>();
		List<RefPaymentType> paymentTypeList = paymentTypeService.getAllPaymentTypes();

		PaymentType paymentType;
		for (RefPaymentType cnt : paymentTypeList) {
			paymentType = dozerMapper.map(cnt, PaymentType.class);
			resList.add(paymentType);
		}
		return resList;
	}


	@GetMapping(value = PgwUrlConstants.REF_PAYMENT_STATUS_CODE, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Status> getRefStatusLst() {
		List<RefStatus> refStatusLst = refStatusSvc.primaryDao().findAll();
		List<Status> refStatSdk = new ArrayList<>();
		for (RefStatus r : refStatusLst) {
			refStatSdk.add(dozerMapper.map(r, Status.class));
		}
		return refStatSdk;
	}


	@GetMapping(value = PgwUrlConstants.REF_PAYMENT_STATUS_CODE + "/nextItem", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public Status getRefStatusLst(@RequestParam String statuscode) {
		List<RefStatus> refStatusLst = refStatusSvc.primaryDao().findAll();
		Status refStatSdk = new Status();
		boolean controller = false;
		for (RefStatus r : refStatusLst) {
			if (controller) {
				refStatSdk = dozerMapper.map(r, Status.class);
				controller = false;
			}
			if (r.getStatusCode().equals(statuscode)) {
				controller = true;
			}
		}
		return refStatSdk;
	}


	@PostMapping(value = "/saveApsProfile", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public ApsProfileResponse saveApsProfile(@RequestBody ApsProfile apsProfile, HttpServletRequest request,
			HttpServletResponse response) throws BeException {
		logger.info("In saveApsProfile method .............");
		com.bestpay.be.sdk.model.ApsProfile beApsProfile = dozerMapper.map(apsProfile,
				com.bestpay.be.sdk.model.ApsProfile.class);
		com.bestpay.be.sdk.model.ApsProfileResponse beApsProfileResponse = getBeService()
				.saveApsProfile(beApsProfile);
		logger.info("Successfully created merchant: merchantId: {}", beApsProfileResponse.getMerchantId());
		MerCompany merCompany = getBeService().getMerchantCompanyByCompanyId(beApsProfile.getCompanyReferenceId());
		MerCompBankDetails merCompBankDetails = getBeService()
				.getCompRefBankDetailsByCompRefId(beApsProfile.getCompanyReferenceId());
		BeneficiaryDetail beneficiaryDetail = maxMoneyRestController.createBeneficiary(merCompany.getCompanyName(),
				merCompany.getAddress1(), merCompany.getCountry(), null, merCompany.getPhone(),
				merCompany.getEmail(), merCompany.getPicName());
		logger.info(" Benefeciary details have been created in MaxMoney Id: {} ", beneficiaryDetail.getId());
		beApsProfile.setBeneficiaryId(beneficiaryDetail.getId());
		PgwMerchantBeneficiary merchantBeneficiary = new PgwMerchantBeneficiary();
		merchantBeneficiary.setMerchantId(beApsProfileResponse.getMerchantId());
		merchantBeneficiary.setBenefeciaryId(beneficiaryDetail.getId());
		pgwMerchantBeneficiaryService.create(merchantBeneficiary);

		BeneficiaryAccount beneficiaryAccount = maxMoneyRestController.createBeneficiaryAccount(
				beneficiaryDetail.getId(), merCompBankDetails.getBankAccNo(), merCompBankDetails.getBankAccName(),
				merCompany.getCompanyName(), merCompBankDetails.getBankBranch(),
				merCompBankDetails.getBankLocation(), merCompBankDetails.getBankCountry(),
				merCompBankDetails.getBankName());

		logger.info(" BeneficiaryAccount has been registered in MaxMoney, UserId:  {} ", beneficiaryAccount.getId());
		CustomerDetail customerDetail = maxMoneyRestController.customerRegistration(beApsProfile);
		logger.info(" Customer has been registered in MaxMoney {} ", customerDetail.getCustomerName());
		return dozerMapper.map(beApsProfileResponse, ApsProfileResponse.class);

	}


	@PostMapping(value = "/saveIRProfile", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public IRProfileResponse saveIRProfile(@RequestBody IRProfile irProfile, HttpServletRequest request,
			HttpServletResponse response) throws BeException {
		logger.info("In saveIRProfile method .............");
		IRProfileResponse irProfileResponse = new IRProfileResponse();
		MerCompany merCompany = getBeService().getMerchantCompanyByCompanyId(irProfile.getCompanyReferenceId());
		List<PgwMerchantCompanyBankDetails> merCompBankDetailsList = pgwMerchantCompanyBankDetailsService.searchBeneficiaryByCompRefId(merCompany.getCompRefId());
		getBeService().getCompRefBankDetailsByCompRefId(irProfile.getCompanyReferenceId());
		irProfile.setOwnerName(parseName(irProfile.getOwnerName()));
		irProfile.setApsName(parseName(irProfile.getApsName()));
		RegisterCustomerRequest registerCustomerRequest = new RegisterCustomerRequest();
		String[] names = {" "," "};
		if(irProfile.getOwnerName()!=null) {
			String name = irProfile.getOwnerName();
			names = name.split(" ");
		}
		String senderFirstName = "";
		String senderMiddleName = "";
		String senderLastName = "";
		if (names != null && names.length > 0) {
			senderFirstName = names[0];
			if (names.length == 2) {
				senderLastName = senderLastName.concat(names[1]);
			}
			if (names.length >= 3) {
				senderMiddleName = senderMiddleName.concat(names[1]);
				for(int j=2;j<=names.length-1;j++) {
					senderLastName = senderLastName.concat(names[j])+" ";
				}
			}
		}
		registerCustomerRequest.setSenderFirstName(senderFirstName);
		registerCustomerRequest.setSenderMiddleName(senderMiddleName);
		registerCustomerRequest.setSenderLastName(senderLastName);
		String senderGender = "";
		int lastDigit = Character.getNumericValue(
				irProfile.getOwnerNationalId().charAt(irProfile.getOwnerNationalId().length() - 1));
		if (lastDigit % 2 == 0) {
			senderGender = "FEMALE";
		} else {
			senderGender = "MALE";
		}
		registerCustomerRequest.setSenderGender(senderGender);
		registerCustomerRequest.setSenderAddress(irProfile.getOwnerAddress().toUpperCase());
		registerCustomerRequest.setSenderCity(getCityDescription(irProfile.getOwnerCity()));
		registerCustomerRequest.setSenderState(getStateDescription(irProfile.getOwnerState()));
		registerCustomerRequest.setSenderCountry(MALAYSIA);
		registerCustomerRequest.setSenderZipCode(irProfile.getOwnerPostCode());
		String ownerPhoneNo = irProfile.getOwnerPhoneNo();
		if (irProfile.getOwnerPhoneNo() != null && irProfile.getOwnerPhoneNo().substring(0, 2).equals("+6")) {
			ownerPhoneNo = irProfile.getOwnerPhoneNo().substring(2);
		}
		registerCustomerRequest.setSenderMobile(ownerPhoneNo);
		registerCustomerRequest.setSenderIDType("NRIC");
		registerCustomerRequest.setSenderIDNumber(irProfile.getOwnerNationalId());
		registerCustomerRequest.setIdIssuePlace(MALAYSIA);
		registerCustomerRequest.setIdIssueDate(DateUtil.convertDate(new Date(), BaseConstants.DT_YYYY_MM_DD_DASH));
		Calendar c = Calendar.getInstance();
		c.add(Calendar.YEAR, 20);
		Date idExpireDate = c.getTime();
		registerCustomerRequest.setIdExpireDate(DateUtil.convertDate(idExpireDate, BaseConstants.DT_YYYY_MM_DD_DASH));
		registerCustomerRequest.setSenderNativeCountry(MALAYSIA);
		Date senderDateOfBirth = DateUtil.convertStrDateToDate(irProfile.getOwnerNationalId().substring(0, 6),
				"yyMMdd");
		registerCustomerRequest
				.setSenderDateOfBirth(DateUtil.convertDate(senderDateOfBirth, BaseConstants.DT_YYYY_MM_DD_DASH));
		registerCustomerRequest.setSenderOccupation("SELF EMPLOYED AND BUSINESS");
		registerCustomerRequest.setSenderEmployerName(irProfile.getApsName());
		registerCustomerRequest.setSenderEmployerType("AGENCY SERVICE");
		registerCustomerRequest.setSenderFundSource("BUSINESS INCOME");
		registerCustomerRequest.setSenderPhoto(irProfile.getSenderPhoto());
		if (irProfile.getSenderPhoto1() != null) {
			registerCustomerRequest.setSenderPhoto1(irProfile.getSenderPhoto1());
		}
		RegisterCustomerResult registerCustomerResult = incentiveRemitRestController
				.registerCustomer(registerCustomerRequest);
		if (registerCustomerResult.getCode().equals("0")) {
			logger.info("Registerd Customer successfully. SenderCustomerId: {} ",
					registerCustomerResult.getSenderCustomerId());
			PgwMerchantPid pgwMerchantPid = pgwMerchantPidService
					.findByMerchantMaxmoneyPidByPid(registerCustomerResult.getSenderCustomerId());
			if (pgwMerchantPid != null) {
				irProfileResponse.setMerchantId(pgwMerchantPid.getMerchantId());
				MerPayPageSet merPayPageSet = getBeService().getMerPayPageSetById(pgwMerchantPid.getMerchantId());
				irProfileResponse.setVerifyKey(merPayPageSet.getVerifyKey());
				irProfileResponse.setMessage("Customer is already registered");
				return irProfileResponse;
			}
			PgwMerchantCompanyBankDetails merCompBankDetails = new PgwMerchantCompanyBankDetails();
			if(!BaseUtil.isListZero(merCompBankDetailsList)) {
				merCompBankDetails = merCompBankDetailsList.get(0);
			}
			RegisterBeneficiaryRequest registerBeneficiaryRequest = new RegisterBeneficiaryRequest();
			registerBeneficiaryRequest.setSenderCustomerId(registerCustomerResult.getSenderCustomerId());
			String beneficiaryFirstName = "";
			String beneficiaryMiddleName = "";
			String beneficiaryLastName = "";
			String[] benNames = merCompany.getCompanyName().split(" ");
			StringBuilder bld = new StringBuilder();
			if (benNames != null && benNames.length >= 2) {
				beneficiaryLastName = benNames[benNames.length - 1];
				for (int i = 0; i < benNames.length - 1; i++) {
					bld.append(benNames[i] + " ");
				}
				beneficiaryFirstName = parseName(bld.toString());
			}
			registerBeneficiaryRequest.setFirstName(beneficiaryFirstName);
			registerBeneficiaryRequest.setMiddleName(beneficiaryMiddleName);
			registerBeneficiaryRequest.setLastName(beneficiaryLastName);
			registerBeneficiaryRequest.setAddress(merCompany.getAddress1());
			registerBeneficiaryRequest.setCity(merCompany.getCity());
			registerBeneficiaryRequest.setCountry(merCompBankDetails.getBankCountry());
			String merchantPhone = merCompany.getPhone();
			if (merCompany.getPhone() != null && merCompany.getPhone().substring(0, 2).equals("+6")) {
				merchantPhone = merCompany.getPhone().substring(2);
			}
			registerBeneficiaryRequest.setMobile(merchantPhone);
			registerBeneficiaryRequest.setEmail(merCompany.getEmail());
			registerBeneficiaryRequest.setRelationShip(merCompany.getRelationship());
			RegisterBeneficiaryResult registerBeneficiaryResult = incentiveRemitRestController
					.registerBeneficiary(registerBeneficiaryRequest);
			if (registerBeneficiaryResult.getCode().equals("0")) {
				logger.info("RegisterBeneficiary is successful, BeneficiarySno: {}",
						registerBeneficiaryResult.getBeneficiarySno());
				com.bestpay.be.sdk.model.IRProfile beIRProfile = dozerMapper.map(irProfile,
						com.bestpay.be.sdk.model.IRProfile.class);
				com.bestpay.be.sdk.model.IRProfileResponse beIRProfileResponse = getBeService()
						.saveIRProfile(beIRProfile);
				logger.info("Successfully created merchant: merchantId: {}", beIRProfileResponse.getMerchantId());
				beIRProfileResponse.setMessage(" Customer registration successful ");
				PgwMerchantBeneficiary merchantBeneficiary = new PgwMerchantBeneficiary();
				merchantBeneficiary.setMerchantId(beIRProfileResponse.getMerchantId());
				merchantBeneficiary.setMtoId("INCENTIVE_REMIT");
				merchantBeneficiary.setBenefeciaryId(registerBeneficiaryResult.getBeneficiarySno());
				pgwMerchantBeneficiaryService.create(merchantBeneficiary);
				
				pgwMerchantPid = new PgwMerchantPid();
				pgwMerchantPid.setMerchantId(beIRProfileResponse.getMerchantId());
				pgwMerchantPid.setMtoId("INCENTIVE_REMIT");
				pgwMerchantPid.setPid(registerCustomerResult.getSenderCustomerId());
				pgwMerchantPidService.create(pgwMerchantPid);
				logger.info("SenderCustomerId saved into MerchantPid.. ");
				return dozerMapper.map(beIRProfileResponse, IRProfileResponse.class);
			} else {
				logger.info("RegisterBeneficiary failed Msg: {} {}", registerBeneficiaryResult.getCode(),
						registerBeneficiaryResult.getMessage());
				irProfileResponse.setMessage(" RegisterBeneficiary failed Msg: "
						+ registerBeneficiaryResult.getCode() + " " + registerBeneficiaryResult.getMessage());
			}
		} else {
			logger.info("RegisterCustomer failed Msg: {} {}", registerCustomerResult.getCode(),
					registerCustomerResult.getMessage());
			irProfileResponse.setMessage(" RegisterCustomer failed Msg: " + registerCustomerResult.getCode() + " "
					+ registerCustomerResult.getMessage());
		}

		return irProfileResponse;

	}


	@PostMapping(value = PgwUrlConstants.UPD_CUSTOMER, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public CustomerDetail updateCustomer(@RequestBody ApsProfile apsProfile, HttpServletRequest request,
			HttpServletResponse response) {

		return maxMoneyRestController.updateCustomer(apsProfile);
	}


	private String getStateDescription(String stateCode) {
		RefState refState = refStateService.findByStateCode(stateCode);
		if (refState != null) {
			return refState.getStateDesc();
		}
		return null;
	}


	private String getCityDescription(String cityCode) {
		RefCity refCity = refCityService.findByCityCode(cityCode);
		if (refCity != null) {
			return refCity.getDescEn();
		}
		return null;
	}
	
	private String parseName(String name) {
		StringBuilder sb = new StringBuilder();
		if(name!=null) {
			sb = new StringBuilder(name);
			for(int i=0;i<sb.length();) {
				if(!Character.isAlphabetic(sb.charAt(i)) && !Character.isWhitespace(sb.charAt(i))){
					sb.deleteCharAt(i);
				}else {i++;}
			}
		}
		return sb.toString();
	}

}