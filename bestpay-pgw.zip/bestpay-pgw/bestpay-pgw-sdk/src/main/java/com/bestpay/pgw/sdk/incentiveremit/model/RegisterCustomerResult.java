package com.bestpay.pgw.sdk.incentiveremit.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "RegisterCustomerResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class RegisterCustomerResult {

	@XmlElement(name = "CODE")
	private String code;

	@XmlElement(name = "MESSAGE")
	private String message;

	@XmlElement(name = "SenderCustomerID")
	private String senderCustomerId;


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public String getSenderCustomerId() {
		return senderCustomerId;
	}


	public void setSenderCustomerId(String senderCustomerId) {
		this.senderCustomerId = senderCustomerId;
	}

}
