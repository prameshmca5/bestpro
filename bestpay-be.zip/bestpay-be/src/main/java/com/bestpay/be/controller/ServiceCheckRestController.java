/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.config.ConfigConstants;
import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.model.ServiceCheck;
import com.bestpay.be.sdk.util.BaseUtil;

/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
@RestController
@RequestMapping(BeUrlConstants.SERVICE_CHECK)
public class ServiceCheckRestController extends AbstractRestController {

	@Autowired
	DataSource dataSource;

	private static final String SERVICE_NAME = "SST Service";

	private static final String SUCCESS = "SUCCESS";

	private static final String FAILED = "FAILED";

	@GetMapping(consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ServiceCheck serviceCheck(HttpServletRequest request) {
		StringBuffer url = request.getRequestURL();
		String uri = request.getRequestURI();
		ServiceCheck svcTest = new ServiceCheck(SERVICE_NAME, url.substring(0, url.indexOf(uri)), SUCCESS);

		// CACHE CONNECTION

		// DB CONNECTION
		String mysqlUrl = messageSource.getMessage(ConfigConstants.DB_CONF_URL, null, Locale.getDefault());
		try {
			if (!BaseUtil.isObjNull(dataSource.getConnection())) {
				svcTest.setMysql(new ServiceCheck("MySQL Connection", mysqlUrl, SUCCESS));
			} else {
				svcTest.setMysql(new ServiceCheck("MySQL Connection", mysqlUrl, FAILED));
			}
		} catch (Exception e) {
			svcTest.setMysql(
					new ServiceCheck("MySQL Connection (SST) ", mysqlUrl, FAILED + " [" + e.getMessage() + "]"));
			svcTest.setServiceResponse(FAILED);
		}
		return svcTest;
	}

	@GetMapping(value = "test", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public String serviceCheck() {
		return SERVICE_NAME;
	}

}