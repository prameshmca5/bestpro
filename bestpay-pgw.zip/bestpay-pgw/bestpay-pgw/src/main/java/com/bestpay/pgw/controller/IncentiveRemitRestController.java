package com.bestpay.pgw.controller;


import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.pgw.config.ConfigConstants;
import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwMerchantPid;
import com.bestpay.pgw.model.PgwMerchantProvider;
import com.bestpay.pgw.model.PgwTransaction;
import com.bestpay.pgw.model.PgwTransactionHistory;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.incentiveremit.model.AuthorizedConfirmedResponse;
import com.bestpay.pgw.sdk.incentiveremit.model.BeneficiaryDetailResult;
import com.bestpay.pgw.sdk.incentiveremit.model.BillPlzTransactionRequest;
import com.bestpay.pgw.sdk.incentiveremit.model.BillPlzTransactionResponse;
import com.bestpay.pgw.sdk.incentiveremit.model.ExRateRequest;
import com.bestpay.pgw.sdk.incentiveremit.model.ExRateResult;
import com.bestpay.pgw.sdk.incentiveremit.model.RegisterBeneficiaryRequest;
import com.bestpay.pgw.sdk.incentiveremit.model.RegisterBeneficiaryResult;
import com.bestpay.pgw.sdk.incentiveremit.model.RegisterCustomerRequest;
import com.bestpay.pgw.sdk.incentiveremit.model.RegisterCustomerResult;
import com.bestpay.pgw.sdk.incentiveremit.model.SearchCustomerResult;
import com.bestpay.pgw.sdk.incentiveremit.model.SendTransactionRequest;
import com.bestpay.pgw.sdk.incentiveremit.model.SendTransactionResult;
import com.bestpay.pgw.sdk.incentiveremit.model.TransactionReport;
import com.bestpay.pgw.sdk.incentiveremit.model.TransactionReportResult;
import com.bestpay.pgw.sdk.incentiveremit.model.TransactionStatusResponse;
import com.bestpay.pgw.sdk.incentiveremit.model.UserLoginResult;
import com.bestpay.pgw.sdk.model.RemittanceStatusDto;
import com.bestpay.pgw.service.PgwMerchantPidService;
import com.bestpay.pgw.service.PgwTransactionHistoryService;
import com.bestpay.pgw.service.PgwTransactionService;
import com.bestpay.pgw.service.RefFpxResponseCodeService;
import com.bstsb.util.MediaType;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@RestController
@RequestMapping(PgwUrlConstants.INCENTIVEREMIT_SERVICE)
public class IncentiveRemitRestController extends AbstractRestController {

	private static final Logger logger = LoggerFactory.getLogger(IncentiveRemitRestController.class);

	@Autowired
	protected RefFpxResponseCodeService refFpxResponseCodeService;

	@Autowired
	protected PgwTransactionService pgwTransactionService;

	@Autowired
	protected PgwMerchantPidService pgwMerchantPidService;

	@Autowired
	public PgwTransactionHistoryService transHistoryService;

	private static final String IR_URL = "https://imtpay.com/mobileAPI/websiteAPI.asmx";

	private static final String AGENT_CODE = "BESTINETHQ";

	private static final String USER_ID = "bestinet";

	private static final String AGENT_SESSION_ID = "bstpmtgateway";

	private static final String PWORD = "BestineT(8)";

	private static final String CONTENT_TYPE = "Content-Type";

	private static final String TEXT_XML = "text/xml";

	private static final String SIGNATURE = "Signature string: {}";

	private static final String FINAL_HASH = "finalHash: {}";

	private static final String AGENT_CODE_XML = "<AGENT_CODE>" + AGENT_CODE + "</AGENT_CODE> ";

	private static final String USER_ID_XML = "<USER_ID>" + USER_ID + "</USER_ID> ";

	private static final String AGENT_SESSION_ID_XML = "<AGENT_SESSION_ID>" + AGENT_SESSION_ID
			+ "</AGENT_SESSION_ID> ";

	private static final String INCENTIVE_REMIT = "INCENTIVE_REMIT";

	private static final String SPACE_STRING = "{} {} {}";

	private static final String CLOSE_SENDERCUSTOMERID = "</SenderCustomerID> ";

	private static final String OPEN_SENDERCUSTOMERID = "<SenderCustomerID>";

	private static final String CLOSE_SIGNATURE = "</SIGNATURE> ";

	private static final String OPEN_SIGNATURE = "<SIGNATURE>";


	@GetMapping(value = "/userLogin", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public UserLoginResult userLogin() {
		try {
			URL obj = new URL(IR_URL);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			String mobile = "0182653545";
			con.setRequestProperty(CONTENT_TYPE, TEXT_XML);
			String signature = AGENT_CODE + USER_ID + mobile + AGENT_SESSION_ID + PWORD;
			String finalHash = DigestUtils.sha256Hex(signature);
			String xml = "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <userLogin xmlns=\"iRemitWebservice\"> <AGENT_CODE>"
					+ AGENT_CODE + "</AGENT_CODE> <USER_ID>" + USER_ID + "</USER_ID> <MOBILENUMBER>" + mobile
					+ "</MOBILENUMBER> " + AGENT_SESSION_ID_XML + " <SIGNATURE>" + finalHash
					+ "</SIGNATURE> </userLogin> </soap:Body> </soap:Envelope>";
			con.setDoOutput(true);
			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(xml);
			wr.flush();
			wr.close();
			String responseStatus = con.getResponseMessage();
			logger.info("{}", responseStatus);
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			logger.info("response: {}", response);
			String soapBody = response.substring(response.indexOf("<userLoginResult>"),
					response.indexOf("</userLoginResult>") + 18);
			logger.info(soapBody);
			JAXBContext jaxbContext = JAXBContext.newInstance(UserLoginResult.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(soapBody);
			return (UserLoginResult) jaxbUnmarshaller.unmarshal(reader);
		} catch (Exception e) {
			logger.info("{} ", e);
		}
		return new UserLoginResult();
	}


	@PostMapping(value = "/registerCustomer", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public RegisterCustomerResult registerCustomer(@RequestBody RegisterCustomerRequest registerCustomerRequest) {
		try {
			logger.info("In registerCustomer method");
			if (registerCustomerRequest.getSenderIdType2() == null) {
				registerCustomerRequest.setSenderIdType2("");
			}
			if (registerCustomerRequest.getSenderIdNumber2() == null) {
				registerCustomerRequest.setSenderIdNumber2("");
			}
			URL obj = new URL(IR_URL);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty(CONTENT_TYPE, TEXT_XML);
			String signature = AGENT_CODE + USER_ID + AGENT_SESSION_ID + getSignature(registerCustomerRequest)
					+ PWORD;
			logger.info(SIGNATURE, signature);
			String finalHash = DigestUtils.sha256Hex(signature);
			logger.info(FINAL_HASH, finalHash);
			String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <RegisterCustomer xmlns=\"iRemitWebservice\"> <AGENT_CODE>"
					+ AGENT_CODE + "</AGENT_CODE> <USER_ID>" + USER_ID + "</USER_ID>" + AGENT_SESSION_ID_XML
					+ " <SenderFirstName>" + registerCustomerRequest.getSenderFirstName()
					+ "</SenderFirstName> <SenderMiddleName>" + registerCustomerRequest.getSenderMiddleName()
					+ "</SenderMiddleName>" + " <SenderLastName>" + registerCustomerRequest.getSenderLastName()
					+ "</SenderLastName> <SenderGender>" + registerCustomerRequest.getSenderGender()
					+ "</SenderGender> <SenderAddress>" + registerCustomerRequest.getSenderAddress()
					+ "</SenderAddress> <SenderCity>" + registerCustomerRequest.getSenderCity() + "</SenderCity>"
					+ " <SenderState>" + registerCustomerRequest.getSenderState()
					+ "</SenderState> <SenderCountry>" + registerCustomerRequest.getSenderCountry()
					+ "</SenderCountry> <SenderZipCode>" + registerCustomerRequest.getSenderZipCode()
					+ "</SenderZipCode> <SenderMobile>" + registerCustomerRequest.getSenderMobile()
					+ "</SenderMobile>" + "<SenderIDType>" + registerCustomerRequest.getSenderIDType()
					+ "</SenderIDType> <SenderIDNumber>" + registerCustomerRequest.getSenderIDNumber()
					+ "</SenderIDNumber> <IDIssuePlace>" + registerCustomerRequest.getIdIssuePlace()
					+ "</IDIssuePlace> <IDIssueDate>" + registerCustomerRequest.getIdIssueDate() + "</IDIssueDate>"
					+ "<IDExpireDate>" + registerCustomerRequest.getIdExpireDate()
					+ "</IDExpireDate> <SenderIDType2>" + registerCustomerRequest.getSenderIdType2()
					+ "</SenderIDType2> <SenderIDNumber2>" + registerCustomerRequest.getSenderIdNumber2()
					+ "</SenderIDNumber2> <SenderNativeCountry>" + registerCustomerRequest.getSenderNativeCountry()
					+ "</SenderNativeCountry> " + "<SenderDateOfBirth>"
					+ registerCustomerRequest.getSenderDateOfBirth() + "</SenderDateOfBirth> <SenderOccupation>"
					+ registerCustomerRequest.getSenderOccupation() + "</SenderOccupation> <SenderEmployerName>"
					+ registerCustomerRequest.getSenderEmployerName()
					+ "</SenderEmployerName> <SenderEmployerType>"
					+ registerCustomerRequest.getSenderEmployerType() + "</SenderEmployerType> "
					+ "<SenderFundSource>" + registerCustomerRequest.getSenderFundSource()
					+ "</SenderFundSource> <SenderPhoto>" + registerCustomerRequest.getSenderPhoto()
					+ "</SenderPhoto> <SenderPhoto1>" + registerCustomerRequest.getSenderPhoto1()
					+ "</SenderPhoto1>" + " <SIGNATURE>" + finalHash
					+ "</SIGNATURE> </RegisterCustomer> </soap:Body> </soap:Envelope>";
			con.setDoOutput(true);
			logger.info(xml);

			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(xml);
			wr.flush();
			wr.close();
			String responseStatus = con.getResponseMessage();
			logger.info(responseStatus);
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			String soapBody = response.substring(response.indexOf("<RegisterCustomerResult>"),
					response.indexOf("</RegisterCustomerResult>") + 25);
			logger.info(soapBody);
			JAXBContext jaxbContext = JAXBContext.newInstance(RegisterCustomerResult.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(soapBody);
			RegisterCustomerResult registerCustomer = (RegisterCustomerResult) jaxbUnmarshaller.unmarshal(reader);
			logger.info(registerCustomer.getMessage() + " " + registerCustomer.getCode() + " "
					+ registerCustomer.getSenderCustomerId());
			return registerCustomer;
		} catch (Exception e) {
			logger.info("{} ", e);
		}
		return new RegisterCustomerResult();
	}


	private String getSignature(Object registerCustomerRequest) throws IllegalAccessException, NoSuchFieldException {
		Field[] allFields = registerCustomerRequest.getClass().getDeclaredFields();
		StringBuilder signature = new StringBuilder();

		for (Field each : allFields) {

			Field field = registerCustomerRequest.getClass().getDeclaredField(each.getName());
			field.setAccessible(true);
			Object value = field.get(registerCustomerRequest);
			if (value != null && !field.getName().contains("Photo")) {
				signature.append(value);
			}

		}

		return signature.toString();
	}


	@PostMapping(value = "/registerBeneficiary", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public RegisterBeneficiaryResult registerBeneficiary(
			@RequestBody RegisterBeneficiaryRequest registerBeneficiaryRequest) {
		try {
			logger.info("In registerBeneficiary method");
			URL obj = new URL(IR_URL);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty(CONTENT_TYPE, TEXT_XML);
			String signature = AGENT_CODE + USER_ID + AGENT_SESSION_ID + getSignature(registerBeneficiaryRequest)
					+ PWORD;
			logger.info(SIGNATURE, signature);
			String finalHash = DigestUtils.sha256Hex(signature);
			logger.info(FINAL_HASH, finalHash);
			String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <RegisterBeneficiary xmlns=\"iRemitWebservice\"> "
					+ AGENT_CODE_XML + USER_ID_XML + AGENT_SESSION_ID_XML + OPEN_SENDERCUSTOMERID
					+ registerBeneficiaryRequest.getSenderCustomerId() + CLOSE_SENDERCUSTOMERID
					+ "<BeneficiaryFirstName>" + registerBeneficiaryRequest.getFirstName()
					+ "</BeneficiaryFirstName> " + "<BeneficiaryMiddleName>"
					+ registerBeneficiaryRequest.getMiddleName() + "</BeneficiaryMiddleName> "
					+ "<BeneficiaryLastName>" + registerBeneficiaryRequest.getLastName()
					+ "</BeneficiaryLastName> " + "<BeneficiaryAddress>" + registerBeneficiaryRequest.getAddress()
					+ "</BeneficiaryAddress> " + "<BeneficiaryCity>" + registerBeneficiaryRequest.getCity()
					+ "</BeneficiaryCity> " + "<BeneficiaryCountry>" + registerBeneficiaryRequest.getCountry()
					+ "</BeneficiaryCountry> " + "<BeneficiaryMobile>" + registerBeneficiaryRequest.getMobile()
					+ "</BeneficiaryMobile> " + "<BeneficiaryEmail>" + registerBeneficiaryRequest.getEmail()
					+ "</BeneficiaryEmail> " + "<BeneficeryRelationship>"
					+ registerBeneficiaryRequest.getRelationShip() + "</BeneficeryRelationship> " + OPEN_SIGNATURE
					+ finalHash + "</SIGNATURE> </RegisterBeneficiary> </soap:Body> </soap:Envelope>";
			con.setDoOutput(true);
			logger.info(xml);

			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(xml);
			wr.flush();
			wr.close();
			String responseStatus = con.getResponseMessage();
			logger.info(responseStatus);
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			String soapBody = response.substring(response.indexOf("<RegisterBeneficiaryResult>"),
					response.indexOf("</RegisterBeneficiaryResult>") + 28);
			logger.info(soapBody);
			JAXBContext jaxbContext = JAXBContext.newInstance(RegisterBeneficiaryResult.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(soapBody);
			RegisterBeneficiaryResult registerBeneficiary = (RegisterBeneficiaryResult) jaxbUnmarshaller
					.unmarshal(reader);
			logger.info(SPACE_STRING, registerBeneficiary.getMessage(), registerBeneficiary.getBeneficiarySno(),
					registerBeneficiary.getSenderCustomerId());
			return registerBeneficiary;
		} catch (Exception e) {
			logger.info("{}", e);
		}
		return new RegisterBeneficiaryResult();
	}


	@PostMapping(value = "/getExRate", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public ExRateResult getExRate(@RequestBody ExRateRequest exRateRequest) {
		try {
			logger.info("In getExRate method");
			if (exRateRequest.getPromotionCode() == null) {
				exRateRequest.setPromotionCode("");
			}
			if (exRateRequest.getPayoutPartnerId() == null) {
				exRateRequest.setPayoutPartnerId("");
			}
			URL obj = new URL(IR_URL);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty(CONTENT_TYPE, TEXT_XML);
			String signature = AGENT_CODE + USER_ID + AGENT_SESSION_ID + getSignature(exRateRequest) + PWORD;
			logger.info(SIGNATURE, signature);
			String finalHash = DigestUtils.sha256Hex(signature);
			logger.info(FINAL_HASH, finalHash);
			String xml = "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <GetEXRate xmlns=\"iRemitWebservice\">"
					+ " <AGENT_CODE>" + AGENT_CODE + "</AGENT_CODE> " + USER_ID_XML + AGENT_SESSION_ID_XML
					+ "<TRANSFERAMOUNT>" + exRateRequest.getTransferAmount() + "</TRANSFERAMOUNT>"
					+ "<PAYMENTMODE>" + exRateRequest.getPaymentMode() + "</PAYMENTMODE> " + "<CALC_BY>"
					+ exRateRequest.getCalcBy() + "</CALC_BY> " + "<LOCATION_ID>" + exRateRequest.getLocationId()
					+ "</LOCATION_ID> " + "<PAYOUT_COUNTRY>" + exRateRequest.getPayoutCountry()
					+ "</PAYOUT_COUNTRY> " + "<PROMOTION_CODE>" + exRateRequest.getPromotionCode()
					+ "</PROMOTION_CODE> " + "<PAYOUT_PARTNER_ID>" + exRateRequest.getPayoutPartnerId()
					+ "</PAYOUT_PARTNER_ID> " + OPEN_SIGNATURE + finalHash + CLOSE_SIGNATURE
					+ "</GetEXRate> </soap:Body> </soap:Envelope>";
			con.setDoOutput(true);
			logger.info(xml);

			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(xml);
			wr.flush();
			wr.close();
			con.getResponseMessage();

			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			String soapBody = response.substring(response.indexOf("<GetEXRateResult>"),
					response.indexOf("</GetEXRateResult>") + 18);
			logger.info(soapBody);
			JAXBContext jaxbContext = JAXBContext.newInstance(ExRateResult.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(soapBody);
			ExRateResult exRate = (ExRateResult) jaxbUnmarshaller.unmarshal(reader);
			logger.info(SPACE_STRING, exRate.getMessage(), exRate.getGstCharge(), exRate.getAdditionalPremiumRate());
			return exRate;
		} catch (Exception e) {
			logger.info("{} ", e);
		}
		return new ExRateResult();
	}


	@PostMapping(value = "/sendTransaction", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public SendTransactionResult sendTransaction(@RequestBody SendTransactionRequest sendTransactionRequest) {
		try {
			logger.info("In sendTransaction method");
			if (sendTransactionRequest.getPromotionCode() == null) {
				sendTransactionRequest.setPromotionCode("");
			}
			if (sendTransactionRequest.getPayoutPartnerId() == null) {
				sendTransactionRequest.setPayoutPartnerId("");
			}
			if (sendTransactionRequest.getSenderMiddleName() == null) {
				sendTransactionRequest.setSenderMiddleName("");
			}
			if (sendTransactionRequest.getSenderSecondaryIdType() == null) {
				sendTransactionRequest.setSenderSecondaryIdType("");
			}
			if (sendTransactionRequest.getSenderSecondaryIdNumber() == null) {
				sendTransactionRequest.setSenderSecondaryIdNumber("");
			}
			URL obj = new URL(getServiceProvider(INCENTIVE_REMIT).getUrl());
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty(CONTENT_TYPE, TEXT_XML);
			String signature = getServiceProvider(INCENTIVE_REMIT).getAgentCode()
					+ getServiceProvider(INCENTIVE_REMIT).getUserId()
					+ getServiceProvider(INCENTIVE_REMIT).getAgentSessionId()
					+ getSignature(sendTransactionRequest) + getServiceProvider(INCENTIVE_REMIT).getPassword();
			logger.info(SIGNATURE, signature);
			String finalHash = DigestUtils.sha256Hex(signature);
			logger.info(FINAL_HASH, finalHash);
			String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <SendTransaction xmlns=\"iRemitWebservice\">"
					+ AGENT_CODE_XML + USER_ID_XML + AGENT_SESSION_ID_XML + "<AGENT_TXNID>"
					+ sendTransactionRequest.getAgentTxnId() + "</AGENT_TXNID> " + "<PAYOUT_PARTNER_ID>"
					+ sendTransactionRequest.getPayoutPartnerId() + "</PAYOUT_PARTNER_ID> " + "<LOCATION_ID>"
					+ sendTransactionRequest.getLocationId() + "</LOCATION_ID> " + "<SENDER_ID>"
					+ sendTransactionRequest.getSenderId() + "</SENDER_ID> " + "<SENDER_FIRST_NAME>"
					+ sendTransactionRequest.getSenderFirstName() + "</SENDER_FIRST_NAME> "
					+ "<SENDER_MIDDLE_NAME>" + sendTransactionRequest.getSenderMiddleName()
					+ "</SENDER_MIDDLE_NAME> " + "<SENDER_LAST_NAME>" + sendTransactionRequest.getSenderLastName()
					+ "</SENDER_LAST_NAME> " + "<SENDER_GENDER>" + sendTransactionRequest.getSenderGender()
					+ "</SENDER_GENDER> " + "<SENDER_ADDRESS>" + sendTransactionRequest.getSenderAddress()
					+ "</SENDER_ADDRESS> " + "<SENDER_CITY>" + sendTransactionRequest.getSenderCity()
					+ "</SENDER_CITY> " + "<SENDER_STATES>" + sendTransactionRequest.getSenderStates()
					+ "</SENDER_STATES> " + "<SENDER_ZIPCODE>" + sendTransactionRequest.getSenderZipCode()
					+ "</SENDER_ZIPCODE> " + "<SENDER_COUNTRY>" + sendTransactionRequest.getSenderCountry()
					+ "</SENDER_COUNTRY> " + "<SENDER_MOBILE>" + sendTransactionRequest.getSenderMobile()
					+ "</SENDER_MOBILE> " + "<SENDER_NATIONALITY>" + sendTransactionRequest.getSenderNationality()
					+ "</SENDER_NATIONALITY> " + "<SENDER_ID_TYPE>" + sendTransactionRequest.getSenderIdType()
					+ "</SENDER_ID_TYPE> " + "<SENDER_ID_NUMBER>" + sendTransactionRequest.getSenderIdNumber()
					+ "</SENDER_ID_NUMBER> " + "<SENDER_ID_ISSUE_COUNTRY>"
					+ sendTransactionRequest.getSenderIdIssueCountry() + "</SENDER_ID_ISSUE_COUNTRY> "
					+ "<SENDER_ID_ISSUE_DATE>" + sendTransactionRequest.getSenderIdIssueDate()
					+ "</SENDER_ID_ISSUE_DATE> " + "<SENDER_ID_EXPIRE_DATE>"
					+ sendTransactionRequest.getSenderIdExpireDate() + "</SENDER_ID_EXPIRE_DATE> "
					+ "<SENDER_DATE_OF_BIRTH>" + sendTransactionRequest.getSenderDateOfBirth()
					+ "</SENDER_DATE_OF_BIRTH> " + "<SENDER_OCCUPATION>"
					+ sendTransactionRequest.getSenderOccupation() + "</SENDER_OCCUPATION> "
					+ "<SENDER_SOURCE_OF_FUND>" + sendTransactionRequest.getSenderSourceOfFund()
					+ "</SENDER_SOURCE_OF_FUND> " + "<SENDER_SECONDARY_ID_TYPE>"
					+ sendTransactionRequest.getSenderSecondaryIdType() + "</SENDER_SECONDARY_ID_TYPE> "
					+ "<SENDER_SECONDARY_ID_NUMBER>" + sendTransactionRequest.getSenderSecondaryIdNumber()
					+ "</SENDER_SECONDARY_ID_NUMBER> " + "<SENDER_BENEFICIARY_RELATIONSHIP>"
					+ sendTransactionRequest.getSenderBeneficiaryRelationship()
					+ "</SENDER_BENEFICIARY_RELATIONSHIP> " + "<PURPOSE_OF_REMITTANCE>"
					+ sendTransactionRequest.getPurposeOfRemittance() + "</PURPOSE_OF_REMITTANCE> "
					+ "<RECEIVER_SNO>" + sendTransactionRequest.getReceiverSno() + "</RECEIVER_SNO> "
					+ "<RECEIVER_FIRST_NAME>" + sendTransactionRequest.getReceiverFirstName()
					+ "</RECEIVER_FIRST_NAME> " + "<RECEIVER_MIDDLE_NAME>"
					+ sendTransactionRequest.getReceiverMiddleName() + "</RECEIVER_MIDDLE_NAME> "
					+ "<RECEIVER_LAST_NAME>" + sendTransactionRequest.getReceiverLastName()
					+ "</RECEIVER_LAST_NAME> " + "<RECEIVER_ADDRESS>" + sendTransactionRequest.getReceiverAddress()
					+ "</RECEIVER_ADDRESS> " + "<RECEIVER_CONTACT_NUMBER>"
					+ sendTransactionRequest.getReceiverContactNumber() + "</RECEIVER_CONTACT_NUMBER> "
					+ "<RECEIVER_CITY>" + sendTransactionRequest.getReceiverCity() + "</RECEIVER_CITY> "
					+ "<RECEIVER_COUNTRY>" + sendTransactionRequest.getReceiverCountry() + "</RECEIVER_COUNTRY> "
					+ "<RECEIVER_ID_TYPE>" + sendTransactionRequest.getReceiverIdType() + "</RECEIVER_ID_TYPE> "
					+ "<RECEIVER_ID_NUMBER>" + sendTransactionRequest.getReceiverIdNumber()
					+ "</RECEIVER_ID_NUMBER> " + "<CALC_BY>" + sendTransactionRequest.getCalcBy() + "</CALC_BY> "
					+ "<TRANSFER_AMOUNT>" + sendTransactionRequest.getTransferAmount() + "</TRANSFER_AMOUNT> "
					+ "<TRANSFER_CURRENCY>" + sendTransactionRequest.getTransferCurrency()
					+ "</TRANSFER_CURRENCY> " + "<PAYMENTMODE>" + sendTransactionRequest.getPaymentMode()
					+ "</PAYMENTMODE> " + "<BANKID>" + sendTransactionRequest.getBankId() + "</BANKID> "
					+ "<BANK_NAME>" + sendTransactionRequest.getBankName() + "</BANK_NAME> " + "<BANK_BRANCHID>"
					+ sendTransactionRequest.getBankBranchId() + "</BANK_BRANCHID> " + "<BANK_BRANCH_NAME>"
					+ sendTransactionRequest.getBankBranchName() + "</BANK_BRANCH_NAME> " + "<BANK_ACCOUNT_NUMBER>"
					+ sendTransactionRequest.getBankAccountNumber() + "</BANK_ACCOUNT_NUMBER> "
					+ "<PROMOTION_CODE>" + sendTransactionRequest.getPromotionCode() + "</PROMOTION_CODE> "
					+ OPEN_SIGNATURE + finalHash + CLOSE_SIGNATURE
					+ "</SendTransaction> </soap:Body> </soap:Envelope>";
			con.setDoOutput(true);
			logger.info(xml);

			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(xml);
			wr.flush();
			wr.close();
			con.getResponseMessage();

			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			String soapBody = response.substring(response.indexOf("<SendTransactionResult>"),
					response.indexOf("</SendTransactionResult>") + 24);
			logger.info(soapBody);
			JAXBContext jaxbContext = JAXBContext.newInstance(SendTransactionResult.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(soapBody);
			SendTransactionResult transaction = (SendTransactionResult) jaxbUnmarshaller.unmarshal(reader);
			logger.info(SPACE_STRING, transaction.getMessage(), transaction.getCode(), transaction.getPinNo());
			return transaction;
		} catch (Exception e) {
			logger.info("{} ", e);
		}
		return new SendTransactionResult();
	}


	@GetMapping(value = "/authorizedConfirmed", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public AuthorizedConfirmedResponse authorizedConfirmed(@RequestParam String pinNo) {
		try {
			logger.info("In authorizedConfirmed method");
			URL obj = new URL(getServiceProvider(INCENTIVE_REMIT).getUrl());
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty(CONTENT_TYPE, TEXT_XML);
			String signature = getServiceProvider(INCENTIVE_REMIT).getAgentCode()
					+ getServiceProvider(INCENTIVE_REMIT).getUserId() + pinNo
					+ getServiceProvider(INCENTIVE_REMIT).getAgentSessionId()
					+ getServiceProvider(INCENTIVE_REMIT).getPassword();
			logger.info(SIGNATURE, signature);
			String finalHash = DigestUtils.sha256Hex(signature);
			logger.info(FINAL_HASH, finalHash);
			String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <Authorized_Confirmed xmlns=\"iRemitWebservice\"> "
					+ AGENT_CODE_XML + USER_ID_XML + "<PINNO>" + pinNo + "</PINNO> " + AGENT_SESSION_ID_XML
					+ OPEN_SIGNATURE + finalHash + CLOSE_SIGNATURE
					+ "</Authorized_Confirmed> </soap:Body> </soap:Envelope>";
			con.setDoOutput(true);
			logger.info(xml);

			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(xml);
			wr.flush();
			wr.close();
			con.getResponseMessage();

			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			String soapBody = response.substring(response.indexOf("<Authorized_ConfirmedResult>"),
					response.indexOf("</Authorized_ConfirmedResult>") + 29);
			logger.info(soapBody);
			JAXBContext jaxbContext = JAXBContext.newInstance(AuthorizedConfirmedResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(soapBody);
			AuthorizedConfirmedResponse authorized = (AuthorizedConfirmedResponse) jaxbUnmarshaller
					.unmarshal(reader);
			logger.info(SPACE_STRING, authorized.getMessage(), authorized.getCode(), authorized.getAgentSessionId());
			return authorized;
		} catch (Exception e) {
			logger.info("{} ", e);
		}
		return new AuthorizedConfirmedResponse();
	}


	@GetMapping(value = "/transactionStatus", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public TransactionStatusResponse transactionStatus(@RequestParam String refNo) {
		try {
			logger.info("In transactionStatus method");
			URL obj = new URL(getServiceProvider(INCENTIVE_REMIT).getUrl());
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty(CONTENT_TYPE, TEXT_XML);
			String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <getTransactionStatus xmlns=\"iRemitWebservice\"> "
					+ "<REFNO>" + refNo + "</REFNO> " + "</getTransactionStatus> </soap:Body> </soap:Envelope>";
			con.setDoOutput(true);
			logger.info(xml);

			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(xml);
			wr.flush();
			wr.close();
			con.getResponseMessage();

			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			String soapBody = response.substring(response.indexOf("<getTransactionStatusResult>"),
					response.indexOf("</getTransactionStatusResult>") + 29);
			logger.info(soapBody);
			JAXBContext jaxbContext = JAXBContext.newInstance(TransactionStatusResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(soapBody);
			TransactionStatusResponse transaction = (TransactionStatusResponse) jaxbUnmarshaller.unmarshal(reader);
			logger.info(SPACE_STRING, transaction.getRefNo(), transaction.getCode(), transaction.getStatus());
			return transaction;
		} catch (Exception e) {
			logger.info("{} ", e);
		}
		return new TransactionStatusResponse();
	}


	@PostMapping(value = "/transactionReport", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<TransactionReport> transactionReport(@RequestParam String reportType, @RequestParam String fromDate,
			@RequestParam String fromDateTime, @RequestParam String toDate, @RequestParam String toDateTime) {
		try {
			logger.info("In transactionReport method");
			URL obj = new URL(IR_URL);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty(CONTENT_TYPE, TEXT_XML);

			String signature = AGENT_CODE + USER_ID + AGENT_SESSION_ID + reportType + fromDate + fromDateTime
					+ toDate + toDateTime + PWORD;
			logger.info(SIGNATURE, signature);
			String finalHash = DigestUtils.sha256Hex(signature);
			logger.info(FINAL_HASH, finalHash);

			String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <TransactionReport xmlns=\"iRemitWebservice\"> "
					+ AGENT_CODE_XML + USER_ID_XML + AGENT_SESSION_ID_XML + "<REPORT_TYPE>" + reportType
					+ "</REPORT_TYPE> " + "<FROM_DATE>" + fromDate + "</FROM_DATE> " + "<FROM_DATE_TIME>"
					+ fromDateTime + "</FROM_DATE_TIME> " + "<TO_DATE>" + toDate + "</TO_DATE> " + "<TO_DATE_TIME>"
					+ toDateTime + "</TO_DATE_TIME> " + OPEN_SIGNATURE + finalHash
					+ "</SIGNATURE> </TransactionReport> </soap:Body> </soap:Envelope>";
			con.setDoOutput(true);
			logger.info(xml);

			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(xml);
			wr.flush();
			wr.close();
			con.getResponseMessage();

			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			String soapBody = response.substring(response.indexOf("<TransactionReportResult>"),
					response.indexOf("</TransactionReportResult>") + 26);
			logger.info(soapBody);
			JAXBContext jaxbContext = JAXBContext.newInstance(TransactionReportResult.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(soapBody);
			TransactionReportResult transaction = (TransactionReportResult) jaxbUnmarshaller.unmarshal(reader);
			for (TransactionReport transReport : transaction.getTransactionReports()) {
				logger.info(SPACE_STRING, transReport.getPinNo(), transReport.getSenderName(),
						transReport.getStatus());
			}
			return transaction.getTransactionReports();
		} catch (Exception e) {
			logger.info("{} ", e);
		}
		return Collections.emptyList();
	}


	@PostMapping(value = "/transactionBillPlz", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public BillPlzTransactionResponse transactionBillPlz(@RequestBody BillPlzTransactionRequest transactionRequest) {
		logger.info("In transactionBillPlz method");
		BillPlzTransactionResponse transaction = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(getServiceProvider(INCENTIVE_REMIT).getFpxUrl());

			HttpPost request = new HttpPost(sbUrl.toString());
			request.addHeader("Authorization", getServiceProvider(INCENTIVE_REMIT).getApikey());

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("collection_id", transactionRequest.getCollectionId()));
			params.add(new BasicNameValuePair("description", transactionRequest.getDescription()));
			params.add(new BasicNameValuePair("email", transactionRequest.getEmail()));
			params.add(new BasicNameValuePair("mobile", transactionRequest.getMobile()));
			params.add(new BasicNameValuePair("name", transactionRequest.getName()));
			params.add(new BasicNameValuePair("amount", transactionRequest.getAmount()));
			params.add(new BasicNameValuePair("reference_1_label", transactionRequest.getReference_1_Label()));
			params.add(new BasicNameValuePair("reference_1", transactionRequest.getReference_1()));
			params.add(new BasicNameValuePair("reference_2_label", transactionRequest.getReference_2_Label()));
			params.add(new BasicNameValuePair("reference_2", transactionRequest.getReference_2()));
			params.add(new BasicNameValuePair("callback_url", transactionRequest.getCallbackUrl()));
			params.add(new BasicNameValuePair("redirect_url", transactionRequest.getRedirectUrl()));

			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					transaction = objectMapper.readValue(instream, BillPlzTransactionResponse.class);
					instream.close();
				}
			} else {

				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();

					instream.close();
					logger.info("Error in transactionBillPlz ");
				} else {
					logger.info("No Response from Server");
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("customerRegistration UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("customerRegistration ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("customerRegistration JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("customerRegistration JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("customerRegistration IOException: {}", e.getMessage());
		}

		return transaction;
	}


	public SearchCustomerResult searchCustomer(String customerId, String idType, String idNumber) {
		try {
			logger.info("In searchCustomer method");
			URL obj = new URL(IR_URL);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty(CONTENT_TYPE, TEXT_XML);
			String signature = AGENT_CODE + USER_ID + AGENT_SESSION_ID + customerId + idType + idNumber + PWORD;
			logger.info(SIGNATURE, signature);
			String finalHash = DigestUtils.sha256Hex(signature);
			logger.info(FINAL_HASH, finalHash);
			String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <SearchCustomer xmlns=\"iRemitWebservice\"> "
					+ AGENT_CODE_XML + USER_ID_XML + AGENT_SESSION_ID_XML + OPEN_SENDERCUSTOMERID + customerId
					+ CLOSE_SENDERCUSTOMERID + "<CustomerIDType>" + idType + "</CustomerIDType> "
					+ "<CustomerIDNumber>" + idNumber + "</CustomerIDNumber> " + OPEN_SIGNATURE + finalHash
					+ CLOSE_SIGNATURE + "</SearchCustomer> </soap:Body> </soap:Envelope>";
			con.setDoOutput(true);
			logger.info(xml);

			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(xml);
			wr.flush();
			wr.close();
			String responseStatus = con.getResponseMessage();
			logger.info(responseStatus);
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			String soapBody = response.substring(response.indexOf("<SearchCustomerResult>"),
					response.indexOf("</SearchCustomerResult>") + 23);
			logger.info(soapBody);
			JAXBContext jaxbContext = JAXBContext.newInstance(SearchCustomerResult.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(soapBody);
			SearchCustomerResult searchCustomer = (SearchCustomerResult) jaxbUnmarshaller.unmarshal(reader);
			logger.info(searchCustomer.getMessage() + " " + searchCustomer.getCustomerDetailInformation() + " "
					+ searchCustomer.getIdIssueDate());
			return searchCustomer;
		} catch (Exception e) {
			logger.info("{} ", e);
		}
		return new SearchCustomerResult();
	}


	@GetMapping(value = PgwUrlConstants.FIND_INCENT_BENEF_DETAILS, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public BeneficiaryDetailResult getBeneficiaryDetail(String beneficiarySno, String senderCustomerId) {
		try {
			logger.info("In getBeneficiaryDetail method");
			URL obj = new URL(IR_URL);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty(CONTENT_TYPE, TEXT_XML);
			String signature = AGENT_CODE + USER_ID + AGENT_SESSION_ID + beneficiarySno + senderCustomerId + PWORD;
			logger.info(SIGNATURE, signature);
			String finalHash = DigestUtils.sha256Hex(signature);
			logger.info(FINAL_HASH, finalHash);
			String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <GetBeneficiaryDetail xmlns=\"iRemitWebservice\"> "
					+ AGENT_CODE_XML + USER_ID_XML + "<AGENT_SESSION_ID>" + AGENT_SESSION_ID
					+ "</AGENT_SESSION_ID> " + "<BeneficiarySno>" + beneficiarySno + "</BeneficiarySno> "
					+ OPEN_SENDERCUSTOMERID + senderCustomerId + CLOSE_SENDERCUSTOMERID + OPEN_SIGNATURE
					+ finalHash + CLOSE_SIGNATURE + "</GetBeneficiaryDetail> </soap:Body> </soap:Envelope>";
			con.setDoOutput(true);
			logger.info(xml);

			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(xml);
			wr.flush();
			wr.close();
			String responseStatus = con.getResponseMessage();
			logger.info(responseStatus);
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			String soapBody = response.substring(response.indexOf("<GetBeneficiaryDetailResult>"),
					response.indexOf("</GetBeneficiaryDetailResult>") + 29);
			logger.info(soapBody);
			JAXBContext jaxbContext = JAXBContext.newInstance(BeneficiaryDetailResult.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(soapBody);
			BeneficiaryDetailResult beneficiaryDetail = (BeneficiaryDetailResult) jaxbUnmarshaller.unmarshal(reader);
			logger.info(beneficiaryDetail.getBeneficiaryAddress() + " " + beneficiaryDetail.getBeneficiaryCity()
					+ " " + beneficiaryDetail.getBeneficiaryFirstName());
			return beneficiaryDetail;
		} catch (Exception e) {
			logger.info("{} ", e);
		}
		return new BeneficiaryDetailResult();
	}


	@GetMapping(value = PgwUrlConstants.IRORDERSTATUS, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public RemittanceStatusDto getIROrderStatus(@RequestParam String orderId) {
		String merpid = null;
		String incentId = null;
		RemittanceStatusDto remitdto = new RemittanceStatusDto();
		if (orderId != null) {
			PgwTransaction transaction = pgwTransactionService.findByMerOrderDetails(orderId);
			if (transaction != null && transaction.getPinNo() != null) {
				incentId = transaction.getPinNo();
				PgwMerchantPid pid = pgwMerchantPidService.findByMerchantMaxmoneyPid(transaction.getMerchantId());
				merpid = pid.getPid();
				remitdto.setOrderId(incentId);
				remitdto.setpId(merpid);
				String refNo = incentId;
				try {
					TransactionStatusResponse transRespd;
					transRespd = transactionStatus(refNo);
					if (transRespd.getStatus().equals("Paid") || transRespd.getStatus().equals("Post")) {
						remitdto.setTransStatus("success");
						remitdto.setOrderDetails("Remitted");
						remitdto.setStatusCode("03");
					} else if (transRespd.getStatus().equals("Cancel")) {
						if (transaction.getSubmerId() != null) {
							remitdto.setTransStatus("fail");
							remitdto.setOrderDetails("Remitted Failed");
							remitdto.setStatusCode("07");
						} else {
							remitdto.setTransStatus("fail");
							remitdto.setOrderDetails("Payment Failed");
							remitdto.setStatusCode("04");
						}
					} else {
						remitdto.setTransStatus("pending");
						remitdto.setOrderDetails("Pending Remittance");
						remitdto.setStatusCode("05");
					}

					if (!BaseUtil.isEquals(transaction.getResMsg(), remitdto.getOrderDetails())) {
						transaction.setResCode(remitdto.getStatusCode());
						transaction.setResMsg(remitdto.getOrderDetails());
						transaction.setStatus(remitdto.getTransStatus());
						pgwTransactionService.update(transaction);
						saveTransHistory(transaction);
					}

				} catch (Exception e) {
					remitdto.setStatusCode("04");
					remitdto.setErrorCode("76");
					remitdto.setDescription("Transaction Not Found");
					logger.info("MAXMONEY ORDER STATUS ISSUE {}", e.getMessage());
				}
			} else {
				remitdto.setStatusCode("04");
				remitdto.setErrorCode("76");
				remitdto.setDescription("Transaction Not Found");
			}
		}
		return remitdto;
	}


	private void saveTransHistory(PgwTransaction p) {
		try {
			PgwTransactionHistory h = dozerMapper.map(p, PgwTransactionHistory.class);
			h.setId(null);
			transHistoryService.create(h);
		} catch (Exception e1) {
			logger.info("Error in creating transaction history {}", e1.getMessage());
		}
	}


	private PgwMerchantProvider getServiceProvider(String providerName) {
		return pgwMerchantProviderService.findByMerchantBenefId(providerName);
	}

}
