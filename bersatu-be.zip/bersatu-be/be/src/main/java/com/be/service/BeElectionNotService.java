/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.be.service;


import java.io.IOException;
import java.util.Comparator;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeElectionNotQf;
import com.be.dao.BeElectionNotRepository;
import com.be.model.BeElectionNot;
import com.be.sdk.model.ElectionNot;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;


/**
 * @author mohd.naem
 * @since March 31 , 2021
 */
@Service(QualifierConstants.BE_ELECTION_NOT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_ELECTION_NOT_SVC)
@Transactional
public class BeElectionNotService extends AbstractService<BeElectionNot> {

	protected static Logger logger = LoggerFactory.getLogger(BeElectionNotService.class);

	@Autowired
	private BeElectionNotRepository beElectionNotDao;

	@Autowired
	private BeElectionNotQf beElectionNotQf;


	@Override
	public GenericRepository<BeElectionNot> primaryDao() {
		return beElectionNotDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return null;
	}


	public long getCount(ElectionNot dto) {
		return beElectionNotQf.getCount(dto);
	}


	@SuppressWarnings("unchecked")
	public List<ElectionNot> searchPagination(ElectionNot dto, DataTableRequest<?> dataTableInRQ) throws IOException {
		return JsonUtil.transferToList(beElectionNotQf.searchAllByProperty(dto, dataTableInRQ), ElectionNot.class);
	}


	@SuppressWarnings("unchecked")
	public ElectionNot search(ElectionNot dto) throws IOException {
		List<BeElectionNot> beElectionNotList = beElectionNotQf.searchAllByProperty(dto, null);
		ElectionNot electionNot = null;
		if (!BaseUtil.isListNull(beElectionNotList)) {
			BeElectionNot beMemberProfile = beElectionNotList.stream()
					.sorted(Comparator.comparingInt(BeElectionNot::getElectionNotId).reversed()).findFirst()
					.orElse(null);
			if (!BaseUtil.isObjNull(beMemberProfile)) {
				electionNot = JsonUtil.transferToObject(beMemberProfile, ElectionNot.class);
			}
		}
		return electionNot;
	}
}