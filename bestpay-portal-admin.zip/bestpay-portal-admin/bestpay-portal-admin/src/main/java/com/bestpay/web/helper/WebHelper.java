/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.bestpay.idm.sdk.constants.IdmRoleConstants;
import com.bestpay.idm.sdk.model.UserMenu;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.idm.sdk.model.UserRole;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.config.iam.CustomUserDetails;
import com.bestpay.web.constants.PageConstants;

/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class WebHelper {

	protected static Logger logger = LoggerFactory.getLogger(AuthHelper.class);

	@Autowired
	private HttpServletRequest request;

	public boolean isOn() {
		return true;
	}

	public List<UserMenu> getMenuList() {
		List<UserMenu> menuList = new ArrayList<>();
		UserProfile userProfile = null;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth.isAuthenticated()) {
			CustomUserDetails cud = (CustomUserDetails) auth.getPrincipal();
			userProfile = cud.getProfile();
			menuList = userProfile.getMenusList();
		}
		return menuList;
	}

	public String baseUrl() {
		String host = request.getHeader("X-Forwarded-Host");
		return "//" + (!BaseUtil.isObjNull(host) ? host : request.getHeader("Host"));
	}

	public String redirectUrl() {
		String url = PageConstants.PAGE_HOME;
		try {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			if (BaseUtil.isObjNull(auth)) {
				return PageConstants.PAGE_SRC;
			}
			if (auth.isAuthenticated()) {
				CustomUserDetails cud = (CustomUserDetails) auth.getPrincipal();
				UserProfile userProfile = cud.getProfile();
				if (!BaseUtil.isObjNull(userProfile)) {
					url = redirectPageByRole(userProfile.getRolesList());
				}
			}
		} catch (Exception e) {
			logger.error("Error exception = {}", e);
		}
		return url;
	}

	public static String redirectPageByRole(List<UserRole> roleLst) {
		if (!BaseUtil.isListNull(roleLst)) {
			for (UserRole ur : roleLst) {
				if (PAGE_REDIRECT_MAP.containsKey(ur.getRoleCode())) {
					return PAGE_REDIRECT_MAP.get(ur.getRoleCode()).toString();
				}
			}
		}
		return null;
	}

	protected static final Map<String, Object> PAGE_REDIRECT_MAP = new HashMap<>();

	static {
		PAGE_REDIRECT_MAP.put(IdmRoleConstants.SYSTEM_ADMIN, PageConstants.PAGE_IDM_USR_LST);
	}

}