/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 * @author Atiqah Khairuddin
 *
 */
public class McAttendance implements Serializable, IQfCriteria<McAttendance> {

	private static final long serialVersionUID = 4484528769852221123L;

	private Integer tvlMcAttdId;

	private Integer mcProfId;

	private Integer tvlProfId;

	private Integer statusId;

	private List<Tvl> tvl;

	private TvlProfile tvlProfile;
	
	private Timestamp createDt;
	
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date attendanceDtFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date attendanceDtTo;


	public Integer getTvlMcAttdId() {
		return tvlMcAttdId;
	}


	public void setTvlMcAttdId(Integer tvlMcAttdId) {
		this.tvlMcAttdId = tvlMcAttdId;
	}


	public Integer getMcProfId() {
		return mcProfId;
	}


	public void setMcProfId(Integer mcProfId) {
		this.mcProfId = mcProfId;
	}


	public Integer getStatusId() {
		return statusId;
	}


	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}


	public List<Tvl> getTvl() {
		return tvl;
	}


	public void setTvl(List<Tvl> tvl) {
		this.tvl = tvl;
	}


	public Integer getTvlProfId() {
		return tvlProfId;
	}


	public void setTvlProfId(Integer tvlProfId) {
		this.tvlProfId = tvlProfId;
	}


	public TvlProfile getTvlProfile() {
		return tvlProfile;
	}


	public void setTvlProfile(TvlProfile tvlProfile) {
		this.tvlProfile = tvlProfile;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public Date getAttendanceDtFrom() {
		return attendanceDtFrom;
	}


	public void setAttendanceDtFrom(Date attendanceDtFrom) {
		this.attendanceDtFrom = attendanceDtFrom;
	}


	public Date getAttendanceDtTo() {
		return attendanceDtTo;
	}


	public void setAttendanceDtTo(Date attendanceDtTo) {
		this.attendanceDtTo = attendanceDtTo;
	}
}
