
package com.bestpay.be.sdk.model;


import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Form49_2", "Back", "LOR", "Front", "Form24_2", "Form49_1", "Form24_3", "DirectorBack", "BR",
		"DirectorFront", "Form24_1" })
public class Images {

	@JsonProperty("Form49_2")
	private String form492;

	@JsonProperty("Back")
	private String back;

	@JsonProperty("LOR")
	private String lOR;

	@JsonProperty("Front")
	private String front;

	@JsonProperty("Form24_2")
	private String form242;

	@JsonProperty("Form49_1")
	private String form491;

	@JsonProperty("Form24_3")
	private String form243;

	@JsonProperty("DirectorBack")
	private String directorBack;

	@JsonProperty("BR")
	private String bR;

	@JsonProperty("DirectorFront")
	private String directorFront;

	@JsonProperty("Form24_1")
	private String form241;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<>();


	@JsonProperty("Form49_2")
	public String getForm492() {
		return form492;
	}


	@JsonProperty("Form49_2")
	public void setForm492(String form492) {
		this.form492 = form492;
	}


	@JsonProperty("Back")
	public String getBack() {
		return back;
	}


	@JsonProperty("Back")
	public void setBack(String back) {
		this.back = back;
	}


	@JsonProperty("LOR")
	public String getLOR() {
		return lOR;
	}


	@JsonProperty("LOR")
	public void setLOR(String lOR) {
		this.lOR = lOR;
	}


	@JsonProperty("Front")
	public String getFront() {
		return front;
	}


	@JsonProperty("Front")
	public void setFront(String front) {
		this.front = front;
	}


	@JsonProperty("Form24_2")
	public String getForm242() {
		return form242;
	}


	@JsonProperty("Form24_2")
	public void setForm242(String form242) {
		this.form242 = form242;
	}


	@JsonProperty("Form49_1")
	public String getForm491() {
		return form491;
	}


	@JsonProperty("Form49_1")
	public void setForm491(String form491) {
		this.form491 = form491;
	}


	@JsonProperty("Form24_3")
	public String getForm243() {
		return form243;
	}


	@JsonProperty("Form24_3")
	public void setForm243(String form243) {
		this.form243 = form243;
	}


	@JsonProperty("DirectorBack")
	public String getDirectorBack() {
		return directorBack;
	}


	@JsonProperty("DirectorBack")
	public void setDirectorBack(String directorBack) {
		this.directorBack = directorBack;
	}


	@JsonProperty("BR")
	public String getBR() {
		return bR;
	}


	@JsonProperty("BR")
	public void setBR(String bR) {
		this.bR = bR;
	}


	@JsonProperty("DirectorFront")
	public String getDirectorFront() {
		return directorFront;
	}


	@JsonProperty("DirectorFront")
	public void setDirectorFront(String directorFront) {
		this.directorFront = directorFront;
	}


	@JsonProperty("Form24_1")
	public String getForm241() {
		return form241;
	}


	@JsonProperty("Form24_1")
	public void setForm241(String form241) {
		this.form241 = form241;
	}


	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return additionalProperties;
	}


	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		additionalProperties.put(name, value);
	}

}
