/**
 *
 */
package com.bestpay.web.test.payment;


import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.model.PgwResponse;
import com.bestpay.be.sdk.model.Transaction;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;


/**
 * @author chaithanya
 *
 */

@Controller
@RequestMapping(value = PageConstants.PAYMENT_RECEIPT_TEST)
public class ReceiptController extends AbstractController {

	private static final Logger logger = LoggerFactory.getLogger(ReceiptController.class);

	private static final String PDG_STATUS = "PENDING";


	@PostMapping()
	public ModelAndView paymentReceipt(HttpServletRequest request, HttpSession session) {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_TEST_RECEIPT);
		try {
			PgwResponse pgwResponse = new PgwResponse();
			pgwResponse.setB4u_tranId(request.getParameter("b4u_tranId"));
			Transaction transaction = getBeService().getTransDtlsById(pgwResponse.getB4u_tranId());
			String billname = transaction.getBillingName().toUpperCase();
			String desc = transaction.getResMsg().replaceAll("_", " ");
			transaction.setResMsg(desc);
			pgwResponse.setB4u_orderId(transaction.getOrderId());
			pgwResponse.setB4u_billingEmail(transaction.getBillingEmail());
			pgwResponse.setB4u_billingMobile(transaction.getBillingMobile());
			pgwResponse.setB4u_orderId(transaction.getOrderId());
			String createdate = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(transaction.getPaymentDt());
			pgwResponse.setB4u_billDate(createdate);
			pgwResponse.setB4u_description(transaction.getBillingInfo());
			pgwResponse.setB4u_billingName(billname);
			pgwResponse.setB4u_amount(transaction.getBillAmt().toString());
			pgwResponse.setB4u_actualAmt(transaction.getActAmt());
			pgwResponse.setB4u_transAmt(transaction.getTransRate());
			pgwResponse.setB4u_currency(transaction.getActCur());

			String status = transaction.getStatus();
			String payStatus = "";
			if (BaseUtil.isEquals(status, "SUCCESS")) {
				payStatus = "PAYMENT SUCCESS";
			} else if (BaseUtil.isEquals(status, "FAIL")) {
				payStatus = "PAYMENT FAILED";
			} else if (BaseUtil.isEquals(status, PDG_STATUS)) {
				payStatus = PDG_STATUS;
			}
			pgwResponse.setB4u_status(payStatus);
			mav.addObject("pgwResponse", pgwResponse);
		} catch (Exception e) {
			logger.error("payment receipt = {}", e);
		}
		return mav;
	}


	@GetMapping(value = "/{transid}")
	public ModelAndView paymentReceidpt(@PathVariable("transid") String transid, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_TEST_RECEIPT);
		try {
			PgwResponse pgwResponse = new PgwResponse();
			pgwResponse.setB4u_tranId(transid);
			Transaction transaction = getBeService().getTransDtlsById(pgwResponse.getB4u_tranId());
			String billname = transaction.getBillingName().toUpperCase();
			String desc = transaction.getResMsg().replaceAll("_", " ");
			transaction.setResMsg(desc);
			pgwResponse.setB4u_orderId(transaction.getOrderId());
			pgwResponse.setB4u_billingEmail(transaction.getBillingEmail());
			pgwResponse.setB4u_billingMobile(transaction.getBillingMobile());
			pgwResponse.setB4u_orderId(transaction.getOrderId());
			String createdate = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(transaction.getPaymentDt());
			pgwResponse.setB4u_billDate(createdate);
			pgwResponse.setB4u_description(transaction.getBillingInfo());
			pgwResponse.setB4u_billingName(billname);
			pgwResponse.setB4u_amount(transaction.getBillAmt().toString());
			pgwResponse.setB4u_actualAmt(transaction.getActAmt());
			pgwResponse.setB4u_transAmt(transaction.getTransRate());
			pgwResponse.setB4u_currency(transaction.getActCur());

			String status = transaction.getStatus();
			String payStatus = "";
			if (BaseUtil.isEquals(status, "SUCCESS")) {
				payStatus = "PAYMENT SUCCESS";
			} else if (BaseUtil.isEquals(status, "FAIL")) {
				payStatus = "PAYMENT FAILED";
			} else if (BaseUtil.isEquals(status, PDG_STATUS)) {
				payStatus = PDG_STATUS;
			}
			pgwResponse.setB4u_status(payStatus);
			mav.addObject("pgwResponse", pgwResponse);
		} catch (Exception e) {
			logger.error("paymentReceidpt = {}", e);
		}
		return mav;
	}

}
