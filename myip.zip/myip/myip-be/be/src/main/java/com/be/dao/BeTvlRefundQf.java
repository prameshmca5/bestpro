/**
 * 
 */
package com.be.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeTvlRefund;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.TvlRefund;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;

/**
 * @author Ramesh Pongiannan
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_REFUND_QF)
public class BeTvlRefundQf extends QueryFactory<BeTvlRefund> {

		
 	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;

	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}
	
	@Override
	public Specification<BeTvlRefund> searchByProperty(BeTvlRefund t) {
		return (Root<BeTvlRefund> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}

	@Override
	public List<BeTvlRefund> searchAllByProperty(BeTvlRefund t) {
		CriteriaQuery<BeTvlRefund> cq = cb.createQuery(BeTvlRefund.class);
		Root<BeTvlRefund> from = cq.from(BeTvlRefund.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}

	public List<BeTvlRefund> searchPaymentRefundPagination(TvlRefund dto, DataTableRequest<?> dataTableInRQ) {

		List<BeTvlRefund> result = new ArrayList<>();
		CriteriaQuery<BeTvlRefund> cq = cb.createQuery(BeTvlRefund.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlRefund> root = cq.from(BeTvlRefund.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq, true);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					cq.orderBy(getOrderByClause(cb, root, pagination));
				}
			}
			TypedQuery<BeTvlRefund> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}
	
	
	public BeTvlRefund searchbyRefund(TvlRefund dto) {

		BeTvlRefund result = null;
		CriteriaQuery<BeTvlRefund> cq = cb.createQuery(BeTvlRefund.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlRefund> root = cq.from(BeTvlRefund.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq, true);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeTvlRefund> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}
	
	public Long getCount(TvlRefund dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeTvlRefund> root = cq.from(BeTvlRefund.class);
		predicates.addAll(generateCriteria(cb, root, dto));
		
		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}
	
	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			BeTvlRefund dto = JsonUtil.transferToObject(criteria, BeTvlRefund.class);
			if (!BaseUtil.isObjNull(dto.getTvlRefundId())) {
				predicates.add(cb.equal(from.get("tvlRefundId"), dto.getTvlRefundId()));
			}
			
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void joinFetch(From<?, ?> from, List<Predicate> predicates, TvlRefund dto, CriteriaQuery<BeTvlRefund> cq, boolean allDtls ) {
		from.fetch("tvlPaymentDtl", JoinType.LEFT);
		from.fetch("refundTypeMtdt", JoinType.LEFT);
	}
 
}
