/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;
import java.util.List;

/**
 * @author michelle.angela
 *
 */
public class ConfigPaymentStage implements Serializable, IQfCriteria<ConfigPaymentBreakdown>  {

	private static final long serialVersionUID = 1292078708420374485L;

	private Integer pmtStageId;
	 
	private Metadata pmtIndMtdt;
	 
	private String pmtType;
	
	private String description;
	
	private Boolean isActive;

	private Integer sequence;
	
	private List<ConfigPaymentBreakdown> configPaymentBreakdowns;


	public Integer getPmtStageId() {
		return pmtStageId;
	}

	public void setPmtStageId(Integer pmtStageId) {
		this.pmtStageId = pmtStageId;
	}

	public Metadata getPmtIndMtdt() {
		return pmtIndMtdt;
	}

	public void setPmtIndMtdt(Metadata pmtIndMtdt) {
		this.pmtIndMtdt = pmtIndMtdt;
	}

	public String getPmtType() {
		return pmtType;
	}

	public void setPmtType(String pmtType) {
		this.pmtType = pmtType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	public List<ConfigPaymentBreakdown> getConfigPaymentBreakdowns() {
		return configPaymentBreakdowns;
	}

	public void setConfigPaymentBreakdowns(List<ConfigPaymentBreakdown> configPaymentBreakdowns) {
		this.configPaymentBreakdowns = configPaymentBreakdowns;
	}
}
