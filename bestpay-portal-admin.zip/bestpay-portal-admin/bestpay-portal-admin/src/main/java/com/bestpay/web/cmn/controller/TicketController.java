/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.constants.FileUploadConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.RefDocuments;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.sdk.model.Ticket;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.dm.sdk.exception.DmException;
import com.bestpay.dm.sdk.model.Documents;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.MenuDto;
import com.bestpay.idm.sdk.model.RoleMenu;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.constants.ProjectEnum;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.form.TicketDocsForm;
import com.bestpay.web.util.WebUtil;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;


/**
 * @author Atiqah Khairuddin
 * @since November 29, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_TICKET)
public class TicketController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(TicketController.class);

	private static final String TECHSTATLIST = "techStatList";

	private static final String TECHSTAT = "TECHSTAT";

	private static final String EXCEPTION = "Exception: {}";

	private static final String IDM_EXCEPTION = "IdmException: {}";

	private static final String TICKET = "ticket";

	private static final String TECHCAT = "TECHCAT";


	// view ticket
	@GetMapping
	public ModelAndView view(TicketDocsForm ticketList, BindingResult result) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TICKET, "tckt", null, "ticket-script");
		ticketList.setUserType(getCurrentUser().getUserRoleGroupCode());
		mav.addObject(TICKET, ticketList);
		mav.addObject(TECHSTATLIST, staticData.status(TECHSTAT));
		return mav;
	}


	// Search ticket
	@PostMapping(params = "search")
	public ModelAndView search(@ModelAttribute(TICKET) Ticket ticket, BindingResult result, HttpServletRequest request,
			HttpServletResponse response) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TICKET, TICKET, null, "ticket-script");
		ticket.setUserType(getCurrentUser().getUserRoleGroupCode());
		mav.addObject(TICKET, ticket);
		mav.addObject(TECHSTATLIST, staticData.status(TECHSTAT));
		return mav;
	}


	// Get paginated ticket
	@GetMapping(value = "/paginated")
	public @ResponseBody String getTicketPaginated(@ModelAttribute(TICKET) TicketDocsForm ticket,
			HttpServletRequest request) throws BeException {
		LOGGER.info("GET PAGINATED TICKET LIST....");
		UserProfile authUser = getCurrentUser();
		LOGGER.info("status = {}", ticket.getStatus());
		DataTableResults<Ticket> ticketList = null;
		try {
			Ticket tckt = dozerMapper.map(ticket, Ticket.class);
			tckt.setUserRoleGroupCode(authUser.getUserRoleGroupCode());
			tckt.setUserId(authUser.getUserId());
			ticketList = getBeService().searchTicket(tckt, getPaginationRequest(request, true));

			LOGGER.info("status list = {}", tckt.getStatus());
		} catch (Exception e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(e.getMessage());
		}

		return new Gson().toJson(ticketList);
	}


	// Reset view ticket
	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute(TICKET) @Validated TicketDocsForm ticket, BindingResult result,
			HttpServletRequest request, HttpSession session) throws BeException {
		TicketDocsForm ticketList = new TicketDocsForm();
		LOGGER.info("--reset--");
		return view(ticketList, result);
	}


	@GetMapping(value = "/update/{ticketId}")
	public ModelAndView viewUpdate(@PathVariable("ticketId") Integer ticketId,
			@ModelAttribute(TICKET) TicketDocsForm ticket, HttpServletRequest request) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TICKET_CRT, "create_ticket", null);
		Ticket tckt = getBeService().getTicketById(ticketId);
		TicketDocsForm ticket1 = dozerMapper.map(tckt, TicketDocsForm.class);
		Status statusCategory = getBeService().getStatusDescByStatusCodeAndType(TECHCAT, tckt.getCategory());
		Status status = getBeService().getStatusDescByStatusCodeAndType(TECHSTAT, tckt.getStatus());
		MenuDto idmMenu = getIdmService().findMenuByMenuCode(ticket1.getModule());
		if (!BaseUtil.isObjNull(ticket1.getSupportId())) {
			UserProfile userProfile = getIdmService().getUserProfileById(ticket1.getSupportId(), false, false);
			mav.addObject("userProfile", userProfile);
		}

		// Retrieve Merchant Logo
		Documents docs = new Documents();
		if (!BaseUtil.isObjNull(ticket1.getDocMgtId())) {
			try {
				docs = getDmService(ProjectEnum.BESTPAY).download(ticket1.getDocMgtId());
			} catch (IdmException e) {
				LOGGER.error(IDM_EXCEPTION, e.getMessage());
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (DmException e) {
				LOGGER.error("DmException: {}", e.getMessage());
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(EXCEPTION, e.getMessage());
			}
		}

		ticket1.setTicketAttach(docs);

		mav.addObject(TICKET, ticket1);
		mav.addObject("status", status);
		mav.addObject("statusCategory", statusCategory);
		String sdf = new SimpleDateFormat("dd-MM-yyyy hh:mm a").format(ticket1.getIssuerDate());
		mav.addObject("issueDate", sdf);
		mav.addObject("idmMenu", idmMenu);
		mav.addObject("techCatList", staticData.status(TECHCAT));
		mav.addObject(TECHSTATLIST, staticData.status(TECHSTAT));
		return mav;
	}


	@PostMapping(value = "/update/{ticketId}", params = "update")
	public ModelAndView updateTicket(@PathVariable Integer ticketId, @ModelAttribute(TICKET) Ticket ticket,
			BindingResult result) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TICKET_CRT, "create_ticket", null);
		UserProfile authUser = getCurrentUser();
		ticket.setUserId(authUser.getUserId());
		ticket.setUserRoleGroupCode(authUser.getUserRoleGroupCode());
		ticket.setTicketId(ticketId);
		TicketDocsForm ticket1 = new TicketDocsForm();

		if (BaseUtil.isEqualsCaseIgnore(authUser.getUserRoleGroupCode(), "ADM_ADMIN")) {
			ticket.setSupportId(ticket.getSupportId());
		}

		if (BaseUtil.isEqualsCaseIgnore(authUser.getUserRoleGroupCode(), "ADM_SUPPORT")) {
			ticket.setStatus(ticket.getStatus());
		}

		LOGGER.info("Result = {}", ticket.getSupportId());
		String listTicket = "";
		if (!result.hasErrors()) {
			try {
				getBeService().updateTicket(ticket);
				Ticket tckt = getBeService().getTicketById(ticket.getTicketId());
				ticket1 = dozerMapper.map(tckt, TicketDocsForm.class);
				Status statusCategory = getBeService().getStatusDescByStatusCodeAndType(TECHCAT,
						tckt.getCategory());
				Status status = getBeService().getStatusDescByStatusCodeAndType(TECHSTAT, tckt.getStatus());
				MenuDto idmMenu = getIdmService().findMenuByMenuCode(ticket1.getModule());
				mav.addObject("status", status);
				mav.addObject("statusCategory", statusCategory);
				mav.addObject("idmMenu", idmMenu);
				mav.addObject(TECHSTATLIST, staticData.status(TECHSTAT));

				// Retrieve Merchant Logo
				Documents docs = new Documents();
				if (!BaseUtil.isObjNull(ticket1.getDocMgtId())) {
					docs = downloadTicketAttachment(ticket1);
				}

				ticket1.setTicketAttach(docs);

				mav.addAllObjects(PopupBox.success(TICKET, null,
						messageService.getMessage(MessageConstants.SUCC_UPDATE_TICKET)));
				LOGGER.info("Successfully update ticket");
				mav.addAllObjects(PopupBox.success(null, null,
						listTicket + messageService.getMessage(MessageConstants.SUCC_UPDATE_TICKET),
						PageConstants.PAGE_TICKET));
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
		mav.addObject(TICKET, ticket1);
		return mav;
	}


	public Documents downloadTicketAttachment(TicketDocsForm ticket1) {
		Documents ticketName = new Documents();
		try {
			ticketName = getDmService(ProjectEnum.BESTPAY).download(ticket1.getDocMgtId());
		} catch (IdmException e) {
			LOGGER.error(IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (DmException e) {
			LOGGER.error("DmException: {}", e.getMessage());
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
		}
		return ticketName;
	}


	@ModelAttribute("refDocLst")
	public List<RefDocuments> getRefDocLst() throws BeException {
		return staticData.refDocList(FileUploadConstants.TICKET_ATTACH);
	}


	@ModelAttribute("userRoleMenuList")
	public List<RoleMenu> getUserRoleMenuList() {
		List<RoleMenu> roleMenuList = new ArrayList<>();
		try {
			List<RoleMenu> roleMenuList1 = getIdmService().findUserMenuByRoleCode("MER_ADMIN");

			for (RoleMenu roleMenu : roleMenuList1) {

				getCurrentUser().getProfId();

				LOGGER.info("role menu = {}", roleMenu);

				roleMenuList.add(roleMenu);
			}

		} catch (IdmException e) {
			LOGGER.error(IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
		}
		return roleMenuList;
	}


	@ModelAttribute("userByRoleList")
	public List<UserProfile> getUserByRole() {
		List<UserProfile> userProfileList = new ArrayList<>();
		try {
			List<UserProfile> userProfileList1 = getIdmService().getUserProfileByRoles("ADM_SUPPORT");

			for (UserProfile userProfile : userProfileList1) {

				getCurrentUser().getProfId();

				LOGGER.info("role menu = {}", userProfile);

				userProfileList.add(userProfile);
			}

		} catch (IdmException e) {
			LOGGER.error(IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
		}
		return userProfileList;
	}

}