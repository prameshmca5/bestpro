/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwMerchantContactRepository;
import com.bestpay.be.model.PgwMerchantContact;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since June 25, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_MER_CONTACT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MER_CONTACT_SVC)
public class PgwMerchantContactService extends AbstractService<PgwMerchantContact> {

	@Autowired
	private PgwMerchantContactRepository merchantContactDao;


	@Override
	public PgwMerchantContactRepository primaryDao() {
		return merchantContactDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantContact findMerContactByMerchantId(String merchantId) {
		return merchantContactDao.findMerContactByMerchantId(merchantId);
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public PgwMerchantContact findMerchantForBlacklistByEmail(String value) {
		return merchantContactDao.findMerchantForBlacklistByEmail(value);
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public PgwMerchantContact findMerchantForBlacklistByMobile(String value) {
		return merchantContactDao.findMerchantForBlacklistByMobile(value);
	}

}