package com.bestpay.pgw.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.PgwCtrlGen;
import com.bestpay.pgw.util.QualifierConstants;


/**
 * @author Chaithanya
 * @since 13/07/2018
 */
@Repository
@RepositoryDefinition(domainClass = PgwCtrlGen.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_CTRL_GEN_DAO)
public interface PgwCtrlGenRepository extends GenericRepository<PgwCtrlGen> {

	@Query("select u from PgwCtrlGen u where u.ctrlGenDt=:ctrlGenDt")
	public PgwCtrlGen findCtrlGenDt(@Param("ctrlGenDt") String ctrlGenDt);
}