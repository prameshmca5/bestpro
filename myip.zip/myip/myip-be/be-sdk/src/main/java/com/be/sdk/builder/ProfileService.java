/**
 * 
 */
package com.be.sdk.builder;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.AcctProfile;
import com.be.sdk.model.AirlinesProfile;
import com.be.sdk.model.DoctorProfile;
import com.be.sdk.model.McAddress;
import com.be.sdk.model.McProfile;
import com.util.pagination.DataTableResults;

/**
 * @author michelle.angela
 *
 */
public class ProfileService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;
	
	public ProfileService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}
	
	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}

	@Override
	public String url() {
		return url;
	}

	public AcctProfile register(AcctProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES);
		sb.append(BeUrlConstants.REGISTER);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, AcctProfile.class);
	}
	
	public AcctProfile getAcctProfile(AcctProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES);
		sb.append(BeUrlConstants.GET_DETAIL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, AcctProfile.class);
	}
	
	public AirlinesProfile getAirlinesProfile(AirlinesProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.AIRLINES);
		sb.append(BeUrlConstants.GET_DETAIL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, AirlinesProfile.class);
	}
	
	public AirlinesProfile registerAirline(AirlinesProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.AIRLINES);
		sb.append(BeUrlConstants.REGISTER);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, AirlinesProfile.class);
	}
	
	public McProfile getMcProfile(McProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.MC_PROFILE);
		sb.append(BeUrlConstants.GET_DETAIL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, McProfile.class);
	}
	
	public McProfile registerMc(McProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.MC_PROFILE);
		sb.append(BeUrlConstants.REGISTER);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, McProfile.class);
	}
	
	public AcctProfile update(AcctProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES);
		sb.append(BeUrlConstants.UPDATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, AcctProfile.class);
	}
	
	public DoctorProfile getDoctorProfile(DoctorProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.DOCTOR);
		sb.append(BeUrlConstants.GET_DETAIL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, DoctorProfile.class);
	}
	
	public DoctorProfile registerDoctor(DoctorProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.DOCTOR);
		sb.append(BeUrlConstants.REGISTER);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, DoctorProfile.class);
	}
	
	public DoctorProfile updateDoctor(DoctorProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.DOCTOR);
		sb.append(BeUrlConstants.UPDATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, DoctorProfile.class);
	}
	
	@SuppressWarnings("unchecked")
	public DataTableResults<DoctorProfile> searchDoctorPagination(DoctorProfile dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.DOCTOR);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}
	
	public List<DoctorProfile> getDoctorList(DoctorProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.DOCTOR);
		sb.append(BeUrlConstants.GET_LIST);
		DoctorProfile[] profileArray =  restTemplate().postForObject(getServiceURI(sb.toString()), dto, DoctorProfile[].class);
		return Arrays.asList(profileArray);
	}
	
	public List<McProfile> getMcList(McProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.MC_PROFILE);
		sb.append(BeUrlConstants.GET_LIST);
		McProfile[] profileArray =  restTemplate().postForObject(getServiceURI(sb.toString()), dto, McProfile[].class);
		return Arrays.asList(profileArray);
	}
	
	public List<AirlinesProfile> getAirlinesList(AirlinesProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.AIRLINES);
		sb.append(BeUrlConstants.GET_LIST);
		AirlinesProfile[] profileArray =  restTemplate().postForObject(getServiceURI(sb.toString()), dto, AirlinesProfile[].class);
		return Arrays.asList(profileArray);
	}
	
	@SuppressWarnings("unchecked")
	public DataTableResults<McProfile> searchMcProfilePagination(McProfile dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.MC_PROFILE);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}
	
	@SuppressWarnings("unchecked")
	public DataTableResults<McAddress> searchMcAddressPagination(McAddress dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.MC_ADDRESS);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}
	
	@SuppressWarnings("unchecked")
	public DataTableResults<AirlinesProfile> searchAirlinesPagination(AirlinesProfile dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.AIRLINES);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}
	
	public McAddress getMcAddress(McAddress dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.MC_ADDRESS);
		sb.append(BeUrlConstants.GET_DETAIL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, McAddress.class);
	}

	public McProfile updateMc(McProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.MC_PROFILE);
		sb.append(BeUrlConstants.UPDATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, McProfile.class);
	}
	
	public AirlinesProfile updateAirline(AirlinesProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.AIRLINES);
		sb.append(BeUrlConstants.UPDATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, AirlinesProfile.class);
	}

	public List<AirlinesProfile> checkAirlineExistByCertainCriteria(AirlinesProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROFILES).append(BeUrlConstants.AIRLINES);
		sb.append(BeUrlConstants.AIRLINE_EXIST);
		AirlinesProfile[] profileArray = restTemplate().postForObject(getServiceURI(sb.toString()), dto, AirlinesProfile[].class);
		return Arrays.asList(profileArray);
	}
}
