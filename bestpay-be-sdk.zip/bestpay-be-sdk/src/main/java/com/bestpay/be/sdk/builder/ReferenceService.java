/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.builder;


import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.bestpay.be.sdk.client.BeRestTemplate;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Bank;
import com.bestpay.be.sdk.model.Category;
import com.bestpay.be.sdk.model.Channel;
import com.bestpay.be.sdk.model.City;
import com.bestpay.be.sdk.model.Config;
import com.bestpay.be.sdk.model.Country;
import com.bestpay.be.sdk.model.Nationality;
import com.bestpay.be.sdk.model.RefDocuments;
import com.bestpay.be.sdk.model.RefEmbedRequest;
import com.bestpay.be.sdk.model.RefEmbedResponse;
import com.bestpay.be.sdk.model.RefFpxResponseCodeDto;
import com.bestpay.be.sdk.model.RefStatus;
import com.bestpay.be.sdk.model.ReferralMultiChannel;
import com.bestpay.be.sdk.model.RelationShip;
import com.bestpay.be.sdk.model.State;
import com.bestpay.be.sdk.model.StaticList;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.sdk.model.SubscriptionPlan;
import com.bestpay.be.sdk.util.BaseUtil;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
public class ReferenceService extends AbstractService {

	private BeRestTemplate restTemplate;

	private Properties prop;

	private String url;


	public ReferenceService(BeRestTemplate restTemplate, Properties prop, String url) {
		this.restTemplate = restTemplate;
		this.prop = prop;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public Properties prop() {
		return prop;
	}


	@Override
	public String url() {
		return url;
	}


	public boolean evict() throws BeException {
		return evict(null);
	}


	public boolean evict(String prefixKey) throws BeException {
		StringBuilder sbUrl = new StringBuilder();
		sbUrl.append(BeUrlConstants.REFERENCE).append("/evict");
		if (!BaseUtil.isObjNull(prefixKey)) {
			sbUrl.append("?prefixKey=" + prefixKey);
		}
		return restTemplate().getForObject(getServiceURI(sbUrl.toString()), boolean.class);
	}


	@SuppressWarnings("unchecked")
	public Map<String, String> findAllConfig() throws BeException {
		return restTemplate().getForObject(getServiceURI(BeUrlConstants.REFERENCE + BeUrlConstants.APJ_CONFIG),
				HashMap.class);
	}


	public List<Config> findEqmConfig() throws BeException {
		Config[] svcResp = restTemplate().getForObject(BeUrlConstants.APJ_CONFIG, Config[].class);
		return Arrays.asList(svcResp);
	}


	public List<Config> findEqmConfig(String configAgency) throws BeException {
		StringBuilder sbUrl = new StringBuilder();
		sbUrl.append(BeUrlConstants.APJ_CONFIG).append("/{configAgency}");

		Map<String, Object> params = new HashMap<>();
		params.put("configAgency", configAgency);

		Config[] svcResp = restTemplate().getForObject(sbUrl.toString(), Config[].class, params);
		return Arrays.asList(svcResp);
	}


	public List<Country> getRefCountryLst() throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REF_REF_COUNTRY);
		Country[] refStats = restTemplate().getForObject(getServiceURI(sb.toString()), Country[].class);
		return Arrays.asList(refStats);
	}


	public List<City> findByAllCities() throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.CITY);
		City[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), City[].class);

		return Arrays.asList(svcResp);
	}


	// find city
	public City findByCityCode(String cityCode) throws BeException {
		return restTemplate().getForObject(getServiceURI(BeUrlConstants.CITY + "/" + cityCode), City.class);
	}


	// find city by city and state code
	public City fidCityByCityStateCode(String cityCode, String stateCode) throws BeException {
		return restTemplate().getForObject(getServiceURI(BeUrlConstants.CITY + "/" + cityCode + "/" + stateCode),
				City.class);
	}


	public List<RefDocuments> getRefDocLst() throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE + "/refDocList");
		RefDocuments[] refStats = restTemplate().getForObject(getServiceURI(sb.toString()), RefDocuments[].class);
		return Arrays.asList(refStats);
	}


	// list status
	public List<Status> findByAllStatus() throws BeException {
		Status[] svcResp = restTemplate().getForObject(getServiceURI(BeUrlConstants.STATUS), Status[].class);
		return Arrays.asList(svcResp);
	}


	// find status
	public Status findByStatusCodeAndType(String statusCode, String type) throws BeException {
		Map<String, Object> params = new HashMap<>();
		params.put("statusCode", statusCode);
		params.put("type", type);
		return restTemplate().getForObject(getServiceURI(BeUrlConstants.STATUS + "/{statusCode}" + "/{type}"),
				Status.class, params);
	}


	// add status
	public Status addStatus(Status status) throws BeException {
		return restTemplate().postForObject(getServiceURI(BeUrlConstants.STATUS), status, Status.class);
	}


	// update status
	public boolean updatStatus(Status status) throws BeException {
		return restTemplate().putForObject(getServiceURI(BeUrlConstants.STATUS), status, boolean.class, null);
	}


	public StaticList all() throws BeException {
		StringBuilder sbUrl = new StringBuilder();
		sbUrl.append(BeUrlConstants.REFERENCE);
		return restTemplate().getForObject(getServiceURI(sbUrl.toString()), StaticList.class);
	}


	// list relation
	public List<RelationShip> findAllRelationShips() throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_RELATIONSHIP);
		RelationShip[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), RelationShip[].class);
		return Arrays.asList(svcResp);
	}


	// list of state
	public List<State> findAllState() throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_STATE);
		State[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), State[].class);
		return Arrays.asList(svcResp);
	}


	// list of state with countries
	public List<Country> allCountry() throws BeException {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_COUNTRY);

		Country[] countryArray = restTemplate().getForObject(getServiceURI(sb.toString()), Country[].class);

		return Arrays.asList(countryArray);
	}


	// list of nationality
	public List<Nationality> findAllNationality() throws BeException {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_NATIONALITY);

		Nationality[] nationalityArray = restTemplate().getForObject(getServiceURI(sb.toString()),
				Nationality[].class);

		return Arrays.asList(nationalityArray);
	}


	// nationality by code
	public Nationality findByNationalityCode(String ntnltyCode) throws BeException {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_NATIONALITY_CODE);
		sb.append("/" + ntnltyCode);

		return restTemplate().getForObject(getServiceURI(sb.toString()), Nationality.class);
	}


	// nationality by description
	public Nationality findNationalityByDesc(String ntnltyDescEn) throws BeException {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_NATIONALITY_DESC);
		sb.append("/" + ntnltyDescEn);

		return restTemplate().getForObject(getServiceURI(sb.toString()), Nationality.class);
	}


	public List<Status> getAllStatus() throws BeException {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_STAUS);

		Status[] statusArray = restTemplate().getForObject(getServiceURI(sb.toString()), Status[].class);

		return Arrays.asList(statusArray);
	}


	public List<Category> getAllCategory() throws BeException {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_CAT);

		Category[] catArray = restTemplate().getForObject(getServiceURI(sb.toString()), Category[].class);

		return Arrays.asList(catArray);
	}


	public RefEmbedResponse getRrefData(RefEmbedRequest refEmbedRequest) throws BeException {
		return restTemplate().postForObject(getServiceURI(BeUrlConstants.REFERENCE + "/refData"), refEmbedRequest,
				RefEmbedResponse.class);
	}


	public List<Channel> getAllChannel() throws BeException {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_CHANNEL);

		Channel[] chanArray = restTemplate().getForObject(getServiceURI(sb.toString()), Channel[].class);

		return Arrays.asList(chanArray);
	}


	public List<Bank> getAllBank() throws BeException {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_BANK);

		Bank[] bankArray = restTemplate().getForObject(getServiceURI(sb.toString()), Bank[].class);

		return Arrays.asList(bankArray);
	}


	public List<RefStatus> getRefStatus(String refCode) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append("/search");
		sb.append("/" + refCode);

		RefStatus[] refStatusArray = restTemplate().getForObject(getServiceURI(sb.toString()), RefStatus[].class);

		return Arrays.asList(refStatusArray);
	}


	public List<SubscriptionPlan> getAllSubscriptionPlan() throws BeException {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_SUB_PLAN);

		SubscriptionPlan[] subPlanArray = restTemplate().getForObject(getServiceURI(sb.toString()),
				SubscriptionPlan[].class);

		return Arrays.asList(subPlanArray);
	}


	public List<RefFpxResponseCodeDto> getAllFpxResCode() throws BeException {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_FPX_RESPOND_CODE);

		RefFpxResponseCodeDto[] fpxResCodeArray = restTemplate().getForObject(getServiceURI(sb.toString()),
				RefFpxResponseCodeDto[].class);

		return Arrays.asList(fpxResCodeArray);
	}


	public List<ReferralMultiChannel> getRefMultiChannelLst() throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_REF_MULTI_CHANNEL);
		ReferralMultiChannel[] refStats = restTemplate().getForObject(getServiceURI(sb.toString()),
				ReferralMultiChannel[].class);
		return Arrays.asList(refStats);
	}

}