/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwMerchantCompanyBankDetails;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerCompBankDetails;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;

/**
 * @author Atiqah Khairuddin
 * @since May 29, 2019
 */
@RestController
@RequestMapping(BeUrlConstants.MER_COMP_BANK_DETAILS)
public class MerCompBankDetailsRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MerCompBankDetailsRestController.class);

	String skipValues = "[-+.^:,()*@/]";

	@Autowired
	protected ReferenceRestController referenceRestController;

	@PostMapping(value = BeUrlConstants.PAGINATED, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<MerCompBankDetails> searchMerCompBankDetailsPaginated(
			@Valid @RequestBody MerCompBankDetails merCompBankDetails, HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwMerchantCompanyBankDetails> result = pgwMerchantCompanyBankDetailsService
				.searchMerCompBankDetails(merCompBankDetails, dataTableInRQ);
		DataTableResults<MerCompBankDetails> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			dataTableInResp.setDraw(result.getDraw());
			dataTableInResp.setError(result.getError());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<MerCompBankDetails> bpLst = new ArrayList<>();
				for (PgwMerchantCompanyBankDetails bbp : result.getData()) {
					MerCompBankDetails trustee = dozerMapper.map(bbp, MerCompBankDetails.class);
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		LOGGER.info("Merchant company referral registration = {}", dataTableInResp.getData());
		return dataTableInResp;
	}

	@GetMapping(value = "/{compRefId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerCompBankDetails getBenDetailsByCompRefId(@PathVariable String compRefId) {

		PgwMerchantCompanyBankDetails pgwMerchantCompanyBankDetails = super.pgwMerchantCompanyBankDetailsService
				.findBeneficiaryByCompRefId(compRefId);

		MerCompBankDetails merCompBankDetails = new MerCompBankDetails();
		if (!BaseUtil.isObjNull(pgwMerchantCompanyBankDetails)) {
			merCompBankDetails = dozerMapper.map(pgwMerchantCompanyBankDetails, MerCompBankDetails.class);
		}

		return merCompBankDetails;
	}

	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerCompBankDetails updateBeneficiarySetting(@Valid @RequestBody MerCompBankDetails merCompBankDetails,
			HttpServletRequest request, HttpServletResponse response) throws BeException {

		if (merCompBankDetails == null) {// accountSetting null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		if (StringUtils.isBlank(merCompBankDetails.getCompRefId())) {// no merchant
			// name
			throw new BeException(BeErrorCodeEnum.I400IDM137, new String[] { "Company Ref Id", "Beneficiary Details" });
		}

		PgwMerchantCompanyBankDetails pgwMerchantCompanyBankDetails = new PgwMerchantCompanyBankDetails();
		PgwMerchantCompanyBankDetails merchantCompanyBankDetails = super.pgwMerchantCompanyBankDetailsService
				.findBeneficiaryByCompBankId(merCompBankDetails.getCompBankId());

		if (BaseUtil.isObjNull(merchantCompanyBankDetails)) {
			pgwMerchantCompanyBankDetails.setCompRefId(merCompBankDetails.getCompRefId());
			pgwMerchantCompanyBankDetails.setBankName(merCompBankDetails.getBankName().toUpperCase());
			pgwMerchantCompanyBankDetails.setBankAccName(merCompBankDetails.getBankAccName().toUpperCase());
			pgwMerchantCompanyBankDetails.setBankAccNo(merCompBankDetails.getBankAccNo());
			pgwMerchantCompanyBankDetails.setBankBranch(merCompBankDetails.getBankBranch().toUpperCase());
			pgwMerchantCompanyBankDetails.setBankLocation(merCompBankDetails.getBankLocation());
			pgwMerchantCompanyBankDetails.setBankCountry(merCompBankDetails.getBankCountry());
			pgwMerchantCompanyBankDetails.setCreateId(merCompBankDetails.getCreateId());
			super.pgwMerchantCompanyBankDetailsService.create(pgwMerchantCompanyBankDetails);
		} else {
			merchantCompanyBankDetails.setBankName(merCompBankDetails.getBankName().toUpperCase());
			merchantCompanyBankDetails.setBankAccName(merCompBankDetails.getBankAccName().toUpperCase());
			merchantCompanyBankDetails.setBankAccNo(merCompBankDetails.getBankAccNo());
			merchantCompanyBankDetails.setBankBranch(merCompBankDetails.getBankBranch().toUpperCase());
			merchantCompanyBankDetails.setBankLocation(merCompBankDetails.getBankLocation());
			merchantCompanyBankDetails.setBankCountry(merCompBankDetails.getBankCountry());
			merchantCompanyBankDetails.setUpdateId(merCompBankDetails.getCreateId());
			super.pgwMerchantCompanyBankDetailsService.update(merchantCompanyBankDetails);
		}

		MerCompBankDetails compBankDet = new MerCompBankDetails();
		PgwMerchantCompanyBankDetails updatBenDetails = super.pgwMerchantCompanyBankDetailsService
				.findBeneficiaryByCompRefId(merCompBankDetails.getCompRefId());
		if (!BaseUtil.isObjNull(updatBenDetails)) {
			compBankDet = dozerMapper.map(updatBenDetails, MerCompBankDetails.class);
		}
		return compBankDet;
	}

	@GetMapping(value = BeUrlConstants.GET_BANK_DETAILS_BY_COMPBANKID + "/{compBankId}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MerCompBankDetails getBenDetailsByCompBankId(@PathVariable Integer compBankId) {

		PgwMerchantCompanyBankDetails pgwMerchantCompanyBankDetails = super.pgwMerchantCompanyBankDetailsService
				.findBeneficiaryByCompBankId(compBankId);

		MerCompBankDetails merCompBankDetails = new MerCompBankDetails();
		if (!BaseUtil.isObjNull(pgwMerchantCompanyBankDetails)) {
			merCompBankDetails = dozerMapper.map(pgwMerchantCompanyBankDetails, MerCompBankDetails.class);
		}

		return merCompBankDetails;
	}
}
