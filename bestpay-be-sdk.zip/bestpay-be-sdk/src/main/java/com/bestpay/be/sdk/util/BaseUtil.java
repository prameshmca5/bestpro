/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.util;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.util.List;

import org.apache.commons.lang3.text.WordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bestpay.be.sdk.constants.BaseConstants;
import com.bestpay.be.sdk.exception.BeException;

/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
public class BaseUtil {

	private BaseUtil() {
		throw new IllegalStateException("Utility class");
	}

	protected static Logger logger = LoggerFactory.getLogger(BaseUtil.class);

	private static final String ERROR_ENCRYPTING = "Error while encrypting: ";

	/***
	 * This method will return a trim string, if object passing is null it will
	 * return EMPTY STRING("")
	 *
	 * @param obj Object that are passed in
	 * @return a string representation of the object
	 * @exception Exception if have error occur
	 */
	public static String getStr(Object obj) {
		if (obj != null) {
			return obj.toString().trim();
		} else {
			return BaseConstants.EMPTY_STRING;
		}
	}

	/**
	 * This method will return a trim string, if object passing is null it will
	 * return null. This function needed as JMS functions need to maintain the null
	 * values rather than empty string
	 *
	 * @param obj Object that are passed in
	 * @return a string representation of the object
	 */
	public static String getStrWithNull(Object obj) {
		if (obj != null) {
			return obj.toString().trim();
		} else {
			return null;
		}
	}

	/***
	 * This method will return a trim UPPERCASE string, if object passing is null it
	 * will return EMPTY STRING("")
	 *
	 * @param obj Object that are passed in
	 * @return a string representation of the object
	 * @exception Exception if have error occur
	 */
	public static String getStrUpper(Object obj) {
		if (obj != null) {
			return obj.toString().trim().toUpperCase();
		} else {
			return BaseConstants.EMPTY_STRING;
		}
	}

	/**
	 * This method is same with getStrWithNull() The returned string will be either
	 * in UPPERCASE or null values
	 *
	 * @param obj Object that are passed in
	 * @return a string representation of the object with UPPERCASE
	 */
	public static String getStrUpperWithNull(Object obj) {
		if (obj != null && !getStr(obj).equalsIgnoreCase("NULL")) {
			return obj.toString().trim().toUpperCase();
		} else {
			return null;
		}
	}

	public static String getStrLower(Object obj) {
		if (obj != null) {
			return obj.toString().trim().toLowerCase();
		} else {
			return BaseConstants.EMPTY_STRING;
		}
	}

	/**
	 * This method will return string to Title Case
	 *
	 * @param obj
	 * @return String in Title Case
	 */
	public static String getStrTitle(Object obj) {
		if (!isObjNull(obj)) {
			String modStr = obj.toString().trim().toLowerCase();
			String[] strArr = modStr.split(BaseConstants.SPACE);
			StringBuilder newStr = new StringBuilder();
			for (int i = 0; i < strArr.length; i++) {
				strArr[i] = Character.toUpperCase(strArr[i].charAt(0)) + strArr[i].substring(1);
				newStr.append(strArr[i]);
				newStr.append("");
			}
			return newStr.toString().trim();
		} else {
			return BaseConstants.EMPTY_STRING;
		}
	}

	public static Integer getInt(Object obj) {
		if (obj != null) {
			try {
				return Integer.parseInt(obj.toString().trim());
			} catch (Exception e) {
				logger.error(ERROR_ENCRYPTING, e);
				return BaseConstants.ZERO;
			}
		} else {
			return BaseConstants.ZERO;
		}
	}

	/**
	 * This method will return a double value.
	 *
	 * @param obj the number to obtain double value
	 * @return
	 */
	public static Double getDouble(Object obj) {
		return getDouble(obj, null);
	}

	/**
	 * This method will return a double value based on decimal format pattern.
	 *
	 * @param obj     the number to obtain double value
	 * @param pattern decimal format pattern. eg. ##.##
	 * @return
	 */
	public static Double getDouble(Object obj, String pattern) {
		if (obj != null) {
			try {
				double d = Double.parseDouble(obj.toString().trim());

				if (!isObjNull(pattern)) {
					DecimalFormat df = new DecimalFormat(pattern);
					return Double.parseDouble(df.format(d));
				} else {
					return d;
				}
			} catch (Exception e) {
				logger.error(ERROR_ENCRYPTING, e);
				return (double) 0;
			}
		} else {
			return (double) 0;
		}
	}

	/**
	 * Convert Object value to BigDecimal value. Object can be any String, Double,
	 * Integer, Long, etc
	 *
	 * @param input Object which need to be convert to BigDecimal
	 * @return A BigDecimal value for specified Object
	 */
	public static BigDecimal getBigDecimal(Object input) {
		try {
			if (input instanceof String) {
				return new BigDecimal((String) input);
			} else if (input instanceof Double) {
				return BigDecimal.valueOf((Double) input);
			} else if (input instanceof Integer) {
				return BigDecimal.valueOf((Integer) input);
			} else if (input instanceof Long) {
				return BigDecimal.valueOf((Long) input);
			} else if (input instanceof BigInteger) {
				return new BigDecimal((BigInteger) input);
			} else if (input instanceof Float) {
				return BigDecimal.valueOf((Float) input);
			} else if (input instanceof Short) {
				return new BigDecimal((Short) input);
			} else if (input instanceof BigDecimal) {
				return (BigDecimal) input;
			} else {
				return new BigDecimal(BaseConstants.ZERO);
			}
		} catch (Exception e) {
			logger.error(ERROR_ENCRYPTING, e);
			return new BigDecimal(BaseConstants.ZERO);
		}
	}

	public static Integer getListSize(List<?> o) {
		if (o != null && !o.isEmpty()) {
			return o.size();
		} else {
			return BaseConstants.ZERO;
		}
	}

	public static Boolean isListNull(List<?> o) {
		return !(o != null && getListSize(o) > 0);
	}

	public static Boolean isListZero(List<?> o) {
		return (!isListNull(o) && o.isEmpty());
	}

	public static Boolean isListNullZero(List<?> o) {
		return (isListNull(o) || (!isListNull(o) && o.isEmpty()));
	}

	public static boolean isEquals(String oriSrc, String compareSrc) {
		return (oriSrc != null && getStr(oriSrc).equals(getStr(compareSrc)));
	}

	public static boolean isEqualsCaseIgnore(String oriSrc, String compareSrc) {
		return (oriSrc != null && getStr(oriSrc).equalsIgnoreCase(getStr(compareSrc)));
	}

	public static boolean isEqualsAny(String oriSrc, String compareSrc) {
		boolean isEqual = false;
		String[] compareSrcArr = compareSrc.split(",");
		for (String element : compareSrcArr) {
			if (oriSrc != null && getStr(oriSrc).equals(getStr(element))) {
				isEqual = true;
				break;
			}
		}

		return isEqual;
	}

	public static boolean isEqualsCaseIgnoreAny(String oriSrc, String compareSrc) {
		boolean isEqual = false;
		String[] compareSrcArr = compareSrc.split(",");
		for (String element : compareSrcArr) {
			if (oriSrc != null && getStr(oriSrc).equalsIgnoreCase(getStr(element))) {
				isEqual = true;
				break;
			}
		}

		return isEqual;
	}

	public static boolean isObjNull(Object obj) {
		return !(obj != null && getStr(obj).length() > 0);
	}

	public static Boolean isListNullAndZero(List<?> o) {
		return (isListNull(o) || (!isListNull(o) && o.isEmpty()));
	}

	public static Boolean isMaxNoReached(Integer supplyNo, Integer compareNo) {
		return (supplyNo > compareNo);
	}

	/**
	 * Copies a range of characters into a new String.
	 *
	 * @param input String need to be sub string
	 * @param start the offset of the first character
	 * @param end   the offset one past the last character
	 * @return a new String containing the characters from start to end - 1
	 */
	public static String subString(String input, int start, int end) {
		if (input != null) {
			return getStr(input).substring(start, end);
		} else {
			return BaseConstants.EMPTY_STRING;
		}
	}

	/**
	 * Copies a range of characters into a new String.
	 *
	 * @param input String need to be sub string
	 * @param start the offset of the first character
	 * @return a new String containing the characters from start to the end of the
	 *         string
	 */
	public static String subString(String input, int start) {
		if (input != null) {
			return getStr(input).substring(start);
		} else {
			return BaseConstants.EMPTY_STRING;
		}
	}

	/**
	 * Check if the email address is valid (Required JavaMail class)
	 *
	 * @param email The email address to be checked
	 * @return True is valid email address, False otherwise
	 * @author mhazwanh
	 */
	public static boolean isValidEmailAddress(String email) {
		boolean result = false;
		if (!isObjNull(email)) {
			result = email.matches("/[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}/");
		}
		return result;
	}

	/**
	 * Transfer all properties to Target object from Originating (Source)
	 * object.<br>
	 * Change the prefix naming for the target object field/method.
	 *
	 * @param obj1       origin object where the properties being referred
	 * @param obj2       target object to retrieve the properties
	 * @param obj1Prefix origin object prefix for field/method name
	 * @param obj2Prefix target object prefix for field/method name
	 */
	public static Object transferProperties(Object obj1, Object obj2, String obj1Prefix, String obj2Prefix)
			throws BeException {

		// Loop all Object 1 fields
		for (Field f : obj1.getClass().getDeclaredFields()) {

			String obj1FieldName = f.getName();
			String obj2FieldName = obj1FieldName.replace(obj1Prefix, obj2Prefix);
			String obj1GetMethodName = "get" + WordUtils.capitalize(obj1FieldName);
			String obj2SetMethodName = "set" + WordUtils.capitalize(obj2FieldName);

			try {
				// Fetch Object 1 Data
				Object obj1FieldData = transferFetchObjectData1(obj1, obj1GetMethodName);

				// Set Object 2 Data with Object 1 Data
				transferFetchObjectData2(f, obj1FieldData, obj2SetMethodName, obj2);

			} catch (Exception e) {
				e.getMessage();
			}

		}
		return obj2;
	}

	private static Object transferFetchObjectData1(Object obj1, String obj1GetMethodName) throws BeException {
		try {
			return obj1.getClass().getMethod(obj1GetMethodName).invoke(obj1);
		} catch (Exception e) {
			throw new BeException("Data not found for Object 1 Method [" + obj1GetMethodName + "]");
		}
	}

	private static void transferFetchObjectData2(Field f, Object obj1FieldData, String obj2SetMethodName, Object obj2)
			throws BeException {

		try {
			obj2.getClass().getMethod(obj2SetMethodName, f.getType()).invoke(obj2, obj1FieldData);
		} catch (Exception e) {
			throw new BeException("Object 2 Method not found [" + obj2SetMethodName + "]");
		}
	}

	/**
	 * Transfer all properties to Target object from Originating (Source)
	 * object.<br>
	 * Change the prefix naming for the target object field/method.
	 *
	 * @param obj1            origin object where the properties being referred
	 * @param obj2            target object to retrieve the properties
	 * @param obj1Prefix      origin object prefix for field/method name
	 * @param obj2Prefix      target object prefix for field/method name
	 * @param transEmptyField tranfer empty values
	 */
	public static Object transferProperties(Object obj1, Object obj2, String obj1Prefix, String obj2Prefix,
			boolean transEmptyField) {

		// Loop all Object 1 fields
		for (Field f : obj1.getClass().getDeclaredFields()) {

			String obj1FieldName = f.getName();
			String obj2FieldName = obj1FieldName.replace(obj1Prefix, obj2Prefix);
			String obj1GetMethodName = "get" + WordUtils.capitalize(obj1FieldName);
			String obj2SetMethodName = "set" + WordUtils.capitalize(obj2FieldName);

			try {
				// Fetch Object 1 Data
				Object obj1FieldData = fetchObjectData1(obj1, obj1GetMethodName);

				// Set Object 2 Data with Object 1 Data
				fetchObjectData2(f, transEmptyField, obj1FieldData, obj2SetMethodName, obj2FieldName, obj2);

			} catch (Exception e) {
				e.getMessage();
			}

		}
		return obj2;
	}

	private static Object fetchObjectData1(Object obj1, String obj1GetMethodName) throws BeException {
		try {
			return obj1.getClass().getMethod(obj1GetMethodName).invoke(obj1);
		} catch (Exception e) {
			throw new BeException("Data not found for Object 1 Method [" + obj1GetMethodName + "]");
		}
	}

	private static void fetchObjectData2(Field f, boolean transEmptyField, Object obj1FieldData,
			String obj2SetMethodName, Object obj2FieldName, Object obj2) throws BeException {
		try {
			if (!transEmptyField) {
				if (!isObjNull(obj1FieldData)) {
					obj2.getClass().getMethod(obj2SetMethodName, f.getType()).invoke(obj2, obj1FieldData);
					obj2.getClass().getMethod("get" + WordUtils.capitalize((String) obj2FieldName)).invoke(obj2);
				}
			} else {
				obj2.getClass().getMethod(obj2SetMethodName, f.getType()).invoke(obj2, obj1FieldData);
			}
		} catch (Exception e) {
			throw new BeException("Object 2 Method not found [" + obj2SetMethodName + "]");
		}
	}

	/**
	 * Check if has number, change that number to bigDecimal presentation
	 *
	 * @param string
	 * @return string with number presented as bigDecimal (has ',' symbol in number)
	 * @author nazmiKadim
	 */
	public static String changeNumberFormatInString(String str) {
		DecimalFormat df = new DecimalFormat("#,###.00");
		StringBuilder sb = new StringBuilder();
		String[] split = str.split("\\s+");
		for (String element : split) {
			Object dummy = element.replaceAll("\\D+", "");
			if (!isObjNull(dummy)) {
				String number = df.format(getBigDecimal(element));
				sb.append(number + " ");
			} else {
				sb.append(element + " ");
			}
		}
		return sb.toString();
	}
}
