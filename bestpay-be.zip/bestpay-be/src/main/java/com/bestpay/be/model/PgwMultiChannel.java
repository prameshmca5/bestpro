/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@Entity
@Table(name = "PGW_MULTI_CHANNEL")
public class PgwMultiChannel extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "MULTI_CHNL_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer mulChannelId;

	@Column(name = "MERCHANT_ID")
	private String merchantId;

	@Column(name = "CHANNEL")
	private String channel;

	@Column(name = "ENABLE")
	private Integer enable;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "RATE")
	private Double rate;

	@Column(name = "COST")
	private Double cost;

	@Column(name = "ADDITIONAL_COST")
	private Double additionalCost;

	@Column(name = "MONTHLY_FEE")
	private Double monthlyFee;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public PgwMultiChannel() {
		// pgwMultiChannel backend model
	}


	public Integer getMulChannelId() {
		return mulChannelId;
	}


	public void setMulChannelId(Integer mulChannelId) {
		this.mulChannelId = mulChannelId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public Integer getEnable() {
		return enable;
	}


	public void setEnable(Integer enable) {
		this.enable = enable;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Double getRate() {
		return rate;
	}


	public void setRate(Double rate) {
		this.rate = rate;
	}


	public Double getCost() {
		return cost;
	}


	public void setCost(Double cost) {
		this.cost = cost;
	}


	public Double getAdditionalCost() {
		return additionalCost;
	}


	public void setAdditionalCost(Double additionalCost) {
		this.additionalCost = additionalCost;
	}


	public Double getMonthlyFee() {
		return monthlyFee;
	}


	public void setMonthlyFee(Double monthlyFee) {
		this.monthlyFee = monthlyFee;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}