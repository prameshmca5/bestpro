
package com.bestpay.pgw.sdk.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cdd",
    "edd",
    "ofacID",
    "pepID",
    "transactionAmountPerDay",
    "transactionAmountPerMonth",
    "transactionBranchesPerMonth",
    "transactionIntervalsPerMonth"
})
public class RiskProfile {

    @JsonProperty("cdd")
    private Cdd cdd;
    @JsonProperty("edd")
    private Edd edd;
    @JsonProperty("ofacID")
    private String ofacID;
    @JsonProperty("pepID")
    private String pepID;
    @JsonProperty("transactionAmountPerDay")
    private String transactionAmountPerDay;
    @JsonProperty("transactionAmountPerMonth")
    private String transactionAmountPerMonth;
    @JsonProperty("transactionBranchesPerMonth")
    private String transactionBranchesPerMonth;
    @JsonProperty("transactionIntervalsPerMonth")
    private String transactionIntervalsPerMonth;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cdd")
    public Cdd getCdd() {
        return cdd;
    }

    @JsonProperty("cdd")
    public void setCdd(Cdd cdd) {
        this.cdd = cdd;
    }

    @JsonProperty("edd")
    public Edd getEdd() {
        return edd;
    }

    @JsonProperty("edd")
    public void setEdd(Edd edd) {
        this.edd = edd;
    }

    @JsonProperty("ofacID")
    public String getOfacID() {
        return ofacID;
    }

    @JsonProperty("ofacID")
    public void setOfacID(String ofacID) {
        this.ofacID = ofacID;
    }

    @JsonProperty("pepID")
    public String getPepID() {
        return pepID;
    }

    @JsonProperty("pepID")
    public void setPepID(String pepID) {
        this.pepID = pepID;
    }

    @JsonProperty("transactionAmountPerDay")
    public String getTransactionAmountPerDay() {
        return transactionAmountPerDay;
    }

    @JsonProperty("transactionAmountPerDay")
    public void setTransactionAmountPerDay(String transactionAmountPerDay) {
        this.transactionAmountPerDay = transactionAmountPerDay;
    }

    @JsonProperty("transactionAmountPerMonth")
    public String getTransactionAmountPerMonth() {
        return transactionAmountPerMonth;
    }

    @JsonProperty("transactionAmountPerMonth")
    public void setTransactionAmountPerMonth(String transactionAmountPerMonth) {
        this.transactionAmountPerMonth = transactionAmountPerMonth;
    }

    @JsonProperty("transactionBranchesPerMonth")
    public String getTransactionBranchesPerMonth() {
        return transactionBranchesPerMonth;
    }

    @JsonProperty("transactionBranchesPerMonth")
    public void setTransactionBranchesPerMonth(String transactionBranchesPerMonth) {
        this.transactionBranchesPerMonth = transactionBranchesPerMonth;
    }

    @JsonProperty("transactionIntervalsPerMonth")
    public String getTransactionIntervalsPerMonth() {
        return transactionIntervalsPerMonth;
    }

    @JsonProperty("transactionIntervalsPerMonth")
    public void setTransactionIntervalsPerMonth(String transactionIntervalsPerMonth) {
        this.transactionIntervalsPerMonth = transactionIntervalsPerMonth;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
