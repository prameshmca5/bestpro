package com.bestpay.be.sdk.model;


public class PgwResponse {

	private String b4u_orderId;

	private String b4u_tranId;

	private String b4u_amount;

	private String b4u_merchantId;

	private String b4u_status;

	private String b4u_bank;

	private String b4u_paymentcode;

	private String b4u_channel;

	private String b4u_billingName;

	private String b4u_billingEmail;

	private String b4u_billingMobile;

	private String b4u_billingInfo;

	private Float b4u_billAmt;

	private Float b4u_transAmt;

	private Float b4u_actualAmt;

	private String b4u_billDate;

	private String b4u_currency;

	private String b4u_description;


	public String getB4u_orderId() {
		return b4u_orderId;
	}


	public void setB4u_orderId(String b4u_orderId) {
		this.b4u_orderId = b4u_orderId;
	}


	public String getB4u_tranId() {
		return b4u_tranId;
	}


	public void setB4u_tranId(String b4u_tranId) {
		this.b4u_tranId = b4u_tranId;
	}


	public String getB4u_amount() {
		return b4u_amount;
	}


	public void setB4u_amount(String b4u_amount) {
		this.b4u_amount = b4u_amount;
	}


	public String getB4u_merchantId() {
		return b4u_merchantId;
	}


	public void setB4u_merchantId(String b4u_merchantId) {
		this.b4u_merchantId = b4u_merchantId;
	}


	public String getB4u_status() {
		return b4u_status;
	}


	public void setB4u_status(String b4u_status) {
		this.b4u_status = b4u_status;
	}


	public String getB4u_bank() {
		return b4u_bank;
	}


	public void setB4u_bank(String b4u_bank) {
		this.b4u_bank = b4u_bank;
	}


	public String getB4u_paymentcode() {
		return b4u_paymentcode;
	}


	public void setB4u_paymentcode(String b4u_paymentcode) {
		this.b4u_paymentcode = b4u_paymentcode;
	}


	public String getB4u_channel() {
		return b4u_channel;
	}


	public void setB4u_channel(String b4u_channel) {
		this.b4u_channel = b4u_channel;
	}


	public String getB4u_currency() {
		return b4u_currency;
	}


	public void setB4u_currency(String b4u_currency) {
		this.b4u_currency = b4u_currency;
	}


	public String getB4u_billingName() {
		return b4u_billingName;
	}


	public void setB4u_billingName(String b4u_billingName) {
		this.b4u_billingName = b4u_billingName;
	}


	public String getB4u_billingEmail() {
		return b4u_billingEmail;
	}


	public void setB4u_billingEmail(String b4u_billingEmail) {
		this.b4u_billingEmail = b4u_billingEmail;
	}


	public String getB4u_billingMobile() {
		return b4u_billingMobile;
	}


	public void setB4u_billingMobile(String b4u_billingMobile) {
		this.b4u_billingMobile = b4u_billingMobile;
	}


	public String getB4u_billingInfo() {
		return b4u_billingInfo;
	}


	public void setB4u_billingInfo(String b4u_billingInfo) {
		this.b4u_billingInfo = b4u_billingInfo;
	}


	public Float getB4u_billAmt() {
		return b4u_billAmt;
	}


	public void setB4u_billAmt(Float b4u_billAmt) {
		this.b4u_billAmt = b4u_billAmt;
	}


	public Float getB4u_transAmt() {
		return b4u_transAmt;
	}


	public void setB4u_transAmt(Float b4u_transAmt) {
		this.b4u_transAmt = b4u_transAmt;
	}


	public Float getB4u_actualAmt() {
		return b4u_actualAmt;
	}


	public void setB4u_actualAmt(Float b4u_actualAmt) {
		this.b4u_actualAmt = b4u_actualAmt;
	}


	public String getB4u_billDate() {
		return b4u_billDate;
	}


	public void setB4u_billDate(String b4u_billDate) {
		this.b4u_billDate = b4u_billDate;
	}


	public String getB4u_description() {
		return b4u_description;
	}


	public void setB4u_description(String b4u_description) {
		this.b4u_description = b4u_description;
	}

}
