/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.config.ConfigConstants;
import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwMerchantBeneficiary;
import com.bestpay.be.model.PgwMerchantCompany;
import com.bestpay.be.model.PgwMerchantCompanyBankDetails;
import com.bestpay.be.model.PgwMerchantPid;
import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.model.PgwMultiChannel;
import com.bestpay.be.model.PgwSettlementConfig;
import com.bestpay.be.model.PgwTrxnDocument;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.ApsProfile;
import com.bestpay.be.sdk.model.ApsProfileResponse;
import com.bestpay.be.sdk.model.BeneficiaryAccount;
import com.bestpay.be.sdk.model.BeneficiaryDetail;
import com.bestpay.be.sdk.model.CustomerDetail;
import com.bestpay.be.sdk.model.IRProfile;
import com.bestpay.be.sdk.model.IRProfileResponse;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.model.MerAccSet;
import com.bestpay.be.sdk.model.MerCompany;
import com.bestpay.be.sdk.model.MerGenInfo;
import com.bestpay.be.sdk.model.MerPayPageSet;
import com.bestpay.be.sdk.model.RegisterBeneficiaryRequest;
import com.bestpay.be.sdk.model.RegisterBeneficiaryResult;
import com.bestpay.be.sdk.model.RegisterCustomerRequest;
import com.bestpay.be.sdk.model.RegisterCustomerResult;
import com.bestpay.be.sdk.model.TrxnDocuments;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.service.PgwMerchantBeneficiaryService;
import com.bestpay.be.service.RefCityService;
import com.bestpay.be.service.RefStateService;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.notify.sdk.constants.MailTemplate;
import com.bestpay.notify.sdk.constants.MailTypeEnum;
import com.bestpay.notify.sdk.model.Notification;
import com.bestpay.notify.sdk.util.MailUtil;
import com.bstsb.util.DateUtil;
import com.bstsb.util.MediaType;
import com.bstsb.util.constants.BaseConstants;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.MER_ACC_INFO)
public class AccInfoRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AccInfoRestController.class);

	private static final String MAXMONEY = "MAX_MONEY";

	private static final String INCENTIVEREMIT = "INCENTIVE_REMIT";

	String skipValues = "[-+.^:,()*@/]";

	@Autowired
	protected GenInfoRestController genInfoRestController;

	@Autowired
	protected AccountSetRestController accountSetRestController;

	@Autowired
	protected ReferenceRestController referenceRestController;

	@Autowired
	protected PayPageSettingRestController payPageSettingRestController;

	@Autowired
	protected RefCityService cityService;

	@Autowired
	protected RefStateService stateService;

	@Autowired
	protected IncentiveRemitRestController incentiveRemitRestController;

	@Autowired
	protected PgwMerchantBeneficiaryService pgwMerchantBeneficiaryService;

	@Autowired
	protected MaxMoneyRestController maxMoneyRestController;

	Random random = new Random();

	private static final String MALAYSIA = "MALAYSIA";


	@PostMapping(value = BeUrlConstants.MERCHANT_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<MerAccInfo> searchSettlementReportPaginated(@Valid @RequestBody MerAccInfo merAccInfo,
			HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwMerchantProfile> result = pgwMerchantProfileService.searchMerchantProfile(merAccInfo,
				dataTableInRQ);
		DataTableResults<MerAccInfo> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			dataTableInResp.setDraw(result.getDraw());
			dataTableInResp.setError(result.getError());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<MerAccInfo> bpLst = new ArrayList<>();
				for (PgwMerchantProfile bbp : result.getData()) {
					MerAccInfo trustee = dozerMapper.map(bbp, MerAccInfo.class);
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		LOGGER.info("Merchant registration = {}", dataTableInResp.getData());
		return dataTableInResp;
	}


	@GetMapping(value = "/{merchantId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerAccInfo getMerchantProfileById(@PathVariable String merchantId) {

		PgwMerchantProfile accInfo = super.pgwMerchantProfileService.findMerProfileByMerchantId(merchantId);

		MerAccInfo merPro = new MerAccInfo();
		if (!BaseUtil.isObjNull(accInfo)) {
			merPro = dozerMapper.map(accInfo, MerAccInfo.class);
		}
		return merPro;
	}


	@GetMapping(consumes = { MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MerAccInfo getMerchantProfileByProfId(
			@RequestParam(value = "merProfId", required = false) Integer merProfId) {
		PgwMerchantProfile accInfo = super.pgwMerchantProfileService.findByMerchantProfileId(merProfId);

		MerAccInfo merPro = new MerAccInfo();
		if (!BaseUtil.isObjNull(accInfo)) {
			merPro = dozerMapper.map(accInfo, MerAccInfo.class);
		}
		return merPro;
	}


	@PostMapping(value = BeUrlConstants.CREATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerAccInfo addMerchantProfile(@Valid @RequestBody MerAccInfo merAccInfo, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		LOGGER.info("Create new merchant profile ... ");
		if (merAccInfo == null) {// accountInfo null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}

		PgwMerchantProfile merProfile = new PgwMerchantProfile();
		new Date();

		PgwMerchantProfile accInfo = super.pgwMerchantProfileService
				.findMerProfileByMerchantId(merAccInfo.getMerchantId());

		String merId = null;
		merId = super.genUserName(merAccInfo.getCompany().replaceAll(skipValues, ""));

		if (BaseUtil.isObjNull(accInfo)) {
			merProfile.setMerchantId(merId);
			merProfile.setEmail(merAccInfo.getEmail());
			merProfile.setCompany(merAccInfo.getCompany().toUpperCase());
			merProfile.setDomain(merAccInfo.getDomain());
			merProfile.setSalesPic(merAccInfo.getSalesPic());
			merProfile.setSubscriptionPlan(merAccInfo.getSubscriptionPlan());
			merProfile.setAcStatus(merAccInfo.getAcStatus());
			merProfile.setMonthlyCancel(merAccInfo.getMonthlyCancel());
			merProfile.setMonthlyChargeback(merAccInfo.getMonthlyChargeback());
			merProfile.setTotalChargeback(merAccInfo.getTotalChargeback());
			merProfile.setHighrisk(merAccInfo.getHighrisk());
			merProfile.setStartContractDate(merAccInfo.getStartContractDate());
			merProfile.setExpireDate(merAccInfo.getExpireDate());
			merProfile.setMemo(merAccInfo.getMemo());
			merProfile.setOwnerDirectorName(merAccInfo.getOwnerDirectorName());
			merProfile.setOwnerDirectorNationalId(merAccInfo.getOwnerDirectorNationalId());
			merProfile.setNatureOfBusiness(merAccInfo.getNatureOfBusiness());
			merProfile.setCompanyRefId(merAccInfo.getCompanyRefId());
			merProfile.setCompRefFlag(merAccInfo.getCompRefFlag());
			merProfile.setCreateId(merAccInfo.getUserId());
			merProfile.setPdpa(0);
			super.pgwMerchantProfileService.create(merProfile);
		} else {
			throw new BeException(BeErrorCodeEnum.I404APJ110);
		}

		MerAccInfo merPro = new MerAccInfo();
		PgwMerchantProfile updatAccInfo = super.pgwMerchantProfileService.findMerProfileByMerchantId(merId);
		if (!BaseUtil.isObjNull(updatAccInfo)) {
			merPro = dozerMapper.map(updatAccInfo, MerAccInfo.class);
		}
		return merPro;
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerAccInfo updateMerchantProfile(@Valid @RequestBody MerAccInfo merAccInfo, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		LOGGER.info("Create new merchant profile ... ");
		if (merAccInfo == null) {// accountInfo null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		if (StringUtils.isBlank(merAccInfo.getMerchantId())) {// no merchant
			// name
			throw new BeException(BeErrorCodeEnum.I400IDM137, new String[] { "Merchant Name", "Merchant Profile" });
		}
		
		 
		PgwMerchantProfile accInfo = super.pgwMerchantProfileService
				.findMerProfileByMerchantId(merAccInfo.getOldMerchantId());
		 
		 
		if (!BaseUtil.isObjNull(accInfo)) {
			accInfo.setMerchantId(merAccInfo.getMerchantId());
			accInfo.setEmail(merAccInfo.getEmail());
			accInfo.setCompany(merAccInfo.getCompany().toUpperCase());
			accInfo.setDomain(merAccInfo.getDomain());
			accInfo.setSalesPic(merAccInfo.getSalesPic());
			accInfo.setSubscriptionPlan(merAccInfo.getSubscriptionPlan());
			accInfo.setAcStatus(merAccInfo.getAcStatus());
			accInfo.setMonthlyCancel(merAccInfo.getMonthlyCancel());
			accInfo.setMonthlyChargeback(merAccInfo.getMonthlyChargeback());
			accInfo.setTotalChargeback(merAccInfo.getTotalChargeback());
			accInfo.setHighrisk(merAccInfo.getHighrisk());
			accInfo.setStartContractDate(merAccInfo.getStartContractDate());
			accInfo.setExpireDate(merAccInfo.getExpireDate());
			accInfo.setMemo(merAccInfo.getMemo());
			accInfo.setOwnerDirectorName(merAccInfo.getOwnerDirectorName());
			accInfo.setOwnerDirectorNationalId(merAccInfo.getOwnerDirectorNationalId());
			accInfo.setNatureOfBusiness(merAccInfo.getNatureOfBusiness());
			accInfo.setCompanyRefId(merAccInfo.getCompanyRefId());
			accInfo.setUpdateId(merAccInfo.getUserId());
			if(merAccInfo.getPdpa()!=null) {
				accInfo.setPdpa(merAccInfo.getPdpa());
			}else {
				accInfo.setPdpa(accInfo.getPdpa());
			}
			super.pgwMerchantProfileService.update(accInfo);
		} else {
			throw new BeException(BeErrorCodeEnum.I404APJ110);
		}

		MerAccInfo merPro = new MerAccInfo();
		PgwMerchantProfile updatAccInfo = super.pgwMerchantProfileService
				.findMerProfileByMerchantId(merAccInfo.getMerchantId());
		if (!BaseUtil.isObjNull(updatAccInfo)) {
			merPro = dozerMapper.map(updatAccInfo, MerAccInfo.class);
		}
		return merPro;
	}


	// @Added by Ramesh Pongiannan
	@PostMapping(value = BeUrlConstants.ALL_MER_LIST, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<MerAccInfo> getMerChantgetWrapperById(@Valid @RequestBody MerAccInfo merAccInfo,
			HttpServletRequest request, HttpServletResponse response) throws BeException {
		List<MerAccInfo> multichannelList = new ArrayList<>();
		List<PgwMerchantProfile> channelLst = pgwMerchantProfileService.findAllMerchantList();
		if (BaseUtil.isListNullAndZero(channelLst)) {

			throw new BeException(BeErrorCodeEnum.E404PLC001, new String[] {});
		}
		for (PgwMerchantProfile c : channelLst) {
			multichannelList.add(dozerMapper.map(c, MerAccInfo.class));
		}
		return multichannelList;
	}


	@GetMapping(value = BeUrlConstants.DEACTV_MER_EXPRD_SCHEDULER, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public void merExpireInactive(HttpServletRequest request) {
		LOGGER.info(" deActivateExpiredMerchantsScheduler ran ");
		List<PgwMerchantProfile> profileList = pgwMerchantProfileService.findExpiredMerchantList();
		for (PgwMerchantProfile c : profileList) {
			UserProfile userProfile = getIdmService(request).getUserprofileByMerchantProfileId(c.getMerProfId());
			if (!BaseUtil.isObjNull(userProfile)) {
				getIdmService(request).deactivateUserProfile(userProfile);
				LOGGER.info("Deactivated merchantId: {} ProfId: {} Email: {} ", c.getMerchantId(),
						userProfile.getProfId(), userProfile.getEmail());
			}
		}

	}


	@GetMapping(value = BeUrlConstants.CNT_MER_STATUS, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<String> getCountByMerchantStatus(HttpServletRequest request) {
		return pgwMerchantProfileService.getCountByStatus();
	}


	@PostMapping(value = "/saveApsProfile", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public ApsProfileResponse saveApsProfile(@RequestBody ApsProfile apsProfile, HttpServletRequest request,
			HttpServletResponse response) throws BeException {
		Date expiryDate = new Date();
		MerAccInfo merAccInfo = new MerAccInfo();
		merAccInfo.setEmail(apsProfile.getOwnerEmail());
		merAccInfo.setCompany(apsProfile.getApsName());
		merAccInfo.setOwnerDirectorName(apsProfile.getOwnerName());
		merAccInfo.setOwnerDirectorNationalId(apsProfile.getOwnerNationalId());
		merAccInfo.setCompanyRefId(apsProfile.getCompanyReferenceId());
		merAccInfo.setAcStatus("ACTIVE");
		merAccInfo.setExpireDate(DateUtil.addYearMonthDaysToDate(expiryDate, 4, 0, 0));
		merAccInfo.setNatureOfBusiness(apsProfile.getNatureOfBusiness());
		MerAccInfo createdProfile = addMerchantProfile(merAccInfo, request, response);
		LOGGER.info("Created Merchant Profile, merchantId : {}", merAccInfo.getMerchantId());
		UserProfile createUserProfile = new UserProfile();
		createUserProfile.setFullName(createdProfile.getCompany());
		createUserProfile.setEmail(createdProfile.getEmail());
		createUserProfile.setProfId(createdProfile.getMerProfId());
		createUserProfile.setUserType("MER");
		createUserProfile.setUserRoleGroupCode("MER_ADMIN");
		UserProfile userProfile = getIdmService().createMerchantUserWithPassword(createUserProfile, "true", "true");
		LOGGER.info("Created User Profile, userId : {}", userProfile.getUserId());
		MerGenInfo merGenInfo = new MerGenInfo();
		merGenInfo.setMerchantId(createdProfile.getMerchantId());
		merGenInfo.setMphone(apsProfile.getOwnerPhoneNo());
		merGenInfo.setAddress(apsProfile.getOwnerAddress());
		merGenInfo.setAddress2(apsProfile.getOwnerAddress2());
		merGenInfo.setAddress3(apsProfile.getOwnerAddress3());
		merGenInfo.setState(apsProfile.getOwnerState());
		merGenInfo.setCity(apsProfile.getOwnerCity());
		merGenInfo.setPostcode(apsProfile.getOwnerPostCode());
		genInfoRestController.updateMerchantContact(merGenInfo, request, response);
		LOGGER.info("Successfully created Merchant General Info .... ");
		MerAccSet merAccSet = new MerAccSet();
		merAccSet.setMerchantId(createdProfile.getMerchantId());
		merAccSet.setIcNumber(apsProfile.getRegistrationNo());
		accountSetRestController.updateAccountSetting(merAccSet, request, response);
		MerPayPageSet merPayPageSet = new MerPayPageSet();
		merPayPageSet.setMerchantId(createdProfile.getMerchantId());
		merPayPageSet.setVerifyKey(getVerifyKey());
		merPayPageSet.setEnableVerify(1);
		merPayPageSet.setCallbackUrl(messageService.getMessage(ConfigConstants.MM_CALLBACK_URL));
		merPayPageSet.setCallbackUrlWithIpn("1");
		merPayPageSet.setReturnUrl(messageService.getMessage(ConfigConstants.MM_RETURN_URL));
		merPayPageSet.setReturnUrlWithIpn("1");
		payPageSettingRestController.updatePaymentPageSettings(merPayPageSet, request, response);
		PgwMultiChannel pgwMultiChannel = new PgwMultiChannel();
		pgwMultiChannel.setMerchantId(createdProfile.getMerchantId());
		pgwMultiChannel.setChannel(MAXMONEY);
		pgwMultiChannel.setStatus("A");
		pgwMultiChannel.setEnable(1);
		pgwMultiChannel.setCreateId("Apjatigo");
		pgwMultiChannel.setRate(0d);
		pgwMultiChannel.setCost(0d);
		pgwMultiChannel.setAdditionalCost(0d);
		pgwMultiChannel.setMonthlyFee(0d);
		pgwMultiChannelService.create(pgwMultiChannel);
		PgwSettlementConfig pgwSettlementConfig = new PgwSettlementConfig();
		pgwSettlementConfig.setReserveDay(2);
		pgwSettlementConfig.setMerchantId(createdProfile.getMerchantId());
		pgwSettlementConfig.setCreateId("apjatigo");
		pgwSettlementConfigService.create(pgwSettlementConfig);
		LOGGER.info("Successfully created Merchant Account Set");
		ApsProfileResponse apsProfileResponse = new ApsProfileResponse();
		apsProfileResponse.setMerchantId(merGenInfo.getMerchantId());
		apsProfileResponse.setUrl("http://10.10.11.25:8080/bestpay-portal-merchant/company_profile/update/"
				+ merGenInfo.getMerchantId());
		apsProfileResponse.setVerifyKey(merPayPageSet.getVerifyKey());
		return apsProfileResponse;
	}


	// Third party using Incentive Remittance registration. EX : Apjatigo
	@PostMapping(value = "/saveIRProfile", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public IRProfileResponse saveIRProfile(@RequestBody IRProfile apsProfile, HttpServletRequest request,
			HttpServletResponse response) throws BeException {
		LOGGER.info("In saveApsProfile method ");
		Date expiryDate = new Date();
		MerAccInfo merAccInfo = new MerAccInfo();
		merAccInfo.setEmail(apsProfile.getOwnerEmail());
		merAccInfo.setCompany(apsProfile.getApsName());
		merAccInfo.setOwnerDirectorName(apsProfile.getOwnerName());
		merAccInfo.setOwnerDirectorNationalId(apsProfile.getOwnerNationalId());
		merAccInfo.setCompanyRefId(apsProfile.getCompanyReferenceId());
		merAccInfo.setAcStatus("ACTIVE");
		merAccInfo.setExpireDate(DateUtil.addYearMonthDaysToDate(expiryDate, 4, 0, 0));
		merAccInfo.setNatureOfBusiness(apsProfile.getNatureOfBusiness());
		MerAccInfo createdProfile = addMerchantProfile(merAccInfo, request, response);
		LOGGER.info("Created Merchant Profile, merchantId : {}", merAccInfo.getMerchantId());
		UserProfile createUserProfile = new UserProfile();
		createUserProfile.setFullName(createdProfile.getCompany());
		createUserProfile.setEmail(createdProfile.getEmail());
		createUserProfile.setProfId(createdProfile.getMerProfId());
		createUserProfile.setUserType("MER");
		createUserProfile.setUserRoleGroupCode("MER_ADMIN");
		UserProfile userProfile = getIdmService().createMerchantUserWithPassword(createUserProfile, "true", "true");
		LOGGER.info("Created User Profile, userId : {}", userProfile.getUserId());
		MerGenInfo merGenInfo = new MerGenInfo();
		merGenInfo.setMerchantId(createdProfile.getMerchantId());
		merGenInfo.setMphone(apsProfile.getOwnerPhoneNo());
		if (apsProfile.getOwnerAddress() != null) {
			merGenInfo.setAddress(apsProfile.getOwnerAddress());
		} else {
			merGenInfo.setAddress("");
		}
		if (apsProfile.getOwnerAddress2() != null) {
			merGenInfo.setAddress2(apsProfile.getOwnerAddress2());
		} else {
			merGenInfo.setAddress2("");
		}
		if (apsProfile.getOwnerAddress3() != null) {
			merGenInfo.setAddress3(apsProfile.getOwnerAddress3());
		} else {
			merGenInfo.setAddress3("");
		}
		merGenInfo.setState(apsProfile.getOwnerState());
		merGenInfo.setCity(apsProfile.getOwnerCity());
		merGenInfo.setPostcode(apsProfile.getOwnerPostCode());
		merGenInfo.setCountry("MYS");
		genInfoRestController.updateMerchantContact(merGenInfo, request, response);
		LOGGER.info("Successfully created Merchant General Info .... ");
		MerAccSet merAccSet = new MerAccSet();
		merAccSet.setMerchantId(createdProfile.getMerchantId());
		merAccSet.setIcType("NEW");
		merAccSet.setIcNumber(apsProfile.getRegistrationNo());
		accountSetRestController.updateAccountSetting(merAccSet, request, response);
		MerPayPageSet merPayPageSet = new MerPayPageSet();
		merPayPageSet.setMerchantId(createdProfile.getMerchantId());
		merPayPageSet.setVerifyKey(getVerifyKey());
		merPayPageSet.setEnableVerify(1);
		merPayPageSet.setCallbackUrl(messageService.getMessage(ConfigConstants.MM_CALLBACK_URL));
		merPayPageSet.setCallbackUrlWithIpn("1");
		merPayPageSet.setReturnUrl(messageService.getMessage(ConfigConstants.MM_RETURN_URL));
		merPayPageSet.setReturnUrlWithIpn("1");
		payPageSettingRestController.updatePaymentPageSettings(merPayPageSet, request, response);
		PgwMultiChannel pgwMultiChannel = new PgwMultiChannel();
		pgwMultiChannel.setMerchantId(createdProfile.getMerchantId());
		pgwMultiChannel.setChannel(INCENTIVEREMIT);
		pgwMultiChannel.setStatus("A");
		pgwMultiChannel.setEnable(1);
		pgwMultiChannel.setCreateId(apsProfile.getCompanyReferenceId());
		pgwMultiChannel.setRate(0d);
		pgwMultiChannel.setCost(0d);
		pgwMultiChannel.setAdditionalCost(0d);
		pgwMultiChannel.setMonthlyFee(0d);
		pgwMultiChannelService.create(pgwMultiChannel);
		LOGGER.info("Successfully created Merchant Account Set .... ");
		PgwSettlementConfig pgwSettlementConfig = new PgwSettlementConfig();
		pgwSettlementConfig.setReserveDay(2);
		pgwSettlementConfig.setMerchantId(createdProfile.getMerchantId());
		pgwSettlementConfig.setCreateId(apsProfile.getCompanyReferenceId());
		pgwSettlementConfigService.create(pgwSettlementConfig);
		IRProfileResponse irProfileResponse = new IRProfileResponse();
		irProfileResponse.setMerchantId(merGenInfo.getMerchantId());
		irProfileResponse.setVerifyKey(merPayPageSet.getVerifyKey());
		return irProfileResponse;
	}


	// Added By Ramesh Pongiannan
	// Internal Profile using Incentive Remittance registration. EX : Merchant
	// Registration and Update.
	@PostMapping(value = BeUrlConstants.SAVE_INTER_IR_PROFILE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public IRProfileResponse saveIRInternalProfile(@RequestBody IRProfile irProfile, HttpServletRequest request,
			HttpServletResponse response) {

		LOGGER.info("In saveIRProfile method .............");
		IRProfileResponse irProfileResponse = new IRProfileResponse();
		PgwMerchantCompany merCompany = super.pgwMerchantCompanyService
				.findCompanyByCompRefId(irProfile.getCompanyReferenceId());
		RegisterCustomerRequest registerCustomerRequest = new RegisterCustomerRequest();
		String name = irProfile.getOwnerName();
		String[] names = name.split(" ");
		String senderFirstName = "";
		String senderMiddleName = "";
		String senderLastName = "";
		if (names != null && names.length > 0) {
			senderFirstName = names[0];
			if (names.length == 2) {
				senderLastName = senderLastName.concat(names[1]);
			}
			if (names.length == 3) {
				senderMiddleName = senderMiddleName.concat(names[1]);
				senderLastName = senderLastName.concat(names[2]);
			}
		}
		registerCustomerRequest.setSenderFirstName(senderFirstName);
		registerCustomerRequest.setSenderMiddleName(senderMiddleName);
		registerCustomerRequest.setSenderLastName(senderLastName);
		String senderGender = "";
		int lastDigit = Character.getNumericValue(
				irProfile.getOwnerNationalId().charAt(irProfile.getOwnerNationalId().length() - 1));
		if (lastDigit % 2 == 0) {
			senderGender = "FEMALE";
		} else {
			senderGender = "MALE";
		}
		registerCustomerRequest.setSenderGender(senderGender);
		registerCustomerRequest.setSenderAddress(irProfile.getOwnerAddress().toUpperCase());
		registerCustomerRequest.setSenderCity(irProfile.getOwnerCity());
		registerCustomerRequest.setSenderState(irProfile.getOwnerState());
		registerCustomerRequest.setSenderCountry(MALAYSIA);
		registerCustomerRequest.setSenderZipCode(irProfile.getOwnerPostCode());
		String ownerPhoneNo = irProfile.getOwnerPhoneNo();
		if (irProfile.getOwnerPhoneNo() != null && irProfile.getOwnerPhoneNo().substring(0, 2).equals("+6")) {
			ownerPhoneNo = irProfile.getOwnerPhoneNo().substring(2);
		}
		registerCustomerRequest.setSenderMobile(ownerPhoneNo);
		registerCustomerRequest.setSenderIDType("NRIC");
		registerCustomerRequest.setSenderIDNumber(irProfile.getOwnerNationalId());
		registerCustomerRequest.setIdIssuePlace(MALAYSIA);
		registerCustomerRequest.setIdIssueDate(DateUtil.convertDate(new Date(), BaseConstants.DT_YYYY_MM_DD_DASH));
		Calendar c = Calendar.getInstance();
		c.add(Calendar.YEAR, 20);
		Date idExpireDate = c.getTime();
		registerCustomerRequest.setIdExpireDate(DateUtil.convertDate(idExpireDate, BaseConstants.DT_YYYY_MM_DD_DASH));
		registerCustomerRequest.setSenderNativeCountry(MALAYSIA);
		Date senderDateOfBirth = DateUtil.convertStrDateToDate(irProfile.getOwnerNationalId().substring(0, 6),
				"yyMMdd");
		registerCustomerRequest
				.setSenderDateOfBirth(DateUtil.convertDate(senderDateOfBirth, BaseConstants.DT_YYYY_MM_DD_DASH));
		registerCustomerRequest.setSenderOccupation("SELF EMPLOYED AND BUSINESS");
		registerCustomerRequest.setSenderEmployerName(irProfile.getApsName());
		registerCustomerRequest.setSenderEmployerType("AGENCY SERVICE");
		registerCustomerRequest.setSenderFundSource("BUSINESS INCOME");
		registerCustomerRequest.setSenderPhoto(irProfile.getSenderPhoto());
		if (irProfile.getSenderPhoto1() != null) {
			registerCustomerRequest.setSenderPhoto1(irProfile.getSenderPhoto1());
		}
		RegisterCustomerResult registerCustomerResult = incentiveRemitRestController
				.registerCustomer(registerCustomerRequest);
		if (registerCustomerResult.getCode().equals("0")) {
			LOGGER.info("Registerd Customer successfully. SenderCustomerId: {} ",
					registerCustomerResult.getSenderCustomerId());
			RegisterBeneficiaryRequest registerBeneficiaryRequest = new RegisterBeneficiaryRequest();
			registerBeneficiaryRequest.setSenderCustomerId(registerCustomerResult.getSenderCustomerId());
			String beneficiaryFirstName = "";
			String beneficiaryMiddleName = "";
			String beneficiaryLastName = "";
			String[] benNames = merCompany.getCompanyName().split(" ");
			StringBuilder bld = new StringBuilder();
			if (benNames != null && benNames.length >= 2) {
				beneficiaryLastName = benNames[benNames.length - 1];
				for (int i = 0; i < benNames.length - 1; i++) {
					bld.append(benNames[i] + " ");
				}
				beneficiaryFirstName = bld.toString();
			}
			registerBeneficiaryRequest.setFirstName(beneficiaryFirstName);
			registerBeneficiaryRequest.setMiddleName(beneficiaryMiddleName);
			registerBeneficiaryRequest.setLastName(beneficiaryLastName);
			registerBeneficiaryRequest.setAddress(merCompany.getAddress1());
			registerBeneficiaryRequest.setCity(merCompany.getCity());
			registerBeneficiaryRequest.setCountry(merCompany.getCountry());
			String merchantPhone = merCompany.getPhone();
			if (merCompany.getPhone() != null && merCompany.getPhone().substring(0, 2).equals("+6")) {
				merchantPhone = merCompany.getPhone().substring(2);
			}
			registerBeneficiaryRequest.setMobile(merchantPhone);
			registerBeneficiaryRequest.setEmail(merCompany.getEmail());
			registerBeneficiaryRequest.setRelationShip(merCompany.getRelationship());
			RegisterBeneficiaryResult registerBeneficiaryResult = incentiveRemitRestController
					.registerBeneficiary(registerBeneficiaryRequest);
			if (registerBeneficiaryResult.getCode().equals("0")) {
				LOGGER.info("RegisterBeneficiary is successful, BeneficiarySno: {}",
						registerBeneficiaryResult.getBeneficiarySno());
				IRProfileResponse beIRProfileResponse = new IRProfileResponse();
				LOGGER.info("Successfully created merchant: merchantId: {}", irProfile.getMerchantId());
				beIRProfileResponse.setMessage(" Customer registration successful ");
				PgwMerchantBeneficiary merchantBeneficiary = new PgwMerchantBeneficiary();
				merchantBeneficiary.setMerchantId(irProfile.getMerchantId());
				merchantBeneficiary.setMtoId(INCENTIVEREMIT);
				merchantBeneficiary.setBenefeciaryId(registerBeneficiaryResult.getBeneficiarySno());
				pgwMerchantBeneficiaryService.create(merchantBeneficiary);

				PgwMerchantPid pgwMerchantPid = new PgwMerchantPid();
				pgwMerchantPid.setMerchantId(irProfile.getMerchantId());
				pgwMerchantPid.setMtoId(INCENTIVEREMIT);
				pgwMerchantPid.setPid(registerCustomerResult.getSenderCustomerId());
				pgwMerchantPidService.create(pgwMerchantPid);
				LOGGER.info("SenderCustomerId saved into MerchantPid.. ");
				return dozerMapper.map(beIRProfileResponse, IRProfileResponse.class);
			} else {
				LOGGER.info("RegisterBeneficiary failed Msg: {} {}", registerBeneficiaryResult.getCode(),
						registerBeneficiaryResult.getMessage());
				irProfileResponse.setMessage(" RegisterBeneficiary failed Msg: "
						+ registerBeneficiaryResult.getCode() + " " + registerBeneficiaryResult.getMessage());
			}
		} else {
			LOGGER.info("RegisterCustomer failed Msg: {} {}", registerCustomerResult.getCode(),
					registerCustomerResult.getMessage());
			irProfileResponse.setMessage(" RegisterCustomer failed Msg: " + registerCustomerResult.getCode() + " "
					+ registerCustomerResult.getMessage());
		}
		return irProfileResponse;
	}


	@PostMapping(value = "/saveDocuments", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public TrxnDocuments saveDocuments(@RequestBody TrxnDocuments trxnDocuments, HttpServletRequest request,
			HttpServletResponse response) throws BeException {
		if (BaseUtil.isObjNull(trxnDocuments)) {
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		PgwTrxnDocument pgwTrxnDocument = super.pgwTrxnDocumentsService
				.create(dozerMapper.map(trxnDocuments, PgwTrxnDocument.class));

		return dozerMapper.map(pgwTrxnDocument, TrxnDocuments.class);
	}


	@GetMapping(value = "/merchantCompanyProfile/{companyId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerCompany getMerchantCompanyByName(@PathVariable Integer companyId) {

		PgwMerchantCompany merComInfo = super.pgwMerchantCompanyService.findCompanyByCompanyId(companyId);

		MerCompany merCompany = new MerCompany();
		if (!BaseUtil.isObjNull(merCompany)) {
			merCompany = dozerMapper.map(merComInfo, MerCompany.class);
		}
		return merCompany;
	}


	private String getVerifyKey() {
		String chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < 32; i++) {
			int rnum = ThreadLocalRandom.current().nextInt(0, 61);
			sb.append(chars.charAt(rnum));
		}
		return sb.toString();
	}


	@GetMapping(value = "/getMerCompanyByCompanyId/{companyId}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MerCompany getMerCompanyByCompanyId(@PathVariable Integer companyId, HttpServletRequest request) {
		PgwMerchantCompany pgwMerchantCompany = super.pgwMerchantCompanyService.findCompanyByCompanyId(companyId);
		if (pgwMerchantCompany != null) {
			return dozerMapper.map(pgwMerchantCompany, MerCompany.class);
		}
		return null;
	}


	// @Added by Ramesh Pongiannan
	@PostMapping(value = BeUrlConstants.GET_OWNERID, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<MerAccInfo> getOwnerNationalId(@Valid @RequestBody MerAccInfo merAccInfo, HttpServletRequest request,
			HttpServletResponse response) {
		List<MerAccInfo> multichannelList = new ArrayList<>();
		String ownerId = merAccInfo.getOwnerDirectorNationalId();
		List<PgwMerchantProfile> channelLst = super.pgwMerchantProfileService.findByOwnerNationalId(ownerId);
		if (!BaseUtil.isListNullAndZero(channelLst)) {
			for (PgwMerchantProfile c : channelLst) {
				multichannelList.add(dozerMapper.map(c, MerAccInfo.class));
			}
		}
		return multichannelList;
	}


	public MerAccInfo getMerchantProfile(@Valid @RequestBody MerAccInfo merAccInfo) throws BeException {

		LOGGER.info("Get Profile merchant profile ... ");
		if (merAccInfo == null) {// accountInfo null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		String merId = merAccInfo.getMerchantId();
		MerAccInfo merPro = new MerAccInfo();
		PgwMerchantProfile updatAccInfo = super.pgwMerchantProfileService.findMerProfileByMerchantId(merId);
		if (!BaseUtil.isObjNull(updatAccInfo)) {
			merPro = dozerMapper.map(updatAccInfo, MerAccInfo.class);
		}
		return merPro;
	}


	// Internal Profile register to MaxMoney
	@PostMapping(value = BeUrlConstants.SAVE_INTER_MM_PROFILE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public ApsProfileResponse saveMMInternalProfile(@RequestBody ApsProfile apsProfile, HttpServletRequest request,
			HttpServletResponse response) {
		LOGGER.info("In saveMMProfile method .............");
		LOGGER.info("Successfully created merchant: merchantId: {}", apsProfile.getMerchantId());
		PgwMerchantCompany merCompany = super.pgwMerchantCompanyService
				.findCompanyByCompRefId(apsProfile.getCompanyReferenceId());
		PgwMerchantCompanyBankDetails merCompBankDetails = super.pgwMerchantCompanyBankDetailsService
				.findBeneficiaryByCompRefId(apsProfile.getCompanyReferenceId());
		BeneficiaryDetail beneficiaryDetail = maxMoneyRestController.createBeneficiary(merCompany.getCompanyName(),
				merCompany.getAddress1(), merCompany.getCountry(), null, merCompany.getPhone(),
				merCompany.getEmail(), merCompany.getPicName());
		LOGGER.info(" Benefeciary details have been created in MaxMoney Id: {} ", beneficiaryDetail.getId());
		apsProfile.setBeneficiaryId(beneficiaryDetail.getId());
		PgwMerchantBeneficiary merchantBeneficiary = new PgwMerchantBeneficiary();
		merchantBeneficiary.setMerchantId(apsProfile.getMerchantId());
		merchantBeneficiary.setBenefeciaryId(beneficiaryDetail.getId());
		merchantBeneficiary.setMtoId(MAXMONEY);
		pgwMerchantBeneficiaryService.create(merchantBeneficiary);

		BeneficiaryAccount beneficiaryAccount = maxMoneyRestController.createBeneficiaryAccount(
				beneficiaryDetail.getId(), merCompBankDetails.getBankAccNo(), merCompBankDetails.getBankAccName(),
				merCompany.getCompanyName(), merCompBankDetails.getBankBranch(),
				merCompBankDetails.getBankLocation(), merCompBankDetails.getBankCountry(),
				merCompBankDetails.getBankName());
		ApsProfileResponse beApsProfileResponse = saveMaxMoneyProfile(apsProfile, request, response);
		LOGGER.info(" BeneficiaryAccount has been registered in MaxMoney, UserId:  {} ", beneficiaryAccount.getId());
		CustomerDetail customerDetail = maxMoneyRestController.customerRegistration(apsProfile);
		LOGGER.info(" Customer has been registered in MaxMoney {} ", customerDetail.getCustomerName());
		return dozerMapper.map(beApsProfileResponse, ApsProfileResponse.class);
	}


	public ApsProfileResponse saveMaxMoneyProfile(ApsProfile apsProfile, HttpServletRequest request,
			HttpServletResponse response) {
		LOGGER.info("In saveApsProfile method ");
		PgwMultiChannel pgwMultiChannel = new PgwMultiChannel();
		pgwMultiChannel.setMerchantId(apsProfile.getMerchantId());
		request.changeSessionId();
		response.getLocale();
		pgwMultiChannel.setChannel(MAXMONEY);
		pgwMultiChannel.setStatus("A");
		pgwMultiChannel.setEnable(1);
		pgwMultiChannel.setCreateId("Bestpay");
		pgwMultiChannel.setRate(0d);
		pgwMultiChannel.setCost(0d);
		pgwMultiChannel.setAdditionalCost(0d);
		pgwMultiChannel.setMonthlyFee(0d);
		pgwMultiChannelService.create(pgwMultiChannel);
		PgwSettlementConfig pgwSettlementConfig = new PgwSettlementConfig();
		pgwSettlementConfig.setReserveDay(2);
		pgwSettlementConfig.setMerchantId(apsProfile.getMerchantId());
		pgwSettlementConfig.setCreateId("Bestpay");
		pgwSettlementConfigService.create(pgwSettlementConfig);
		LOGGER.info("Successfully created Merchant Account Set .... ");
		ApsProfileResponse apsProfileResponse = new ApsProfileResponse();
		apsProfileResponse.setMerchantId(apsProfile.getMerchantId());
		return apsProfileResponse;
	}


	@PostMapping(value = BeUrlConstants.SEND_ACTIVATION_EMAIL, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerAccInfo sendActivationEmail(@RequestBody String merchantId, HttpServletRequest request,
			HttpServletResponse response) {
		PgwMerchantProfile merProfile = super.pgwMerchantProfileService.findMerProfileByMerchantId(merchantId);
		Map<String, Object> map = new HashMap<>();
		map.put("name", merProfile.getCompany());
		Notification notification = new Notification();
		notification.setNotifyTo(merProfile.getEmail());
		notification.setSubject(MailTemplate.IDM_ACCOUNT_PYMT_ACTIVATE.getSubject());
		notification.setMetaData(MailUtil.convertMapToJson(map));
		getNotifyService(request).addNotification(notification, MailTypeEnum.MAIL,
				MailTemplate.IDM_ACCOUNT_PYMT_ACTIVATE);

		return dozerMapper.map(merProfile, MerAccInfo.class);
	}
	
	@PostMapping(value = BeUrlConstants.SEND_APPROVALN_EMAIL, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerAccInfo sendApprovalEmail(@RequestBody String merchantId, HttpServletRequest request,
			HttpServletResponse response) {
		PgwMerchantProfile merProfile = super.pgwMerchantProfileService.findMerProfileByMerchantId(merchantId);
		Map<String, Object> map = new HashMap<>();
		map.put("name", "Admin");
		map.put("mercahntid", merProfile.getMerchantId());
		map.put("mercahntname", merProfile.getOwnerDirectorName());
		Notification notification = new Notification();
		notification.setNotifyTo("support.bestpay.com.my");
		notification.setNotifyCc("ramesh.pongiannan@bestinet.com.my");
		notification.setNotifyCc("rameshkp2@gmail.com");
		notification.setSubject(MailTemplate.IDM_ACCOUNT_SEND_APPROVAL.getSubject());
		notification.setMetaData(MailUtil.convertMapToJson(map));
		getNotifyService(request).addNotification(notification, MailTypeEnum.MAIL,
				MailTemplate.IDM_ACCOUNT_SEND_APPROVAL);

		return dozerMapper.map(merProfile, MerAccInfo.class);
	}
}
