/**
 *
 */
package com.bestpay.web.dialect.processor;


import org.thymeleaf.Arguments;
import org.thymeleaf.dom.Element;
import org.thymeleaf.processor.ProcessorResult;
import org.thymeleaf.spring4.context.SpringWebContext;

import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.dialect.AbstractBstElement;
import com.bestpay.web.dialect.constants.AttributeConstants;
import com.bestpay.web.dialect.constants.ElementConstants;
import com.bestpay.web.dialect.constants.ElementEnum;


/**
 * @author Mary Jane Buenaventura
 * @since 22/02/2018
 */
public class SelectElementController extends AbstractBstElement {

	public SelectElementController(String elementName) {
		super(elementName);
	}


	@Override
	protected ProcessorResult processElement(Arguments arguments, Element element) {
		String elementNm = getElementName(element);
		((SpringWebContext) arguments.getContext()).getApplicationContext();
		Element newElement = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_SELECT,
				false);
		newElement.setRecomputeProcessorsImmediately(true);

		String attrClass = ElementEnum.findStyleByName(elementNm);

		if (!BaseUtil.isObjNull(element.getAttributeValue(AttributeConstants.ATTR_CLASS))) {
			attrClass = element.getAttributeValue(AttributeConstants.ATTR_CLASS) + " " + attrClass;
		} else if (!BaseUtil.isObjNull(element.getAttributeValue(AttributeConstants.ATTR_TH_CLASSAPPEND))) {
			attrClass = attrClass + " " + element.getAttributeValue(AttributeConstants.ATTR_TH_CLASSAPPEND);
		} else {
			attrClass = ElementEnum.findStyleByName(elementNm);
		}

		newElement.setAttribute(AttributeConstants.ATTR_CLASS, attrClass);

		element.getParent().insertAfter(element, newElement);
		element.getParent().removeChild(element);

		return ProcessorResult.OK;
	}


	@Override
	public int getPrecedence() {
		return 100000;
	}

}
