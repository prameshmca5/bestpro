/**
* Copyright 2018. Bestinet Sdn Bhd
*/
package com.bestpay.web.config.iam;


import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.bestpay.dm.sdk.model.Documents;
import com.bestpay.idm.sdk.constants.IdmErrorCodeEnum;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.ConfigDto;
import com.bestpay.idm.sdk.model.LoginDto;
import com.bestpay.idm.sdk.model.Token;
import com.bestpay.idm.sdk.model.UserLoginAttemptsDto;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.idm.sdk.model.UserRole;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.idm.sdk.util.SSHA;
import com.bestpay.web.config.ConfigConstants;
import com.bestpay.web.config.audit.AuditActionPolicy;
import com.bestpay.web.constants.ProjectEnum;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.WebUtil;
import com.bstsb.util.DateUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
public class CustomAuthenticationManager extends AbstractController implements AuthenticationManager {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomAuthenticationManager.class);

	private static final String WAITING_TIME = "ATTEMPT_WAITING_TIME";

	private static final String LBL_ERR_ACC_PSWD = "lbl.err.acc.pwd.attmpt.blk";

	private static final String LBL_ERR_INV_PSWD = "lbl.err.inv.pwd";


	@Override
	public Authentication authenticate(Authentication auth) {
		LOGGER.debug("Performing custom authentication");
		LOGGER.debug("Username: {} - Password: {}", auth.getName(), auth.getCredentials());
		LOGGER.debug("eKey: {}", messageService.getMessage(ConfigConstants.SVC_IDM_EKEY));

		String userId = auth.getName();
		String pword = SSHA.getLDAPSSHAHash(String.valueOf(auth.getCredentials()), getPwordEkey());
		LOGGER.debug(pword);

		LoginDto login = new LoginDto();
		login.setUserId(userId);
		login.setPassword(pword);
		login.setUserType(messageService.getMessage("app.portal.type"));
		LOGGER.info("Portal Type: {}", login.getUserType());

		String reqMsg = "";
		try {
			reqMsg = new ObjectMapper().writeValueAsString(login);
		} catch (JsonProcessingException e1) {
			// ignore
		}

		if ("gov".equalsIgnoreCase(login.getUserType())) {
			Date now = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
			String timeStr = sdf.format(now);
			try {
				Time timeNow = new Time(sdf.parse(timeStr).getTime());
				Time timeFrom = new Time(sdf.parse(messageService.getMessage("gov.portal.access.from")).getTime());
				Time timeTo = new Time(sdf.parse(messageService.getMessage("gov.portal.access.to")).getTime());
				LOGGER.debug(
						"\n\tTime NOW: {} \\n\\tTime From: {} \\n\\tTime To: {} \\n\\tDate From: {} \\n\\tDate To: {}",
						timeNow, timeFrom, timeTo, timeNow.before(timeFrom), timeNow.after(timeTo));
				if (timeNow.before(timeFrom) || timeNow.after(timeTo)) {
					if ((timeNow.after(timeFrom) && timeNow.before(timeTo))) {
						// DO NOTHING
					} else {
						throw new BadCredentialsException(messageService.getMessage("msg.sys.off.acc"));
					}
				}

			} catch (ParseException e) {
				// IGNORE
			}

		}

		try {
			login = getIdmService().login(login);
		} catch (IdmException e) {
			LOGGER.error("IdmException: {}", e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
			String errorCode = null;
			String geterrorCode = e.getInternalErrorCode();
			if (BaseUtil.isEqualsCaseIgnore(IdmErrorCodeEnum.E503IDM000.name(), errorCode)) {
				throw new BadCredentialsException("System unavailable. Please contact administrator. <br/>"
						+ (errorCode != null ? " [ " + errorCode + " ]" : ""));
			} else if (BaseUtil.isEquals(IdmErrorCodeEnum.I404IDM103.name(), geterrorCode)) {
				LOGGER.info("USER NAME --- {}", login.getUserId());
				java.sql.Timestamp curAttemptTime = DateUtil.getSQLTimestamp();
				String curruser = login.getUserId();
				Long totattmpt = getConfigValue("ATTEMPT_LOGIN");
				Long getIntervel = getConfigValue("ATTEMPT_INTERVAL_TIME");
				Long getWaiting = getConfigValue(WAITING_TIME);
				Integer getACount = 0;
				try {
					UserLoginAttemptsDto userattempt = getuserDetails(curruser);
					if (userattempt.getUserId() != null) {
						long totFirstAttmMint = DateUtil.convTimestampBetweenFirstAndLastLoginAttempt(
								curAttemptTime, userattempt.getFirstAttemptDateTime());
						long totLastAttmMint = DateUtil.convTimestampBetweenFirstAndLastLoginAttempt(
								curAttemptTime, userattempt.getLastAttemptDateTime());

						Integer getinsAttempt = 1;
						if ((totFirstAttmMint < getIntervel && (userattempt.getAttemptNumber()) != 3)
								|| (totLastAttmMint < getWaiting && (userattempt.getAttemptNumber()) == 3)) {
							getinsAttempt = userattempt.getAttemptNumber();
						}
						if (totattmpt > getinsAttempt) {
							if (getWaiting < totFirstAttmMint) {
								createNdUpdateRecord(curruser, 1, curAttemptTime, curAttemptTime, 0);
								getACount = (int) (totattmpt - 1);
							} else {
								Integer attemptCout = userattempt.getAttemptNumber() + 1;
								createNdUpdateRecord(curruser, attemptCout,
										userattempt.getFirstAttemptDateTime(), curAttemptTime,
										userattempt.getId());
								getACount = (int) (totattmpt - attemptCout);
							}
						}
					}
				} catch (Exception e1) {
					getACount = (int) (totattmpt - 1);
					createNdUpdateRecord(curruser, 1, curAttemptTime, curAttemptTime, 0);
				}

				Integer totatt = totattmpt.intValue();
				if (getACount != 0) {
					throw new BadCredentialsException(messageService.getMessage("lbl.err.inv.pwd.attmpt",
							new Integer[] { totatt, getACount }));
				} else {
					UserLoginAttemptsDto userattempts = getuserDetails(curruser);
					long totMin = DateUtil.convTimestampBetweenFirstAndLastLoginAttempt(curAttemptTime,
							userattempts.getLastAttemptDateTime());
					Integer waittime = (int) (getWaiting - totMin);
					throw new BadCredentialsException(
							messageService.getMessage(LBL_ERR_ACC_PSWD, new Integer[] { waittime }));
				}
			} else {
				throw new BadCredentialsException(messageService.getMessage(LBL_ERR_INV_PSWD)
						+ (errorCode != null ? " [ " + errorCode + " ]" : ""));
			}
		} catch (Exception e) {
			LOGGER.error("Exception: {}", e.getMessage());
			throw new BadCredentialsException(messageService.getMessage(LBL_ERR_INV_PSWD));
		}

		if (login == null || login.getToken() == null) {
			throw new BadCredentialsException(messageService.getMessage(LBL_ERR_INV_PSWD));
		}

		Token token = login.getToken();
		// here to view upload profile picture
		UserProfile userProfile = null;
		com.bestpay.idm.sdk.model.Documents profilePic = null;

		try {
			String curruser = login.getUserId();
			Integer totRec = getCountUserDetails(curruser);
			if (totRec > 0) {
				Boolean logAttempt = getAttemptCountProfile(curruser);
				if (!logAttempt) {
					Integer waittime = getAttemptWaitingTime(curruser);
					throw new BadCredentialsException(
							messageService.getMessage(LBL_ERR_ACC_PSWD, new Integer[] { waittime }));
				}
			}
			userProfile = getIdmService(login.getClientId(), token.getAccessToken()).getUserProfileById(userId, true,
					true);
			Documents profileDocs = getDmService(ProjectEnum.BESTPAY).download(userProfile.getDocMgtId());
			if (!BaseUtil.isObjNull(profileDocs)) {
				profilePic = dozerMapper.map(profileDocs, com.bestpay.idm.sdk.model.Documents.class);
				String str = Base64.encodeBase64String(profileDocs.getContent());
				profilePic.setContentString(str);
				userProfile.setProfilePicture(profilePic);
			}
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("{}", new ObjectMapper().valueToTree(userProfile));
			}

		} catch (IdmException e) {

			LOGGER.error("IdmException: {}", e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
			String errorCode = null;
			errorCode = e.getInternalErrorCode();
			throw new BadCredentialsException(messageService.getMessage(LBL_ERR_INV_PSWD)
					+ (errorCode != null ? " [ " + errorCode + " ]" : ""));
		} catch (Exception e) {
			LOGGER.error("Exception: {}", e.getMessage());
			// throw new
		}

		LOGGER.debug("userProfile: {}", userProfile);
		if (userProfile == null || BaseUtil.isObjNull(userProfile.getUserId())) {
			try {
				staticData.addUserAction(AuditActionPolicy.LOGIN_FAILED, auth.getName(), reqMsg);
			} catch (Exception ex) {
				LOGGER.error("IDM-AuditAction Response Error: {}", ex.getMessage());
			}
			String curruser = login.getUserId();

			Integer totRec = getCountUserDetails(curruser);
			if (totRec > 0) {
				Boolean logAttempt = getAttemptCountProfile(curruser);
				if (!logAttempt) {
					Integer waittime = getAttemptWaitingTime(curruser);
					throw new BadCredentialsException(
							messageService.getMessage(LBL_ERR_ACC_PSWD, new Integer[] { waittime }));
				}
			}
			throw new BadCredentialsException(messageService.getMessage(LBL_ERR_INV_PSWD));
		}

		LOGGER.info("UserType: {}", userProfile.getUserType());
		CustomUserProfile profile = getProfileByUserType(userProfile.getUserType(), userProfile.getProfId(),
				userProfile.getBranchId());
		CustomUserDetails customUserDetails = null;

		if (profile != null) {
			customUserDetails = new CustomUserDetails(userProfile, profile, token);
		} else {
			customUserDetails = new CustomUserDetails(userProfile, token);
		}

		try {
			staticData.addUserAction(AuditActionPolicy.LOGIN, auth.getName(), reqMsg);
		} catch (Exception e) {
			LOGGER.error("IDM-AuditAction Response Error: {}", e.getMessage());
		}

		return new UsernamePasswordAuthenticationToken(customUserDetails, auth.getCredentials(),
				getAuthorities(userProfile));

	}


	public Collection<GrantedAuthority> getAuthorities(UserProfile userProfile) {
		// Create a list of grants for this user
		List<GrantedAuthority> authList = new ArrayList<>();
		LOGGER.debug("userProfile: {}", !BaseUtil.isObjNull(userProfile));

		// Get roles from UserProfile object
		if (!BaseUtil.isObjNull(userProfile) && !BaseUtil.isListNull(userProfile.getRolesList())) {
			LOGGER.debug("Role Size: {}", userProfile.getRolesList().size());
			for (UserRole role : userProfile.getRolesList()) {
				LOGGER.debug("Role: {}", role.getRoleCode());
				authList.add(new SimpleGrantedAuthority(role.getRoleCode()));
			}

		}

		// Return list of granted authorities
		return authList;
	}


	public Long getConfigValue(String configCode) {
		ConfigDto userAttempt = new ConfigDto();
		userAttempt.setConfigCode(configCode);
		userAttempt = getIdmService().userConfig(userAttempt);
		String getTotAtt = userAttempt.getConfigVal();
		return Long.parseLong(getTotAtt);
	}


	public UserLoginAttemptsDto getuserDetails(String username) {
		return getIdmService().getuserattempt(username);
	}


	public Boolean getAttemptCountProfile(String username) {
		Long getWaiting = getConfigValue(WAITING_TIME);
		Long getAmtLogin = getConfigValue("ATTEMPT_LOGIN");
		boolean countAtt = true;
		UserLoginAttemptsDto userattempts = getuserDetails(username);
		try {
			java.sql.Timestamp curAttemptTime = DateUtil.getSQLTimestamp();
			long totMin = DateUtil.convTimestampBetweenFirstAndLastLoginAttempt(curAttemptTime,
					userattempts.getLastAttemptDateTime());
			Integer waittime = (int) (getWaiting - totMin);
			Integer attmt = userattempts.getAttemptNumber();
			Integer getTotAmt = getAmtLogin.intValue();
			if (waittime > 0 && attmt.equals(getTotAmt)) {
				countAtt = false;
			}
		} catch (Exception e) {
			LOGGER.debug("Attempt Record not found.");
		}
		return countAtt;
	}


	public int getCountUserDetails(String username) {
		UserLoginAttemptsDto userattempt = new UserLoginAttemptsDto();
		Integer countAtt = 0;
		try {
			userattempt = getIdmService().getuserattempt(username);
			countAtt = userattempt.getId();
		} catch (Exception e) {
			LOGGER.debug("Attempt Record not found.");
		}

		return countAtt;
	}


	public Integer getAttemptWaitingTime(String username) {
		Long getWaiting = getConfigValue(WAITING_TIME);
		UserLoginAttemptsDto userattempts = getuserDetails(username);
		java.sql.Timestamp curAttemptTime = DateUtil.getSQLTimestamp();
		long totMin = DateUtil.convTimestampBetweenFirstAndLastLoginAttempt(curAttemptTime,
				userattempts.getLastAttemptDateTime());
		return (int) (getWaiting - totMin);
	}


	public UserLoginAttemptsDto createNdUpdateRecord(String username, Integer attempt, java.sql.Timestamp ftime,
			java.sql.Timestamp ltime, Integer upid) {
		UserLoginAttemptsDto userLoginAttemptsDto = new UserLoginAttemptsDto();
		userLoginAttemptsDto.setUserId(username);
		try {
			InetAddress ip = InetAddress.getLocalHost();
			userLoginAttemptsDto.setIpAddress(ip.getHostAddress());
			LOGGER.info("HOST ADDRESS ---- {}", ip.getHostAddress());
		} catch (UnknownHostException e1) {
			LOGGER.debug("Error message = {}", e1);
		}
		userLoginAttemptsDto.setCreateId(username);
		userLoginAttemptsDto.setAttemptNumber(attempt);
		userLoginAttemptsDto.setFirstAttemptDateTime(ftime);
		userLoginAttemptsDto.setLastAttemptDateTime(ltime);
		if (upid != 0) {
			userLoginAttemptsDto.setId(upid);
			userLoginAttemptsDto.setUpdateId(username);
		}
		userLoginAttemptsDto = getIdmService().userattempt(userLoginAttemptsDto);
		return userLoginAttemptsDto;

	}


	private CustomUserProfile getProfileByUserType(String userType, Integer profId, Integer branchId) {
		CustomUserProfile profile = null;
		LOGGER.info("getProfileByUserType>>> {} - {} - {}", userType, profId, branchId);

		return profile;
	}

}