/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BeUrlConstants {

	private BeUrlConstants() {
		throw new IllegalStateException("BeUrlConstants class");
	}


	public static final String SERVICE_CHECK = "/serviceCheck";

	public static final String REFERENCE = "/references";

	public static final String CONFIG = "/config";

	public static final String SERVICES = "/services";

	public static final String API_SERVICES = SERVICES + "/api";

	public static final String API_GENERATE_QR = API_SERVICES + "/digitalid/qr/generate";

	public static final String MOBILE_SERVICES = SERVICES + "/mobile";

	public static final String MOBILE_REGISTRATION_CERT = MOBILE_SERVICES + "/registration/cert";

	public static final String MOBILE_STORE_CERT = MOBILE_SERVICES + "/store/cert";

	public static final String MOBILE_SUBMIT_CERT = MOBILE_SERVICES + "/submit/cert";

	public static final String MOBILE_REVOKE_CERT = MOBILE_SERVICES + "/revoke/cert";

	public static final String MOBILE_LOGIN = MOBILE_SERVICES + "/login";

	public static final String MOBILE_LOGOUT = MOBILE_SERVICES + "/logout";

	public static final String API_DEVICE_SEARCH = API_SERVICES + "/device/search";

	public static final String API_USER_SEARCH = API_SERVICES + "/user/search";

	public static final String API_USER_REGISTER = API_SERVICES + "/user/register";

	public static final String API_CONTACT_UPDATE = API_SERVICES + "/contact/update";

	public static final String API_ACTIVATION_CODE_GENERATE = API_SERVICES + "/activationCode/generate";

	public static final String API_ACTIVATION_CODE_VERIFY = API_SERVICES + "/activationCode/verify";

	public static final String API_VERIFY_QR_CODE = API_SERVICES + "/qr/verify";

	public static final String API_VERIFY_PHOTO = API_SERVICES + "/photo/verify";
	
	public static final String API_DIGITALID_STATUS_CHECK = API_SERVICES + "/digitalId/status/check";

	public static final String MOBILE_SEARCH_FACE = MOBILE_SERVICES + "/face/search";

	public static final String MOBILE_PINCODE_VERIFY = MOBILE_SERVICES + "/pinCode/verify";

	public static final String MOBILE_PINCODE_UPDATE = MOBILE_SERVICES + "/pinCode/update";

	public static final String MOBILE_GEN_INVITATION_CODE = MOBILE_SERVICES + "/invCode/generate";

	public static final String MOBILE_VERIFY_INVITATION_CODE = MOBILE_SERVICES + "/invCode/verify";

	public static final String SUBSCRIBER_SERVICES = SERVICES + "/subscriber";

	public static final String SUBSCRIBER_ADD = SUBSCRIBER_SERVICES + "/addSubscriber";

	public static final String SUBSCRIBER_SEARCH_COMPANY = SUBSCRIBER_SERVICES + "/searchCompany";

	public static final String SUBSCRIBER_LIST = SUBSCRIBER_SERVICES + "/subscriberList";

	public static final String SUBSCRIBER_DEACTIVATED = SUBSCRIBER_SERVICES + "/subscriberDeactivated";

	public static final String MOBILE_SEARCH_PROFILE = MOBILE_SERVICES + "/profile/search";

	public static final String MOBILE_VERIFY_AUTH = MOBILE_SERVICES + "/auth/verify";

	public static final String MOBILE_VERIFY_DIGITALID = MOBILE_SERVICES + "/digitalId/verify";

	public static final String MOBILE_REGISTER_PROFILE = MOBILE_SERVICES + "/profile/register";

	public static final String MAINTENANCE = "/maintenance";

	public static final String MAINTENANCE_BIDCONFIG = MAINTENANCE + "/bidConfig";

	public static final String MAINTENANCE_BIDCONFIG_UPDATE = MAINTENANCE_BIDCONFIG + "/update";

	public static final String MAINTENANCE_BIDCONFIG_CREATE = MAINTENANCE_BIDCONFIG + "/create";

	public static final String MAINTENANCE_BIDCONFIG_FIND_BY_ID = MAINTENANCE_BIDCONFIG + "/findById";

	public static final String MAINTENANCE_BIDCONFIG_PAGINATED = MAINTENANCE_BIDCONFIG + "/paginated";

	public static final String MAINTENANCE_BIDCONFIG_DELETED = MAINTENANCE_BIDCONFIG + "/remove";

	public static final String MAINTENANCE_BIDCONFIG_CD_VALIDATE = MAINTENANCE_BIDCONFIG + "/cdvalidate";

	public static final String GET_ALL_DOCUMENTS_ID = "/findDocById";

}
