
package com.bestpay.pgw.sdk.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "incomeSource",
    "isCompleted",
    "natureOfBusiness",
    "pepInfo",
    "wealthInfo"
})
public class Edd {

    @JsonProperty("incomeSource")
    private String incomeSource;
    @JsonProperty("isCompleted")
    private String isCompleted;
    @JsonProperty("natureOfBusiness")
    private String natureOfBusiness;
    @JsonProperty("pepInfo")
    private String pepInfo;
    @JsonProperty("wealthInfo")
    private String wealthInfo;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("incomeSource")
    public String getIncomeSource() {
        return incomeSource;
    }

    @JsonProperty("incomeSource")
    public void setIncomeSource(String incomeSource) {
        this.incomeSource = incomeSource;
    }

    @JsonProperty("isCompleted")
    public String getIsCompleted() {
        return isCompleted;
    }

    @JsonProperty("isCompleted")
    public void setIsCompleted(String isCompleted) {
        this.isCompleted = isCompleted;
    }

    @JsonProperty("natureOfBusiness")
    public String getNatureOfBusiness() {
        return natureOfBusiness;
    }

    @JsonProperty("natureOfBusiness")
    public void setNatureOfBusiness(String natureOfBusiness) {
        this.natureOfBusiness = natureOfBusiness;
    }

    @JsonProperty("pepInfo")
    public String getPepInfo() {
        return pepInfo;
    }

    @JsonProperty("pepInfo")
    public void setPepInfo(String pepInfo) {
        this.pepInfo = pepInfo;
    }

    @JsonProperty("wealthInfo")
    public String getWealthInfo() {
        return wealthInfo;
    }

    @JsonProperty("wealthInfo")
    public void setWealthInfo(String wealthInfo) {
        this.wealthInfo = wealthInfo;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
