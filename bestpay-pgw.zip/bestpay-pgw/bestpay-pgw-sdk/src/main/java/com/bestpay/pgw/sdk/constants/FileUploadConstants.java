/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since 03/03/2018
 */
public class FileUploadConstants {

	public static final String PROFILE_PIC = "PROFPIC";


	private FileUploadConstants() {

	}

}