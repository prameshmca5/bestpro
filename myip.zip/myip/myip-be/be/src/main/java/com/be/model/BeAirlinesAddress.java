/**
 * 
 */
package com.be.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_AIRLINES_ADDRESS")
public class BeAirlinesAddress extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = 6925360134634315100L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="AIRLINES_ADDR_ID")
	private Integer airlinesAddrId;

	@JsonIgnoreProperties("airlinesAddresses")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "AIRLINES_PROF_ID")
	private BeAirlinesProfile airlinesProfile;
 
 	@Column(name = "ADDR_1")
	private String addr1;

	@Column(name = "ADDR_2")
	private String addr2;

	@Column(name = "ADDR_3")
	private String addr3;

	@Column(name = "ADDR_4")
	private String addr4;
	
	@Column(name = "CITY_DESC")
	private String cityDesc;

	@Column(name = "STATE_DESC")
	private String stateDesc;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CITY_CD")
	private RefCity city;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATE_CD")
	private RefState state;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNTRY_CD")
	private RefCountry country;
	
	@Column(name = "ZIPCODE")
	private String zipcode;

	@Column(name = "ADDR_TYPE")
	private String addrType;
	
	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	public Integer getAirlinesAddrId() {
		return airlinesAddrId;
	}

	public void setAirlinesAddrId(Integer airlinesAddrId) {
		this.airlinesAddrId = airlinesAddrId;
	}

	public BeAirlinesProfile getAirlinesProfile() {
		return airlinesProfile;
	}

	public void setAirlinesProfile(BeAirlinesProfile airlinesProfile) {
		this.airlinesProfile = airlinesProfile;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getAddr3() {
		return addr3;
	}

	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}

	public String getAddr4() {
		return addr4;
	}

	public void setAddr4(String addr4) {
		this.addr4 = addr4;
	}

	public String getCityDesc() {
		return cityDesc;
	}

	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc;
	}

	public String getStateDesc() {
		return stateDesc;
	}

	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc;
	}

	public RefCity getCity() {
		return city;
	}

	public void setCity(RefCity city) {
		this.city = city;
	}

	public RefState getState() {
		return state;
	}

	public void setState(RefState state) {
		this.state = state;
	}

	public RefCountry getCountry() {
		return country;
	}

	public void setCountry(RefCountry country) {
		this.country = country;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getAddrType() {
		return addrType;
	}

	public void setAddrType(String addrType) {
		this.addrType = addrType;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}
	
}
