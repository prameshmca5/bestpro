/**
 *
 */
package com.be.service;


import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeAcctTravellerQf;
import com.be.dao.BeAcctTravellerRepository;
import com.be.model.BeAcctPassport;
import com.be.model.BeAcctProfile;
import com.be.model.BeAcctTraveller;
import com.be.model.BeTvl;
import com.be.model.BeTvlProfile;
import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_ACCT_TRAVELLER_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_ACCT_TRAVELLER_SVC)
public class BeAcctTravellerService extends AbstractService<BeAcctTraveller> {

	@Autowired
	private BeAcctTravellerRepository beAcctTravellerDao;

	@Autowired
	BeAcctTravellerQf beAcctTravellerQf;

	@Autowired
	BeAcctPassportService beAcctPassportSvc;

	@Autowired
	BeTvlProfileService beTvlProfileSvc;


	@Override
	public GenericRepository<BeAcctTraveller> primaryDao() {
		return beAcctTravellerDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beAcctTravellerQf.generateCriteria(cb, from, criteria);
	}


	@SuppressWarnings("unchecked")
	public List<AcctTraveller> searchBeAcctTravellerPagination(AcctTraveller dto, DataTableRequest<?> dataTableInRQ)
			throws IOException {
		return JsonUtil.transferToList(beAcctTravellerQf.searchBeAcctTravellerPagination(dto, dataTableInRQ),
				AcctTraveller.class);
	}


	public BeAcctTraveller searchBeAcctTraveller(AcctTraveller dto) {
		return beAcctTravellerQf.searchBeAcctTraveller(dto);
	}


	public BeAcctTraveller searchBeAcctTravellerInner(AcctTraveller dto) {
		return beAcctTravellerQf.searchBeAcctTravellerInner(dto);
	}


	public long getCount(AcctTraveller dto) {
		return beAcctTravellerQf.getCount(dto);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class })
	public BeAcctTraveller addTravellerInfo(AcctTraveller dto, Integer acctProfId, String userId, List<BeTvl> beTvls)
			throws IOException {

		BeAcctTraveller beAcctTraveller = JsonUtil.transferToObject(dto, BeAcctTraveller.class);

		BeAcctTraveller beAcctTravellerOri = null;
		if (BaseUtil.isObjNull(dto.getAcctTvlrId())) {
			beAcctTraveller.setCreateId(userId);
			beAcctTraveller.setIsPaid(false);
			if (BaseUtil.isObjNull(dto.getAcctProfile()) && !BaseUtil.isObjNull(acctProfId)) {
				BeAcctProfile acctProfile = new BeAcctProfile();
				acctProfile.setAcctProfId(acctProfId);
				beAcctTraveller.setAcctProfile(acctProfile);
			}
		} else {
			AcctTraveller atDto = new AcctTraveller();
			atDto.setAcctTvlrId(dto.getAcctTvlrId());
			beAcctTravellerOri = searchBeAcctTraveller(atDto);
			beAcctTraveller.setCreateId(beAcctTravellerOri.getCreateId());
			beAcctTraveller.setCreateDt(beAcctTravellerOri.getCreateDt());
			beAcctTraveller.setIsPaid(beAcctTravellerOri.getIsPaid());
			beAcctTraveller.setAcctProfile(beAcctTravellerOri.getAcctProfile());
		}

		if (!BaseUtil.isObjNull(dto.getAcctPassport()) && !BaseUtil.isObjNull(dto.getAcctPassport())) {
			if (!BaseUtil.isObjNull(beAcctTravellerOri)
					&& !BaseUtil.isObjNull(beAcctTravellerOri.getAcctPassport())) {
				beAcctTravellerOri.getAcctPassport().setIsActive(false);
				beAcctTravellerOri.getAcctPassport().setUpdateId(userId);
				beAcctPassportSvc.update(beAcctTravellerOri.getAcctPassport());
			}
			BeAcctPassport passport = beAcctPassportSvc.createUpdate(beAcctTraveller.getAcctPassport(), userId);
			beAcctTraveller.setAcctPassport(passport);
		}

		// if(!BaseUtil.isListNull(dto.getTrxnDocumentList())) {
		// if(BaseUtil.isObjNull(beAcctTraveller))
		// }

		beAcctTraveller.setUpdateId(userId);
		beAcctTraveller = update(beAcctTraveller);

		if (BaseUtil.isObjNull(beAcctTraveller.getAcctPassport().getAcctTvlrId())) {
			beAcctTraveller.getAcctPassport().setAcctTvlrId(beAcctTraveller.getAcctTvlrId());
			beAcctPassportSvc.update(beAcctTraveller.getAcctPassport());
		}

		beTvlProfileSvc.updateTvlProfile(JsonUtil.transferToObject(beAcctTraveller, BeTvlProfile.class),
				beAcctTraveller, beTvls, userId);

		return beAcctTraveller;
	}


	public List<BeAcctTraveller> searchAllByProperty(BeAcctTraveller profile) {
		return beAcctTravellerQf.searchAllByProperty(profile);
	}


	public List<BeAcctTraveller> saveList(List<BeAcctTraveller> infos) {
		return beAcctTravellerDao.save(infos);
	}
}
