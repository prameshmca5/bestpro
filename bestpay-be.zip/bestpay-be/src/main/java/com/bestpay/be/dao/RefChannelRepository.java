/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.RefChannel;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Afif saman
 * @since Jul 10, 2018
 */
@Repository
@RepositoryDefinition(domainClass = RefChannel.class, idClass = Integer.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_CHANNEL_DAO)
public interface RefChannelRepository extends GenericRepository<RefChannel> {

	@Query("select u from RefChannel u where u.publicName = :publicName ")
	RefChannel findRefChannelByPublicName(@Param("publicName") String publicName);


	@Query("select count(u) from RefChannel u ")
	int totalRecords();


	@Query("select u from RefChannel u where u.publicName = :publicName")
	List<RefChannel> findChannelByPublicName(@Param("publicName") String publicName);


	@Query("select u from RefChannel u where u.name = :name")
	List<RefChannel> findChannelByName(@Param("name") String name);

}