/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeAcctPassport;
import com.be.model.BeAcctProfile;
import com.be.model.BeAcctTraveller;
import com.be.model.RefCountry;
import com.be.model.RefMetadata;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.AcctProfile;
import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Metadata;
import com.be.service.BeAcctPassportService;
import com.be.service.BeAcctProfileService;
import com.be.service.RefCountryService;
import com.be.service.RefMetadataService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;


/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_ACCT_TRAVELLER_QF)
public class BeAcctTravellerQf extends QueryFactory<BeAcctTraveller> {

	@Autowired
	BeAcctPassportService acctPassportSvc;

	@Autowired
	BeAcctProfileService beAcctProfileSvc;

	@Autowired
	RefMetadataService refMetadataSvc;

	@Autowired
	RefCountryService refCountrySvc;

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BeAcctTraveller> searchByProperty(BeAcctTraveller t) {
		return (Root<BeAcctTraveller> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}


	@Override
	public List<BeAcctTraveller> searchAllByProperty(BeAcctTraveller t) {
		CriteriaQuery<BeAcctTraveller> cq = cb.createQuery(BeAcctTraveller.class);
		Root<BeAcctTraveller> from = cq.from(BeAcctTraveller.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public List<BeAcctTraveller> searchBeAcctTravellerPagination(AcctTraveller dto,
			DataTableRequest<?> dataTableInRQ) {

		List<BeAcctTraveller> result = new ArrayList<>();
		CriteriaQuery<BeAcctTraveller> cq = cb.createQuery(BeAcctTraveller.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeAcctTraveller> root = cq.from(BeAcctTraveller.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					cq.orderBy(getOrderByClause(cb, root, pagination));
				}
			}

			TypedQuery<BeAcctTraveller> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}


	public BeAcctTraveller searchBeAcctTraveller(AcctTraveller dto) {

		BeAcctTraveller result = null;
		CriteriaQuery<BeAcctTraveller> cq = cb.createQuery(BeAcctTraveller.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeAcctTraveller> root = cq.from(BeAcctTraveller.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeAcctTraveller> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}


	public Long getCount(AcctTraveller dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeAcctTraveller> root = cq.from(BeAcctTraveller.class);
		predicates.addAll(generateCriteria(cb, root, dto));

		if (!BaseUtil.isObjNull(dto.getTypeMtdtCd())) {
			Metadata typeMtdtDto = new Metadata();
			typeMtdtDto.setMtdtCd(dto.getTypeMtdtCd());
			Join<BeAcctTraveller, RefMetadata> typeMtdt = root.join("typeMtdt", JoinType.LEFT);
			predicates.addAll(refMetadataSvc.generateCriteria(cb, typeMtdt, typeMtdtDto));
		}

		if (!BaseUtil.isObjNull(dto.getRelationMtdtCd())) {
			Metadata relationMtdtDto = new Metadata();
			relationMtdtDto.setMtdtCd(dto.getRelationMtdtCd());
			Join<BeAcctTraveller, RefMetadata> relationMtdt = root.join("relationMtdt", JoinType.LEFT);
			predicates.addAll(refMetadataSvc.generateCriteria(cb, relationMtdt, relationMtdtDto));
		}

		if (!BaseUtil.isObjNull(dto.getPassportNo()) || !BaseUtil.isObjNull(dto.getNationality())) {
			Join<BeAcctTraveller, BeAcctPassport> passport = root.join("acctPassport", JoinType.LEFT);
			predicates.addAll(acctPassportSvc.generateCriteria(cb, passport, dto));

			if (!BaseUtil.isObjNull(dto.getNationality())
					&& !BaseUtil.isObjNull(dto.getNationality().getCntryCd())) {
				Join<BeAcctPassport, RefCountry> nationality = passport.join("nationality", JoinType.LEFT);
				predicates.addAll(refCountrySvc.generateCriteria(cb, nationality, dto.getNationality()));
			}
		}

		if (!BaseUtil.isObjNull(dto.getAcctProfId())) {
			AcctProfile acctProfileDto = new AcctProfile();
			acctProfileDto.setAcctProfId(dto.getAcctProfId());
			Join<BeAcctTraveller, BeAcctProfile> acctProfile = root.join("acctProfile", JoinType.LEFT);
			predicates.addAll(beAcctProfileSvc.generateCriteria(cb, acctProfile, dto));
		}

		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			AcctTraveller dto = JsonUtil.transferToObject(criteria, AcctTraveller.class);
			if (!BaseUtil.isObjNull(dto.getAcctTvlrId())) {
				predicates.add(cb.equal(from.get("acctTvlrId"), dto.getAcctTvlrId()));
			} else if (!BaseUtil.isListNull(dto.getAcctTvlrIdList())) {
				predicates.add(from.get("acctTvlrId").in(dto.getAcctTvlrIdList()).not());
			}

			if (!BaseUtil.isObjNull(dto.getFullName())) {
				predicates.add(cb.like(from.get("fullName"), "%" + dto.getFullName() + "%"));
			}

			if (!BaseUtil.isObjNull(dto.getIsPaid())) {
				predicates.add(cb.equal(from.get("isPaid"), dto.getIsPaid()));
			}

		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void joinFetch(From<?, ?> from, List<Predicate> predicates, AcctTraveller dto, CriteriaQuery<?> cq) {

		from.fetch("nationality", JoinType.LEFT);
		from.fetch("country", JoinType.LEFT);

		Join<BeAcctTraveller, RefMetadata> typeMtdt = (Join) from.fetch("typeMtdt", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getTypeMtdtCd())) {
			Metadata typeMtdtDto = new Metadata();
			typeMtdtDto.setMtdtCd(dto.getTypeMtdtCd());
			predicates.addAll(refMetadataSvc.generateCriteria(cb, typeMtdt, typeMtdtDto));
		}

		Join<BeAcctTraveller, RefMetadata> relationMtdt = (Join) from.fetch("relationMtdt", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getRelationMtdtCd())) {
			Metadata relationMtdtDto = new Metadata();
			relationMtdtDto.setMtdtCd(dto.getRelationMtdtCd());
			predicates.addAll(refMetadataSvc.generateCriteria(cb, relationMtdt, relationMtdtDto));
		}

		Join<BeAcctTraveller, BeAcctPassport> passport = (Join) from.fetch("acctPassport", JoinType.LEFT);
		Join<BeAcctPassport, RefCountry> nationality = (Join) passport.fetch("nationality", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getPassportNo()) || !BaseUtil.isObjNull(dto.getNationality())) {
			predicates.addAll(acctPassportSvc.generateCriteria(cb, passport, dto));
			if (!BaseUtil.isObjNull(dto.getNationality())
					&& !BaseUtil.isObjNull(dto.getNationality().getCntryCd())) {
				predicates.addAll(refCountrySvc.generateCriteria(cb, nationality, dto.getNationality()));
			}
		}

		if (!BaseUtil.isObjNull(dto.getAcctProfId())) {
			AcctProfile acctProfileDto = new AcctProfile();
			acctProfileDto.setAcctProfId(dto.getAcctProfId());
			Join<BeAcctTraveller, BeAcctProfile> acctProfile = from.join("acctProfile", JoinType.LEFT);
			predicates.addAll(beAcctProfileSvc.generateCriteria(cb, acctProfile, acctProfileDto));
		}

		if (dto.isView()) {
			from.fetch("acctProfile", JoinType.LEFT);
			from.fetch("ecRelationMtdt", JoinType.LEFT);
			from.fetch("country", JoinType.LEFT);
			from.fetch("birthPlace", JoinType.LEFT);
		}
	}


	public BeAcctTraveller searchBeAcctTravellerInner(AcctTraveller dto) {

		BeAcctTraveller result = null;
		CriteriaQuery<BeAcctTraveller> cq = cb.createQuery(BeAcctTraveller.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeAcctTraveller> root = cq.from(BeAcctTraveller.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetchInner(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeAcctTraveller> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void joinFetchInner(From<?, ?> from, List<Predicate> predicates, AcctTraveller dto, CriteriaQuery<?> cq) {

		Join<BeAcctTraveller, RefMetadata> typeMtdt = (Join) from.fetch("typeMtdt", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getTypeMtdtCd())) {
			Metadata typeMtdtDto = new Metadata();
			typeMtdtDto.setMtdtCd(dto.getTypeMtdtCd());
			predicates.addAll(refMetadataSvc.generateCriteria(cb, typeMtdt, typeMtdtDto));
		}

		Join<BeAcctTraveller, RefMetadata> relationMtdt = (Join) from.fetch("relationMtdt", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getRelationMtdtCd())) {
			Metadata relationMtdtDto = new Metadata();
			relationMtdtDto.setMtdtCd(dto.getRelationMtdtCd());
			predicates.addAll(refMetadataSvc.generateCriteria(cb, relationMtdt, relationMtdtDto));
		}

		Join<BeAcctTraveller, BeAcctPassport> passport = (Join) from.fetch("acctPassport", JoinType.INNER);
		Join<BeAcctPassport, RefCountry> nationality = (Join) passport.fetch("nationality", JoinType.INNER);
		if (!BaseUtil.isObjNull(dto.getPassportNo()) || !BaseUtil.isObjNull(dto.getNationality())) {
			predicates.addAll(acctPassportSvc.generateCriteria(cb, passport, dto));
			if (!BaseUtil.isObjNull(dto.getNationality())
					&& !BaseUtil.isObjNull(dto.getNationality().getCntryCd())) {
				predicates.addAll(refCountrySvc.generateCriteria(cb, nationality, dto.getNationality()));
			}
		}

		if (!BaseUtil.isObjNull(dto.getAcctProfId())) {
			AcctProfile acctProfileDto = new AcctProfile();
			acctProfileDto.setAcctProfId(dto.getAcctProfId());
			Join<BeAcctTraveller, BeAcctProfile> acctProfile = from.join("acctProfile", JoinType.INNER);
			predicates.addAll(beAcctProfileSvc.generateCriteria(cb, acctProfile, acctProfileDto));
		}

		if (dto.isView()) {
			from.fetch("acctProfile", JoinType.LEFT);
			from.fetch("ecRelationMtdt", JoinType.LEFT);
			from.fetch("country", JoinType.LEFT);
			from.fetch("birthPlace", JoinType.LEFT);
		}
	}
}
