package com.bestpay.be.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;

/**
 * @author Atiqah Khairuddin
 * @since May 23, 2019
 */
@Entity
@Table(name = "PGW_MERCHANT_COMPANY_BANK_DETAILS")
public class PgwMerchantCompanyBankDetails extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "MER_COMP_BANK_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer compBankId;

	@Column(name = "COMP_REF_ID")
	private String compRefId;
	
	@Column(name = "COMP_BANK_NAME")
	private String bankName;

	@Column(name = "COMP_BANK_ACC_NAME")
	private String bankAccName;

	@Column(name = "COMP_BANK_ACC_NO")
	private String bankAccNo;

	@Column(name = "COMP_BANK_BRANCH")
	private String bankBranch;

	@Column(name = "COMP_BANK_LOCATION")
	private String bankLocation;

	@Column(name = "COMP_BANK_COUNTRY")
	private String bankCountry;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	public Integer getCompBankId() {
		return compBankId;
	}

	public void setCompBankId(Integer compBankId) {
		this.compBankId = compBankId;
	}

	public String getCompRefId() {
		return compRefId;
	}

	public void setCompRefId(String compRefId) {
		this.compRefId = compRefId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankAccName() {
		return bankAccName;
	}

	public void setBankAccName(String bankAccName) {
		this.bankAccName = bankAccName;
	}

	public String getBankAccNo() {
		return bankAccNo;
	}

	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}

	public String getBankBranch() {
		return bankBranch;
	}

	public void setBankBranch(String bankBranch) {
		this.bankBranch = bankBranch;
	}

	public String getBankLocation() {
		return bankLocation;
	}

	public void setBankLocation(String bankLocation) {
		this.bankLocation = bankLocation;
	}

	public String getBankCountry() {
		return bankCountry;
	}

	public void setBankCountry(String bankCountry) {
		this.bankCountry = bankCountry;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}
