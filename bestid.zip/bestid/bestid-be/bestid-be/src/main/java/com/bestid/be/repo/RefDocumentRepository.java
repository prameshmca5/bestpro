package com.bestid.be.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.RefDocument;


@Repository
@RepositoryDefinition(domainClass = RefDocument.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_DOCUMENT_DAO)
public interface RefDocumentRepository extends GenericRepository<RefDocument> {

	@Query("select u from RefDocument u where u.trxnNo = :trxnNo")
	public List<RefDocument> findAllByTrxnNo(@Param("trxnNo") String trxnNo);

	@Query("select u from RefDocument u where u.docId = :docId ")
	public RefDocument findTrxnDocumentsByDocId(@Param("docId") Integer docId);
	
	@Query("select u from RefDocument u where u.trxnNo = :trxnNo")
	public RefDocument findTrxnDocumentsByTrxnNo(@Param("trxnNo") String trxnNo);
	
	@Query("select u from RefDocument u where u.trxnNo = :trxnNo and u.trxnNo = :title and u.docDescEn = :docDescEn")
	public RefDocument findTrxnDocumentsByTrxnNoTitleDocDesc(@Param("trxnNo") String trxnNo,@Param("title") String title,@Param("docDescEn") String docDescEn);
	
}