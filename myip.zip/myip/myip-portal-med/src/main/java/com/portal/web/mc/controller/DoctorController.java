package com.portal.web.mc.controller;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.be.sdk.constants.IdmRoleConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.DoctorProfile;
import com.be.sdk.model.McProfile;
import com.be.sdk.model.Status;
import com.be.sdk.model.TrxnDocuments;
import com.dm.sdk.exception.DmException;
import com.dm.sdk.model.Documents;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.idm.sdk.exception.IdmException;
import com.idm.sdk.model.ForgotPassword;
import com.idm.sdk.model.UserGroup;
import com.idm.sdk.model.UserGroupBranch;
import com.idm.sdk.model.UserProfile;
import com.portal.config.audit.AuditActionControl;
import com.portal.config.audit.AuditActionPolicy;
import com.portal.constants.AppConstants;
import com.portal.constants.CryptoBaseUtil;
import com.portal.constants.IDORUtil;
import com.portal.constants.MessageConstants;
import com.portal.constants.PageConstants;
import com.portal.constants.PageTemplate;
import com.portal.constants.ProjectEnum;
import com.portal.constants.TrippleDes;
import com.portal.core.AbstractController;
import com.portal.web.util.WebUtil;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.PopupBox;
import com.util.UidGenerator;
import com.util.constants.BaseConstants;
import com.util.model.CustomMultipartFile;
import com.util.model.FileUpload;
import com.util.model.RefDocuments;
import com.util.pagination.DataTableResults;


@Controller
@RequestMapping(value = PageConstants.PAGE_SEARCH_DOCTOR)
public class DoctorController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(DoctorController.class);

	private static final String JS_FILENAME = "doctor";

	private static final String MODULE = "";

	private static final String PAGE_USER_ID = "/user?id=";

	private static final String PFX_IDMUPD = "idmupd";

	private static final String PFX_ISADMIN = "isAdmin";

	private static final String PFX_ISINACTIVE = "isInactive";

	private static final String PFX_NEWUSER = "newUser";

	private static final String PFX_UPDUSER = "updUser";

	private static final String PFX_USERID = "userId";

	private static final String PFX_USRCREATE = "usrCreate";

	private static final String PFX_USRUPDATE = "usrUpdate";

	private static final String PFX_ERROR = "Error";

	private static final String PFX_USERPROFILE = "userProfile";

	public Map<String, String> userSecretMap = new HashMap<>();

	@Autowired
	@Qualifier("doctorValidator")
	private Validator validator;


	@Override
	protected void bindingPreparation(WebDataBinder binder) {

//		userSecretMap = new HashMap<>();
		binder.setValidator(validator);
		binder.setBindEmptyMultipartFiles(false);
		super.bindingPreparation(binder);
	}


	@GetMapping
	public ModelAndView list(@ModelAttribute("doctorProfile") DoctorProfile doctorProfile, UserProfile userProfile,
			BindingResult result, HttpServletRequest request) {

		ModelAndView mav = getDefaultMav(PageTemplate.PAGE_DOC_SRCH, MODULE, null, null, JS_FILENAME);
		mav.addObject(AppConstants.PORTAL_MODULE, "doc-search");
		return mav;
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String getDocList(@ModelAttribute("doctorProfile") DoctorProfile doctorProfile,
			UserProfile userProfile, BindingResult result, HttpServletRequest request, HttpSession session) {

		LOGGER.info("GET PAGINATED USER LIST....");
		DataTableResults<UserProfile> tasks = null;
		try {
			UserProfile authUser = getCurrentUser();

			userProfile.setUserTypeCode(authUser.getUserTypeCode());
			if (!BaseUtil.isObjNull(authUser)) {
				String userRoleGroupCode = !BaseUtil.isObjNull(authUser.getUserRoleGroup())
						? BaseUtil.getStr(authUser.getUserRoleGroup().getUserGroupCode())
						: BaseUtil.getStr(authUser.getUserGroupCode());
				LOGGER.info("userRoleGroup: {}", userRoleGroupCode);

				// Add filter for the roles logged in user can create
				if (!BaseUtil.isObjNull(userRoleGroupCode)) {
					List<String> userGroup = new ArrayList<>();
					userGroup.add(userRoleGroupCode);
					userProfile.setUserRoleGroupCodeList(userGroup);
				} else {
					LOGGER.warn("User role group not found.");
				}

				// Add filter by country, if exists in logged in user
				if (!BaseUtil.isObjNull(authUser.getCntryCd())) {
					userProfile.setCntryCd(authUser.getCntryCd());
				}

				// Add filter by role branch, if exists in logged in user
				if (!BaseUtil.isObjNull(authUser.getUserGroupRoleBranchCd())) {
					userProfile.setUserGroupRoleBranchCd(authUser.getUserGroupRoleBranchCd());
				}

				// Add filter by profId, if exists in logged in user
				// if (!BaseUtil.isObjNull(authUser.getProfId())) {
				// userProfile.setProfId(authUser.getProfId());
				// }

				if (!BaseUtil.isObjNull(authUser.getUserGroupRoleBranchCode())) {
					userProfile.setUserGroupRoleBranchCode(authUser.getUserGroupRoleBranchCode());
				}

				// Add filter by branchId, if exists in logged in user
				/*
				 * if
				 * ((!BaseUtil.isObjNull(authUser.getUserGroupRoleBranchCd()
				 * ) ||
				 * !BaseUtil.isObjNull(authUser.getUserGroupRoleBranchCode()
				 * )) && !BaseUtil.isObjNull(authUser.getBranchId())) {
				 * userProfile.setBranchId(authUser.getBranchId()); }
				 */

				if (!BaseUtil.isObjNull(authUser.getBranchId())) {
					userProfile.setBranchId(authUser.getBranchId());
				}

			}

			tasks = getIdmService().searchUserProfile(userProfile, false, getPaginationRequest(request, true));
			List<UserProfile> newTasks = JsonUtil.objectMapper().convertValue(tasks.getData(),
					new TypeReference<List<UserProfile>>() {
					});

			String keySecret = staticData.beConfig("HASH_SECRET_KEY");
//			int randomNo = new Random().nextInt();
			newTasks = newTasks.stream().map(task -> {
				try {
					String cyptString = CryptoBaseUtil.encrypt(task.getUserId(),keySecret );
					
//					String hash = IDORUtil.computeFrontEndIdentifier(randomNo + task.getUserId());
					task.setSecCdId(cyptString);
//					session.setAttribute("hashId", hash);
//					session.setAttribute("mgUserId", task.getUserId());
//					userSecretMap.put(hash, task.getUserId());
//					session.setAttribute("userSecretMap", userSecretMap);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return task;
				}

				return task;
			}).collect(Collectors.toList());

			if (!BaseUtil.isListNull(newTasks)) {
				tasks.setData(newTasks);
			}
		} catch (Exception e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(e.getMessage());
		}

		return new Gson().toJson(tasks);
	}


	@GetMapping(value = "/addDr")
	public ModelAndView viewProfile(@RequestParam("id") String id,
			@ModelAttribute("doctorProfile") DoctorProfile doctorProfile, BindingResult result) {
		ModelAndView mav = getDefaultMavProfile(id);
		mav.getModelMap().get(PFX_USERPROFILE);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.usr.prof"));
		mav.addObject(AppConstants.PORTAL_MODULE, "doc-add");
		mav.addObject("refDocLst01", getRefDocLst01());
		mav.addObject("refDocLst02", getRefDocLst02());
		mav.addObject("refDocLst03", getRefDocLst03());
		return mav;
	}


	@PostMapping(value = "/addDr")
	public ModelAndView create(@Valid @ModelAttribute("doctorProfile") DoctorProfile doctorProfile,
			BindingResult result, HttpServletRequest request, HttpSession session) throws BeException {
		boolean isInactive = false;
		String id = doctorProfile.getAction();
		ModelAndView mav = getDefaultMav(PageTemplate.PAGE_DOC_ADD, MODULE, null, null, JS_FILENAME);
		
		if (!result.hasErrors()) {
			UserProfile pr = getCurrentUser();
			doctorProfile = dozerMapper.map(doctorProfile, DoctorProfile.class);
			if (hasAnyRole(IdmRoleConstants.ADMIN_ROLES)) {
				if (BaseUtil.isObjNull(doctorProfile.getUserGroupCode())) {
					doctorProfile.setUserGroupCode(doctorProfile.getUserRoleGroupCode());
				}
				trySetUser(doctorProfile, mav);

			} else {
				doctorProfile.setUserTypeCode(pr.getUserType().getUserTypeCode());
			}

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("userProfile: {}", new ObjectMapper().valueToTree(doctorProfile));
			}

			UserProfile createUserProfile = dozerMapper.map(doctorProfile, UserProfile.class);

			// OPERATOR PROFILE
			if (BaseUtil.isEquals(doctorProfile.getUserRoleGroupCode(), "MC_OPERATOR")) {
				UserProfile prof = null;
//				doctorProfile.setUserId();
				
				try {
					prof = getIdmService().getUserProfileById(CryptoBaseUtil.decrypt(doctorProfile.getUserId(), staticData.beConfig("HASH_SECRET_KEY")), false, false);
				} catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
				if (!BaseUtil.isObjNull(prof)) {
					// userid already exist
					mav.addAllObjects(PopupBox.error(PFX_USRCREATE, messageService.getMessage(
							MessageConstants.ERR_USER_ID_EXISTS, new String[] { doctorProfile.getUserId() })));
				} else {
					tryCreateUser(doctorProfile, createUserProfile, mav, result, id, null);
				}

				doctorProfile.setUserRoleGroupCode(doctorProfile.getUserRoleGroupCode());
			}

			// DOCTOR PROFILE CREATE AND UPDATE
			if (BaseUtil.isEquals(doctorProfile.getUserRoleGroupCode(), "MC_DOCTOR")) {
				try {
					Integer curUser = getCurrentUser().getProfId();
					McProfile mcProfile = new McProfile();
					mcProfile.setMcProfId(curUser);
					doctorProfile.setBeMcProfile(mcProfile);
					String fullname = doctorProfile.getFirstName() + " " + doctorProfile.getLastName();
					doctorProfile.setFullName(fullname);
					if (!BaseUtil.isEquals(doctorProfile.getDocRefNo(), "")) {
						doctorProfile.setDocRefNo(doctorProfile.getDocRefNo());
					} else {
						doctorProfile.setDocRefNo(UidGenerator.generateUid("DOCT"));
					}
					List<TrxnDocuments> trxnList = new ArrayList<>();
					TrxnDocuments doc1 = new TrxnDocuments();
					if (!BaseUtil.isListNullZero(doctorProfile.getFileUploadsSupportingDoc1())
							&& doctorProfile.getFileUploadsSupportingDoc1().size() == 1) {

						FileUpload fu = doctorProfile.getFileUploadsSupportingDoc1().get(0);
						if (fu.getDocMgtId() != null && !fu.getDocMgtId().isEmpty()) {
							doc1 = getTrxnDocValue(fu, doctorProfile.getDocRefNo(), "DOCTCER01");
							trxnList.add(doc1);
						}
					}
					TrxnDocuments doc2 = new TrxnDocuments();
					if (!BaseUtil.isListNullZero(doctorProfile.getFileUploadsSupportingDoc2())
							&& doctorProfile.getFileUploadsSupportingDoc2().size() == 1) {

						FileUpload fu = doctorProfile.getFileUploadsSupportingDoc2().get(0);
						if (fu.getDocMgtId() != null && !fu.getDocMgtId().isEmpty()) {
							doc2 = getTrxnDocValue(fu, doctorProfile.getDocRefNo(), "DOCTCER02");
							trxnList.add(doc2);
						}
					}
					TrxnDocuments doc3 = new TrxnDocuments();
					if (!BaseUtil.isListNullZero(doctorProfile.getFileUploadsSupportingDoc3())
							&& doctorProfile.getFileUploadsSupportingDoc3().size() == 1) {

						FileUpload fu = doctorProfile.getFileUploadsSupportingDoc3().get(0);
						if (fu.getDocMgtId() != null && !fu.getDocMgtId().isEmpty()) {
							doc3 = getTrxnDocValue(fu, doctorProfile.getDocRefNo(), "DOCTCER03");
							trxnList.add(doc3);
						}
					}
					doctorProfile.setTrxnDocuments(trxnList);
					// UPDATE DOCTOR PROFILE AND IDM PROFILE
					if (doctorProfile.getDocProfId() != null) {
						doctorProfile.setIsActive(true);
						doctorProfile.setDocProfId(doctorProfile.getDocProfId());
						doctorProfile.setUserId(CryptoBaseUtil.decrypt(doctorProfile.getUserId(), staticData.beConfig("HASH_SECRET_KEY")));
						doctorProfile = getBeService().profileService().updateDoctor(doctorProfile);
						if (doctorProfile.getDocProfId() != null) {
							LOGGER.info("tryUpdateUser: {}", doctorProfile.getStateCd());
							createUserProfile.setCntryCd(doctorProfile.getStateCd());
							tryUpdateUser(createUserProfile, mav, id);
						}
						LOGGER.info("payload--", doctorProfile);
						if (doctorProfile.getDocProfId() != null) {

							mav.addAllObjects(PopupBox.success("Register", null, "Record successfully updated",
									PageConstants.PAGE_SEARCH_DOCTOR));
						} else {
							mav.addAllObjects(PopupBox.error("Register", null, "Record updation failed"));
						}
					} else {
						// CREATE DOCTOR PROFILE AND IDM PROFILE
						UserProfile prof = null;
						try {
							prof = getIdmService().getUserProfileById(doctorProfile.getUserId(), false, false);
						} catch (Exception e) {
							LOGGER.error(e.getMessage());
						}

						if (!BaseUtil.isObjNull(prof)) {
							// userid already exist
							mav.addAllObjects(PopupBox.error(PFX_USRCREATE, "Error",
									messageService.getMessage(MessageConstants.ERR_USER_NAME_EXISTS,
											new String[] { doctorProfile.getUserId() })));
						} else {
							doctorProfile = getBeService().profileService().registerDoctor(doctorProfile);
							if (doctorProfile.getDocProfId() != null) {
								if (BaseUtil.isEqualsCaseIgnore("new", id)) {
									mav.addObject(AppConstants.PORTAL_TRANS_ID, PFX_NEWUSER);

									tryCreateUser(doctorProfile, createUserProfile, mav, result, id,
											doctorProfile.getDocProfId());

									doctorProfile = new DoctorProfile();
									mav.addAllObjects(
											PopupBox.success("Register", null, "Record successfully created",
													PageConstants.PAGE_SEARCH_DOCTOR));
									mav.addObject("doctorProfile", doctorProfile);
									LOGGER.info("OPERATION IS OKAY");
								}
							}

						}

						LOGGER.info("payload--", doctorProfile);

					}
				} catch (BeException beEx) {
					mav.addAllObjects(PopupBox.error("Register", null, "Exception occurred while inserting data"));
				}
				doctorProfile.setUserRoleGroupCode(doctorProfile.getUserRoleGroupCode());
			}
			addCheck(doctorProfile, mav);

		}

		mav.addObject(PFX_ISADMIN, hasAnyRole(IdmRoleConstants.ADMIN_ROLES));
		mav.addObject(PFX_ISINACTIVE, isInactive);
		if (!BaseUtil.isEquals(doctorProfile.getUserId(), "")
				&& !BaseUtil.isEquals(doctorProfile.getUserId(), "new")) {
			mav.addObject(PFX_USERID, id);
			mav.addObject("id", id);
			UserProfile usp = new UserProfile();
			usp.setStatus(doctorProfile.getStatus());
			mav.addObject("userProfile", usp);
			// doctorProfile = new DoctorProfile();
		} else {
			mav.addObject(PFX_USERID, "new");
			mav.addObject("id", "new");
			UserProfile usp = new UserProfile();
			usp.setStatus("F");
			mav.addObject("userProfile", usp);
		}
		mav.addObject(AppConstants.PORTAL_MODULE, "doc-add");
		mav.addObject("addType", true);

		mav.addObject("doctorProfile", doctorProfile);
		mav.addObject("refDocLst01", getRefDocLst01());
		mav.addObject("refDocLst02", getRefDocLst02());
		mav.addObject("refDocLst03", getRefDocLst03());

		return mav;
	}


	private void trySetUser(DoctorProfile doctorProfile, ModelAndView mav) {
		try {
			UserGroup ug = findAdminRoleGroupCodeByUserGroup(doctorProfile.getUserGroupCode(),
					getCurrentUser().getUserRoleGroupCode());
			if (ug != null) {
				doctorProfile.setUserRoleGroupCode(ug.getUserRoleGroupCode());
				doctorProfile.setUserTypeCode(ug.getUserType().getUserTypeCode());
			}
		} catch (IdmException e) {
			if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
				throw e;
			}
			mav.addAllObjects(WebUtil.checkServiceDown(e));
		} catch (Exception e) {
			if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
				throw e;
			}
			mav.addAllObjects(WebUtil.checkServiceDown(e));
			mav.addAllObjects(PopupBox.error(PFX_USRCREATE,
					messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
		}
	}


	private UserGroup findAdminRoleGroupCodeByUserGroup(String userGroup, String userLevel) {
		List<UserGroup> roleGroupCode = findAllUserRoleGroupByGroupCode(userGroup);
		for (UserGroup prUserGroup : roleGroupCode) {
			if (BaseUtil.isEquals(prUserGroup.getParentRoleGroup(), userLevel)) {
				return prUserGroup;
			}
		}
		return null;
	}


	private List<UserGroup> findAllUserRoleGroupByGroupCode(String groupCode) {
		LOGGER.debug("finding all with Id: {}", groupCode);

		String parentRoleGroup = getParentRoleGroup();
		LOGGER.debug("parentRoleGroup: {}", parentRoleGroup);

		List<UserGroup> userGroupList = new ArrayList<>();
		try {
			List<UserGroup> result = getIdmService().findUserGroupByRoleGroupCode(groupCode, true, true);
			for (UserGroup userGroup : result) {
				if (BaseUtil.isEquals(userGroup.getParentRoleGroup(), parentRoleGroup)) {
					userGroupList.add(userGroup);
				}
			}
		} catch (IdmException e) {
			LOGGER.error(BaseConstants.LOG_IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
			if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
				throw e;
			}
		}

		return userGroupList;
	}


	private String getParentRoleGroup() {
		String parentRoleGroup = BaseConstants.EMPTY_STRING;
		UserProfile authUser = getCurrentUser();
		if (!BaseUtil.isObjNull(authUser)) {
			LOGGER.debug("authUser: {}", authUser);
			String userRoleGroup = BaseUtil.getStr(authUser.getUserRoleGroupCode());
			LOGGER.debug("userRoleGroup: {}", userRoleGroup);
			List<UserGroup> userGroups = getIdmService().findUserGroupByRoleGroupCode(userRoleGroup, true, true);
			LOGGER.debug("userGroups: {}", userGroups);
			for (UserGroup userGroup : userGroups) {
				if (BaseUtil.isEquals(userGroup.getUserRoleGroupCode(), userRoleGroup)) {
					parentRoleGroup = userGroup.getUserRoleGroupCode();
					break;
				}
			}
		}

		LOGGER.debug("parentRoleGroup: {}", parentRoleGroup);
		return parentRoleGroup;
	}


	@ModelAttribute("userRoleGroupList")
	public List<UserGroup> getUserRoleGroupList() {
		List<UserGroup> sortedLst = new ArrayList<>();
		if (hasAnyRole(IdmRoleConstants.ADMIN_ROLES)) {
			try {
				List<UserGroup> userGroupList = getIdmService()
						.findUserGroupByParentRoleGroup(getCurrentUser().getUserRoleGroup().getUserGroupCode());
				sortedLst = userGroupList.stream().sorted(Comparator.comparing(UserGroup::getUserGroupDesc))
						.collect(Collectors.toList());
			} catch (IdmException e) {
				LOGGER.error(BaseConstants.LOG_IDM_EXCEPTION, e.getMessage());
				if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
				if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
					throw e;
				}
			}
		}
		return sortedLst;
	}


	private void tryCreateUser(DoctorProfile userProfile, UserProfile createUserProfile, ModelAndView mav,
			BindingResult result, String id, Integer docprofid) {
		try {
			DoctorProfile doctorProfile = null;
			LOGGER.debug("tryCreateUser: {}", JsonUtil.objectMapper().writeValueAsString(userProfile));
			// INSERT DOCTOR OR CURRENT AUTH USER DETAILS
			UserProfile authUser = getCurrentUser();
			if (docprofid != null) {
				createUserProfile.setProfId(docprofid);
			} else {
				createUserProfile.setProfId(authUser.getProfId());
			}
			if (!BaseUtil.isObjNull(userProfile.getStateCd())) {
				createUserProfile.setCntryCd(userProfile.getStateCd());
			} else if (!BaseUtil.isObjNull(authUser) && !BaseUtil.isObjNull(authUser.getCntryCd())) {
				createUserProfile.setCntryCd(authUser.getCntryCd());
				if (!BaseUtil.isObjNull(authUser.getCntryCd()) && !BaseUtil.isObjNull(authUser.getBranchId())) {
					createUserProfile.setBranchId(authUser.getBranchId());
				}
			}

			if (!BaseUtil.isObjNull(createUserProfile.getCntryCd()) && BaseUtil.isObjNull(authUser.getBranchId())) {
				LOGGER.info("JANE_STATE------------------------{}", userProfile.getStateCd());
				UserGroupBranch userGroupBranch = new UserGroupBranch();
				userGroupBranch.setBranchCode(userProfile.getStateCd());
				List<UserGroupBranch> ug = getIdmService().searchUserGroupBranch(userGroupBranch);
				Integer[] branchId = new Integer[1];
				ug.forEach(n -> {
					LOGGER.info("LOOP - {}, {}", n.getBranchCode(), userProfile.getStateCd());
					if (BaseUtil.isEqualsCaseIgnore(n.getBranchCode(), userProfile.getStateCd())) {
						branchId[0] = n.getBranchId();
					}
				});
				createUserProfile.setBranchId(branchId[0]);
			}

			if (!BaseUtil.isObjNull(userProfile.getUserGroupRoleBranchCd())) {
				createUserProfile.setUserGroupRoleBranchCd(userProfile.getUserGroupRoleBranchCd());
				createUserProfile.setUserGroupRoleBranchCode(userProfile.getUserGroupRoleBranchCd());
				UserGroupBranch userGroupBranch = new UserGroupBranch();
				LOGGER.info("JANE_------------------------{}", userProfile.getUserGroupRoleBranchCd());
				userGroupBranch.setBranchCode(userProfile.getUserGroupRoleBranchCd());
				List<UserGroupBranch> ug = getIdmService().searchUserGroupBranch(userGroupBranch);
				Integer[] branchId = new Integer[1];
				ug.forEach(n -> {
					LOGGER.info("LOOP - {}, {}", n.getBranchCode(), userProfile.getUserGroupRoleBranchCd());
					if (BaseUtil.isEqualsCaseIgnore(n.getBranchCode(), userProfile.getUserGroupRoleBranchCd())) {
						branchId[0] = n.getBranchId();
					}
				});
				createUserProfile.setBranchId(branchId[0]);
			} else if (!BaseUtil.isObjNull(authUser) && !BaseUtil.isObjNull(authUser.getUserGroupRoleBranchCode())) {
				createUserProfile.setUserGroupRoleBranchCode(authUser.getUserGroupRoleBranchCode());
				UserGroupBranch userGroupBranch = new UserGroupBranch();
				userGroupBranch.setBranchCode(authUser.getUserGroupRoleBranchCode());
				LOGGER.info("TEST: {}", authUser.getUserGroupRoleBranchCode());
				List<UserGroupBranch> ug = getIdmService().searchUserGroupBranch(userGroupBranch);
				Integer[] branchId = new Integer[1];
				if (!BaseUtil.isListNullZero(ug)) {
					ug.forEach(n -> {
						LOGGER.info("LOOP - {}, {}", n.getBranchCode(), authUser.getUserGroupRoleBranchCode());
						if (BaseUtil.isEqualsCaseIgnore(n.getBranchCode(),
								authUser.getUserGroupRoleBranchCode())) {
							branchId[0] = n.getBranchId();
						}
					});
					createUserProfile.setBranchId(branchId[0]);
				}
			}
			createUserProfile.setNationalId(userProfile.getIdentityNo());
			userProfile.setIdentityNo(userProfile.getIdentityNo());
			if (BaseUtil.isObjNull(userProfile.getEmail())) {
				createUserProfile = getIdmService().createUser(createUserProfile, true, true, false, false);
			} else {
				createUserProfile = getIdmService().createUser(createUserProfile, true, true);
			}

			if (createUserProfile != null) {
				doctorProfile = new DoctorProfile();
				mav.addObject("doctorProfile", doctorProfile);
				mav.addAllObjects(PopupBox.success(PFX_USRCREATE, null,
						messageService.getMessage(MessageConstants.SUCC_CREATE_USER),
						PageConstants.PAGE_SEARCH_DOCTOR));
			} else {
				mav.addAllObjects(PopupBox.error(PFX_USRCREATE, null,
						messageService.getMessage(MessageConstants.ERROR_CRE_USER),
						PageConstants.PAGE_SEARCH_DOCTOR + PAGE_USER_ID + id));
			}
		} catch (IdmException e) {
			if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
				throw e;
			}
			mav.addAllObjects(PopupBox.error(PFX_USRCREATE, PFX_ERROR,
					messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
		} catch (Exception e) {

			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
			mav.addAllObjects(PopupBox.error(PFX_USRCREATE, PFX_ERROR,
					messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
		}
	}


	private void tryUpdateUser(UserProfile createUserProfile, ModelAndView mav, String id) {
		try {
			if (BaseUtil.isEqualsCaseIgnore("id", id)) {
				mav.addObject(AppConstants.PORTAL_MODULE, PFX_IDMUPD);
				createUserProfile.setUserId(getCurrentUserId());

			} else {
				mav.addObject(AppConstants.PORTAL_TRANS_ID, PFX_UPDUSER);
			}

			createUserProfile.setUserId(CryptoBaseUtil.decrypt(createUserProfile.getUserId(), staticData.beConfig("HASH_SECRET_KEY")));
			boolean isUpdated = getIdmService().updateProfile(createUserProfile);

			if (isUpdated) {
				if (BaseUtil.isEqualsCaseIgnore("id", id)) {
					mav.addAllObjects(PopupBox.success(PFX_USRUPDATE, null,
							messageService.getMessage(MessageConstants.SUCC_UPD_USER),
							PageConstants.PAGE_IDM_USR_UPD_LOGIN));
				} else {
					mav.addAllObjects(PopupBox.success(PFX_USRUPDATE, null,
							messageService.getMessage(MessageConstants.SUCC_UPD_USER),
							PageConstants.PAGE_SEARCH_DOCTOR));
				}
			} else {
				mav.addAllObjects(PopupBox.error(PFX_USRUPDATE, null,
						messageService.getMessage(MessageConstants.ERROR_UPD_USER),
						PageConstants.PAGE_SEARCH_DOCTOR + PAGE_USER_ID + id));
			}
		} catch (IdmException e) {
			if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
				throw e;
			}
			mav.addAllObjects(PopupBox.error(PFX_USRUPDATE, PFX_ERROR,
					messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
		} catch (Exception e) {
			if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
				throw e;
			}
			mav.addAllObjects(PopupBox.error(PFX_USRUPDATE, PFX_ERROR,
					messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
		}
	}


	private void addCheck(DoctorProfile userProfile, ModelAndView mav) {
		boolean isSelCountry = false;
		boolean isSelBranch = false;
		LOGGER.info("selected userGroup: {}", userProfile.getUserRoleGroupCode());
		if (!BaseUtil.isObjNull(userProfile.getUserRoleGroupCode())) {
			LOGGER.info("check selected userGroup: {}", userProfile.getUserRoleGroupCode());
			UserGroup ug = getUserRoleGroup(userProfile.getUserRoleGroupCode(), userProfile, null);
			if (!BaseUtil.isObjNull(ug)) {
				isSelCountry = ug.isSelCountry() != null ? ug.isSelCountry() : false;
				isSelBranch = ug.isSelBranch() != null ? ug.isSelBranch() : false;
			}
		}
		mav.addObject("isSelCountry", isSelCountry);
		mav.addObject("isSelBranch", isSelBranch);
	}


	public @ResponseBody UserGroup getUserRoleGroup(@PathVariable String userGroup, DoctorProfile userProfile,
			BindingResult result) {
		if (BaseUtil.isObjNull(userGroup)) {
			return new UserGroup();
		}

		List<UserGroup> ugLst = getUserRoleGroupList();
		return ugLst.stream().filter(ugr -> userGroup.equals(ugr.getUserGroupCode())).findFirst()
				.orElse(new UserGroup());
	}


	private TrxnDocuments getTrxnDocValue(FileUpload upload, String docRefNo, String trxnNo) {
		if (upload.getDocMgtId() == null || upload.getDocMgtId().isEmpty()) {
			return null;
		}
		Documents doc = new Documents();
		CustomMultipartFile file = upload.getFile();
		if (file != null) {
			if (file != null) {
				for (RefDocuments refDoc : staticData.findRefDocumentssByTrxnNo(trxnNo)) {
					doc = dozerMapper.map(file, Documents.class);
					doc.setDocid(refDoc.getDocId());
					doc.setLength(file.getSize());
					doc.setContent(file.getContent());
					if (upload.getDocMgtId() != null && !upload.getDocMgtId().isEmpty()) {
						doc.setId(upload.getDocMgtId());
					}
				}
			}
		}
		TrxnDocuments txnDoc = new TrxnDocuments();
		if (!BaseUtil.isObjNull(doc.getContent()) && (doc.getContent().length != 0)
				|| (BaseUtil.isObjNull(doc.getId()) && (doc.getContent().length != 0))) {

			Documents newDoc = getDmService(ProjectEnum.MYIP).upload(doc);
			LOGGER.info(newDoc.getId());
			txnDoc.setDocId(newDoc.getDocid());
			txnDoc.setDocMgtId(newDoc.getId());
			txnDoc.setDocContentType(newDoc.getContentType());
			txnDoc.setDocRefNo(newDoc.getRefno());
			txnDoc.setAppRefNo("");

		} else {
			txnDoc.setDocId(doc.getDocid());
			txnDoc.setDocRefNo(docRefNo);
			txnDoc.setDocMgtId(doc.getId());
			txnDoc.setAppRefNo("");
			txnDoc.setDocContentType(doc.getContentType());
			if (doc.getFilename().equals("") && doc.getContent().length == 0) {
				txnDoc.setDocToRemove(true);
			}
		}
		return txnDoc;
	}


	@ModelAttribute("appStatList")
	public List<Status> getAppStatusList() throws Exception {
		List<Status> statusList = staticData.findAllStatus();
		LOGGER.info("<<<<<< statLst size >>>>>>" + statusList.size());

		return statusList;
	}


	@ModelAttribute("refDocLst01")
	public List<RefDocuments> getRefDocLst01() {
		return staticData.findRefDocumentssByTrxnNo("DOCTCER01");
	}


	@ModelAttribute("refDocLst02")
	public List<RefDocuments> getRefDocLst02() {
		return staticData.findRefDocumentssByTrxnNo("DOCTCER02");
	}


	@ModelAttribute("refDocLst03")
	public List<RefDocuments> getRefDocLst03() {
		return staticData.findRefDocumentssByTrxnNo("DOCTCER03");
	}


	private ModelAndView getDefaultMavProfile(String userId) {
		ModelAndView mav = getDefaultMav(PageTemplate.PAGE_DOC_ADD, MODULE, null, null, JS_FILENAME);
		DoctorProfile userProfile = new DoctorProfile();
		boolean isInactive = false;
		String urlresent = null;
		String urlrePwd = null;
		String urldeact = null;
		String urlact = null;
		String encrptValue = userId;
		if (BaseUtil.isEqualsCaseIgnore("new", userId)) {
			mav.addObject(AppConstants.PORTAL_TRANS_ID, PFX_NEWUSER);
			userProfile.setUserTypeCode(AppConstants.TMS_USER_TYPE);
			userProfile.setPassword("password");
		} else {
			String userName = BaseUtil.isEqualsCaseIgnore("id", userId) ? getCurrentUserId() : userId;
			if (!BaseUtil.isEqualsCaseIgnore("id", userId)) {

				try {
					userId = CryptoBaseUtil.decrypt(userId, staticData.beConfig("HASH_SECRET_KEY"));
				} catch (Exception e) {
					// TODO: handle exception
				}
//				userId = userSecretMap.get(encrptValue);
				userName = userId;
			}
			urlresent = "/myip-portal-med/searchDr/resent?id=" + encrptValue;
			urlrePwd = "/myip-portal-med/searchDr/resetPwd?id=" + encrptValue;
			urldeact = "/myip-portal-med/searchDr/deactivate?id=" + encrptValue;
			urlact = "/myip-portal-med/searchDr/activate?id=" + encrptValue;

			// userProfile.setIdentityNo(userProfile.getNationalId());
			try {
				UserProfile userProfileObj = getIdmService().getUserProfileById(userName, false, false);

				if (!BaseUtil.isEqualsCaseIgnore("id", userId) && !BaseUtil.isObjNull(userProfileObj)) {
					isInactive = !BaseUtil.isEqualsCaseIgnore(BaseConstants.STATUS_ACTIVE,
							userProfileObj.getStatus());
				}

				userProfile = dozerMapper.map(userProfileObj, DoctorProfile.class);
				if (!BaseUtil.isObjNull(userProfileObj.getUserRoleGroup())) {
					userProfile.setUserRoleGroupCode(userProfileObj.getUserRoleGroup().getUserGroupCode());
				}
				if (!BaseUtil.isObjNull(userProfileObj.getUserGroupRoleBranchCode())
						|| !BaseUtil.isObjNull(userProfileObj.getUserGroupRoleBranchCd())) {
					if (!BaseUtil.isObjNull(userProfileObj.getUserGroupRoleBranchCode())) {
						userProfile.setUserGroupRoleBranchCd(userProfileObj.getUserGroupRoleBranchCode());
					} else {
						userProfile.setUserGroupRoleBranchCd(userProfileObj.getUserGroupRoleBranchCd());
					}
				}
				if (!BaseUtil.isObjNull(userProfileObj.getCntryCd())) {
					userProfile.setStateCd(userProfileObj.getCntryCd());
				}
				userProfile.setIdentityNo(userProfileObj.getNationalId());
				DoctorProfile docprof = new DoctorProfile();
				docprof.setDocProfId(userProfileObj.getProfId());
				docprof = getBeService().profileService().getDoctorProfile(docprof);
				System.out.println("doctorId " + docprof.getDoctorId());
				userProfile.setDepartment(docprof.getDepartment());
				userProfile.setDesignation(docprof.getDesignation());
				userProfile.setDivision(docprof.getDivision());
				userProfile.setDoctorId(docprof.getDoctorId());
				userProfile.setFaxNo(docprof.getFaxNo());
				userProfile.setExt(docprof.getExt());
				userProfile.setMedCertNo(docprof.getMedCertNo());
				userProfile.setDocProfId(docprof.getDocProfId());
				userProfile.setDocRefNo(docprof.getDocRefNo());

				if (!BaseUtil.isEquals(docprof.getDocRefNo(), null)) {
					String medRptUrl1 = "";
					String supdoc1 = getTrxnDocumentDocMgtId(docprof.getDocRefNo(), "DOCTCER01");
					if (supdoc1 != null) {
						List<FileUpload> fileUpload1 = null;
						fileUpload1 = getDocumentdetailsinDM(docprof.getDocRefNo(), supdoc1);
						userProfile.setFileUploadsSupportingDoc1(fileUpload1);
						medRptUrl1 = supdoc1;
					} else {
						medRptUrl1 = null;
					}
					userProfile.setSupportingDoc1(medRptUrl1);
				}

				if (!BaseUtil.isEquals(docprof.getDocRefNo(), null)) {
					String medRptUrl2 = "";
					String supdoc2 = getTrxnDocumentDocMgtId(docprof.getDocRefNo(), "DOCTCER02");
					if (supdoc2 != null) {
						List<FileUpload> fileUpload2 = null;
						fileUpload2 = getDocumentdetailsinDM(docprof.getDocRefNo(), supdoc2);
						userProfile.setFileUploadsSupportingDoc2(fileUpload2);
						medRptUrl2 = supdoc2;
					} else {
						medRptUrl2 = null;
					}
					userProfile.setSupportingDoc2(medRptUrl2);
				}

				if (!BaseUtil.isEquals(docprof.getDocRefNo(), null)) {
					String medRptUrl3 = "";
					String supdoc3 = getTrxnDocumentDocMgtId(docprof.getDocRefNo(), "DOCTCER03");
					if (supdoc3 != null) {
						List<FileUpload> fileUpload3 = null;
						fileUpload3 = getDocumentdetailsinDM(docprof.getDocRefNo(), supdoc3);
						userProfile.setFileUploadsSupportingDoc3(fileUpload3);
						medRptUrl3 = supdoc3;
					} else {
						medRptUrl3 = null;
					}
					userProfile.setSupportingDoc3(medRptUrl3);
				}
				// userProfile = dozerMapper.map(docprof,
				// DoctorProfile.class);
				// mav.addObject("docprof", docprof);
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}

			// Update for logged in User
			if (BaseUtil.isEqualsCaseIgnore("id", userId)) {
				mav.addObject(AppConstants.PORTAL_MODULE, PFX_IDMUPD);
			} else if (!isInactive) {
				mav.addObject(AppConstants.PORTAL_TRANS_ID, PFX_UPDUSER);
			}

		}

		addCheck(userProfile, mav);

		mav.addObject(PFX_ISADMIN, hasAnyRole(IdmRoleConstants.ADMIN_ROLES));
		mav.addObject(PFX_ISINACTIVE, isInactive);
		mav.addObject(PFX_USERID, BaseUtil.isObjNull(encrptValue) ? userId : encrptValue);
		mav.addObject(PFX_USERPROFILE, userProfile);
		mav.addObject("doctorProfile", userProfile);
		mav.addObject("urlresent", urlresent);
		mav.addObject("urlrePwd", urlrePwd);
		mav.addObject("urldeact", urldeact);
		mav.addObject("urlact", urlact);
		return mav;
	}


	private List<FileUpload> getDocumentdetailsinDM(String docRefNo, String docMgtId) {
		List<FileUpload> fileUpload = new ArrayList<>();
		List<TrxnDocuments> refDocLst = getBeService().trxnDocumentService().getTrxnDocuments(docRefNo);
		for (TrxnDocuments refDoc : refDocLst) {
			FileUpload file = new FileUpload();
			Documents docs = null;
			if (!BaseUtil.isObjNull(docMgtId)) {
				try {
					if (BaseUtil.isEquals(refDoc.getDocMgtId(), docMgtId)) {
						docs = getDmService(ProjectEnum.MYIP).getMetadata(docMgtId);
					}
				} catch (IdmException e) {
					LOGGER.error("IdmException: {}", e.getMessage());
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (DmException e) {
					LOGGER.error("DmException: {}", e.getMessage());
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error("Exception: {}", e.getMessage());
				}
			}

			if (BaseUtil.isEquals(refDoc.getDocMgtId(), docMgtId)) {
				if (docs != null && docs.getDocid().equals(refDoc.getDocId())) {
					file = dozerMapper.map(docs, FileUpload.class);
					CustomMultipartFile fl = new CustomMultipartFile();
					LOGGER.info(docs.getFilename());
					LOGGER.info(docs.getContentType());
					fl.setFilename(docs.getFilename());
					fl.setContentType(docs.getContentType());
					file.setFile(fl);
				}
				file.setDocId(refDoc.getDocId());
				file.setDocMgtId(docMgtId);
				fileUpload.add(file);
			}
		}
		return fileUpload;
	}


	private String getTrxnDocumentDocMgtId(String docRefNo, String docTrxnNo) {
		List<TrxnDocuments> docs = getBeService().trxnDocumentService().getTrxnDocuments(docRefNo);
		List<TrxnDocuments> newLst = new ArrayList<>();
		List<RefDocuments> refDocs = staticData.findRefDocumentssByTrxnNo(docTrxnNo);
		if (!BaseUtil.isListNullZero(refDocs)) {
			RefDocuments refDoc = refDocs.get(0);
			newLst = docs.stream().filter(res -> res.getDocId() == refDoc.getDocId()).collect(Collectors.toList());
		}
		if (!BaseUtil.isListNullZero(newLst)) {
			return newLst.get(0).getDocMgtId();
		}
		return null;
	}


	/**
	 * Resend User Credentials
	 *
	 * @param userProfile
	 * @param result
	 * @return @
	 */
	@AuditActionControl(action = AuditActionPolicy.RESEND_CRED)
	@GetMapping(value = "/resent")
	public ModelAndView resentCredential(@Valid @RequestParam("id") String id,
			@ModelAttribute("doctorProfile") DoctorProfile userProfile, BindingResult result,
			HttpServletRequest request, HttpSession session) throws BeException {
		LOGGER.info("[Post] Resent User credential: {}", id);
		ModelAndView mav = viewProfile(id, userProfile, result);
		userProfile = (DoctorProfile) mav.getModelMap().get(PFX_USERPROFILE);

		if (!BaseUtil.isEqualsCaseIgnore("id", id) && !BaseUtil.isEqualsCaseIgnore("new", id)
				&& !BaseUtil.isObjNull(userProfile)) {
			try {
				userProfile.setUserTypeCode(userProfile.getUserTypeCode());
				UserProfile userProfileObj = dozerMapper.map(userProfile, UserProfile.class);
				
				userProfileObj.setUserId(CryptoBaseUtil.decrypt(id, staticData.beConfig("HASH_SECRET_KEY")));
				getIdmService().activateUser(userProfileObj);
//				session.removeAttribute("hashId");
//				session.removeAttribute("mgUserId");
				mav.addAllObjects(PopupBox.success(PFX_USRUPDATE, null,
						messageService.getMessage(MessageConstants.SUCC_RESENT_USER_CRE),
						PageConstants.PAGE_SEARCH_DOCTOR));
			} catch (IdmException e) {
				LOGGER.error(e.getMessage());
				if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
					throw e;
				}
				mav.addAllObjects(PopupBox.success(PFX_USRUPDATE, null,
						messageService.getMessage(MessageConstants.ERROR_RESENT_USER_CRE),
						PageConstants.PAGE_SEARCH_DOCTOR));
			}
		}

		return mav;
	}


	/**
	 * Reset Password
	 *
	 * @param userId
	 * @param userProfile
	 * @param result
	 * @return @
	 */
	@AuditActionControl(action = AuditActionPolicy.RESET_PWORD)
	@GetMapping(value = "/resetPwd")
	public ModelAndView forgotPword(@Valid @RequestParam("id") String id, DoctorProfile userProfile,
			BindingResult result, HttpSession session) {
		LOGGER.info("[POST] Reset Password : {}", id);
		ModelAndView mav = viewProfile(id, userProfile, result);

		try {
			ForgotPassword forgotPassword = new ForgotPassword();
			forgotPassword.setUserName(CryptoBaseUtil.decrypt(id, staticData.beConfig("HASH_SECRET_KEY")));
			getIdmService().forgotPassword(forgotPassword);
//			session.removeAttribute("hashId");
//			session.removeAttribute("mgUserId");
			mav.addAllObjects(
					PopupBox.success(null, null, messageService.getMessage(MessageConstants.SUCC_FORGOT_PWORD),
							PageConstants.PAGE_SEARCH_DOCTOR));
		} catch (IdmException e) {
			if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
				throw e;
			}
			mav.addAllObjects(PopupBox.error(e.getInternalErrorCode(), e.getMessage()));
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			mav.addAllObjects(PopupBox.error(PFX_USRUPDATE, PFX_ERROR,
					messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
			if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
				throw e;
			}
		}

		return mav;
	}


	/**
	 * Deactivate User
	 *
	 * @param userId
	 * @param userProfile
	 * @param result
	 * @return
	 */
	@AuditActionControl(action = AuditActionPolicy.DEACTIVATE_USER)
	@GetMapping(value = "/deactivate")
	public ModelAndView deactivate(@Valid @RequestParam("id") String id, DoctorProfile userProfile,
			BindingResult result, HttpSession session) {
		LOGGER.info("[Post] User Deactivate: {}", id);
		ModelAndView mav = viewProfile(id, userProfile, result);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.cmn.usr.dea"));
		userProfile = (DoctorProfile) mav.getModelMap().get(PFX_USERPROFILE);

		if (!BaseUtil.isEqualsCaseIgnore("id", id) && !BaseUtil.isEqualsCaseIgnore("new", id)
				&& !BaseUtil.isObjNull(userProfile)) {
			try {
				// userProfile.setFullName(BaseUtil.getStrUpperWithNull(userProfile.getFullName()));
				userProfile.setStatus(AppConstants.INACTIVE);
				userProfile.setUserTypeCode(userProfile.getUserTypeCode());

				UserProfile userProfileObj = dozerMapper.map(userProfile, UserProfile.class);
				userProfile.setUserId(CryptoBaseUtil.decrypt(id, staticData.beConfig("HASH_SECRET_KEY")));
				boolean isUpdated = getIdmService().updateProfile(userProfileObj);
//				session.removeAttribute("hashId");
//				session.removeAttribute("mgUserId");
				if (isUpdated) {
					mav.addAllObjects(PopupBox.success(PFX_USRUPDATE, null,
							messageService.getMessage(MessageConstants.SUCC_DEACTIVATE_USER),
							PageConstants.PAGE_SEARCH_DOCTOR));
				} else {
					mav.addAllObjects(PopupBox.success(PFX_USRUPDATE, null,
							messageService.getMessage(MessageConstants.ERROR_FAIL_DEACTIVATE_USER),
							PageConstants.PAGE_SEARCH_DOCTOR));
				}
				mav.addObject(PFX_ISINACTIVE, true);
			} catch (IdmException e) {
				if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
					throw e;
				}
				mav.addAllObjects(PopupBox.error(e.getInternalErrorCode(), e.getMessage()));
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
				if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
					throw e;
				}
				mav.addAllObjects(PopupBox.error("userUpdate",
						messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
			}
		}

		return mav;
	}


	/**
	 * Activate User
	 *
	 * @param userId
	 * @param userProfile
	 * @param result
	 * @return @
	 */
	@AuditActionControl(action = AuditActionPolicy.ACTIVATE_USER)
	@GetMapping(value = "/activate")
	public ModelAndView activate(@Valid @RequestParam("id") String id, DoctorProfile userProfile, BindingResult result,
			HttpSession session) {
		LOGGER.info("[Post] User Activate: {}", id);
		ModelAndView mav = viewProfile(id, userProfile, result);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.cmn.usr.act"));
		userProfile = (DoctorProfile) mav.getModelMap().get(PFX_USERPROFILE);

		if (!BaseUtil.isEqualsCaseIgnore("id", id) && !BaseUtil.isEqualsCaseIgnore("new", id)
				&& !BaseUtil.isObjNull(userProfile)) {
			try {
				userProfile.setUserTypeCode(userProfile.getUserTypeCode());
				UserProfile userProfileObj = dozerMapper.map(userProfile, UserProfile.class);
				userProfileObj.setUserId(CryptoBaseUtil.decrypt(id, staticData.beConfig("HASH_SECRET_KEY")));
				getIdmService().activateUser(userProfileObj);
//				session.removeAttribute("hashId");
//				session.removeAttribute("mgUserId");
				mav.addAllObjects(PopupBox.success(PFX_USRUPDATE, null,
						messageService.getMessage(MessageConstants.SUCC_ACTIVATE_USER),
						PageConstants.PAGE_SEARCH_DOCTOR));
			} catch (IdmException e) {
				if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
					throw e;
				}
				mav.addAllObjects(PopupBox.error(e.getInternalErrorCode(), e.getMessage()));
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
				if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
					throw e;
				}
				mav.addAllObjects(PopupBox.success(PFX_USRUPDATE, null,
						messageService.getMessage(MessageConstants.ERROR_FAIL_ACTIVATE_USER),
						PageConstants.PAGE_SEARCH_DOCTOR));
			}
		}

		return mav;
	}


	String updateUserIdEncryptToReal(String id) {
		String idReal = id;
		try {
			TrippleDes td = new TrippleDes();
			idReal = td.decrypt(id);
			// id = userIdSecCd;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return idReal;
	}
}
