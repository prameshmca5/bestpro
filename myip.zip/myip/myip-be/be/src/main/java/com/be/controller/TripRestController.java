/**
 *
 */
package com.be.controller;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.model.BeTvlTrip;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.Trip;
import com.be.sdk.model.TripHealth;
import com.be.service.BeTvlTripHealthService;
import com.be.service.BeTvlTripService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;
import com.util.pagination.DataTableRequest;
import com.util.pagination.DataTableResults;


/**
 * @author michelle.angela
 *
 */
@Lazy
@RestController
@RequestMapping(BeUrlConstants.TRIP)
public class TripRestController extends AbstractRestController {

	@Autowired
	private BeTvlTripService tvlTripSvc;

	@Autowired
	private BeTvlTripHealthService tvlTripHealthSvc;


	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<Trip> searchTripPagination(@RequestBody Trip dto, HttpServletRequest request)
			throws IOException {

		DataTableRequest<Trip> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) tvlTripSvc.getCount(dto);
		List<Trip> filtered = tvlTripSvc.searchTripPagination(dto, dataTableInRQ);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("ALL DATA: {}", totalCount);
			LOGGER.debug("ALL filtered DATA : {}", filtered);
		}

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.GET_DETAIL, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Trip getTravellerDetail(@RequestBody Trip dto, HttpServletRequest request) throws IOException {
		return JsonUtil.transferToObject(tvlTripSvc.searchBeTvlTrip(dto), Trip.class);
	}


	@PostMapping(value = BeUrlConstants.INFO_ADD, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<Trip> addTripInfo(@RequestBody Trip dto, HttpServletRequest request) throws IOException {
		try {
			List<Trip> tripList = new ArrayList<>();
			if (!BaseUtil.isObjNull(dto)) {

				String userId = getCurrUserId(request);

				tripList = tvlTripSvc.addTripInfo(dto, userId, request);

			}

			return tripList;
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.HEALTH + BeUrlConstants.INFO_ADD, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public Trip addTripHealths(@RequestBody Trip dto, HttpServletRequest request) throws IOException {
		try {

			if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getTvlTripId())
					|| BaseUtil.isObjNull(dto.getTripHealths())) {
				throw new BeException(BeErrorCodeEnum.E400C004);
			}

			BeTvlTrip trip = tvlTripSvc.find(dto.getTvlTripId());
			if (BaseUtil.isObjNull(trip)) {
				throw new BeException(BeErrorCodeEnum.I404C001);
			}

			List<TripHealth> tripHealths = JsonUtil.transferToList(tvlTripHealthSvc.addTripHealth(
					dto.getTripHealths(), trip, dto.getStatusId(), getCurrUserId(request)), TripHealth.class);
			dto.setTripHealths(tripHealths);
			return dto;

		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}

}
