/**
 *
 */
package com.be.controller;


import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.model.BeTvlProfile;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.McAttendance;
import com.be.service.BeTvlMcAttendanceService;
import com.be.service.BeTvlProfileService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;


/**
 * @author Atiqah Khairuddin
 *
 */
@Lazy
@RestController
@RequestMapping(BeUrlConstants.MC_ATTENDANCE)
public class McAttendanceRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(McAttendanceRestController.class);

	@Autowired
	private BeTvlMcAttendanceService beTvlMcAttendanceSvc;

	@Autowired
	private BeTvlProfileService beTvlProfileSvc;


	@PostMapping(value = BeUrlConstants.INFO_ADD, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public McAttendance addAttendanceInfo(@RequestBody McAttendance dto, HttpServletRequest request)
			throws IOException {
		try {
			McAttendance mcAttendance = null;
			if (!BaseUtil.isObjNull(dto)) {
				BeTvlProfile beTvlProfile = beTvlProfileSvc.find(dto.getTvlProfId());
				if (BaseUtil.isObjNull(beTvlProfile)) {
					throw new BeException(BeErrorCodeEnum.I404C001);
				}
				mcAttendance = JsonUtil.transferToObject(
						beTvlMcAttendanceSvc.addAttendanceInfo(dto, beTvlProfile, getCurrUserId(request)), McAttendance.class);
			}
			return mcAttendance;
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}

	/**
	 * @Autowired private BeAcctTravellerService acctTravellerSvc;
	 *
	 *
	 * @PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = {
	 *                    MediaType.APPLICATION_JSON }, produces = {
	 *                    MediaType.APPLICATION_JSON }) public
	 *                    DataTableResults<AcctTraveller>
	 *                    searchTravellerPaginated(@RequestBody AcctTraveller
	 *                    dto, HttpServletRequest request) throws IOException {
	 *
	 *                    DataTableRequest<AcctTraveller> dataTableInRQ = new
	 *                    DataTableRequest<>(request.getParameterMap()); int
	 *                    totalCount = (int) acctTravellerSvc.getCount(dto);
	 *                    List<AcctTraveller> filtered =
	 *                    acctTravellerSvc.searchBeAcctTravellerPagination(dto,
	 *                    dataTableInRQ);
	 *
	 *                    if (LOGGER.isDebugEnabled()) { LOGGER.debug("ALL
	 *                    DATA: {}", totalCount); LOGGER.debug("ALL filtered
	 *                    DATA : {}", filtered); }
	 *
	 *                    return new DataTableResults<>(dataTableInRQ,
	 *                    totalCount, filtered); }
	 *
	 *
	 * @PostMapping(value = BeUrlConstants.GET_DETAIL, consumes = {
	 *                    MediaType.APPLICATION_JSON }, produces = {
	 *                    MediaType.APPLICATION_JSON }) public AcctTraveller
	 *                    getTravellerDetail(@RequestBody AcctTraveller dto,
	 *                    HttpServletRequest request) throws IOException {
	 *                    return
	 *                    JsonUtil.transferToObject(acctTravellerSvc.searchBeAcctTraveller(dto),
	 *                    AcctTraveller.class); }
	 *
	 *
	 * 				@SuppressWarnings("unchecked")
	 * @PostMapping(value = BeUrlConstants.INFO_ADD, consumes = {
	 *                    MediaType.APPLICATION_JSON }, produces = {
	 *                    MediaType.APPLICATION_JSON }) public
	 *                    List<AcctTraveller> addTravellerInfo(@RequestBody
	 *                    List<AcctTraveller>
	 *                    dtoList, @RequestParam("acctProfId") Integer
	 *                    acctProfId, HttpServletRequest request) throws
	 *                    IOException {
	 *
	 *                    List<AcctTraveller> acctTravellers = new
	 *                    ArrayList<>(); if (!BaseUtil.isListNull(dtoList)) {
	 *                    acctTravellers = JsonUtil.transferToList(
	 *                    acctTravellerSvc.addTravellerInfo(JsonUtil.transferToList(dtoList,
	 *                    BeAcctTraveller.class), acctProfId, "system"),
	 *                    AcctTraveller.class); } return acctTravellers; }
	 */
}
