/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BeConfigConstants {

	public static final String SMS_SWITCH = "SMS_SWITCH";


	private BeConfigConstants() {
		throw new IllegalStateException("BeConfigConstants class");
	}
}