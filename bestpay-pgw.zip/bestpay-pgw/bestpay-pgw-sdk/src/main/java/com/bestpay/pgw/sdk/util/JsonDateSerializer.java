/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.util;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class JsonDateSerializer extends JsonSerializer<Date> {

	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");


	@Override
	public void serialize(Date date, JsonGenerator gen, SerializerProvider provider) throws IOException {
		gen.writeString(dateFormat.format(date));
	}

}
