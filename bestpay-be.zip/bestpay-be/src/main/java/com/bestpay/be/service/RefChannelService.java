/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.config.ConfigConstants;
import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.CmsManagementCustomDao;
import com.bestpay.be.dao.RefChannelRepository;
import com.bestpay.be.model.RefChannel;
import com.bestpay.be.sdk.constants.BeCacheConstants;
import com.bestpay.be.sdk.model.Channel;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Afif Saman
 * @since Jul 10, 2018
 */
@Transactional
@Service(QualifierConstants.REF_CHANNEL_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_CHANNEL_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
public class RefChannelService extends AbstractService<RefChannel> {

	@Autowired
	RefChannelRepository refChannelDao;

	@Autowired
	CmsManagementCustomDao cmsManagementCustomDao;


	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_CHANNEL_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	@Override
	public List<RefChannel> findAll() {
		return refChannelDao.findAll();
	}


	@Override
	public GenericRepository<RefChannel> primaryDao() {
		return refChannelDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public RefChannel findRefChannelByPublicName(String publicName) {
		return refChannelDao.findRefChannelByPublicName(publicName);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<RefChannel> searchChannelByPagination(Channel channel, DataTableRequest dataTableInRQ) {
		return cmsManagementCustomDao.searchChannelByPagination(channel, dataTableInRQ);
	}


	public List<RefChannel> findChannelByPublicName(String publicName) {
		return refChannelDao.findChannelByPublicName(publicName);
	}


	public List<RefChannel> findChannelByName(String name) {
		return refChannelDao.findChannelByName(name);
	}

}
