/**
 * 
 */
package com.be.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.be.core.AbstractEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author michelle.angela
 *
 */
 @Entity
 @Table(name = "BE_MC_PIC")
public class BeMcPic extends AbstractEntity implements Serializable {

	 	private static final long serialVersionUID = 1773616194308090801L;

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name="MC_PIC_ID")
		private Integer mcPicId;

		@JsonIgnoreProperties("mcPics")
		@ManyToOne(fetch = FetchType.LAZY)
		@JoinColumn(name = "MC_PROF_ID")
		private BeMcProfile mcProfile;
		 
		@OneToOne(fetch = FetchType.LAZY)
		@JoinColumn(name = "TITLE_TYPE_MTDT_ID")
		private RefMetadata mcTypeMtdt;
		
		@Column(name = "FULL_NAME")
		private String fullName;
		
		@Column(name = "CONTACT_NO")
		private String contactNo;
		
		@Column(name = "DESIGNATION")
		private String designation;
		
		@Column(name = "EMAIL")
		private String email;
		
		@Type(type = "org.hibernate.type.NumericBooleanType")
		@Column(name = "STATUS")
		private Boolean isActive;
		
		@Column(name = "CREATE_ID")
		private String createId;

		@Column(name = "CREATE_DT")
		private Timestamp createDt;

		@Column(name = "UPDATE_ID")
		private String updateId;

		@Column(name = "UPDATE_DT")
		private Timestamp updateDt;

		public Integer getMcPicId() {
			return mcPicId;
		}

		public void setMcPicId(Integer mcPicId) {
			this.mcPicId = mcPicId;
		}

		public BeMcProfile getMcProfile() {
			return mcProfile;
		}

		public void setMcProfile(BeMcProfile mcProfile) {
			this.mcProfile = mcProfile;
		}

		public RefMetadata getMcTypeMtdt() {
			return mcTypeMtdt;
		}

		public void setMcTypeMtdt(RefMetadata mcTypeMtdt) {
			this.mcTypeMtdt = mcTypeMtdt;
		}

		public String getFullName() {
			return fullName;
		}

		public void setFullName(String fullName) {
			this.fullName = fullName;
		}

		public String getContactNo() {
			return contactNo;
		}

		public void setContactNo(String contactNo) {
			this.contactNo = contactNo;
		}

		public String getDesignation() {
			return designation;
		}

		public void setDesignation(String designation) {
			this.designation = designation;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public Boolean getIsActive() {
			return isActive;
		}

		public void setIsActive(Boolean isActive) {
			this.isActive = isActive;
		}

		public String getCreateId() {
			return createId;
		}

		public void setCreateId(String createId) {
			this.createId = createId;
		}

		public Timestamp getCreateDt() {
			return createDt;
		}

		public void setCreateDt(Timestamp createDt) {
			this.createDt = createDt;
		}

		public String getUpdateId() {
			return updateId;
		}

		public void setUpdateId(String updateId) {
			this.updateId = updateId;
		}

		public Timestamp getUpdateDt() {
			return updateDt;
		}

		public void setUpdateDt(Timestamp updateDt) {
			this.updateDt = updateDt;
		}
		
}
