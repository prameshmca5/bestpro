/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeWatchlist;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Watchlist;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;


/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_WATCHLIST_QF)
public class BeWatchlistQf extends QueryFactory<BeWatchlist> {

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BeWatchlist> searchByProperty(BeWatchlist t) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<BeWatchlist> searchAllByProperty(BeWatchlist t) {
		CriteriaQuery<BeWatchlist> cq = cb.createQuery(BeWatchlist.class);
		Root<BeWatchlist> root = cq.from(BeWatchlist.class);
		List<Predicate> predicates = generateCriteria(cb, root, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public Long getCount(Watchlist dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeWatchlist> root = cq.from(BeWatchlist.class);
		predicates.addAll(generateCriteria(cb, root, dto));

		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}


	public List<BeWatchlist> searchAllByProperty(Watchlist dto, DataTableRequest<?> dataTableInRQ) {

		List<BeWatchlist> result = new ArrayList<>();
		CriteriaQuery<BeWatchlist> cq = cb.createQuery(BeWatchlist.class);
		List<Predicate> predicates = new ArrayList<>();
		if (cq != null) {
			Root<BeWatchlist> root = cq.from(BeWatchlist.class);
			predicates.addAll(generateCriteria(cb, root, dto));

			cq.select(root);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					List<Order> orders = getOrderByClause(cb, root, pagination);
					if (BaseUtil.isListNull(orders)) {
						orders.add(cb.desc(root.get("createDt")));
					}
					cq.orderBy(orders);
				}
			}

			TypedQuery<BeWatchlist> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			Watchlist dto = JsonUtil.transferToObject(criteria, Watchlist.class);
			if (!BaseUtil.isObjNull(dto.getIdNo())) {
				predicates.add(cb.equal(from.get("idNo"), dto.getIdNo()));
			}

			if (!BaseUtil.isObjNull(dto.getStatus())) {
				predicates.add(cb.equal(from.get("status"), dto.getStatus()));
			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}
}
