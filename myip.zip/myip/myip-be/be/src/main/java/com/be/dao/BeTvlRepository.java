/**
 *
 */
package com.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.BeTvl;


/**
 * @author michelle.angela
 *
 */
@Lazy
@Repository
@RepositoryDefinition(domainClass = BeTvl.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_DAO)
public interface BeTvlRepository extends GenericRepository<BeTvl> {

	@Query("select u from BeTvl u where u.tvlProfile.tvlProfId = :tvlProfId ")
	BeTvl findByTvlProfId(@Param("tvlProfId") Integer tvlProfId);
}
