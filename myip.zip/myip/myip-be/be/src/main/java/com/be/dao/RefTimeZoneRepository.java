package com.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.RefTimeZone;


/**
 * @author Atiqah Khairuddin
 * @since Sept 17, 2020
 */
@Lazy
@Repository
@RepositoryDefinition(domainClass = RefTimeZone.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_TIMEZONE_DAO)
public interface RefTimeZoneRepository extends GenericRepository<RefTimeZone> {

	@Query("select u from RefTimeZone u where u.tzid = :tzid ")
	RefTimeZone findByTzId(@Param("tzid") String tzid);


	@Query("select u from RefTimeZone u where u.cntryCd = :cntryCd ")
	RefTimeZone findByCountryCode(@Param("cntryCd") String cntryCd);


	@Query("select u from RefTimeZone u where u.timeZoneId = :timeZoneId ")
	RefTimeZone findByTimezoneId(@Param("timeZoneId") String timeZoneId);
}