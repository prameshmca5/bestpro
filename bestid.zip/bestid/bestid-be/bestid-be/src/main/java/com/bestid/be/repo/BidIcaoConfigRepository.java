/**
 *
 */
package com.bestid.be.repo;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidConfig;
import com.bestid.be.model.BidIcaoConfig;


/**
 * @author roziana
 * @since Feb 26, 2019
 */
@Repository
@RepositoryDefinition(domainClass = BidConfig.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_ICAO_CONFIG_REPOSITORY)
public interface BidIcaoConfigRepository extends GenericRepository<BidIcaoConfig> {

	@Query("select u from BidIcaoConfig u where u.configCd= :configCd")
	BidIcaoConfig findByConfigCd(@Param("configCd") String configCd);


	@Query("select u from BidIcaoConfig u where u.configVal= :configVal")
	List<BidIcaoConfig> findByConfigVal(@Param("configVal") String configVal);

}
