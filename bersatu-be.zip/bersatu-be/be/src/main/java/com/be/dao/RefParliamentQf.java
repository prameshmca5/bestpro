/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.RefParliament;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Parliament;
import com.util.BaseUtil;
import com.util.JsonUtil;


/**
 * @author Ramesh Pongiannan
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_PARLIAMENT_QF)
public class RefParliamentQf extends QueryFactory<RefParliament> {

	@PersistenceContext
	private EntityManager em;


	@Override
	public Specification<RefParliament> searchByProperty(RefParliament t) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<RefParliament> searchAllByProperty(RefParliament t) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<RefParliament> cq = cb.createQuery(RefParliament.class);
		Root<RefParliament> parliamentRoot = cq.from(RefParliament.class);
		List<Predicate> predicates = generateCriteria(cb, parliamentRoot, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			Parliament dto = JsonUtil.transferToObject(criteria, Parliament.class);

			if (!BaseUtil.isObjNull(dto)) {

				if (!BaseUtil.isObjNull(dto.getParliamentCd())) {
					predicates.add(cb.equal(from.get("parliamentCd"), dto.getParliamentCd()));
				}

				if (!BaseUtil.isObjNull(dto.getParliamentDesc())) {
					predicates.add(cb.like(from.get("parliamentDesc"), "%" + dto.getParliamentDesc() + "%"));
				}

			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

}
