/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dialect.processor;


import org.thymeleaf.Arguments;
import org.thymeleaf.dom.Element;
import org.thymeleaf.processor.ProcessorResult;

import com.bestpay.web.dialect.AbstractBstElement;
import com.bestpay.web.dialect.constants.AttributeConstants;
import com.bestpay.web.dialect.constants.ElementConstants;
import com.bestpay.web.dialect.constants.ElementEnum;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class SpanElementProcessor extends AbstractBstElement {

	public SpanElementProcessor(String elementName) {
		super(elementName);
	}


	@Override
	protected ProcessorResult processElement(Arguments arguments, Element element) {
		String elementNm = getElementName(element);
		Element newElement = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_SPAN,
				false);
		newElement.setRecomputeProcessorsImmediately(true);
		newElement.setAttribute(AttributeConstants.ATTR_CLASS, ElementEnum.findStyleByName(elementNm));

		element.getParent().insertAfter(element, newElement);
		element.getParent().removeChild(element);

		return ProcessorResult.OK;
	}


	@Override
	public int getPrecedence() {
		return 100000;
	}

}
