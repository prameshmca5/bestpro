/**
 *
 */
package com.bestpay.pgw.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.PgwMerchantPidRepository;
import com.bestpay.pgw.model.PgwMerchantPid;
import com.bestpay.pgw.util.QualifierConstants;


/**
 * @author Mohammad Rashid
 * @since 25/03/2019
 */
@Service(QualifierConstants.PGW_MERCHANT_PID_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_PID_SVC)
@Transactional
public class PgwMerchantPidService extends AbstractService<PgwMerchantPid> {

	@Autowired
	private PgwMerchantPidRepository pgwMerchantPidDao;


	@Override
	public GenericRepository<PgwMerchantPid> primaryDao() {
		return pgwMerchantPidDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwMerchantPid> findByMerchantPid(String merchantId) {
		return pgwMerchantPidDao.findPgwMerchantPidBymerchantId(merchantId);
	}


	public PgwMerchantPid findByMerchantMaxmoneyPid(String merchantId) {
		return pgwMerchantPidDao.findPgwMerchantMaxmoeyPidBymerchantId(merchantId);
	}


	public PgwMerchantPid findByMerchantMaxmoneyPidByPid(String pid) {
		return pgwMerchantPidDao.findPgwMerchantMaxmoeyPidByPid(pid);
	}

}