/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;
import java.util.List;

/**
 * @author michelle.angela
 *
 */
public class PaymentDtl implements Serializable, IQfCriteria<PaymentDtl> {

	private static final long serialVersionUID = -232602477579065682L;
	
	private Integer tvlPmtDtlId;
	
	private Payment tvlPayment;
	
	private TvlProfile tvlProfile;
	
	private double amount;
	
	private List<PaymentInfo> tvlPaymentInfos;
	
	private List<TvlRefund> tvlRefunds;
	
	private AcctTraveller acctTraveller; 

	public Integer getTvlPmtDtlId() {
		return tvlPmtDtlId;
	}

	public void setTvlPmtDtlId(Integer tvlPmtDtlId) {
		this.tvlPmtDtlId = tvlPmtDtlId;
	}

	public Payment getTvlPayment() {
		return tvlPayment;
	}

	public void setTvlPayment(Payment tvlPayment) {
		this.tvlPayment = tvlPayment;
	}

	public TvlProfile getTvlProfile() {
		return tvlProfile;
	}

	public void setTvlProfile(TvlProfile tvlProfile) {
		this.tvlProfile = tvlProfile;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public List<PaymentInfo> getTvlPaymentInfos() {
		return tvlPaymentInfos;
	}

	public void setTvlPaymentInfos(List<PaymentInfo> tvlPaymentInfos) {
		this.tvlPaymentInfos = tvlPaymentInfos;
	}

	public List<TvlRefund> getTvlRefunds() {
		return tvlRefunds;
	}

	public void setTvlRefunds(List<TvlRefund> tvlRefunds) {
		this.tvlRefunds = tvlRefunds;
	}

	public AcctTraveller getAcctTraveller() {
		return acctTraveller;
	}

	public void setAcctTraveller(AcctTraveller acctTraveller) {
		this.acctTraveller = acctTraveller;
	}

}
