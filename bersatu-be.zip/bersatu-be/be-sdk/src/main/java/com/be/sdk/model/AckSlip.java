/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;


/**
 * @author nurul.naimma
 *
 * @since Aug 6, 2021
 */
public class AckSlip implements Serializable {

	private static final long serialVersionUID = 5718212658115143565L;

	private String fullName;

	private String idNo;

	private String orgDivisionCd;

	private String orgDivisionDesc;

	private String orgBranchCd;

	private String orgBranchDesc;

	private Double totalAmount;

	private String address1;

	private String address2;

	private String address3;

	private String postcode;

	private String cityCd;

	private String cityDesc;

	private String stateCd;

	private String stateDesc;

	private String countryCd;

	private String countryDesc;


	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}


	/**
	 * @param fullName
	 *             the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	/**
	 * @return the idNo
	 */
	public String getIdNo() {
		return idNo;
	}


	/**
	 * @param idNo
	 *             the idNo to set
	 */
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}


	/**
	 * @return the orgDivisionCd
	 */
	public String getOrgDivisionCd() {
		return orgDivisionCd;
	}


	/**
	 * @param orgDivisionCd
	 *             the orgDivisionCd to set
	 */
	public void setOrgDivisionCd(String orgDivisionCd) {
		this.orgDivisionCd = orgDivisionCd;
	}


	/**
	 * @return the orgDivisionDesc
	 */
	public String getOrgDivisionDesc() {
		return orgDivisionDesc;
	}


	/**
	 * @param orgDivisionDesc
	 *             the orgDivisionDesc to set
	 */
	public void setOrgDivisionDesc(String orgDivisionDesc) {
		this.orgDivisionDesc = orgDivisionDesc;
	}


	/**
	 * @return the orgBranchCd
	 */
	public String getOrgBranchCd() {
		return orgBranchCd;
	}


	/**
	 * @param orgBranchCd
	 *             the orgBranchCd to set
	 */
	public void setOrgBranchCd(String orgBranchCd) {
		this.orgBranchCd = orgBranchCd;
	}


	/**
	 * @return the orgBranchDesc
	 */
	public String getOrgBranchDesc() {
		return orgBranchDesc;
	}


	/**
	 * @param orgBranchDesc
	 *             the orgBranchDesc to set
	 */
	public void setOrgBranchDesc(String orgBranchDesc) {
		this.orgBranchDesc = orgBranchDesc;
	}


	/**
	 * @return the totalAmount
	 */
	public Double getTotalAmount() {
		return totalAmount;
	}


	/**
	 * @param totalAmount
	 *             the totalAmount to set
	 */
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}


	/**
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}


	/**
	 * @param address1
	 *             the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}


	/**
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}


	/**
	 * @param address2
	 *             the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	/**
	 * @return the address3
	 */
	public String getAddress3() {
		return address3;
	}


	/**
	 * @param address3
	 *             the address3 to set
	 */
	public void setAddress3(String address3) {
		this.address3 = address3;
	}


	/**
	 * @return the postcode
	 */
	public String getPostcode() {
		return postcode;
	}


	/**
	 * @param postcode
	 *             the postcode to set
	 */
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	/**
	 * @return the cityCd
	 */
	public String getCityCd() {
		return cityCd;
	}


	/**
	 * @param cityCd
	 *             the cityCd to set
	 */
	public void setCityCd(String cityCd) {
		this.cityCd = cityCd;
	}


	/**
	 * @return the cityDesc
	 */
	public String getCityDesc() {
		return cityDesc;
	}


	/**
	 * @param cityDesc
	 *             the cityDesc to set
	 */
	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc;
	}


	/**
	 * @return the stateCd
	 */
	public String getStateCd() {
		return stateCd;
	}


	/**
	 * @param stateCd
	 *             the stateCd to set
	 */
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}


	/**
	 * @return the stateDesc
	 */
	public String getStateDesc() {
		return stateDesc;
	}


	/**
	 * @param stateDesc
	 *             the stateDesc to set
	 */
	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc;
	}


	/**
	 * @return the countryCd
	 */
	public String getCountryCd() {
		return countryCd;
	}


	/**
	 * @param countryCd
	 *             the countryCd to set
	 */
	public void setCountryCd(String countryCd) {
		this.countryCd = countryCd;
	}


	/**
	 * @return the countryDesc
	 */
	public String getCountryDesc() {
		return countryDesc;
	}


	/**
	 * @param countryDesc
	 *             the countryDesc to set
	 */
	public void setCountryDesc(String countryDesc) {
		this.countryDesc = countryDesc;
	}

}
