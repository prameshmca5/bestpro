/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since 03/03/2018
 */
public class FileUploadConstants {

	private FileUploadConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String PROFILE_PIC = "PROFPIC";

	public static final String TICKET_ATTACH = "TICKETATTACH";

}