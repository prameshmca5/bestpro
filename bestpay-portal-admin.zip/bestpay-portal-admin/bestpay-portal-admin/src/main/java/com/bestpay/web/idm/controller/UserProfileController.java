/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.idm.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.constants.FileUploadConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.model.RefDocuments;
import com.bestpay.dm.sdk.exception.DmException;
import com.bestpay.dm.sdk.model.Documents;
import com.bestpay.idm.sdk.constants.BaseConstants;
import com.bestpay.idm.sdk.constants.IdmRoleConstants;
import com.bestpay.idm.sdk.constants.IdmUserTypeConstants;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.ForgotPassword;
import com.bestpay.idm.sdk.model.UserGroup;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.idm.sdk.pagination.DataTableResults;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.config.audit.AuditActionControl;
import com.bestpay.web.config.audit.AuditActionPolicy;
import com.bestpay.web.config.iam.CustomUserDetails;
import com.bestpay.web.constants.AppConstants;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.constants.ProjectEnum;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.dto.CustomMultipartFile;
import com.bestpay.web.dto.FileUpload;
import com.bestpay.web.idm.form.IdmUploadProfilePictureForm;
import com.bestpay.web.util.WebUtil;
import com.bstsb.util.PopupBox;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_IDM_USR_LST)
public class UserProfileController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserProfileController.class);

	private static final String USERSTAT = "USERSTAT";

	private static final String STATUS_LIST = "statusList";

	private static final String USR_CREATE = "usrCreate";

	private static final String ERROR = "Error";

	private static final String EXCEPTION = "Exception: {}";

	private static final String IDM_RESPONSE_ERROR = "IDM Response Error: {} - {}";

	private static final String IDM_EXCEPTION = "IdmException: {}";

	private static final String PROFILE_PICTURE_DOCMGMTID = "Profile Picture DocMgtId: {}";

	private static final String IDM_UPD = "idmupd";

	private static final String IS_ADMIN = "isAdmin";

	private static final String IS_INACTIVE = "isInactive";

	private static final String NEW_USER = "newUser";

	private static final String UPD_USER = "updUser";

	private static final String USER_ID = "userId";

	private static final String USER_PROFILE = "userProfile";

	private static final String USER_MGMT = "user_mgmt";

	private static final String USR_UPDATE = "usrUpdate";

	@Autowired
	@Qualifier("userProfileValidator")
	private Validator validator;


	@Override
	protected void bindingPreparation(WebDataBinder binder) {
		binder.setValidator(validator);
		super.bindingPreparation(binder);
	}


	@GetMapping
	public ModelAndView view(UserProfile userProfile, BindingResult result) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_IDM_USR_LST, USER_MGMT, null, "user-profile-script");
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.cmn.mgmt.usr"));
		List<UserGroup> userGrp = getUserRoleGroupList();
		if (!BaseUtil.isObjNull(userProfile) && !BaseUtil.isListNullZero(userGrp)) {
			int maxNoOfUser = getMaxNoOfUser();
			LOGGER.info("maxNoOfUser = {}", maxNoOfUser);
		} else {
			mav.addObject("viewCreateBtn", messageService.getMessage("lbl.msg.alrdy.max.lmt"));
		}
		mav.addObject(STATUS_LIST, staticData.status(USERSTAT));
		return mav;
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String getApplicationInfoPaginated(@ModelAttribute(USER_PROFILE) UserProfile userProfile,
			BindingResult result, HttpServletRequest request) {
		LOGGER.info("GET PAGINATED USER LIST....");
		DataTableResults<UserProfile> tasks = null;
		try {
			UserProfile authUser = getCurrentUser();
			userProfile.setUserType(IdmUserTypeConstants.ADM);
			if (!BaseUtil.isObjNull(authUser)) {
				if (authUser.getUserType().equals("SYSA")) {
					List<String> userRoleGroupCodeList = new ArrayList<>();
					userRoleGroupCodeList.add(IdmRoleConstants.ADM_ADMIN);
					userRoleGroupCodeList.add(IdmRoleConstants.ADM_FINANCE);
					userRoleGroupCodeList.add(IdmRoleConstants.SYSTEM_ADMIN);
					userProfile.setUserRoleGroupCodeList(userRoleGroupCodeList);
				}

				String userRoleGroupCode = BaseUtil.getStr(authUser.getUserRoleGroupCode());
				LOGGER.info("userRoleGroup: {}", userRoleGroupCode);

				boolean isPortalAdmin = hasAnyRole(IdmRoleConstants.ADM_ADMIN, IdmRoleConstants.SYSTEM_ADMIN);
				LOGGER.info("isSuperAdmin: {}", isPortalAdmin);

				userProfile.setParentRoleGroup(userRoleGroupCode);

				if (isPortalAdmin) {
					userProfile.setUserType(null);

				} else {
					if (!BaseUtil.isObjNull(userRoleGroupCode)) {
						String userGroup = getUserGroupCode(authUser.getUserRoleGroupCode());
						LOGGER.debug("userGroup code: {}", userGroup);
						userProfile.setUserGroupCode(userGroup);
					} else {
						LOGGER.debug("User role group not found.");
					}
				}

			}

			tasks = getIdmService().searchUserProfile(userProfile, false, getPaginationRequest(request, true));
		} catch (Exception e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(e.getMessage());
		}

		return new Gson().toJson(tasks);
	}


	/**
	 * User Profile Detail Page
	 *
	 * @param userId
	 * @param userProfile
	 * @param result
	 * @return
	 * @throws BeException
	 */
	@GetMapping(value = "/{userId}")
	public ModelAndView viewProfile(@PathVariable String userId,
			@ModelAttribute(USER_PROFILE) IdmUploadProfilePictureForm userProfile, BindingResult result)
			throws BeException {
		ModelAndView mav = getDefaultMavProfile(userId);
		IdmUploadProfilePictureForm userProfile1 = (IdmUploadProfilePictureForm) mav.getModelMap().get(USER_PROFILE);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.usr.prof"));
		mav.addObject(USER_PROFILE, userProfile1);
		mav.addObject(STATUS_LIST, staticData.status(USERSTAT));
		return mav;
	}


	@PostMapping(value = "/{userId}", params = "reset")
	public ModelAndView reset(@RequestParam String reset, @PathVariable String userId,
			@ModelAttribute(USER_PROFILE) IdmUploadProfilePictureForm userProfile, BindingResult result,
			HttpSession session) throws BeException {
		return viewProfile(userId, userProfile, result);
	}


	private ModelAndView getDefaultMavProfile(String userId) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_IDM_USR_CRED, USER_MGMT, null);
		IdmUploadProfilePictureForm userProfile = new IdmUploadProfilePictureForm();
		boolean isInactive = false;

		if (BaseUtil.isEqualsCaseIgnore("new", userId)) {
			mav.addObject(AppConstants.PORTAL_TRANS_ID, NEW_USER);
			userProfile.setUserType(IdmUserTypeConstants.ADM);
		} else {
			String userName = BaseUtil.isEqualsCaseIgnore("id", userId) ? getCurrentUserId() : userId;

			try {
				UserProfile userProfileObj = getIdmService().getUserProfileById(userName, false, false);
				if (!BaseUtil.isEqualsCaseIgnore("id", userId) && !BaseUtil.isObjNull(userProfileObj)) {
					isInactive = !BaseUtil.isEqualsCaseIgnore(BaseConstants.STATUS_ACTIVE,
							userProfileObj.getStatus());
				}
				userProfile = dozerMapper.map(userProfileObj, IdmUploadProfilePictureForm.class);
				if (userProfileObj.getStatus().equalsIgnoreCase("A")) {
					userProfile.setStatusValue("Active");
				} else if (userProfileObj.getStatus().equalsIgnoreCase("I")) {
					userProfile.setStatusValue("Inactive");
				} else if (userProfileObj.getStatus().equalsIgnoreCase("F")) {
					userProfile.setStatusValue("Pending Activation");
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}

			// Update for logged in User
			if (BaseUtil.isEqualsCaseIgnore("id", userId)) {
				mav.addObject(AppConstants.PORTAL_MODULE, IDM_UPD);
			} else if (!isInactive) {
				mav.addObject(AppConstants.PORTAL_TRANS_ID, UPD_USER);
			}

		}

		// Retrieve Profile Picture
		List<FileUpload> fileUpload = new ArrayList<>();
		List<RefDocuments> refDocLst = getRefDocLst();
		for (RefDocuments refDoc : refDocLst) {
			FileUpload file = new FileUpload();
			Documents docs = null;
			if (!BaseUtil.isObjNull(userProfile.getDocMgtId())) {
				try {
					docs = getDmService(ProjectEnum.BESTPAY).getMetadata(userProfile.getDocMgtId());
				} catch (IdmException e) {
					LOGGER.error(IDM_EXCEPTION, e.getMessage());
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (DmException e) {
					LOGGER.error("DmException: {}", e.getMessage());
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error(EXCEPTION, e.getMessage());
				}
			}

			if (docs != null && Integer.valueOf(docs.getDocid()).equals(Integer.valueOf(refDoc.getDocId()))) {
				file = dozerMapper.map(docs, FileUpload.class);
				CustomMultipartFile fl = new CustomMultipartFile();
				fl.setFilename(file.getFileName());
				file.setFile(fl);
			}
			file.setDocId(refDoc.getDocId());
			file.setDocMgtId(userProfile.getDocMgtId());
			if (refDoc.getCompulsary() != null && "Y".equalsIgnoreCase(refDoc.getCompulsary())) {
				file.setCompulsary(true);
			}
			fileUpload.add(file);
		}

		userProfile.setFileUploads(fileUpload);
		mav.addObject(IS_ADMIN, hasAnyRole(IdmRoleConstants.ADMIN_ROLES));
		mav.addObject(IS_INACTIVE, isInactive);
		mav.addObject(USER_ID, userId);
		mav.addObject(USER_PROFILE, userProfile);
		mav.addObject(STATUS_LIST, staticData.status(USERSTAT));
		return mav;
	}


	/**
	 * User Profile Create
	 *
	 * @param userId
	 * @param userProfile
	 * @param result
	 * @return
	 * @throws Exception
	 */
	@AuditActionControl(action = AuditActionPolicy.CREATE_USER)
	@PostMapping(value = "/{userId}", params = "create")
	public ModelAndView create(@PathVariable String userId,
			@Valid @ModelAttribute(USER_PROFILE) IdmUploadProfilePictureForm userProfile, BindingResult result) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_IDM_USR_CRED, USER_MGMT, null);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.cmn.usr.cre"));
		if (!result.hasErrors()) {
			// get max count of selected role group code.
			String userRoleGroupCode = userProfile.getUserRoleGroupCode();
			int allowedCount = getMaxNoOfUserPerRole(userRoleGroupCode);
			LOGGER.info("Total Allowed {} -- {}", userRoleGroupCode, allowedCount);
			// Get count max of selected role group profile.
			int profileCount = getMaxNoOfUserPerRoleprofile(userRoleGroupCode);
			LOGGER.info("Total Active Count Profile {}", profileCount);
			if (allowedCount <= profileCount) {
				mav.addAllObjects(PopupBox.warn(USR_CREATE, messageService
						.getMessage(MessageConstants.ERROR_MAX_CREATE_USER, new Integer[] { allowedCount })));
			} else {

				UserProfile pr = getCurrentUser();
				userProfile = dozerMapper.map(userProfile, IdmUploadProfilePictureForm.class);
				if (hasAnyRole(IdmRoleConstants.ADMIN_ROLES)) {
					if (BaseUtil.isObjNull(userProfile.getUserGroupCode())) {
						userProfile.setUserGroupCode(userProfile.getUserRoleGroupCode());
					}
					try {
						UserGroup ug = findAdminRoleGroupCodeByUserGroup(userProfile.getUserGroupCode(),
								getCurrentUser().getUserRoleGroupCode());
						if (ug != null) {
							userProfile.setUserRoleGroupCode(ug.getUserRoleGroupCode());
							userProfile.setUserType(ug.getUserType());
						}
					} catch (IdmException e) {
						if (WebUtil.checkTokenError(e)) {
							throw e;
						}
						if (WebUtil.checkSystemDown(e)) {
							throw e;
						}
						mav.addAllObjects(WebUtil.checkServiceDown(e));
					} catch (Exception e) {
						mav.addAllObjects(WebUtil.checkServiceDown(e));
						mav.addAllObjects(PopupBox.error(USR_CREATE,
								messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
					}
				} else {
					userProfile.setUserType(BaseUtil.isObjNull(pr) ? "" : pr.getUserType());
				}

				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("userProfile: {}", new ObjectMapper().valueToTree(userProfile));
				}

				UserProfile createUserProfile = dozerMapper.map(userProfile, UserProfile.class);

				if (BaseUtil.isEqualsCaseIgnore("new", userId)) {
					mav.addObject(AppConstants.PORTAL_TRANS_ID, NEW_USER);
					try {
						if (!BaseUtil.isListNullZero(userProfile.getFileUploads())
								&& userProfile.getFileUploads().size() == 1) {
							// Profile Picture is only one
							FileUpload fu = userProfile.getFileUploads().get(0);
							com.bestpay.web.dto.CustomMultipartFile file = fu.getFile();
							if (file != null) {
								Documents doc = new Documents();
								doc.setContentType(file.getContentType());
								doc.setFilename(file.getFilename());
								doc.setDocid(fu.getDocId());
								doc.setLength(file.getSize());
								doc.setRefno(createUserProfile.getUserId());
								doc.setContent(file.getContent());
								if (!BaseUtil.isObjNull(doc.getContent()) && (doc.getContent().length != 0)
										|| (BaseUtil.isObjNull(doc.getId())
												&& (doc.getContent().length != 0))) {
									Documents newDoc = getDmService(ProjectEnum.BESTPAY).upload(doc);
									LOGGER.info(PROFILE_PICTURE_DOCMGMTID, newDoc.getId());
									createUserProfile.setDocMgtId(newDoc.getId());
								}
							}
						}

						createUserProfile = getIdmService().createUser(createUserProfile);
						if (createUserProfile != null) {
							mav.addAllObjects(PopupBox.success(USR_CREATE, null,
									messageService.getMessage(MessageConstants.SUCC_CRE_USER),
									PageConstants.PAGE_IDM_USR_LST));
						} else {
							mav.addAllObjects(PopupBox.error(USR_CREATE, null,
									messageService.getMessage(MessageConstants.ERROR_CRE_USER),
									PageConstants.PAGE_IDM_USR_LST + "/" + userId));
						}
					} catch (IdmException e) {
						if (WebUtil.checkSystemDown(e)) {
							throw e;
						}
						mav.addAllObjects(PopupBox.error(USR_CREATE, ERROR,
								messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
					} catch (Exception e) {
						LOGGER.error(EXCEPTION, e.getMessage());
						mav.addAllObjects(PopupBox.error(USR_CREATE, ERROR,
								messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
					}

				} else {
					try {
						if (BaseUtil.isEqualsCaseIgnore("id", userId)) {
							mav.addObject(AppConstants.PORTAL_MODULE, IDM_UPD);
							createUserProfile.setUserId(getCurrentUserId());
						} else {
							mav.addObject(AppConstants.PORTAL_TRANS_ID, UPD_USER);
						}

						boolean isUpdated = getIdmService().updateProfile(createUserProfile);

						if (isUpdated) {
							if (BaseUtil.isEqualsCaseIgnore("id", userId)) {
								mav.addAllObjects(PopupBox.success(USR_UPDATE, null,
										messageService.getMessage(MessageConstants.SUCC_UPD_USER),
										PageConstants.PAGE_IDM_USR_UPD_LOGIN));
							} else {
								mav.addAllObjects(PopupBox.success(USR_UPDATE, null,
										messageService.getMessage(MessageConstants.SUCC_UPD_USER),
										PageConstants.PAGE_IDM_USR_LST));
							}
						} else {
							mav.addAllObjects(PopupBox.error(USR_UPDATE, null,
									messageService.getMessage(MessageConstants.ERROR_UPD_USER),
									PageConstants.PAGE_IDM_USR_LST + "/" + userId));
						}
					} catch (IdmException e) {
						if (WebUtil.checkSystemDown(e)) {
							throw e;
						}
						mav.addAllObjects(PopupBox.error(USR_UPDATE, ERROR,
								messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
					} catch (Exception e) {
						mav.addAllObjects(PopupBox.error(USR_UPDATE, ERROR,
								messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
					}
				}
			}
		}
		mav.addObject(IS_ADMIN, hasAnyRole(IdmRoleConstants.ADMIN_ROLES));
		mav.addObject(USER_PROFILE, userProfile);
		mav.addObject(IS_INACTIVE, false);
		mav.addObject(USER_ID, userId);
		return mav;
	}


	/**
	 * User Profile Update
	 *
	 * @param userId
	 * @param userProfile
	 * @param result
	 * @return
	 * @throws BeException
	 * @throws Exception
	 */
	@AuditActionControl(action = AuditActionPolicy.UPDATE_USER)
	@PostMapping(value = "/{userId}", params = "update")
	public ModelAndView update(@PathVariable String userId,
			@Valid @ModelAttribute(USER_PROFILE) IdmUploadProfilePictureForm userProfile, BindingResult result)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_IDM_USR_CRED, USER_MGMT, null);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.cmn.usr.upd"));
		if (!result.hasErrors()) {
			UserProfile pr = getCurrentUser();
			userProfile = dozerMapper.map(userProfile, IdmUploadProfilePictureForm.class);
			if (hasAnyRole(IdmRoleConstants.ADMIN_ROLES)) {
				if (BaseUtil.isObjNull(userProfile.getUserGroupCode())) {
					userProfile.setUserGroupCode(userProfile.getUserRoleGroupCode());
				}
				try {
					UserGroup ug = findAdminRoleGroupCodeByUserGroup(userProfile.getUserGroupCode(),
							getCurrentUser().getUserRoleGroupCode());
					if (ug != null) {
						userProfile.setUserRoleGroupCode(ug.getUserRoleGroupCode());
						userProfile.setUserType(ug.getUserType());
					}
				} catch (IdmException e) {
					if (WebUtil.checkTokenError(e)) {
						throw e;
					}
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
					mav.addAllObjects(WebUtil.checkServiceDown(e));
				} catch (Exception e) {
					mav.addAllObjects(WebUtil.checkServiceDown(e));
					mav.addAllObjects(PopupBox.error(USR_CREATE,
							messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
				}
			} else {
				userProfile.setUserType(BaseUtil.isObjNull(pr) ? "" : pr.getUserType());
			}
			UserProfile createUserProfile = dozerMapper.map(userProfile, UserProfile.class);

			if (BaseUtil.isEqualsCaseIgnore("new", userId)) {
				mav.addObject(AppConstants.PORTAL_TRANS_ID, NEW_USER);
				try {
					createUserProfile = getIdmService().createUser(createUserProfile);
					if (createUserProfile != null) {
						mav.addAllObjects(PopupBox.success(USR_CREATE, null,
								messageService.getMessage(MessageConstants.SUCC_CRE_USER),
								PageConstants.PAGE_IDM_USR_LST));
					} else {
						mav.addAllObjects(PopupBox.error(USR_CREATE, null,
								messageService.getMessage(MessageConstants.ERROR_CRE_USER),
								PageConstants.PAGE_IDM_USR_LST + "/" + userId));
					}
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
					mav.addAllObjects(PopupBox.error(USR_CREATE, null,
							messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
				} catch (Exception e) {
					mav.addAllObjects(PopupBox.error(USR_CREATE, null,
							messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
				}

			} else {
				try {
					if (BaseUtil.isEqualsCaseIgnore("id", userId)) {
						mav.addObject(AppConstants.PORTAL_MODULE, IDM_UPD);
						createUserProfile.setUserId(getCurrentUserId());
					} else {
						mav.addObject(AppConstants.PORTAL_TRANS_ID, UPD_USER);
					}

					if (!BaseUtil.isListNullZero(userProfile.getFileUploads())
							&& userProfile.getFileUploads().size() == 1) {
						// Profile Picture is only one
						FileUpload fu = userProfile.getFileUploads().get(0);
						com.bestpay.web.dto.CustomMultipartFile file = fu.getFile();
						if (file != null) {
							Documents doc = new Documents();
							doc.setContentType(file.getContentType());
							doc.setFilename(file.getFilename());
							doc.setDocid(fu.getDocId());
							if (!BaseUtil.isObjNull(fu.getDocMgtId())) {
								doc.setId(fu.getDocMgtId());
							}
							doc.setLength(file.getSize());
							doc.setRefno(createUserProfile.getUserId());
							doc.setContent(file.getContent());
							if (!BaseUtil.isObjNull(doc.getContent()) && (doc.getContent().length != 0)
									|| (BaseUtil.isObjNull(doc.getId()) && (doc.getContent().length != 0))) {
								Documents newDoc = getDmService(ProjectEnum.BESTPAY).upload(doc);
								LOGGER.info(PROFILE_PICTURE_DOCMGMTID, newDoc.getId());
								createUserProfile.setDocMgtId(newDoc.getId());
							}
						}
					}

					boolean isUpdated = getIdmService().updateProfile(createUserProfile);

					if (isUpdated) {
						if (BaseUtil.isEqualsCaseIgnore("id", userId)) {
							mav.addAllObjects(PopupBox.success(USR_UPDATE, null,
									messageService.getMessage(MessageConstants.SUCC_UPD_USER),
									PageConstants.PAGE_IDM_USR_UPD_LOGIN));
						} else {
							mav.addAllObjects(PopupBox.success(USR_UPDATE, null,
									messageService.getMessage(MessageConstants.SUCC_UPD_USER),
									PageConstants.PAGE_IDM_USR_LST));
						}
					} else {
						mav.addAllObjects(PopupBox.error(USR_UPDATE, null,
								messageService.getMessage(MessageConstants.ERROR_UPD_USER),
								PageConstants.PAGE_IDM_USR_LST + "/" + userId));
					}
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
					mav.addAllObjects(PopupBox.error(USR_UPDATE, null,
							messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
				} catch (Exception e) {
					mav.addAllObjects(PopupBox.error(USR_UPDATE, null,
							messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
				}
			}
		}

		mav.addObject(IS_ADMIN, hasAnyRole(IdmRoleConstants.ADMIN_ROLES));
		mav.addObject(USER_PROFILE, userProfile);
		mav.addObject(IS_INACTIVE, false);
		mav.addObject(USER_ID, userId);
		mav.addObject(STATUS_LIST, staticData.status(USERSTAT));
		return mav;
	}


	/**
	 * User Profile Update
	 *
	 * @param userId
	 * @param userProfile
	 * @param result
	 * @return
	 * @throws Exception
	 */
	@AuditActionControl(action = AuditActionPolicy.UPDATE_USER)
	@PostMapping(value = "/{userId}", params = "updateProfile")
	public ModelAndView updateProfile(@RequestParam String updateProfile, @PathVariable String userId,
			@Valid @ModelAttribute(USER_PROFILE) IdmUploadProfilePictureForm userProfile, BindingResult result) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_IDM_USR_CRED, USER_MGMT, null);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.cmn.usr.upd"));
		if (!result.hasErrors()) {
			UserProfile pr = getCurrentUser();
			userProfile = dozerMapper.map(userProfile, IdmUploadProfilePictureForm.class);
			if (hasAnyRole(IdmRoleConstants.ADMIN_ROLES)) {
				if (BaseUtil.isObjNull(userProfile.getUserGroupCode())) {
					userProfile.setUserGroupCode(userProfile.getUserRoleGroupCode());
				}
				try {
					UserGroup ug = findAdminRoleGroupCodeByUserGroup(userProfile.getUserGroupCode(),
							getCurrentUser().getUserRoleGroupCode());
					if (ug != null) {
						userProfile.setUserRoleGroupCode(ug.getUserRoleGroupCode());
						userProfile.setUserType(ug.getUserType());
					}
				} catch (IdmException e) {
					if (WebUtil.checkTokenError(e)) {
						throw e;
					}
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
					mav.addAllObjects(WebUtil.checkServiceDown(e));
				} catch (Exception e) {
					mav.addAllObjects(WebUtil.checkServiceDown(e));
					mav.addAllObjects(PopupBox.error(USR_CREATE,
							messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
				}
			} else {
				userProfile.setUserType(BaseUtil.isObjNull(pr) ? "" : pr.getUserType());
			}
			UserProfile createUserProfile = dozerMapper.map(userProfile, UserProfile.class);

			if (BaseUtil.isEqualsCaseIgnore("new", userId)) {
				mav.addObject(AppConstants.PORTAL_TRANS_ID, NEW_USER);
				try {
					createUserProfile = getIdmService().createUser(createUserProfile);
					if (createUserProfile != null) {
						mav.addAllObjects(PopupBox.success(USR_CREATE, null,
								messageService.getMessage(MessageConstants.SUCC_CRE_USER),
								PageConstants.PAGE_IDM_USR_LST));
					} else {
						mav.addAllObjects(PopupBox.error(USR_CREATE, null,
								messageService.getMessage(MessageConstants.ERROR_CRE_USER),
								PageConstants.PAGE_IDM_USR_LST + "/" + userId));
					}
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
					mav.addAllObjects(PopupBox.error(USR_CREATE, null,
							messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
				} catch (Exception e) {
					mav.addAllObjects(PopupBox.error(USR_CREATE, null,
							messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
				}

			} else {
				try {
					if (BaseUtil.isEqualsCaseIgnore("id", userId)) {
						mav.addObject(AppConstants.PORTAL_MODULE, IDM_UPD);
						createUserProfile.setUserId(getCurrentUserId());
					} else {
						mav.addObject(AppConstants.PORTAL_TRANS_ID, UPD_USER);
					}
					Documents doc = new Documents();

					if (!BaseUtil.isListNullZero(userProfile.getFileUploads())
							&& userProfile.getFileUploads().size() == 1) {
						// Profile Picture is only one
						FileUpload fu = userProfile.getFileUploads().get(0);
						com.bestpay.web.dto.CustomMultipartFile file = fu.getFile();
						if (file != null) {
							doc.setContentType(file.getContentType());
							doc.setFilename(file.getFilename());
							doc.setDocid(fu.getDocId());
							if (!BaseUtil.isObjNull(fu.getDocMgtId())) {
								doc.setId(fu.getDocMgtId());
							}
							doc.setLength(file.getSize());
							doc.setRefno(createUserProfile.getUserId());
							doc.setContent(file.getContent());
							if (!BaseUtil.isObjNull(doc.getContent()) && (doc.getContent().length != 0)
									|| (BaseUtil.isObjNull(doc.getId()) && (doc.getContent().length != 0))) {
								Documents newDoc = getDmService(ProjectEnum.BESTPAY).upload(doc);
								LOGGER.info(PROFILE_PICTURE_DOCMGMTID, newDoc.getId());
								createUserProfile.setDocMgtId(newDoc.getId());
							}

						}
					}

					Authentication auth = SecurityContextHolder.getContext().getAuthentication();
					if (auth.isAuthenticated()) {
						CustomUserDetails cud = (CustomUserDetails) auth.getPrincipal();
						UserProfile userProf = cud.getProfile();
						if (!BaseUtil.isObjNull(userProf) && !BaseUtil.isObjNull(doc)) {
							if (BaseUtil.isObjNull(userProf.getProfilePicture())) {
								userProf.setProfilePicture(new com.bestpay.idm.sdk.model.Documents());
							}
							userProf.getProfilePicture()
									.setContentString(Base64.encodeBase64String(doc.getContent()));
							userProf.getProfilePicture().setContentType(doc.getContentType());
							cud.setProfile(userProf);
						}
					}

					boolean isUpdated = getIdmService().updateProfile(createUserProfile);
					if (isUpdated) {
						if (BaseUtil.isEqualsCaseIgnore("id", userId)) {
							mav.addAllObjects(PopupBox.success(USR_UPDATE, null,
									messageService.getMessage(MessageConstants.SUCC_UPD_USER),
									PageConstants.PAGE_IDM_USR_UPD_LOGIN));
						} else {
							mav.addAllObjects(PopupBox.success(USR_UPDATE, null,
									messageService.getMessage(MessageConstants.SUCC_UPD_USER),
									PageConstants.PAGE_IDM_USR_LST));
						}
					} else {
						mav.addAllObjects(PopupBox.error(USR_UPDATE, null,
								messageService.getMessage(MessageConstants.ERROR_UPD_USER),
								PageConstants.PAGE_IDM_USR_LST + "/" + userId));
					}
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
					mav.addAllObjects(PopupBox.error(USR_UPDATE, null,
							messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
				} catch (Exception e) {
					mav.addAllObjects(PopupBox.error(USR_UPDATE, null,
							messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
				}
			}
		}

		mav.addObject(IS_ADMIN, hasAnyRole(IdmRoleConstants.ADMIN_ROLES));
		mav.addObject(USER_PROFILE, userProfile);
		mav.addObject(IS_INACTIVE, false);
		mav.addObject(USER_ID, userId);
		return mav;
	}


	/**
	 * Deactivate User
	 *
	 * @param userId
	 * @param userProfile
	 * @param result
	 * @return
	 * @throws BeException
	 */
	@AuditActionControl(action = AuditActionPolicy.DEACTIVATE_USER)
	@PostMapping(value = "/{userId}", params = "deactivate")
	public ModelAndView deactivate(@RequestParam String deactivate, @PathVariable String userId,
			IdmUploadProfilePictureForm userProfile, BindingResult result) throws BeException {
		LOGGER.info("[Post] User Deactivate: {}", userId);
		ModelAndView mav = viewProfile(userId, userProfile, result);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.cmn.usr.dea"));
		userProfile = (IdmUploadProfilePictureForm) mav.getModelMap().get(USER_PROFILE);

		if (!BaseUtil.isEqualsCaseIgnore("id", userId) && !BaseUtil.isEqualsCaseIgnore("new", userId)
				&& !BaseUtil.isObjNull(userProfile)) {
			try {
				userProfile.setFullName(BaseUtil.getStrUpperWithNull(userProfile.getFullName()));
				userProfile.setStatus(AppConstants.INACTIVE);
				UserProfile userProfileObj = dozerMapper.map(userProfile, UserProfile.class);
				boolean isUpdated = getIdmService().updateProfile(userProfileObj);
				if (isUpdated) {
					mav.addAllObjects(PopupBox.success(USR_UPDATE, null,
							messageService.getMessage(MessageConstants.SUCC_DEACTIVATE_USER),
							PageConstants.PAGE_IDM_USR_LST));
				} else {
					mav.addAllObjects(PopupBox.success(USR_UPDATE, null,
							messageService.getMessage(MessageConstants.ERROR_FAIL_DEACTIVATE_USER),
							PageConstants.PAGE_IDM_USR_LST));
				}
				mav.addObject(IS_INACTIVE, true);
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
				LOGGER.error(IDM_RESPONSE_ERROR, e.getInternalErrorCode(), e.getMessage());
				mav.addAllObjects(PopupBox.error(e.getInternalErrorCode(), e.getMessage()));
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
				mav.addAllObjects(PopupBox.error("userUpdate",
						messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
			}
		}

		return mav;
	}


	/**
	 * Activate User
	 *
	 * @param userId
	 * @param userProfile
	 * @param result
	 * @return
	 * @throws BeException
	 * @throws Exception
	 */
	@AuditActionControl(action = AuditActionPolicy.ACTIVATE_USER)
	@PostMapping(value = "/{userId}", params = "activate")
	public ModelAndView activate(@RequestParam String activate, @PathVariable String userId,
			IdmUploadProfilePictureForm userProfile, BindingResult result) throws BeException {
		LOGGER.info("[Post] User Activate: {}", userId);
		ModelAndView mav = viewProfile(userId, userProfile, result);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.cmn.usr.act"));
		userProfile = (IdmUploadProfilePictureForm) mav.getModelMap().get(USER_PROFILE);

		if (!BaseUtil.isEqualsCaseIgnore("id", userId) && !BaseUtil.isEqualsCaseIgnore("new", userId)
				&& !BaseUtil.isObjNull(userProfile)) {
			try {
				UserProfile userProfileObj = dozerMapper.map(userProfile, UserProfile.class);
				String name = userProfileObj.getFullName();
				if (!BaseUtil.isObjNull(userProfileObj.getProfId())) {
					MerAccInfo merAccInfo = getBeService().getMerchantByProfId(userProfileObj.getProfId());
					userProfileObj.setFullName(merAccInfo.getCompany());
				}
				userProfileObj = getIdmService().activateUser(userProfileObj);
				if (!BaseUtil.isObjNull(userProfileObj.getProfId())) {
					userProfileObj.setFullName(name);
				}
				mav.addAllObjects(PopupBox.success(USR_UPDATE, null,
						messageService.getMessage(MessageConstants.SUCC_ACTIVATE_USER),
						PageConstants.PAGE_IDM_USR_LST));
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
				LOGGER.error(IDM_RESPONSE_ERROR, e.getInternalErrorCode(), e.getMessage());
				mav.addAllObjects(PopupBox.error(e.getInternalErrorCode(), e.getMessage()));
			} catch (Exception e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
				LOGGER.error(e.getMessage());
				mav.addAllObjects(PopupBox.success(USR_UPDATE, null,
						messageService.getMessage(MessageConstants.ERROR_FAIL_ACTIVATE_USER),
						PageConstants.PAGE_IDM_USR_LST));
			}
		}

		return mav;
	}


	/**
	 * Resend User Credentials
	 *
	 * @param userProfile
	 * @param result
	 * @return
	 * @throws BeException
	 * @throws Exception
	 */
	@AuditActionControl(action = AuditActionPolicy.RESEND_CRED)
	@PostMapping(value = "/{userId}", params = "resent")
	public ModelAndView resentCredential(@RequestParam String resent, @PathVariable String userId,
			IdmUploadProfilePictureForm userProfile, BindingResult result) throws BeException {
		LOGGER.info("[Post] Resent User credential: {}", userId);
		ModelAndView mav = viewProfile(userId, userProfile, result);
		userProfile = (IdmUploadProfilePictureForm) mav.getModelMap().get(USER_PROFILE);

		if (!BaseUtil.isEqualsCaseIgnore("id", userId) && !BaseUtil.isEqualsCaseIgnore("new", userId)
				&& !BaseUtil.isObjNull(userProfile)) {
			try {
				UserProfile userProfileObj = dozerMapper.map(userProfile, UserProfile.class);
				String name = userProfileObj.getFullName();
				if (!BaseUtil.isObjNull(userProfileObj.getProfId())) {
					MerAccInfo merAccInfo = getBeService().getMerchantByProfId(userProfileObj.getProfId());
					userProfileObj.setFullName(merAccInfo.getCompany());
				}
				userProfileObj = getIdmService().activateUser(userProfileObj);
				if (!BaseUtil.isObjNull(userProfileObj.getProfId())) {
					userProfileObj.setFullName(name);
				}
				mav.addAllObjects(PopupBox.success(USR_UPDATE, null,
						messageService.getMessage(MessageConstants.SUCC_RESENT_USER_CRE),
						PageConstants.PAGE_IDM_USR_LST));
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
				LOGGER.error(e.getMessage());
			} catch (Exception e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
				mav.addAllObjects(PopupBox.success(USR_UPDATE, null,
						messageService.getMessage(MessageConstants.ERROR_RESENT_USER_CRE),
						PageConstants.PAGE_IDM_USR_LST));
			}
		}

		return mav;
	}


	/**
	 * Reset Password
	 *
	 * @param userId
	 * @param userProfile
	 * @param result
	 * @return
	 * @throws BeException
	 * @throws Exception
	 */
	@AuditActionControl(action = AuditActionPolicy.RESET_PWORD)
	@PostMapping(value = "/{userId}", params = "resetPwd")
	public ModelAndView forgotPword(@RequestParam String resetPwd, @PathVariable String userId,
			@Validated IdmUploadProfilePictureForm userProfile, BindingResult result) throws BeException {
		LOGGER.info("[POST] Reset Password : {}", userId);
		ModelAndView mav = viewProfile(userId, userProfile, result);

		try {
			ForgotPassword forgotPassword = new ForgotPassword();
			forgotPassword.setUserName(userId);
			UserProfile profile = getIdmService().getUserProfileById(userId, false, false);
			if (!BaseUtil.isObjNull(profile) && !BaseUtil.isObjNull(profile.getProfId())) {
				forgotPassword.setName(getBeService().getMerchantByProfId(profile.getProfId()).getCompany());
			}
			getIdmService().forgotPassword(forgotPassword);

			mav.addAllObjects(
					PopupBox.success(null, null, messageService.getMessage(MessageConstants.SUCC_FORGOT_PWORD),
							PageConstants.PAGE_IDM_USR_LST));
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(IDM_RESPONSE_ERROR, e.getInternalErrorCode(), e.getMessage());
			mav.addAllObjects(PopupBox.error(e.getInternalErrorCode(), e.getMessage()));
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			mav.addAllObjects(PopupBox.error(USR_UPDATE, ERROR,
					messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
		}

		return mav;
	}


	private UserGroup findAdminRoleGroupCodeByUserGroup(String userGroup, String userLevel) {
		List<UserGroup> roleGroupCode = findAllUserRoleGroupByGroupCode(userGroup);

		for (UserGroup prUserGroup : roleGroupCode) {
			if (BaseUtil.isEquals(prUserGroup.getParentRoleGroup(), userLevel)) {
				return prUserGroup;
			}
		}
		return null;
	}


	private List<UserGroup> findAllUserRoleGroupByGroupCode(String groupCode) {
		LOGGER.debug("finding all with Id: {}", groupCode);

		String parentRoleGroup = getParentRoleGroup();
		LOGGER.debug("parentRoleGroup: {}", parentRoleGroup);

		List<UserGroup> userGroupList = new ArrayList<>();
		try {
			List<UserGroup> result = getIdmService().findUserGroupByRoleGroupCode(groupCode);
			for (UserGroup userGroup : result) {
				if (BaseUtil.isEquals(userGroup.getParentRoleGroup(), parentRoleGroup)) {
					userGroupList.add(userGroup);
				}
			}
		} catch (IdmException t) {
			LOGGER.error(IDM_EXCEPTION, t.getMessage());
			if (WebUtil.checkTokenError(t)) {
				throw t;
			}
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
		}

		return userGroupList;
	}


	private String getParentRoleGroup() {
		String parentRoleGroup = BaseConstants.EMPTY_STRING;
		UserProfile authUser = getCurrentUser();
		if (!BaseUtil.isObjNull(authUser)) {
			LOGGER.debug("authUser: {}", authUser);
			String userRoleGroup = BaseUtil.getStr(authUser.getUserRoleGroupCode());
			LOGGER.debug("userRoleGroup: {}", userRoleGroup);
			List<UserGroup> userGroups = getIdmService().findUserGroupByRoleGroupCode(userRoleGroup);
			LOGGER.debug("userGroups: {}", userGroups);
			for (UserGroup userGroup : userGroups) {
				if (BaseUtil.isEquals(userGroup.getUserRoleGroupCode(), userRoleGroup)) {
					parentRoleGroup = userGroup.getUserRoleGroupCode();
					break;
				}
			}
		}

		LOGGER.debug("parentRoleGroup: {}", parentRoleGroup);
		return parentRoleGroup;
	}


	@ModelAttribute("userRoleGroupList")
	public List<UserGroup> getUserRoleGroupList() {
		List<UserGroup> userGroupList = new ArrayList<>();
		if (hasAnyRole(IdmRoleConstants.ADMIN_ROLES)) {
			try {
				List<UserGroup> userGroupList1 = getIdmService()
						.findUserGroupByParentRoleGroup(getCurrentUser().getUserRoleGroupCode());

				for (UserGroup group : userGroupList1) {
					if ((BaseUtil.isEqualsCaseIgnore(group.getUserGroupCode(), IdmRoleConstants.ADM_FINANCE)
							|| BaseUtil.isEqualsCaseIgnore(group.getUserGroupCode(), IdmRoleConstants.MER_ADMIN)
							|| BaseUtil.isEqualsCaseIgnore(group.getUserGroupCode(), IdmRoleConstants.ADM_ADMIN)
							|| BaseUtil.isEqualsCaseIgnore(group.getUserGroupCode(),
									IdmRoleConstants.ADM_SUPPORT))
							&& !(getCurrentUser().getUserType().equals("SYSA") && BaseUtil.isEqualsCaseIgnore(
									group.getUserGroupCode(), IdmRoleConstants.MER_ADMIN))) {
						userGroupList.add(group);
					}
				}

			} catch (IdmException e) {
				LOGGER.error(IDM_EXCEPTION, e.getMessage());
				if (WebUtil.checkTokenError(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(EXCEPTION, e.getMessage());
			}
		}
		return userGroupList;
	}


	private int getMaxNoOfUser() {
		int maxNumberOfUser = 0;
		UserProfile authUser = getCurrentUser();
		try {
			List<UserGroup> userGroupList = getIdmService()
					.findUserGroupByRoleGroupCode(authUser.getUserRoleGroupCode());
			for (UserGroup userGroup : userGroupList) {
				if (BaseUtil.isEquals(userGroup.getUserRoleGroupCode(), authUser.getUserRoleGroupCode())) {
					maxNumberOfUser = userGroup.getMaxNoOfUser();
					break;
				}
			}
		} catch (IdmException e) {
			LOGGER.error(IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
		}

		return maxNumberOfUser;
	}


	private int getMaxNoOfUserPerRole(String rolegroupid) {
		int maxNumberOfUser = 0;
		try {
			List<UserGroup> userGroupList = getIdmService().findUserGroupByRoleGroupCode(rolegroupid);
			for (UserGroup userGroup : userGroupList) {
				maxNumberOfUser = userGroup.getMaxNoOfUser();
			}
		} catch (IdmException e) {
			LOGGER.error(IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
		}

		return maxNumberOfUser;
	}


	private String getUserGroupCode(String userRoleGroupCode) {
		List<UserGroup> userGroupList = new ArrayList<>();
		String userGroupCode = BaseConstants.EMPTY_STRING;
		try {
			userGroupList = getIdmService().findUserGroupByRoleGroupCode(userRoleGroupCode);
			for (UserGroup userGroup : userGroupList) {
				if (BaseUtil.isEquals(userGroup.getUserRoleGroupCode(), userRoleGroupCode)) {
					userGroupCode = userGroup.getUserGroupCode();
					break;
				}
			}
		} catch (IdmException e) {
			LOGGER.error(IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
		}

		return userGroupCode;
	}


	private int getMaxNoOfUserPerRoleprofile(String rolegroupid) {
		int maxNumberOfUserprofile = 0;
		try {
			List<UserProfile> userGroupProfile = getIdmService()
					.findUserGroupProfileCountByRoleGroupCode(rolegroupid);
			maxNumberOfUserprofile = userGroupProfile.size();
		} catch (IdmException e) {
			LOGGER.error(IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
		}

		return maxNumberOfUserprofile;
	}


	@ModelAttribute("refDocLst")
	public List<RefDocuments> getRefDocLst() throws BeException {
		return staticData.refDocList(FileUploadConstants.PROFILE_PIC);
	}

}