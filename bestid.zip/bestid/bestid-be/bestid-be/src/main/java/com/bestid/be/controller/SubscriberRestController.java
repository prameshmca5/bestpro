package com.bestid.be.controller;

import java.util.Calendar;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestid.be.constants.TxnCodeConstants;
import com.bestid.be.constants.UriConstants;
import com.bestid.be.model.BidCompany;
import com.bestid.be.sdk.constants.BeErrorCodeEnum;
import com.bestid.be.sdk.exception.BeException;
import com.bestid.be.sdk.model.MessageResponse;
import com.bestid.be.sdk.model.SubscriberInfo;
import com.bestid.be.service.BidCompanyService;
import com.bestid.be.service.BidSubscriberService;
import com.bstsb.util.BaseUtil;

@Lazy
@RestController
public class SubscriberRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(SubscriberRestController.class);

	@Autowired
	private BidSubscriberService bidSubscriberService;

	@Autowired
	private BidCompanyService bidCompanyService;

	/**
	 * Add New Subscriber
	 */
	@PostMapping(value = UriConstants.SUBSCRIBER_ADD, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse addSubscriber(@RequestParam(defaultValue = TxnCodeConstants.SUBSCRIBER_ADD) String trxnNo,
			@RequestBody SubscriberInfo subscriberInfo, HttpServletRequest request) {

		String subscrCd = null;
		String userId = getCurrUserId(request);
		if (BaseUtil.isObjNull(subscriberInfo)) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		if (!BaseUtil.isEqualsCaseIgnore(subscriberInfo.getIndicator(), "edit") && (!BaseUtil.isObjNull(subscriberInfo)
				&& !BaseUtil.isObjNull(subscriberInfo.getSysName()) && subscriberInfo.getSysName().length() >= 3)) {
			subscrCd = genSystemCode(subscriberInfo.getSysName()) + generateRandomNoInStr();
			subscriberInfo.setSubscrCd(subscrCd);

		}

		bidSubscriberService.createSubscriberInfo(subscriberInfo, userId, request);

		return new MessageResponse(new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()),
				BeErrorCodeEnum.E200BST000.getCode(), BeErrorCodeEnum.E200BST000.getMessage(),
				BeErrorCodeEnum.E200BST000.getMessage(), request.getRequestURI(), subscriberInfo);
	}

	public static String generateRandomNoInStr() {
		return BaseUtil.getStr(new Random().nextInt(899) + 100);
	}

	protected String genSystemCode(String name) {
		String sysCode = "";
		name = name.replaceAll("[^\\w]", "");
		LOGGER.info("name.length() ::{}", name.length());

		if (name.length() < 3) {
			name = name + RandomStringUtils.randomAlphabetic(3 - name.length());
		}

		if (name.length() >= 3) {
			int start = 1;
			int end = 2;
			sysCode = name.substring(0, start) + name.substring(name.length() - end);
		} else {
			return null;
		}
		LOGGER.info("sysCode::{}", sysCode);
		return sysCode.toUpperCase();
	}

	@GetMapping(value = UriConstants.SUBSCRIBER_SEARCH_COMPANY, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse searchCompany(@RequestParam String cmpnyRegNo, HttpServletRequest request,
			HttpServletResponse response) {

		if (cmpnyRegNo == null) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);

		}
		BidCompany bc = bidCompanyService.findByCmpnyRegNo(cmpnyRegNo);

		return new MessageResponse(new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()),
				BeErrorCodeEnum.E200BST000.getCode(), BeErrorCodeEnum.E200BST000.getMessage(),
				BeErrorCodeEnum.E200BST000.getMessage(), request.getRequestURI(), bc);
	}

	/**
	 * Subscriber List
	 */
	@PostMapping(value = UriConstants.SUBSCRIBER_LIST, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<SubscriberInfo> subscriberList(
			@RequestParam(defaultValue = TxnCodeConstants.SUBSCRIBER_LIST) String trxnNo,
			@RequestBody SubscriberInfo subscriberInfo, HttpServletRequest request) {

		List<SubscriberInfo> resultList = null;
		resultList = bidSubscriberService.findBySearchCriteria(subscriberInfo);
		if (BaseUtil.isListNull(resultList)) {
			throw new BeException(BeErrorCodeEnum.E404BST004);

		}
		return resultList;
	}

	/**
	 * Subscriber Deactivated
	 */

	@PostMapping(value = UriConstants.SUBSCRIBER_DEACTIVATED, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public Boolean subscriberDeactivated(@RequestBody SubscriberInfo subscriberInfo, HttpServletRequest request) {
		Boolean subscriberDeactivated = Boolean.FALSE;
		String userId = getCurrUserId(request);
		try {
			LOGGER.info("subscriberDeactivated: values {} ", subscriberInfo.getSubscrCd());
			subscriberDeactivated = bidSubscriberService.deactivatedSubscriber(subscriberInfo, userId);
			LOGGER.info("update subscriberDeactivated status:{} ", subscriberDeactivated);
		} catch (Exception e) {
			LOGGER.error("Error while subscriberDeactivated:{} ", e.getMessage());
		}
		return subscriberDeactivated;
	}
}
