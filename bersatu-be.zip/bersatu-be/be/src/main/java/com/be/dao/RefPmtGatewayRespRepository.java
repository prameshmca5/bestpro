/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.RefPmtGatewayResp;


/**
 * @author nurul.naimma
 *
 * @since Apr 19, 2021
 */

@Lazy
@Repository
@RepositoryDefinition(domainClass = RefPmtGatewayResp.class, idClass = Integer.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_PMT_GATEWAY_RESP_DAO)
public interface RefPmtGatewayRespRepository extends GenericRepository<RefPmtGatewayResp> {

}
