package com.bestpay.pgw.sdk.model;

import java.io.Serializable;

public class MerchantInfoDto implements Serializable {
	
	private static final long serialVersionUID = 6645623423283005357L;
	
	private MerchantProfile merchantProfile;
	private MerchantContact merchantContact;
	private String merchantLogo;
	private String state;
	private String country;
	
	public MerchantProfile getMerchantProfile() {
		return merchantProfile;
	}
	public void setMerchantProfile(MerchantProfile merchantProfile) {
		this.merchantProfile = merchantProfile;
	}
	public MerchantContact getMerchantContact() {
		return merchantContact;
	}
	public void setMerchantContact(MerchantContact merchantContact) {
		this.merchantContact = merchantContact;
	}
	
	public String getMerchantLogo() {
		return merchantLogo;
	}
	
	public void setMerchantLogo(String merchantLogo) {
		this.merchantLogo = merchantLogo;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	

}
