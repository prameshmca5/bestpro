/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.sdk.model.TransactionRptInfo;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.report.sdk.constants.ReportTypeEnum;
import com.bestpay.report.sdk.model.Report;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ReportUtil;
import com.bestpay.web.util.WebUtil;
import com.google.gson.Gson;


/**
 * @author Afif Saman
 * @since June 21, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_DT_RNG_RPT)
public class DateRangeReportController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(DateRangeReportController.class);

	private static final String ADDFIELD = "addField";

	private static final String FROM_DATE = "fromDate";

	private static final String STATUS = "status";

	private static final String TO_DATE = "toDate";


	@GetMapping
	public ModelAndView view(@ModelAttribute("transRptInfo") TransactionRptInfo transRptInfo, BindingResult result,
			HttpSession session) throws BeException {
		// Removing session attributes if any
		session.removeAttribute(FROM_DATE);
		session.removeAttribute(TO_DATE);
		session.removeAttribute(STATUS);
		session.removeAttribute(ADDFIELD);

		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_DT_RNG_RPT, "report", null, "date-range-report-script");
		List<Status> status = staticData.status("TRANSTAT");
		mav.addObject("statusList", status);
		return mav;
	}


	@PostMapping(params = "search")
	public ModelAndView search(@ModelAttribute("transRptInfo") TransactionRptInfo transRptInfo, BindingResult result,
			HttpServletRequest request, HttpSession session) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_DT_RNG_RPT, "report", null, "date-range-report-script");
		// Set session attributes
		session.setAttribute(FROM_DATE, transRptInfo.getFromDate());
		session.setAttribute(TO_DATE, transRptInfo.getToDate());
		session.setAttribute(STATUS, transRptInfo.getStatus());
		session.setAttribute(ADDFIELD, transRptInfo.getAddField());

		List<Status> status = staticData.status("TRANSTAT");
		mav.addObject("transRptInfo", transRptInfo);
		mav.addObject("statusList", status);
		return mav;
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String getTransactionRptInfoPaginated(
			@ModelAttribute("transRptInfo") TransactionRptInfo transRptInfo, BindingResult result,
			HttpServletRequest request) {
		LOGGER.info("GET PAGINATED DATE RANGE REPORT LIST....");
		UserProfile authUser = getCurrentUser();
		LOGGER.info("User ID = {}", authUser);
		DataTableResults<TransactionRptInfo> reports = null;
		try {
			reports = getBeService().searchTransactionReport(transRptInfo, getPaginationRequest(request, true));
		} catch (Exception e) {
			if (WebUtil.checkSystemDown(e)) {
				LOGGER.error(e.getMessage());
			}
			LOGGER.error(e.getMessage());
		}

		return new Gson().toJson(reports);
	}


	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute("transRptInfo") @Validated TransactionRptInfo transRptInfo,
			BindingResult result, HttpServletRequest request, HttpSession session) throws BeException {
		TransactionRptInfo transactionRptInfo = new TransactionRptInfo();
		return view(transactionRptInfo, result, session);
	}


	@GetMapping(value = "print/genDateRangeReport")
	public @ResponseBody Report genDateRangeTransReport(
			@ModelAttribute("transactionRptInfo") TransactionRptInfo transactionRptInfo,
			@RequestParam(value = FROM_DATE, required = false) String fromDate,
			@RequestParam(value = TO_DATE, required = false) String toDate,
			@RequestParam(value = STATUS, required = false) String status,
			@RequestParam(value = ADDFIELD, required = false) String addField, BindingResult result,
			HttpServletRequest request, HttpSession session) {

		LOGGER.info("fromDate = {}", fromDate);
		LOGGER.info("toDate = {}", toDate);
		LOGGER.info("status = {}", status);
		LOGGER.info("addField = {}", addField);
		Report report = null;
		try {
			report = getReportService().genDateRangeRpt(fromDate, toDate, status, addField, ReportTypeEnum.PDF, true,
					0);
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.debug("Error export to pdf {}", e);
		}
		return report;
	}


	@GetMapping(value = "print/dateRangeCsvReport.xls")
	public @ResponseBody ResponseEntity<byte[]> genCSVDataReport(
			@ModelAttribute("transactionRptInfo") TransactionRptInfo transactionRptInfo, BindingResult result,
			HttpServletRequest request, HttpSession session) {

		Date fromDate = (Date) request.getSession(true).getAttribute(FROM_DATE);
		Date toDate = (Date) request.getSession(true).getAttribute(TO_DATE);
		String status = (String) request.getSession(true).getAttribute(STATUS);
		String addField = (String) request.getSession(true).getAttribute(ADDFIELD);
		DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String frmDt = !BaseUtil.isObjNull(fromDate) ? sdf.format(fromDate) : "";
		String toDt = !BaseUtil.isObjNull(toDate) ? sdf.format(toDate) : "";

		if (!StringUtils.hasText(status)) {
			status = "";
		}
		if (!StringUtils.hasText(addField)) {
			addField = "";
		}

		try {
			Report report = getReportService().genDateRangeRpt(frmDt, toDt, status, addField, ReportTypeEnum.CSV,
					true, 0);

			if (!BaseUtil.isObjNull(report)) {
				byte[] fb = report.getReportBytes();
				return new ResponseEntity<>(fb, ReportUtil.getHttpHeadersCSV("DateRangeReport", fb.length),
						HttpStatus.OK);
			}

		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.debug("Error export to csv {}", e);
		}
		return null;
	}

}