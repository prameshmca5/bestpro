package com.bestpay.be.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * @author Venugopal Kasalanati
 * @since June 26, 2018
 */
@Entity
@Table(name = "PGW_MERCHANT_COMPANY")
public class PgwMerchantCompany extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "COMP_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer companyId;

	@Column(name = "COMP_REF_ID")
	private String compRefId;

	@Column(name = "COMP_NAME")
	private String companyName;

	@Column(name = "COMP_ADDRESS_1")
	private String address1;

	@Column(name = "COMP_ADDRESS_2")
	private String address2;

	@Column(name = "COMP_ADDRESS_3")
	private String address3;

	@Column(name = "COMP_POSTCODE")
	private String postcode;

	@Column(name = "COMP_CITY")
	private String city;

	@Column(name = "COMP_STATE")
	private String state;

	@Column(name = "COMP_COUNTRY")
	private String country;

	@Column(name = "COMP_EMAIL")
	private String email;

	@Column(name = "COMP_PHONE")
	private String phone;

	@Column(name = "COMP_PIC_NAME")
	private String picName;

	@Column(name = "COMP_PIC_EMAIL")
	private String picEmail;

	@Column(name = "COMP_PIC_PHONE")
	private String picPhone;

	@Column(name = "COMP_CALLBACK_URL")
	private String callbackUrl;

	@Column(name = "COMP_RELATIONSHIP")
	private String relationship;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getCompanyId() {
		return companyId;
	}


	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}


	public String getCompRefId() {
		return compRefId;
	}


	public void setCompRefId(String compRefId) {
		this.compRefId = compRefId;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public String getAddress1() {
		return address1;
	}


	public void setAddress1(String address1) {
		this.address1 = address1;
	}


	public String getAddress2() {
		return address2;
	}


	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	public String getAddress3() {
		return address3;
	}


	public void setAddress3(String address3) {
		this.address3 = address3;
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getPicName() {
		return picName;
	}


	public void setPicName(String picName) {
		this.picName = picName;
	}


	public String getPicEmail() {
		return picEmail;
	}


	public void setPicEmail(String picEmail) {
		this.picEmail = picEmail;
	}


	public String getPicPhone() {
		return picPhone;
	}


	public void setPicPhone(String picPhone) {
		this.picPhone = picPhone;
	}


	public String getCallbackUrl() {
		return callbackUrl;
	}


	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}


	public String getRelationship() {
		return relationship;
	}


	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getCreateId() {
		return null;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}

}
