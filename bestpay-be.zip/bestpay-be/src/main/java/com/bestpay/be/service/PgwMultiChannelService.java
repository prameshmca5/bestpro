/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwMultiChannelRepository;
import com.bestpay.be.model.PgwMultiChannel;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Afif Saman
 * @since July 11, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_MUL_CHAN_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MUL_CHAN_SVC)
public class PgwMultiChannelService extends AbstractService<PgwMultiChannel> {

	@Autowired
	private PgwMultiChannelRepository multiChannelDao;


	@Override
	public PgwMultiChannelRepository primaryDao() {
		return multiChannelDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwMultiChannel> findMultiChannelByMerchantId(String merchantId) {
		return multiChannelDao.findMultiChannelByMerchantId(merchantId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMultiChannel findActiveMultiChannelByMerIdAndChannel(String merchantId, String channel) {
		return multiChannelDao.findActiveMultiChannelByMerIdAndChannel(merchantId, channel, "A");
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwMultiChannel> findMultiChannelByMerchantIdAndStatus(String merchantId) {
		return multiChannelDao.findMultiChannelByMerchantIdAndStatus(merchantId);
	}
}