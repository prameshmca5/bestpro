/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.constants;

/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public enum PgwErrorCodeEnum {

	E503APJ000(503,"PGW service at {0} unreachable"),
	E503APJ001(503,"IDM service at {0} unreachable"),
	E503APJ002(503,"Merchant service URL at {0} unreachable"),
	E408APJ002(408,"Request timed out connecting to IDM after <response time>/<timeout duration>"),
	E500APJ003(500,"Exception thrown from IDM service. {0}"),
	E500APJ004(504,"Exception thrown from SST service. {0}"),
	E503APJ004(503,"Mongo service at {0} unreachable"),
	E408APJ005(408,"Request timed out connecting to Mongo after <response time>/<timeout duration>"),
	E500APJ006(500,"MongoException occured. {0}"),
	E404APJ007(404,"Cache service at {0} unreachable"),
	E408APJ008(408,"Request timed out connecting to Cache service after <response time>/<timeout duration>"),
	E500APJ009(500,"Exception thrown from Cache service. {0}"),
	E500APJ010(500,"Document Upload failed."),
	E500APJ011(500,"Bank Statement Upload failed."),
	E400IDM913(400, "Invalid Request Body"),
	E400APJ011(400, "X-Message-Id Header is missing"),
	E400APJ012(400, "Authorization Header is missing"),
	E400APJ013(400, "Invalid Request Body"),
	E400APJ014(400, "Bad Request"),
	E400APJ015(400, "{0} is required."),
	E400APJ016(400, "Invalid Date Format {0}."),
	I404APJ109(405, "The record doesn't exists"),
	I404APJ110(405, "The record already exists"),
	I404APJ111(405, "Payment Transaction already exists."),
	E404APJ008(404, "Creation failed."),
	E404APJ009(404, "Relation {0} not found"),
	E400APJ246(400, "Missing value for compulsary fields {0}"),
	E409CMN914(409, "Relation {0} already exist"),
	E409APJ917(410, "KTP / National ID Already Exists"),
	E400PGW011(400, "Error while generating FPX Request"),
	E400PGW012(400, "Mechant not found with Id {0}"),
	E404PGW111(405, "Payment Transaction details not available"),
	E404PGW112(405, "No transaction available with OrderID {0} and TransId {1}"),
	E404PGW113(405, "Transaction details required to create"),
	E404PGW114(405, "Audit details required, can not accept empty"),
	E404PGW115(405, "No transaction available with OrderID {0} and Merchant {1}"),
	E404PGW116(405, "Document Not Found."),
	E404PGW117(405, "merchantLogo Not Found."),
	;
	
	private final int code;
	private final String message;
	
	PgwErrorCodeEnum(int code, String message) {
		this.code = code;
		this.message =  message;
	}

	public static PgwErrorCodeEnum findByName(String name){
	    for(PgwErrorCodeEnum v : PgwErrorCodeEnum.values()){
	        if(v.name().equals(name)){
	            return v;
	        }
	    }
	    
	    return null;
	}
	
	public static int findInternalCode(String name) {
		for(PgwErrorCodeEnum v : PgwErrorCodeEnum.values()){
	        if(v.name().equals(name)){
	            return v.getCode();
	        }
	    }
	    
	    return 0;
	}

	public String getMessage() {
		return message;
	}
	
	public int getCode() {
		return code;
	}
}
