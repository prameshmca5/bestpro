/**
  * Copyright 2019
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;


/**
 * The persistent class for the BE_PRE_REG database table.
 *
 * @author Naem Othman
 * @since March 31, 2020
 */
@Entity
@Table(name = "BE_PRE_REG")
public class BePreReg extends AbstractEntity implements Serializable, IQfCriteria<BePreReg> {

	private static final long serialVersionUID = 6016032592885161865L;

	@Id
	@Column(name = "PRE_REG_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer preRegId;

	@Column(name = "TXN_ID")
	private String txnId;

	@Column(name = "APP_REF_NO")
	private String appRefNo;

	@Column(name = "FULL_NAME")
	private String fullName;

	@Column(name = "ID_NO")
	private String idNo;

	@Column(name = "GENDER_MTDT_ID")
	private Integer genderMtdtId;

	@Column(name = "RELIGION_MTDT_ID")
	private Integer religionMtdtId;

	@Temporal(TemporalType.DATE)
	@Column(name = "DOB")
	private Date dob;

	@Column(name = "ETHNIC_MTDT_ID")
	private Integer ethnicMtdtId;

	@Column(name = "CONTACT_NO")
	private String contactNo;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "POSITION_ID")
	private Integer positionId;

	@Column(name = "EDU_MTDT_ID")
	private Integer eduMtdtId;

	@Column(name = "EDU_DESC")
	private String eduDesc;

	@Column(name = "OCCUPATION_MTDT_ID")
	private Integer occupationMtdtId;

	@Column(name = "ORG_STATE_CD")
	private String orgStateCd;

	@Column(name = "ORG_DIVISION_CD")
	private String orgDivisionCd;

	@Column(name = "ORG_BRANCH_CD")
	private String orgBranchCd;

	@Column(name = "VOTER_REG_MTDT_ID")
	private Integer voterRegMtdtId;

	@Column(name = "DOC_REF_NO")
	private String docRefNo;

	@Column(name = "SPR_STATE_CD")
	private String sprStateCd;

	@Column(name = "PARLIAMENT_CODE")
	private String parliamentCode;

	@Column(name = "DUN_CODE")
	private String dunCode;

	@Column(name = "MEMBER_CTGRY_MTDT_ID")
	private Integer memberCtrgyMtdtId;

	@Column(name = "MEMBER_TYPE_MTDT_ID")
	private Integer memberTypeMtdtId;

	@Column(name = "PASSCODE")
	private String passcode;

	@Column(name = "STATUS_ID")
	private Integer statusId;

	@OneToOne
	@JoinColumn(name = "STATUS_ID", insertable = false, updatable = false)
	private RefStatus status;

	@Column(name = "CHANNEL_MTDT_ID")
	private Integer channelMtdtId;

	@Column(name = "APPLY_BY")
	private String applyBy;

	@Column(name = "APPLY_DT")
	private Timestamp applyDt;

	@Column(name = "APPLY_REMARKS")
	private String applyRemarks;

	@Column(name = "APPROVE_BY")
	private String approveBy;

	// @Temporal(TemporalType.DATE)
	@Column(name = "APPROVE_DT")
	private Timestamp approveDt;

	@Column(name = "APPROVE_REMARKS")
	private String approveRemarks;

	@Column(name = "HQ_IND")
	private Integer hqInd;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@OneToMany(mappedBy = "preReg", cascade = { CascadeType.ALL })
	private List<BePreRegAddress> preRegAddressList;

	@OneToMany()
	@JoinColumn(name = "DOC_REF_NO", referencedColumnName = "DOC_REF_NO", insertable = false, updatable = false)
	private List<BeTrxnDocument> trxnDocumentsList;

	@Transient
	private BePayment payment;


	public Integer getPreRegId() {
		return preRegId;
	}


	public void setPreRegId(Integer preRegId) {
		this.preRegId = preRegId;
	}


	public String getTxnId() {
		return txnId;
	}


	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName.toUpperCase();
	}


	public String getIdNo() {
		return idNo;
	}


	public void setIdNo(String idNo) {
		this.idNo = idNo.toUpperCase();
	}


	public Integer getGenderMtdtId() {
		return genderMtdtId;
	}


	public void setGenderMtdtId(Integer genderMtdtId) {
		this.genderMtdtId = genderMtdtId;
	}


	public Integer getReligionMtdtId() {
		return religionMtdtId;
	}


	public void setReligionMtdtId(Integer religionMtdtId) {
		this.religionMtdtId = religionMtdtId;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public Integer getEthnicMtdtId() {
		return ethnicMtdtId;
	}


	public void setEthnicMtdtId(Integer ethnicMtdtId) {
		this.ethnicMtdtId = ethnicMtdtId;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Integer getEduMtdtId() {
		return eduMtdtId;
	}


	public void setEduMtdtId(Integer eduMtdtId) {
		this.eduMtdtId = eduMtdtId;
	}


	public String getEduDesc() {
		return eduDesc;
	}


	public void setEduDesc(String eduDesc) {
		this.eduDesc = eduDesc.toUpperCase();
	}


	public Integer getOccupationMtdtId() {
		return occupationMtdtId;
	}


	public void setOccupationMtdtId(Integer occupationMtdtId) {
		this.occupationMtdtId = occupationMtdtId;
	}


	public String getOrgStateCd() {
		return orgStateCd;
	}


	public void setOrgStateCd(String orgStateCd) {
		this.orgStateCd = orgStateCd;
	}


	public String getOrgDivisionCd() {
		return orgDivisionCd;
	}


	public void setOrgDivisionCd(String orgDivisionCd) {
		this.orgDivisionCd = orgDivisionCd;
	}


	public String getOrgBranchCd() {
		return orgBranchCd;
	}


	public void setOrgBranchCd(String orgBranchCd) {
		this.orgBranchCd = orgBranchCd;
	}


	public Integer getVoterRegMtdtId() {
		return voterRegMtdtId;
	}


	public void setVoterRegMtdtId(Integer voterRegMtdtId) {
		this.voterRegMtdtId = voterRegMtdtId;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public String getPasscode() {
		return passcode;
	}


	public void setPasscode(String passcode) {
		this.passcode = passcode;
	}


	public Integer getStatusId() {
		return statusId;
	}


	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}


	public Integer getChannelMtdtId() {
		return channelMtdtId;
	}


	public void setChannelMtdtId(Integer channelMtdtId) {
		this.channelMtdtId = channelMtdtId;
	}


	public String getApplyBy() {
		return applyBy;
	}


	public void setApplyBy(String applyBy) {
		this.applyBy = applyBy.toUpperCase();
	}


	public Timestamp getApplyDt() {
		return applyDt;
	}


	public void setApplyDt(Timestamp applyDt) {
		this.applyDt = applyDt;
	}


	public String getApplyRemarks() {
		return applyRemarks;
	}


	public void setApplyRemarks(String applyRemarks) {
		this.applyRemarks = applyRemarks.toUpperCase();
	}


	public String getApproveBy() {
		return approveBy;
	}


	public void setApproveBy(String approveBy) {
		this.approveBy = approveBy.toUpperCase();
	}


	public Timestamp getApproveDt() {
		return approveDt;
	}


	public void setApproveDt(Timestamp approveDt) {
		this.approveDt = approveDt;
	}


	public String getApproveRemarks() {
		return approveRemarks;
	}


	public void setApproveRemarks(String approveRemarks) {
		this.approveRemarks = approveRemarks.toUpperCase();
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public List<BePreRegAddress> getPreRegAddressList() {
		return preRegAddressList;
	}


	public void setPreRegAddressList(List<BePreRegAddress> preRegAddressList) {
		this.preRegAddressList = preRegAddressList;
	}


	public List<BeTrxnDocument> getTrxnDocumentsList() {
		return trxnDocumentsList;
	}


	public void setTrxnDocumentsList(List<BeTrxnDocument> trxnDocumentsList) {
		this.trxnDocumentsList = trxnDocumentsList;
	}


	public String getAppRefNo() {
		return appRefNo;
	}


	public void setAppRefNo(String appRefNo) {
		this.appRefNo = appRefNo;
	}


	public RefStatus getStatus() {
		return status;
	}


	public void setStatus(RefStatus status) {
		this.status = status;
	}


	public String getParliamentCode() {
		return parliamentCode;
	}


	public void setParliamentCode(String parliamentCode) {
		this.parliamentCode = parliamentCode;
	}


	public String getDunCode() {
		return dunCode;
	}


	public void setDunCode(String dunCode) {
		this.dunCode = dunCode;
	}


	public Integer getMemberCtrgyMtdtId() {
		return memberCtrgyMtdtId;
	}


	public void setMemberCtrgyMtdtId(Integer memberCtrgyMtdtId) {
		this.memberCtrgyMtdtId = memberCtrgyMtdtId;
	}


	public Integer getMemberTypeMtdtId() {
		return memberTypeMtdtId;
	}


	public void setMemberTypeMtdtId(Integer memberTypeMtdtId) {
		this.memberTypeMtdtId = memberTypeMtdtId;
	}


	public void addBePreRegAddressList(List<BePreRegAddress> bePreRegAddressList) {
		bePreRegAddressList.forEach(address -> {
			address.setPreReg(this);
		});

		setPreRegAddressList(bePreRegAddressList);
	}


	public BePayment getPayment() {
		return payment;
	}


	public void setPayment(BePayment payment) {
		this.payment = payment;
	}


	/**
	 * @return the positionId
	 */
	public Integer getPositionId() {
		return positionId;
	}


	/**
	 * @param positionId
	 *             the positionId to set
	 */
	public void setPositionId(Integer positionId) {
		this.positionId = positionId;
	}


	/**
	 * @return the sprStateCd
	 */
	public String getSprStateCd() {
		return sprStateCd;
	}


	/**
	 * @param sprStateCd
	 *             the sprStateCd to set
	 */
	public void setSprStateCd(String sprStateCd) {
		this.sprStateCd = sprStateCd;
	}


	/**
	 * @return the hqInd
	 */
	public Integer getHqInd() {
		return hqInd;
	}


	/**
	 * @param hqInd
	 *             the hqInd to set
	 */
	public void setHqInd(Integer hqInd) {
		this.hqInd = hqInd;
	}

}