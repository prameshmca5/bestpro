/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;


/**
 * @author Ramesh Pongiannan
 *
 */
@Entity
@Table(name = "REF_PARLIAMENT")
public class RefParliament extends AbstractEntity implements Serializable, IQfCriteria<RefParliament> {

	private static final long serialVersionUID = 5466589728737397061L;

	@Id
	@Column(name = "PARLIAMENT_CD")
	private String parliamentCd;

	@Column(name = "PARLIAMENT_DESC")
	private String parliamentDesc;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "STATE_CD", insertable = false, updatable = false)
	private RefState state;

	@Column(name = "STATE_CD")
	private String stateCd;
	
	@Column(name = "DIVISION_CD")
	private String divisionCd;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;


	public String getParliamentCd() {
		return parliamentCd;
	}


	public void setParliamentCd(String parliamentCd) {
		this.parliamentCd = parliamentCd;
	}


	public String getParliamentDesc() {
		return parliamentDesc;
	}


	public void setParliamentDesc(String parliamentDesc) {
		this.parliamentDesc = parliamentDesc;
	}


	public String getStateCd() {
		return stateCd;
	}


	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}


	public RefState getState() {
		return state;
	}


	public void setState(RefState state) {
		this.state = state;
	}


	public String getDivisionCd() {
		return divisionCd;
	}


	public void setDivisionCd(String divisionCd) {
		this.divisionCd = divisionCd;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
