/**
  * Copyright 2019
 */
package com.be.sdk.model;


import java.io.Serializable;


/**
 *
 * @author Naem Othman
 * @since March 31, 2020
 */
public class Watchlist implements Serializable, IQfCriteria<Watchlist> {

	/**
	 *
	 */
	private static final long serialVersionUID = 4561247819680906727L;

	private Integer watchId;

	private String idNo;

	private String source;

	private Boolean status;

	private String contactNo;


	public Integer getWatchId() {
		return watchId;
	}


	public void setWatchId(Integer watchId) {
		this.watchId = watchId;
	}


	public String getIdNo() {
		return idNo;
	}


	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public Boolean getStatus() {
		return status;
	}


	public void setStatus(Boolean status) {
		this.status = status;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

}