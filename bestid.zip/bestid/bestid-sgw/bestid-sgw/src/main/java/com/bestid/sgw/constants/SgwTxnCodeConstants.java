/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.sgw.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
public class SgwTxnCodeConstants {

	private SgwTxnCodeConstants() {
		throw new IllegalStateException("Constants class");
	}


	public static final String HEADER_MESSAGE_ID = "X-Message-Id";

	public static final String HEADER_AUTHORIZATION = "Authorization";

	public static final String SEC_REGISTER_CERT = "SEC_REGISTER_CERT";

	public static final String SEC_STORE_CERT = "SEC_STORE_CERT";

	public static final String SEC_SUBMIT_CERT = "SEC_SUBMIT_CERT";

	public static final String SEC_REVOKE_CERT = "SEC_REVOKE_CERT";

	public static final String SGW_GENERATE_QR_CODE = "SGW_GENERATE_QR_CODE";

	public static final String MOBILE_LOGIN = "MOBILE_LOGIN";

	public static final String MOBILE_LOGOUT = "MOBILE_LOGOUT";

	public static final String SGW_SEARCH_DEVICE = "SGW_SEARCH_DEVICE";

	public static final String SGW_SEARCH_USER = "SGW_SEARCH_USER";

	public static final String SGW_REGISTER_USER = "SGW_REGISTER_USER";
	
	public static final String SGW_REGISTER_PROFILE = "SGW_REGISTER_PROFILE";

	public static final String SGW_UPDATE_CONTACT = "SGW_UPDATE_CONTACT";

	public static final String SGW_GEN_ACTIVATION_CODE = "SGW_GEN_ACTIVATION_CODE";

	public static final String SGW_VERIFY_ACTIVATION_CODE = "SGW_VERIFY_ACTIVATION_CODE";

	public static final String SGW_VERIFY_QR_CODE = "SGW_VERIFY_QR_CODE";

	public static final String SGW_VERIFY_PHOTO = "SGW_VERIFY_PHOTO";

	public static final String SEC_FACE_SEARCH = "SEC_FACE_SEARCH";

	public static final String SEC_PINCODE_VERIFY = "SEC_PINCODE_VERIFY";

	public static final String SEC_PINCODE_UPDATE = "SEC_PINCODE_UPDATE";

	public static final String SEC_INVITATION_CODE_GENERATE = "SEC_INVITATION_CODE_GENERATE";

	public static final String SEC_INVITATION_CODE_VERIFY = "SEC_INVITATION_CODE_VERIFY";

	public static final String SEC_PROFILE_SEARCH = "SEC_PROFILE_SEARCH";
	
    public static final String SGW_VERIFY_AUTH = "SGW_VERIFY_AUTH";
	
	public static final String SGW_VERIFY_DIGITALID = "SGW_VERIFY_DIGITALID";
	
	public static final String SGW_DIGITALID_STATUS_CHECK = "SGW_DIGITALID_STATUS_CHECK";

}