/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;


/**
 * @author Atiqah Khairuddin
 * @since Sept 14, 2018
 */
public class MerSubscriptionPlan implements Serializable {

	private static final long serialVersionUID = 607657392585361232L;

	private Integer merSubId;

	private String merchantId;

	private Integer subPlanId;

	private Date expiryDate;

	private String status;

	private String createId;

	private Timestamp createDt;

	private String updateId;

	private Timestamp updateDt;

	private String userId;


	public Integer getMerSubId() {
		return merSubId;
	}


	public void setMerSubId(Integer merSubId) {
		this.merSubId = merSubId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public Integer getSubPlanId() {
		return subPlanId;
	}


	public void setSubPlanId(Integer subPlanId) {
		this.subPlanId = subPlanId;
	}


	public Date getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}

}