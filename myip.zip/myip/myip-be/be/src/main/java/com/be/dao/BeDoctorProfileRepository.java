/**
 * 
 */
package com.be.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.BeDoctorProfile;

/**
 * @author michelle.angela
 *
 */
@Lazy
@Repository
@RepositoryDefinition(domainClass = BeDoctorProfile.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_DOCTOR_PROFILE_DAO)
public interface BeDoctorProfileRepository extends GenericRepository<BeDoctorProfile> {

	@Query("select u from BeDoctorProfile u where u.beMcProfile.mcProfId = :mcProfId ")
	public List<BeDoctorProfile> findByMcProfId(@Param("mcProfId") Integer mcProfId);
	
	@Query("select u from BeDoctorProfile u where u.email = :email ")
	public BeDoctorProfile findByEmail(@Param("email") String email);
}
