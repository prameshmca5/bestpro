/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.model.PgwSettlement;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.SettlementRptInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;


/**
 * @author Afif Saman
 * @since June 6, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.STTLMNT_REPORT)
public class SttlmntReportRestController extends AbstractRestController {

	/**
	 * Search Settlement Report by pagination
	 *
	 * @param settlementRptInfo
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */

	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<SettlementRptInfo> searchSettlementReportPaginated(
			@Valid @RequestBody SettlementRptInfo settlementRptInfo, HttpServletRequest request) {
		PgwMerchantProfile pgwMerchantProfile = new PgwMerchantProfile();
		if (!BaseUtil.isObjNull(settlementRptInfo.getMerProfId())) {
			pgwMerchantProfile = pgwMerchantProfileService.findByMerchantProfileId(settlementRptInfo.getMerProfId());
		}
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwSettlement> result = pgwSettlementService.searchSettlementReport(settlementRptInfo,
				dataTableInRQ, pgwMerchantProfile);
		DataTableResults<SettlementRptInfo> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<SettlementRptInfo> bpLst = new ArrayList<>();
				for (PgwSettlement bbp : result.getData()) {
					SettlementRptInfo trustee = dozerMapper.map(bbp, SettlementRptInfo.class);
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		return dataTableInResp;
	}


	/**
	 * Search Remittance Settlement Report by pagination
	 *
	 * @param settlementRptInfo
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@PostMapping(value = BeUrlConstants.SET_RPT_PAGINATED_BY_REMIT, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DataTableResults<SettlementRptInfo> searchRemittanceSettlementReportPaginated(
			@Valid @RequestBody SettlementRptInfo settlementRptInfo, HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwSettlement> result = pgwSettlementService.searchRemitSettlementReport(settlementRptInfo,
				dataTableInRQ);
		DataTableResults<SettlementRptInfo> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<SettlementRptInfo> bpLst = new ArrayList<>();
				for (PgwSettlement bbp : result.getData()) {
					SettlementRptInfo trustee = dozerMapper.map(bbp, SettlementRptInfo.class);
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		return dataTableInResp;
	}


	@PostMapping(value = BeUrlConstants.SETTLEMENT_RPT_INFO, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<SettlementRptInfo> findSettleRptInfo(@Valid @RequestBody SettlementRptInfo settlementRptInfo,
			HttpServletRequest request) {
		PgwMerchantProfile pgwMerchantProfile = new PgwMerchantProfile();
		if (!BaseUtil.isObjNull(settlementRptInfo.getMerProfId())) {
			pgwMerchantProfile = pgwMerchantProfileService.findByMerchantProfileId(settlementRptInfo.getMerProfId());
		}
		List<SettlementRptInfo> settlementList = new ArrayList<>();
		List<PgwSettlement> pgwSettlement = pgwSettlementService.loadSettleRptInfo(settlementRptInfo,
				pgwMerchantProfile);
		if (!CollectionUtils.isEmpty(pgwSettlement)) {
			for (PgwSettlement info : pgwSettlement) {
				SettlementRptInfo trustee = dozerMapper.map(info, SettlementRptInfo.class);
				settlementList.add(trustee);
			}
		}

		return settlementList;
	}


	@PostMapping(value = BeUrlConstants.REMIT_SETTLEMENT_RPT_INFO, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<SettlementRptInfo> findRemitSettleRptInfo(@Valid @RequestBody SettlementRptInfo settlementRptInfo,
			HttpServletRequest request) {
		List<SettlementRptInfo> settlementList = new ArrayList<>();
		List<PgwSettlement> pgwSettlement = pgwSettlementService.loadRemitSettleRptInfo(settlementRptInfo);
		if (!CollectionUtils.isEmpty(pgwSettlement)) {
			for (PgwSettlement info : pgwSettlement) {
				SettlementRptInfo trustee = dozerMapper.map(info, SettlementRptInfo.class);
				settlementList.add(trustee);
			}
		}

		return settlementList;
	}

}
