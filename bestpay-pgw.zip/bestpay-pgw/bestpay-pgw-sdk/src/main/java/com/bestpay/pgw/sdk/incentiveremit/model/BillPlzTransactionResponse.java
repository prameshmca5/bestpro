package com.bestpay.pgw.sdk.incentiveremit.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id", "collection_id", "paid", "state", "amount", "paid_amount", "due_at", "email", "mobile",
		"name", "url", "reference_1_label", "reference_1", "reference_2_label", "reference_2", "redirect_url",
		"callback_url", "description", "paid_at" })
public class BillPlzTransactionResponse {

	@JsonProperty("id")
	private String id;

	@JsonProperty("collection_id")
	private String collectionId;

	@JsonProperty("paid")
	private String paid;

	@JsonProperty("state")
	private String state;

	@JsonProperty("amount")
	private String amount;

	@JsonProperty("paid_amount")
	private String paidAmount;

	@JsonProperty("due_at")
	private String dueAt;

	@JsonProperty("email")
	private String email;

	@JsonProperty("mobile")
	private String mobile;

	@JsonProperty("name")
	private String name;

	@JsonProperty("url")
	private String url;

	@JsonProperty("reference_1_label")
	private String reference1Label;

	@JsonProperty("reference_1")
	private String reference1;

	@JsonProperty("reference_2_label")
	private String reference2Label;

	@JsonProperty("reference_2")
	private String reference2;

	@JsonProperty("redirect_url")
	private String redirectUrl;

	@JsonProperty("callback_url")
	private String callbackUrl;

	@JsonProperty("description")
	private String description;

	@JsonProperty("paid_at")
	private String paidAt;


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getCollectionId() {
		return collectionId;
	}


	public void setCollectionId(String collectionId) {
		this.collectionId = collectionId;
	}


	public String getPaid() {
		return paid;
	}


	public void setPaid(String paid) {
		this.paid = paid;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getAmount() {
		return amount;
	}


	public void setAmount(String amount) {
		this.amount = amount;
	}


	public String getPaidAmount() {
		return paidAmount;
	}


	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}


	public String getDueAt() {
		return dueAt;
	}


	public void setDueAt(String dueAt) {
		this.dueAt = dueAt;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public String getReference1Label() {
		return reference1Label;
	}


	public void setReference1Label(String reference1Label) {
		this.reference1Label = reference1Label;
	}


	public String getReference1() {
		return reference1;
	}


	public void setReference1(String reference1) {
		this.reference1 = reference1;
	}


	public String getReference2Label() {
		return reference2Label;
	}


	public void setReference2Label(String reference2Label) {
		this.reference2Label = reference2Label;
	}


	public String getReference2() {
		return reference2;
	}


	public void setReference2(String reference2) {
		this.reference2 = reference2;
	}


	public String getRedirectUrl() {
		return redirectUrl;
	}


	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}


	public String getCallbackUrl() {
		return callbackUrl;
	}


	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getPaidAt() {
		return paidAt;
	}


	public void setPaidAt(String paidAt) {
		this.paidAt = paidAt;
	}

}
