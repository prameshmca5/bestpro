/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 12, 2018
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class MobileUser implements Serializable {

	private static final long serialVersionUID = 106316930304813799L;

	private String username;

	private String password;

	private String name;

	private String pin;

	private String oldPin;

	private String faceId;

	private String status;

	private String verifyMethod;

	private String qr;

	private Device deviceInfo;

	private String faceImage;

	private String profileId;

	private String uuid;

	private String subscrId;

	private String digitalIdInd;

	private String systemCode;

	private String mobileNo;
	
	private Integer applId;


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getPin() {
		return pin;
	}


	public void setPin(String pin) {
		this.pin = pin;
	}


	public String getFaceId() {
		return faceId;
	}


	public void setFaceId(String faceId) {
		this.faceId = faceId;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Device getDeviceInfo() {
		return deviceInfo;
	}


	public void setDeviceInfo(Device deviceInfo) {
		this.deviceInfo = deviceInfo;
	}


	public String getOldPin() {
		return oldPin;
	}


	public void setOldPin(String oldPin) {
		this.oldPin = oldPin;
	}


	public String getVerifyMethod() {
		return verifyMethod;
	}


	public void setVerifyMethod(String verifyMethod) {
		this.verifyMethod = verifyMethod;
	}


	public String getQr() {
		return qr;
	}


	public void setQr(String qr) {
		this.qr = qr;
	}


	public String getFaceImage() {
		return faceImage;
	}


	public void setFaceImage(String faceImage) {
		this.faceImage = faceImage;
	}


	public String getProfileId() {
		return profileId;
	}


	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}


	public String getUuid() {
		return uuid;
	}


	public void setUuid(String uuid) {
		this.uuid = uuid;
	}


	public String getSubscrId() {
		return subscrId;
	}


	public void setSubscrId(String subscrId) {
		this.subscrId = subscrId;
	}


	public String getDigitalIdInd() {
		return digitalIdInd;
	}


	public void setDigitalIdInd(String digitalIdInd) {
		this.digitalIdInd = digitalIdInd;
	}


	public String getSystemCode() {
		return systemCode;
	}


	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}


	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public Integer getApplId() {
		return applId;
	}


	public void setApplId(Integer applId) {
		this.applId = applId;
	}

}