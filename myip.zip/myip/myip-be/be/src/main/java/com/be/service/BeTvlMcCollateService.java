/**
 *
 */
package com.be.service;


import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTvlMcCollateRepository;
import com.be.model.BeTvlMcCollate;
import com.be.sdk.model.IQfCriteria;


/**
 * @author Atiqah Khairuddin
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_MC_COLLATE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_MC_COLLATE_SVC)
public class BeTvlMcCollateService extends AbstractService<BeTvlMcCollate> {

	@Autowired
	private BeTvlMcCollateRepository beTvlMcCollateDao;


	@Override
	public GenericRepository<BeTvlMcCollate> primaryDao() {
		return beTvlMcCollateDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public BeTvlMcCollate findBeTvlMcCollate(Integer tvlTestResultId, Integer mcCollateId) {
		return beTvlMcCollateDao.findBeTvlMcCollate(tvlTestResultId, mcCollateId);
	}

}
