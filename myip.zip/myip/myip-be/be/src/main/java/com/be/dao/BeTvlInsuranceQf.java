/**
 * 
 */
package com.be.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeTvlInsurance;
import com.be.model.BeTvlPayment;
import com.be.model.BeTvlPaymentDtl;
import com.be.model.BeTvlProfile;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Insurance;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;

/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_INSURANCE_QF)
public class BeTvlInsuranceQf extends QueryFactory<BeTvlInsurance> {

	@Autowired
	BeTvlProfileQf beTvlProfileQf;
	
	@Autowired
	BeTvlPaymentQf beTvlPaymentQf;
	
	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;

	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}
	
	@Override
	public Specification<BeTvlInsurance> searchByProperty(BeTvlInsurance t) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BeTvlInsurance> searchAllByProperty(BeTvlInsurance t) {
		CriteriaQuery<BeTvlInsurance> cq = cb.createQuery(BeTvlInsurance.class);
		Root<BeTvlInsurance> from = cq.from(BeTvlInsurance.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}

	public List<BeTvlInsurance> searchInsurancePagination(Insurance dto, DataTableRequest<?> dataTableInRQ) {

		List<BeTvlInsurance> result = new ArrayList<>();
		CriteriaQuery<BeTvlInsurance> cq = cb.createQuery(BeTvlInsurance.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlInsurance> root = cq.from(BeTvlInsurance.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					cq.orderBy(getOrderByClause(cb, root, pagination));
				}
			}

			TypedQuery<BeTvlInsurance> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}
	
	public Long getCount(Insurance dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeTvlInsurance> root = cq.from(BeTvlInsurance.class);
		predicates.addAll(generateCriteria(cb, root, dto));
		
		Join<BeTvlInsurance, BeTvlProfile> tvlProfile = root.join("tvlProfile", JoinType.LEFT);
		predicates.addAll(beTvlProfileQf.generateCriteria(cb, tvlProfile, dto));
		
		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}
	
	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			Insurance dto = JsonUtil.transferToObject(criteria, Insurance.class);
			
			if (!BaseUtil.isObjNull(dto.getTvlInsId())) {
				predicates.add(cb.equal(from.get("tvlInsId"), dto.getTvlInsId()));
			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}
		return predicates;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void joinFetch(From<?, ?> from, List<Predicate> predicates, Insurance dto, CriteriaQuery<?> cq) {

		Join<BeTvlInsurance, BeTvlProfile> tvlProfile = (Join) from.fetch("tvlProfile", JoinType.LEFT);
		if(!BaseUtil.isObjNull(dto.getTvlProfile()))
			predicates.addAll(beTvlProfileQf.generateCriteria(cb, tvlProfile, dto.getTvlProfile()));
		
		Join<BeTvlInsurance, BeTvlPaymentDtl> tvlPaymentDtl = (Join) from.fetch("tvlPaymentDtl", JoinType.LEFT);
		Join<BeTvlPaymentDtl, BeTvlPayment> tvlPayment = (Join) tvlPaymentDtl.fetch("tvlPayment", JoinType.LEFT);
		if(!BaseUtil.isObjNull(dto.getTvlPayment()))
			predicates.addAll(beTvlProfileQf.generateCriteria(cb, tvlPayment, dto.getTvlPayment()));
	}
}
