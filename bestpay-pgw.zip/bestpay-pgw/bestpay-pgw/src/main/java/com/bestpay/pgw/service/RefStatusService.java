/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.config.ConfigConstants;
import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.RefStatusRepository;
import com.bestpay.pgw.model.RefStatus;
import com.bestpay.pgw.sdk.constants.PgwCacheConstants;
import com.bestpay.pgw.util.QualifierConstants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 3, 2016
 */
@Transactional
@Service(QualifierConstants.REF_STATUS_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_STATUS_SVC)
@CacheConfig(cacheNames = PgwCacheConstants.CACHE_BUCKET)
public class RefStatusService extends AbstractService<RefStatus> {

	@Autowired
	RefStatusRepository refStatusDao;


	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_STATUS_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	@Override
	public List<RefStatus> findAll() {
		return refStatusDao.findAll();
	}


	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_STATUS.concat(#statusCode)", condition = "#statusCode != null and #result != null")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public RefStatus findByStatusCode(String statusCode) {
		return refStatusDao.findByStatusCode(statusCode);
	}


	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_STATUS_TYP.concat(#statusType)", condition = "#statusType != null and #result != null")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<RefStatus> findByStatusType(String statusType) {
		return refStatusDao.findByStatusType(statusType);
	}


	@Override
	@Caching(evict = {
			@CacheEvict(beforeInvocation = true, key = ConfigConstants.CACHE_JAVA_FILE + ".CACHE_KEY_STATUS_ALL"),
			@CacheEvict(beforeInvocation = true, key = ConfigConstants.CACHE_JAVA_FILE
					+ ".CACHE_KEY_STATUS_TYP.concat(#s.statusType)") }, put = {
							@CachePut(key = ConfigConstants.CACHE_JAVA_FILE
									+ ".CACHE_KEY_STATUS.concat(#s.statusCd)") })
	public RefStatus create(RefStatus s) {
		return super.create(s);
	}


	@Override
	@Caching(evict = {
			@CacheEvict(beforeInvocation = true, key = ConfigConstants.CACHE_JAVA_FILE + ".CACHE_KEY_STATUS_ALL"),
			@CacheEvict(beforeInvocation = true, key = ConfigConstants.CACHE_JAVA_FILE
					+ ".CACHE_KEY_STATUS.concat(#s.statusCd)"),
			@CacheEvict(beforeInvocation = true, key = ConfigConstants.CACHE_JAVA_FILE
					+ ".CACHE_KEY_STATUS_TYP.concat(#s.statusType)") })
	public RefStatus update(RefStatus s) {
		return super.update(s);
	}


	@Override
	@Caching(evict = {
			@CacheEvict(beforeInvocation = true, key = ConfigConstants.CACHE_JAVA_FILE + ".CACHE_KEY_STATUS_ALL"), })
	public boolean delete(Integer id) {
		return super.delete(id);
	}


	@Override
	public GenericRepository<RefStatus> primaryDao() {
		return refStatusDao;
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public RefStatus findByStatusDescEn(String statusCode) {
		return refStatusDao.findByStatusDescEn(statusCode);
	}
}
