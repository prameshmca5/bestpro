var csrf_token = jQuery("input[name=_csrf]").val();

var trLink = true;

$(window).bind('beforeunload', function() {
	portalUtil.showMainLoading(true);
});

function processRowNum(oSettings) {
	if (oSettings.bSorted || oSettings.bFiltered) {
		for (var i = 0, iLen = oSettings.aiDisplay.length; i < iLen; i++) {
			$('td:eq(0)', oSettings.aoData[oSettings.aiDisplay[i]].nTr).html(
					i + 1);
		}
	} else {
		var cntr = oSettings._iDisplayStart+1;
		for ( var ii=0, iiLen=oSettings.aiDisplay.length ; ii<iiLen ; ii++ ) {
			$('td:eq(0)', oSettings.aoData[ oSettings.aiDisplay[ii] ].nTr ).html( cntr++ );
		}
	}
}

function hidePagination(e, id) {
	if (e.api().data().length <= e.fnSettings()._iDisplayLength) {
		$(id + '_paginate').css("display", "none");
	}
	if (e.api().data().length == 0) {
		$(id + '_info').css("display", "none");
	}
}

function refresh() {
	location.reload();
}

function maxLengthCheck(object) {
	if (object.value.length > object.maxLength) {
		object.value = object.value.slice(0, object.maxLength)
	}
}

// Disable right click
/*
 * $(document).bind('contextmenu', function (e) { e.preventDefault(); });
 */

// Drawback for datepicker
/*
 * $(function(){ if (!Modernizr.inputtypes.date) { // If not native HTML5
 * support, fallback to jQuery datePicker $('input[type=date]').datepicker({ //
 * Consistent format with the HTML5 picker dateFormat : 'yy-mm-dd' }, //
 * Localization $.datepicker.regional['it'] ); } });
 */

function documentPopupForWallet(url, title, type) {

	var createDateFrom = $('input[name="createDateFrom"]').val();
	var createDateTo = $('input[name="createDateTo"]').val();
	var paymentMode = $('#paymentMode').val();
	var paymentRefNo = $('#paymentRefNo').val();
	var companyName = $('#profileTypeMruSelectName').val();
	var profileType = $('input[name="profileType"]:checked').val();

	var payDateFrom = document.getElementById('errorPaymentDateFrom');
	var payDateTo = document.getElementById('errorPaymentDateTo');
	var profileError = document.getElementById('errorProfile');
	
	if (createDateFrom == "") {
		payDateFrom.className +="errors ";
		payDateFrom.innerHTML = "Payment Date From is required";
		return false;
	}

	if (createDateTo == "") {
		payDateTo.className +="errors ";
		payDateTo.innerHTML = "Payment Date From is required";
		return false;
	}
	if (createDateFrom == "" && createDateTo == "") {
		payDateFrom.className +="errors ";
		payDateFrom.innerHTML = "Payment Date From is required";
		
		payDateTo.className +="errors ";
		payDateTo.innerHTML = "Payment Date From is required";
		return false;
	}
	if (companyName == "") {
		profileError.className +="errors ";
		profileError.innerHTML = "Company Name is required";
		return false;
	}

	url = url + '?createDateFrom=' + createDateFrom + '&createDateTo='
			+ createDateTo + '&paymentMode=' + paymentMode + '&paymentRefNo='
			+ paymentRefNo + '&optrId=' + companyName + '&profileType='
			+ profileType;
	documentPopup(url, title, type);
}

function documentPopupForWalletSOA(url, title, type) {

	var createDateFrom = $('input[name="createDateFrom"]').val();
	var createDateTo = $('input[name="createDateTo"]').val();
	var companyName = $('#profileTypeMruSelectName').val();
	var profileType = $('input[name="profileType"]:checked').val();

	var payDateFrom = document.getElementById('errorPaymentDateFrom');
	var payDateTo = document.getElementById('errorPaymentDateTo');
	var profileError = document.getElementById('errorProfile');
	
	if (createDateFrom == "") {
		payDateFrom.className +="errors ";
		payDateFrom.innerHTML = "Payment Date From is required";
		return false;
	}

	if (createDateTo == "") {
		payDateTo.className +="errors ";
		payDateTo.innerHTML = "Payment Date From is required";
		return false;
	}
	if (createDateFrom == "" && createDateTo == "") {
		payDateFrom.className +="errors ";
		payDateFrom.innerHTML = "Payment Date From is required";
		
		payDateTo.className +="errors ";
		payDateTo.innerHTML = "Payment Date From is required";
		return false;
	}
	if (companyName == "") {
		profileError.className +="errors ";
		profileError.innerHTML = "Company Name is required";
		return false;
	}

	url = url + '?createDateFrom=' + createDateFrom + '&createDateTo='
			+ createDateTo + '&optrId=' + companyName + '&profileType='
			+ profileType;
	documentPopup(url, title, type);
}

function documentPopupForRegListRpt(url, title, type) {

	var regDateFrom = $('input[name="regDateFrom"]').val();
	var regDateTo = $('input[name="regDateTo"]').val();
	var sector = $('#sectorSelectId').val();
	var registeredBy = $('#regSelectId').val();
	var roc = $('#roc').val();
	var cmpany = $('#companySelectedId').val();
	var passportNo = $('#passportNo').val();

	url = url + '?regDateFrom=' + regDateFrom + '&regDateTo=' + regDateTo
			+ '&sector=' + sector + '&registeredBy=' + registeredBy + '&roc='
			+ roc + '&cmpany=' + cmpany + '&passportNo=' + passportNo;
	documentPopup(url, title, type);
}

function documentPopupForAevRegListRpt(url, title, type) {

	var regDateFrom = $('input[name="regDateFrom"]').val();
	var regDateTo = $('input[name="regDateTo"]').val();
	var synDate = $('input[name="synDate"]').val();
	var passportNo = $('#aevEmployerList[name="passportNo"]').val();
	var manualDataEntry = $('input[name="manualDataEntry"]').val();
	var companyRoc = $('#aevEmployerList[name="companyRoc"]').val();
	var companyStatus = $('#employerStatus').val();
	var aevStatus = $('#aevWorkerStatus').val();
	var registrationNo = $('#aevEmployerList[name="registrationNo"]').val();

	url = url + '?regDateFrom=' + regDateFrom + '&regDateTo=' + regDateTo + '&synDate=' + synDate
	+ '&passportNo=' + passportNo + '&manualDataEntry=' + manualDataEntry 
	+ '&companyRoc=' + companyRoc + '&companyStatus=' + companyStatus
	+ '&aevStatus=' + aevStatus + '&registrationNo=' + registrationNo ;
	documentPopup(url, title, type);
}

var MimeType = {
	pdf : {
		mediaType : "application/pdf",
		fileExt : ".pdf"
	},
	gif : {
		mediaType : "image/gif",
		fileExt : ".gif"
	},
	png : {
		mediaType : "image/png",
		fileExt : ".png"
	},
	jpg : {
		mediaType : "image/jpeg",
		fileExt : ".jpeg, .jpg"
	},
	doc : {
		mediaType : "application/msword",
		fileExt : ".doc"
	},
	docx : {
		mediaType : "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
		fileExt : ".docx"
	},
	xls : {
		mediaType : "application/vnd.ms-excel",
		fileExt : ".xls"
	},
	xlsx : {
		mediaType : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
		fileExt : ".docx"
	}
};

var portalUtil = (function() {
	return {
		showMainLoading : function(isShow) {
			if ((typeof isShow) === "undefined") {
				isShow = true;
			}
			if (isShow) {
				$('#overlay_message')
						.attr('style', "display: block !important");
			} else {
				$('#overlay_message').attr('style', "display: none !important");
			}
		},
		showMessage : function(message, type) {
			type = type || 'info';
			$('#message_modal .modal-body p').html(message);
			$('#message_modal').removeClass('error info warning')
					.addClass(type).modal('show');
		},
		showSuccessMessage : function(message, callback) {
			message = message || 'This operation succeeds';
			bootbox.dialog({
				closeButton : false,
				message : message,
				title : "<i class=\"glyphicon\"></i>",
				className : "message-modal success",
				buttons : {
					confirm : {
						label : "OK",
						className : "btn-success",
						callback : function() {
							if (callback)
								callback();
						}
					}
				}
			});
		},
		showConfirm : function(message, callback) {
			message = message || 'Are you sure?';
			bootbox.dialog({
				closeButton : false,
				message : message,
				title : "<i class=\"glyphicon\"></i>",
				className : "message-modal confirm",
				buttons : {
					cancal : {
						label : prop.btnNo,
						className : "btn-default",
						callback : function() {
							callback(false);
						}
					},
					confirm : {
						label : prop.btnYes,
						className : "btn-info",
						callback : function() {
							callback(true);
						}
					}
				}
			});
		}
	}
})();

function langSelect(lang) {
	var url = window.location.href;
	if (url.includes("lang=")) {
		url = url.substr(0, url.indexOf('lang=') - 1);
	}
	var separator = (url.indexOf("?") === -1) ? "?" : "&";
	var newParam = separator + "lang=" + lang;
	if ((location.hash == null || location.hash == '') && url.includes("#")) {
		url = url.replace('#', '') + newParam;
	}
	window.location.href = url + newParam;
}

function backToInbox() {
	window.location.href = contextPath + '/inbox';
}

$(document).on(
		'keyup',
		'.input-amount',
		function() {
			var x = $(this).val();
			$(this).val(
					x.toString().replace(/,/g, "").replace(
							/\B(?=(\d{3})+(?!\d))/g, ","));
		});

$(document).on('keypress', '.input-amount', function(e) {
	console.log(e.keyCode);
	if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
		return false;
	}
});

$(document).on(
		'keyup',
		'.format-number',
		function() {
			var x = $(this).val();
			$(this).val(
					x.toString().replace(/,/g, "").replace(
							/\B(?=(\d{3})+(?!\d))/g, ","));
		});

$(document).on(
		'keypress',
		'.limit-number',
		function(e) {
			console.log(e.keyCode);
			if (e.which != 8 && e.which != 0
					&& ((e.which < 48 && e.which != 46) || e.which > 57)) {
				return false;
			}
			let targetId = "#" + e.originalEvent.target.id;
			var amountCancelDecimal = $(targetId).val().split('.')[1];
			let amountCancelText = null;
		    if (window.getSelection) {
		    	amountCancelText = window.getSelection().toString();
		    }
			    console.log("ID ", targetId);
			
			if(amountCancelDecimal && amountCancelDecimal.length > 1 && (amountCancelText != $(targetId).val())) {
				return false;
			}
		});

function dataTableInit(id) {
	$(id).dataTable({
		"dom" : '<"top"i>t<"bottom"p><"clear">',
		"oLanguage" : {
			"sEmptyTable" : prop.errNoRecFnd,
			"sLoadingRecords" : "Please wait - loading...",
			"sProcessing" : "DataTables is currently busy",
			"sZeroRecords" : "No records to display"
		},
		"fnDrawCallback" : function(oSettings) {
			hidePagination(this, id);
			processRowNum(oSettings);
		}
	});
}

function numberWithCommas(x) {
	return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

jQuery(document)
		.ready(
				function() {
					$("#topUpAmt").change(
							function() {
								var amt = this.value;
								var gstPrcnt = parseInt($("#gstPrcnt").val());
								var gst = 0;
								if (gstPrcnt > 0) {
									gst = parseInt(amt-(amt /((100+gstPrcnt)/100)));
								}
								console.log
								var creditedAmount = amt - gst;
								$("#gst").val(gst);
								$("#lblGst").val(gst);
								$("#creditedAmount").val(creditedAmount);
								$("#lblCreditedAmount").val(
										numberWithCommas(creditedAmount));

							});

					dataTableInit('tblCrdHstryLst');
					dataTableInit('#prdLstId');
					$('#prdLstId tbody').on('click', 'tr', function() {
						var rowId = this.id;
						if (rowId != null) {
							location.href = contextPath + "/products/" + rowId;
						}
					});

					dataTableInit('#tblRefProdLstId');
					$('#tblRefProdLstId tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								if (rowId != null) {
									location.href = contextPath
											+ "/maintenance/product/" + rowId;
								}
							});

					dataTableInit('#tblRefProdCatLstId');
					$('#tblRefProdCatLstId tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								if (rowId != null) {
									location.href = contextPath
											+ "/maintenance/product-cat/"
											+ rowId;
								}
							});

					dataTableInit('#tblReceiverLst');
					$('#tblReceiverLst tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								console.log(rowId);
								if (rowId != null) {
									location.href = contextPath + "/receivers/"
											+ rowId;
								}
							});

					dataTableInit('#tblMerchantLst');
					$('#tblMerchantLst tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								if (rowId != null) {
									location.href = contextPath + "/merchants/"
											+ rowId;
								}
							});

					dataTableInit('#tblRefCityLstId');
					// $('#tblRefCityLstId').dataTable({ "dom":
					// '<"top"i>t<"bottom"p><"clear">', "fnDrawCallback":
					// function ( oSettings )
					// {hidePagination(this,"#tblRefCityLstId");
					// processRowNum(oSettings);}});
					$('#tblRefCityLstId tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								if (rowId != null) {
									location.href = contextPath
											+ "/maintenance/city/" + rowId;
								}
							});

					dataTableInit('#tblRefDistLstId');
					// $('#tblRefDistLstId').dataTable({ "dom":
					// '<"top"i>t<"bottom"p><"clear">', "fnDrawCallback":
					// function ( oSettings )
					// {hidePagination(this,"#tblRefDistLstId");
					// processRowNum(oSettings);}});
					$('#tblRefDistLstId tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								if (rowId != null) {
									location.href = contextPath
											+ "/maintenance/district/" + rowId;
								}
							});

					dataTableInit('#tblRefStateLstId');
					// $('#tblRefStateLstId').dataTable({ "dom":
					// '<"top"i>t<"bottom"p><"clear">', "fnDrawCallback":
					// function ( oSettings )
					// {hidePagination(this,"#tblRefStateLstId");
					// processRowNum(oSettings);}});
					$('#tblRefStateLstId tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								if (rowId != null) {
									location.href = contextPath
											+ "/maintenance/state/" + rowId;
								}
							});

					dataTableInit('#tblRefBankLstId');
					// $('#tblRefBankLstId').dataTable({ "dom":
					// '<"top"i>t<"bottom"p><"clear">', "fnDrawCallback":
					// function ( oSettings )
					// {hidePagination(this,"#tblRefBankLstId");
					// processRowNum(oSettings);}});
					$('#tblRefBankLstId tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								if (rowId != null) {
									location.href = contextPath
											+ "/maintenance/bank/" + rowId;
								}
							});

					dataTableInit('#tblRefStatusLstId');
					// $('#tblRefStatusLstId').dataTable({ "dom":
					// '<"top"i>t<"bottom"p><"clear">', "fnDrawCallback":
					// function ( oSettings )
					// {hidePagination(this,"#tblRefStatusLstId");
					// processRowNum(oSettings);}});
					$('#tblRefStatusLstId tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								if (rowId != null) {
									location.href = contextPath
											+ "/maintenance/status/" + rowId;
								}
							});

					// reg
					dataTableInit('#mruListTableId');
					// $('#mruListTableId').dataTable({ "dom":
					// '<"top"i>t<"bottom"p><"clear">', "fnDrawCallback":
					// function ( oSettings )
					// {hidePagination(this,"#mruListTableId");
					// processRowNum(oSettings);}});
					$('#mruListTableId tbody').on('click', 'tr', function() {
						var rowId = this.id;
						if (rowId != null) {
							location.href = contextPath + rowId;
						}
					});

					dataTableInit('#apsListTableId');
					// $('#mruListTableId').dataTable({ "dom":
					// '<"top"i>t<"bottom"p><"clear">', "fnDrawCallback":
					// function ( oSettings )
					// {hidePagination(this,"#mruListTableId");
					// processRowNum(oSettings);}});
					$('#apsListTableId tbody').on('click', 'tr', function() {
						var rowId = this.id;
						if (rowId != null) {
							location.href = contextPath + rowId;
						}
					});

					dataTableInit('#oscListTableId');
					// $('#mruListTableId').dataTable({ "dom":
					// '<"top"i>t<"bottom"p><"clear">', "fnDrawCallback":
					// function ( oSettings )
					// {hidePagination(this,"#mruListTableId");
					// processRowNum(oSettings);}});
					$('#oscListTableId tbody').on('click', 'tr', function() {
						var rowId = this.id;
						if (rowId != null) {
							location.href = contextPath + rowId;
						}
					});

					dataTableInit('#cruListTableId');
					// $('#mruListTableId').dataTable({ "dom":
					// '<"top"i>t<"bottom"p><"clear">', "fnDrawCallback":
					// function ( oSettings )
					// {hidePagination(this,"#mruListTableId");
					// processRowNum(oSettings);}});
					$('#cruListTableId tbody').on('click', 'tr', function() {
						var rowId = this.id;
						if (rowId != null) {
							location.href = contextPath + rowId;
						}
					});

					dataTableInit('#walletListTableId');
					dataTableInit('#regListTableId');
					dataTableInit('#aevWorkerListId');

					var oTableColl = $('#surrCollectListTableId')
							.dataTable(
									{
										"dom" : '<"top"i>t<"bottom"p><"clear">',
										"processing" : true,
										"fnDrawCallback" : function() {
											hidePagination(this,
													"#surrCollectListTableId");
											$('.chk')
													.click(
															function() {
																var allPages = oTableColl
																		.fnGetNodes();
																var pmtTxnIds = [];
																var total = 0;
																var items = Number($(
																		'input[type="checkbox"]',
																		allPages).length);
																var itemCheck = Number($(
																		'input[type="checkbox"]:checked',
																		allPages).length);
																if (itemCheck < items) {
																	$('#chkAll')
																			.prop(
																					'checked',
																					false);
																} else if (itemCheck == items) {
																	$('#chkAll')
																			.prop(
																					'checked',
																					true);
																}

																var decimalTotal = total
																		.toFixed(2);
																$('#total')
																		.text(
																				decimalTotal);
																document
																		.getElementById("hiddenInp").value = pmtTxnIds;
															});
											$('#chkAll')
													.click(
															function() {
																var allPages = oTableColl
																		.fnGetNodes();

																var total = 0;
																var pmtTxnIds = [];
																if ($('#chkAll')
																		.is(
																				':checked')) {
																	$(
																			'input[type="checkbox"]',
																			allPages)
																			.prop(
																					'checked',
																					true);

																} else {
																	$(
																			'input[type="checkbox"]',
																			allPages)
																			.prop(
																					'checked',
																					false);
																}
																var decimalTotal = total
																		.toFixed(2);
																$('#total')
																		.text(
																				decimalTotal);
																document
																		.getElementById("hiddenInp").value = pmtTxnIds;
															});
										}
									});

					$('#surrSummaryListTableId').dataTable({
						"dom" : '<"top"i>t<"bottom"p><"clear">',
						"fnDrawCallback" : function(oSettings) {
							hidePagination(this, "#surrSummaryListTableId");
							processRowNum(oSettings);
						}
					});

					jQuery(document)
							.ready(
									function() {

										var imiOverwriteBranchIds = [];
										var tmpBranchIds2 = [];

										$(".remarksClass")
												.keyup(
														function() {
															var textinput = $(
																	'.remarksClass')
																	.val();
															document
																	.getElementById("hiddenInpRemarks").value = textinput;

														});

										$(".overwrite")
												.change(
														function() {

															// $('option[value='
															// + $(this).val() +
															// ']').attr('disabled',
															// 'disabled');
															var valOverwrite = this.value;
															$(
																	"#"
																			+ this.id
																			+ "imi")
																	.prop(
																			"checked",
																			true);
															var valTempBrnch = ($('input[class="defaultSelected"]:checked')
																	.val());
															createListBranchSelected(valOverwrite);
															createListTempBrnchSelected(valTempBrnch);

														});

										function createListBranchSelected(
												valOverwrite) {
											imiOverwriteBranchIds
													.push(valOverwrite);
											document
													.getElementById("hiddenInp").value = imiOverwriteBranchIds;
											console
													.log("imiOverwriteBranchIds>"
															+ imiOverwriteBranchIds);

										}

										function createListTempBrnchSelected(
												valTempBrnch) {
											tmpBranchIds.push(valTempBrnch);
											document
													.getElementById("hiddenInpTemp").value = valTempBrnch;
											console.log("tmpBranchIds>"
													+ valTempBrnch);

										}

										$(".btnSelectStatus")
												.change(
														function() {
															var selectedIndex = this.value;
															console
																	.log("selectedIndex>>>>>"
																			+ selectedIndex);
															document
																	.getElementById("hiddenInpRbtn").value = selectedIndex;

														});

										$(".defaultSelected")
												.change(
														function() {
															var val = this.value;
															tmpBranchIds2
																	.push(val);
															console
																	.log("TEST::::"
																			+ tmpBranchIds2);
															document
																	.getElementById("hiddenInpTemp2").value = val;
														});

									})

					$('#branchIdEmp tr')
							.each(
									function() {
										$(this)
												.find('select:eq(0)')
												.change(
														function() {
															if ($(
																	'#branchIdEmp')
																	.find(
																			'select option[value='
																					+ $(
																							this)
																							.val()
																					+ ']:selected').length > 1) {
																$(this)
																		.val(
																				$(
																						this)
																						.find(
																								"option:first")
																						.val());
															}
														});
									});

					dataTableInit('#tblTranLst');
					$('#tblTranLst tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								if (rowId != null) {
									portalUtil.showMainLoading(true);
									var inputURL = contextPath
											+ "/trans-list/details/" + rowId;
									console.log(inputURL);
									$.ajax({
										headers : {
											'X-CSRF-Token' : csrf_token
										},
										type : "GET",
										action : 'xhttp',
										url : inputURL,
										success : function(data) {
											$('#popup_content').html(data);
											$('#popup_modal').modal('show');
										}
									}).done(function() {
										portalUtil.showMainLoading(false);
									});
								}
							});

					dataTableInit('#tblTranRepLst');

					if ($('#userGroupCode').length > 0) {
						onChangeGroup();
					}

					$('#aTag').click(function() {
						document.getElementById('appForm').submit();
					});

					$('.app-flow').click(function() {
						location.href = contextPath + $(this).attr("href");
					});

					dataTableInit('#tblRegList');
					$('#tblRegList tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								console.log(rowId);
								if (rowId != null) {
									location.href = contextPath
											+ "/application/registrationList/"
											+ rowId;
								}
							});

					dataTableInit('#trasSuplist');
					$('#trasSuplist tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								console.log(rowId);
								if (rowId != null) {
									location.href = contextPath
											+ "/application/supervisorInput/"
											+ rowId;
								}
							});

					// $('#tblUsers').dataTable({ "dom":
					// '<"top"i>t<"bottom"p><"clear">', "fnDrawCallback":
					// function ( oSettings ) {hidePagination(this,"#tblUsers");
					// processRowNum(oSettings);}});
					dataTableInit('#trasSuplist');
					dataTableInit('#tblUsers');

					$('#UserList1').dataTable({
						"dom" : '<"top"i>t<"bottom"p><"clear">',
						"aoColumnDefs" : [ {
							"bSortable" : false,
							"aTargets" : [ 0 ]
						} ],
						"order" : [ [ 1, "asc" ] ],
						"fnDrawCallback" : function() {
							hidePagination(this, "#UserList1");
						}
					});

					$('#licCertExpiryPckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						startDate : getDatePlusDays(5)
					});

					$('#endDatePckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#crtDtPckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#unitAsgDtFrm').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#unitAsgDtFrm').datepicker().on(
							'changeDate',
							function(ev) {
								var minDate = new Date(ev.date.valueOf());
								$('#unitAsgDtToPckr').datepicker(
										'setStartDate', minDate);
							});

					$('#unitAsgDtToPckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#applctnDtFromPckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#applctnDtFromPckr').datepicker().on(
							'changeDate',
							function(ev) {
								var minDate = new Date(ev.date.valueOf());
								$('#applctnDtToPckr').datepicker(
										'setStartDate', minDate);
							});

					$('#applctnDtToPckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#dobPckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});
					
					$('#verDobPckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});
					
					 $('#verDobPckr').datepicker().on('changeDate', function (ev) {
						 var msj = document.getElementById("errDate");
						 
						 var dobDate = $('#dobPckr').datepicker('getDate');
						 var checkDate = dobDate.valueOf();
						 var verDate = ev.date.valueOf();
					     if (verDate == checkDate) {
					    	 msj.style.display = "none";
					     }else{
					    	 msj.innerHTML="Date of Birth does not match";
					    	 msj.style.display = "block";
					    	
					    	 
					    	 
					     }
					    	 
					     
					 });
					
					$('#expPckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						startDate : new Date()
					});

					$('#startDatePckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy"
					});

					$('#apprveDtFrmPckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#apprveDtFrmPckr').datepicker().on(
							'changeDate',
							function(ev) {
								var minDate = new Date(ev.date.valueOf());
								$('#apprveDtToPckr').datepicker('setStartDate',
										minDate);
							});

					$('#apprveDtToPckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#dateFrmPckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					}).on('changeDate', function(ev) {
						console.log('on Change!!!')
						var minDate = new Date(ev.date.valueOf());
						$('#dateToPckr').datepicker('setStartDate', minDate);
					});

					$('#dateToPckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#interviewDatePckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						startDate : new Date()
					});
					
					 $('#interviewDatePckr').datepicker().on('changeDate', function (ev) {
						 var msj = document.getElementById("errorDate");
						 
						 var dobDate = $('#expPckr').datepicker('getDate');
						 var checkDate = dobDate.valueOf();
						 var verDate = ev.date.valueOf();
					     if (verDate == checkDate) {
					    	 msj.style.display = "none";
					     }else{
					    	 msj.innerHTML="Expired Date does not match";
					    	 msj.style.display = "block";
					    	
					    	 
					    	 
					     }
					    	 
					     
					 });
					$('#srchInterviewDatePckr').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy"
					});

					$('#applctnDtFrom').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#applctnDtFrom').datepicker().on(
							'changeDate',
							function(ev) {
								var minDate = new Date(ev.date.valueOf());
								$('#applctnDtTo').datepicker('setStartDate',
										minDate);
							});

					$('#applctnDtTo').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#mruAsgDtFrm').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#mruAsgDtTo').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#paymentDateFrom').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#paymentDateTo').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#paymentDate').datepicker({
						autoclose : true,
						todayHighlight : true,
						format : "dd/mm/yyyy",
						endDate : new Date()
					});

					$('#tblCardLst tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								console.log(rowId);
								if (rowId != null) {
									location.href = contextPath + "/card-info/"
											+ rowId;
								}
							});

					$('#brndLstId tbody').on(
							'click',
							'tr',
							function() {
								var rowId = this.id;
								if (rowId != null) {
									location.href = contextPath
											+ "/maintenance/brand/" + rowId;
								}
							});

					var tblInbox = $('#MyInboxList').DataTable({
						"dom" : '<"top"i>t<"bottom"p><"clear">',
						"order" : [ [ 3, 'asc' ] ],
						"fnDrawCallback" : function() {
							hidePagination(this, "#MyInboxList");
						}
					});
					jQuery('#MyInboxList tbody').on('click', 'tr a',
							function() {
								trLink = false;
							});
					jQuery("#MyInboxList tbody").on('click',
							"tr input[type='checkbox']", function() {
								trLink = false;
							});
					jQuery('#MyInboxList tbody')
							.on(
									'click',
									'tr',
									function() {
										if (trLink) {
											var data = tblInbox.row(this)
													.data();
											var refNo = data[0].indexOf('/') > -1 ? data[0]
													.replace(new RegExp('/',
															'g'), '-')
													: data[0];
											var transType = data[3];
											console
													.log("transType ::::> "
															+ transType
															+ " - refNo ::::> "
															+ refNo);
											window.location.href = contextPath
													+ '/inbox/' + transType
													+ '/' + refNo
													+ '?isClaim=true';
										}
										trLink = true;
									});

					var tblInboxHistory = $('#HistoryList').DataTable({
						"dom" : '<"top"i>t<"bottom"p><"clear">',
						"order" : [ [ 3, 'asc' ] ],
						"fnDrawCallback" : function() {
							hidePagination(this, "#HistoryList");
						}
					});
					jQuery('#HistoryList tbody').on('click', 'tr a',
							function() {
								trLink = false;
							});
					jQuery("#HistoryList tbody").on('click',
							"tr input[type='checkbox']", function() {
								trLink = false;
							});
					jQuery('#HistoryList tbody')
							.on(
									'click',
									'tr',
									function() {
										if (trLink) {
											var data = tblInboxHistory
													.row(this).data();
											var refNo = data[0].indexOf('/') > -1 ? data[0]
													.replace(new RegExp('/',
															'g'), '-')
													: data[0];
											var transType = data[3];
											console
													.log("transType ::::> "
															+ transType
															+ " - refNo ::::> "
															+ refNo);
											window.location.href = contextPath
													+ '/inbox/' + transType
													+ '/' + refNo
													+ '?isClaim=true';
										}
										trLink = true;
									});

					var tblInboxPool = $('#PoolList').DataTable({
						"dom" : '<"top"i>t<"bottom"p><"clear">',
						"order" : [ [ 3, 'asc' ] ],
						"fnDrawCallback" : function() {
							hidePagination(this, "#PoolList");
						}
					});
					jQuery('#PoolList tbody').on('click', 'tr a', function() {
						trLink = false;
					});
					jQuery("#PoolList tbody").on('click',
							"tr input[type='checkbox']", function() {
								trLink = false;
							});
					jQuery('#PoolList tbody')
							.on(
									'click',
									'tr',
									function() {
										if (trLink) {
											var data = tblInboxPool.row(this)
													.data();
											var refNo = data[0].indexOf('/') > -1 ? data[0]
													.replace(new RegExp('/',
															'g'), '-')
													: data[0];
											var transType = data[3];
											console
													.log("transType ::::> "
															+ transType
															+ " - refNo ::::> "
															+ refNo);
											window.location.href = contextPath
													+ '/inbox/' + transType
													+ '/' + refNo
													+ '?isClaim=true';
										}
										trLink = true;
									});

				});

var chkboxCheck = 0;
var selctedType = "-1";
if (document.getElementById("selectedRoles") != null) {
	var dataLst = document.getElementById("selectedRoles").value.split(",");
	for (var index = 0; index < dataLst.length; index++) {
		selectedIds.push(dataLst[index]);
	}
}

function onSearchAcptColl() {
	var trxNo = document.getElementById('trxNo').value;
	window.location.href = contextPath + '/collections/accept/' + trxNo;
}

function redirectURL(value) {
	console.log("redirectURL>>" + contextPath + value);
	location.href = contextPath + value;
}

function onChangeState() {
	var stateCod = $('#state').val();

	var url = contextPath + '/district/stateCode/' + stateCod;
	$.getJSON(url, {
		ajax : 'true'
	}, function(data) {
		var html = prop.selOptDef;
		var len = data.length;
		for (var i = 0; i < len; i++) {
			console.log(data[i].districtCode, data[i].districtDesc);
			html += '<option value="' + data[i].districtCode + '">'
					+ data[i].districtDesc + '</option>';
		}
		html += '</option>';
		$('#districtCode').html(html);
	});
}

function onChangeCategoryType() {
	var prodCatType = $('#prodCatType').val();

	var url = contextPath + '/product-list/prdCatType/' + prodCatType;
	$.getJSON(url, {
		ajax : 'true'
	}, function(data) {
		var html = prop.selOptDef;
		var len = data.length;
		for (var i = 0; i < len; i++) {
			console.log(data[i].prodCatId, data[i].prodCatDesc);
			html += '<option value="' + data[i].prodCatId + '">'
					+ data[i].prodCatDesc + '</option>';
		}
		html += '</option>';
		$('#prodCatId').html(html);
	});
}

function onChangeCollectionStatus(e) {
	var selectedIndex = e.value;
	var url = contextPath + '/collections/accept/onchangecolst/'
			+ selectedIndex;
	$.ajax({
		type : "GET",
		url : url,
		success : function(response) {
			$("#refreshId").html(response);
		}
	});
}

function onChangeCategory() {
	var prodCatId = $('#prodCatId').val();
	var url = contextPath + '/product-list/prdCat/' + prodCatId;
	$.getJSON(url, {
		ajax : 'true'
	}, function(data) {
		var html = prop.selOptDef;
		var len = data.length;
		for (var i = 0; i < len; i++) {
			html += '<option value="' + data[i].prodId + '">'
					+ data[i].prodDesc + '</option>';
		}
		html += '</option>';
		$('#prodId').html(html);
	});
}

function onChangeGroup() {
	var groupCode = $('#userGroupCode').val();
	if (groupCode == 'BANK') {
		$('#divBranch').show();
	} else {
		$('#divBranch').hide();
	}
}

function documentPopupProject(url, title, docType, type) {
	var newURL = '';
	if (type == 'null')
		newURL = contextPath + "/" + url;
	else
		newURL = contextPath + "/" + url + "/" + type;

	console.log("newURL--- " + newURL);
	jQuery("#rptTtl").html(title);
	jQuery("#pdfUrl").attr('data', newURL);
	jQuery("#pdfUrl").attr('type', docType);
	jQuery("#embdPdfUrl").attr('src', newURL);
	jQuery("#pdfAncUrl").attr('href', newURL);
	jQuery("#rptDialog").modal("show");
}

function documentPopup(url, title, type) {
	portalUtil.showMainLoading(true);
	setTimeout(
			function() {
				var inputUrl = contextPath;
				if (type == 'aform' || type == 'aslip') {
					inputUrl = inputUrl + "/" + url
					if (type == 'aform') {
						jQuery("#titleText").html(prop.lblRegFrm);
					} else if (type == 'aslip') {
						jQuery("#titleText").html(prop.lblAsgSlip);
					}
				} else {
					inputUrl = inputUrl + "/" + url
				}
				inputUrl = encodeURI(inputUrl);
				$
						.ajax(
								{
									async : false,
									global : false,
									headers : {
										'X-CSRF-Token' : csrf_token
									},
									type : "GET",
									action : 'xhttp',
									url : inputUrl,
									success : function(data) {
										console.log(data)
										var doc = data;
										jQuery("#rptTtl").html(title);
										var srcObj = contextPath
												+ "/images/no-document.png";
										var mimeType = "image/png";
										if (doc.content != undefined) {
											srcObj = 'data:' + doc.contentType
													+ ';base64,' + doc.content;
											mimeType = doc.contentType;
										} else if (doc.reportBytes != undefined) {
											srcObj = 'data:' + doc.mimeType
													+ ';base64,'
													+ doc.reportBytes;
											mimeType = doc.mimeType;
										}
										var object = '<object id="pdfUrl" width="100%" height="500px"'
												+ ' data="'
												+ srcObj
												+ '" '
												+ ' type="'
												+ mimeType
												+ '" >'
												+ '<embed '
												+ '  src="'
												+ srcObj
												+ '" '
												+ '  type="'
												+ mimeType
												+ '" '
												+ '  width="100%" '
												+ '  height="500px" />'
												+ '</object>';
										jQuery("#pdfUrl").replaceWith(object);
										jQuery("#rptDialog").modal("show");
									}
								}).done(function() {
							portalUtil.showMainLoading(false);
						});
			}, 1000);
}

function documentPopupQuotaAppReport(url, title, type) {
	var appDateFrom = $('#applctnDtFrom').val();
	var appDateTo = $('#applctnDtTo').val();
	var aksName = $('#aksName').val();
	var sector = $('#sector').val();
	var subSector = $('#subSector').val();
	var jobCategory = $('#jobCategory').val();
	var appStatus = $('#appStatus').val();
	var companyRegNo = $('#companyRegNo').val();
	var intvwDate = '';
	var apprDate = '';
	$('#srchInterviewDate').val();
	$('#apprveDtFrm').val();
	url = url + '?appDateFrom=' + appDateFrom + '&appDateTo=' + appDateTo
			+ '&aksName=' + aksName + '&sector=' + sector + '&subSector='
			+ subSector + '&jobCategory=' + jobCategory + '&appStatus='
			+ appStatus + '&companyRegNo=' + companyRegNo + '&intvwDate='
			+ intvwDate + '&apprDate=' + apprDate;
	documentPopup(url, title, type);

}

function onChangeEmployerStatus(e) {

	var selectedIndex = e.value;
	console.log(selectedIndex);
	if (selectedIndex == "REJECTED") {

		$("#textAreaId").hide();
	} else {
		$("#textAreaId").show();

	}

}

function documentPopupSurrenderCollReport(url, title, type) {
	var collectionTxnNo = $('#collectionTxnNo').val();
	var surrenderDt = $('#surrenderDt').val();
	var surrenderBy = $('#surrenderBy').val();
	url = url + '?collectionTxnNo=' + collectionTxnNo + '&surrenderDt='
			+ surrenderDt + '&surrenderBy=' + surrenderBy;
	documentPopup(url, title, type);
}

var appUtil = (function() {
	return {
		showMainLoading : function(isShow) {
			if ((typeof isShow) === "undefined") {
				isShow = true;
			}
			if (isShow) {
				$('#main_loading').attr('style', "display: block !important");
			} else {
				$('#main_loading').attr('style', "display: none !important");
			}
		}
	}
})();

function ajaxCall(inputType, inputURL, inputData, todo, dataType) {
	appUtil.showMainLoading(true);
	if (todo == 'addWorker' || todo == 'removeWorker') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addWorker') {
					$('#popup_modal').modal('hide');
				}
				$('#addWorker').dataTable().fnDestroy();
				$('#addWorker').dataTable({
					/*
					 * responsive: true, "dom": '<"top"i>t<"bottom"p><"clear">',
					 * "data": newData.aaData, "aoColumns": [ null, null, null,
					 * null, null ], "aoColumnDefs": [{ "bSortable": false }]
					 */

					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						hidePagination(this, "#addWorker");
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else if (todo == 'addProduct' || todo == 'removeProduct') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addProduct') {
					$('#popup_modal').modal('hide');
				}
				$('#addProduct').dataTable().fnDestroy();
				$('#addProduct').dataTable({
					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else if (todo == 'addSlghtr' || todo == 'removeSlghtr') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addSlghtr') {
					$('#popup_modal').modal('hide');
				}
				$('#addSlghtr').dataTable().fnDestroy();
				$('#addSlghtr').dataTable({
					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						hidePagination(this, "#addSlghtr");
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else if (todo == 'addLicense' || todo == 'removeLicense') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addLicense') {
					$('#popup_modal').modal('hide');
				}
				$('#addLicense').dataTable().fnDestroy();
				$('#addLicense').dataTable({
					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else if (todo == 'addCrop' || todo == 'removeCrop') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addCrop') {
					$('#popup_modal').modal('hide');
				}
				$('#addCrop').dataTable().fnDestroy();
				$('#addCrop').dataTable({
					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else if (todo == 'addLivestock' || todo == 'removeLivestock') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addLivestock') {
					$('#popup_modal').modal('hide');
				}
				$('#addLivestock').dataTable().fnDestroy();
				$('#addLivestock').dataTable({
					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else if (todo == 'addNursery' || todo == 'removeNursery') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addNursery') {
					$('#popup_modal').modal('hide');
				}
				$('#addNursery').dataTable().fnDestroy();
				$('#addNursery').dataTable({
					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});

	} else if (todo == 'addPremise' || todo == 'removePremise') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addPremise') {
					$('#popup_modal').modal('hide');
				}
				$('#addPremise').dataTable().fnDestroy();
				$('#addPremise').dataTable({
					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});

	} else if (todo == 'addFinancial' || todo == 'removeFinancial') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addFinancial') {
					$('#popup_modal').modal('hide');
				}
				$('#tblFinancial').dataTable().fnDestroy();
				$('#tblFinancial').dataTable({
					/*
					 * responsive: true, "dom": '<"top"i>t<"bottom"p><"clear">',
					 * "data": newData.aaData, "aoColumns": [ null, null, null,
					 * null, null ], "aoColumnDefs": [{ "bSortable": false }]
					 */

					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						hidePagination(this, "#tblFinancial");
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else if (todo == 'addActivity' || todo == 'removePlnttActivity') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addActivity') {
					$('#popup_modal').modal('hide');
				}
				$('#addActivity').dataTable().fnDestroy();
				$('#addActivity').dataTable({
					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else if (todo == 'addProject' || todo == 'removeProject') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addProject') {
					$('#popup_modal').modal('hide');
				}
				$('#addProject').dataTable().fnDestroy();
				$('#addProject').dataTable({
					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else if (todo == 'addSubCon' || todo == 'removeSubCon') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addSubCon') {
					$('#popup_modal').modal('hide');
				}
				$('#addSubCon').dataTable().fnDestroy();
				$('#addSubCon').dataTable({
					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						hidePagination(this, "#addSubCon");
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else if (todo == 'addSubConFeedmill' || todo == 'removeSubConFeedmill') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addSubConFeedmill') {
					$('#popup_modal').modal('hide');
				}
				$('#addSubConFeedmill').dataTable().fnDestroy();
				$('#addSubConFeedmill').dataTable({
					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						hidePagination(this, "#addSubConFeedmill");
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else if (todo == 'addSubConSlghtr' || todo == 'removeSubConSlghtr') {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			success : function(data) {
				var newData = JSON.parse(data);
				if (todo == 'addSubConSlghtr') {
					$('#popup_modal').modal('hide');
				}
				$('#addSubConSlghtr').dataTable().fnDestroy();
				$('#addSubConSlghtr').dataTable({
					"dom" : '<"top"i>t<"bottom"p><"clear">',
					"fnDrawCallback" : function(oSettings) {
						hidePagination(this, "#addSubConSlghtr");
						processRowNum(oSettings)
					},
					"aoColumnDefs" : [ {
						"bSortable" : false,
						"aTargets" : [ 0 ]
					} ],
					"aaSorting" : [ [ 1, 'asc' ] ],
					"data" : newData.aaData
				});
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else if (todo) {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData,
			dataType : dataType,
			success : function(data) {
				if (todo == 'showDialog') {
					$('#popup_content').html(data);
					$('#popup_modal').modal('show');
				} else if (todo == 'showWorker') {
					$("#mainPopupType").html("custom");
					$(".modal-title").html("Current Manpower");
					$('#popup_content').html(data);
					$('#popup_modal').modal('show');
				}
			}
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	} else {
		$.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : inputType,
			action : 'xhttp',
			url : inputURL,
			data : inputData
		}).done(function() {
			appUtil.showMainLoading(false);
		});
	}
}

function checkDate(field) {
	var minYear = 1900;
	var maxYear = (new Date()).getFullYear();

	var errorMsg = "";

	let re = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
	let regs = "";

	if (field.value != '') {
		if (regs = field.value.match(re)) {
			if (regs[1] < 1 || regs[1] > 31) {
				errorMsg = prop.invDay.replace("{0}", regs[1]);
			} else if (regs[2] < 1 || regs[2] > 12) {
				errorMsg = prop.invMonth.replace("{0}", regs[2]);
			} else if (regs[3] < minYear || regs[3] > maxYear) {
				errorMsg = prop.invYear.replace("{0}", regs[3]).replace("{1}",
						minYear).replace("{2}", maxYear);
			}
		} else {
			errorMsg = prop.invFmtDt.replace("{0}", field.value);
		}
	}
	
	return errorMsg;
}

function getDatePlusDays(days) {
	var dt = new Date();
	dt.setDate(dt.getDate() + days);
	dt = new Date(dt);
	return dt;
}

function checkDateNoFuture(dt) {
	var now = new Date();
	if (dt.indexOf('/') > -1) {
		var parts = dt.split('/');
		var date = new Date(parts[2], parts[1] - 1, parts[0]);
	}
	return date > now;
}

function checkDateNoPast(dt) {
	var now = new Date();
	if (dt.indexOf('/') > -1) {
		var parts = dt.split('/');
		var date = new Date(parts[2], parts[1] - 1, parts[0]);
	}
	return date < now;
}

function validateEmailAddress(email) {
	var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	return emailReg.test(email);
}

function validateSearch(e) {
	var hasSrchError = false;
	if (e == "mrchnt") {
		var regNo = $("#companyReg").val();
		var cmpNam = $("#companyName").val();
		if ((regNo == null && cmpNam == null) || (regNo == '' && cmpNam == '')) {
			hasSrchError = true;
		}

	} else if (e == "prdct") {
		var prodCatType = $("#prodCatType").val();
		var pcode = $("#prodCode").val();
		var pname = $("#prodName").val();
		var brandDesc = $("#brandDesc").val();
		if ((prodCatType == null && pcode == null && pname == null && brandDesc == null)
				|| (prodCatType == '' && pcode == '' && pname == '' && brandDesc == '')) {
			hasSrchError = true;
		}

	} else if (e == "rcvr") {
		var btchType = $("#batch").val();
		var icno = $("#icNo").val();
		var name = $("#name").val();
		if ((btchType == null && icno == null && name == null)
				|| (btchType == '' && icno == '' && name == '')) {
			hasSrchError = true;
		}

	} else if (e == "trxn") {
		var cardType = $("#cardType").val();
		var mechantId = $("#mechantId").val();
		var icNo = $("#icNo").val();
		if ((cardType == null && mechantId == null && icNo == null)
				|| (cardType == '' && mechantId == '' && icNo == '')) {
			hasSrchError = true;
		}

	} else if (e == "prdctRep") {
		var startDate = $("#dateFrmPckr").val();
		var endDate = $("#dateToPckr").val();
		if (startDate == '' || startDate == null) {
			hasSrchError = true;
		}
		if (endDate == '' || endDate == null) {
			hasSrchError = true;
		}

	}
	if (hasSrchError) {
		$("#srchErrMsg").show();
		return false;
	} else {
		$("#srchErrMsg").hide();
		return true;
	}

}

function initDatatable(e) {
	$('#' + e).dataTable({
		"dom" : '<"top"i>t<"bottom"p><"clear">',
		"fnDrawCallback" : function(oSettings) {
			hidePagination(this, "#" + e);
			processRowNum(oSettings);
		}
	});

}

function handleMruChange(element) {
	var serviceResponse = "";
	try {
		$('#selSmartSch').val('');
	} catch (err) {

	}
	var formData = {
		'profileType' : element.value
	};
	$.ajax({
		headers : {
			'X-CSRF-Token' : csrf_token
		},

		url : contextPath + '/mru/assignment/getProfileTypeList',
		data : formData,
		type : 'POST',
		async : false,
		success : function(data) {
			serviceResponse = data;
			var $select = $('#profileTypeMruSelectName');
			$select.empty();
			for (var i = 0; i < serviceResponse.length; i++) {
				var o = $('<option/>', {
					value : serviceResponse[i].oprtrId
				}).text(serviceResponse[i].operatorFullName);
				o.appendTo($select);
			}
		},
		error : function() {
		}
	});
}

function handleDruChange(element) {
	var serviceResponse = "";
	var formData = {
		'profileType' : element.value
	};
	$.ajax({
		headers : {
			'X-CSRF-Token' : csrf_token
		},

		url : contextPath + '/cru/assignment/getProfileTypeList',
		data : formData,
		type : 'POST',
		async : false,
		success : function(data) {
			serviceResponse = data;
			var $select = $('#profileTypeDruSelectName');
			$select.empty();
			for (var i = 0; i < serviceResponse.length; i++) {
				var o = $('<option/>', {
					value : serviceResponse[i].oprtrId
				}).text(serviceResponse[i].operatorFullName);
				o.appendTo($select);
			}
		},
		error : function() {
		}
	});
}

function getDivisionVal(districtVal) {
	var formData = new FormData();
	formData.append("districttype", districtVal)
	appUtil.showMainLoading(true);
	$.ajax({
		headers : {
			'X-CSRF-Token' : csrf_token
		},
		url : contextPath + '/register/osc/getDistByDivList',
		dataType : 'script',
		cache : false,
		contentType : false,
		processData : false,
		data : formData,
		type : 'POST'
	}).done(function() {
		appUtil.showMainLoading(false);
	});
}

function getDivisionVal1(districtVal) {
	var serviceResponse = "";
	var formData = {
		'divisionCode' : districtVal.value
	};
	appUtil.showMainLoading(true);
	$.ajax({
		headers : {
			'X-CSRF-Token' : csrf_token
		},
		url : contextPath + '/register/osc/getDistByDivList',
		data : formData,
		type : 'POST',
		async : false,
		success : function(data) {
			serviceResponse = data;
			var $select = $('#districtCode');
			$select.empty();
			var p = $('<option/>', {
				value : ''
			}).text('-Please Select-').prop('selected', true);
			p.appendTo($select);
			for (var i = 0; i < serviceResponse.length; i++) {
				var o = $('<option/>', {
					value : serviceResponse[i].districtCode
				}).text(serviceResponse[i].districtDesc);
				o.appendTo($select);
			}
		},
		error : function() {
		}
	});
	appUtil.showMainLoading(false);
}

function smartSearch(element, URLname) {
	var serviceResponse = "";
	var formData = {
		'searchValue' : ''
	};
	$.ajax({
		headers : {
			'X-CSRF-Token' : csrf_token
		},

		url : contextPath + URLname,
		data : formData,
		type : 'POST',
		async : false,
		success : function(data) {
			serviceResponse = data;
			$(element).autocomplete({
				source : serviceResponse
			});

		},
		error : function() {
		}
	});
}

function restrictSpace() {
	if (event.keyCode == 32) {
		event.returnValue = false;
		return false;
	}
}
function removeNonAlphaNumeric(t) {
	var eleVal = document.getElementById(t.id);
	eleVal.value = eleVal.value.replace(/[^a-zA-Z\d\s]/g, '');
}

function changeToUpperCaseNoSpace(t) {
	var eleVal = document.getElementById(t.id);
	eleVal.value = eleVal.value.toUpperCase().replace(/ /g, '');
}

/** ******* added by asif start ************* */
// creating combo box for smart search
(function($) {
	$
			.widget(
					"custom.combobox",
					{
						_create : function() {
							this.wrapper = $("<span>").addClass(
									"custom-combobox")
									.insertAfter(this.element);

							this.element.hide();
							this._createAutocomplete();
						},

						_createAutocomplete : function() {
							var selected = this.element.children(":selected"), value = selected
									.val() ? selected.text() : "";

							this.input = $("<input>").appendTo(this.wrapper)
									.val(value).attr("title", "").attr("id",
											"selSmartSch").attr("name",
											"companyName").addClass(
											"form-control text-uppercase")
									// .attr( "size", "50px" )
									// .attr("class", "form-control
									// text-uppercase")
									.autocomplete({
										delay : 0,
										minLength : 0,
										source : $.proxy(this, "_source")
									}).tooltip({
										tooltipClass : "ui-state-highlight"
									});

							this._on(this.input, {
								autocompleteselect : function(event, ui) {
									ui.item.option.selected = true;
									this._trigger("select", event, {
										item : ui.item.option
									});
								},

								autocompletechange : "_removeIfInvalid"
							});
						},

						_source : function(request, response) {
							var matcher = new RegExp($.ui.autocomplete
									.escapeRegex(request.term), "i");
							response(this.element.children("option").map(
									function() {
										var text = $(this).text();
										if (this.value
												&& (!request.term || matcher
														.test(text)))
											return {
												label : text,
												value : text,
												option : this
											};
									}));
						},

						_removeIfInvalid : function(event, ui) {

							// Selected an item, nothing to do
							if (ui.item) {
								return;
							}

							// Search for a match (case-insensitive)
							var value = this.input.val(), valueLowerCase = value
									.toLowerCase(), valid = false;
							this.element
									.children("option")
									.each(
											function() {
												if ($(this).text()
														.toLowerCase() === valueLowerCase) {
													this.selected = valid = true;
													return false;
												}
											});

							// Found a match, nothing to do
							if (valid) {
								return;
							}

							// Remove invalid value
							this.input.val("").attr("title",
									value + " didn't match any item").tooltip(
									"open");
							this.element.val("");
							this._delay(function() {
								this.input.tooltip("close").attr("title", "");
							}, 2500);
							this.input.autocomplete("instance").term = "";
						},

						_destroy : function() {
							this.wrapper.remove();
							this.element.show();
						}
					});
})(jQuery);
/*
 * //appending combo box with drop down list //so drop down would hide n smart
 * select would be visible
 */

var currrentPathName = window.location.pathname;
$(function() {

	if (currrentPathName.indexOf("/pppab-portal/mru/assignment/new") != -1) {
		try {
			$("#profileTypeMruSelectName").combobox();
		} catch (e) {
		}
	}

	if (currrentPathName.indexOf("/pppab-portal/cru/assignment/new") != -1) {
		try {
			$("#profileTypeDruSelectName").combobox();
		} catch (e) {
		}
	}

});

/** ********* added by asif end **************** */
$('#dateSynPckr').datepicker({
		autoclose : true,
		todayHighlight : true,
		format : "dd/mm/yyyy",
		endDate : new Date()
	});
$('#dob').datepicker({
		autoclose : true,
		todayHighlight : true,
		format : "dd/mm/yyyy",
		endDate : new Date()
	});

$('#manualDataEntry').on('change', function(){
	   this.value = this.checked ? 1 : 0;
	}).change();

function readFile() {
	  
	  if (this.files && this.files[0]) {
	    
		  var max = 500000; // 500KB
		  var jpeg = "jpeg";
		  var jpg = "jpg";
		  var png = "png";
		  
		  var filename = document.getElementById("inp").value;
		  var res = filename.split('.').pop().toLowerCase()
		  var errFile = document.getElementById("errFile");
		  var errServer = document.getElementById("errImgServer");
		  
		  if(errServer != null){
				errServer.innerHTML="";
				errServer.style.display = "none";
			}
		  
		    if (this.files && this.files[0].size > max) {
		    	displayPopup("Read file error", "File too large.", "error info warning");
		        
		        var FR= new FileReader();
			    
			    FR.addEventListener("load", function() {
			    	document.getElementById("imgView").src = "/pppab-portal/images/no-document.png";
				    document.getElementById("b64").value = "/pppab-portal/images/no-document.png";
			    	document.getElementById("inp").value = "";
			    });  
			    
			    FR.readAsDataURL( this.files[0] );
		   	   
		   	}
		    else if (res != jpeg
					&& res != jpg 
					&& res != png) {
				 
				 errFile.innerHTML="Invalid file type!";
				 errFile.style.display = "block";
				    var FR1= new FileReader();
				    
				    FR1.addEventListener("load", function() {
				    	document.getElementById("imgView").src = "/pppab-portal/images/no-document.png";
					    document.getElementById("b64").value = "/pppab-portal/images/no-document.png";
				    	document.getElementById("inp").value = "";
				    }); 
				    
				    FR1.readAsDataURL( this.files[0] );
		    }
		    else{
		    	var FR2= new FileReader();
			    
			    FR2.addEventListener("load", function(e) {
			      document.getElementById("imgView").src = e.target.result;
			      document.getElementById("b64").value = e.target.result;
			    }); 
			    
			    FR2.readAsDataURL( this.files[0] );
			    
			    errFile.innerHTML="";
				errFile.style.display = "none";
		    }
	  }
	  
	}

function readFileObject() {
	
	  if (this.files && this.files[0]) {
		  var max = 500000; // 500KB
		  
			var jpeg = "jpeg";
			var jpg = "jpg";
			var png = "png";
			var pdf = "pdf";
			var filename = document.getElementById("inputFileObject").value;
			var res = filename.split('.').pop().toLowerCase()
			var errFile = document.getElementById("errFile");
			var errServer = document.getElementById("errFileServer");
			
			if(errServer != null){
				errServer.innerHTML="";
				errServer.style.display = "none";
			}
			
			if (this.files && this.files[0].size > max) {
				errFile.innerHTML="File size too large!";
				errFile.style.display = "block";
				var FR= new FileReader();
				    
				FR.addEventListener("load", function() {
					document.getElementById("objectView").data = "/pppab-portal/images/no-document.png";
					document.getElementById("objectStore").value = "/pppab-portal/images/no-document.png";
				}); 
				    
				FR.readAsDataURL( this.files[0] );
			}
			else if (res != jpeg
					&& res != jpg 
					&& res != png
					&& res != pdf) {
				 
				 errFile.innerHTML="Invalid file type!";
				 errFile.style.display = "block";
				    var FR1= new FileReader();
				    
				    FR1.addEventListener("load", function() {
				      document.getElementById("objectView").data = "/pppab-portal/images/no-document.png";
				      document.getElementById("objectStore").value = "/pppab-portal/images/no-document.png";
				    }); 
				    
				    FR1.readAsDataURL( this.files[0] );
			
			}else{
				    	var FR2= new FileReader();
				        
				    	FR2.addEventListener("load", function(e) {
						      document.getElementById("objectView").data = e.target.result;
						      document.getElementById("objectStore").value = e.target.result;
				        }); 
				        
				        FR2.readAsDataURL( this.files[0] );
				        
				        errFile.innerHTML="";
						errFile.style.display = "none";
				    }
	  }
	  }
	  

var imageUpload = document.getElementById('inp');

if(imageUpload){
	imageUpload.addEventListener('change', readFile, false);
}

var objectUpload = document.getElementById('inputFileObject');

if(objectUpload){
	objectUpload.addEventListener('change', readFileObject, false);
}

// Get the modal
var modal = document.getElementById('myModal');

function validateFunction(id) {
    var x = document.getElementById(id);
    var objName;
    var msj = document.getElementById("msj");
	
	if (id == 'pasportNo') {
		objName = 'Passport No.'; 
	} else if (id == 'lastName') {
		objName = 'Last Name'; 
	} else if (id == 'firstName') {
		objName = 'First Name'; 
	}
	
    if(x.value != null && x.value!=''){
    	$(modal).attr("data-validate",id);
    	msj.innerHTML="Please Confirm " + objName + " <span id='popupFieldId' hidden>"+id+"</span>";
        modal.style.display = "block";
        document.getElementById("value2").focus();
    }
}

// When Update valu
function onCheckValue(){
	var type = $(modal).attr('data-validate');
	
	var firtName = document.getElementById(type);
	var checkValue = document.getElementById("value2");
	var msg = document.getElementById("message");
	var tempId = '#'+type+'Temp';

	var objName;
	
	if (type == 'pasportNo') {
		objName = 'Passport No.'; 
	} else if (type == 'lastName') {
		objName = 'Last Name'; 
	} else if (type == 'firstName') {
		objName = 'First Name'; 
	}

	if(firtName.value.toUpperCase()==checkValue.value.toUpperCase()){
		modal.style.display = "none";
		checkValue.value=null;
		msg.style.display = "none";
		$(tempId).val(firtName.value);
	}else if(checkValue.value!=null){
		msg.style.display = "block";
		msg.innerHTML="* Wrong  " + objName + ". Please check the " + objName;
		
	}
}

function onCancelPopup(){
	var type = $(modal).attr('data-validate');
	var firtName = document.getElementById(type);
	var checkValue = document.getElementById("value2");
	var msg = document.getElementById("message");
	var popupId = $('#popupFieldId').text();
	var fieldTemp = $('#'+popupId+'Temp').val();
	if (fieldTemp === undefined) {
		fieldTemp = '';
	}
	firtName.value = fieldTemp;
	checkValue.value=null;
	msg.style.display = "none";
	modal.style.display = "none";
}

// Get the modal
var radioMmodal = document.getElementById('radioModal');


function genderValidate(id) {
    $(radioMmodal).attr("data-validate",id);
    radioMmodal.style.display = "block";
    msjRadio.innerHTML="Please Confirm Gender";
    document.getElementById("currentMale").focus();
   
}

function onCheckGenValue(){
	var type = $(radioMmodal).attr('data-validate');
	var firtName = document.getElementById(type);
	var msgGen = document.getElementById("messageGen");
	var checkValue = $('input[name="genderPopup"]:checked').val();
	
	if (firtName.value == "F") {
		// checkValue = document.getElementById("female2");
		if(firtName.value==checkValue){
			$('input[name="genderPopup"]').removeProp('checked');
			radioMmodal.style.display = "none";
			msgGen.innerHTML="";
		}else {
			msgGen.innerHTML="* Wrong Gender. Please check the Gender";
			msgGen.style.display = "block";
			$('input[name="genderPopup"]').removeProp('checked');

		}
	}else{
		// checkValue = document.getElementById("male2");
		if(firtName.value==checkValue){
			radioMmodal.style.display = "none";
			msgGen.innerHTML="";
			$('input[name="genderPopup"]').removeProp('checked');
		}else {
			msgGen.innerHTML="* Wrong Gender. Please check the Gender";
			msgGen.style.display = "block";
			$('input[name="genderPopup"]').removeProp('checked');

		}
	}
	
}

function onCancelGenPopup(){
	radioMmodal.style.display = "none";
	messageGen.innerHTML="";
	
}


// Get the modal
var countryMmodal = document.getElementById('countryMmodal');
var labelCountryName;

function countryValidate(id) {
    var e = document.getElementById(id);
    var strUser = e.options[e.selectedIndex].value;
    
    var msjCon = document.getElementById("msjCon");
    
    if(id == 'nationality'){
    	labelCountryName = 'Nationality';
    }
    else{
    	labelCountryName = 'Country Issue';
    }
	
    $(countryMmodal).attr("data-validate",strUser);
    
    if(strUser!=""){
    	msjCon.innerHTML="Please Confirm " + labelCountryName + " <span id='popupId' hidden>"+id+"</span>";
    	countryMmodal.style.display = "block";
    	document.getElementById("selectModal").focus();
    	
    }
}

function onCheckConValue(){
	var type = $(countryMmodal).attr('data-validate');
	// var firtName = document.getElementById(type);
	var messageCon = document.getElementById("messageCon");
	var checkValue = $('option[name="countryPopup"]:checked').val();
	
	if(type==checkValue){
		countryMmodal.style.display = "none";
		messageCon.innerHTML= "";
		$('option[name="countryPopup"]').removeAttr('selected');
	}else{
		messageCon.style.display = "block";
		messageCon.innerHTML="* Wrong " + labelCountryName + ". Please check the " + labelCountryName;
		$('option[name="countryPopup"]').removeAttr('selected');
	}
}

function onCancelConPopup(){
	countryMmodal.style.display = "none";
	messageCon.innerHTML= "";

}


var currentIndex = 0,
items = $('.container_image div'),
itemAmt = items.length;

function cycleItems() {
var item = $('.container_image div').eq(currentIndex);
items.hide();
item.css('display','inline-block');
}

function isValidDate(str) {
    var parts = str.split('/');
    if (parts.length < 3)
        return false;
    else {
        var day = parseInt(parts[0]);
        var month = parseInt(parts[1]);
        var year = parseInt(parts[2]);
        if (isNaN(day) || isNaN(month) || isNaN(year)) {
            return false;
        }
        if (day < 1 || year < 1 || year < 999 || year > 9999)
            return false;
        if(month>12||month<1)
            return false;
        if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) && day > 31)
            return false;
        if ((month == 4 || month == 6 || month == 9 || month == 11 ) && day > 30)
            return false;
        if (month == 2) {
            if (((year % 4) == 0 && (year % 100) != 0) || ((year % 400) == 0 && (year % 100) == 0)) {
                if (day > 29)
                    return false;
            } else {
                if (day > 28)
                    return false;
            }      
        }
        return true;
    }
}

function validateNamePattern() 
{
            var charCode = event.keyCode;

            return ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || 
            	charCode == 8 || charCode == 32 || charCode == 50 || (event.shiftKey == true && charCode == 64));
}

function validatePassportPattern() 
{
            var charCode = event.keyCode;

            return ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || 
            	charCode == 8 || (charCode > 47 && charCode < 58));
}

function getAge(dateString) {
	var dateForm = dateString.substring(3,5) + '/' + dateString.substring(0,2) + '/' + (dateString.substring(6,10) - 1);
	var birth = new Date(dateForm);
	var check = new Date();

	var milliDay = 1000 * 60 * 60 * 24; // a day in milliseconds;


	var ageInDays = (check - birth) / milliDay;

	var ageInYears =  Math.floor(ageInDays / 365 );
	
 /*
	 * var today = new Date(); var birthDate = new Date(dateString); var age =
	 * today.getFullYear() - birthDate.getFullYear(); var m = today.getMonth() -
	 * birthDate.getMonth(); if (m < 0 || (m === 0 && today.getDate() <
	 * birthDate.getDate())) { age--; }
	 */
    return ageInYears;
}
/** ***IMAGE SLIDER ***** */

$('.slider span.next').click(function() {
	  let $current = $(this).siblings('img.active');
	  let $next = $current.next('img');
	  if ($next.length != 0) {
	    $current.removeClass('active');
	    $next.addClass('active');
	  }
	})
	$('.slider span.prev').click(function() {
	  let $current = $(this).siblings('img.active');
	  let $prev = $current.prev('img');
	  if ($prev.length != 0) {
	    $current.removeClass('active');
	    $prev.addClass('active');
	  }
	})
	
 $("#selectTag").change(function () {
        if ($("#selectTag").val() == 'email') {
        	$("#emailInput").show();
        	$("#mobileInput").hide();
        } else if ($("#selectTag").val() == 'mobile') {
        	$("#emailInput").hide();
        	$("#mobileInput").show();
        } else {
        	$("#emailInput").hide();
        	$("#mobileInput").hide();
        }
    });

function deleteTag(tagId) {
	portalUtil.showConfirm("Are you sure to delete this record?", function(bool) {
		if(bool) {
	    	var method = "";
	    	var inputUrl = "";
	    	method = "DELETE";
	    	inputUrl = contextPath + '/blacklist/delete/'+ tagId;
	    	
	    	$.ajax({
	    		headers: { 'X-CSRF-Token': csrf_token },
	    		type: method, 
	    		url: inputUrl, 
	    	}).done(function() {
	    		console.log("Record is deleted");
	    		location.href = contextPath + "/blacklist";
	    	})
		}
	});
}

$("#blcklstSelectTag").change(function () {
    if ($("#blcklstSelectTag").val() == 'email') {
    	$("#blcklstEmailInput").show();
    	$("#blcklstMobileInput").hide();
    } else if ($("#blcklstSelectTag").val() == 'mobile') {
    	$("#blcklstEmailInput").hide();
    	$("#blcklstMobileInput").show();
    } else {
    	$("#blcklstEmailInput").hide();
    	$("#blcklstMobileInput").hide();
    	$("input#blcklstEmail").val("");
    	$("input#blcklstMobile").val("");

    }
});

$('#blcklstRst').bind('click', function() {
	$("input#blcklstEmail").val("");
	$('select#blcklstSelectTag').val("");
	$('input#blcklstMobile').val("");
});

function documentPopupDateRangeReport(url, title, type) {
	console.log(' documentPopupDateRangeReport')
	var fromDate = $("input#applctnDtFromPckr").val();
	var toDate = $("input#applctnDtToPckr").val();
	var status = $('select#selectStatus').val();
	var addField = $('select#selectAddField').val();


	url = url+'?fromDate='+fromDate+'&toDate='+toDate + '&status=' + status 
	+ '&addField=' + addField;
	documentPopup(url, title, type);
}

function documentPopupDailyReport(url, title, type) {
	console.log(' documentPopupDailyReport')
	var status = $('select#selectStatus').val();
	var addField = $('select#selectAddField').val();


	url = url+'?status=' + status + '&addField=' + addField;
	documentPopup(url, title, type);
}

/** *** Added by Atiqah ***** */
$('#startContractDate').datepicker({
	autoclose : true,
	todayHighlight : true,
	format : "dd/mm/yyyy",
	startDate : new Date(),
});

$('#expireDate').datepicker({
	autoclose : true,
	todayHighlight : true,
	format : "dd/mm/yyyy",
	startDate: new Date(),
});

$('#startContractDate').datepicker().on(
		'changeDate',
		function(ev) {
		var minDate = new Date(ev.date.valueOf());
		$('#expireDate').datepicker('setStartDate',minDate);
 });

// $(function(){
// console.log($('select#selectIdorClass').val())
// for (i=50;i<=100;i++){
// $('#selectIdorClass').append($('<option></option>').val(i).html(i))
// }
// });

$(function(){
	for (let i=1;i<=7;i++){
		$('#selectReserveDay').append($('<option></option>').val(i).html(i))
	}
});

$('#vKeyButton').bind('click', function() {
    var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
    var string_length = 32;
    var randomstring = '';
    for (var i = 0; i < string_length; i++) {
        var rnum = Math.floor(Math.random() * chars.length);
        randomstring += chars.substring(rnum, rnum + 1);
    }
	$('input#verifyKey').val(randomstring);
});

if ($('#addNewCat').is(":checked")) {
	$('#newMerCat').show()		
}

$('#addNewCat').bind('click', function(){
	if($(this).is(":checked")){
		$('#newMerCat').show()		
	} else {
		$('#newMerCat').hide()	
	}
})

if ($('#weeklyMode').is(":checked")) {
	$('#settleDay').val("Monday")		
}

$('#weeklyMode').bind('click', function() {
	$('#settleDay').val("Monday")	
})

function amountSetTwoDecimal(event) {
	if(event.value) {
		event.value = parseFloat(event.value).toFixed(2);
	}
}

$(document).on(
		'keypress',
		'.alphaOnly',
		function(e) {
			var key = e.charCode;
			  return (key > 64 && key < 91) || (key > 96 && key < 123) || (key > 31 && key < 33);
		});


if ($('#cc_email1').is(":checked")) {
	$('.ccemailto').show()		
}

$('#cc_email1').bind('click', function(){
	console.log($('.ccemailto'));
	if($(this).is(":checked")){
		$('.ccemailto').show()		
	} else {
		$('.ccemailto').hide()	
	}
})

if($('#transactionRate').val()) {
	$('#transactionRate').val(parseFloat($('#transactionRate').val()).toFixed(2));
}

if($('#transactionFee').val()) {
	$('#transactionFee').val(parseFloat($('#transactionFee').val()).toFixed(2));
}

if($('#settlementFee').val()) {
	$('#settlementFee').val(parseFloat($('#settlementFee').val()).toFixed(2));
}

if($('#minSettleAmt').val()) {
	$('#minSettleAmt').val(parseFloat($('#minSettleAmt').val()).toFixed(2));
}

if($('#maxAmt').val()) {
	$('#maxAmt').val(parseFloat($('#maxAmt').val()).toFixed(2));
}

if($('#minAmt').val()) {
	$('#minAmt').val(parseFloat($('#minAmt').val()).toFixed(2));
}

if($('#transRate').val()) {
	$('#transRate').val(parseFloat($('#transRate').val()).toFixed(2));
}

if($('#billAmt').val()) {
	let billAmt = $('#billAmt').val().split(' ');
	let currency = billAmt[0] != "null" ? billAmt[0] : '';
	let amount = billAmt[1] != "null" ? parseFloat(billAmt[1]).toFixed(2) : ' -';
	$('#billAmt').val(currency + ' ' + amount);
}

if($('#actAmt').val()) {
	let actAmt = $('#actAmt').val().split(' ');
	let currency = actAmt[0] != "null" ? actAmt[0] : '';
	let amount = actAmt[1] != "null" ? parseFloat(actAmt[1]).toFixed(2) : '';
	$('#actAmt').val(currency +  ' ' + amount);
}
	
/*
 * for (i = 0; i < noOfChannel; i++) { if ($('#merChanSetschannel' +
 * i).is(":checked")) { if($('#merChanSetsrate').val()) { $('#merChanSetsrate' +
 * i).val(parseFloat($('#merChanSetsrate' + i ).val()).toFixed(2)); }
 * 
 * if($('#merChanSetscost').val()) { $('#merChanSetscost' +
 * i).val(parseFloat($('#merChanSetscost' + i).val()).toFixed(2)); } } }
 */
	
	$(document).ready(function(){
		if($("#accStatus").val() == '')
			$("#accStatus").val('INACTIVE');
		
		if($("#country").val() == '') {
			$("#country").val('MYS');
			onChangeCountry();
		}else if($("#country").val() == 'MYS'){
			onChangeCountry();
			onChangeStateMy();
		}
	});

	function onSelectAccType() {
		
		var statusCode = $('#accType').val();
		var paramValue;
		if(statusCode == 'COM'){
			paramValue = "ICTYPE_COM";
			$("#idType").prop("disabled",false);
		}else if (statusCode == ''){
			paramValue = "ICTYPE";
			$("#idType").prop("disabled",true);
			$("#icNumber").prop("disabled",true);
		}else if (statusCode == 'IND'){
			paramValue = "ICTYPE_IND";
			$("#idType").prop("disabled",false);
		}
		
		var currentPath=_contextPath1.origin+'/bestpay-portal-admin/account-info/search/'+paramValue;
		  $.ajax({
				method : "POST",
				url : currentPath,
				action : 'xhttp',
				headers: { 'X-CSRF-Token': csrf_token },
				async: false,
				success : function(response) {
					var options = [];
					var result = JSON.parse(response);
					var cSelect = document.getElementById("idType"); 
			        while (cSelect.options.length > 0) { 
			        	 cSelect.remove(0); 
			        	 } 
			        if(result) {
			        	options.push('<option value="">- Please Select -</option>');
			        	for (var i in result) {
			    			options.push('<option value="'+result[i].statusCode+'">'+result[i].statusDescEn+ '</option>');
			        	}
			        	$('#idType').html(options.join(''));
			        }
				}
			});
		
		
	}
	
	function documentTransDetailsReport(url, title, type) {
		console.log(' documentTransDetailsReport')
		var transId = $('#transId').val();
		console.log(transId);
		url = url+'?transId='+transId;
		documentPopup(url, title, type);
	}
	
	function documentPopupSettlementReport(url, title, type) {
		console.log(' documentPopupSettlementReport');
		var sttleDateFrom = $('input#applctnDtFromPckr').val();
		var sttleDateTo = $('input#applctnDtToPckr').val();

		url = url+'?sttleDateFrom=' + sttleDateFrom + '&sttleDateTo=' + sttleDateTo;
		documentPopup(url, title, type);
	}
	
// if ($('#psa').is(":checked")) {
// $('#bankName').addClass('required');
// $('#accountName').addClass('required');
// $('#accountNum').addClass('required');
// }
	
// $('#psa').bind('click', function(){
// if($(this).is(":checked")){
// $('#bankName').addClass('required');
// $('#accountName').addClass('required');
// $('#accountNum').addClass('required');
// } else {
// $('#bankName').removeClass('required');
// $('#accountName').removeClass('required');
// $('#accountNum').removeClass('required');
// }
// })
	
	function onChangeCountry() {
	var countryCode = $('#country').val();
	console.log(countryCode)
	$
			.ajax({
				method : "POST",
				headers : {
					'X-CSRF-Token' : csrf_token
				},
				action : 'xhttp',
				url : contextPath + "/static-list/state",
				data : {
					'countryCode' : countryCode
				},
				async : false
			})
			.done(
					function(data) {

						var options = [];
						var result = JSON.parse(data);

						if (result) {
							options
									.push('<option value="">- Please Select -</option>');
							for ( var i in result) {
								options.push('<option value="',
										result[i].stateCode, '">',
										result[i].stateDesc, '</option>');
							}
							$("#state").html(options.join(''));
						}
						
						if(countryCode != 'MYS'){
							$('#stateNonMy').show()	
							$('#stateMy').hide()	
							$('#cityNonMy').show()	
							$('#cityMy').hide()	
						}else{
							$('#stateMy').show()	
							$('#stateNonMy').hide()	
							$('#cityMy').show()	
							$('#cityNonMy').hide()
						}
							
					});
	
	if (document.getElementById('chargeAmount').value != '') {
		document.getElementById('chargeAmount').value = parseFloat(
				document.getElementById('chargeAmount').value).toFixed(2);
	}
}
	
	function onChangeStateMy() {
		var stateCode = $('#stateMy').val();
		var cityCode1 = $('#cityMy').val();
		$
		.ajax({
			method : "POST",
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			action : 'xhttp',
			url : contextPath + "/static-list/city",
			data : {
				'stateCode' : stateCode
			},
			async : false
		})
		.done(
				function(data) {
					
					var options = [];
					var result = JSON.parse(data);
					if (result) {
						options
						.push('<option value="">- Please Select -</option>');
						for ( var i in result) {
							options.push('<option value="',
									result[i].cityCode, '">',
									result[i].descEn, '</option>');
						}
						$("#cityMy").html(options.join(''));
					}
					
				});
		$('select option[value='+cityCode1+']').prop("selected",true);
	}
	
	

	// for Bank list service
	
	function getBankList(obj,inputURL){
		
		if (typeof obj === "undefined"){
			console.log(obj);
		}
		
		var b4u_merchantId = $('#merchantId').val();
		if(b4u_merchantId==''){
			checkMerchant()
			return;
		}
		console.log("url =", inputURL)
		console.log("b4u_merchantId: "+b4u_merchantId);
		
	   portalUtil.showMainLoading(true);
	  
	  
	   
	   var payType = $('input[name="payMethod"]:checked').val();  
	   console.log("payType :::: "+payType);
	   
		var hashKeyURL = contextPath+ "/mer_fpx_paylink/getHashKey";
		var reqhash = null;
	   $.ajax({
			headers : {
				'X-CSRF-Token' : csrf_token
			},
			type : "GET",
			action : 'xhttp',
			url : hashKeyURL,
			data: {
					'merchantId' : b4u_merchantId,
					'payMethod' : payType
				  },
			success : function(data) {
				console.log("success : "+data);
				$('#reqhash').val(data);
				reqhash  = data;
				
			}
		}).done(function() {
			$.ajax({
				headers : {
					'X-CSRF-Token' : csrf_token
				},
				
				
				cache : false,
				type : "POST",
				contentType: 'application/json; charset=utf-8',
				action : 'xhttp',
				url : inputURL,
				
				data:JSON.stringify( {
					'b4u_merchantId':b4u_merchantId,
					'b4u_payMethod':payType,
					'b4u_reqhash':reqhash
				}),
				success : function(data) {
					console.log("success: "+data);
				}
			}).done(function(data) {
				
				console.log("done");
				var bankList = data.bankList;
				
				
				let $select = $("#bankCode");
				$select.empty();
				$('#bankCode').niceSelect('destroy');
				var option=$("<option value ='' selected='selected'>Select Bank </option>");
				
				option.appendTo($("#bankCode"))
				
				if(bankList!=null && bankList.length !=0){
					
					for(var s=0;s<bankList.length;s++)
					{
						
						if(bankList[s].bankCode==""){
							option=$("<option value ='"+bankList[s].bankCode+"'>"+bankList[s].bankName +" [Offline]"+"</option>");
						}
						else{
							option=$("<option value ='"+bankList[s].bankCode+"'>"+bankList[s].bankName +"</option>");
						}
						
						option.appendTo($("#bankCode"))
						// option.appendTo($("#bankName"))
						
					}
				}
				
				$('#bankCode').niceSelect('update');
				$('#bankCode').niceSelect();
				
				portalUtil.showMainLoading(false);
				checkMerchant();
			});
		});
	   
	   
		
	}

	$( document ).ready(function() {
		// getBankList();
	});


	function selectBankName(){
		var bankName = $("#bankCode :selected").text();
		$('#bankName').val(bankName);
	}
	
function checkMerchant(){
		
		var validErr = "Validation Error";
		var message = '';
		var type = "error info warning";
		
		var b4u_merchantId = $('#merchantId').val();
		if(b4u_merchantId==''|| b4u_merchantId== null ){
			message = "Merchant Id is empty, please provide";
			displayPopup(validErr, message, type);
			return;
		
		}
}

	function checkBankName(){
		
		var validErr = "Validation Error";
		var message = '';
		var type = "error info warning";
		
		var b4u_merchantId = $('#merchantId').val();
		if(b4u_merchantId==''){
			message = "Merchant Id is empty, please select merchant Id";
			displayPopup(validErr, message, type);
			return;
		}
		
	/*
	 * var b4u_bankName = $('#bankName').val(); if(b4u_bankName==''){ message =
	 * "Bank Name is empty, please provide"; displayPopup(validErr, message,
	 * type); return; }
	 */
		var b4u_amount = $('#amount').val();
		if(b4u_amount==''){
			validErr = "Amount Error";
			message = "please enter amount";
			displayPopup(validErr, message, type);
			return;
		}
		var bankCode = $('#bankCode').val();
		bankCode = $.trim(bankCode);
		
		var len = bankCode.length;
		
		if(bankCode==''){
			validErr = "Bank Error";
			message = "please select bank from list";
			displayPopup(validErr, message, type);
			return;
		}
		if(len<=0){
			validErr = "Bank Error";
			message = "Selected Bank is deactivated, please select other bank from list";
			displayPopup(validErr, message, type);
			return;
		}
		
		$('#formsubmitId').submit();
	}	

	function displayPopup(validErr, message, type){
		$('#message_modal_title_id').html(validErr);
		$('#message_modal_body_id').html(message);
		$('#message_modal').addClass(type).modal('show');
		return true;
	}
	
	function settlementInvoice(url, title, type) {
		console.log(' settlementInvoice')
		var settlementId = $('#settlementId').val();
		console.log(settlementId);
		url = url+'?settlementId='+settlementId;
		documentPopup(url, title, type);
	}
	
	function settlementReceipt(url, title, type) {
		console.log(' settlementInvoice')
		var settlementId = $('#settlementId').val();
		console.log(settlementId);
		url = url+'?settlementId='+settlementId;
		documentPopup(url, title, type);
	}
	
	$("#resetCmsChannel").click(function(){
		  document.location.reload();
		});
	