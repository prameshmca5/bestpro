$(document).ready(function() {
	var start = $('input[name="createDtFrom"]').val('');
    var end =  $('input[name="createDtTo"]').val('');
    function cb(start, end) {
        if(start) {
            $('input[name="createDtFrom"]').val(start.format('DD/MM/YYYY'));            
        }
        
        if(end) {
            $('input[name="createDtTo"]').val(end.format('DD/MM/YYYY'));            
        }
    }

    $('#createDtRange').daterangepicker({
        minDate: moment("2020-01-01"),
        startDate: start,
        endDate: end,
        minYear: 2019,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    });

    $('#createDtRange').on('apply.daterangepicker', function(ev, picker) {
        $('input[name="createDtFrom"]').val(picker.startDate.format('DD/MM/YYYY'));   
        $('input[name="createDtTo"]').val(picker.endDate.format('DD/MM/YYYY'));   
    });

    $('#createDtRange').on('cancel.daterangepicker', function(ev, picker) {
        $('input[name="createDtFrom"]').val('');   
        $('input[name="createDtTo"]').val('');   
    });
    
    var oTblDocLst = $('#tblDocLst').DataTable({
    	"processing" : true,
    	"serverSide" : true,
    	'responsive' : true,
    	'destroy' : true,
    	"columns" : [ 
    		{ "data": null, "searchable" : false, "orderable" : false },
    		{ "data" : "departureDt",
    		"render" : function(data, type, row) {
    			if (data) {
    				var date = new Date(data);
    				var dd = date.getDate();
    				var mm = date.getMonth() + 1;
    				var yyyy = date.getFullYear();

    				if (dd < 10) {
    					dd = "0" + dd;
    				}
    				if (mm < 10) {
    					mm = "0" + mm;
    				}

    				return dd + "/" + mm + "/" + yyyy;
    			}
    			return "-";
    		},
    	}, 
    	{
    		"data" : "identityNo",
    		"render" : function(data, type, row) {
    			return data || "-";
    		},
    	}, 
    	{
    		"data" : "fullName.toUpperCase()",
    		"render" : function(data, type, row) {
    			return data || "-";
    		},
    	},
    	{
    		"data" : "isActive",
    		"render" : function(data, type, row) {
    			return data.isActive ? "ACTIVE" : "EXPIRED";
    		},
    	}, 
    	 { "data": null, "searchable" : false, "orderable" : false, 
          	"render": function ( data, type, row ) {
//          		return "haha";
          		var transferCase ='<center><a title="View Profile" class="mr-2" href=' + contextPath + '/tvlHstry/'+  row.docProfId +' ><i class="fa fa-exchange fa-lg"></i></a>';
          		transferCase += '<a title="View Profile" class="mr-2" href=' + contextPath + '/refund/updateStatus/'+ row.docProfId +' ><i class="fa fa-edit fa-lg"></i></a></center>';
          		return transferCase;
          	}
    	}, ],
    	"ajax" : $.fn.dataTable.pipeline({
    		"pages" : 1,
    		"type" : "GET",
    		"url" : contextPath + "/searchDr/paginated",
    		"action" : 'xhttp',
    		'beforeSend' : dtRequestHeader,
    		"dataSrc" : dtDataSrc,
    		"data" : function(data) {
//    			data.createDtFrom = $('input[name="createDtFrom"]').val();
//            	data.createDtTo = $('input[name="createDtTo"]').val();
//            	data.identityNo = $("#identityNo").val();
//            	data.fullName = $("#fullName").val();        	
//            	data.status = $("#status").val();
    		},
    		"error" : function() { // error handling
    		}
    	}),

    	"initComplete": function(settings, json) {
      		$('input#createDtFrom').unbind();
      		$('input#createDtTo').unbind();
    		$('input#identityNo').unbind();
      		$('input#fullName').unbind();  		  		
      		$('input#status').unbind();
      		$('#searchFilter').bind('click', function(e) {
            	portalUtil.showMainLoading(true);
            	oTblDocLst
                .column(1).search($('input[name="createDtFrom"]').val())
                .column(1).search($('input[name="createDtTo"]').val())
                .column(2).search($('input#identityNo').val())
                .column(3).search($('input#fullName').val())
                .column(4).search($('input#status').val())
                oTblDocLst.draw();
            	$(".em-toggle").click();
            });
      		$('#searchClear').bind('click', function(e) {
      			$('input[name="createDtFrom"]').val("")
            	$('input[name="createDtTo"]').val("")
            	$('input#identityNo').val("")
            	$('input#fullName').val("")
            	$('input#fullName').val("")
            	$('input#status').val("")
    			oTblDocLst.columns().search("").draw();
    			$(".em-toggle").click();
    		});
           
        },
        "language" : {
			"emptyTable" : prop.dtbEmptyTable
		},
    	"fnDrawCallback" : function(oSettings) {
    		processRowNum(oSettings);
    		hidePagination(this, "#tblTvlHome");
    		portalUtil.showMainLoading(false);
    	}
    });
    
});