/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;


/**
 * @author michelle.angela
 *
 */
public class McCollate implements Serializable {

	private static final long serialVersionUID = 4728679881929207934L;

	private Integer mcCollateId;

	private TvlTestResult tvlTestResult;

	private ConfigMcCollate configMcCollate;

	private Metadata resultMtdt;

	private Integer mtdtId;

	public Integer getMcCollateId() {
		return mcCollateId;
	}


	public void setMcCollateId(Integer mcCollateId) {
		this.mcCollateId = mcCollateId;
	}


	public TvlTestResult getTvlTestResult() {
		return tvlTestResult;
	}


	public void setTvlTestResult(TvlTestResult tvlTestResult) {
		this.tvlTestResult = tvlTestResult;
	}


	public ConfigMcCollate getConfigMcCollate() {
		return configMcCollate;
	}


	public void setConfigMcCollate(ConfigMcCollate configMcCollate) {
		this.configMcCollate = configMcCollate;
	}


	public Metadata getResultMtdt() {
		return resultMtdt;
	}


	public void setResultMtdt(Metadata resultMtdt) {
		this.resultMtdt = resultMtdt;
	}


	public Integer getMtdtId() {
		return mtdtId;
	}


	public void setMtdtId(Integer mtdtId) {
		this.mtdtId = mtdtId;
	}

}
