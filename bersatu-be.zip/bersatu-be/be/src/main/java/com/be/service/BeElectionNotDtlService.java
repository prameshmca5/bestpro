/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.be.service;


import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeElectionNotDtlQf;
import com.be.dao.BeElectionNotDtlRepository;
import com.be.model.BeElectionNotDtl;
import com.be.sdk.model.ElectionNotDtl;
import com.be.sdk.model.IQfCriteria;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;


/**
 * @author mohd.naem
 * @since March 31 , 2021
 */
@Service(QualifierConstants.BE_ELECTION_NOT_DTL_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_ELECTION_NOT_DTL_SVC)
@Transactional
public class BeElectionNotDtlService extends AbstractService<BeElectionNotDtl> {

	protected static Logger logger = LoggerFactory.getLogger(BeElectionNotDtlService.class);

	@Autowired
	private BeElectionNotDtlRepository beElectionNotDtlDao;

	@Autowired
	private BeElectionNotDtlQf beElectionNotDtlQf;


	@Override
	public GenericRepository<BeElectionNotDtl> primaryDao() {
		return beElectionNotDtlDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return null;
	}


	public long getCount(ElectionNotDtl dto) {
		return beElectionNotDtlQf.getCount(dto);
	}


	@SuppressWarnings("unchecked")
	public List<ElectionNotDtl> searchPagination(ElectionNotDtl dto, DataTableRequest<?> dataTableInRQ)
			throws IOException {
		return JsonUtil.transferToList(beElectionNotDtlQf.searchAllByProperty(dto, dataTableInRQ),
				ElectionNotDtl.class);
	}

}