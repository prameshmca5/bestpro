/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.sgw.controller;


import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import com.bestid.be.sdk.client.BeServiceClient;
import com.bestid.sgw.constants.ProjectEnum;
import com.bestid.sgw.constants.SgwTxnCodeConstants;
import com.bstsb.dm.sdk.client.DmServiceClient;
import com.bstsb.idm.sdk.client.IdmServiceClient;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
public abstract class AbstractRestController {

	@Autowired
	protected MessageSource messageSource;

	@Autowired
	protected Mapper dozerMapper;

	@Autowired
	protected IdmServiceClient idmService;

	@Autowired
	protected BeServiceClient beService;

	@Autowired
	private DmServiceClient dmService;


	public IdmServiceClient getIdmService(HttpServletRequest request) {
		String messageId = request.getHeader(SgwTxnCodeConstants.HEADER_MESSAGE_ID);
		if (messageId == null) {
			messageId = String.valueOf(UUID.randomUUID());
		}
		String auth = request.getHeader(SgwTxnCodeConstants.HEADER_AUTHORIZATION);
		idmService.setAuthToken(auth);
		idmService.setMessageId(messageId);
		return idmService;
	}


	public BeServiceClient getBeService(HttpServletRequest request) {
		String messageId = request.getHeader(SgwTxnCodeConstants.HEADER_MESSAGE_ID);
		if (messageId == null) {
			messageId = String.valueOf(UUID.randomUUID());
		}
		String auth = request.getHeader(SgwTxnCodeConstants.HEADER_AUTHORIZATION);
		beService.setAuthToken(auth);
		beService.setMessageId(messageId);
		return beService;
	}


	public DmServiceClient getDmService(HttpServletRequest request, ProjectEnum project) {
		if (project != null) {
			dmService.setProjId(project.getName());
		}
		String messageId = request.getHeader(SgwTxnCodeConstants.HEADER_MESSAGE_ID);
		if (messageId == null) {
			messageId = String.valueOf(UUID.randomUUID());
		}
		String auth = request.getHeader(SgwTxnCodeConstants.HEADER_AUTHORIZATION);
		dmService.setAuthToken(auth);
		dmService.setMessageId(messageId);
		return dmService;
	}

}