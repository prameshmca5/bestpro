package com.bestpay.be.sdk.model;


public class RegisterCustomerRequest {

	private String senderFirstName;

	private String senderMiddleName;

	private String senderLastName;

	private String senderGender;

	private String senderAddress;

	private String senderCity;

	private String senderState;

	private String senderCountry;

	private String senderZipCode;

	private String senderMobile;

	private String senderIDType;

	private String senderIDNumber;

	private String idIssuePlace;

	private String idIssueDate;

	private String idExpireDate;

	private String senderIdType2;

	private String senderIdNumber2;

	private String senderNativeCountry;

	private String senderDateOfBirth;

	private String senderOccupation;

	private String senderEmployerName;

	private String senderEmployerType;

	private String senderFundSource;

	private String senderPhoto;

	private String senderPhoto1;


	public String getSenderFirstName() {
		return senderFirstName;
	}


	public void setSenderFirstName(String senderFirstName) {
		this.senderFirstName = senderFirstName;
	}


	public String getSenderMiddleName() {
		return senderMiddleName;
	}


	public void setSenderMiddleName(String senderMiddleName) {
		this.senderMiddleName = senderMiddleName;
	}


	public String getSenderLastName() {
		return senderLastName;
	}


	public void setSenderLastName(String senderLastName) {
		this.senderLastName = senderLastName;
	}


	public String getSenderGender() {
		return senderGender;
	}


	public void setSenderGender(String senderGender) {
		this.senderGender = senderGender;
	}


	public String getSenderAddress() {
		return senderAddress;
	}


	public void setSenderAddress(String senderAddress) {
		this.senderAddress = senderAddress;
	}


	public String getSenderCity() {
		return senderCity;
	}


	public void setSenderCity(String senderCity) {
		this.senderCity = senderCity;
	}


	public String getSenderState() {
		return senderState;
	}


	public void setSenderState(String senderState) {
		this.senderState = senderState;
	}


	public String getSenderCountry() {
		return senderCountry;
	}


	public void setSenderCountry(String senderCountry) {
		this.senderCountry = senderCountry;
	}


	public String getSenderZipCode() {
		return senderZipCode;
	}


	public void setSenderZipCode(String senderZipCode) {
		this.senderZipCode = senderZipCode;
	}


	public String getSenderMobile() {
		return senderMobile;
	}


	public void setSenderMobile(String senderMobile) {
		this.senderMobile = senderMobile;
	}


	public String getSenderIDType() {
		return senderIDType;
	}


	public void setSenderIDType(String senderIDType) {
		this.senderIDType = senderIDType;
	}


	public String getSenderIDNumber() {
		return senderIDNumber;
	}


	public void setSenderIDNumber(String senderIDNumber) {
		this.senderIDNumber = senderIDNumber;
	}


	public String getIdIssuePlace() {
		return idIssuePlace;
	}


	public void setIdIssuePlace(String idIssuePlace) {
		this.idIssuePlace = idIssuePlace;
	}


	public String getIdIssueDate() {
		return idIssueDate;
	}


	public void setIdIssueDate(String idIssueDate) {
		this.idIssueDate = idIssueDate;
	}


	public String getIdExpireDate() {
		return idExpireDate;
	}


	public void setIdExpireDate(String idExpireDate) {
		this.idExpireDate = idExpireDate;
	}


	public String getSenderIdType2() {
		return senderIdType2;
	}


	public void setSenderIdType2(String senderIdType2) {
		this.senderIdType2 = senderIdType2;
	}


	public String getSenderIdNumber2() {
		return senderIdNumber2;
	}


	public void setSenderIdNumber2(String senderIdNumber2) {
		this.senderIdNumber2 = senderIdNumber2;
	}


	public String getSenderNativeCountry() {
		return senderNativeCountry;
	}


	public void setSenderNativeCountry(String senderNativeCountry) {
		this.senderNativeCountry = senderNativeCountry;
	}


	public String getSenderDateOfBirth() {
		return senderDateOfBirth;
	}


	public void setSenderDateOfBirth(String senderDateOfBirth) {
		this.senderDateOfBirth = senderDateOfBirth;
	}


	public String getSenderOccupation() {
		return senderOccupation;
	}


	public void setSenderOccupation(String senderOccupation) {
		this.senderOccupation = senderOccupation;
	}


	public String getSenderEmployerName() {
		return senderEmployerName;
	}


	public void setSenderEmployerName(String senderEmployerName) {
		this.senderEmployerName = senderEmployerName;
	}


	public String getSenderEmployerType() {
		return senderEmployerType;
	}


	public void setSenderEmployerType(String senderEmployerType) {
		this.senderEmployerType = senderEmployerType;
	}


	public String getSenderFundSource() {
		return senderFundSource;
	}


	public void setSenderFundSource(String senderFundSource) {
		this.senderFundSource = senderFundSource;
	}


	public String getSenderPhoto() {
		return senderPhoto;
	}


	public void setSenderPhoto(String senderPhoto) {
		this.senderPhoto = senderPhoto;
	}


	public String getSenderPhoto1() {
		return senderPhoto1;
	}


	public void setSenderPhoto1(String senderPhoto1) {
		this.senderPhoto1 = senderPhoto1;
	}

}
