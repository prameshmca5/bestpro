/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwRestriction;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerRestriction;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;

/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.MER_RESTRICTION)
public class RestrictionRestController extends AbstractRestController {

	@GetMapping(value = "/{merchantId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerRestriction findRestrictionByMerchantId(@PathVariable String merchantId) {

		PgwRestriction restriction = super.pgwRestrictionService.findRestrictionByMerchantId(merchantId);

		MerRestriction merRestriction = new MerRestriction();
		if (!BaseUtil.isObjNull(restriction)) {
			merRestriction = dozerMapper.map(restriction, MerRestriction.class);
		}
		return merRestriction;
	}

	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerRestriction updateRestriction(@Valid @RequestBody MerRestriction merRestriction,
			HttpServletRequest request, HttpServletResponse response) throws BeException {

		if (merRestriction == null) {// restriction null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		if (StringUtils.isBlank(merRestriction.getMerchantId())) {// no
			// merchant
			// name
			throw new BeException(BeErrorCodeEnum.I400IDM137, new String[] { "Merchant Name", "Merchant Profile" });
		}

		PgwRestriction restriction = new PgwRestriction();
		PgwRestriction restrict = super.pgwRestrictionService
				.findRestrictionByMerchantId(merRestriction.getMerchantId());

		if (BaseUtil.isObjNull(restrict)) {
			restriction.setMerchantId(merRestriction.getMerchantId());
			restriction.setAllowCountryIp(merRestriction.getAllowCountryIp());
			restriction.setAcceptedCountryIp(merRestriction.getAcceptedCountryIp());
			restriction.setAllowCountryCc(merRestriction.getAllowCountryCc());
			restriction.setAcceptedCountryCc(merRestriction.getAcceptedCountryCc());
			restriction.setCreateId(merRestriction.getUserId());
			super.pgwRestrictionService.create(restriction);
		} else {
			restrict.setMerchantId(merRestriction.getMerchantId());
			restrict.setMerchantId(merRestriction.getMerchantId());
			restrict.setAllowCountryIp(merRestriction.getAllowCountryIp());
			restrict.setAcceptedCountryIp(merRestriction.getAcceptedCountryIp());
			restrict.setAllowCountryCc(merRestriction.getAllowCountryCc());
			restrict.setAcceptedCountryCc(merRestriction.getAcceptedCountryCc());
			restrict.setUpdateId(merRestriction.getUserId());
			super.pgwRestrictionService.update(restrict);
		}

		MerRestriction restr = new MerRestriction();
		PgwRestriction updatRestriction = super.pgwRestrictionService
				.findRestrictionByMerchantId(merRestriction.getMerchantId());
		if (!BaseUtil.isObjNull(updatRestriction)) {
			restr = dozerMapper.map(updatRestriction, MerRestriction.class);
		}
		return restr;
	}

}
