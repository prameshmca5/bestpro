/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwPaymentSetting;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerPayPageSet;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;


/**
 * @author Afif Saman
 * @since July 13, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.PAY_PAGE_SET)
public class PayPageSettingRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(PayPageSettingRestController.class);

	private static final String HTTP = "http://";

	private static final String HTTPS = "https://";


	@GetMapping(value = "/{merchantId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerPayPageSet getPaymentSettingById(@PathVariable String merchantId) {

		PgwPaymentSetting pgwPaymentSetting = super.pgwPaymentSettingService.findPaymentSettingMerchantId(merchantId);

		MerPayPageSet payPageSet = new MerPayPageSet();
		if (!BaseUtil.isObjNull(pgwPaymentSetting)) {
			payPageSet = dozerMapper.map(pgwPaymentSetting, MerPayPageSet.class);
			if (!BaseUtil.isObjNull(pgwPaymentSetting.getReturnUrl())
					&& pgwPaymentSetting.getReturnUrl().startsWith(HTTP)) {
				payPageSet.setProtocolReturnUrl(HTTP);
				payPageSet.setReturnUrl(pgwPaymentSetting.getReturnUrl().substring(7));
			} else if (!BaseUtil.isObjNull(pgwPaymentSetting.getReturnUrl())
					&& pgwPaymentSetting.getReturnUrl().startsWith(HTTPS)) {
				payPageSet.setProtocolReturnUrl(HTTPS);
				payPageSet.setReturnUrl(pgwPaymentSetting.getReturnUrl().substring(8));
			}

			if (!BaseUtil.isObjNull(pgwPaymentSetting.getCallbackUrl())
					&& pgwPaymentSetting.getCallbackUrl().startsWith(HTTP)) {
				payPageSet.setProtocolCallbackUrl(HTTP);
				payPageSet.setCallbackUrl(pgwPaymentSetting.getCallbackUrl().substring(7));
			} else if (!BaseUtil.isObjNull(pgwPaymentSetting.getCallbackUrl())
					&& pgwPaymentSetting.getReturnUrl().startsWith(HTTPS)) {
				payPageSet.setProtocolCallbackUrl(HTTPS);
				payPageSet.setCallbackUrl(pgwPaymentSetting.getCallbackUrl().substring(8));
			}
		}
		return payPageSet;
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public boolean updatePaymentPageSettings(@Valid @RequestBody MerPayPageSet merPayPageSet,
			HttpServletRequest request, HttpServletResponse response) throws BeException {

		LOGGER.info("Update Payment Page Settings ... ");
		if (BaseUtil.isObjNull(merPayPageSet)) {// Payment page setting null
			throw new BeException(BeErrorCodeEnum.E404PPSC001);
		}

		PgwPaymentSetting pgwPaymentSetting = super.pgwPaymentSettingService
				.findPaymentSettingMerchantId(merPayPageSet.getMerchantId());
		if (!BaseUtil.isObjNull(pgwPaymentSetting)) {
			if ((merPayPageSet.getProtocolReturnUrl() != null) && (merPayPageSet.getReturnUrl() != null)) {
				pgwPaymentSetting.setReturnUrl(merPayPageSet.getProtocolReturnUrl() + merPayPageSet.getReturnUrl());
			}
			pgwPaymentSetting.setReturnUrlWithIpn(merPayPageSet.getReturnUrlWithIpn());
			if ((merPayPageSet.getProtocolCallbackUrl() != null) && (merPayPageSet.getCallbackUrl() != null)) {
				pgwPaymentSetting
						.setCallbackUrl(merPayPageSet.getProtocolCallbackUrl() + merPayPageSet.getCallbackUrl());
			}
			pgwPaymentSetting.setCallbackUrlWithIpn(merPayPageSet.getCallbackUrlWithIpn());
			pgwPaymentSetting.setVerifyKey(merPayPageSet.getVerifyKey());
			pgwPaymentSetting.setUpdateId(merPayPageSet.getUserId());

			// Removing picture is not working. Remove property remained
			// false
			// when updating. Conflict with normal update. Will remove this
			// condition once fixed.
			pgwPaymentSetting.setDocMgtId(merPayPageSet.getDocMgtId());
			if (!BaseUtil.isObjNull(merPayPageSet.getEnableVerify())) {
				pgwPaymentSetting.setEnableVerify(merPayPageSet.getEnableVerify());
			} else {
				pgwPaymentSetting.setEnableVerify(1);
			}
			if (!BaseUtil.isObjNull(merPayPageSet.getEmailNotification())) {
				pgwPaymentSetting.setEmailNotification(merPayPageSet.getEmailNotification());
			} else {
				pgwPaymentSetting.setEmailNotification("0");
			}
			if (!BaseUtil.isObjNull(merPayPageSet.getReceipt())) {
				pgwPaymentSetting.setReceipt(merPayPageSet.getReceipt());
			} else {
				pgwPaymentSetting.setReceipt("0");
			}
			if (!BaseUtil.isObjNull(merPayPageSet.getCanModifyOid())) {
				pgwPaymentSetting.setCanModifyOid(merPayPageSet.getCanModifyOid());
			} else {
				pgwPaymentSetting.setCanModifyOid(0);
			}
			if (!BaseUtil.isObjNull(merPayPageSet.getCanModifyAmt())) {
				pgwPaymentSetting.setCanModifyAmt(merPayPageSet.getCanModifyAmt());
			} else {
				pgwPaymentSetting.setCanModifyAmt(0);
			}
			if (!BaseUtil.isObjNull(merPayPageSet.getCantModifyDesc())) {
				pgwPaymentSetting.setCantModifyDesc(merPayPageSet.getCantModifyDesc());
			} else {
				pgwPaymentSetting.setCantModifyDesc("0");
			}
			if (!BaseUtil.isObjNull(merPayPageSet.getEmailLock())) {
				pgwPaymentSetting.setEmailLock(merPayPageSet.getEmailLock());
			} else {
				pgwPaymentSetting.setEmailLock("0");
			}
			if (!BaseUtil.isObjNull(merPayPageSet.getNameLock())) {
				pgwPaymentSetting.setNameLock(merPayPageSet.getNameLock());
			} else {
				pgwPaymentSetting.setNameLock("0");
			}
			if (!BaseUtil.isObjNull(merPayPageSet.getPhoneLock())) {
				pgwPaymentSetting.setPhoneLock(merPayPageSet.getPhoneLock());
			} else {
				pgwPaymentSetting.setPhoneLock("0");
			}
			pgwPaymentSetting.setSellerId(merPayPageSet.getSellerId());
			pgwPaymentSetting.setUpdateDt(new Timestamp(new Date().getTime()));

			super.pgwPaymentSettingService.update(pgwPaymentSetting);
			return true;
		} else {
			PgwPaymentSetting newPaymentSetting = dozerMapper.map(merPayPageSet, PgwPaymentSetting.class);
			newPaymentSetting.setCreateId(merPayPageSet.getUserId());
			newPaymentSetting.setUpdateId(merPayPageSet.getUserId());
			newPaymentSetting.setUpdateDt(new Timestamp(new Date().getTime()));
			super.pgwPaymentSettingService.create(newPaymentSetting);
		}
		return false;
	}


	// @Added by Ramesh Pongiannan
	@PostMapping(value = BeUrlConstants.ALL_MER_PAYSET_LIST, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<MerPayPageSet> getMerChantgetWrapperById(@Valid @RequestBody MerPayPageSet merPayPageSet,
			HttpServletRequest request, HttpServletResponse response) throws BeException {
		List<MerPayPageSet> multichannelList = new ArrayList<>();
		List<PgwPaymentSetting> channelLst = pgwPaymentSettingService.findAllMerchantList();
		if (BaseUtil.isListNullAndZero(channelLst)) {

			throw new BeException(BeErrorCodeEnum.E404PLC001, new String[] {});
		}
		for (PgwPaymentSetting c : channelLst) {
			multichannelList.add(dozerMapper.map(c, MerPayPageSet.class));
		}
		return multichannelList;
	}
	
	@PostMapping(value = BeUrlConstants.ALL_MER_PAYSET_LIST_BY_COMPREFID, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<MerPayPageSet> findPaysetByCompRefId(@Valid @RequestBody String compRefId,
			HttpServletRequest request, HttpServletResponse response) throws BeException {
		if (BaseUtil.isObjNull(compRefId)) {

			throw new BeException(BeErrorCodeEnum.E404PLC001, new String[] {});
		}
		List<MerPayPageSet> multichannelList = new ArrayList<>();
		List<PgwPaymentSetting> channelLst = pgwPaymentSettingService.findMerchantListByCompRefId(compRefId);
		if (BaseUtil.isListNullAndZero(channelLst)) {

			throw new BeException(BeErrorCodeEnum.E404PLC001, new String[] {});
		}
		for (PgwPaymentSetting c : channelLst) {
			multichannelList.add(dozerMapper.map(c, MerPayPageSet.class));
		}
		return multichannelList;
	}


}
