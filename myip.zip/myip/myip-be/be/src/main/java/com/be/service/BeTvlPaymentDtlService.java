/**
 * 
 */
package com.be.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTvlPaymentDtlQf;
import com.be.dao.BeTvlPaymentDtlRepository;
import com.be.model.BeAcctPassport;
import com.be.model.BeTvlPayment;
import com.be.model.BeTvlPaymentDtl;
import com.be.model.RefChannel;
import com.be.model.RefPymntMsgCode;
import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Payment;
import com.be.sdk.model.PaymentDtl;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_PAYMENT_DTL_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_PAYMENT_DTL_SVC)
public class BeTvlPaymentDtlService extends AbstractService<BeTvlPaymentDtl> {

	@Autowired
	private BeTvlPaymentDtlRepository beTvlPaymentDtlDao;
	
	@Autowired
	BeTvlPaymentDtlQf beTvlPaymentDtlQf;
		
	@Override
	public GenericRepository<BeTvlPaymentDtl> primaryDao() {
		return beTvlPaymentDtlDao;
	}

	public long getCount(PaymentDtl dto) {
		return beTvlPaymentDtlQf.getCount(dto);
	}

	public BeTvlPaymentDtl searchBeTvlPayment(PaymentDtl dto) {
		return beTvlPaymentDtlQf.searchPayment(dto);
	}

	@SuppressWarnings("unchecked")
	public List<PaymentDtl> searchBeTvlPaymentDetails(PaymentDtl dto, DataTableRequest<?> dataTableInRQ) 
			throws IOException {
		return JsonUtil.transferToList(beTvlPaymentDtlQf.searchBeTvlPaymentDetails(dto, dataTableInRQ), PaymentDtl.class);
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}

	public BeTvlPaymentDtl createUpdate(BeTvlPaymentDtl beTvlPaymentDtl, String string) {
		 return create(beTvlPaymentDtl);
	}
	
 
}
