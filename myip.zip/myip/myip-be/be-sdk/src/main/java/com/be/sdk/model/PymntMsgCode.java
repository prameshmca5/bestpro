/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author michelle.angela
 *
 */
public class PymntMsgCode implements Serializable {

	private static final long serialVersionUID = -3762795517186668679L;

	private Integer pymntMsgCodeId;

	private String respCd;

	private String respDescription;
	
	private Integer statusCd;

	private Channel channel;
	
	private String createId;

	private Timestamp createDt;

	private Timestamp updateDt;

	private String updateId;

	public Integer getPymntMsgCodeId() {
		return pymntMsgCodeId;
	}

	public void setPymntMsgCodeId(Integer pymntMsgCodeId) {
		this.pymntMsgCodeId = pymntMsgCodeId;
	}

	public String getRespCd() {
		return respCd;
	}

	public void setRespCd(String respCd) {
		this.respCd = respCd;
	}

	public String getRespDescription() {
		return respDescription;
	}

	public void setRespDescription(String respDescription) {
		this.respDescription = respDescription;
	}

	public Integer getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(Integer statusCd) {
		this.statusCd = statusCd;
	}

	public Channel getChannel() {
		return channel;
	}

	public void setChannel(Channel channel) {
		this.channel = channel;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	
	
}
