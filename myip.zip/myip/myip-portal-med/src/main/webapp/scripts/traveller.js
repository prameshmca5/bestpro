var initProfileUpload;
var initUploadImage;
var initUploadCamera;
//var stopCamera;
var localstream;
var reset;
var displayImageFile;
var drawOnSourceCanvas;
var drawSourceImage;
var calculateDimension;
var addEventHandler;
var cropImage;
var qualityCheck;
var checkIcao;
var faceIds;

var video;
var defaultCaptureMsg = 'Click <i class="fa fa-upload" aria-hidden="true"></i> to upload an image or <i class="fa fa-play" aria-hidden="true"></i> to start the camera.';


$(function() {
	faceIds = $('#faceIds');
	
	console.log(faceIds);
	var oTblTravellerHstry = $('#tblTravellerHstry')
			.DataTable(
					{
						"processing" : true,
						"serverSide" : true,
						'responsive' : true,
						'destroy' : true,
						'colReorder' : {
							'enable' : false
						},
//						order : [ [ 1, "asc" ] ],
						
						retrieve : true,
						"columns" : [
								{
									"data" : null,
									"searchable" : false,
									"orderable" : false,
									// "visible": false,
									"render" : function(data, type, row) {
										return "as";
									},
								},
								{
									"data" : "nationality",
									"orderable" : true,
									"searchable" : true,
									"render" : function(data, type, row) {
										var nationality = (data != null ? data.cntryDesc
												: "-");
										return "<span id='id-row' data-id='"
												+ row.acctTvlrId + "'>"
												+ nationality + "</span>"
									},
								},
								{
									"data" : "fullName",
									"orderable" : true,
									"searchable" : true,
									"render" : function(data, type, row) {
										if (data != null && data != "") {

											return data;

										}

										return "-";
									}
								},
								{
									"data" : "acctPassport.passportNo",
									"orderable" : true,
									"searchable" : true,
									"render" : function(data, type, row) {
										if (data != null && data != "") {

											return data;

										}

										return "-";

									}
								},
								{
									"data" : "gender",
									"orderable" : true,
									"searchable" : true,
									"render" : function(data, type, row) {
										if (data != null) {

											return data == "M" ? "MALE"
													: "FEMALE";

										}

										return "-";
									}
								}, { "data": "relationMtdt.mtdtDesc", 
									"orderable" : true,
									"searchable" : true,
				  	            	"render": function (data, type, row) { 
										if (data != null && data != "") {

											return data;

										}

										return "-";
			  	            	},
			  	            },
			  	            
			  	          { "data": "typeMtdt.mtdtDesc", 
								"orderable" : true,
								"searchable" : true,
			  	            	"render": function (data, type, row) { 
									if (data != null && data != "") {

										return data;

									}

									return "-";
			  	            	},
			  	            }, ],
						"ajax" : $.fn.dataTable.pipeline({
							"pages" : 1,
							"type" : "GET",
							"url" : contextPath + "/mcVerifyAttendance/paginated",
							"action" : 'xhttp',
							'beforeSend' : dtRequestHeader,
							"dataSrc" : dtDataSrc,
							"data" : function(data) {
								data.fullName = $("input#fullName").val();
								data.passportNo = $("input#passportNo").val();
//								if(data.typeMtdt!=null)
									data.typeMtdtCd = $("select#typeInput").val();
								
//								if(data.relationMtdt!=null)
									data.relationMtdtCd = $("select#relationInput").val();
								
								console.log("data", data);
							},
							"error" : function() {
							}
						}),
						"language" : {
							"emptyTable" : prop.dtbEmptyTable
						},
						"initComplete" : function(settings, json) {
//							$('input#fullName').unbind();
//							$('input#passportNo').unbind();
							$('#searchFilter').bind(
									'click',
									function(e) {
										
//										console.log($('input#fullName').val(),$('input#passportNo').val(),$('select#relationInput').val(),$('select#typeInput').val());
										portalUtil.showMainLoading(true);
										oTblTravellerHstry
										.column(2).search($('input#fullName').val())
										.column(3).search($('input#passportNo').val());
//										.column(5).search($('input#relationInput').val());
										
//									if(oTblTravellerHstry.column(5)!=null)
										oTblTravellerHstry.column(5).search($('select#relationInput').val());
									
//									if(oTblTravellerHstry.column(6)!=null)
										oTblTravellerHstry.column(6).search($('select#typeInput').val());

										oTblTravellerHstry.draw();
										$(".em-toggle").click();
									});
							$('#searchClear').bind('click', function(e) {
								$('input#fullName').val("")
								$('input#passportNo').val("")
								$('input#typeInput').val("")
								$('input#relationInput').val("")
								// $("#status").val("").select2();
								// $("#userRoleGroupCode").val("").select2();
								oTblTravellerHstry.columns().search("").draw();
								$(".em-toggle").click();
							});

						},
						"fnDrawCallback" : function(oSettings) {
							processRowNum(oSettings);
							hidePagination(this, "#tblTravellerHstry");
							portalUtil.showMainLoading(false);
						}
					});


	$(document).on('click', "#tblTravellerHstry tbody tr", function() {
		var id = $(this).find('#id-row').data('id'); // id row data
		 console.log("as",id);
		window.location.href = contextPath + '/mcVerifyAttendance/' + id + "/update";
	});

//	$('#tblTravellerHstry').dataTable().fnSetFilteringEnterPress();

	var getStringDate = function(data) {
		console.log("date", data);
		var date = Date(data);

		return new moment(date).format("DD/MM/YYYY");
	}

/* if ($('input[name="acctPassport.passportExpiryDt"]').length > 0)
 $('input[name="acctPassport.passportExpiryDt"]').val(
 getStringDate($('input[name="acctPassport.passportExpiryDt"]')
 .val()));*/

 /*if ($('input[name="dob"]').length > 0)
 $('input[name="dob"]').val(getStringDate($('input[name="dob"]').val()));*/

	/*$('#passportExpDate').daterangepicker(
			{
				singleDatePicker : true,
				showDropdowns : true,
				// endDate : new Date(),
				minDate : new Date(),
				minYear : parseInt(moment().format('YYYY'), 15),
				// maxYear: parseInt(moment().format('YYYY'), 15),
				locale : {
					format : "DD/MM/YYYY"
				},
			},
			function(start, end, label) {

				console.log("passExp", start.format('DD/MM/YYYY'));
				$('input[name="acctPassport.passportExpiryDt"]').val(
						start.format('DD/MM/YYYY'))
			});*/
 
  var dtPckrPayload = {
		    singleDatePicker: true,
		    showDropdowns: true,
		    minDate : new Date(),
		    minYear : parseInt(moment().format('YYYY'), 15),
		};
 
	$('#passportExpDate').daterangepicker(dtPckrPayload, function(start) {
		$('input[name="passportExpStr"]').val(start.format('DD/MM/YYYY'));
	});

	$('#dobDate').daterangepicker({
		singleDatePicker : true,
		showDropdowns : true,
		endDate : new Date(),
		maxDate : new Date(),
		minYear : 1901,
		maxYear : parseInt(moment().format('YYYY'), 15),
		locale : {
			format : "DD/MM/YYYY"
		},
	}, function(start, end, label) {
		$('input[name="dobStr"]').val(start.format('DD/MM/YYYY'))
		
		var now = moment();
		var before = moment(start);
		console.log(now.diff(before, 'years')); 
		
		$.ajax({
	        'async' : false,
			'global' : false,
			headers : {
				'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
			},
			type: "POST",
			action : 'xhttp',
	        url: contextPath + "/mcVerifyAttendance/getType?type="+now.diff(before, 'years'),
	       
	    }).done(function(a) {
	    	
	    	console.log(JSON.parse(a));
	    	var meta = JSON.parse(a);
	    	
	    	$('#typeField').val(meta.mtdtCd);
	    	$('#typeFieldDesc').val(meta.mtdtDesc);
	    });
	});

	$(document).on('click', '.btn-edit-trvler', function() {
		var id = $(this).data('id');

		window.location.href = contextPath + '/mcVerifyAttendance/' + id + '/update';
		console.log("id", id);
		// pgil popup
	});

	
	//stopCamera = function(btnUploadId,btnStartId,btnStopId,btnCaptureId,videoId,captureMsgId){
	//	$(btnUploadId).show();
	//	$(btnStartId).show();
	//	$(btnStopId).hide();
	//	$(btnCaptureId).hide();
	//	if(localstream) {
	//		video = $(videoId);
	//		video[0].src = "";
	//		localstream.getTracks()[0].stop();
	//	}
	//	$(captureMsgId).html(defaultCaptureMsg);
	//}
	
//	
	initUploadCamera = function(){
		
		var uploadCameraBox = $('.uploadCameraBox');
		
		var boxChildren = uploadCameraBox.find('.enroll-box');
		console.log("boxChildren",boxChildren);
		$.each(boxChildren,function(index,box){
// console.log("box",$(box).find('#btnStart').show());
			console.log("class",$(box).hasClass());
// var className = "";
			var className = $(box).attr("class");
			className = "."+className.split(" ").join(".");
			
			

			var cnvasContainerId = className+" #canvas-container";
			var cnvasPotretId = className+" #canvas-portrait";
			var btnInputFileId = className+" #btnUpload";
			var captureMsgId = className+" #captureMsg";
			var btnCropId = className+" #btnCrop";
			
			$(box).find('#btnStart').show();
			$(box).find('#btnStop').hide();
			$(box).find('#btnCapture').hide();
			$(box).find('#captureMsg').html(defaultCaptureMsg);
			$(box).find("#inputFile").change(function(a) {
		        window.sourceCanvas = null;
		        var b = a.target.files[0];
		        displayImageFile(className,b,btnInputFileId,cnvasPotretId,cnvasContainerId,btnCropId,captureMsgId);
		    });
		});
		
	}
	
	qualityCheck = function(mainClass,a,needCrop){
		
		var btnUploadId = mainClass+" #btnUpload";
		var btnStartId = mainClass+" #btnStart";
		var btnStopId = mainClass+" #btnStop";
		var btnCaptureId = mainClass+" #btnCapture";
		var videoId = mainClass+" #video";
		var captureMsgId = mainClass+" #captureMsg";
		var btnCropId = mainClass+" #btnCrop";
		var btnIcaoId = mainClass+" #btnIcao";
		var btnCamviId = mainClass+" #btnCamvi";
		var icaoCriteriaId = mainClass+" .icaoCriteria";
		var singleFaceId = mainClass+" #singleFace";
		var constraintsFullFrontalId = mainClass+" #constraintsFullFrontal";
		var background = mainClass+" #background";
		var focusId = mainClass+" #focus";
		var faceDetectedId = mainClass+" #faceDetected";
		var icaoCriteriaId = mainClass+" #icaoCriteria";
		var cnvasContainerId = mainClass+" #canvas-container";
		var cnvasPotretId = mainClass+" #canvas-portrait";
		var canvasPrevId = mainClass+" #canvas-preview";
		var videoId = mainClass+" #video";

		var croppedCanvas = $(cnvasPotretId).cropper('getCroppedCanvas');
		var canvaURL = croppedCanvas.toDataURL();
		
		
		$.ajax({
	        'async' : false,
			'global' : false,
			headers : {
				'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
			},
			type: "POST",
			action : 'xhttp',
	        url: window.contextPath + "/mcVerifyAttendance?quality",
	        data: a
	    }).done(function(a) {
	    	if(a.result == 'pass') {
	    		// 20200715 changes
	    		$(btnCropId).hide();
//	    		$(btnCropId).html("Image Quality <i class='fa fa-check-circle' aria-hidden='true' style='color:#4caf50;'></i>")
	    		var img =  new Image();
	    		img.src = canvaURL;
	    		img.height = "300";
	    		$(videoId).hide();
	    		$(cnvasPotretId).cropper('destroy')
	    		$(cnvasPotretId).hide();
	    		$(canvasPrevId).show();
	    		$(canvasPrevId).html(img);
	    		//$(btnIcaoId).show();
	    		$(icaoCriteriaId).show();    	
	    		$(faceDetectedId).attr("disabled", "disabled");
	    		$(singleFaceId).attr("disabled", "disabled");
	    		$(focusId).attr("disabled", "disabled");
//	    		$(captureMsgId).html('Select ICAO Criteria below and click Check ICAO button.');
	    		
	    		checkIcao(mainClass);
	    		return;
	    	} else {
	    		$(btnCropId).html("Image Quality <i class='fa fa-times-circle' aria-hidden='true' style='color:#dc3545;'></i>")
	    		$(captureMsgId).html(defaultCaptureMsg);
	    	}
	    	$(btnCropId).prop('disabled', true);
	    	portalUtil.showMainLoading(false);
	    }).fail(function() {
	    	
	    	reset(cnvasPotretId,btnCaptureId,btnStopId,btnCropId,btnIcaoId,btnCamviId,icaoCriteriaId,
					singleFaceId,constraintsFullFrontalId,background,focusId,faceDetectedId,
					icaoCriteriaId,btnUploadId,captureMsgId);
	    	
	        $.messager.alert("Error", "Face detection error", "error")
	        portalUtil.showMainLoading(false);
	    })
	}
	

	checkIcao = function(enroll) {
		portalUtil.showMainLoading(true);
		var img = $(enroll).find("#canvas-preview > img");
		var features = [];
		$(enroll).find('.icaoCriteria:checkbox:checked').each(function() {
	    	features.push($(this).attr('id'));
	    });
	    
		var src = img[0].src;
		a = {
				// enrollType: enroll.split("-")[1],
		        image: src.replace('data:image/png;base64,', ''),
		        start: xStaffId,
		        email: xEmail,
		        faceId: xFaceId,
		        photoId: xPhotoId,
		        icaoCriteria: features.join(',')
		    };
	    $.ajax({
			'global' : false,
			headers : {
				'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
			},
			type: "POST",
			action : 'xhttp',
	        url: window.contextPath + "/mcVerifyAttendance?icao",
	        data: a
	    }).done(function(a) {
	    	if(a.result == 'pass') {
	    		// 20200715 changes
	    		
//	    		$(enroll).find("#btnIcao").html("ICAO Passed <i class='fa fa-check-circle' aria-hidden='true' style='color:#4caf50;'></i>")
//	    		$(enroll).find("#btnCamvi").show();
//	    		$(enroll).find('#captureMsg').html('Click Finish to save the photo for Face verification.');
	    		
	    		enrollId(0,enroll);
	    	} else {
	    		//$(enroll).find("#btnIcao").html("Failed Upload <i class='fa fa-times-circle' aria-hidden='true' style='color:#dc3545;'></i>")
	    		$(enroll).find("#btnCamvi").hide();
	    		$(enroll).find('#captureMsg').html(defaultCaptureMsg);
	    	}
	    	icaoResult(a.singleFace, $(enroll).find("#singleFace"));
			icaoResult(a.faceDetected, $(enroll).find("#faceDetected"));
			/*
			 * icaoResult(a.imageInterpolated, $("#imageInterpolated"));
			 * icaoResult(a.constraintsFullFrontal,
			 * $("#constraintsFullFrontal")); icaoResult(a.constraintsPassport,
			 * $("#constraintsPassport")); icaoResult(a.resolution,
			 * $("#resolution")); icaoResult(a.pose, $("#pose"));
			 * icaoResult(a.gazeFrontal, $("#gazeFrontal"));
			 * icaoResult(a.mouthClosed, $("#mouthClosed"));
			 * icaoResult(a.nonOccluded, $("#nonOccluded"));
			 */
			/* icaoResult(a.background, $("#background")); */
			icaoResult(a.focus, $(enroll).find("#focus"));
			/*
			 * icaoResult(a.faceShadow, $("#faceShadow"));
			 * icaoResult(a.notHotspots, $("#notHotspots"));
			 * icaoResult(a.exposure, $("#exposure"));
			 * icaoResult(a.expressionNeutral, $("#expressionNeutral"));
			 * icaoResult(a.eyesOpen, $("#eyesOpen")); icaoResult(a.colour,
			 * $("#colour")); icaoResult(a.noReflections, $("#noReflections"));
			 * icaoResult(a.noGlasses, $("#noGlasses"));
			 */
			$(enroll).find(".icaoCriteria").attr("disabled", "disabled");
			$(enroll).find("#btnIcao").prop('disabled', true);
	    	portalUtil.showMainLoading(false);
	    }).fail(function() {
	    	reset();
	        $.messager.alert("Error", "Face detection error", "error")
	        portalUtil.showMainLoading(false);
	    })
	}

	

	cropImage = function(needCrop=true,enroll) {
// var className = $(box).attr("class");
// className = "."+className.split(" ").join(".");
		
		if(cropImage){
			portalUtil.showMainLoading(true);
			var croppedCanvas = $(enroll).find("#canvas-portrait").cropper('getCroppedCanvas');
			var canvaURL = croppedCanvas.toDataURL();
			a = {
			        image: canvaURL,
			        start: xStaffId,
			        email: xEmail,
			        faceId: xFaceId,
			        photoId: xPhotoId	        
			    };
		}
		
		
		
		
		qualityCheck(enroll,a,needCrop);
	    
	}

	

	calculateDimension = function(a, b, c, d) {
	    c = {
	        width: c,
	        height: d
	    };
	    a > c.width || b > c.height ? (a /= b, b = c.width / a, b <= c.height ? c.height = Math.round(b) : c.width = Math.round(c.height * a)) : (c.width = a, c.height = b);
	    return c
	}
	
	initProfileUpload = function(mainClass,paramTrvlID,paramEmail,paramFaceId,paramPhotoId){
		var mainClass = mainClass;
		initUploadImage(mainClass,paramTrvlID,paramEmail,paramFaceId,paramPhotoId,mainClass+" #inputFile",mainClass+" #canvas-preview",mainClass+" #drop");
	}
	
// initProfileUpload =
// function(paramTrvlID,paramEmail,paramFaceId,paramPhotoId){
// var mainClass = ".enroll-profile";
// initUploadImage(mainClass,paramTrvlID,paramEmail,paramFaceId,paramPhotoId,mainClass+"
// #inputFile",mainClass+" #canvas-preview",mainClass+" #drop");
// }
//	
	reset = function(cnvasPotretId,btnCaptureId,btnStopId,btnCropId,btnIcaoId,btnCamviId,icaoCriteriaId,
			singleFaceId,constraintsFullFrontalId,background,focusId,faceDetectedId,
			icaoCriteriaId,btnUploadId,captureMsgId){
		$(cnvasPotretId).hide();
		$(cnvasPotretId).cropper('destroy')
		$(btnCaptureId).hide();
		$(btnStopId).hide();
		capturePID = 0;
		captureName = "";
		numCapture = 0;
		var cropTitle = $(btnCropId).attr('title');
		$(btnCropId).text(cropTitle);
		$(btnCropId).removeAttr('disabled');
		$(btnCropId).hide();
		var icaoTitle = $(btnIcaoId).attr('title');
		$(btnIcaoId).text(icaoTitle);
		$(btnIcaoId).removeAttr('disabled');
		$(btnIcaoId).hide();
		var camviTitle = $(btnCamviId).attr('title');
		$(btnCamviId).text(camviTitle);
		$(btnCamviId).removeAttr('disabled');
		$(btnCamviId).hide();
		$.each($(icaoCriteriaId),function(index,value) {
			var element = $(value).siblings('.label-text');
			
// console.log(value,element);
			
			if(element.length>0){

				element[0].classList.remove("green");
				element[0].classList.remove("red");
			}
			
			$(value).removeAttr('checked');
			$(value).removeAttr("disabled");
		});
		$(singleFaceId).attr('checked','checked');
		$(constraintsFullFrontalId).attr('checked','checked');
		$(background).attr('checked','checked');
		$(focusId).attr('checked','checked');
		$(faceDetectedId).attr('checked','checked');
		$(icaoCriteriaId).hide();	
		$(btnUploadId).show();
		$(captureMsgId).html(defaultCaptureMsg);
	}
	
	addEventHandler = function(obj, evt, handler) {
	    if(obj.addEventListener) {
	        // W3C method
	        obj.addEventListener(evt, handler, false);
	    } else if(obj.attachEvent) {
	        // IE method.
	        obj.attachEvent('on'+evt, handler);
	    } else {
	        // Old school method.
	        obj['on'+evt] = handler;
	    }
	}
	
	
	initUploadImage = function(mainClass,paramTrvlID,paramEmail,paramFaceId,paramPhotoId,btnInputFileId,canvasPrevId,dropId){
		
		var btnUploadId = mainClass+" #btnUpload";
		var btnStartId = mainClass+" #btnStart";
		var btnStopId = mainClass+" #btnStop";
		var btnCaptureId = mainClass+" #btnCapture";
		var videoId = mainClass+" #video";
		var captureMsgId = mainClass+" #captureMsg";
		var btnCropId = mainClass+" #btnCrop";
		var btnIcaoId = mainClass+" #btnIcao";
		var btnCamviId = mainClass+" #btnCamvi";
		var icaoCriteriaId = mainClass+" .icaoCriteria";
		var singleFaceId = mainClass+" #singleFace";
		var constraintsFullFrontalId = mainClass+" #constraintsFullFrontal";
		var background = mainClass+" #background";
		var focusId = mainClass+" #focus";
		var faceDetectedId = mainClass+" #faceDetected";
		var icaoCriteriaId = mainClass+" #icaoCriteria";
		var cnvasContainerId = mainClass+" #canvas-container";
		var cnvasPotretId = mainClass+" #canvas-portrait";
		
		stopCamera(mainClass);
		//stopCamera(btnUploadId,btnStartId,btnStopId,btnCaptureId,videoId,captureMsgId);
		xStaffId = paramTrvlID;
		xEmail = paramEmail;
		xFaceId = (paramFaceId===null || paramFaceId==='null')? '' : paramFaceId;
		xPhotoId = '5c9ae95977b8bbb5bb62aab2';
		/*
		 * xStaffId = x; xEmail = y; xFaceId = (z===null || z==='null')? '' : z;
		 * xPhotoId = a;
		 */
		console.log("btnInputFileId",btnInputFileId);
		$(btnInputFileId).click();
		
		reset(cnvasPotretId,btnCaptureId,btnStopId,btnCropId,btnIcaoId,btnCamviId,icaoCriteriaId,
				singleFaceId,constraintsFullFrontalId,background,focusId,faceDetectedId,
				icaoCriteriaId,btnUploadId,captureMsgId);
		
		$(canvasPrevId).hide();
		
// var drop = document.querySelector(dropId);
		var drop = $(dropId)[0];
	    if(window.FileReader) { 
	    	  addEventHandler(window, 'load', function() {
	    	  	
	    	    function cancel(e) {
	    	      if (e.preventDefault) { e.preventDefault(); }
	    	      return false;
	    	    }
	    	  
	    	    // Tells the browser that we *can* drop on this target
	    	    addEventHandler(drop, 'dragover', cancel);
	    	    addEventHandler(drop, 'dragenter', cancel);
	    	  });
	    	}

	    addEventHandler(drop, 'drop', function (e) {
	    	  e = e || window.event; // get window.event if e argument
										// missing (in IE)
	    	  if (e.preventDefault) { e.preventDefault(); } // stops the browser
															// from redirecting
															// off to the image.

	    	  var dt    = e.dataTransfer;
	    	  displayImageFile(mainClass,dt.files[0],btnInputFileId,cnvasPotretId,cnvasContainerId,btnCropId,captureMsgId);
	    	  return false;
	    	});
	}
	

	drawSourceImage = function(mainClass,cnvasPotretId,cnvasContainerId,btnCropId,captureMsgId) {
	    if (window.sourceCanvas) {
	        var a = $(cnvasContainerId).width();
	        var b = $(cnvasContainerId).height();
	        a = calculateDimension(window.sourceCanvas.width, window.sourceCanvas.height, a, b);
	        window.proportion = window.sourceCanvas.width / a.width;
	        b = $(cnvasPotretId);
	        b = b[0];

// b = document.querySelector(cnvasPotretId);
	        console.log(mainClass,cnvasContainerId,cnvasPotretId,b);
	        b.width = 800; 
	        b.height = 500;
	        b.getContext("2d").drawImage(window.sourceCanvas, 0, 0,
	            window.sourceCanvas.width, window.sourceCanvas.height, 0, 0, b.width, b.height);
	        if (parent.onImageChange) {
	        	parent.onImageChange(window.sourceCanvas, window.filename)
	        }
	        
	        var canvas = document.querySelector(cnvasPotretId);
	        $(cnvasPotretId).show();
	        $(cnvasPotretId).cropper('destroy')
	        $(cnvasPotretId).cropper({
	        	dragMode: 'move',
	        	  aspectRatio: mainClass == '.enroll-box.enroll-profile' ? 6 /7 : 16 / 10,
	        	  cropBoxResizable: false,
	        	  autoCropArea: 1,
	              strict: false,
	              guides: false,
	              maxCropBoxWidth: canvas.width,
	              maxCropBoxHeight: canvas.height,
	              restore: false,
	              center: false,
	              highlight: false,
	              cropBoxMovable: false,
	              toggleDragModeOnDblclick: false,
	        	});
	        $(btnCropId).show();

//	        console.log("face Ids ",mainClass,$(mainClass).find('#faceIds'));
	        $(mainClass).find('#faceIds').hide();
//			faceIds.hide();
	    	$(captureMsgId).html('Click Crop & Check Quality button.');
	    }
	}
	
	
	drawSourceImagePass = function(cnvasPotretId,cnvasContainerId,btnCropId,captureMsgId) {
	    if (window.sourceCanvas) {
	        var a = $(cnvasContainerId).width();
	        var b = $(cnvasContainerId).height();
	        a = calculateDimension(window.sourceCanvas.width, window.sourceCanvas.height, a, b);
	        window.proportion = window.sourceCanvas.width / a.width;
	        b = $(cnvasPotretId);
	        b = b[0];

// b = document.querySelector(cnvasPotretId);
	        console.log(cnvasContainerId,cnvasPotretId,b);
	        b.width = 800; 
	        b.height = 500;
	        b.getContext("2d").drawImage(window.sourceCanvas, 0, 0,
	            window.sourceCanvas.width, window.sourceCanvas.height, 0, 0, b.width, b.height);
	        if (parent.onImageChange) {
	        	parent.onImageChange(window.sourceCanvas, window.filename)
	        }
	        
	        var canvas = document.querySelector(cnvasPotretId);
	        $(cnvasPotretId).show();
	        $(cnvasPotretId).cropper('destroy')
	        $(cnvasPotretId).cropper({
	        	dragMode: 'move',
	        	  aspectRatio: 16 / 10,
	        	  cropBoxResizable: false,
	        	  autoCropArea: 1,
	              strict: false,
	              guides: false,
	              maxCropBoxWidth: canvas.width,
	              maxCropBoxHeight: canvas.height,
	              restore: false,
	              center: false,
	              highlight: false,
	              cropBoxMovable: false,
	              toggleDragModeOnDblclick: false,
	        	});
	        $(btnCropId).show();
	    	$(captureMsgId).html('Click Crop & Check Quality button.');
	    }
	}
	
	
	drawOnSourceCanvas = function(img) {
// console.log("image",img);
		window.sourceCanvas || (window.sourceCanvas = document.createElement("canvas"));
	    if (window.sourceCanvas) {
	    	// limit the size of the source image, this is to prevent the
			// request from being too big in size for tomcat to handle
	    	var scale = 1;
	    	if (img.width > 2000 || img.height > 2000) {
	    		if (2000 / img.width < scale) {
	    			scale = 2000 / img.width;
	    		}
	    		if (2000 / img.height < scale) {
	    			scale = 2000 / img.height;
	    		}
	    	}
	    	window.sourceCanvas.width = img.width * scale;
	        window.sourceCanvas.height = img.height * scale;
	        window.sourceCanvas.getContext("2d").drawImage(img, 0, 0, img.width, img.height, 0, 0, window.sourceCanvas.width, window.sourceCanvas.height);
	    }
	}
	

	displayImageFile = function(mainClass,b,btnInputFileId,cnvasPotretId,cnvasContainerId,btnCropId,captureMsgId) {
	    b.type.match(/image.*/) && (a = new FileReader, a.onload = (function(theFile) {
	       

	        return function(e){
	        	

	    	var d = new Image;

	        d.cnvasPotretId = theFile.cnvasPotretId;
	        d.cnvasContainerId =theFile.cnvasContainerId;
	        d.onload = function() {
	            // $("#inputFileName").val(b.name);
	            window.filename = b.name;
	            drawOnSourceCanvas(this);
	            drawSourceImage(mainClass,this.cnvasPotretId,this.cnvasContainerId,btnCropId,captureMsgId); 
	            if($("#faceDivId").hasClass(".cropFace")){
	            	debugger;
	            	drawSourceImage(mainClass,this.cnvasPotretId,this.cnvasContainerId,btnCropId,captureMsgId); 
	            }
	            
	            if($(".cropPassport").hasClass()){
	            	debugger;
	            	 drawSourceImagePass(this.cnvasPotretId,this.cnvasContainerId,btnCropId,captureMsgId); 
	            }
	            
	            $(btnInputFileId).val("")
	        };
	        

	            console.log(e.target.result);
		        d.src = e.target.result
	        };
	    })({cnvasPotretId:cnvasPotretId,cnvasContainerId:cnvasContainerId,btnCropId:btnCropId,captureMsgId:captureMsgId}), a.readAsDataURL(b))
	}
	
	
	
	initUploadCamera();
	
	$(document).on('click','#btnUpload',function(){
		var paramTrvlID = $(this).data("trvlid");
		var paramEmail = $(this).data("email");
		var paramFaceId = $(this).data("faceid");
		var paramPhotoId = $(this).data("photoid");
		var enroll = $(this).data("enroll");
		
// console.log("enrol",enroll);
		initProfileUpload(enroll,paramTrvlID,paramEmail,paramFaceId,paramPhotoId);
	});
	
	$(document).on('click','#btnCrop',function(){
		var enroll = $(this).data("enroll");
		var crop = $(this).data("crop");
		
// console.log("enrol",enroll);
		cropImage(crop,enroll);
	});
	
	$(document).on('click','#btnIcao',function(){
		var enroll = $(this).data("enroll");
		
// console.log("enrol",enroll);
		checkIcao(enroll);
	});
	
	$(document).on('click','#btnCamvi',function(){
		var enroll = $(this).data("enroll");
		var id = $(this).data("id");
		
// console.log("enrol",enroll);
		enrollId(id,enroll);
	});
	
	$(document).on('click','#btnCapture',function(){
		var enroll = $(this).data("enroll");
//		var id = $(this).data("id");
		
// console.log("enrol",enroll);
		captureVideo(enroll);
	});
	
	function icaoResult(res, eCheck) {
		var element = eCheck.siblings('.label-text');
		
		if(element.length>0){
			if(res) { 
				eCheck.attr("checked", "checked");
				element[0].classList.add("green")
			} else {
				element[0].classList.add("red")
			}
		}
		
	}
	
	
	$(document).on('click','#btnStart',function(){
		var paramTrvlID = $(this).data("trvlid");
		var paramEmail = $(this).data("email");
		var paramFaceId = $(this).data("faceid");
		var paramPhotoId = $(this).data("photoid");
		var enroll = $(this).data("enroll");
		
		faceIds = $('#faceIds');
		
// console.log("enrol",enroll);
		initCamera(enroll,paramTrvlID,paramEmail,paramFaceId,paramPhotoId);
	});

	function initCamera(enroll,x,y,z,a) {
		xStaffId = x;
		xEmail = y;
		xFaceId = (z===null || z==='null')? '' : z;
		xPhotoId = '5c9ae95977b8bbb5bb62aab2';
		camIcon = $(enroll).find('#video').siblings("img")
		
	    reset();
	    var constraints = { audio: false, video: { width: { min: 320, ideal: 800 }, height: { min: 240, ideal: 600 } } }; 

	    navigator.mediaDevices.getUserMedia(constraints)
		    .then(function(mediaStream) {
//		        console.log("face Ids ",enroll,$(enroll).find('#faceIds'));
		        $(enroll).find('#faceIds').hide();
		    	video = $(enroll).find("#video").show()[0];
		    	video.srcObject = mediaStream;
		      	video.onloadedmetadata = function() {
		        video.play();
		        

		        
		        camIcon.hide();
		        $(enroll).find('#btnUpload').hide();
		        $(enroll).find('#btnStart').hide();
		        $(enroll).find('#btnStop').show();
		        $(enroll).find('#btnCapture').show();
		        $(enroll).find("#canvas-preview").hide();
		      };
		      localstream = mediaStream; 
		      
		      $(enroll).find('#captureMsg').html('Click <i class="fa fa-camera"></i> to capture photo. Click <i class="fa fa-stop"></i> to stop the camera.');
	    }).catch(function(err) {
	    	if(err.name === 'NotFoundError'){
	    		portalUtil.showMessage("Camera not available. Please check your camera's connection to capture photo.","warning");	
	    	}
	    	console.log(err.name + ": " + err.message); }); // always check for errors at the end.
	    
	}

	function captureVideo(mainClass) {
	    var b = document.createElement("canvas");
	    var ratio =  video.videoWidth/video.videoHeight;
	    b.width = 800;
	    b.height = b.width/ratio;
	    b.getContext("2d").drawImage(video, 0, 0, b.width, b.height);
//	    var canvas = document.querySelector(mainClass+" #canvas-portrait");
	    var canvas = $(mainClass).find('#canvas-portrait')[0];
	    var ctx = canvas.getContext('2d');
	    ctx.drawImage(video, 0,0, canvas.width, canvas.height);
	    $(mainClass).find('#canvas-portrait').show();
	    $(mainClass).find('#canvas-portrait').cropper('destroy')
	    $(mainClass).find('#canvas-portrait').cropper({
	    	dragMode: 'move',
	    	  aspectRatio: 2 / 3,
	    	  cropBoxResizable: false,
	    	  autoCropArea: 1,
	          strict: false,
	          guides: false,
	          maxCropBoxWidth: canvas.width,
	          maxCropBoxHeight: canvas.height,
	          restore: false,
	          center: false,
	          highlight: false,
	          cropBoxMovable: false,
	          toggleDragModeOnDblclick: false,
	    	});
	    stopCamera(mainClass)
	    $(mainClass).find('#video').hide();
	    $(mainClass).find('#btnStart').show();
	    $(mainClass).find('#btnStop').hide();
	    $(mainClass).find('#btnCapture').hide();
	    $(mainClass).find("#btnCrop").show();
	    $(mainClass).find('#captureMsg').html('Click Crop & Check Quality button.');
	}
	

	function stopCamera(mainClass) {
		$(mainClass).find('#btnUpload').show();
		$(mainClass).find('#btnStart').show();
		$(mainClass).find('#btnStop').hide();
		$(mainClass).find('#btnCapture').hide();
		if(localstream) {
			video = $(mainClass).find("#video");
			video[0].src = "";
			localstream.getTracks()[0].stop();
		}
		$(mainClass).find('#captureMsg').html(defaultCaptureMsg);
	}
	
	

	function enrollId(id,mainClass) {
// debugger;
		portalUtil.showMainLoading(true);
		var result;
		var img = $(mainClass).find("#canvas-preview > img");
		var src = img[0].src.replace('data:image/png;base64,', '')
		
		var enroll = mainClass==".enroll-profile" ? "profile" : "passport" ;
		
		a = {
		        image: src,
		        start: xStaffId,
		        staffId: xStaffId,
		        email: xEmail,
		        faceId: xFaceId,
		        photoId: xPhotoId
// enrollType: enroll,
		    };
	    $.ajax({
	        'async' : false,
			'global' : false,
			headers : {
				'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
			},
			type: "POST",
			action : 'xhttp',
	        url: window.contextPath + "/mcVerifyAttendance?enroll="+enroll,
	        data: a
	    }).done(function(a) {

    		console.log("person ",a);
	    	
	    	if(a!=null){
				if(a.photoId!=null) $('#photoIdField').val(a.photoId);
				if(a.faceId!=null) $('#faceIdField').val(a.faceId);
				if(a.id!=null) $('#passIdField').val(a.id);
	    	}

    		
	    	if(a.personId != null) {
	    		$(mainClass).find("#btnCamvi").html("Completed <i class='fa fa-check-circle' aria-hidden='true' style='color:#4caf50;'></i>")
	    		$(mainClass).find("#btnCamvi").show();
	    		
	    		result = true;
	    	} else {
	    		$(mainClass).find("#btnCamvi").html("Registration Failed <i class='fa fa-times-circle' aria-hidden='true' style='color:#dc3545;'></i>")
	    		$(mainClass).find("#btnCamvi").hide();
	    	}
	    	$(mainClass).find("#btnCamvi").prop('disabled', true);
	    	portalUtil.showMainLoading(false);
	    }).fail(function() {
	    	reset();
	        $.messager.alert("Error", "Face detection error", "error");
	        portalUtil.showMainLoading(false);
	    })
// debugger;
	    if(result) {
	    	var faceIds = document.getElementById("faceIds");
	    	faceIds.src = faceIds.src + "?hash=" + new Date().getTime();
	    	$(mainClass).find('#captureMsg').html('Photo is successfully saved. ' + defaultCaptureMsg);
		    //portalUtil.showSuccess("Photo successfully saved");
	    }
	}
	

	$(document).on('click','#checkbox-declare',function(){
// console.log($(this).prop("checked"));
		if($('#submitProceed').length>0){
			
			$('#submitClose').prop('disabled',!$(this).prop("checked"));
			$('#submitProceed').prop('disabled',!$(this).prop("checked"));
		}
		
	});
	
	/*jQuery.validator.addMethod("dateCustom", function(value, element) {
	  // allow any non-whitespace characters as the host part
	  return this.optional( element ) || /^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[13-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/.test( value );
	}, 'Please enter a valid Date.');
	
	$("#travellerAddForm").validate({
		 rules: {
				'fullName' : {
					required: true
				},
				'nationality.cntryCd' : {
					required: true
				},
				'acctPassport.passportNo' : {
					required: true
				},
				'gender' : {
					required: true
				},
				'dob' : {
					required: true,
//					date: true,
					dateCustom : true
				},
				'acctPassport.passportExpiryDt' : {
					required: true
				},
				'birthPlace.cntryCd' : {
					required: true
				},
				'relationMtdt.mtdtCd' : {
					required: true
				},
				'contactNo' : {
					required: true
				},
	            'email': {
					email: true
				},
	            emailToCompare: {
					email: true,
//					equalTo: '#acctTraveller\\.email'
				},
				'addr1' : {
					required: true
				},
				'addr2' : {
					required: true
				},
				'stateDesc' : {
					required: true
				},
				'cityDesc' : {
					required: true
				},
				'zipcode' : {
					required: true
				},
				'country.cntryCd' : {
					required: true
				},
		 },
	  submitHandler: function(form) {
	    // do other things for a valid form
//		  console.log("as");
	    form.submit();
	  }
	});*/
	
	// form validation
//	$('#travellerAddForm').validate({ 
//        rules: {
//			'fullName' : {
//				required: true
//			},
//			'acctPassport.passportNo' : {
//				required: true
//			},
//            'email' : {
//				required: true,
//                email: true
//            }
//		},
//		messages : {
//			'fullName': {
//				required: "Please enter full name."
//			}
//		}
//	});
	
// $("#commentForm").validate();

	function stopCamera() {
		$('#btnUpload').show();
		$('#btnStart').show();
		$('#btnStop').hide();
		$('#btnCapture').hide();
		if(localstream) {
			video = $("#video");
			video[0].src = "";
			localstream.getTracks()[0].stop();
		}
		$('#captureMsg').html(defaultCaptureMsg);
	}
	
	$(".crop1").cropperImage({
		altImage: window.contextPath + '/images/default-alt-profile.png',
        padding: "10px",
        maxWidth: "280px",
        maxWidthAction: null,
        heightSource: "300px",
        aspectRatio: 3 / 4,
        defaultImage: window.contextPath + '/images/camera_close.png',
        params: {
        	image: this,
	        start: "trvlid",
	        email: "email",
	        faceId: "faceid",
	        photoId: "xPhotoId"
        },
        icaoFeaturesRequired: [
			"singleFace",
        	"faceDetected",
        	"focus",
        	"eyesOpen",
        	"portraitImage"
        ],
        icaoFeatures: [
        	{key: "singleFace",text: "Single Face"},
        	{key: "faceDetected",text: "Face Detected"},
        	{key: "focus",text: "Focus"},
        	{key: "eyesOpen",text: "Eyes Open"},
        	{key: "portraitImage",text: "Portrait Style"},
        	{key: "photoNotCenter",text: "Photo Center"},
        	{key: "hairAcrossEyes",text: "Hair Across Eyes"},
        	{key: "eyesTilted",text: "Eyes Tilted"},
        	{key: "background",text: "Busy Background"},
        	{key: "redEyes",text: "Red Eyes"},
        	{key: "shadowBehindHead",text: "Shadow Behind Head"},
        	{key: "faceShadow",text: "Shadow Across Face"},
        	{key: "noReflections",text: "Face Reflection On Skin"},
        ],
        messages : {
        	defaultMsg: 'Click <i class="fa fa-upload" aria-hidden="true"></i> to upload an image or <i class="fa fa-play" aria-hidden="true"></i> to start the camera.',
            qualityErrorMsg: '<span class="text-danger">Quality failed!</span>',
        	icaoErrorMsg: '<span class="text-danger">ICAO failed!</span>',
        	successMsg: '<span class="text-success">Success upload</span>',
        	failMsg: '<span class="text-danger">Failed Upload</span>',
        	icaoSuccessMsg: '<span class="text-success">Icao checking success!</span>',
        },
        urlQualityCheck: window.contextPath + "/mcVerifyAttendance?quality",
        urlIcaoCheck: window.contextPath + "/mcVerifyAttendance?icao",
        urlEnrollCheck: window.contextPath + "/mcVerifyAttendance?enroll=profile",
        callback: function () {
            console.log("result", this); 
            
            if(this!=null){
				if(this.photoId!=null) $('#photoIdField').val(this.photoId);
				if(this.faceId!=null) $('#faceIdField').val(this.faceId);
				if(this.id!=null) $('#passIdField').val(this.id);
				

//	    		embedDataMrz(this.mRZdata);
	    	}
        },
        response: function(){
        	portalUtil.showMainLoading(this.status == 1 ? true : false);
        }
    });
	
	$(".crop2").cropperImage({
		altImage: window.contextPath + '/images/default-alt-passport.png',
        padding: "10px",
        maxWidth: "500px",
        maxWidthAction: null,
        heightSource: "300px",
        aspectRatio: 16 / 11,
        hideCamera: true,
        defaultImage: window.contextPath + '/images/camera_close.png',
        params: {
        	image: this,
	        start: "trvlid",
	        email: "email",
	        faceId: "faceid",
	        photoId: "xPhotoId"
        },
        messages : {
        	defaultMsg: 'Click <i class="fa fa-upload" aria-hidden="true"></i> to upload an image',
        	qualityErrorMsg: '<span class="text-danger">Quality failed!</span>',
        	icaoErrorMsg: '<span class="text-danger">ICAO failed!</span>',
        	successMsg: '<span class="text-success">Success upload</span>',
        	failMsg: '<span class="text-danger">Failed Upload</span>',
        	icaoSuccessMsg: '<span class="text-success">Icao checking success!</span>',
        },
        checkPassport: true,
        checkQuality: false,
        checkIcaoCriteria: false,
        urlQualityCheck: window.contextPath + "/mcVerifyAttendance?quality",
        urlIcaoCheck: window.contextPath + "/mcVerifyAttendance?icao",
        urlEnrollCheck: window.contextPath + "/mcVerifyAttendance?enroll=passport",
        callback: function () {
            console.log("result", this); 
            
            if(this!=null){
				if(this.photoId!=null) $('#photoIdField').val(this.photoId);
				if(this.faceId!=null) $('#faceIdField').val(this.faceId);
				if(this.id!=null) $('#passIdField').val(this.id);
				

	    		embedDataMrz(this.mRZdata);
	    	}
        },
        response: function(){
        	console.log("status pass",this.status);
        	portalUtil.showMainLoading(this.status == 1 ? true : false);
        }
    });
	

	
	$(document).on('change','select[name="acctPassport.nationality.cntryCd"]',function(){
		var data = $(this).val();
		console.log(data);
		if(data!=null) $('select[name="country.cntryCd"]').val(data);
		if(data!=null) $('select[name="country.cntryCd"]').trigger("change");
		if(data!=null) $('select[name="birthPlace.cntryCd"]').val(data);
		if(data!=null) $('select[name="birthPlace.cntryCd"]').trigger("change");
	});
	
	function embedDataMrz(mRZdata){
		
		try {
			if(mRZdata!=null){
				if(mRZdata.first_name!=null) $('#fullName').val(mRZdata.first_name);
				if(mRZdata.nationality!=null) $('select[name="nationality.cntryCd"]').val(mRZdata.nationality);
				if(mRZdata.nationality!=null) $('select[name="nationality.cntryCd"]').trigger("change");
				if(mRZdata.country!=null) $('select[name="country.cntryCd"]').val(mRZdata.country);
				if(mRZdata.country!=null) $('select[name="country.cntryCd"]').trigger("change");
				if(mRZdata.document_no!=null) $('input[name="acctPassport.passportNo"]').val(mRZdata.document_no);
				if(mRZdata.gender!=null) $('select[name="gender"]').val(mRZdata.gender);
				if(mRZdata.gender!=null) $('select[name="gender"]').trigger("change");
				if(mRZdata.nationality!=null) $('select[name="birthPlace.cntryCd"]').val(mRZdata.nationality);
				if(mRZdata.nationality!=null) $('select[name="birthPlace.cntryCd"]').trigger("change");
				
				
				if(mRZdata.date_of_expiry!=null){
					var expDate = moment(mRZdata.date_of_expiry,'DD/MM/YYYY');
					$('input[name="passportExpStr"]').val(expDate.format("DD/MM/YYYY"));
					$('input[name="passportExpStr"]').trigger("change");
				}

				if(mRZdata.date_of_birth!=null){

					var birthDate = moment(mRZdata.date_of_birth,'DD/MM/YYYY');
					$('input[name="dobStr"]').val(birthDate.format("DD/MM/YYYY"));
					$('input[name="dobStr"]').trigger("change");
					
					$.ajax({
				        'async' : false,
						'global' : false,
						headers : {
							'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
						},
						type: "POST",
						action : 'xhttp',
				        url: contextPath + "/mcVerifyAttendance/getType?type="+moment().diff(birthDate, 'years'),
				       
				    }).done(function(a) {
				    	
				    	if(a!=null){
//				    		console.log(JSON.parse(a));
					    	var meta = JSON.parse(a);
					    	
					    	$('#typeField').val(meta.mtdtCd);
					    	$('#typeFieldDesc').val(meta.mtdtDesc);
				    	}
				    	
				    });
				
				}
				
				
				
			}
		} catch (e) {
			// TODO: handle exception
		}
		
		
		
		
	}
});


$(function ($) {
    var video;
    // var localstream;
    // var cropper;
    var onVideoLoad = false;

    $.fn.cropperImage = function (options) {
    	var mainThis = this;
        var parent = null;
        var cropper = null;
        var varcroppedImageDataURL = null;
        var localstream;

        var settings = $.extend({
            // These are the defaults.
        	altImage: null,
            maxWidth: "200px",
            maxWidthAction: null,
            heightSource: "300px",
            padding: "10px",
            aspectRatio: 3 / 4,
            fit: 0,
            // autoCropArea: 0,
            defaultImage: '',
            hideUpload: false,
            hideCamera: false,
            checkPassport: false,
            checkIcaoCriteria: true,
            enrollService: true,
            pathDocumentView: null,
            icaoFeatures: [
            	{key: "singleFace",text: "Single Face"},
            	{key: "faceDetected",text: "Face Detected"},
            	{key: "focus",text: "Focus"}
            ],
            icaoFeaturesRequired: [
            	"singleFace",
	        	"faceDetected",
	        	"focus",
            ],
            btnUploadImageClass: 'btnUploadImage',
            btnCropImageClass: 'btnCropImage',
            btnSnapVideoClass: 'btnSnapVideo',
            btnEnableVideoClass: 'btnEnableVideo',
            btnDisableVideoClass: 'btnDisableVideo',
            messageBoxClass: 'cropperImage-action-text',
            messages : {
            	defaultMsg: 'Click <i class="fa fa-upload" aria-hidden="true"></i> to upload an image or <i class="fa fa-play" aria-hidden="true"></i> to start the camera.',
            	qualityErrorMsg: 'Quality failed!',
            	icaoErrorMsg: 'ICAO failed!',
            	successMsg: 'Success upload',
            	failMsg: 'Failed Upload',
            	icaoSuccessMsg: 'Icao checking success!',
            }
            
        }, options);
        
        settings.pathDocumentView = this.attr("file-path");
        settings.params = {
    		start: this.data("trvlid"),
	        email: this.data("email"),
	        faceId: this.data("faceid"),
	        photoId: this.data("photoid")
        };
        
        buildTemplate();

        
        mainThis.find('.cropperImage-criteria-icao-text').hover(
		  function() {
		    mainThis.find('.cropperImage-criteria-icao-card').removeClass('cropperImage-class-none');
		  }, function() {
		   mainThis.find('.cropperImage-criteria-icao-card').addClass('cropperImage-class-none');
		  }
		);
        
        
        function buildTemplate() {
//        	console.log(mainThis);
        	
			var mainTempLayout = $('<div/>').addClass("cropperImage-layout rounded");
			var mainTempSourceLayout = $('<div/>').addClass("cropperImage-source-layout border");
			mainTempSourceLayout.append($("<div/>").addClass("col-source"));
			mainTempSourceLayout.find('.col-source').append(
					$("<div/>").addClass("cropperImage-source cropperImage-class-none")
					.append(
							$("<img/>").addClass("cropperImage-source-image cropperImage-class-none")
					).append(
							$("<video/>").addClass("cropperImage-source-video cropperImage-class-none")
							.html("Your browser does not support the video tag.")
					)
			);
			mainTempSourceLayout.find('.col-source').append(
					$("<div/>").addClass("cropperImage-ouput")
					.append(
							$("<img/>").addClass("cropperImage-output-image")
							.attr("border",0)
							.css("border",0).css("text-decoration","none").css("outline","none").css("background","white")
							.attr("src",settings.params.photoId!=null ? settings.pathDocumentView+settings.params.photoId : null)
					)
			);
			
			var mainTempActionLayout = $('<div/>').addClass("cropperImage-action-layout border");
			
			mainTempActionLayout.append($("<div/>").addClass("row"));
			var mainTempActionLayoutRow = mainTempActionLayout.find('.row');
			
			mainTempActionLayoutRow.append($("<div/>").addClass("col col-left"));
			
			var mainTempActionLayoutColLeft = mainTempActionLayoutRow.find('.col-left');
			
			if(settings.altImage!=null)
			{
				mainTempActionLayoutRow.append($("<div/>").addClass("col-md-auto col-right d-flex align-items-center justify-content-center"));
				var mainTempActionLayoutColRight = mainTempActionLayoutRow.find('.col-right');
				
//				setup altImage
				mainTempActionLayoutColRight.append($("<img/>").addClass('p-2').attr('src',settings.altImage).css('height','90px'));
			}
			
			mainTempActionLayoutColLeft.append($("<div/>").addClass("col-source cropperImage-action pb-1 text-center"));

			mainTempActionLayoutColLeft.find('.col-source').append(
					$("<input/>").addClass("cropperImage-class-none").attr("id","fileInput").attr("type","file").attr("accept","image/*")
			);
			mainTempActionLayoutColLeft.find('.col-source').append(
					$("<bst:btn-sm-error/>").addClass("text-center btnUploadImage").attr("type","button")
					.append(
						$("<em/>").addClass("btnIconInitial fa fa-upload").attr("aria-hidden",true)
					)
			);
			mainTempActionLayoutColLeft.find('.col-source').append(
					$("<bst:btn-sm-error/>").addClass("btnIconInitialOuter text-center btnCropImage cropperImage-class-none").attr("type","button")
					.html("Crop &amp; Save")
			);
			

			mainTempActionLayoutColLeft.find('.col-source').append(
						$("<bst:btn-sm-error/>").addClass("text-center btnSnapVideo cropperImage-class-none").attr("type","button")
						.append(
							$("<em/>").addClass("btnIconInitial fa fa-camera").attr("aria-hidden",true)
						)
				);

			if(!settings.hideCamera){
				mainTempActionLayoutColLeft.find('.col-source').append(
						$("<bst:btn-sm-error/>").addClass("text-center btnEnableVideo").attr("type","button")
						.append(
							$("<em/>").addClass("btnIconInitial fa fa-play").attr("aria-hidden",true)
						)
				);
			}
			
			mainTempActionLayoutColLeft.find('.col-source').append(
					$("<bst:btn-sm-error/>").addClass("text-center btnDisableVideo cropperImage-class-none").attr("type","button")
					.append(
						$("<em/>").addClass("btnIconInitial fa fa-stop").attr("aria-hidden",true)
					)
			);
			
			mainTempActionLayoutColLeft.append($("<div/>").addClass("col-source cropperImage-action-text pt-1 text-center"));

			
			mainTempLayout.append(mainTempSourceLayout);
			mainTempLayout.append(mainTempActionLayout);
			mainThis.append(mainTempLayout);
			
			parent = mainThis.find(".cropperImage-layout");
			
			mainThis.find('.col-source').css('max-width', settings.maxWidth);
			mainThis.find('.col-source.cropperImage-action').css('max-width', settings.maxWidthAction != null ? settings.maxWidthAction : '100%');
			mainThis.find('.col-source.cropperImage-action-text').css('max-width', settings.maxWidthAction != null ? settings.maxWidthAction : '100%');
			mainThis.find('.cropperImage-source-layout')
	            .css('height', settings.heightSource);
	        // parent.find('.cropperImage-ouput')
	        //     .css('height', settings.heightSource);
			mainThis.find('.cropperImage-source-layout .col-source')
	            .css('padding', settings.padding);
			mainThis.find('.cropperImage-action-layout .col-source')
	            .css('padding', settings.padding);
			mainThis.find('.cropperImage-ouput').css('background-image',settings.params.photoId==null ? 'url('+settings.defaultImage+')' : null);
	        
/*	        if(settings.checkIcaoCriteria){

	        	var parentDiv = $("<div/>").addClass("position-relative cropperImage-criteria-icao cropperImage-class-none text-center border rounded");
	        	
	        	parentDiv.append($("<span/>").addClass("cropperImage-criteria-icao-text cropperImage-class-none success").append($("<i/>").addClass("fa fa-check text-success")).append("All ICAO face checking criteria PASS"));
	        	parentDiv.append($("<span/>").addClass("cropperImage-criteria-icao-text cropperImage-class-none failed text-danger").append($("<i/>").addClass("fa fa-exclamation-circle")).append("View ICAO Checking"));
	        	var layoutCriteria = $("<div/>").addClass("position-absolute text-left col-12 cropperImage-criteria-icao-card cropperImage-class-none").append($("<div/>").addClass("row p-1"));

	        	$.each(settings.icaoFeatures,function(index,value){
	        		var divT = $("<p/>").addClass('col-4').addClass("col cropperImage-criteria-icao-input data-"+value.key).html(value.text);
	        		layoutCriteria.find("div").append(divT);
	        	});
	        	
	        	parentDiv.append(layoutCriteria);
	        	
	        	mainThis.append(parentDiv);
	        } */
	        
	        if(settings.checkIcaoCriteria){
	        	var parentDiv = $("<div/>").addClass("position-relative cropperImage-criteria-icao cropperImage-class-none text-center border rounded");
	        	
	        	parentDiv.append($("<span/>").addClass("cropperImage-criteria-icao-text cropperImage-class-none success").append($("<i/>").addClass("fa fa-check text-success")).append("All ICAO face checking criteria PASS"));
	        	parentDiv.append($("<span/>").addClass("cropperImage-criteria-icao-text cropperImage-class-none failed text-danger").append($("<i/>").addClass("fa fa-exclamation-circle")).append("View ICAO Checking"));
	        	var layoutCriteria = $("<div/>").addClass("position-absolute text-left col-12 cropperImage-criteria-icao-card cropperImage-class-none").append($("<div/>").addClass("row p-1"));

	        	$.each(settings.icaoFeatures,function(index,value){
	        		var divT = $("<p/>").addClass('col-4').addClass("col cropperImage-criteria-icao-input data-"+value.key).append($("<span/>").addClass('criteria-star d-inline-block position-relative').html(value.text));
	        		layoutCriteria.find("div").append(divT);
	        		
	        		if($.inArray(value.key,settings.icaoFeaturesRequired)>=0)  divT.find('.criteria-star').addClass('req');
	        	});
	        	
	        	parentDiv.append(layoutCriteria);
	        	
	        	mainThis.append(parentDiv);
	        }
	        
		}

        function calculateSizeKbBase64String(base64) {
            var stringLength = base64.length - 'data:image/png;base64,'.length;
            var sizeInBytes = 4 * Math.ceil((stringLength / 3)) * 0.5624896334383812;
            return sizeInBytes / 1024;
        }

        // setup display crop / show image
        function setupShowImage(base64) {
            parent.find(".cropperImage-source-image").addClass("cropperImage-class-none");
            parent.find(".cropperImage-source-video").addClass("cropperImage-class-none");
            parent.find(".cropperImage-source").addClass("cropperImage-class-none");

            parent.find(".cropperImage-ouput").removeClass("cropperImage-class-none");
            parent.find('.cropperImage-ouput').css('background-image',base64==null ? 'url('+settings.defaultImage+')' : null);
	        


            cropper.cropper('reset');
            cropper.cropper('clear');
            cropper.cropper('destroy');
            // cropper.cropper('replace', null);

            parent.find(".cropperImage-ouput .cropperImage-output-image").attr("src", base64);

            settings.params = {
            	image: base64,
            	start: settings.params.start,
    	        email: settings.params.email,
    	        faceId: settings.params.faceId,
    	        photoId: settings.params.photoId
            };
            checkQuality();
            // showImageAfterCrop();
        }

        function checkQuality() {
            options.response.call({status:1});
			if(settings.checkPassport){
		//        options.response.call({status:0});
		//        options.callback.call({id});
		//		setting.
		        checkEnroll(settings.params);
				return;
				
		
			}

        	var features = settings.checkIcaoCriteria ? settings.icaoFeatures.map(a=>a.key) : [];
    		$.each(features,function(index,value){
    			mainThis.find('.cropperImage-criteria-icao-input.data-'+value).removeClass("ticked failed");
    			
    		});
//        	settings.params.image = base64;


	        mainThis.find('.cropperImage-criteria-icao').addClass('cropperImage-class-none');
        	
        	$.ajax({
    			'global' : false,
    			headers : {
    				'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
    			},
    			type: "POST",
    			action : 'xhttp',
    	        url: settings.urlQualityCheck,
    	        data: settings.params
    	    }).done(function(a) {
    	    	if(a.result == 'pass') {

    	        	if(!settings.checkIcaoCriteria){
    	        		
    	        		if(!settings.enrollService){
            	    		parent.find("."+settings.messageBoxClass).html(settings.messages.icaoSuccessMsg);
            	    		console.log(parent.find("."+settings.messageBoxClass),settings.messages.icaoSuccessMsg);
        		            options.response.call({status:0});
        	        		options.callback.call(a);
        	        		return;
        	        	}
    	        		
    	        		checkEnroll();
    	        		return;
    	        	}
    	    		
//    	    		enrollId(0,enroll);
    	    		checkIcao();
    	    	} else {
					console.log("failed");
	            	mainThis.find('.cropperImage-criteria-icao').addClass('cropperImage-class-none');
    	            options.response.call({status:0});
    	    		parent.find("."+settings.messageBoxClass).html(settings.messages.qualityErrorMsg);
//    	    		//$(enroll).find("#btnIcao").html("Failed Upload <i class='fa fa-times-circle' aria-hidden='true' style='color:#dc3545;'></i>")
//    	    		$(enroll).find("#btnCamvi").hide();
//    	    		$(enroll).find('#captureMsg').html(defaultCaptureMsgQualityCheck);
    	    	}
    	    	
    	    }).fail(function() {
					console.log("failed aa");
	            options.response.call({status:0});
	            mainThis.find('.cropperImage-criteria-icao').addClass('cropperImage-class-none');
	    		parent.find("."+settings.messageBoxClass).html(settings.messages.qualityErrorMsg);
    	    })
		}

        function checkIcao() {
        	
        	// Now it can be used reliably with $.map()
        	var icaoFeaturesArray = $.map( settings.icaoFeatures, function( val, i ) {
        	  // Do something
//        		return va
        	});
        	
        	var features = settings.checkIcaoCriteria ? settings.icaoFeatures.map(a=>a.key) : [];
        	var featuresRequired = settings.icaoFeaturesRequired;
    		
//    		console.log("find",parent.find('.cropperImage-criteria-icao'));
    		
    		mainThis.find('.cropperImage-criteria-icao').removeClass('cropperImage-class-none')
    		

            settings.params = {
            	image: settings.params.image.replace('data:image/png;base64,', ''),
            	start: settings.params.start,
    	        email: settings.params.email,
    	        faceId: settings.params.faceId,
    	        photoId: settings.params.photoId,
		        icaoCriteria: features.join(','),
		        icaoCriteriaRequired: featuresRequired.join(',')
            };
            
    	    
    		
        	$.ajax({
    			'global' : false,
    			headers : {
    				'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
    			},
    			type: "POST",
    			action : 'xhttp',
    	        url: settings.urlIcaoCheck,
    	        data: settings.params
    	    }).done(function(a) {
	    		$.each(features,function(index,value){
	    			mainThis.find('.cropperImage-criteria-icao-input.data-'+value).removeClass("ticked failed");
//	    			console.log(value,a,a[value],parent.find('.cropperImage-criteria-icao-input[value='+value+']'));
	    			if(a[value]==true){
	    				mainThis.find('.cropperImage-criteria-icao-input.data-'+value).addClass("ticked");
	    			}
	    			else{
	    				mainThis.find('.cropperImage-criteria-icao-input.data-'+value).addClass("failed");
	    			}
	    		});
	    		
	    		mainThis.find('.cropperImage-criteria-icao').removeClass('cropperImage-class-none');
	    		mainThis.find('.cropperImage-criteria-icao-text').addClass('cropperImage-class-none');
    	    	if(a.result == 'pass') {
//    	    		enrollId(0,enroll);
    	    		mainThis.find('.cropperImage-criteria-icao-text.success').removeClass('cropperImage-class-none');


    	        	if(!settings.enrollService){
        	    		parent.find("."+settings.messageBoxClass).html(settings.messages.icaoSuccessMsg);
        	    		console.log(parent.find("."+settings.messageBoxClass),settings.messages.icaoSuccessMsg);
    		            options.response.call({status:0});
    	        		options.callback.call(a);
    	        		return;
    	        	}
    	    		
    	    		checkEnroll();
    	    	} else {
    	    		mainThis.find('.cropperImage-criteria-icao-text.failed').removeClass('cropperImage-class-none');


    	            options.response.call({status:0});
    	    		parent.find("."+settings.messageBoxClass).html(settings.messages.icaoErrorMsg);
//    	    		//$(enroll).find("#btnIcao").html("Failed Upload <i class='fa fa-times-circle' aria-hidden='true' style='color:#dc3545;'></i>")
//    	    		$(enroll).find("#btnCamvi").hide();
//    	    		$(enroll).find('#captureMsg').html(defaultCaptureMsgQualityCheck);
    	    	}
    	    	
    	    }).fail(function() {
	            options.response.call({status:0});
	    		parent.find("."+settings.messageBoxClass).html(settings.messages.icaoErrorMsg);
    	    })
		}

        function checkEnroll(params=null) {
        	
        	var param = params!=null 
    		? {
	            	image: settings.params.image.replace('data:image/png;base64,', ''),
	            	start: settings.params.start,
	    	        email: settings.params.email,
	    	        faceId: settings.params.faceId,
	    	        photoId: settings.params.photoId
	            }
    		: settings.params ;
            
	    	
	    	$.ajax({
				'global' : false,
				headers : {
					'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
				},
				type: "POST",
				action : 'xhttp',
		        url: settings.urlEnrollCheck,
		        data: param
		    }).done(function(a) {
	    		parent.find("."+settings.messageBoxClass).html(settings.messages.successMsg);
                options.callback.call(a);
	            options.response.call({status:0});
    	    }).fail(function() {

	            options.response.call({status:0});
	    		parent.find("."+settings.messageBoxClass).html(settings.messages.failMsg);
                
    	    });
		}

        function createCropImage() {
            varcroppedImageDataURL = cropper
                .cropper('getCroppedCanvas', {
                    // width: 200,
                    // height: 400,
                    imageSmoothingEnabled: true,
                    imageSmoothingQuality: "high",
                })
                .toDataURL();

            // console.log(varcroppedImageDataURL);
            scaleSourceForShow(varcroppedImageDataURL);
        }

        function scaleSourceForShow(base64) {

            var img = document.createElement('img');

            // When the event "onload" is triggered we can resize the image.
            img.onload = function () {
                // We create a canvas and get its context.
                var canvas = document.createElement('canvas');
                var ctx = canvas.getContext('2d');

                var scale = 1;
                var scaleWidth, scaleHeight;

                if (this.width > 1000 || this.height > 1000) {
                    if (1000 / this.width < scale) {
                        scale = 1000 / this.width;

                    }
                    if (1000 / this.height < scale) {
                        scale = 1000 / this.height;
                    }
                }

                scaleWidth = img.width * scale;
                scaleHeight = img.height * scale;

                // We set the dimensions at the wanted size.
                canvas.width = scaleWidth;
                canvas.height = scaleHeight;

                // We resize the image with the canvas method drawImage();
                ctx.drawImage(this, 0, 0, scaleWidth, scaleHeight);

                var dataURI = canvas.toDataURL();

                parent.find('.'+settings.btnCropImageClass).addClass("cropperImage-class-none");
                parent.find('.'+settings.btnDisableVideoClass).addClass("cropperImage-class-none");
                parent.find('.'+settings.btnEnableVideoClass).addClass("cropperImage-class-none");
                parent.find('.'+settings.btnSnapVideoClass).addClass("cropperImage-class-none");

                parent.find('.'+settings.btnEnableVideoClass).removeClass("cropperImage-class-none");
                parent.find('.'+settings.btnUploadImageClass).removeClass("cropperImage-class-none");
                setupShowImage(canvas.toDataURL());

            };
            img.src = base64;
        }



        function initiateCropper() {
            cropper = parent.find('.cropperImage-source-image').cropper({
                aspectRatio: options.aspectRatio,
                dragMode: "move",
                cropBoxMovable: false,
                cropBoxResizable: false,
                viewMode: settings.fit,
            });
        }

        function stopVideo(){
            if(video!=null){
                
                video.pause();
                localstream.getTracks()[0].stop();
            }
        }

        function startVideo() {
            var videoSource = parent.find(".col-source .cropperImage-source-video");
            var constraints = { audio: false, video: true }; 

            
            var constraints = {
                audio: false, video: {aspectRatio: options.aspectRatio},
                // width: { min: 440, ideal: 1080, max: 1080 },
                // height: { min: 700, ideal: 1920 },
                // aspectRatio: 0.777777778,
                frameRate: { max: 60 },
                facingMode: { exact: "user" }
            };

            navigator.mediaDevices.getUserMedia(constraints)
            .then(function(mediaStream) {
                    try {

                
                parent.find('.'+settings.btnUploadImageClass).addClass("cropperImage-class-none");
                parent.find('.'+settings.btnSnapVideoClass).removeClass("cropperImage-class-none");
                parent.find('.'+settings.btnEnableVideoClass).addClass("cropperImage-class-none");
                parent.find('.'+settings.btnDisableVideoClass).removeClass("cropperImage-class-none");
                
                localstream = mediaStream;
                video = parent.find(".col-source .cropperImage-source-video").show()[0];
                video.srcObject = mediaStream;
                video.onloadedmetadata = function() {
                if(video) video.play();
                parent.find(".col-source .cropperImage-source").removeClass("cropperImage-class-none");
                videoSource.removeClass("cropperImage-class-none");
                parent.find(".col-source .cropperImage-ouput").addClass("cropperImage-class-none");

            };
                    } catch (error) {
                        
                    }
                localstream = mediaStream;
            }).catch(function(err) {
            
            console.log(err.name + ": " + err.message); 
            });
            
        }

        function initiateFileReader() {
            parent.find("#fileInput").on("change", function () {
                var file = $(this);
                if (this.files && this.files[0]) {
                    if (this.files[0].type.match(/^image\//)) {
                        var reader = new FileReader();
                        reader.onload = function (evt) {
                            setupNewImageCropLayout(evt.target.result);
                            file.val("");
                        };
                        reader.readAsDataURL(this.files[0]);
                    } else {
                        alert("Invalid file type! Please select an image file.");
                    }
                } else {
                    alert("No file(s) selected.");
                }
            });
        }

         // Capture video frame
         function captureVideo() {
            var canvas = document.createElement("canvas");
            videoLayout = parent.find(".capture #videoSource").get(0);
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;

            canvas.getContext("2d").drawImage(video, 0, 0, canvas.width, canvas.height);
            // stopVideo();
            stopVideo();
            setupNewImageCropLayout(canvas.toDataURL());
        }


        // setup crop source image / replace
        function setupNewImageCropLayout(base64) {
            initiateCropper();
            cropper.cropper('reset');
            cropper.cropper('clear');
            
            parent.find(".cropperImage-source-video").addClass("cropperImage-class-none");
            parent.find(".cropperImage-ouput").addClass("cropperImage-class-none");
            parent.find(".cropperImage-source").removeClass("cropperImage-class-none");
            parent.find('.'+settings.btnSnapVideoClass).addClass("cropperImage-class-none");
            parent.find('.'+settings.btnDisableVideoClass).addClass("cropperImage-class-none");
            parent.find('.'+settings.btnEnableVideoClass).addClass("cropperImage-class-none");

            
            parent.find('.'+settings.btnCropImageClass).removeClass("cropperImage-class-none");

            cropper.cropper('replace', base64);
        }
        
        function defaultStatus(){
        	parent.find('.'+settings.btnDisableVideoClass).addClass("cropperImage-class-none");
            parent.find(".cropperImage-source").addClass("cropperImage-class-none");
            parent.find(".cropperImage-source-video").addClass("cropperImage-class-none");
            parent.find(".cropperImage-ouput").removeClass("cropperImage-class-none"); 
            parent.find('.'+settings.btnUploadImageClass).removeClass("cropperImage-class-none");
        	parent.find('.'+settings.btnEnableVideoClass).removeClass("cropperImage-class-none");
        	parent.find('.'+settings.btnSnapVideoClass).addClass("cropperImage-class-none");
        	parent.find('.cropperImage-action-text').html(settings.messages.defaultMsg);
//        	defaultCaptureMsg
        }

        // initiateCropper();
        initiateFileReader();
        defaultStatus();

        $(parent).on("click", "."+settings.btnCropImageClass, function () {
            createCropImage();
            // showCrop(false);
        });

        $(parent).on("click", "."+settings.btnUploadImageClass, function () {
            $(parent).find("#fileInput").click();
        });

        $(parent).on("click", "."+settings.btnEnableVideoClass, function () {
            startVideo();
        });

        $(parent).on("click", "."+settings.btnSnapVideoClass, function () {
            captureVideo();
        });

        $(parent).on("click", "."+settings.btnDisableVideoClass, function () {
            stopVideo();
            defaultStatus();
        });
    }
}( jQuery ));