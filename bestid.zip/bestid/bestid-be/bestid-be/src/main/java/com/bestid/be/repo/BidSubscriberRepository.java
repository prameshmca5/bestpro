/**
 *
 */
package com.bestid.be.repo;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidSubscriber;

/**
 * @author mukhlis.hamzah
 * @since 1 Mar 2019
 */
@Repository
@RepositoryDefinition(domainClass = BidSubscriber.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_SUBSCRIBER_REPOSITORY)
public interface BidSubscriberRepository extends GenericRepository<BidSubscriber> {

	@Query("select u from BidSubscriber u where u.subscrCd= :subscrCd")
	BidSubscriber findSysCd(@Param("subscrCd") String subscrCd);

	@Query("select u from BidCompany u ,BidSubscriber s where u.cmpnyId= s.cmpnyId and u.cmpnyRegNo= :cmpnyRegNo and s.sysName= :sysName  ")
	BidSubscriber findByCmpnyRegNoAndSysName(@Param("cmpnyRegNo") String cmpnyRegNo, @Param("sysName") String sysName);
	
	@Query("select u from BidSubscriber u where u.subscrId= :subscrId and u.subscrType= :subscrType")
	BidSubscriber findBySubscribIdType(@Param("subscrId") int subscrId, @Param("subscrType") String subscrType);

}
