package com.portal.web.mc.form;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import com.be.sdk.model.MRZdata;
import com.camvi.sdk.model.FacesDto;

public class PersonFormDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String personId;

	private String faceId;
	
	private MRZdata mRZdata;

	public MRZdata getmRZdata() {
		return mRZdata;
	}

	public void setmRZdata(MRZdata mRZdata) {
		this.mRZdata = mRZdata;
	}

	private double confidence;

	private String person;

	private String face;

	private String name;

	private List<String> details;

	private String creation;

	private String code;

	private String message;

	private List<FacesDto> faces;
	
	private String result;
	
	private double similarity;
	
	/** The id. document */
	private String id;

	/** The refno. */
	private String refno;

	/** The docid. */
	private Integer docid;

	/** The txnno. */
	private String txnno;

	/** The files id. */
	private String filesId;

	/** The filename. */
	private String filename;

	/** The length. */
	private long length;

	/** The content type. */
	private String contentType;

	/** The version. */
	private String version;

	/** The upload date. */
	private Timestamp uploadDate;

	/** The content. */
	private byte[] content;

	private String dmBucket;
	
	private String photoId;

	public String getPersonId() {
		return personId;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	public String getFaceId() {
		return faceId;
	}

	public void setFaceId(String faceId) {
		this.faceId = faceId;
	}

	public double getConfidence() {
		return confidence;
	}

	public void setConfidence(double confidence) {
		this.confidence = confidence;
	}

	public String getPerson() {
		return person;
	}

	public void setPerson(String person) {
		this.person = person;
	}

	public String getFace() {
		return face;
	}

	public void setFace(String face) {
		this.face = face;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getDetails() {
		return details;
	}

	public void setDetails(List<String> details) {
		this.details = details;
	}

	public String getCreation() {
		return creation;
	}

	public void setCreation(String creation) {
		this.creation = creation;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<FacesDto> getFaces() {
		return faces;
	}

	public void setFaces(List<FacesDto> faces) {
		this.faces = faces;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public double getSimilarity() {
		return similarity;
	}

	public void setSimilarity(double similarity) {
		this.similarity = similarity;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRefno() {
		return refno;
	}

	public void setRefno(String refno) {
		this.refno = refno;
	}

	public Integer getDocid() {
		return docid;
	}

	public void setDocid(Integer docid) {
		this.docid = docid;
	}

	public String getTxnno() {
		return txnno;
	}

	public void setTxnno(String txnno) {
		this.txnno = txnno;
	}

	public String getFilesId() {
		return filesId;
	}

	public void setFilesId(String filesId) {
		this.filesId = filesId;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public long getLength() {
		return length;
	}

	public void setLength(long length) {
		this.length = length;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Timestamp getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(Timestamp uploadDate) {
		this.uploadDate = uploadDate;
	}

	public byte[] getContent() {
		return content;
	}

	public void setContent(byte[] content) {
		this.content = content;
	}

	public String getDmBucket() {
		return dmBucket;
	}

	public void setDmBucket(String dmBucket) {
		this.dmBucket = dmBucket;
	}

	public String getPhotoId() {
		return photoId;
	}

	public void setPhotoId(String photoId) {
		this.photoId = photoId;
	}
	
	

}
