package com.bestpay.pgw.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

 
@JsonInclude(Include.NON_NULL)
public class FpxPayResponse implements Serializable {

	private static final long serialVersionUID = -503202399644239358L;

	private String fpx_msgType; // Indicate Message Type AC

	private String fpx_msgToken; // indicate business model 01-B2C

	private String fpx_fpxTxnId;

	private String fpx_sellerExId;

	private String fpx_sellerExOrderNo;

	private String fpx_sellerTxnTime;

	private String fpx_sellerOrderNo;

	private String fpx_sellerId;

	private String fpx_txnCurrency;

	private String fpx_txnAmount;

	private String fpx_checkSum;

	private String fpx_buyerName;//

	private String fpx_buyerBankId;

	private String fpx_buyerBankBranch;

	private String fpx_buyerId;

	private String fpx_makerName;

	private String fpx_buyerIban;

	private String fpx_debitAuthCode;

	private String fpx_debitAuthNo;

	private String fpx_creditAuthCode;

	private String fpx_creditAuthNo;

	private String fpxUrl;

	private String as_sfid;

	private String as_fid;

	private String fpx_fpxTxnTime;

	private String finalChecksum;


	/**
	 * @return the fpx_msgType
	 */
	public String getFpx_msgType() {
		return fpx_msgType;
	}


	/**
	 * @param fpx_msgType
	 *             the fpx_msgType to set
	 */
	public void setFpx_msgType(String fpx_msgType) {
		this.fpx_msgType = fpx_msgType;
	}


	/**
	 * @return the fpx_msgToken
	 */
	public String getFpx_msgToken() {
		return fpx_msgToken;
	}


	/**
	 * @param fpx_msgToken
	 *             the fpx_msgToken to set
	 */
	public void setFpx_msgToken(String fpx_msgToken) {
		this.fpx_msgToken = fpx_msgToken;
	}


	/**
	 * @return the fpx_fpxTxnId
	 */
	public String getFpx_fpxTxnId() {
		return fpx_fpxTxnId;
	}


	/**
	 * @param fpx_fpxTxnId
	 *             the fpx_fpxTxnId to set
	 */
	public void setFpx_fpxTxnId(String fpx_fpxTxnId) {
		this.fpx_fpxTxnId = fpx_fpxTxnId;
	}


	/**
	 * @return the fpx_sellerExId
	 */
	public String getFpx_sellerExId() {
		return fpx_sellerExId;
	}


	/**
	 * @param fpx_sellerExId
	 *             the fpx_sellerExId to set
	 */
	public void setFpx_sellerExId(String fpx_sellerExId) {
		this.fpx_sellerExId = fpx_sellerExId;
	}


	/**
	 * @return the fpx_sellerExOrderNo
	 */
	public String getFpx_sellerExOrderNo() {
		return fpx_sellerExOrderNo;
	}


	/**
	 * @param fpx_sellerExOrderNo
	 *             the fpx_sellerExOrderNo to set
	 */
	public void setFpx_sellerExOrderNo(String fpx_sellerExOrderNo) {
		this.fpx_sellerExOrderNo = fpx_sellerExOrderNo;
	}


	/**
	 * @return the fpx_sellerTxnTime
	 */
	public String getFpx_sellerTxnTime() {
		return fpx_sellerTxnTime;
	}


	/**
	 * @param fpx_sellerTxnTime
	 *             the fpx_sellerTxnTime to set
	 */
	public void setFpx_sellerTxnTime(String fpx_sellerTxnTime) {
		this.fpx_sellerTxnTime = fpx_sellerTxnTime;
	}


	/**
	 * @return the fpx_sellerOrderNo
	 */
	public String getFpx_sellerOrderNo() {
		return fpx_sellerOrderNo;
	}


	/**
	 * @param fpx_sellerOrderNo
	 *             the fpx_sellerOrderNo to set
	 */
	public void setFpx_sellerOrderNo(String fpx_sellerOrderNo) {
		this.fpx_sellerOrderNo = fpx_sellerOrderNo;
	}


	/**
	 * @return the fpx_sellerId
	 */
	public String getFpx_sellerId() {
		return fpx_sellerId;
	}


	/**
	 * @param fpx_sellerId
	 *             the fpx_sellerId to set
	 */
	public void setFpx_sellerId(String fpx_sellerId) {
		this.fpx_sellerId = fpx_sellerId;
	}


	/**
	 * @return the fpx_txnCurrency
	 */
	public String getFpx_txnCurrency() {
		return fpx_txnCurrency;
	}


	/**
	 * @param fpx_txnCurrency
	 *             the fpx_txnCurrency to set
	 */
	public void setFpx_txnCurrency(String fpx_txnCurrency) {
		this.fpx_txnCurrency = fpx_txnCurrency;
	}


	/**
	 * @return the fpx_txnAmount
	 */
	public String getFpx_txnAmount() {
		return fpx_txnAmount;
	}


	/**
	 * @param fpx_txnAmount
	 *             the fpx_txnAmount to set
	 */
	public void setFpx_txnAmount(String fpx_txnAmount) {
		this.fpx_txnAmount = fpx_txnAmount;
	}


	/**
	 * @return the fpx_checkSum
	 */
	public String getFpx_checkSum() {
		return fpx_checkSum;
	}


	/**
	 * @param fpx_checkSum
	 *             the fpx_checkSum to set
	 */
	public void setFpx_checkSum(String fpx_checkSum) {
		this.fpx_checkSum = fpx_checkSum;
	}


	/**
	 * @return the fpx_buyerName
	 */
	public String getFpx_buyerName() {
		return fpx_buyerName;
	}


	/**
	 * @param fpx_buyerName
	 *             the fpx_buyerName to set
	 */
	public void setFpx_buyerName(String fpx_buyerName) {
		this.fpx_buyerName = fpx_buyerName;
	}


	/**
	 * @return the fpx_buyerBankId
	 */
	public String getFpx_buyerBankId() {
		return fpx_buyerBankId;
	}


	/**
	 * @param fpx_buyerBankId
	 *             the fpx_buyerBankId to set
	 */
	public void setFpx_buyerBankId(String fpx_buyerBankId) {
		this.fpx_buyerBankId = fpx_buyerBankId;
	}


	/**
	 * @return the fpx_buyerBankBranch
	 */
	public String getFpx_buyerBankBranch() {
		return fpx_buyerBankBranch;
	}


	/**
	 * @param fpx_buyerBankBranch
	 *             the fpx_buyerBankBranch to set
	 */
	public void setFpx_buyerBankBranch(String fpx_buyerBankBranch) {
		this.fpx_buyerBankBranch = fpx_buyerBankBranch;
	}


	/**
	 * @return the fpx_buyerId
	 */
	public String getFpx_buyerId() {
		return fpx_buyerId;
	}


	/**
	 * @param fpx_buyerId
	 *             the fpx_buyerId to set
	 */
	public void setFpx_buyerId(String fpx_buyerId) {
		this.fpx_buyerId = fpx_buyerId;
	}


	/**
	 * @return the fpx_makerName
	 */
	public String getFpx_makerName() {
		return fpx_makerName;
	}


	/**
	 * @param fpx_makerName
	 *             the fpx_makerName to set
	 */
	public void setFpx_makerName(String fpx_makerName) {
		this.fpx_makerName = fpx_makerName;
	}


	/**
	 * @return the fpx_buyerIban
	 */
	public String getFpx_buyerIban() {
		return fpx_buyerIban;
	}


	/**
	 * @param fpx_buyerIban
	 *             the fpx_buyerIban to set
	 */
	public void setFpx_buyerIban(String fpx_buyerIban) {
		this.fpx_buyerIban = fpx_buyerIban;
	}


	/**
	 * @return the fpx_debitAuthCode
	 */
	public String getFpx_debitAuthCode() {
		return fpx_debitAuthCode;
	}


	/**
	 * @param fpx_debitAuthCode
	 *             the fpx_debitAuthCode to set
	 */
	public void setFpx_debitAuthCode(String fpx_debitAuthCode) {
		this.fpx_debitAuthCode = fpx_debitAuthCode;
	}


	/**
	 * @return the fpx_debitAuthNo
	 */
	public String getFpx_debitAuthNo() {
		return fpx_debitAuthNo;
	}


	/**
	 * @param fpx_debitAuthNo
	 *             the fpx_debitAuthNo to set
	 */
	public void setFpx_debitAuthNo(String fpx_debitAuthNo) {
		this.fpx_debitAuthNo = fpx_debitAuthNo;
	}


	/**
	 * @return the fpx_creditAuthCode
	 */
	public String getFpx_creditAuthCode() {
		return fpx_creditAuthCode;
	}


	/**
	 * @param fpx_creditAuthCode
	 *             the fpx_creditAuthCode to set
	 */
	public void setFpx_creditAuthCode(String fpx_creditAuthCode) {
		this.fpx_creditAuthCode = fpx_creditAuthCode;
	}


	/**
	 * @return the fpx_creditAuthNo
	 */
	public String getFpx_creditAuthNo() {
		return fpx_creditAuthNo;
	}


	/**
	 * @param fpx_creditAuthNo
	 *             the fpx_creditAuthNo to set
	 */
	public void setFpx_creditAuthNo(String fpx_creditAuthNo) {
		this.fpx_creditAuthNo = fpx_creditAuthNo;
	}


	/**
	 * @return the fpxUrl
	 */
	public String getFpxUrl() {
		return fpxUrl;
	}


	/**
	 * @param fpxUrl
	 *             the fpxUrl to set
	 */
	public void setFpxUrl(String fpxUrl) {
		this.fpxUrl = fpxUrl;
	}


	/**
	 * @return the as_sfid
	 */
	public String getAs_sfid() {
		return as_sfid;
	}


	/**
	 * @param as_sfid
	 *             the as_sfid to set
	 */
	public void setAs_sfid(String as_sfid) {
		this.as_sfid = as_sfid;
	}


	/**
	 * @return the as_fid
	 */
	public String getAs_fid() {
		return as_fid;
	}


	/**
	 * @param as_fid
	 *             the as_fid to set
	 */
	public void setAs_fid(String as_fid) {
		this.as_fid = as_fid;
	}


	/**
	 * @return the fpx_fpxTxnTime
	 */
	public String getFpx_fpxTxnTime() {
		return fpx_fpxTxnTime;
	}


	/**
	 * @param fpx_fpxTxnTime
	 *             the fpx_fpxTxnTime to set
	 */
	public void setFpx_fpxTxnTime(String fpx_fpxTxnTime) {
		this.fpx_fpxTxnTime = fpx_fpxTxnTime;
	}


	public String getFinalChecksum() {
		return finalChecksum;
	}


	public void setFinalChecksum(String finalChecksum) {
		this.finalChecksum = finalChecksum;
	}

}