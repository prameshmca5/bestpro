/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;


/**
 * @author michelle.angela
 *
 */
public class TvlRefund implements Serializable, IQfCriteria<TvlRefund> {

	private static final long serialVersionUID = -3355258602745188873L;

	private Integer tvlRefundId;

	private PaymentDtl tvlPaymentDtl;

	private Metadata refundTypeMtdt;

	private ConfigPaymentBreakdown pmtBreakdown;

	private double amount;

	private String remarks;

	private Status status;

	public Integer getTvlRefundId() {
		return tvlRefundId;
	}


	public void setTvlRefundId(Integer tvlRefundId) {
		this.tvlRefundId = tvlRefundId;
	}


	public PaymentDtl getTvlPaymentDtl() {
		return tvlPaymentDtl;
	}


	public void setTvlPaymentDtl(PaymentDtl tvlPaymentDtl) {
		this.tvlPaymentDtl = tvlPaymentDtl;
	}


	public Metadata getRefundTypeMtdt() {
		return refundTypeMtdt;
	}


	public void setRefundTypeMtdt(Metadata refundTypeMtdt) {
		this.refundTypeMtdt = refundTypeMtdt;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public ConfigPaymentBreakdown getPmtBreakdown() {
		return pmtBreakdown;
	}


	public void setPmtBreakdown(ConfigPaymentBreakdown pmtBreakdown) {
		this.pmtBreakdown = pmtBreakdown;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}

}
