/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.model.MerChanSet;
import com.bestpay.be.sdk.model.MerGenInfo;
import com.bestpay.be.sdk.model.MerPayPageSet;
import com.bestpay.be.sdk.model.PaymentLinkInfo;
import com.bestpay.be.sdk.model.PgwResponse;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.web.config.ConfigConstants;
import com.bestpay.web.constants.AppConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;

/**
 * @author Rashid
 * @since Oct 19, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_FPX_PAYLK)
public class MerFpxPaymentController extends AbstractController {

	private static final Logger logger = LoggerFactory.getLogger(MerFpxPaymentController.class);

	private static final String TEST_PAYMENT_LINK = "testPaymentLink";

	@GetMapping
	public ModelAndView view(@ModelAttribute(TEST_PAYMENT_LINK) PaymentLinkInfo paymentLinkInfo,
			MerPayPageSet merPayPageSet, BindingResult result, HttpSession sessio, HttpServletResponse response)
			throws BeException {
		logger.info("WELCOME PAYMENT LINK PAGE");

		PaymentLinkInfo paylkinfo = new PaymentLinkInfo();

		Date date = new Date();
		Random r = new Random(System.currentTimeMillis());
		Integer randnumber = ((1 + r.nextInt(2)) * 10000 + r.nextInt(10000));
		String curdat = new SimpleDateFormat("yyyyMMdd").format(date);
		String orderId = curdat + randnumber;
		paylkinfo.setOrderId(orderId);
		paylkinfo.setCurrency("MYR");
		paylkinfo.setPayMethod("B2C");
		paylkinfo.setMerBankUrl(messageService.getMessage(ConfigConstants.SVC_PGW_BANK_URL));
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TEST_PAYLK_2, "Test Payment Link", null);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.pgw.tst.lst"));
		mav.addObject(TEST_PAYMENT_LINK, paylkinfo);

		List<MerPayPageSet> channelList = getBeService().getAllMerChantpaymentList(merPayPageSet);
		mav.addObject("channel", channelList);
		return mav;

	}

	@PostMapping
	public ModelAndView viewpost(@ModelAttribute(TEST_PAYMENT_LINK) PaymentLinkInfo paymentLinkInfo,
			MerChanSet merChanSet, BindingResult result, HttpServletRequest request, HttpServletResponse response)
			throws BeException {

		// Generate URL
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_MER_FPX_PAYMENT, "Test Payment Link", null);
		String merid = paymentLinkInfo.getMerchantId();
		paymentLinkInfo.setMerPayUrl(messageService.getMessage(ConfigConstants.PAYMENT_LINK_URL));
		paymentLinkInfo.setChannel("FPX");
		paymentLinkInfo.setCurrency("MYR");

		// PgwMerchantContact
		MerAccInfo accInfo = getBeService().getAccInfoById(merid);
		String bankCode = paymentLinkInfo.getBankCode();
		String payType = paymentLinkInfo.getPayMethod();
		String payType1 = payType.replaceAll(",$", "");
		String bankCode1 = bankCode.replaceAll(",$", "");

		paymentLinkInfo.setName(accInfo.getCompany());
		// get general merchent info
		MerGenInfo merGenInfo = getBeService().getGenInfoById(merid);
		
		if(merGenInfo.getPhone() == null || merGenInfo.getPhone().isEmpty()) {
			String mobile = merGenInfo.getMphone();
			paymentLinkInfo.setMobile(mobile);
		}else {
		String mphone = merGenInfo.getPhone();
		paymentLinkInfo.setMobile(mphone);
		}
		paymentLinkInfo.setDescription(merGenInfo.getAddress());
		paymentLinkInfo.setEmail(accInfo.getEmail());
		paymentLinkInfo.setMerchantId(merid);
		paymentLinkInfo.setBankCode(bankCode1);
		paymentLinkInfo.setPayMethod(payType1);

		// get verify key
		MerPayPageSet payPageSet = getBeService().getMerPayPageSetById(merid);
		String verifykey = null;
		if (!BaseUtil.isObjNull(payPageSet)) {
			verifykey = payPageSet.getVerifyKey();
		}

		logger.info("VERIFYKEY-- {}", verifykey);

		StringBuilder reqhashParam = new StringBuilder();
		DigestUtils.sha256Hex(reqhashParam.toString());
		reqhashParam.append(paymentLinkInfo.getMerchantId()).append(paymentLinkInfo.getCurrency())
				.append(paymentLinkInfo.getOrderId())
				// .append(new
				// BigDecimal(paymentLinkInfo.getAmount()).setScale(2,
				// BigDecimal.ROUND_HALF_UP))
				.append(paymentLinkInfo.getAmount()).append(verifykey);
		String requestHash = DigestUtils.sha256Hex(reqhashParam.toString());
		paymentLinkInfo.setReqhash(requestHash);

		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.pgw.tst.lst"));
		mav.addObject(TEST_PAYMENT_LINK, paymentLinkInfo);
		mav.addObject("merPayUrl", messageService.getMessage(ConfigConstants.SVC_PGW_PAY_URL));
		return mav;
	}

	@PostMapping(value = PageConstants.PAGE_TEST_RECEIPT)
	public ModelAndView postPaymentRespBestPay(HttpServletRequest request) {

		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_TEST_RECEIPT);

		PgwResponse pgwResponse = new PgwResponse();

		pgwResponse.setB4u_orderId(request.getParameter("b4u_orderId"));

		pgwResponse.setB4u_currency(request.getParameter("b4u_currency"));

		pgwResponse.setB4u_amount(request.getParameter("b4u_amount"));

		pgwResponse.setB4u_status(request.getParameter("b4u_status"));

		mav.addObject(TEST_PAYMENT_LINK, pgwResponse);
		return mav;

	}

	@GetMapping(value = "/getHashKey")

	public @ResponseBody String getHashValue(@ModelAttribute("paymentLinkInfo") PaymentLinkInfo paymentLinkInfo)
			throws BeException {

		String payMethod = paymentLinkInfo.getPayMethod();
		String merchantId = paymentLinkInfo.getMerchantId();
		// get verify key
		MerPayPageSet payPageSet;
		payPageSet = getBeService().getMerPayPageSetById(merchantId);
		String verifykey = null;
		if (!BaseUtil.isObjNull(payPageSet)) {
			verifykey = payPageSet.getVerifyKey();
		}
		StringBuilder reqhashParam = new StringBuilder();
		reqhashParam.append(merchantId).append(verifykey).append(payMethod);

		String hashCal = DigestUtils.sha256Hex(reqhashParam.toString());
		logger.info("calculated hash val {}", hashCal);
		return hashCal;
	}
}