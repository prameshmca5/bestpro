/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.BaseUtil;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 * @author michelle.angela
 *
 */
public class AcctPassport implements Serializable, IQfCriteria<AcctPassport> {

	private static final long serialVersionUID = 3352900726442233205L;

	private Integer passportId;

	private String passportNo;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date passportExpiryDt;

	private boolean isActive;

	private Country nationality;


	public Integer getPassportId() {
		return passportId;
	}


	public void setPassportId(Integer passportId) {
		this.passportId = passportId;
	}


	public String getPassportNo() {
		return passportNo;
	}


	public void setPassportNo(String passportNo) {
		this.passportNo = BaseUtil.getStrUpperWithNull(passportNo);
	}


	public Date getPassportExpiryDt() {
		return passportExpiryDt;
	}


	public void setPassportExpiryDt(Date passportExpiryDt) {
		this.passportExpiryDt = passportExpiryDt;
	}


	public boolean getIsActive() {
		return isActive;
	}


	public void setIsActive(boolean isActive) {
		this.isActive = isActive;
	}


	public Country getNationality() {
		return nationality;
	}


	public void setNationality(Country nationality) {
		this.nationality = nationality;
	}

}
