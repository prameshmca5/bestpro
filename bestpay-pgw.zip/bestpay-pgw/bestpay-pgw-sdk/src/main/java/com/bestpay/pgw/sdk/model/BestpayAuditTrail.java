/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


public class BestpayAuditTrail implements Serializable {

	private static final long serialVersionUID = -3186445980890420147L;

	private int id;

	private String messageId;

	private String refNo;

	private String buildVersion;

	private Integer cmpnyProfId;

	private String reqData;

	private String txnNo;

	private String createId;

	private Timestamp createDt;


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getMessageId() {
		return messageId;
	}


	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}


	public String getRefNo() {
		return refNo;
	}


	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}


	public String getBuildVersion() {
		return buildVersion;
	}


	public void setBuildVersion(String buildVersion) {
		this.buildVersion = buildVersion;
	}


	public Integer getCmpnyProfId() {
		return cmpnyProfId;
	}


	public void setCmpnyProfId(Integer cmpnyProfId) {
		this.cmpnyProfId = cmpnyProfId;
	}


	public String getReqData() {
		return reqData;
	}


	public void setReqData(String reqData) {
		this.reqData = reqData;
	}


	public String getTxnNo() {
		return txnNo;
	}


	public void setTxnNo(String txnNo) {
		this.txnNo = txnNo;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

}
