/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.SecUserDevice;
import com.bestid.be.qf.SecUserDeviceQf;
import com.bestid.be.repo.GenericRepository;
import com.bestid.be.repo.SecUserDeviceRepository;


/**
 * @author roziana
 * @since Nov 19, 2018
 */
@Transactional
@Service(QualifierConstants.SEC_USER_DEVICE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.SEC_USER_DEVICE_SVC)
public class SecUserDeviceService extends AbstractService<SecUserDevice> {

	@Autowired
	@Qualifier(QualifierConstants.SEC_USER_DEVICE_REPOSITORY)
	SecUserDeviceRepository secUserDeviceDao;

	@Autowired
	@Qualifier(QualifierConstants.SEC_USER_DEVICE_QF)
	SecUserDeviceQf secUserDeviceQf;


	@Override
	public GenericRepository<SecUserDevice> primaryDao() {
		return secUserDeviceDao;
	}


	public SecUserDevice findDeviceId(int deviceId) {
		return secUserDeviceDao.findDeviceId(deviceId);
	}


	public SecUserDevice findDeviceByUserMachine(String userName, String machineId) {
		return secUserDeviceDao.findDeviceByUserMachine(userName, machineId);
	}


	public List<SecUserDevice> findStatus(String status) {
		return secUserDeviceDao.findStatus(status);
	}


	public SecUserDevice findDeviceByMachineId(String machineId) {
		return secUserDeviceDao.findDeviceByMachineId(machineId);
	}


	public SecUserDevice findDeviceByMobileNo(String mobileNo) {
		return secUserDeviceDao.findDeviceByMobileNo(mobileNo);
	}


	public SecUserDevice findByUuid(String uuid) {
		return secUserDeviceDao.findByUuid(uuid);
	}


	public SecUserDevice findDeviceByUidMachineId(String machineId, String uuid) {
		return secUserDeviceDao.findDeviceByUidMachineId(machineId, uuid);
	}


	public SecUserDevice findDeviceByUserIdUuid(int userId, String uuid) {
		return secUserDeviceDao.findDeviceByUserIdUuid(userId, uuid);
	}


	public List<SecUserDevice> searchByProperty(SecUserDevice secUserDevice) {
		return secUserDeviceDao.findAll(secUserDeviceQf.searchByProperty(secUserDevice));
	}


	public SecUserDevice findDeviceByUserIdMachineId(int userId, String machineId) {
		return secUserDeviceDao.findDeviceByUserIdMachineId(userId, machineId);
	}

}
