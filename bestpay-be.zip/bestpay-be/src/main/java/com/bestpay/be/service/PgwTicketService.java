/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwTicketRepository;
import com.bestpay.be.dao.TicketCustomDao;
import com.bestpay.be.model.PgwTicket;
import com.bestpay.be.sdk.model.Ticket;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since November 13, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_TICKET_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_TICKET_SVC)
public class PgwTicketService extends AbstractService<PgwTicket> {

	@Autowired
	private PgwTicketRepository ticketDao;

	@Autowired
	private TicketCustomDao ticketInfoDao;


	@Override
	public PgwTicketRepository primaryDao() {
		return ticketDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwTicket> searchTicket(Ticket ticket, DataTableRequest dataTableInRQ) {
		return ticketInfoDao.searchByPagination(ticket, dataTableInRQ);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwTicket findByTicketId(Integer ticketId) {
		return ticketDao.findByTicketId(ticketId);
	}


	// @Cacheable(key =
	// "T(com.bestinet.commons.sdk.constants.CmnCacheConstants).CACHE_KEY_CMPNY_ACTVTY_ID.concat(#activityId)",
	// condition = "#activityId != null and #result != null")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public PgwTicket findByMerchantId(String merchantId) {
		return ticketDao.findByMerchantId(merchantId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwTicket findBySupportId(String supportId) {
		return ticketDao.findBySupportId(supportId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwTicket findByMerchantIdTicketId(String merchantId, Integer ticketId) {
		return ticketDao.findByMerchantIdTicketId(merchantId, ticketId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public Integer findTicketId(String merchantId) {
		return ticketInfoDao.findRecentTicketByMerchId(merchantId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public String findFeedback(Integer ticketId) {
		return ticketInfoDao.findRecentFeedbackByTicketId(ticketId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<String> getCountOfAllStatus(String merchantId) {
		return ticketInfoDao.getCountOfAllStatus(merchantId);
	}
	
	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public Integer findByTicket(Integer ticketId) {
		return ticketInfoDao.findByTicket(ticketId);
	}

}