package com.bestpay.pgw.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.RefRelationshipRepository;
import com.bestpay.pgw.model.RefRelationship;
import com.bestpay.pgw.sdk.constants.PgwCacheConstants;
import com.bestpay.pgw.util.QualifierConstants;


/**
 * @author Md Asif Aftab
 * @since 3rd April 2018
 */

@Service(QualifierConstants.APJ_RELATIONSHIP_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.APJ_RELATIONSHIP_SVC)
@Transactional
@CacheConfig(cacheNames = PgwCacheConstants.CACHE_BUCKET)
public class RefRelationshipService extends AbstractService<RefRelationship> {

	@Autowired
	private RefRelationshipRepository relationDao;


	@Cacheable(key = "T(com.bestpay.be.sdk.constants.ApjCacheConstants).CACHE_KEY_RELATIONSHIP_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	@Override
	public List<RefRelationship> findAll() {
		return relationDao.findAll();
	}


	@Cacheable(key = "T(com.bestpay.be.sdk.constants.ApjCacheConstants).CMN_REF_RELATIONSHIP_.concat(#relationCode)", condition = "#relationCode != null and #result != null")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public RefRelationship findByRelationCode(String relationCode) {
		return relationDao.findByRelationCode(relationCode);
	}


	@Override
	@Caching(evict = {
			@CacheEvict(beforeInvocation = true, key = "T(com.bestpay.be.sdk.constants.ApjCacheConstants).CACHE_KEY_RELATIONSHIP_ALL"), }, put = {
					@CachePut(key = "T(com.bestpay.be.sdk.constants.ApjCacheConstants).CMN_REF_RELATIONSHIP_.concat(#s.relationCode)") })
	public RefRelationship create(RefRelationship s) {
		return super.create(s);
	}


	@Override
	@Caching(evict = {
			@CacheEvict(beforeInvocation = true, key = "T(com.bestpay.be.sdk.constants.ApjCacheConstants).CACHE_KEY_RELATIONSHIP_ALL"),
			@CacheEvict(beforeInvocation = true, key = "T(com.bestpay.be.sdk.constants.ApjCacheConstants).CMN_REF_RELATIONSHIP_.concat(#s.relationCode)") })
	public RefRelationship update(RefRelationship s) {
		return super.update(s);
	}


	@Override
	@Caching(evict = {
			@CacheEvict(beforeInvocation = true, key = "T(com.bestpay.be.sdk.constants.ApjCacheConstants).CACHE_KEY_RELATIONSHIP_ALL"), })
	public boolean delete(Integer id) {
		return super.delete(id);
	}


	@Override
	public GenericRepository<RefRelationship> primaryDao() {
		return relationDao;
	}
}
