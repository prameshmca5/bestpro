package com.bestpay.pgw.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.PgwMerchantProvider;
import com.bestpay.pgw.util.QualifierConstants;


/**
 * @author Mohammad Rashid
 * @since Mar 25, 2019
 */
@Repository
@RepositoryDefinition(domainClass = PgwMerchantProvider.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_PROVIDER_DAO)
public interface PgwMerchantProviderRepository extends GenericRepository<PgwMerchantProvider> {

	@Query("select u from PgwMerchantProvider u where u.providerPublicName = :providerPublicName ")
	public PgwMerchantProvider findPgwMerchantProviderByName(@Param("providerPublicName") String providerPublicName);

}