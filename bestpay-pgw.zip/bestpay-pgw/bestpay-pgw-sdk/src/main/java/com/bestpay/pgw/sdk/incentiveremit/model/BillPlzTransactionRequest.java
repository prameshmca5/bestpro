package com.bestpay.pgw.sdk.incentiveremit.model;


public class BillPlzTransactionRequest {

	private String collectionId;

	private String description;

	private String email;

	private String mobile;

	private String name;

	private String amount;

	private String reference_1_Label;

	private String reference_1;

	private String reference_2_Label;

	private String reference_2;

	private String callbackUrl;

	private String redirectUrl;


	public String getCollectionId() {
		return collectionId;
	}


	public void setCollectionId(String collectionId) {
		this.collectionId = collectionId;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAmount() {
		return amount;
	}


	public void setAmount(String amount) {
		this.amount = amount;
	}


	public String getCallbackUrl() {
		return callbackUrl;
	}


	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getReference_1_Label() {
		return reference_1_Label;
	}


	public void setReference_1_Label(String reference_1_Label) {
		this.reference_1_Label = reference_1_Label;
	}


	public String getReference_1() {
		return reference_1;
	}


	public void setReference_1(String reference_1) {
		this.reference_1 = reference_1;
	}


	public String getReference_2_Label() {
		return reference_2_Label;
	}


	public void setReference_2_Label(String reference_2_Label) {
		this.reference_2_Label = reference_2_Label;
	}


	public String getReference_2() {
		return reference_2;
	}


	public void setReference_2(String reference_2) {
		this.reference_2 = reference_2;
	}


	public String getRedirectUrl() {
		return redirectUrl;
	}


	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}

}
