package com.bestpay.pgw.sdk.model;

import java.io.Serializable;
import java.sql.Timestamp;


public class MerchantContact implements Serializable {
	
	private static final long serialVersionUID = 6645623423283005357L;
	
	private Integer cntctId;
	private String merchantId;
	private String name;
	private String address;
	private String postcode;
	private String city;
	private String state;
	private String country;
	private String phone;
	private String mobPhone;
	private String fax;
	private String email;
	private String email2;
	private String emailMisc;
	private String emailcc;
	private String emailccTo;
	private String payNoticc;
	private String createId;
	private Timestamp createDt;
	private Timestamp updateDt;
	private String updateId;
	
	public Integer getCntctId() {
		return cntctId;
	}
	public void setCntctId(Integer cntctId) {
		this.cntctId = cntctId;
	}
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getMobPhone() {
		return mobPhone;
	}
	public void setMobPhone(String mobPhone) {
		this.mobPhone = mobPhone;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEmail2() {
		return email2;
	}
	public void setEmail2(String email2) {
		this.email2 = email2;
	}
	public String getEmailMisc() {
		return emailMisc;
	}
	public void setEmailMisc(String emailMisc) {
		this.emailMisc = emailMisc;
	}
	public String getEmailcc() {
		return emailcc;
	}
	public void setEmailcc(String emailcc) {
		this.emailcc = emailcc;
	}
	public String getEmailccTo() {
		return emailccTo;
	}
	public void setEmailccTo(String emailccTo) {
		this.emailccTo = emailccTo;
	}
	public String getPayNoticc() {
		return payNoticc;
	}
	public void setPayNoticc(String payNoticc) {
		this.payNoticc = payNoticc;
	}
	public String getCreateId() {
		return createId;
	}
	public void setCreateId(String createId) {
		this.createId = createId;
	}
	public Timestamp getCreateDt() {
		return createDt;
	}
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}
	public Timestamp getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}
	public String getUpdateId() {
		return updateId;
	}
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
