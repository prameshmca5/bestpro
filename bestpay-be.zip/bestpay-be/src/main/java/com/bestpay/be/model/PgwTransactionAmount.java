package com.bestpay.be.model;


public class PgwTransactionAmount {

	private final String merchantId;

	private final Double billAmount;

	private final Double transactionRate;

	private final Double actualAmount;


	public PgwTransactionAmount(String merchantId, Double billAmount, Double transactionRate, Double actualAmount) {
		this.merchantId = merchantId;
		this.billAmount = billAmount;
		this.transactionRate = transactionRate;
		this.actualAmount = actualAmount;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public Double getBillAmount() {
		return billAmount;
	}


	public Double getTransactionRate() {
		return transactionRate;
	}


	public Double getActualAmount() {
		return actualAmount;
	}

}
