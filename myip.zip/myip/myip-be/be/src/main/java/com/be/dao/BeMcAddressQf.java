/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeMcAddress;
import com.be.model.BeMcProfile;
import com.be.model.RefCountry;
import com.be.model.RefMetadata;
import com.be.model.RefTimeZone;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.Country;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.McAddress;
import com.be.sdk.model.Metadata;
import com.be.sdk.model.GmtTimeZone;
import com.be.service.RefCountryService;
import com.be.service.RefMetadataService;
import com.be.service.RefTimeZoneService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;


/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_MC_ADDRESS_QF)
public class BeMcAddressQf extends QueryFactory<BeMcAddress> {

	@Autowired
	BeMcProfileQf beMcProfileQf;

	@Autowired
	RefCountryService refCountrySvc;

	@Autowired
	RefMetadataService refMetadataSvc;

	@Autowired
	RefTimeZoneService refTimeZoneSvc;

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BeMcAddress> searchByProperty(BeMcAddress t) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<BeMcAddress> searchAllByProperty(BeMcAddress t) {
		CriteriaQuery<BeMcAddress> cq = cb.createQuery(BeMcAddress.class);
		Root<BeMcAddress> from = cq.from(BeMcAddress.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public List<BeMcAddress> searchBeMcAddressPagination(McAddress dto, DataTableRequest<?> dataTableInRQ) {

		List<BeMcAddress> result = new ArrayList<>();
		CriteriaQuery<BeMcAddress> cq = cb.createQuery(BeMcAddress.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeMcAddress> root = cq.from(BeMcAddress.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					cq.orderBy(getOrderByClause(cb, root, pagination));
				}
			}

			TypedQuery<BeMcAddress> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}


	public Long getCount(McAddress dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeMcAddress> root = cq.from(BeMcAddress.class);
		predicates.addAll(generateCriteria(cb, root, dto));

		Join<BeMcAddress, BeMcProfile> mcProfile = root.join("mcProfile", JoinType.INNER);
		predicates.addAll(beMcProfileQf.generateCriteria(cb, mcProfile, dto));

		if (!BaseUtil.isObjNull(dto.getOrgTypeMtdtCd())) {
			Join<BeMcProfile, RefMetadata> orgTypeMtdt = mcProfile.join("orgTypeMtdt", JoinType.LEFT);
			Metadata relationMtdtDto = new Metadata();
			relationMtdtDto.setMtdtCd(dto.getOrgTypeMtdtCd());
			predicates.addAll(refMetadataSvc.generateCriteria(cb, orgTypeMtdt, relationMtdtDto));
		}

		if (!BaseUtil.isObjNull(dto.getMcTypeMtdtCd())) {
			Join<BeMcProfile, RefMetadata> mcTypeMtdt = mcProfile.join("mcTypeMtdt", JoinType.LEFT);
			Metadata relationMtdtDto = new Metadata();
			relationMtdtDto.setMtdtCd(dto.getMcTypeMtdtCd());
			predicates.addAll(refMetadataSvc.generateCriteria(cb, mcTypeMtdt, relationMtdtDto));
		}

		if (!BaseUtil.isObjNull(dto.getCntryCd())) {
			Join<BeMcAddress, RefCountry> country = root.join("country", JoinType.LEFT);
			Country countryDto = new Country();
			countryDto.setCntryCd(dto.getCntryCd());
			predicates.addAll(refCountrySvc.generateCriteria(cb, country, countryDto));
		}

		if (!BaseUtil.isObjNull(dto.getTimeZoneId())) {
			Join<BeMcAddress, RefTimeZone> refTimeZone = root.join("timezone", JoinType.LEFT);
			GmtTimeZone timeZoneDto = new GmtTimeZone();
			timeZoneDto.setTimeZoneId(dto.getTimeZoneId());
			predicates.addAll(refTimeZoneSvc.generateCriteria(cb, refTimeZone, timeZoneDto));
		}

		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}


	public BeMcAddress searchBeMcAddress(McAddress dto) {

		BeMcAddress result = null;
		CriteriaQuery<BeMcAddress> cq = cb.createQuery(BeMcAddress.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeMcAddress> root = cq.from(BeMcAddress.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeMcAddress> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			McAddress dto = JsonUtil.transferToObject(criteria, McAddress.class);
			if (!BaseUtil.isObjNull(dto.getMcAddrId())) {
				predicates.add(cb.equal(from.get("mcAddrId"), dto.getMcAddrId()));
			}

			if (!BaseUtil.isObjNull(dto.getAddr1())) {
				predicates.add(cb.like(from.get("addr1"), "%" + dto.getAddr1() + "%"));
			}

			if (!BaseUtil.isObjNull(dto.getAddr2())) {
				predicates.add(cb.like(from.get("addr2"), "%" + dto.getAddr2() + "%"));
			}

			if (!BaseUtil.isObjNull(dto.getAddr3())) {
				predicates.add(cb.like(from.get("addr3"), "%" + dto.getAddr3() + "%"));
			}

			if (!BaseUtil.isObjNull(dto.getAddrType())) {
				predicates.add(cb.equal(from.get("addrType"), dto.getAddrType()));
			}

			if (!BaseUtil.isObjNull(dto.getZipcode())) {
				predicates.add(cb.equal(from.get("zipcode"), "%" + dto.getZipcode() + "%"));
			}

			if (!BaseUtil.isObjNull(dto.getLatitude())) {
				predicates.add(cb.equal(from.get("latitude"), dto.getLatitude()));
			}

			if (!BaseUtil.isObjNull(dto.getLongitude())) {
				predicates.add(cb.equal(from.get("longitude"), dto.getLongitude()));
			}

		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void joinFetch(From<?, ?> from, List<Predicate> predicates, McAddress dto) {

		Join<BeMcAddress, BeMcProfile> mcProfile = (Join) from.fetch("mcProfile", JoinType.INNER);
		predicates.addAll(beMcProfileQf.generateCriteria(cb, mcProfile, dto));

		Join<BeMcProfile, RefMetadata> orgTypeMtdt = (Join) mcProfile.fetch("orgTypeMtdt", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getOrgTypeMtdtCd())) {
			Metadata relationMtdtDto = new Metadata();
			relationMtdtDto.setMtdtCd(dto.getOrgTypeMtdtCd());
			predicates.addAll(refMetadataSvc.generateCriteria(cb, orgTypeMtdt, relationMtdtDto));
		}

		Join<BeMcProfile, RefMetadata> mcTypeMtdt = (Join) mcProfile.fetch("mcTypeMtdt", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getMcTypeMtdtCd())) {
			Metadata relationMtdtDto = new Metadata();
			relationMtdtDto.setMtdtCd(dto.getMcTypeMtdtCd());
			predicates.addAll(refMetadataSvc.generateCriteria(cb, mcTypeMtdt, relationMtdtDto));
		}

		Join<BeMcAddress, RefCountry> country = (Join) from.fetch("country", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getCntryCd())) {
			Country countryDto = new Country();
			countryDto.setCntryCd(dto.getCntryCd());
			predicates.addAll(refCountrySvc.generateCriteria(cb, country, countryDto));
		}

		Join<BeMcAddress, RefTimeZone> timezone = (Join) from.fetch("timezone", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getTimeZoneId())) {
			GmtTimeZone timeZoneDto = new GmtTimeZone();
			timeZoneDto.setTimeZoneId(dto.getTimeZoneId());
			predicates.addAll(refTimeZoneSvc.generateCriteria(cb, timezone, timeZoneDto));
		}
	}
}
