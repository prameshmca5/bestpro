/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;


/**
 * @author nurul.naimma
 *
 * @since Apr 19, 2021
 */
public class PmtGatewayResp implements Serializable, IQfCriteria<PmtGatewayResp> {

	private static final long serialVersionUID = 8038627549300099161L;

	private Integer pmtGatewayRespId;

	private String respCd;

	private String respDescription;

	private Integer statusCd;

	private String channelCode;


	/**
	 * @return the pmtGatewayRespId
	 */
	public Integer getPmtGatewayRespId() {
		return pmtGatewayRespId;
	}


	/**
	 * @param pmtGatewayRespId
	 *             the pmtGatewayRespId to set
	 */
	public void setPmtGatewayRespId(Integer pmtGatewayRespId) {
		this.pmtGatewayRespId = pmtGatewayRespId;
	}


	/**
	 * @return the respCd
	 */
	public String getRespCd() {
		return respCd;
	}


	/**
	 * @param respCd
	 *             the respCd to set
	 */
	public void setRespCd(String respCd) {
		this.respCd = respCd;
	}


	/**
	 * @return the respDescription
	 */
	public String getRespDescription() {
		return respDescription;
	}


	/**
	 * @param respDescription
	 *             the respDescription to set
	 */
	public void setRespDescription(String respDescription) {
		this.respDescription = respDescription;
	}


	/**
	 * @return the statusCd
	 */
	public Integer getStatusCd() {
		return statusCd;
	}


	/**
	 * @param statusCd
	 *             the statusCd to set
	 */
	public void setStatusCd(Integer statusCd) {
		this.statusCd = statusCd;
	}


	/**
	 * @return the channelCode
	 */
	public String getChannelCode() {
		return channelCode;
	}


	/**
	 * @param channelCode
	 *             the channelCode to set
	 */
	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

}
