package com.be.controller;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.model.BeTrxnDocument;
import com.be.model.BeTrxnDocumentPK;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.TrxnDocuments;
import com.be.service.BeTrxnDocumentService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;


@Lazy
@RestController
@RequestMapping(BeUrlConstants.TRXN_DOCUMENTS)
public class TrxnDocumentRestController extends AbstractRestController {

	@Autowired
	BeTrxnDocumentService beTrxnDocumentsService;


	@PostMapping(value = BeUrlConstants.SEARCH_TRXN_DOCUMENT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public TrxnDocuments searchTrxnDocuments(@RequestBody TrxnDocuments dto, HttpServletRequest request)
			throws IOException {

		// BeTrxnDocument doc =
		// beTrxnDocumentsService.findTrxnDocumentsByRefNo(dto.getDocRefNo());

		BeTrxnDocument doc = beTrxnDocumentsService.findTrxnDocumentsByRefNoAndDocId(dto.getDocRefNo(),
				dto.getDocId());
		TrxnDocuments trxnDoc = new TrxnDocuments();

		if (!BaseUtil.isObjNull(doc) && !BaseUtil.isObjNull(doc.getId())) {
			BeTrxnDocumentPK pk = doc.getId();
			trxnDoc.setDocContentType(doc.getDocContentType());
			trxnDoc.setDocId(pk.getDocId());
			trxnDoc.setDocMgtId(pk.getDocMgtId());
			trxnDoc.setDocRefNo(pk.getDocRefNo());
		} else {
			return null;
		}

		return trxnDoc;
	}


	@GetMapping(value = BeUrlConstants.GET_LIST, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<TrxnDocuments> getTrxnDocuments(@RequestParam("docRefNo") String docRefNo, HttpServletRequest request)
			throws IOException {

		List<TrxnDocuments> trxnDocuments = new ArrayList<>();
		List<BeTrxnDocument> beTrxnDocuments = beTrxnDocumentsService.findTrxnDocumentsByDocRefNo(docRefNo);
		for (BeTrxnDocument doc : beTrxnDocuments) {
			TrxnDocuments trxnDoc = JsonUtil.transferToObject(doc.getId(), TrxnDocuments.class);
			trxnDoc.setDocContentType(doc.getDocContentType());
			trxnDocuments.add(trxnDoc);
		}

		return trxnDocuments;
	}


	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.INFO_ADD_DOC, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<TrxnDocuments> addDocInfo(@RequestBody List<TrxnDocuments> dto, HttpServletRequest request)
			throws IOException {
		try {
			List<TrxnDocuments> trxnDocumentsList = new ArrayList<>();
			if (!BaseUtil.isObjNull(dto)) {

				String userId = getCurrUserId(request);

				trxnDocumentsList = JsonUtil.transferToList(
						beTrxnDocumentsService.createUpdate(dto, userId, dto.get(0).getDocRefNo()),
						TrxnDocuments.class);

			}

			return trxnDocumentsList;
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}
}
