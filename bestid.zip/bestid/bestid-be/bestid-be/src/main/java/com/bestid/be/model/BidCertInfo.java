package com.bestid.be.model;


import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author mukhlis.hamzah
 * @since Feb 14, 2019
 */
@Entity
@Table(name = "BID_CERT_INFO")
public class BidCertInfo implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 4242376310477814640L;

	@Id
	@Column(name = "CERT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int certId;

	@Column(name = "CERT_REF_NO")
	private String certRefNo;

	@Column(name = "CERT_SRC")
	private String certSrc;

	@Column(name = "APPL_ID")
	private Integer applId;

	@Column(name = "REF_NO")
	private String refno;

	@Column(name = "USER_TYPE")
	private Integer userType;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "PHONE_NO")
	private String phoneNo;

	@Column(name = "TITLE")
	private String title;

	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "LAST_NAME")
	private String lastName;

	@Column(name = "ADDRESS")
	private String address;

	@Column(name = "POSTCODE")
	private String postcode;

	@Column(name = "CERT")
	private String cert;

	@Column(name = "GENERATE_DT")
	private Date generateDt;

	@Column(name = "EXPIRED_DT")
	private Date expiredDt;

	@Column(name = "APPROVE_DT")
	private Date approveDt;

	@Column(name = "REVOKE_DT")
	private Date revokeDt;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public int getCertId() {
		return certId;
	}


	public void setCertId(int certId) {
		this.certId = certId;
	}


	public Integer getApplId() {
		return applId;
	}


	public void setApplId(Integer applId) {
		this.applId = applId;
	}


	public String getRefno() {
		return refno;
	}


	public void setRefno(String refno) {
		this.refno = refno;
	}


	public Integer getUserType() {
		return userType;
	}


	public void setUserType(Integer userType) {
		this.userType = userType;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getCert() {
		return cert;
	}


	public void setCert(String cert) {
		this.cert = cert;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Date getGenerateDt() {
		return generateDt;
	}


	public void setGenerateDt(Date generateDt) {
		this.generateDt = generateDt;
	}


	public Date getExpiredDt() {
		return expiredDt;
	}


	public void setExpiredDt(Date expiredDt) {
		this.expiredDt = expiredDt;
	}


	public Date getApproveDt() {
		return approveDt;
	}


	public void setApproveDt(Date approveDt) {
		this.approveDt = approveDt;
	}


	public String getCertRefNo() {
		return certRefNo;
	}


	public void setCertRefNo(String certRefNo) {
		this.certRefNo = certRefNo;
	}


	public Date getRevokeDt() {
		return revokeDt;
	}


	public void setRevokeDt(Date revokeDt) {
		this.revokeDt = revokeDt;
	}


	public String getCertSrc() {
		return certSrc;
	}


	public void setCertSrc(String certSrc) {
		this.certSrc = certSrc;
	}

}
