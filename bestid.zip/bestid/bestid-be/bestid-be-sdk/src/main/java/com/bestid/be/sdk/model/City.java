package com.bestid.be.sdk.model;

import java.io.Serializable;

/**
 * @author Md Asif Aftab
 * @since 27th Feb 2018
 */

public class City implements Serializable{
	
	private static final long serialVersionUID = 607657392585361232L;

	private String cityId;
	private String cityCode;
	private String descEn;
	private String descMy;
	private String state;
	private State stateObj;

	public String getCityId() {
		return cityId;
	}

	public void setCityId(String cityId) {
		this.cityId = cityId;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getDescEn() {
		return descEn;
	}

	public void setDescEn(String descEn) {
		this.descEn = descEn;
	}

	public String getDescMy() {
		return descMy;
	}

	public void setDescMy(String descMy) {
		this.descMy = descMy;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public State getStateObj() {
		return stateObj;
	}

	public void setStateObj(State stateObj) {
		this.stateObj = stateObj;
	}
	
	
}
