/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeElectionNot;
import com.be.model.BeElectionNotDtl;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.ElectionNotDtl;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;


/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_ELECTION_NOT_DTL_QF)
public class BeElectionNotDtlQf extends QueryFactory<BeElectionNotDtl> {

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BeElectionNotDtl> searchByProperty(BeElectionNotDtl t) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<BeElectionNotDtl> searchAllByProperty(BeElectionNotDtl t) {
		CriteriaQuery<BeElectionNotDtl> cq = cb.createQuery(BeElectionNotDtl.class);
		Root<BeElectionNotDtl> root = cq.from(BeElectionNotDtl.class);
		List<Predicate> predicates = generateCriteria(cb, root, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public Long getCount(ElectionNotDtl dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeElectionNotDtl> root = cq.from(BeElectionNotDtl.class);
		predicates.addAll(generateCriteria(cb, root, dto));

		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}


	public List<BeElectionNotDtl> searchAllByProperty(ElectionNotDtl dto, DataTableRequest<?> dataTableInRQ) {

		List<BeElectionNotDtl> result = new ArrayList<>();
		CriteriaQuery<BeElectionNotDtl> cq = cb.createQuery(BeElectionNotDtl.class);
		List<Predicate> predicates = new ArrayList<>();
		if (cq != null) {
			Root<BeElectionNotDtl> root = cq.from(BeElectionNotDtl.class);
			predicates.addAll(generateCriteria(cb, root, dto));

			cq.select(root);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					List<Order> orders = getOrderByClause(cb, root, pagination);
					cq.orderBy(orders);
				}
			}

			TypedQuery<BeElectionNotDtl> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			ElectionNotDtl dto = JsonUtil.transferToObject(criteria, ElectionNotDtl.class);
			if (!BaseUtil.isObjNull(dto.getElectionNotDtlId())) {
				predicates.add(cb.equal(from.get("electionNotDtlId"), dto.getElectionNotDtlId()));
			}

			if (!BaseUtil.isObjNull(dto.getElectionNotId())) {
				BeElectionNot beElectionNot = new BeElectionNot();
				beElectionNot.setElectionNotId(dto.getElectionNotId());
				predicates.add(cb.equal(from.get("electionNot"), beElectionNot));
			}

			if (!BaseUtil.isObjNull(dto.getOrgDivisionCd())) {
				predicates.add(cb.equal(from.get("orgDivisionCd"), dto.getOrgDivisionCd()));
			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

}
