/**
 * Copyright 2018 Bestinet Sdn Bhd
 */
package com.bestpay.web.idm.validator;


import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.web.cmn.controller.AccountInfoController;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ValidationUtil;


/**
 * @author Afif Saman
 * @since July 17, 2018
 */
@Component("accountInfoValidator")
public class AccountInfoValidator extends AbstractController implements Validator {

	private static final Logger LOGGER = LoggerFactory.getLogger(AccountInfoController.class);

	private static final String EXPIRE_DATE = "expireDate";


	@Override
	public boolean supports(Class<?> clazz) {
		return MerAccInfo.class.equals(clazz);
	}


	@Override
	public void validate(Object object, Errors errors) {
		if (object instanceof MerAccInfo) {
			MerAccInfo merAccInfo = (MerAccInfo) object;
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "email", MessageConstants.ERROR_FIELDS_EMAIL);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "company", MessageConstants.ERROR_FIELDS_COMPANY);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "companyRefId",
					MessageConstants.ERROR_FIELDS_COMPANY_REFERRAL);
			// ownerDirectorNationalId
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "ownerDirectorNationalId",
					MessageConstants.ERROR_FIELDS_COMPANY_OWNERID);

			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "acStatus", MessageConstants.ERROR_FIELDS_ACC_STATUS);
			// Validate email if format is valid
			ValidationUtil.rejectIfInvalidEmailFormat(errors, "email", MessageConstants.ERROR_EMAIL_FORMAT);
			if (merAccInfo.getStartContractDate() != null) {
				Date startDate = merAccInfo.getStartContractDate();

				Date expireDate = merAccInfo.getExpireDate();
				LOGGER.info("startDate: {}", startDate);
				LOGGER.info("expireDate: {}", expireDate);
				if (expireDate.before(startDate)) {
					ValidationUtil.rejectIfInvalidAgeLessFormat(errors, EXPIRE_DATE,
							MessageConstants.ERROR_FIELDS_EXPIRY_DT_CON);
				}
				if (expireDate.equals(startDate)) {
					ValidationUtil.rejectIfInvalidAgeLessFormat(errors, EXPIRE_DATE,
							MessageConstants.ERROR_FIELDS_EXPIRY_DT_CON);
				}
			}
		}
	}
}
