/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonTimestampDeserializer;
import com.util.serializer.JsonTimestampSerializer;


/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_TVL_PAYMENT")
public class BeTvlPayment extends AbstractEntity implements Serializable, IQfCriteria<BeTvlPayment> {

	private static final long serialVersionUID = 8662172124094870569L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TVL_PMT_ID")
	private Integer tvlPmtId;

	@Column(name = "PMT_REF_NO")
	private String pmtRefNo;

	@Column(name = "CBS_REF_NO")
	private String cbsRefNo;

	// @Column(name = "INV_REF_NO")
	// private String invRefNo;

	@Column(name = "RCPT_REF_NO")
	private String rcptRefNo;

	@JsonSerialize(using = JsonTimestampSerializer.class)
	@JsonDeserialize(using = JsonTimestampDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH_TIME_S)
	@Column(name = "TRXN_DT")
	private Timestamp trxnDt;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CHANNEL_CODE")
	private RefChannel channel;

	@Column(name = "CURRENCY")
	private String currency;

	@Column(name = "AMOUNT")
	private double amount;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATUS_CD")
	private RefPymntMsgCode statusPymntMsgCode;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "RESP_CD")
	private RefPymntMsgCode respPymntMsgCode;

	@Column(name = "PMT_BY")
	private String pmtBy;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PMT_MTHD_MTDT_ID")
	private RefMetadata pmtMthdMtdt;

	@Temporal(TemporalType.DATE)
	@Column(name = "PMT_DT")
	private Date pmtDt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@JsonIgnoreProperties("tvlPayment")
	@OneToMany(mappedBy = "tvlPayment", fetch = FetchType.LAZY)
	private Set<BeTvlPaymentDtl> beTvlPaymentDtls;

	@Column(name = "DOC_REF_NO")
	private String docRefNo;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "APPS_MTDT_ID")
	private RefMetadata appsMtdt;


	public Integer getTvlPmtId() {
		return tvlPmtId;
	}


	public void setTvlPmtId(Integer tvlPmtId) {
		this.tvlPmtId = tvlPmtId;
	}


	public String getPmtRefNo() {
		return pmtRefNo;
	}


	public void setPmtRefNo(String pmtRefNo) {
		this.pmtRefNo = pmtRefNo;
	}


	public String getCbsRefNo() {
		return cbsRefNo;
	}


	public void setCbsRefNo(String cbsRefNo) {
		this.cbsRefNo = cbsRefNo;
	}

	// public String getInvRefNo() {
	// return invRefNo;
	// }
	//
	// public void setInvRefNo(String invRefNo) {
	// this.invRefNo = invRefNo;
	// }


	public String getRcptRefNo() {
		return rcptRefNo;
	}


	public void setRcptRefNo(String rcptRefNo) {
		this.rcptRefNo = rcptRefNo;
	}


	public Timestamp getTrxnDt() {
		return trxnDt;
	}


	public void setTrxnDt(Timestamp trxnDt) {
		this.trxnDt = trxnDt;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public RefPymntMsgCode getStatusPymntMsgCode() {
		return statusPymntMsgCode;
	}


	public void setStatusPymntMsgCode(RefPymntMsgCode statusPymntMsgCode) {
		this.statusPymntMsgCode = statusPymntMsgCode;
	}


	public RefPymntMsgCode getRespPymntMsgCode() {
		return respPymntMsgCode;
	}


	public void setRespPymntMsgCode(RefPymntMsgCode respPymntMsgCode) {
		this.respPymntMsgCode = respPymntMsgCode;
	}


	public RefChannel getChannel() {
		return channel;
	}


	public void setChannel(RefChannel channel) {
		this.channel = channel;
	}


	public String getPmtBy() {
		return pmtBy;
	}


	public void setPmtBy(String pmtBy) {
		this.pmtBy = pmtBy;
	}


	public Date getPmtDt() {
		return pmtDt;
	}


	public void setPmtDt(Date pmtDt) {
		this.pmtDt = pmtDt;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Set<BeTvlPaymentDtl> getBeTvlPaymentDtls() {
		return beTvlPaymentDtls;
	}


	public void setBeTvlPaymentDtls(Set<BeTvlPaymentDtl> beTvlPaymentDtls) {
		this.beTvlPaymentDtls = beTvlPaymentDtls;
	}


	public RefMetadata getPmtMthdMtdt() {
		return pmtMthdMtdt;
	}


	public void setPmtMthdMtdt(RefMetadata pmtMthdMtdt) {
		this.pmtMthdMtdt = pmtMthdMtdt;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public RefMetadata getAppsMtdt() {
		return appsMtdt;
	}


	public void setAppsMtdt(RefMetadata appsMtdt) {
		this.appsMtdt = appsMtdt;
	}

}
