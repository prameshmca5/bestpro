/**
 *
 */
package com.be.service;


import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTvlInsuranceQf;
import com.be.dao.BeTvlInsuranceRepository;
import com.be.model.BeTvl;
import com.be.model.BeTvlInsurance;
import com.be.model.BeTvlPaymentDtl;
import com.be.model.RefStatus;
import com.be.sdk.constants.FileUploadConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Insurance;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlProfile;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.UidGenerator;
import com.util.pagination.DataTableRequest;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_INSURANCE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_INSURANCE_SVC)
public class BeTvlInsuranceService extends AbstractService<BeTvlInsurance> {

	@Autowired
	private BeTvlInsuranceRepository beTvlInsuranceDao;

	@Autowired
	BeTrxnDocumentService beTrxnDocumentSvc;

	@Autowired
	BeTvlService beTvlSvc;

	@Autowired
	BeTvlInsuranceQf beTvlInsuranceQf;


	@Override
	public GenericRepository<BeTvlInsurance> primaryDao() {
		return beTvlInsuranceDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beTvlInsuranceQf.generateCriteria(cb, from, criteria);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { BeException.class,
			Exception.class })
	public BeTvlInsurance createUpdate(Insurance dto, BeTvlPaymentDtl paymentDtl, String userId) throws IOException {

		BeTvlInsurance beTvlInsurance = beTvlInsuranceDao.findByTvlProfId(dto.getTvlProfId());
		boolean isExists = true;
		if (BaseUtil.isObjNull(beTvlInsurance)) {
			beTvlInsurance = new BeTvlInsurance();
			beTvlInsurance.setTvlProfile(paymentDtl.getTvlProfile());
			beTvlInsurance.setTvlPaymentDtl(paymentDtl);
			beTvlInsurance.setDocRefNo(UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC));
			beTvlInsurance.setCreateId(userId);
			isExists = false;
		}
		if (!BaseUtil.isObjNull(dto.getStatusId())) {
			beTvlInsurance.setStatus(new RefStatus());
			beTvlInsurance.getStatus().setStatusId(dto.getStatusId());
		}
		beTvlInsurance.setCoverageDtl(dto.getCoverageDtl());
		beTvlInsurance.setInsuranceValidity(dto.getInsuranceValidity());
		beTvlInsurance.setUpdateId(userId);
		update(beTvlInsurance);

		if (!isExists && !BaseUtil.isObjNull(paymentDtl.getTvlProfile())) {
			Tvl tvl = new Tvl();
			tvl.setTvlProfile(new TvlProfile());
			tvl.getTvlProfile().setTvlProfId(paymentDtl.getTvlProfile().getTvlProfId());
			BeTvl beTvl = beTvlSvc.searchBeTravel(tvl);
			beTvl.setTvlInsurance(beTvlInsurance);
			beTvl.setUpdateId(userId);
		}
		// if(!BaseUtil.isObjNull(dto.getStatusId())) {
		// beTvlSvc.updateStatus(beTvlInsurance.getTvlProfile().getTvlProfId(),
		// dto.getStatusId());
		// }

		if (!BaseUtil.isListNull(dto.getTrxnDocumentList())) {
			beTrxnDocumentSvc.createUpdate(dto.getTrxnDocumentList(), userId, beTvlInsurance.getDocRefNo());
		}

		return beTvlInsurance;
	}


	@SuppressWarnings("unchecked")
	public List<Insurance> searchBeAcctTravellerPagination(Insurance dto, DataTableRequest<?> dataTableInRQ)
			throws IOException {
		return JsonUtil.transferToList(beTvlInsuranceQf.searchInsurancePagination(dto, dataTableInRQ),
				Insurance.class);
	}


	public long getCount(Insurance dto) {
		return beTvlInsuranceQf.getCount(dto);
	}
}
