/**
 *
 */
package com.be.service;


import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.RefBranchQf;
import com.be.dao.RefBranchRepository;
import com.be.model.RefBranch;
import com.be.sdk.constants.BeCacheConstants;
import com.be.sdk.model.IQfCriteria;


/**
 * @author Ramesh Pongianann
 *
 */
@Lazy
@Transactional
@Service(QualifierConstants.REF_BRANCH_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_BRANCH_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
public class RefBranchService extends AbstractService<RefBranch> {

	@Autowired
	RefBranchRepository refBranchDao;

	@Autowired
	RefBranchQf refBranchQf;


	@Override
	public GenericRepository<RefBranch> primaryDao() {
		return refBranchDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}


	public List<RefBranch> getAll() {
		return refBranchDao.findAll();
	}


	public RefBranch findByBranchCd(String branchCd) {
		return refBranchDao.findByBranchCd(branchCd);
	}


	public List<RefBranch> searchAllByProperty(RefBranch dto) {
		return refBranchQf.searchAllByProperty(dto);
	}
}
