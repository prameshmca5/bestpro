package com.bestpay.pgw.sdk.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

public class MerchantProfile implements Serializable {
	
	private static final long serialVersionUID = 6645623423283005357L;
	
	private Integer merProfId;
	private String merchantId;
	private String company;
	private String email;
	private String domain;
	private String salesPic;
	private String acStatus;
	private String subsPlan;
	private Integer monthlyCncl;
	private Integer monthlyChrgeback;
	private Integer totalChrgeback;
	private Integer highrisk;
	private Timestamp startCntrcDt;
	private Date expiryDt;
	private String memo;
	private String createId;
	private Timestamp createDt;
	private Timestamp updateDt;
	private String updateId;
	private String compRefId;
	private String ownerDirNationalId;
	private String ownerDirName;
	private String beneficiaryId;
	private String docMgtId;
	
	
	
	public String getDocMgtId() {
		return docMgtId;
	}
	public void setDocMgtId(String docMgtId) {
		this.docMgtId = docMgtId;
	}
	public Integer getMerProfId() {
		return merProfId;
	}
	public void setMerProfId(Integer merProfId) {
		this.merProfId = merProfId;
	}
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getSalesPic() {
		return salesPic;
	}
	public void setSalesPic(String salesPic) {
		this.salesPic = salesPic;
	}
	public String getAcStatus() {
		return acStatus;
	}
	public void setAcStatus(String acStatus) {
		this.acStatus = acStatus;
	}
	public String getSubsPlan() {
		return subsPlan;
	}
	public void setSubsPlan(String subsPlan) {
		this.subsPlan = subsPlan;
	}
	public Integer getMonthlyCncl() {
		return monthlyCncl;
	}
	public void setMonthlyCncl(Integer monthlyCncl) {
		this.monthlyCncl = monthlyCncl;
	}
	public Integer getMonthlyChrgeback() {
		return monthlyChrgeback;
	}
	public void setMonthlyChrgeback(Integer monthlyChrgeback) {
		this.monthlyChrgeback = monthlyChrgeback;
	}
	public Integer getTotalChrgeback() {
		return totalChrgeback;
	}
	public void setTotalChrgeback(Integer totalChrgeback) {
		this.totalChrgeback = totalChrgeback;
	}
	public Integer getHighrisk() {
		return highrisk;
	}
	public void setHighrisk(Integer highrisk) {
		this.highrisk = highrisk;
	}
	public Timestamp getStartCntrcDt() {
		return startCntrcDt;
	}
	public void setStartCntrcDt(Timestamp startCntrcDt) {
		this.startCntrcDt = startCntrcDt;
	}
	public Date getExpiryDt() {
		return expiryDt;
	}
	public void setExpiryDt(Date expiryDt) {
		this.expiryDt = expiryDt;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getCreateId() {
		return createId;
	}
	public void setCreateId(String createId) {
		this.createId = createId;
	}
	public Timestamp getCreateDt() {
		return createDt;
	}
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}
	public Timestamp getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}
	public String getUpdateId() {
		return updateId;
	}
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	public String getCompRefId() {
		return compRefId;
	}
	public void setCompRefId(String compRefId) {
		this.compRefId = compRefId;
	}
	public String getOwnerDirNationalId() {
		return ownerDirNationalId;
	}
	public void setOwnerDirNationalId(String ownerDirNationalId) {
		this.ownerDirNationalId = ownerDirNationalId;
	}
	public String getOwnerDirName() {
		return ownerDirName;
	}
	public void setOwnerDirName(String ownerDirName) {
		this.ownerDirName = ownerDirName;
	}
	public String getBeneficiaryId() {
		return beneficiaryId;
	}
	public void setBeneficiaryId(String beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}
	
	
	
}
