/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.sdk.model.ServiceCheck;
import com.bestpay.web.config.ConfigConstants;
import com.bestpay.web.constants.PageConstants;

/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
@RestController
@RequestMapping(PageConstants.SERVICE_CHECK)
public class ServiceCheckRestController extends AbstractController {

	@Autowired
	MessageSource messageSource;

	private static final String SERVICE_NAME = "EMPLOYER PORTAL";

	private static final String SUCCESS = "SUCCESS";

	private static final String FAILED = "FAILED";

	@GetMapping(consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody ServiceCheck serviceCheck(HttpServletRequest request) {
		StringBuffer url = request.getRequestURL();
		String uri = request.getRequestURI();
		ServiceCheck svcTest = new ServiceCheck(SERVICE_NAME, url.substring(0, url.indexOf(uri)), SUCCESS);

		// IDM Service
		String idmUrl = messageSource.getMessage(ConfigConstants.SVC_IDM_URL, null, Locale.getDefault());
		try {
			String str = getIdmService().checkConnection();
			svcTest.setIdm(new ServiceCheck(str, idmUrl, SUCCESS));
		} catch (Exception e) {
			svcTest.setIdm(new ServiceCheck("IDM Service", idmUrl, FAILED + " [" + e.getMessage() + "]"));
			svcTest.setServiceResponse(FAILED);
		}

		// NOTIFICATION Service
		String notifyUrl = messageSource.getMessage(ConfigConstants.SVC_NOT_URL, null, Locale.getDefault());
		try {
			String str = getNotifyService().checkConnection();
			svcTest.setNotification(new ServiceCheck(str, notifyUrl, SUCCESS));
		} catch (Exception e) {
			svcTest.setNotification(
					new ServiceCheck("Notification Service", notifyUrl, FAILED + " [" + e.getMessage() + "]"));
			svcTest.setServiceResponse(FAILED);
		}

		// REPORT Service
		String rptUrl = messageSource.getMessage(ConfigConstants.SVC_RPT_URL, null, Locale.getDefault());
		try {
			String str = getReportService().checkConnection();
			svcTest.setReport(new ServiceCheck(str, rptUrl, SUCCESS));
		} catch (Exception e) {
			svcTest.setReport(new ServiceCheck("REPORT Service", rptUrl, FAILED + " [" + e.getMessage() + "]"));
			svcTest.setServiceResponse(FAILED);
		}

		return svcTest;
	}

	@GetMapping(value = "test", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody String serviceCheck() {
		return SERVICE_NAME;
	}

	@GetMapping(value = "all", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody List<Object> serviceCheckAll(HttpServletRequest request) {
		List<Object> svcTestLst = new ArrayList<>();
		svcTestLst.add(serviceCheck(request));
		try {
			svcTestLst.add(getIdmService().serviceTest());
		} catch (Exception e) {
			svcTestLst.add(new ServiceCheck("IDM Service",
					messageSource.getMessage(ConfigConstants.SVC_IDM_URL, null, Locale.getDefault()), FAILED));
		}
		try {
			svcTestLst.add(getNotifyService().serviceTest());
		} catch (Exception e) {
			svcTestLst.add(new ServiceCheck("NOTIFICATION Service",
					messageSource.getMessage(ConfigConstants.SVC_NOT_URL, null, Locale.getDefault()), FAILED));
		}
		try {
			svcTestLst.add(getReportService().serviceTest());
		} catch (Exception e) {
			svcTestLst.add(new ServiceCheck("REPORT Service",
					messageSource.getMessage(ConfigConstants.SVC_RPT_URL, null, Locale.getDefault()), FAILED));
		}
		return svcTestLst;
	}
}