/**
 *
 */
package com.be.service;


import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTvlQf;
import com.be.dao.BeTvlRepository;
import com.be.model.BeAcctTraveller;
import com.be.model.BeTvl;
import com.be.model.RefStatus;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlProfile;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_SVC)
public class BeTvlService extends AbstractService<BeTvl> {

	public static final String PREFIX_IP = "IP/";

	@Autowired
	private BeTvlRepository beTvlDao;

	@Autowired
	private BeTvlQf beTvlQf;

	@Autowired
	BeConfigService beConfigSvc;

	@Autowired
	BeTvlProfileService beTvlProfileSvc;

	@Autowired
	BeAcctTravellerService beAcctTravellerSvc;


	@Override
	public GenericRepository<BeTvl> primaryDao() {
		return beTvlDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beTvlQf.generateCriteria(cb, from, criteria);
	}


	@SuppressWarnings("unchecked")
	public List<Tvl> searchTravelPagination(Tvl dto, DataTableRequest<?> dataTableInRQ) throws IOException {
		List<BeTvl> list = null;
		try {
			list = beTvlQf.searchBeTravelPagination(dto, dataTableInRQ);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return JsonUtil.transferToList(list, Tvl.class);
	}


	public List<BeTvl> searchBeTravelPagination(Tvl dto) {
		return beTvlQf.searchBeTravelPagination(dto, null);
	}


	public BeTvl searchBeTravel(Tvl dto) throws IOException {
		return beTvlQf.searchBeTravel(dto);
	}


	public long getCount(Tvl dto) {
		return beTvlQf.getCount(dto);
	}


	public BeTvl updateStatus(Integer tvlProfId, Integer statusId) {
		Tvl dto = new Tvl();
		dto.setTvlProfile(new TvlProfile());
		dto.getTvlProfile().setTvlProfId(tvlProfId);
		BeTvl beTvl = beTvlQf.searchBeTravel(dto);
		if (!BaseUtil.isObjNull(beTvl)) {
			beTvl.setStatus(new RefStatus());
			beTvl.getStatus().setStatusId(statusId);
			beTvl = update(beTvl);
		}
		return beTvl;
	}


	public List<BeTvl> saveList(List<BeTvl> beTvlList) {
		return beTvlDao.save(beTvlList);
	}


	public String generateTrxnNo(String cntryCd, Integer acctTvlrId) {
		int cnt = 0;
		if (!BaseUtil.isObjNull(acctTvlrId)) {
			TvlProfile tvlProfile = new TvlProfile();
			tvlProfile.setAcctTraveller(new AcctTraveller());
			tvlProfile.getAcctTraveller().setAcctTvlrId(acctTvlrId);
			cnt = (int) beTvlProfileSvc.getCount(tvlProfile);
		}
		String length = beConfigSvc.findByConfigCode("ID_LENGTH").getConfigVal();
		return generateRandomRefNo(Integer.parseInt(length), "IP", cntryCd, cnt);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public List<BeTvl> bulkUpdateExpired(List<BeTvl> beTvls, List<BeAcctTraveller> beAcctTravellers) {
		beAcctTravellerSvc.saveList(beAcctTravellers);
		return saveList(beTvls);
	}

}
