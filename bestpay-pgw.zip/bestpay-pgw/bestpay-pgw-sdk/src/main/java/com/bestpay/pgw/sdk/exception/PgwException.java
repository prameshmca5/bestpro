/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.exception;


import java.text.MessageFormat;

import com.bestpay.pgw.sdk.constants.BestpayErrorCodeEnum;
import com.bestpay.pgw.sdk.constants.PgwErrorCodeEnum;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
public class PgwException extends RuntimeException {

	private static final long serialVersionUID = -5876380106101907503L;

	private final String internalErrorCode;


	public PgwException() {
		super();
		internalErrorCode = "";
	}


	public PgwException(String s) {
		super(s);
		internalErrorCode = "";
	}


	public PgwException(String internalCode, String reason) {
		super(reason);
		internalErrorCode = internalCode;
	}


	public PgwException(PgwErrorCodeEnum rce) {
		super(rce.getMessage());
		internalErrorCode = rce.name();
	}


	public PgwException(PgwErrorCodeEnum rce, Object[] args) {
		super((args != null ? MessageFormat.format(rce.getMessage(), args) : rce.getMessage()));
		internalErrorCode = rce.name();
	}


	public String getInternalErrorCode() {
		return internalErrorCode;
	}


	public PgwException(BestpayErrorCodeEnum rce, Object[] args) {
		super((args != null ? MessageFormat.format(rce.getMessage(), args) : rce.getMessage()));
		internalErrorCode = rce.name();
	}
}