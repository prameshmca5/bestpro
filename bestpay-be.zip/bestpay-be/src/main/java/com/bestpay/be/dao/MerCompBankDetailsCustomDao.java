/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.bestpay.be.model.PgwMerchantCompanyBankDetails;
import com.bestpay.be.sdk.model.MerCompBankDetails;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.pagination.PaginationCriteria;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;

/**
 * @author Atiqah Khairuddin
 * @since May 31, 2019
 */
@Repository
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_COMPANY_BANK_DETAILS_DAO)
public class MerCompBankDetailsCustomDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(MerCompBankDetailsCustomDao.class);

	@Autowired
	private PgwMerchantCompanyBankDetailsRepository merCompBankDetailsDao;

	@PersistenceContext
	private EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public DataTableResults<PgwMerchantCompanyBankDetails> searchByPagination(MerCompBankDetails merCompBankDetails,
			DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append("from PgwMerchantCompanyBankDetails r ");
		sb.append(" where 1=1 ");

		if (!BaseUtil.isObjNull(merCompBankDetails.getCompRefId())) {
			sb.append(" and r.compRefId like :compRefId ");
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause("r"));
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<PgwMerchantCompanyBankDetails> query = entityManager.createQuery(sb.toString(), PgwMerchantCompanyBankDetails.class);
		// Original Query
		TypedQuery<PgwMerchantCompanyBankDetails> query2 = entityManager.createQuery(sb.toString(), PgwMerchantCompanyBankDetails.class);

		if (!BaseUtil.isObjNull(merCompBankDetails.getCompRefId())) {
			query.setParameter("compRefId", "%" + merCompBankDetails.getCompRefId() + "%");
			query2.setParameter("compRefId", "%" + merCompBankDetails.getCompRefId() + "%");
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwMerchantCompanyBankDetails> dataTableResult = new DataTableResults<>();
		List<PgwMerchantCompanyBankDetails> svcResp = query.getResultList();
		List<PgwMerchantCompanyBankDetails> svcResp2 = query2.getResultList();
		LOGGER.debug("Filtered Size: {}", svcResp.size());
		LOGGER.debug("Original Size: {}", svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : svcResp.size();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		LOGGER.debug("isFilterByEmpty: {}", dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}
		return dataTableResult;
	}

}