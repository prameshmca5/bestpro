/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;


/**
 * @author nurul.naimma
 *
 * @since Apr 19, 2021
 */

@Entity
@Table(name = "REF_PMT_GATEWAY_RESP")
public class RefPmtGatewayResp extends AbstractEntity implements Serializable, IQfCriteria<RefPmtGatewayResp> {

	private static final long serialVersionUID = 2440938718018382142L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PMT_GATEWAY_RESP_ID")
	private Integer pmtGatewayRespId;

	@Column(name = "RESP_CD")
	private String respCd;

	@Column(name = "RESP_DESCRIPTION")
	private String respDescription;

	@Column(name = "STATUS_CD")
	private Integer statusCd;

	@Column(name = "CHANNEL_CODE")
	private String channelCode;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;


	/**
	 * @return the pmtGatewayRespId
	 */
	public Integer getPmtGatewayRespId() {
		return pmtGatewayRespId;
	}


	/**
	 * @param pmtGatewayRespId
	 *             the pmtGatewayRespId to set
	 */
	public void setPmtGatewayRespId(Integer pmtGatewayRespId) {
		this.pmtGatewayRespId = pmtGatewayRespId;
	}


	/**
	 * @return the respCd
	 */
	public String getRespCd() {
		return respCd;
	}


	/**
	 * @param respCd
	 *             the respCd to set
	 */
	public void setRespCd(String respCd) {
		this.respCd = respCd;
	}


	/**
	 * @return the respDescription
	 */
	public String getRespDescription() {
		return respDescription;
	}


	/**
	 * @param respDescription
	 *             the respDescription to set
	 */
	public void setRespDescription(String respDescription) {
		this.respDescription = respDescription;
	}


	/**
	 * @return the statusCd
	 */
	public Integer getStatusCd() {
		return statusCd;
	}


	/**
	 * @param statusCd
	 *             the statusCd to set
	 */
	public void setStatusCd(Integer statusCd) {
		this.statusCd = statusCd;
	}


	/**
	 * @return the channelCode
	 */
	public String getChannelCode() {
		return channelCode;
	}


	/**
	 * @param channelCode
	 *             the channelCode to set
	 */
	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}


	/**
	 * @return the createId
	 */
	@Override
	public String getCreateId() {
		return createId;
	}


	/**
	 * @param createId
	 *             the createId to set
	 */
	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	/**
	 * @return the createDt
	 */
	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	/**
	 * @param createDt
	 *             the createDt to set
	 */
	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	/**
	 * @return the updateDt
	 */
	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	/**
	 * @param updateDt
	 *             the updateDt to set
	 */
	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	/**
	 * @return the updateId
	 */
	@Override
	public String getUpdateId() {
		return updateId;
	}


	/**
	 * @param updateId
	 *             the updateId to set
	 */
	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
