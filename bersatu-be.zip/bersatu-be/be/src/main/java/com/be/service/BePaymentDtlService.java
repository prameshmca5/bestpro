/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.be.service;


import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BePaymentDtlQf;
import com.be.dao.BePaymentDtlRepository;
import com.be.model.BePaymentDtl;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.PaymentDtl;
import com.be.sdk.model.PreReg;
import com.util.BaseUtil;
import com.util.pagination.DataTableRequest;


/**
 * @author mohd.naem
 * @since March 31 , 2021
 */
@Service(QualifierConstants.BE_PAYMENT_DTL_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_PAYMENT_DTL_SVC)
@Transactional
public class BePaymentDtlService extends AbstractService<BePaymentDtl> {

	protected static Logger logger = LoggerFactory.getLogger(BePaymentDtlService.class);

	@Autowired
	private BePaymentDtlRepository bePaymentDtlDao;

	@Autowired
	private BePreRegService bePreRegSvc;

	@Autowired
	private BePaymentDtlQf bePaymentDtlQf;


	@Override
	public GenericRepository<BePaymentDtl> primaryDao() {
		return bePaymentDtlDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return null;
	}


	public PaymentDtl searchDtl(String preRegId) throws IOException {

		PaymentDtl pmtDtl = new PaymentDtl();
		pmtDtl.setItemId(preRegId);

		BePaymentDtl bePaymentDtl = bePaymentDtlQf.searchPaymentDtl(pmtDtl);

		if (!BaseUtil.isObjNull(bePaymentDtl)) {

			// Payment payment =
			// JsonUtil.transferToObject(bePaymentDtl.getPayment(),
			// Payment.class);
			// pmtDtl.setPayment(payment);

			PreReg preReg = new PreReg();
			preReg.setPreRegId(Integer.getInteger(preRegId));
			preReg = bePreRegSvc.search(preReg);

			if (!BaseUtil.isObjNull(preReg)) {
				pmtDtl.setPreReg(preReg);
			}

			pmtDtl.setItemAmount(bePaymentDtl.getItemAmount());
		}
		return pmtDtl;
	}
	
	public List<BePaymentDtl> findByPreRegId(PaymentDtl dto, DataTableRequest<?> dataTableInRQ) throws IOException {
		return bePaymentDtlQf.searchAllByProperty(dto, dataTableInRQ);
	}
}