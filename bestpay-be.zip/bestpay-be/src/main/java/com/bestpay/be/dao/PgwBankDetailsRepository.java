package com.bestpay.be.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwBankDetails;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */

@Repository
@RepositoryDefinition(domainClass = PgwBankDetails.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_ACC_SET_DAO)
public interface PgwBankDetailsRepository extends GenericRepository<PgwBankDetails> {

	@Query("select u from PgwBankDetails u ")
	public PgwBankDetails findAllBankDetails();


	@Query("select u from PgwBankDetails u where u.bankDtlId = :bankDtlId ")
	public PgwBankDetails findByBankDetailsId(@Param("bankDtlId") int accSet);


	@Query("select u from PgwBankDetails u where u.merchantId = :merchantId ")
	public PgwBankDetails findBankDetailsByMerchantId(@Param("merchantId") String merchantId);


	@Query("select u from PgwBankDetails u where u.icType = :icType and u.icNumber = :icNumber ")
	public List<PgwBankDetails> findBankDetailsByIcTypeAndIcNum(@Param("icType") String icType,
			@Param("icNumber") String icNumber);


	@Query("select count(u) from PgwBankDetails u ")
	public int totalRecords();

}