/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.CriteriaBuilder.In;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BePayment;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Payment;
import com.be.sdk.model.PaymentDtl;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;


/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_PAYMENT_QF)
public class BePaymentQf extends QueryFactory<BePayment> {

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;

	protected static final Logger LOGGER = LoggerFactory.getLogger(BePaymentQf.class);
	
	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BePayment> searchByProperty(BePayment t) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<BePayment> searchAllByProperty(BePayment t) {
		CriteriaQuery<BePayment> cq = cb.createQuery(BePayment.class);
		Root<BePayment> root = cq.from(BePayment.class);
		List<Predicate> predicates = generateCriteria(cb, root, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public Long getCount(Payment dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BePayment> root = cq.from(BePayment.class);
		predicates.addAll(generateCriteria(cb, root, dto));

		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}


	public BePayment searchPayment(Payment dto) {

		BePayment result = null;
		CriteriaQuery<BePayment> cq = cb.createQuery(BePayment.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BePayment> root = cq.from(BePayment.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BePayment> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}


	public List<BePayment> searchAllByProperty(Payment dto, DataTableRequest<?> dataTableInRQ) {

		List<BePayment> result = new ArrayList<>();
		CriteriaQuery<BePayment> cq = cb.createQuery(BePayment.class);
		List<Predicate> predicates = new ArrayList<>();
		if (cq != null) {
			Root<BePayment> root = cq.from(BePayment.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			// Filter with Be payment Details
			if(!BaseUtil.isObjNull(dto.getPaymentDtlList())) {
				List<PaymentDtl> pmtD;
				try {
					pmtD = dto.getPaymentDtlList(); 
					In<Integer> in = cb.in(root.get("pmtId"));
					pmtD.forEach(v -> in.value(!BaseUtil.isObjNull(v.getPmtId()) ? BaseUtil.getInt(v.getPmtId()) : null));
					predicates.add(in);
				} catch (Exception e) {
					LOGGER.error("Exception BePaymentQf searchAllByProperty : ", e.getMessage());
				}
			}
						
			cq.select(root);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					List<Order> orders = getOrderByClause(cb, root, pagination);
					cq.orderBy(orders);
				}
			}

			TypedQuery<BePayment> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			Payment dto = JsonUtil.transferToObject(criteria, Payment.class);

			if (!BaseUtil.isObjNull(dto.getPmtId())) {
				predicates.add(cb.equal(from.get("pmtId"), dto.getPmtId()));
			}

			if (!BaseUtil.isObjNull(dto.getTxnId())) {
				predicates.add(cb.equal(from.get("txnId"), dto.getTxnId()));
			}

			if (!BaseUtil.isObjNull(dto.getPmtRefNo())) {
				predicates.add(cb.equal(from.get("pmtRefNo"), dto.getPmtRefNo()));
			}

			if (!BaseUtil.isObjNull(dto.getStatusId())) {
				predicates.add(cb.equal(from.get("statusId"), dto.getStatusId()));
			}

			if (!BaseUtil.isObjNull(dto.getPmtStateCd())) {
				predicates.add(cb.equal(from.get("pmtStateCd"), dto.getPmtStateCd()));
			}

			if (!BaseUtil.isObjNull(dto.getPmtDivisionCd())) {
				predicates.add(cb.equal(from.get("pmtDivisionCd"), dto.getPmtDivisionCd()));
			}

			if (!BaseUtil.isObjNull(dto.getPmtByLevel())) {
				predicates.add(cb.equal(from.get("pmtByLevel"), dto.getPmtByLevel()));
			}

			if (!BaseUtil.isObjNull(dto.getPmtDtFrom())) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(dto.getPmtDtFrom());
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				Date srcDt = cal.getTime();
				predicates.add(cb.greaterThanOrEqualTo(from.get("pmtDt"), srcDt));
			}

			if (!BaseUtil.isObjNull(dto.getPmtDtTo())) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(dto.getPmtDtTo());
				cal.set(Calendar.HOUR_OF_DAY, 23);
				cal.set(Calendar.MINUTE, 59);
				cal.set(Calendar.SECOND, 59);
				Date srcDt = cal.getTime();
				predicates.add(cb.lessThanOrEqualTo(from.get("pmtDt"), srcDt));
			}
			
			if (!BaseUtil.isObjNull(dto.getPmtSchdulerDt())) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(dto.getPmtSchdulerDt());
				//cal.set(Calendar.HOUR_OF_DAY, cal.get(Calendar.HOUR)-1);
				cal.set(Calendar.MINUTE, cal.get(Calendar.MINUTE)-(dto.getEnquirySchedularMinuts()));
				//cal.set(Calendar.SECOND, 00);
				Date srcDt = cal.getTime();
				predicates.add(cb.lessThanOrEqualTo(from.get("pmtDt"), srcDt));
			}


			if (!BaseUtil.isObjNull(dto.getPmtBy())) {
				predicates.add(cb.equal(from.get("pmtBy"), dto.getPmtBy()));
			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}


	private void joinFetch(From<?, ?> from, List<Predicate> predicates, Payment dto, CriteriaQuery<BePayment> cq) {
		from.fetch("status", JoinType.LEFT);
	}

}
