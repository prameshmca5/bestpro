/**
 *
 */
package com.be.controller;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.model.BeAcctPassport;
import com.be.model.BeAcctTraveller;
import com.be.model.BeConfig;
import com.be.model.BeTvl;
import com.be.model.BeTvlPaymentDtl;
import com.be.model.BeTvlStat;
import com.be.model.RefStatus;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeServiceConstants;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.constants.MyIpDQStatusEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.AcctPassport;
import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.Insurance;
import com.be.sdk.model.MRZdata;
import com.be.sdk.model.PaymentDtl;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlProfile;
import com.be.sdk.model.TvlStat;
import com.be.service.BeAcctPassportService;
import com.be.service.BeAcctTravellerService;
import com.be.service.BeConfigService;
import com.be.service.BeTvlInsuranceService;
import com.be.service.BeTvlPaymentDtlService;
import com.be.service.BeTvlProfileService;
import com.be.service.BeTvlService;
import com.be.service.BeTvlStatService;
import com.be.service.IntegrationService;
import com.be.service.RefStatusService;
import com.dm.sdk.exception.DmException;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;
import com.util.pagination.DataTableRequest;
import com.util.pagination.DataTableResults;


/**
 * @author michelle.angela
 *
 */
@Lazy
@RestController
@RequestMapping(BeUrlConstants.TRAVELLER)
public class TravellerRestController extends AbstractRestController {

	public static final String STATUS_APPROVED = "TRIP_APR";

	public static final String STATUS_RETURNED = "TRIP_RTN";

	public static final String STATUS_REJECTED = "TRIP_REJ";

	public static final String TYPE_TRIP = "TRIP";

	@Autowired
	private BeAcctTravellerService acctTravellerSvc;

	@Autowired
	private BeTvlInsuranceService tvlInsuranceSvc;

	@Autowired
	private BeTvlPaymentDtlService tvlPaymentDtlSvc;

	@Autowired
	private BeTvlStatService tvlStatSvc;

	@Autowired
	private BeTvlService tvlSvc;

	@Autowired
	RefStatusService statusSvc;

	@Autowired
	BeAcctPassportService acctPassportSvc;

	// @Autowired
	// RefDocumentService documentSvc;
	//
	// @Autowired
	// BeTrxnDocumentService trxnDocumentSvc;

	@Autowired
	BeTvlProfileService tvlProfileSvc;

	@Autowired
	IntegrationService integrationSvc;

	@Autowired
	BeConfigService configSvc;


	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<AcctTraveller> searchTravellerPaginated(@RequestBody AcctTraveller dto,
			HttpServletRequest request) throws IOException {

		DataTableRequest<AcctTraveller> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) acctTravellerSvc.getCount(dto);
		List<AcctTraveller> filtered = acctTravellerSvc.searchBeAcctTravellerPagination(dto, dataTableInRQ);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("ALL DATA: {}", totalCount);
			LOGGER.debug("ALL filtered DATA : {}", filtered);
		}

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.GET_DETAIL, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public AcctTraveller getTravellerDetail(@RequestBody AcctTraveller dto, HttpServletRequest request)
			throws IOException {
		return JsonUtil.transferToObject(acctTravellerSvc.searchBeAcctTraveller(dto), AcctTraveller.class);
	}


	@PostMapping(value = BeUrlConstants.INFO_ADD, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public AcctTraveller addTravellerInfo(@RequestBody AcctTraveller dto,
			@RequestParam("acctProfId") Integer acctProfId, HttpServletRequest request) throws IOException {

		if (BaseUtil.isObjNull(dto)) {
			throw new BeException(BeErrorCodeEnum.E400C003);
		}

		try {
			List<BeTvl> beTvls = new ArrayList<>();
			if (!BaseUtil.isObjNull(dto.getAcctTvlrId())) {
				Tvl tvlDto = new Tvl();
				tvlDto.setIsActive(true);
				tvlDto.setAcctTvlrId(dto.getAcctTvlrId());
				beTvls = tvlSvc.searchBeTravelPagination(tvlDto);
			} else {
				AcctTraveller atDto = new AcctTraveller();
				atDto.setDob(dto.getDob());
				atDto.setGender(dto.getGender());
				atDto.setPassportNo(dto.getAcctPassport().getPassportNo());
				atDto.setNationality(dto.getNationality());
				atDto.setAcctProfId(acctProfId);
				BeAcctTraveller beAcctTraveller = acctTravellerSvc.searchBeAcctTravellerInner(atDto);
				if (!BaseUtil.isObjNull(beAcctTraveller)) {
					throw new BeException(BeErrorCodeEnum.I409C001);
				}
			}

			return JsonUtil.transferToObject(
					acctTravellerSvc.addTravellerInfo(dto, acctProfId, getCurrUserId(request), beTvls),
					AcctTraveller.class);
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	@PostMapping(value = BeUrlConstants.INSURANCE + BeUrlConstants.INFO_ADD, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public Insurance addTravellerInsuranceInfo(@RequestBody Insurance dto, HttpServletRequest request)
			throws IOException {

		if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getTvlProfId())) {
			throw new BeException(BeErrorCodeEnum.E400C003);
		}

		try {
			PaymentDtl dtoPaymentDtl = new PaymentDtl();
			dtoPaymentDtl.setTvlProfile(new TvlProfile());
			dtoPaymentDtl.getTvlProfile().setTvlProfId(dto.getTvlProfId());
			BeTvlPaymentDtl paymentDtl = tvlPaymentDtlSvc.searchBeTvlPayment(dtoPaymentDtl);
			if (BaseUtil.isObjNull(paymentDtl)) {
				throw new BeException(BeErrorCodeEnum.E400C007);
			}
			return JsonUtil.transferToObject(tvlInsuranceSvc.createUpdate(dto, paymentDtl, getCurrUserId(request)),
					Insurance.class);
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	@PostMapping(value = BeUrlConstants.VERIFY, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public TvlStat verifyTraveller(@RequestBody TvlStat dto, HttpServletRequest request) throws IOException {

		if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getTvlId()) || BaseUtil.isObjNull(dto.getStatusInd())
				|| BaseUtil.isObjNull(dto.getDqStatMtdt())) {
			throw new BeException(BeErrorCodeEnum.E400C003);
		}

		TvlStat tvlStat = null;
		try {
			String statusCd = null;
			Tvl tvl = new Tvl();
			tvl.setTvlId(dto.getTvlId());
			tvl.setEmbedTraveller(true);
			tvl.setEmbedTrip(true);
			tvl.setEmbedAcctProfile(true);
			BeTvl beTvl = tvlSvc.searchBeTravel(tvl);
			if (BaseUtil.isObjNull(beTvl)) {
				throw new BeException(BeErrorCodeEnum.I404C001);
			}

			if (BaseUtil.isEquals("A", dto.getDqStatMtdt().getMtdtCd())) {
				statusCd = STATUS_APPROVED;
			} else if (BaseUtil.isEquals("RJ", dto.getDqStatMtdt().getMtdtCd())) {
				statusCd = STATUS_REJECTED;
			} else if (BaseUtil.isEquals("RT", dto.getDqStatMtdt().getMtdtCd())) {
				statusCd = STATUS_RETURNED;
			}

			if (!BaseUtil.isObjNull(statusCd)) {
				RefStatus status = new RefStatus();
				status.setStatusType(TYPE_TRIP);
				status.setStatusCd(statusCd);
				status = statusSvc.searchAllByProperty(status).get(0);
				beTvl.setStatus(status);
			}

			tvlStat = JsonUtil.transferToObject(tvlStatSvc.createUpdate(dto, beTvl, getCurrUserId(request), request),
					TvlStat.class);

			/**
			 * if(BaseUtil.isEquals(STATUS_APPROVED, statusCd)) {
			 * List<Documents> docList = new ArrayList<>(); List<RefDocument>
			 * myIpDoc =
			 * documentSvc.findAllByTrxnNo(FileUploadConstants.DOC_TRXN_MYIP_SLIP);
			 * Map<String, Object> params = new HashMap<>();
			 * params.put("tvlProfId", beTvl.getTvlProfile().getTvlProfId());
			 *
			 * if(!BaseUtil.isObjNull(beTvl.getTvlProfile()) &&
			 * BaseUtil.isObjNull(beTvl.getTvlProfile().getDocRefNo())) {
			 * beTvl.getTvlProfile().setDocRefNo(UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC));
			 * beTvl.getTvlProfile().setUpdateId(getCurrUserId(request));
			 * tvlProfileSvc.update(beTvl.getTvlProfile()); }
			 *
			 * if(!BaseUtil.isListNull(myIpDoc)) { ReportJasperDto myIP =
			 * getReportService(request).generateReport(myIpDoc.get(0).getDocTrxnNo(),
			 * "pdf", FileUploadConstants.REPORT_FOLDER, params);
			 * if(!BaseUtil.isObjNull(myIP.getFileContent())) {
			 * docList.add(trxnDocumentSvc.upload(myIpDoc.get(0), myIP,
			 * beTvl.getTvlProfile().getTrxnRefNo(), request));
			 * trxnDocumentSvc.createUpdateDoc(docList,
			 * getCurrUserId(request), beTvl.getTvlProfile().getDocRefNo());
			 * } } }
			 */

		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		} catch (DmException e) {
			throw new BeException(BeErrorCodeEnum.E500C010);
		} catch (Exception e) {
			throw new BeException(e.getMessage());
		}

		return tvlStat;
	}


	@PostMapping(value = BeUrlConstants.SEARCH_PASSPORT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public AcctPassport getPassportDetail(@RequestBody AcctPassport dto, HttpServletRequest request)
			throws IOException {
		BeAcctPassport beAcctPassport = dozerMapper.map(dto, BeAcctPassport.class);
		return JsonUtil.transferToObject(acctPassportSvc.searchBeAcctPassport(beAcctPassport), AcctPassport.class);
	}


	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.SEARCH_TRAVELLER, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<AcctTraveller> getTravellerList(@RequestBody AcctTraveller dto, HttpServletRequest request)
			throws IOException {
		return JsonUtil.transferToList(
				acctTravellerSvc.searchAllByProperty(JsonUtil.transferToObject(dto, BeAcctTraveller.class)),
				AcctTraveller.class);
	}


	@PostMapping(value = BeUrlConstants.READ_PASSPORT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MRZdata readPassport(@RequestBody MRZdata dto, HttpServletRequest request) {
		try {
			if (BaseUtil.isObjNull(dto)) {
				throw new BeException(BeErrorCodeEnum.E400C913);
			}

			BeConfig mrzConfig = configSvc.findByConfigCode(BeServiceConstants.BE_CONFIG_MRZ_SVC);
			if (BaseUtil.isObjNull(mrzConfig)) {
				throw new BeException(BeErrorCodeEnum.E400C007);
			}
			if (BaseUtil.isEquals(mrzConfig.getConfigVal(), BeServiceConstants.MRZ_SVC_REGULA)) {
				MRZdata mrzRegula = new MRZdata();
				mrzRegula.setFormat(".jpg");
				mrzRegula.setLightIndex(6);
				mrzRegula.setPageIndex(0);
				mrzRegula.setBase64ImageString(dto.getScan_image_base64());
				return integrationSvc.readPassportRegula(mrzRegula);
			} else {
				return integrationSvc.readPassport(dto);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BeException(e.getMessage());
		}
	}


	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.DQ + BeUrlConstants.VERIFY, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<TvlStat> dqVerifyTraveller(@RequestBody List<TvlStat> dtoList, @RequestParam("tvlId") Integer tvlId,
			HttpServletRequest request) throws IOException {

		if (BaseUtil.isListNull(dtoList) || BaseUtil.isObjNull(tvlId)) {
			throw new BeException(BeErrorCodeEnum.E400C003);
		}

		List<BeTvlStat> tvlStats = new ArrayList<>();
		try {
			BeTvlStat beTvlStat = null;
			// BeTvlStat beTvlStatFcm = null;
			Tvl tvl = new Tvl();
			tvl.setTvlId(tvlId);
			tvl.setEmbedTraveller(true);
			BeTvl beTvl = tvlSvc.searchBeTravel(tvl);
			if (BaseUtil.isObjNull(beTvl)) {
				throw new BeException(BeErrorCodeEnum.I404C001);
			}

			String statusCd = null;
			// String fcmtemplate = null;
			for (TvlStat stat : dtoList) {
				if (MyIpDQStatusEnum.OVERALL.getIndicator().equals(stat.getStatusInd())) {
					if (BaseUtil.isEquals("A", stat.getDqStatMtdt().getMtdtCd())) {
						statusCd = STATUS_APPROVED;
						// fcmtemplate =
						// MailTemplateConstants.FCM_TRAVEL_TRIP_APPROVED;
					} else if (BaseUtil.isEquals("RJ", stat.getDqStatMtdt().getMtdtCd())) {
						statusCd = STATUS_REJECTED;
						// fcmtemplate =
						// MailTemplateConstants.FCM_TRAVEL_TRIP_REJECTED;
					} else if (BaseUtil.isEquals("RT", stat.getDqStatMtdt().getMtdtCd())) {
						statusCd = STATUS_RETURNED;
						// fcmtemplate =
						// MailTemplateConstants.FCM_TRAVEL_TRIP_RETURNED;
					}

					if (!BaseUtil.isObjNull(statusCd)) {
						RefStatus status = new RefStatus();
						status.setStatusType(TYPE_TRIP);
						status.setStatusCd(statusCd);
						status = statusSvc.searchAllByProperty(status).get(0);
						beTvl.setStatus(status);
					}
				}

				beTvlStat = tvlStatSvc.createUpdate(stat, beTvl, getCurrUserId(request), request);
				tvlStats.add(beTvlStat);
				// if (!BaseUtil.isObjNull(statusCd) &&
				// !BaseUtil.isObjNull(fcmtemplate)) {
				// beTvlStatFcm = beTvlStat;
				// }
			}

			// // add fcm notification
			// try {
			// if (!BaseUtil.isObjNull(beTvlStatFcm)) {
			// Map<String, Object> datamap = new LinkedHashMap<>();
			// datamap.put("tripCodeNo",
			// beTvlStatFcm.getTvl().getTvlTrip().getTvlTripCodeNo());
			// datamap.put("passportNo",
			// beTvlStatFcm.getTvl().getTvlProfile().getAcctPassport().getPassportNo());
			//
			// UserProfile profile =
			// getIdmService(request).getUserProfileByProfId(
			// beTvlStatFcm.getTvl().getTvlProfile().getTvlProfId(), false,
			// false);
			//
			// List<FcmDevice> devices = searchAllDevice(profile, request);
			// addFCMNotification(devices, profile, datamap, fcmtemplate,
			// request);
			// }
			// } catch (Exception e) {
			// e.printStackTrace();
			// }
		} catch (BeException e) {
			e.printStackTrace();
			throw new BeException(BeErrorCodeEnum.E500C001);
		} catch (DmException e) {
			throw new BeException(BeErrorCodeEnum.E500C010);
		} catch (Exception e) {
			throw new BeException(e.getMessage());
		}

		return JsonUtil.transferToList(tvlStats, TvlStat.class);
	}


	@PostMapping(value = BeUrlConstants.INSURANCE + BeUrlConstants.SEARCH_PAGINATION, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DataTableResults<Insurance> searchInsurancePaginated(@RequestBody Insurance dto, HttpServletRequest request)
			throws IOException {

		DataTableRequest<Insurance> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) tvlInsuranceSvc.getCount(dto);
		List<Insurance> filtered = tvlInsuranceSvc.searchBeAcctTravellerPagination(dto, dataTableInRQ);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("ALL DATA: {}", totalCount);
			LOGGER.debug("ALL filtered DATA : {}", filtered);
		}

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.GET_LIST, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<AcctTraveller> getTravellerList2(@RequestBody AcctTraveller dto, HttpServletRequest request)
			throws IOException {
		return acctTravellerSvc.searchBeAcctTravellerPagination(dto, null);
	}
}
