/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;


/**
 * @author Afif saman
 * @since Jul 10, 2018
 */
public class MerChanSet implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 6645623423283005357L;

	private Integer mulChannelId;

	private String merchantId;

	private String compRefId;

	private String channel;

	private Double rate;

	private Double cost;

	private Double additionalCost;

	private Double monthlyFee;

	private String deleted;


	public String getDeleted() {
		return deleted;
	}


	public void setDeleted(String deleted) {
		this.deleted = deleted;
	}


	public Integer getMulChannelId() {
		return mulChannelId;
	}


	public void setMulChannelId(Integer mulChannelId) {
		this.mulChannelId = mulChannelId;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public Double getRate() {
		return rate;
	}


	public void setRate(Double rate) {
		this.rate = rate;
	}


	public Double getCost() {
		return cost;
	}


	public void setCost(Double cost) {
		this.cost = cost;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public Double getAdditionalCost() {
		return additionalCost;
	}


	public void setAdditionalCost(Double additionalCost) {
		this.additionalCost = additionalCost;
	}


	public Double getMonthlyFee() {
		return monthlyFee;
	}


	public void setMonthlyFee(Double monthlyFee) {
		this.monthlyFee = monthlyFee;
	}


	public String getCompRefId() {
		return compRefId;
	}


	public void setCompRefId(String compRefId) {
		this.compRefId = compRefId;
	}

}