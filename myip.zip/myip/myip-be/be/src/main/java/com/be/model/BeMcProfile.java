/**
 * 
 */
package com.be.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author michelle.angela
 *
 */
 @Entity
 @Table(name = "BE_MC_PROFILE")
public class BeMcProfile extends AbstractEntity implements Serializable, IQfCriteria<BeMcProfile> {
	 
	private static final long serialVersionUID = 1573300664397232956L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="MC_PROF_ID")
	private Integer mcProfId;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORG_TYPE_MTDT_ID")
	private RefMetadata orgTypeMtdt;
	 
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MC_TYPE_MTDT_ID")
	private RefMetadata mcTypeMtdt;
		
	@Column(name = "MC_REG_NO")
	private String mcRegNo;
	
	@Column(name = "MC_NAME")
	private String mcName;
	
	@Column(name = "CONTACT_NO")
	private String contactNo;
	
	@Column(name = "CONTACT_NO_2")
	private String contactNo2;
	
	@Column(name = "FAX_NO")
	private String faxNo;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "WEBSITE")
	private String website;
	
	@Column(name = "DOC_REF_NO")
	private String docRefNo;
	
	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;
	
	@JsonIgnoreProperties("mcProfile")
	@OneToMany(mappedBy = "mcProfile", fetch = FetchType.LAZY)
	private Set<BeMcOwner> mcOwners;
	
	@JsonIgnoreProperties("mcProfile")
	@OneToMany(mappedBy = "mcProfile", fetch = FetchType.LAZY)
	private Set<BeMcPic> mcPics;
	
	@JsonIgnoreProperties("mcProfile")
	@OneToMany(mappedBy = "mcProfile", fetch = FetchType.LAZY)
	private Set<BeMcAddress> mcAddresses;

	public Integer getMcProfId() {
		return mcProfId;
	}

	public void setMcProfId(Integer mcProfId) {
		this.mcProfId = mcProfId;
	}

	public RefMetadata getOrgTypeMtdt() {
		return orgTypeMtdt;
	}

	public void setOrgTypeMtdt(RefMetadata orgTypeMtdt) {
		this.orgTypeMtdt = orgTypeMtdt;
	}

	public RefMetadata getMcTypeMtdt() {
		return mcTypeMtdt;
	}

	public void setMcTypeMtdt(RefMetadata mcTypeMtdt) {
		this.mcTypeMtdt = mcTypeMtdt;
	}

	public String getMcRegNo() {
		return mcRegNo;
	}

	public void setMcRegNo(String mcRegNo) {
		this.mcRegNo = mcRegNo;
	}

	public String getMcName() {
		return mcName;
	}

	public void setMcName(String mcName) {
		this.mcName = mcName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getContactNo2() {
		return contactNo2;
	}

	public void setContactNo2(String contactNo2) {
		this.contactNo2 = contactNo2;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getDocRefNo() {
		return docRefNo;
	}

	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public Set<BeMcOwner> getMcOwners() {
		return mcOwners;
	}

	public void setMcOwners(Set<BeMcOwner> mcOwners) {
		this.mcOwners = mcOwners;
	}

	public Set<BeMcPic> getMcPics() {
		return mcPics;
	}

	public void setMcPics(Set<BeMcPic> mcPics) {
		this.mcPics = mcPics;
	}

	public Set<BeMcAddress> getMcAddresses() {
		return mcAddresses;
	}

	public void setMcAddresses(Set<BeMcAddress> mcAddresses) {
		this.mcAddresses = mcAddresses;
	}	 
			 
}
