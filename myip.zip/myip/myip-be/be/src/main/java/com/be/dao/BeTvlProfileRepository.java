/**
 *
 */
package com.be.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.BeTvlProfile;


/**
 * @author michelle.angela
 *
 */
@Lazy
@Repository
@RepositoryDefinition(domainClass = BeTvlProfile.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_PROFILE_DAO)
public interface BeTvlProfileRepository extends GenericRepository<BeTvlProfile> {

	@Query("select count(u) from BeTvlProfile u ")
	int totalRecords();


	@Query("select u from BeTvlProfile u, BeTvl v, RefStatus w where u.tvlProfId = v.tvlProfile.tvlProfId "
			+ "and v.status.statusId = w.statusId and u.acctTraveller.acctTvlrId = :acctTvlrId and w.statusCd = :statusCd")
	List<BeTvlProfile> findByAcctTvlrIdAndStatusCode(@Param("acctTvlrId") Integer acctTvlrId,
			@Param("statusCd") String statusCd);
}
