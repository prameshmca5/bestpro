/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.CountryRepository;
import com.bestpay.be.model.RefCountry;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Ilhomjon
 * @since Feb 22, 2018
 */
@Service(QualifierConstants.APJ_COMMON_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.APJ_COMMON_SVC)
public class CountryService extends AbstractService<RefCountry> {

	@Autowired
	private CountryRepository countryDao;


	@Override
	public GenericRepository<RefCountry> primaryDao() {
		return countryDao;
	}


	public List<RefCountry> allCountries() {
		return countryDao.findAllCountries();
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public RefCountry findByCtrCode(String crtCode) {
		return countryDao.findByCode(crtCode);
	}
}