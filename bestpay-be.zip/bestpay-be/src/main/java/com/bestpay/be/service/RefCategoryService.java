/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.RefCategoryRepository;
import com.bestpay.be.model.RefCategory;
import com.bestpay.be.sdk.constants.BeCacheConstants;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Afif Saman
 * @since Jul 19, 2018
 */
@Transactional
@Service(QualifierConstants.REF_CATEGORY_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_CATEGORY_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
public class RefCategoryService extends AbstractService<RefCategory> {

	@Autowired
	RefCategoryRepository refCategoryDao;


	// Not caching RefCategory as merchant can update RefCategory in UI using
	// Business Category Tab in Merchant Management
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	@Override
	public List<RefCategory> findAll() {
		return refCategoryDao.findAll();
	}


	@Override
	public GenericRepository<RefCategory> primaryDao() {
		return refCategoryDao;
	}

}
