/**
 * 
 */
package com.be.service;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.RefDivisionQf;
import com.be.dao.RefDivisionRepository;
import com.be.dao.RefParliamentQf;
import com.be.dao.RefParliamentRepository;
import com.be.model.RefDivision;
import com.be.model.RefParliament;
import com.be.sdk.constants.BeCacheConstants;
import com.be.sdk.model.IQfCriteria;

/**
 * @author Ramesh Pongianann
 *
 */
@Lazy
@Transactional
@Service(QualifierConstants.REF_DIVISION_SVC) 
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_DIVISION_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
public class RefDivisionService extends AbstractService<RefDivision> {

	@Autowired
	RefDivisionRepository refDivisionDao;
	
	@Autowired
	RefDivisionQf refDivisionQf;
	
	@Override
	public GenericRepository<RefDivision> primaryDao() {
		return refDivisionDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<RefDivision> getAll() {
		return refDivisionDao.findAll();
	}

	public RefDivision findByDivisionCd(String divisionCd) {
		return refDivisionDao.findByDivisionCd(divisionCd);
	}
	
	public List<RefDivision> searchAllByProperty(RefDivision dto) {
		return refDivisionQf.searchAllByProperty(dto);
	}
}
