/**
 * Copyright 2020. Bestinet Sdn Bhd
 */
package com.be.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.RefIntAirport;

/**
 * @author nurul.naimma
 *
 * @since 11 Jul 2020
 */

@Repository
@RepositoryDefinition(domainClass = RefIntAirport.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_INT_AIRPORT_DAO)
public interface RefIntAirportRepository extends GenericRepository<RefIntAirport> {

	@Query("select u from RefIntAirport u ")
	List<RefIntAirport> getAllIntAirport();

}
