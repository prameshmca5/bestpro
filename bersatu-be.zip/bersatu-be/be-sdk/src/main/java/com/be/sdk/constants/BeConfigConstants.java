/**
 * Copyright 2019
 */
package com.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BeConfigConstants {

	private BeConfigConstants() {
		throw new IllegalStateException("BeConfigConstants class");
	}


	public static final String SMS_SWITCH = "SMS_SWITCH";

	public static final String APR_LETTER_SIGNATURE = "APR_LETTER_SIGNATURE";

	public static final String APR_LETTER_POSITION = "APR_LETTER_POSITION";

	public static final String APPLICATION_JSON = "application/json";

	public static final String MESSAGE_ID = "X-Message-Id";

	public static final String HEADER_AUTHORIZATION = "Authorization";

	public static final String CONTENT_TYPE = "Content-Type";

	public static final String FORM_URL_ENCODED = "application/x-www-form-urlencoded";

	public static final String PFX_DATA_IMAGE = "data:image/jpeg;base64,";

	public static final String PARAM_IMAGE_DATA = "image-data";

	public static final String PARAM_IMAGE_DATA_1 = "image-data-1";

	public static final String PARAM_IMAGE_DATA_2 = "image-data-2";

	public static final String PARAM_USERNAME = "username";

	public static final String PARAM_PASSWORD = "password";

	public static final String HEADER_AUTHENTICATION = "Authentication";

}