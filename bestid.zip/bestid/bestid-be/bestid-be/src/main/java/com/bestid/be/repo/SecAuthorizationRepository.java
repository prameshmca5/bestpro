/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.repo;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.SecAuthorization;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
@Repository
@RepositoryDefinition(domainClass = SecAuthorization.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.AUTHORIZATION_DAO)
public interface SecAuthorizationRepository extends GenericRepository<SecAuthorization> {

	@Query("select u from SecAuthorization u where u.clientId= :clientId and u.trxnNo = :trxnNo ")
	public SecAuthorization findByClientIdAndTxnNo(@Param("clientId") String clientId, @Param("trxnNo") String trxnNo);

}
