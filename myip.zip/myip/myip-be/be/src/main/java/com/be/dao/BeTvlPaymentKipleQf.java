/**
 * 
 */
package com.be.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeTvlPaymentKiple;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.PaymentKiple;
import com.be.service.BeTvlPaymentKipleService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;

/**
 * @author Ramesh Pongiannan
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_PAYMENT_KIPLE_QF)
public class BeTvlPaymentKipleQf extends QueryFactory<BeTvlPaymentKiple> {

	@Autowired
	BeTvlPaymentKipleService beTvlPaymentKipleSvc;
	
	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;

	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}
	
	@Override
	public Specification<BeTvlPaymentKiple> searchByProperty(BeTvlPaymentKiple t) {
		return (Root<BeTvlPaymentKiple> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}

	@Override
	public List<BeTvlPaymentKiple> searchAllByProperty(BeTvlPaymentKiple t) {
		CriteriaQuery<BeTvlPaymentKiple> cq = cb.createQuery(BeTvlPaymentKiple.class);
		Root<BeTvlPaymentKiple> from = cq.from(BeTvlPaymentKiple.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}

	public List<BeTvlPaymentKiple> searchPaymentKiplePagination(PaymentKiple dto, DataTableRequest<?> dataTableInRQ) {

		List<BeTvlPaymentKiple> result = new ArrayList<>();
		CriteriaQuery<BeTvlPaymentKiple> cq = cb.createQuery(BeTvlPaymentKiple.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlPaymentKiple> root = cq.from(BeTvlPaymentKiple.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					cq.orderBy(getOrderByClause(cb, root, pagination));
				}
			}

			TypedQuery<BeTvlPaymentKiple> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}
	
	
	public BeTvlPaymentKiple searchPaymentKiple(PaymentKiple dto) {

		BeTvlPaymentKiple result = null;
		CriteriaQuery<BeTvlPaymentKiple> cq = cb.createQuery(BeTvlPaymentKiple.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlPaymentKiple> root = cq.from(BeTvlPaymentKiple.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			//joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeTvlPaymentKiple> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}
	
	public Long getCount(PaymentKiple dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeTvlPaymentKiple> root = cq.from(BeTvlPaymentKiple.class);
		predicates.addAll(generateCriteria(cb, root, dto));
		
		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}
	
	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			BeTvlPaymentKiple dto = JsonUtil.transferToObject(criteria, BeTvlPaymentKiple.class);
			if (!BaseUtil.isObjNull(dto.getPmtDt())) {
				predicates.add(cb.equal(from.get("pmtDt"), dto.getPmtDt()));
			}

			if (!BaseUtil.isObjNull(dto.getPmtRefNo())) {
				predicates.add(cb.equal(from.get("pmtRefNo"), dto.getPmtRefNo()));
			}
			
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void joinFetch(From<?, ?> from, List<Predicate> predicates, PaymentKiple dto, CriteriaQuery<BeTvlPaymentKiple> cq) {
		
		/*from.fetch("acctProfile", JoinType.LEFT);
		from.fetch("nationality", JoinType.LEFT);
		
		Join<BeTvlPayment, BeAcctPassport> passport = (Join) from.fetch("acctPassport", JoinType.LEFT);
		if(!BaseUtil.isObjNull(dto.getPassportNo())) {
			predicates.addAll(beTvlPaymentSvc.generateCriteria(cb, passport, dto));
		}	*/	
	}
 
}
