/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;

/**
 * @author michelle.angela
 *
 */
public class TripHealth implements Serializable {

	private static final long serialVersionUID = 4564337569010520040L;

	private Integer tvlTripHealthId;

	private Trip tvlTrip;

	private ConfigTripHealth configTripHealth;

	private Metadata resultMtdt;

	public Integer getTvlTripHealthId() {
		return tvlTripHealthId;
	}

	public void setTvlTripHealthId(Integer tvlTripHealthId) {
		this.tvlTripHealthId = tvlTripHealthId;
	}

	public Trip getTvlTrip() {
		return tvlTrip;
	}

	public void setTvlTrip(Trip tvlTrip) {
		this.tvlTrip = tvlTrip;
	}

	public ConfigTripHealth getConfigTripHealth() {
		return configTripHealth;
	}

	public void setConfigTripHealth(ConfigTripHealth configTripHealth) {
		this.configTripHealth = configTripHealth;
	}

	public Metadata getResultMtdt() {
		return resultMtdt;
	}

	public void setResultMtdt(Metadata resultMtdt) {
		this.resultMtdt = resultMtdt;
	}
	
}
