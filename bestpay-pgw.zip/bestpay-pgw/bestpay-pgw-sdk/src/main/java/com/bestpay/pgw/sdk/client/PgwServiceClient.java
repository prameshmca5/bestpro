/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.client;


import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.http.impl.client.CloseableHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bestpay.pgw.sdk.builder.CommonService;
import com.bestpay.pgw.sdk.builder.ReferenceService;
import com.bestpay.pgw.sdk.constants.PgwConstants;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.constants.ServiceConstants;
import com.bestpay.pgw.sdk.incentiveremit.model.AuthorizedConfirmedResponse;
import com.bestpay.pgw.sdk.incentiveremit.model.BeneficiaryDetailResult;
import com.bestpay.pgw.sdk.incentiveremit.model.BillPlzTransactionRequest;
import com.bestpay.pgw.sdk.incentiveremit.model.BillPlzTransactionResponse;
import com.bestpay.pgw.sdk.incentiveremit.model.ExRateRequest;
import com.bestpay.pgw.sdk.incentiveremit.model.ExRateResult;
import com.bestpay.pgw.sdk.incentiveremit.model.SendTransactionRequest;
import com.bestpay.pgw.sdk.incentiveremit.model.SendTransactionResult;
import com.bestpay.pgw.sdk.incentiveremit.model.TransactionStatusResponse;
import com.bestpay.pgw.sdk.incentiveremit.model.UserLoginResult;
import com.bestpay.pgw.sdk.model.ApsProfile;
import com.bestpay.pgw.sdk.model.ApsProfileResponse;
import com.bestpay.pgw.sdk.model.Channel;
import com.bestpay.pgw.sdk.model.CustomerDetail;
import com.bestpay.pgw.sdk.model.FpxPayResponse;
import com.bestpay.pgw.sdk.model.IRProfile;
import com.bestpay.pgw.sdk.model.IRProfileResponse;
import com.bestpay.pgw.sdk.model.IpayEnquireOrderStatus;
import com.bestpay.pgw.sdk.model.KYCStatusResponse;
import com.bestpay.pgw.sdk.model.MMResponse;
import com.bestpay.pgw.sdk.model.MerCompBankDetails;
import com.bestpay.pgw.sdk.model.MerCompany;
import com.bestpay.pgw.sdk.model.MerchantBeneficiary;
import com.bestpay.pgw.sdk.model.MerchantInfoDto;
import com.bestpay.pgw.sdk.model.MerchantPid;
import com.bestpay.pgw.sdk.model.MultiChannel;
import com.bestpay.pgw.sdk.model.OrderDetails;
import com.bestpay.pgw.sdk.model.PgwAuditTrailDto;
import com.bestpay.pgw.sdk.model.PgwPaymentSettingDto;
import com.bestpay.pgw.sdk.model.PgwTransactionDto;
import com.bestpay.pgw.sdk.model.PgwTransactionHistroyDto;
import com.bestpay.pgw.sdk.model.Provider;
import com.bestpay.pgw.sdk.model.RefBankFpx;
import com.bestpay.pgw.sdk.model.RefFpxResponseCodeDto;
import com.bestpay.pgw.sdk.model.RemittanceStatusDto;
import com.bestpay.pgw.sdk.model.ServiceCheck;
import com.bestpay.pgw.sdk.model.StaticList;
import com.bestpay.pgw.sdk.model.TransferRate;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.pgw.sdk.util.UriUtil;
import com.bstsb.util.UidGenerator;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class PgwServiceClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(PgwServiceClient.class);

	private static final String MERCHANTID = "merchantId";

	private static final String ORDERID = "orderId";

	private static final String MERCHANTID_GET_PARAM = "?merchantId={merchantId}";

	private static PgwServiceClient instance = null;

	private static PgwRestTemplate restTemplate;

	private static Properties prop;

	private String url;

	private String clientId;

	private String token;

	private String authToken;

	private String messageId;

	private int readTimeout;

	static {
		restTemplate = new PgwRestTemplate();
		loadProperty();
	}


	private PgwServiceClient() {
	}


	public PgwServiceClient(String url) {
		this.url = url;
	}


	public PgwServiceClient(String url, int readTimeout) {
		this.url = url;
		this.readTimeout = readTimeout;
	}


	public PgwServiceClient(String url, String clientId, int readTimeout) {
		this.url = url;
		this.clientId = clientId;
		this.readTimeout = readTimeout;
	}


	private static PgwServiceClient getInstance() {
		if (instance == null) {
			instance = new PgwServiceClient();
		}

		return instance;
	}


	private PgwRestTemplate getRestTemplate() {
		CloseableHttpClient httpClient = null;
		if (BaseUtil.isObjNull(messageId)) {
			messageId = UidGenerator.getMessageId();
		}
		if (authToken != null) {
			httpClient = new HttpAuthClient(authToken, messageId, readTimeout).getHttpClient();
		} else {
			httpClient = new HttpAuthClient(clientId, token, messageId, readTimeout).getHttpClient();
		}
		restTemplate.setHttpClient(httpClient);
		return restTemplate;
	}


	private String getServiceURI(String serviceName) {
		if (serviceName.contains("${prefix}")) {
			serviceName = serviceName.replace("${prefix}", prop.getProperty("prefix"));
		}
		if (serviceName.contains("${version}")) {
			serviceName = serviceName.replace("${version}", prop.getProperty("version"));
		}
		String uri = url + serviceName;
		LOGGER.info("Service Rest URL: {} ", uri);
		return uri;
	}


	protected String getServiceURI(String serviceName, Object obj) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);

		JsonNode jnode = mapper.valueToTree(obj);
		boolean isFirst = true;
		StringBuilder sb = new StringBuilder();
		sb.append(getServiceURI(serviceName));

		if (!BaseUtil.isObjNull(obj)) {
			try {
				Map<String, Object> maps = mapper.readValue(jnode.toString(),
						new TypeReference<Map<String, Object>>() {
						});
				for (Map.Entry<String, Object> entry : maps.entrySet()) {
					String mKey = entry.getKey();
					Object mValue = entry.getValue();
					if (!BaseUtil.isObjNull(mValue) && !BaseUtil.isEquals(mKey, "serialVersionUID")) {
						if (isFirst) {
							sb.append("?");
							isFirst = false;
						}
						if (mValue instanceof String) {
							mValue = UriUtil.getVariableValueAsString(mValue);
						}
						sb.append(mKey + "=" + mValue + "&");
					}
				}
			} catch (IOException e) {
				LOGGER.error(e.getMessage());
			}
		}
		return !isFirst ? (sb.toString()).substring(0, sb.length() - 1) : sb.toString();
	}


	private static void loadProperty() {
		prop = new Properties();
		String propFileName = "bestpay-be-sdk.properties";
		InputStream is = getInstance().getClass().getClassLoader().getResourceAsStream(propFileName);
		if (is != null) {
			try {
				prop.load(is);
			} catch (IOException e) {
				LOGGER.error(e.getMessage());
			}
		} else {
			LOGGER.info("NO PROPERTY FOUND");
		}
	}


	public void setClientId(String clientId) {
		this.clientId = clientId;
	}


	public void setToken(String token) {
		this.token = token;
	}


	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}


	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public static void setRestTemplate(PgwRestTemplate restTemplate) {
		PgwServiceClient.restTemplate = restTemplate;
	}


	public String checkConnection() {
		return getRestTemplate().getForObject(getServiceURI(PgwUrlConstants.SERVICE_CHECK + "/test"), String.class);
	}


	public ServiceCheck serviceTest() {
		return getRestTemplate().getForObject(getServiceURI(PgwUrlConstants.SERVICE_CHECK), ServiceCheck.class);
	}


	public ReferenceService reference() {
		return new ReferenceService(getRestTemplate(), prop, url);
	}


	public CommonService commonService() {
		return new CommonService(getRestTemplate(), prop, url);
	}


	public PgwRestTemplate restTemplate() {
		return restTemplate;
	}


	public StaticList getStaticList() {
		return reference().all();
	}


	public StaticList getStaticList(String staticlistType) {

		StaticList staticLst = new StaticList();

		if (staticlistType.equalsIgnoreCase(ServiceConstants.STAT_LST_CITY)) {
			staticLst.setCityList(reference().findByAllCities());
		} else if (staticlistType.equalsIgnoreCase(ServiceConstants.STAT_LST_RELATIONSHIP)) {
			staticLst.setRelationList(reference().findAllRelationShips());
		}

		return staticLst;
	}


	public List<RefBankFpx> findByBankCodeList(List<String> bankCodeLstAll, String payType) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.FIND_BY_BANK_CODE_LIST);
		sb.append("?payType={payType}");
		sb.append("&bankCodeLstAll={bankCodeLstAll}");
		Map<String, Object> params = new HashMap<>();
		params.put("payType", payType);
		params.put("bankCodeLstAll", bankCodeLstAll);
		RefBankFpx[] resp = getRestTemplate().getForObject(getServiceURI(sb.toString()), RefBankFpx[].class, params);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	public PgwTransactionDto findByOrderIDAndTransID(String transId, String orderId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.FIND_BY_ORDER_ID_TRANSID);
		sb.append("?transId={transIdParam}");
		sb.append("&orderId={orderIdParam}");
		Map<String, Object> params = new HashMap<>();
		params.put("transIdParam", transId);
		params.put("orderIdParam", orderId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), PgwTransactionDto.class, params);
	}


	public PgwTransactionDto findByMerchantIDAndOrderID(String merchantId, String orderId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.FIND_BY_MERCHANT_ID_ORDER_ID);
		sb.append("?merchantId={merchantIdParam}");
		sb.append("&orderId={orderId}");
		Map<String, Object> params = new HashMap<>();
		params.put("merchantIdParam", merchantId);
		params.put(ORDERID, orderId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), PgwTransactionDto.class, params);
	}


	public PgwTransactionDto updateBankandChannel(String transId, String orderId, String bankId, String channel) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.UPDATE_CHANNEL_AND_BANK);
		sb.append("?transId={transId}");
		sb.append("&orderId={orderId}");
		sb.append("&bankId={bankId}");
		sb.append("&channel={channel}");
		Map<String, Object> params = new HashMap<>();
		params.put("transId", transId);
		params.put(ORDERID, orderId);
		params.put("bankId", bankId);
		params.put("channel", channel);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), PgwTransactionDto.class, params);
	}


	public RefFpxResponseCodeDto findByFpxCode(String refCode) {
		Map<String, Object> params = new HashMap<>();
		params.put("refCode", refCode);
		return getRestTemplate()
				.getForObject(
						getServiceURI(PgwUrlConstants.REFERENCE + PgwConstants.SLASH
								+ PgwUrlConstants.REF_TYPE_FPX_RES_CODE + "/{refCode}"),
						RefFpxResponseCodeDto.class, params);
	}


	public PgwTransactionDto saveFpxResponse(FpxPayResponse fpxPayResponse) {
		return getRestTemplate().postForObject(getServiceURI(PgwUrlConstants.ADD_FPX_RESPONSE), fpxPayResponse,
				PgwTransactionDto.class);
	}


	public FpxPayResponse saveFpxResponse(FpxPayResponse fpxPayRequest, String respCode) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.ADD_FPX_RESPONSE);
		sb.append("?respCode={respCode}");
		Map<String, Object> params = new HashMap<>();
		params.put("respCode", respCode);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), fpxPayRequest, FpxPayResponse.class,
				params);
	}


	public PgwAuditTrailDto savePgwAuditTrail(PgwAuditTrailDto pgwAudit) {
		return getRestTemplate().postForObject(getServiceURI(PgwUrlConstants.SAVE_PGW_AUDIT_AUDIT), pgwAudit,
				PgwAuditTrailDto.class);
	}


	public PgwTransactionDto createPgwTransaction(PgwTransactionDto transaction) {
		return getRestTemplate().postForObject(getServiceURI(PgwUrlConstants.CREATE_PGW_TRANSACTION), transaction,
				PgwTransactionDto.class);
	}


	public String generateReqhash(String url, String merchantId, String currency, String orderId, double amount,
			String verifyKey) {
		PgwPaymentVerifyHashUrl pvh = new PgwPaymentVerifyHashUrl(url);
		return pvh.generateReqhash(merchantId, currency, orderId, amount, verifyKey);
	}


	public boolean isUrlReqhashVerified(String url, String merchantId, String currency, String orderId, double amount,
			String verifyKey) {
		PgwPaymentVerifyHashUrl pvh = new PgwPaymentVerifyHashUrl(url);
		return pvh.isUrlReqhashVerified(merchantId, currency, orderId, amount, verifyKey);
	}


	public String getUrlWithReqhash(String url, String merchantId, String currency, String orderId, double amount,
			String verifyKey) {
		PgwPaymentVerifyHashUrl pvh = new PgwPaymentVerifyHashUrl(url);
		return pvh.getUrlWithReqhash(merchantId, currency, orderId, amount, verifyKey);
	}


	public PgwPaymentSettingDto findMerchantById(String merchantId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.PAYMENT_SETTING);
		sb.append(PgwUrlConstants.FIND_BY_MERCHANT_ID);
		sb.append("?merchantId={merchantIdParam}");
		Map<String, Object> params = new HashMap<>();
		params.put("merchantIdParam", merchantId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), PgwPaymentSettingDto.class, params);
	}


	public List<MultiChannel> findchannelByMerchantId(String merchantId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MULTI_CHANNEL_SETTING);
		sb.append(PgwUrlConstants.FIND_BY_MERCHANT_ID);
		sb.append(MERCHANTID_GET_PARAM);
		Map<String, Object> params = new HashMap<>();
		params.put(MERCHANTID, merchantId);
		MultiChannel[] resp = getRestTemplate().getForObject(getServiceURI(sb.toString()), MultiChannel[].class,
				params);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	public PgwTransactionDto updatePgwTransaction(PgwTransactionDto transaction) {
		return getRestTemplate().postForObject(getServiceURI(PgwUrlConstants.UPDATE_PGW_TRANSACTION), transaction,
				PgwTransactionDto.class);
	}


	public List<PgwTransactionDto> findFpxPendingTransactions() {
		PgwTransactionDto[] resp = getRestTemplate()
				.getForObject(getServiceURI(PgwUrlConstants.FIND_FPX_PENDING_TRANS), PgwTransactionDto[].class);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	public MerchantInfoDto getMerchantInfo(String merchantId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MERCHANT_PROFILE);
		sb.append(PgwUrlConstants.FIND_BY_MERCHANT_ID);
		sb.append(MERCHANTID_GET_PARAM);
		Map<String, Object> params = new HashMap<>();
		params.put(MERCHANTID, merchantId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerchantInfoDto.class, params);
	}


	public Channel findChannelByPublicName(String refCode) {
		Map<String, Object> params = new HashMap<>();
		params.put("refCode", refCode);
		return getRestTemplate().getForObject(getServiceURI(PgwUrlConstants.REFERENCE + PgwConstants.SLASH
				+ PgwUrlConstants.REF_TYPE_CHANNEL_LIST + "/{refCode}"), Channel.class, params);
	}


	public ApsProfileResponse saveApsProfile(ApsProfile apsProfile) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.SAVE_APS_PROFILE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), apsProfile, ApsProfileResponse.class);
	}


	public TransferRate getTransferRateFromMaxMoney(String currencyCode) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MAXMONEY_SERVICE);
		sb.append(PgwUrlConstants.GET_MAXMONEY_RATE);
		sb.append("?currencyCode=" + currencyCode);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), TransferRate.class);
	}


	public KYCStatusResponse getKYCStatus(String merchantId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MAXMONEY_SERVICE);
		sb.append(PgwUrlConstants.GET_KYC_STATUS);
		sb.append("?merchantId=" + merchantId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), KYCStatusResponse.class);
	}


	public String getSessionIdUsingMMPid(String maxmoneyId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MAXMONEY_SERVICE);
		sb.append(PgwUrlConstants.GET_SESSION_WITH_MMPID);
		sb.append("?maxmoneyId=" + maxmoneyId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), String.class);
	}


	public OrderDetails getRequestPayLoad(OrderDetails orderDetails) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MAXMONEY_SERVICE);
		sb.append(PgwUrlConstants.GET_MAXMONEY_PAYLOAD);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), orderDetails, OrderDetails.class);
	}


	public CustomerDetail updateCustomer(ApsProfile apsProfile) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.UPD_CUSTOMER);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), apsProfile, CustomerDetail.class);
	}


	public CustomerDetail uploadDocs(com.bestpay.pgw.sdk.model.ApsProfile apsProfile) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MAXMONEY_SERVICE);
		sb.append(PgwUrlConstants.UPLOAD_DOCS);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), apsProfile, CustomerDetail.class);
	}


	public MMResponse approveCustomer(String idNo) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MAXMONEY_SERVICE);
		sb.append(PgwUrlConstants.APPROVE_CUSTOMER);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), idNo, MMResponse.class);
	}


	public MMResponse validateCustomer(String idNo) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MAXMONEY_SERVICE);
		sb.append(PgwUrlConstants.VALIDATE_CUSTOMER);
		sb.append("?idNo=" + idNo);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MMResponse.class);

	}


	public CustomerDetail createUser(String idNo) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MAXMONEY_SERVICE);
		sb.append(PgwUrlConstants.CREATE_USER);
		sb.append("?idNo=" + idNo);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), CustomerDetail.class);
	}


	public RemittanceStatusDto getMaxmoneyOrderStatus(String orderid) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MAXMONEY_SERVICE);
		sb.append(PgwUrlConstants.MMORDERSTATUS);
		sb.append("?orderId=" + orderid);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), RemittanceStatusDto.class);
	}


	public OrderDetails getBeneficiaryToOrder(OrderDetails orderDetails) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MAXMONEY_SERVICE);
		sb.append(PgwUrlConstants.GET_BENFI_DETAILS);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), orderDetails, OrderDetails.class);
	}


	public OrderDetails getsubmitionOrder(OrderDetails orderDetails) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MAXMONEY_SERVICE);
		sb.append(PgwUrlConstants.SUBMIT_MAXMONEY_ORDER);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), orderDetails, OrderDetails.class);
	}


	public List<MerchantPid> findMerchantPid(String merchantId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MTO_MERCHANT_PROFILE);
		sb.append(PgwUrlConstants.FIND_MERCHANT_PID);
		sb.append("?merchantId=" + merchantId);
		Map<String, Object> params = new HashMap<>();
		params.put(MERCHANTID, merchantId);
		MerchantPid[] resp = getRestTemplate().getForObject(getServiceURI(sb.toString()), MerchantPid[].class,
				params);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	public PgwTransactionDto findMerchantIdUseRefid(String refId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.FIND_BY_MERCHANT_ID_REFID);
		sb.append("?refId={transIdParam}");
		Map<String, Object> params = new HashMap<>();
		params.put("transIdParam", refId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), PgwTransactionDto.class, params);
	}


	public PgwTransactionDto updateTransactionStatus(String oid, String status, String errcode, String resdsMessage) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.UPDATE_TRANS_STATUS_MAXMONEY);
		sb.append("?oid={oid}");
		sb.append("&status={status}");
		sb.append("&errcode={errcode}");
		sb.append("&resdsMessage={resdsMessage}");
		Map<String, Object> params = new HashMap<>();
		params.put("oid", oid);
		params.put("status", status);
		params.put("errcode", errcode);
		params.put("resdsMessage", resdsMessage);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), PgwTransactionDto.class, params);
	}


	public List<PgwTransactionDto> findRemitPendingTransactions() {
		PgwTransactionDto[] resp = getRestTemplate()
				.getForObject(getServiceURI(PgwUrlConstants.FIND_REMIT_PENDING_TRANS), PgwTransactionDto[].class);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	public RemittanceStatusDto getstatusOrderFromMaxmoney(RemittanceStatusDto remitdto) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MAXMONEY_SERVICE);
		sb.append(PgwUrlConstants.CHKORDER_STATUS_CHK);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), remitdto, RemittanceStatusDto.class);
	}


	public List<PgwTransactionHistroyDto> findTransHistroyByOrderId(String orderId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.TRANS_HISTROY);
		sb.append(PgwUrlConstants.FIND_BY_ORDER_DET_HIST);
		sb.append("?orderId={orderId}");
		Map<String, Object> params = new HashMap<>();
		params.put(ORDERID, orderId);
		PgwTransactionHistroyDto[] resp = getRestTemplate().getForObject(getServiceURI(sb.toString()),
				PgwTransactionHistroyDto[].class, params);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	public IRProfileResponse saveIRProfile(IRProfile irProfile) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.SAVE_IR_PROFILE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), irProfile, IRProfileResponse.class);
	}


	public UserLoginResult getIncentiveServiceStatus() {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.INCENTIVEREMIT_SERVICE);
		sb.append("/userLogin");
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), UserLoginResult.class);
	}


	public ExRateResult getIncentiveRate(ExRateRequest exRateRequest) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.INCENTIVEREMIT_SERVICE);
		sb.append("/getExRate");
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), exRateRequest, ExRateResult.class);
	}


	public SendTransactionResult getIncentiveTransactionPin(SendTransactionRequest sendRequest) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.INCENTIVEREMIT_SERVICE);
		sb.append("/sendTransaction");
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), sendRequest,
				SendTransactionResult.class);
	}


	public BillPlzTransactionResponse sendBillPlz(BillPlzTransactionRequest billRequest) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.INCENTIVEREMIT_SERVICE);
		sb.append("/transactionBillPlz");
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), billRequest,
				BillPlzTransactionResponse.class);
	}


	public AuthorizedConfirmedResponse sendAuthorizedConfirm(String pinNo) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.INCENTIVEREMIT_SERVICE);
		sb.append("/authorizedConfirmed");
		sb.append("?pinNo={pinNo}");
		Map<String, Object> params = new HashMap<>();
		params.put("pinNo", pinNo);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), AuthorizedConfirmedResponse.class,
				params);

	}


	public TransactionStatusResponse checkQueryStatus(String refNo) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.INCENTIVEREMIT_SERVICE);
		sb.append("/transactionStatus");
		sb.append("?refNo={refNo}");
		Map<String, Object> params = new HashMap<>();
		params.put("refNo", refNo);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), TransactionStatusResponse.class, params);

	}


	public PgwTransactionDto updateTransactionStatusbillplz(String oid, String status, String errcode,
			String resdsMessage, String billplzid) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.UPDATE_TRANS_STATUS_IRBILLPLZ);
		sb.append("?oid={oid}");
		sb.append("&status={status}");
		sb.append("&errcode={errcode}");
		sb.append("&resdsMessage={resdsMessage}");
		sb.append("&billplzid={billplzid}");
		Map<String, Object> params = new HashMap<>();
		params.put("oid", oid);
		params.put("status", status);
		params.put("errcode", errcode);
		params.put("resdsMessage", resdsMessage);
		params.put("billplzid", billplzid);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), PgwTransactionDto.class, params);
	}


	public PgwTransactionDto findMerchantIdUseSubmerid(String submerId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.FIND_BY_MERCHANT_ID_SUBMERID);
		sb.append("?submerId={submerId}");
		Map<String, Object> params = new HashMap<>();
		params.put("submerId", submerId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), PgwTransactionDto.class, params);
	}


	public MerchantPid findMerchantIRCustId(MerchantPid pid) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.FIND_MERCHANT_IRCUSID);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), pid, MerchantPid.class);
	}


	public MerchantBeneficiary findMerchantBeneficaryId(String merchantId,String mtoId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MERCHANT_BENEFICIARY);
		sb.append(PgwUrlConstants.FIND_MERCHANT_IRCUSID);
		sb.append("?merchantId={merchantId}");
		sb.append("&mtoId={mtoId}");
		Map<String, Object> params = new HashMap<>();
		params.put("merchantId", merchantId);
		params.put("mtoId", mtoId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerchantBeneficiary.class, params);
	}


	public RemittanceStatusDto getIncentiveOrderStatus(String orderid) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.INCENTIVEREMIT_SERVICE);
		sb.append(PgwUrlConstants.IRORDERSTATUS);
		sb.append("?orderId=" + orderid);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), RemittanceStatusDto.class);
	}


	public BeneficiaryDetailResult getIncentiveBeneficiaryDetails(String beneficiarySno, String senderCustomerId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.INCENTIVEREMIT_SERVICE);
		sb.append(PgwUrlConstants.FIND_INCENT_BENEF_DETAILS);
		sb.append("?beneficiarySno={beneficiarySno}");
		sb.append("&senderCustomerId={senderCustomerId}");
		Map<String, Object> params = new HashMap<>();
		params.put("beneficiarySno", beneficiarySno);
		params.put("senderCustomerId", senderCustomerId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), BeneficiaryDetailResult.class, params);

	}


	/**
	 * Get Merchant Company Bank Details
	 *
	 * @param companyName
	 * @return @
	 */

	public MerCompBankDetails getCompRefBankDetailsByCompRefId(String compRefId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MER_COMP_BANK_DETAILS);
		sb.append("/" + compRefId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerCompBankDetails.class);
	}


	public MerCompany getCompDetailsByCompRefId(String compRefId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.MERCHANT_COMPANY);
		sb.append("/" + compRefId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerCompany.class);
	}


	public Provider getProviderInfo(String providerName) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.PROVIDER);
		sb.append("/" + providerName);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), Provider.class);
	}
	
	public PgwTransactionDto findMerchantIdUseOrderid(String transOrderId) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.FIND_BY_TRANSACTION_ID_ORDERID);
		sb.append("?transOrderId={transOrderId}");
		Map<String, Object> params = new HashMap<>();
		params.put("transOrderId", transOrderId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), PgwTransactionDto.class, params);
	}
	
	public PgwTransactionDto updateTransactionStatusIpay(PgwTransactionDto transaction) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.UPDATE_TRANS_STATUS_IPAY);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), transaction, PgwTransactionDto.class);
	}

	public RefFpxResponseCodeDto findByFpxDesc(String refCode) {
		Map<String, Object> params = new HashMap<>();
		params.put("refCode", refCode);
		return getRestTemplate()
				.getForObject(
						getServiceURI(PgwUrlConstants.REFERENCE + PgwConstants.SLASH
								+ PgwUrlConstants.REF_TYPE_FPX_RES_DESC + "/{refCode}"),
						RefFpxResponseCodeDto.class, params);
	}
	
	public List<RefFpxResponseCodeDto> findByRefFpxDesc(String fpxDesc) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.REFERENCE );
		sb.append(PgwUrlConstants.REF_TYPE_FPX_RES_DESC);
		sb.append("?fpxDesc="+fpxDesc);
		/*Map<String, Object> params = new HashMap<>();
		params.put("fpxDesc", fpxDesc);*/
		RefFpxResponseCodeDto[] resp = getRestTemplate().getForObject(getServiceURI(sb.toString()), RefFpxResponseCodeDto[].class);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}
	
	public IpayEnquireOrderStatus getIpayOrderStatus(String orderid) {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.IPAY_ORDER_SERVICE);
		sb.append(PgwUrlConstants.IPAY_ORDER_ENQUIRE_STATUS);
		sb.append("?orderId=" + orderid);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), IpayEnquireOrderStatus.class);
	}


}