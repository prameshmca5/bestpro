/**
 *
 */
package com.bestid.web.subscribe.form;

import java.sql.Timestamp;
import java.util.List;

import com.bestid.web.cmn.form.FileUpload;

/**
 * @author suhada
 * @since Feb 22, 2019
 */

public class SubscriberInfoForm implements java.io.Serializable {

	private static final long serialVersionUID = 7803285550647135313L;

	private int subscrId;
	private String subscrCd;
	private String sysName;
	private int cmpnyId;
	private String subscrType;
	private String createId;
	private Timestamp createDt;
	private String updateId;
	private Timestamp updateDt;
	private String indicator;
	private String addSub;
	private String cmpnyRegNo;
	private String cmpnyRegNoParam;
	private String deactivated;
	private String sysLogo;
	private String file;


	private CompanyInfoForm companyInfo;
	private List<FileUpload> fileUploads;


	public int getSubscrId() {
		return subscrId;
	}

	public void setSubscrId(int subscrId) {
		this.subscrId = subscrId;
	}

	public String getSubscrCd() {
		return subscrCd;
	}

	public void setSubscrCd(String subscrCd) {
		this.subscrCd = subscrCd;
	}

	public String getSysName() {
		return sysName;
	}

	public void setSysName(String sysName) {
		this.sysName = sysName;
	}

	public int getCmpnyId() {
		return cmpnyId;
	}

	public void setCmpnyId(int cmpnyId) {
		this.cmpnyId = cmpnyId;
	}

	public String getSubscrType() {
		return subscrType;
	}

	public void setSubscrType(String subscrType) {
		this.subscrType = subscrType;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public CompanyInfoForm getCompanyInfo() {
		return companyInfo;
	}

	public void setCompanyInfo(CompanyInfoForm companyInfo) {
		this.companyInfo = companyInfo;
	}

	public String getIndicator() {
		return indicator;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}

	public String getAddSub() {
		return addSub;
	}

	public void setAddSub(String addSub) {
		this.addSub = addSub;
	}

	public String getCmpnyRegNoParam() {
		return cmpnyRegNoParam;
	}

	public void setCmpnyRegNoParam(String cmpnyRegNoParam) {
		this.cmpnyRegNoParam = cmpnyRegNoParam;
	}

	public String getCmpnyRegNo() {
		return cmpnyRegNo;
	}

	public void setCmpnyRegNo(String cmpnyRegNo) {
		this.cmpnyRegNo = cmpnyRegNo;
	}

	public String getDeactivated() {
		return deactivated;
	}

	public void setDeactivated(String deactivated) {
		this.deactivated = deactivated;
	}

	public List<FileUpload> getFileUploads() {
		return fileUploads;
	}

	public void setFileUploads(List<FileUpload> fileUploads) {
		this.fileUploads = fileUploads;
	}

	public String getSysLogo() {
		return sysLogo;
	}

	public void setSysLogo(String sysLogo) {
		this.sysLogo = sysLogo;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}
	
	
}
