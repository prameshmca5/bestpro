package com.bestpay.be.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;

/**
 * @author Md Asif Aftab
 * @since 3rd April 2018
 */

@Entity
@Table(name = "REF_RELATIONSHIP")
public class RefRelationship extends AbstractEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5843669369621248334L;

	@Id
	@Column(name = "RELATION_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String relationId;

	@Column(name = "RELATION_CODE")
	private String relationCode;

	@Column(name = "RELATION_DESC")
	private String relationDesc;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	public String getRelationId() {
		return relationId;
	}

	public void setRelationId(String relationId) {
		this.relationId = relationId;
	}

	public String getRelationCode() {
		return toUpper(relationCode);
	}

	public void setRelationCode(String relationCode) {
		this.relationCode = toUpper(relationCode);
	}

	public String getRelationDesc() {
		return toUpper(relationDesc);
	}

	public void setRelationDesc(String relationDesc) {
		this.relationDesc = toUpper(relationDesc);
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}
