/**
 * 
 */
package com.be.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.BeMcOwner;

/**
 * @author michelle.angela
 *
 */
@Lazy
@Repository
@RepositoryDefinition(domainClass = BeMcOwner.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_MC_OWNER_DAO)
public interface BeMcOwnerRepository extends GenericRepository<BeMcOwner> {

}
