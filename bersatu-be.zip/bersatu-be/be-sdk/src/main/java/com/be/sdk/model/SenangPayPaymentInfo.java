/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author Ramesh Pongiannan
 *
 * @since Dec 15, 2021
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class SenangPayPaymentInfo implements Serializable {
 
	private static final long serialVersionUID = -4552304969633049024L;
	
	 private String transaction_reference;
	 
	 private String transaction_date;
	 
	 private String payment_mode;
	 
	 private String status;

	public String getTransaction_reference() {
		return transaction_reference;
	}

	public void setTransaction_reference(String transaction_reference) {
		this.transaction_reference = transaction_reference;
	}

	public String getTransaction_date() {
		return transaction_date;
	}

	public void setTransaction_date(String transaction_date) {
		this.transaction_date = transaction_date;
	}

	public String getPayment_mode() {
		return payment_mode;
	}

	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	 
}
