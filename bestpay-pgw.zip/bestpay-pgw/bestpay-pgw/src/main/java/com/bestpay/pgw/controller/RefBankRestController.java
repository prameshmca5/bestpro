package com.bestpay.pgw.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.RefBank;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.model.RefBankFpx;
import com.bestpay.pgw.service.RefBankService;


/**
 * @author Chaithanya Kumar
 * @since 03/07/2018
 */
@RestController
public class RefBankRestController extends AbstractRestController {

	@Autowired
	public RefBankService bankService;


	@GetMapping(value = PgwUrlConstants.FIND_BY_BANK_CODE_LIST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<RefBankFpx> findBankCodeList(@RequestParam List<String> bankCodeLstAll,
			@RequestParam(value = "payType") String payType, HttpServletRequest request) {
		List<RefBankFpx> resList = new ArrayList<>();
		List<RefBank> bankList = bankService.findByBankCodeList(bankCodeLstAll, payType);
		for (RefBank cnt : bankList) {
			resList.add(dozerMapper.map(cnt, RefBankFpx.class));
		}
		return resList;
	}

}
