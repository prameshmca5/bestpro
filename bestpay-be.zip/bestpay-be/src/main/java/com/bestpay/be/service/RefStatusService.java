/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.config.ConfigConstants;
import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.RefStatusCustomDao;
import com.bestpay.be.dao.RefStatusRepository;
import com.bestpay.be.model.RefStatus;
import com.bestpay.be.sdk.constants.BeCacheConstants;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 3, 2016
 */
@Transactional
@Service(QualifierConstants.REF_STATUS_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_STATUS_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
public class RefStatusService extends AbstractService<RefStatus> {

	@Autowired
	RefStatusRepository refStatusDao;

	@Autowired
	RefStatusCustomDao refStatusCustomDao;


	@Override
	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_STATUS_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<RefStatus> findAll() {
		return refStatusDao.findAll();
	}


	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_STATUS.concat(#statusCode)", condition = "#statusCode != null and #result != null")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public RefStatus findByStatusCode(String statusCode) {
		return refStatusDao.findByStatusCode(statusCode);
	}


	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_STATUS_TYP.concat(#statusType)", condition = "#statusType != null and #result != null")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<RefStatus> findByStatusType(String statusType) {
		return refStatusDao.findByStatusType(statusType);
	}


	@Override
	@Caching(evict = {
			@CacheEvict(beforeInvocation = true, key = ConfigConstants.CACHE_JAVA_FILE + ".CACHE_KEY_STATUS_ALL"),
			@CacheEvict(beforeInvocation = true, key = ConfigConstants.CACHE_JAVA_FILE
					+ ".CACHE_KEY_STATUS_TYP.concat(#s.statusType)") }, put = {
							@CachePut(key = ConfigConstants.CACHE_JAVA_FILE
									+ ".CACHE_KEY_STATUS.concat(#s.statusCd)") })
	public RefStatus create(RefStatus s) {
		return super.create(s);
	}


	@Override
	@Caching(evict = {
			@CacheEvict(beforeInvocation = true, key = ConfigConstants.CACHE_JAVA_FILE + ".CACHE_KEY_STATUS_ALL"),
			@CacheEvict(beforeInvocation = true, key = ConfigConstants.CACHE_JAVA_FILE
					+ ".CACHE_KEY_STATUS.concat(#s.statusCd)"),
			@CacheEvict(beforeInvocation = true, key = ConfigConstants.CACHE_JAVA_FILE
					+ ".CACHE_KEY_STATUS_TYP.concat(#s.statusType)") })
	public RefStatus update(RefStatus s) {
		return super.update(s);
	}


	@Override
	@Caching(evict = {
			@CacheEvict(beforeInvocation = true, key = ConfigConstants.CACHE_JAVA_FILE + ".CACHE_KEY_STATUS_ALL"), })
	public boolean delete(Integer id) {
		return super.delete(id);
	}


	@Override
	public GenericRepository<RefStatus> primaryDao() {
		return refStatusDao;
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public RefStatus findByStatusDescEn(String statusCode) {
		return refStatusDao.findByStatusDescEn(statusCode);
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public RefStatus findByStatusTypeAndCode(String statusType, String statusCode) {
		return refStatusDao.findByTypeAndCode(statusType, statusCode);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<RefStatus> searchStatusByPagination(com.bestpay.be.sdk.model.RefStatus refStatus,
			DataTableRequest dataTableInRQ) {
		return refStatusCustomDao.searchStatusByPagination(refStatus, dataTableInRQ);
	}
}
