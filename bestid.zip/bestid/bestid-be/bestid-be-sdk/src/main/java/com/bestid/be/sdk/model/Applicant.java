/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;
import java.util.Date;


/**
 * @author nurul.naimma
 *
 * @since 9 Nov 2018
 */
public class Applicant implements Serializable {

	private static final long serialVersionUID = 1918068814289244730L;

	private Integer id;

	private String nationalId;

	private String firstName;

	private String lastName;

	private Date dateBirth;

	private String genderCd;

	private String ntnltyCd;

	private String cntryCd;

	private String contactNo;

	private String email;

	private String address1;

	private String address2;

	private String address3;

	private String address4;

	private String address5;

	private String poscode;

	private String city;

	private String state;

	private String currCntryCd;

	private String docRefNo;


	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}


	/**
	 * @param id
	 *             the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}


	/**
	 * @return the nationalId
	 */
	public String getNationalId() {
		return nationalId;
	}


	/**
	 * @param nationalId
	 *             the nationalId to set
	 */
	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}


	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}


	/**
	 * @param firstName
	 *             the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}


	/**
	 * @param lastName
	 *             the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	/**
	 * @return the dateBirth
	 */
	public Date getDateBirth() {
		return dateBirth;
	}


	/**
	 * @param dateBirth
	 *             the dateBirth to set
	 */
	public void setDateBirth(Date dateBirth) {
		this.dateBirth = dateBirth;
	}


	/**
	 * @return the genderCd
	 */
	public String getGenderCd() {
		return genderCd;
	}


	/**
	 * @param genderCd
	 *             the genderCd to set
	 */
	public void setGenderCd(String genderCd) {
		this.genderCd = genderCd;
	}


	/**
	 * @return the ntnltyCd
	 */
	public String getNtnltyCd() {
		return ntnltyCd;
	}


	/**
	 * @param ntnltyCd
	 *             the ntnltyCd to set
	 */
	public void setNtnltyCd(String ntnltyCd) {
		this.ntnltyCd = ntnltyCd;
	}


	/**
	 * @return the cntryCd
	 */
	public String getCntryCd() {
		return cntryCd;
	}


	/**
	 * @param cntryCd
	 *             the cntryCd to set
	 */
	public void setCntryCd(String cntryCd) {
		this.cntryCd = cntryCd;
	}


	/**
	 * @return the contactNo
	 */
	public String getContactNo() {
		return contactNo;
	}


	/**
	 * @param contactNo
	 *             the contactNo to set
	 */
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}


	/**
	 * @param email
	 *             the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}


	/**
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}


	/**
	 * @param address1
	 *             the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}


	/**
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}


	/**
	 * @param address2
	 *             the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	/**
	 * @return the address3
	 */
	public String getAddress3() {
		return address3;
	}


	/**
	 * @param address3
	 *             the address3 to set
	 */
	public void setAddress3(String address3) {
		this.address3 = address3;
	}


	/**
	 * @return the address4
	 */
	public String getAddress4() {
		return address4;
	}


	/**
	 * @param address4
	 *             the address4 to set
	 */
	public void setAddress4(String address4) {
		this.address4 = address4;
	}


	/**
	 * @return the address5
	 */
	public String getAddress5() {
		return address5;
	}


	/**
	 * @param address5
	 *             the address5 to set
	 */
	public void setAddress5(String address5) {
		this.address5 = address5;
	}


	/**
	 * @return the poscode
	 */
	public String getPoscode() {
		return poscode;
	}


	/**
	 * @param poscode
	 *             the poscode to set
	 */
	public void setPoscode(String poscode) {
		this.poscode = poscode;
	}


	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}


	/**
	 * @param city
	 *             the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}


	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}


	/**
	 * @param state
	 *             the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}


	/**
	 * @return the currCntryCd
	 */
	public String getCurrCntryCd() {
		return currCntryCd;
	}


	/**
	 * @param currCntryCd
	 *             the currCntryCd to set
	 */
	public void setCurrCntryCd(String currCntryCd) {
		this.currCntryCd = currCntryCd;
	}


	/**
	 * @return the docRefNo
	 */
	public String getDocRefNo() {
		return docRefNo;
	}


	/**
	 * @param docRefNo
	 *             the docRefNo to set
	 */
	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}

}
