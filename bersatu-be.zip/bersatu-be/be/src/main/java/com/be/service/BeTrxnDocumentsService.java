package com.be.service;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTrxnDocumentQf;
import com.be.dao.BeTrxnDocumentRepository;
import com.be.model.BeTrxnDocument;
import com.be.model.BeTrxnDocumentPK;
import com.be.sdk.constants.BeCacheConstants;
import com.be.sdk.model.IQfCriteria;
import com.dm.sdk.model.Documents;
import com.util.BaseUtil;


@Lazy
@Transactional
@Service(QualifierConstants.BE_TRXN_DOC_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TRXN_DOC_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
public class BeTrxnDocumentsService extends AbstractService<BeTrxnDocument> {

	@Autowired
	BeTrxnDocumentRepository docRepositry;

	@Autowired
	BeTrxnDocumentQf beTrxnDocumentQf;


	@Override
	public GenericRepository<BeTrxnDocument> primaryDao() {
		// TODO Auto-generated method stub
		return docRepositry;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return beTrxnDocumentQf.generateCriteria(cb, from, criteria);
	}


	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public BeTrxnDocument create(BeTrxnDocument doc) {
		doc.setAppRefNo("");
		doc.setAppType("");
		doc.setVerify(true);
		doc.setUpdateId("system");
		doc.setCreateId("system");
		doc.setCreateDt(getSQLTimestamp());
		doc.setUpdateDt(getSQLTimestamp());
		return docRepositry.saveAndFlush(doc);
		// return docRepositry.saveAndFlush(doc);
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public BeTrxnDocument findTrxnDocumentsByDocMgtId(String docMgtId) {
		BeTrxnDocument beTrxnDocument = null;
		List<BeTrxnDocument> beTrxnDocumentList = docRepositry.findTrxnDocumentsDocMgtId(docMgtId);
		if (!BaseUtil.isListNull(beTrxnDocumentList)) {
			beTrxnDocument = beTrxnDocumentList.get(0);
		}
		return beTrxnDocument;
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<BeTrxnDocument> getTrxnDocumentsByRefNo(String docRefNo) {
		return docRepositry.findByDocRefNo(docRefNo);
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<BeTrxnDocument> getTrxnDocumentsByRefNoAndDocId(String docRefNo, Integer docId) {
		return docRepositry.findTrxnDocumentsByRefNoAndDocId(docRefNo, docId);
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<BeTrxnDocument> createUpdateDoc(List<Documents> docList, String userId, String docRefNo) {
		List<BeTrxnDocument> beTrxnDocuments = new ArrayList<>();
		for (Documents doc : docList) {
			BeTrxnDocument trxnDocument = docRepositry.findTxnDocByRefNoDocId(docRefNo, doc.getDocid(), doc.getId());
			if (BaseUtil.isObjNull(trxnDocument)) {
				trxnDocument = new BeTrxnDocument();
				trxnDocument.setId(new BeTrxnDocumentPK(docRefNo, doc.getDocid(), doc.getId()));
				trxnDocument.setCreateId(userId);
			}
			trxnDocument.setDocContentType(doc.getContentType());
			trxnDocument.setUpdateId(userId);
			beTrxnDocuments.add(trxnDocument);
		}

		return docRepositry.save(beTrxnDocuments);
	}

}
