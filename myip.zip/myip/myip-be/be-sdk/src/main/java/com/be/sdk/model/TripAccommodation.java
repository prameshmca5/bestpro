/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;

/**
 * @author michelle.angela
 *
 */
public class TripAccommodation implements Serializable {

	private static final long serialVersionUID = 3676698138533107455L;

	private Integer tripAccommodationId;
	
	private Trip tvlTrip;
	
	private Metadata typeMtdt;
	
	private String place;
	
	private String addr1;

	private String addr2;

	private String addr3;

	private String addr4;
	
//	private City city;
//
//	private State state;
	
	private String city;
	
	private String state;
	
	private Country country;
	
	private String zipcode;

	public Integer getTripAccommodationId() {
		return tripAccommodationId;
	}

	public void setTripAccommodationId(Integer tripAccommodationId) {
		this.tripAccommodationId = tripAccommodationId;
	}

	public Trip getTvlTrip() {
		return tvlTrip;
	}

	public void setTvlTrip(Trip tvlTrip) {
		this.tvlTrip = tvlTrip;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1.toUpperCase();
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2.toUpperCase();
	}

	public String getAddr3() {
		return addr3;
	}

	public void setAddr3(String addr3) {
		this.addr3 = addr3.toUpperCase();
	}

	public String getAddr4() {
		return addr4;
	}

	public void setAddr4(String addr4) {
		this.addr4 = addr4.toUpperCase();
	}

//	public City getCity() {
//		return city;
//	}
//
//	public void setCity(City city) {
//		this.city = city;
//	}
//
//	public State getState() {
//		return state;
//	}
//
//	public void setState(State state) {
//		this.state = state;
//	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public Metadata getTypeMtdt() {
		return typeMtdt;
	}

	public void setTypeMtdt(Metadata typeMtdt) {
		this.typeMtdt = typeMtdt;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place.toUpperCase();
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city.toUpperCase();
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state.toUpperCase();
	}
	
}
