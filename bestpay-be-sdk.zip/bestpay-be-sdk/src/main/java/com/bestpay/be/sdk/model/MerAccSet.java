/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;


/**
 * @author Atiqah
 * @since June 7, 2018
 */
public class MerAccSet implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1864073233598003483L;

	private String merchantId;

	private Integer bankId;

	private String accountName;

	private String accountNum;

	private Double settlementFee;

	private Double minSettleAmt;

	private Double transactionRate;

	private Double transactionFee;

	private String gstCc;

	private String accBalance;

	private String accType;

	private String icType;

	private String icNumber;

	private String userId;

	private String bankName;

	private String psa;
	
	private Integer pdpa;


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public Integer getBankId() {
		return bankId;
	}


	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}


	public String getAccountName() {
		return accountName;
	}


	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public String getAccountNum() {
		return accountNum;
	}


	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}


	public Double getSettlementFee() {
		return settlementFee;
	}


	public void setSettlementFee(Double settlementFee) {
		this.settlementFee = settlementFee;
	}


	public Double getMinSettleAmt() {
		return minSettleAmt;
	}


	public void setMinSettleAmt(Double minSettleAmt) {
		this.minSettleAmt = minSettleAmt;
	}


	public Double getTransactionRate() {
		return transactionRate;
	}


	public void setTransactionRate(Double transactionRate) {
		this.transactionRate = transactionRate;
	}


	public Double getTransactionFee() {
		return transactionFee;
	}


	public void setTransactionFee(Double transactionFee) {
		this.transactionFee = transactionFee;
	}


	public String getGstCc() {
		return gstCc;
	}


	public void setGstCc(String gstCc) {
		this.gstCc = gstCc;
	}


	public String getAccBalance() {
		return accBalance;
	}


	public void setAccBalance(String accBalance) {
		this.accBalance = accBalance;
	}


	public String getAccType() {
		return accType;
	}


	public void setAccType(String accType) {
		this.accType = accType;
	}


	public String getIcType() {
		return icType;
	}


	public void setIcType(String icType) {
		this.icType = icType;
	}


	public String getIcNumber() {
		return icNumber;
	}


	public void setIcNumber(String icNumber) {
		this.icNumber = icNumber;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getPsa() {
		return psa;
	}


	public void setPsa(String psa) {
		this.psa = psa;
	}


	public Integer getPdpa() {
		return pdpa;
	}


	public void setPdpa(Integer pdpa) {
		this.pdpa = pdpa;
	}
	
}