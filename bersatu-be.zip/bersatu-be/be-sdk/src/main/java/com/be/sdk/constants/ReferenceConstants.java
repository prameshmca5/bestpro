/**
 * Copyright 2019. Universal Recruitment Platform
 */
package com.be.sdk.constants;


/**
 * @author mary.jane
 *
 */
public class ReferenceConstants {

	private ReferenceConstants() {
		throw new IllegalStateException(ReferenceConstants.class.getName());
	}


	private static final String CREATE = "/create";

	private static final String UPDATE = "/update";

	private static final String SEARCH = "/search";

	public static final String REF_TYP_CITY = "/cities";

	public static final String CREATE_CITY = REF_TYP_CITY + CREATE;

	public static final String UPDATE_CITY = REF_TYP_CITY + UPDATE;

	public static final String SEARCH_CITY = REF_TYP_CITY + SEARCH;

	public static final String REF_TYP_STATE = "/states";

	public static final String CREATE_STATE = REF_TYP_STATE + CREATE;

	public static final String UPDATE_STATE = REF_TYP_STATE + UPDATE;

	public static final String SEARCH_STATE = REF_TYP_STATE + SEARCH;
	
	public static final String REF_TYP_STATE_NORMAL = "/state_normal";
	
	public static final String REF_TYP_STATE_MEMBERS = "/state_members";

	public static final String REF_TYP_COUNTRY = "/countries";

	public static final String CREATE_COUNTRY = REF_TYP_COUNTRY + CREATE;

	public static final String UPDATE_COUNTRY = REF_TYP_COUNTRY + UPDATE;

	public static final String SEARCH_COUNTRY = REF_TYP_COUNTRY + SEARCH;

	public static final String REF_TYP_DOCUMENT = "documents";

	public static final String CREATE_DOCUMENT = REF_TYP_DOCUMENT + CREATE;

	public static final String UPDATE_DOCUMENT = REF_TYP_DOCUMENT + UPDATE;

	public static final String REF_TYP_METADATA = "metadata";

	public static final String CREATE_METADATA = REF_TYP_METADATA + CREATE;

	public static final String UPDATE_METADATA = REF_TYP_METADATA + UPDATE;

	public static final String REF_TYP_REASON = "reasons";

	public static final String CREATE_REASON = REF_TYP_REASON + CREATE;

	public static final String UPDATE_REASON = REF_TYP_REASON + UPDATE;

	public static final String REF_TYP_STATUS = "status";

	public static final String CREATE_STATUS = REF_TYP_STATUS + CREATE;

	public static final String UPDATE_STATUS = REF_TYP_STATUS + UPDATE;

	public static final String REF_PARLIAMENT = "parliament";

	public static final String REF_DUN = "dun";

	public static final String REF_DIVISION = "division";

	public static final String REF_BRANCH = "branch";

	public static final String MTDT_OCCUPATION = "OCCUPATION";

	public static final String MTDT_EDUCATION = "EDUCATION";

	public static final String MTDT_ETHNIC = "ETHNIC";

	public static final String MTDT_RELIGION = "RELIGION";

	public static final String MTDT_GENDER = "GENDER";

	public static final String MTDT_PMT_BRKDWN = "PMT_BRKDWN";

	public static final String MTDT_MBR_TYPE = "MBR_TYPE";

	public static final String MTDT_MBR_CAT = "MBR_CAT";

	public static final String MTDT_CD_BRKDWN_TOT = "BRKDWN_TOT";

	public static final String MTDT_CD_BRKDWN_DTL = "BRKDWN_DTL";

	public static final String MTDT_VOTER_REG = "VOTER_REG";

	public static final String MTDT_CD_VOTE_N = "VOTE_N";

	public static final String MTDT_CD_VOTE_NS = "VOTE_NS";

	public static final String REF_PMT_GATEWAY_RESP = "pmtGatewayResp";

	public static final String MTDT_PMT_TYPE = "PMT_TYPE";

	public static final String MTDT_CD_PMT_CC = "PMT_CC";

	public static final String MTDT_REG_CHANNEL = "REG_CHANNEL";

	public static final String MTDT_CD_MOB_SELF = "MOB_SELF";

	public static final String MTDT_ADDR_TYPE = "ADDR_TYPE";

	public static final String MTDT_CD_PRES = "PRES";

	public static final String MTDT_CD_WEB_CNTR = "WEB_CNTR";

	public static final String MTDT_CD_EXIST_Y = "EXIST_Y";

	public static final String STATUS_TYPE_REG_STATUS = "REG_STATUS";

	public static final String REG_STATUS_REJ = "REJ";

	public static final String REF_TYP_POSITION = "position";

	public static final String HQ = "HQ";

	public static final String STATE = "STATE";

	public static final String DIV = "DIV";

	public static final String MTDT_CD_MUSLIM = "MUS";

	public static final String MTDT_CD_NONBUMI = "NONBUMI";

	public static final String MTDT_CD_CAT_NRML = "CAT_NRML";

	public static final String MTDT_CD_CAT_ALLY = "CAT_ALLY";

	public static final String REG_STATUS_PEND = "PEND";

	public static final String REG_STATUS_FAILED = "FAILED";

	public static final String PRE_REG_PUBLIC = "PUBLIC";
	
	public static final String CONFIG_PMT_BATCH_ID = "PAYMENT_BATCH_ID";
}