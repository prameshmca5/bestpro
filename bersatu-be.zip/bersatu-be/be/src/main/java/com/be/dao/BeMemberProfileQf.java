/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeMemberProfile;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.MemberProfile;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;


/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_MEMBER_PROFILE_QF)
public class BeMemberProfileQf extends QueryFactory<BeMemberProfile> {

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BeMemberProfile> searchByProperty(BeMemberProfile t) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<BeMemberProfile> searchAllByProperty(BeMemberProfile t) {
		CriteriaQuery<BeMemberProfile> cq = cb.createQuery(BeMemberProfile.class);
		Root<BeMemberProfile> root = cq.from(BeMemberProfile.class);
		List<Predicate> predicates = generateCriteria(cb, root, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public Long getCount(MemberProfile dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeMemberProfile> root = cq.from(BeMemberProfile.class);
		predicates.addAll(generateCriteria(cb, root, dto));

		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}


	public List<BeMemberProfile> searchAllByProperty(MemberProfile dto, DataTableRequest<?> dataTableInRQ) {

		List<BeMemberProfile> result = new ArrayList<>();
		CriteriaQuery<BeMemberProfile> cq = cb.createQuery(BeMemberProfile.class);
		List<Predicate> predicates = new ArrayList<>();
		if (cq != null) {
			Root<BeMemberProfile> root = cq.from(BeMemberProfile.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					List<Order> orders = getOrderByClause(cb, root, pagination);
					if (BaseUtil.isListNull(orders)) {
						orders.add(cb.desc(root.get("createDt")));
					}
					cq.orderBy(orders);
				}
			}

			TypedQuery<BeMemberProfile> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}
 
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			MemberProfile dto = JsonUtil.transferToObject(criteria, MemberProfile.class);
			if (!BaseUtil.isObjNull(dto.getMemberId())) {
				predicates.add(cb.equal(from.get("memberId"), dto.getMemberId()));
			}

			if (!BaseUtil.isObjNull(dto.getTxnId())) {
				predicates.add(cb.equal(from.get("txnId"), dto.getTxnId()));
			} else if (!BaseUtil.isListNull(dto.getTxnIdList())) {
				predicates.add(from.get("txnId").in(dto.getTxnIdList()));
			}

			if (!BaseUtil.isObjNull(dto.getMemberRefNo())) {
				predicates.add(cb.equal(from.get("memberRefNo"), dto.getMemberRefNo()));
			}

			if (!BaseUtil.isObjNull(dto.getIdNo())) {
				predicates.add(cb.equal(from.get("idNo"), dto.getIdNo()));
			}

			if (!BaseUtil.isObjNull(dto.getFullName())) {
				predicates.add(cb.like(from.get("fullName"), "%" + dto.getFullName() + "%"));
			}

			if (!BaseUtil.isObjNull(dto.getIdNo())) {
				predicates.add(cb.equal(from.get("idNo"), dto.getIdNo()));
			}

			if (!BaseUtil.isObjNull(dto.getStatusId())) {
				if (dto.isNotIn()) {
					predicates.add(cb.notEqual(from.get("statusId"), dto.getStatusId()));
				} else {
					predicates.add(cb.equal(from.get("statusId"), dto.getStatusId()));
				}

			}

			if (!BaseUtil.isObjNull(dto.getOrgStateCd())) {
				predicates.add(cb.equal(from.get("orgStateCd"), dto.getOrgStateCd()));
			}

			if (!BaseUtil.isObjNull(dto.getOrgDivisionCd())) {
				predicates.add(cb.equal(from.get("orgDivisionCd"), dto.getOrgDivisionCd()));
			}

			if (!BaseUtil.isObjNull(dto.getOrgBranchCd())) {
				predicates.add(cb.equal(from.get("orgBranchCd"), dto.getOrgBranchCd()));
			}
			
			if(!BaseUtil.isObjNull(dto.getSprStateCd())) {
				predicates.add(cb.equal(from.get("sprStateCd"), dto.getSprStateCd()));
			}

			if (!BaseUtil.isObjNull(dto.getParliamentCode())) {
				predicates.add(cb.equal(from.get("parliamentCode"), dto.getParliamentCode()));
			}

			if (!BaseUtil.isObjNull(dto.getDunCode())) {
				predicates.add(cb.equal(from.get("dunCode"), dto.getDunCode()));
			}

			if (!BaseUtil.isObjNull(dto.getMemberCtrgyMtdtId())) {
				predicates.add(cb.equal(from.get("memberCtrgyMtdtId"), dto.getMemberCtrgyMtdtId()));
			}

			if (!BaseUtil.isObjNull(dto.getMemberTypeMtdtId())) {
				predicates.add(cb.equal(from.get("memberTypeMtdtId"), dto.getMemberTypeMtdtId()));
			}

			if (!BaseUtil.isObjNull(dto.getVoterRegMtdtId())) {
				predicates.add(cb.equal(from.get("voterRegMtdtId"), dto.getVoterRegMtdtId()));
			}

			if (!BaseUtil.isObjNull(dto.getRegExistMtdtId())) {
				predicates.add(cb.equal(from.get("regExistMtdtId"), dto.getRegExistMtdtId()));
			}

			if (!BaseUtil.isObjNull(dto.getVoterRegMtdtIdList())) {
				predicates.add(from.get("voterRegMtdtId").in(dto.getVoterRegMtdtIdList()));
			}

			if (!BaseUtil.isObjNull(dto.getStatusIdList())) {
				predicates.add(from.get("statusId").in(dto.getStatusIdList()));
			}

			if (!BaseUtil.isObjNull(dto.getCredentialInd())) {
				if (dto.isNotInCredentialInd()) {
					predicates.add(from.get("credentialInd").in(dto.getCredentialInd()).not());
				} else {
					predicates.add(from.get("credentialInd").in(dto.getCredentialInd()));
				}
			}

			if (!BaseUtil.isObjNull(dto.getPositionId())) {
				predicates.add(cb.equal(from.get("positionId"), dto.getPositionId()));
			}

			if (!BaseUtil.isObjNull(dto.getApplyBy())) {
				predicates.add(cb.equal(from.get("applyBy"), dto.getApplyBy()));
			}

			if (!BaseUtil.isObjNull(dto.getApplyDtFrom())) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(dto.getApplyDtFrom());
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				Date srcDt = cal.getTime();
				predicates.add(cb.greaterThanOrEqualTo(from.get("applyDt"), srcDt));
			}

			if (!BaseUtil.isObjNull(dto.getApplyDtTo())) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(dto.getApplyDtTo());
				cal.set(Calendar.HOUR_OF_DAY, 23);
				cal.set(Calendar.MINUTE, 59);
				cal.set(Calendar.SECOND, 59);
				Date srcDt = cal.getTime();
				predicates.add(cb.lessThanOrEqualTo(from.get("applyDt"), srcDt));
			}

			if (!BaseUtil.isObjNull(dto.getDobTo())) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(dto.getDobTo());
				cal.set(Calendar.HOUR_OF_DAY, 23);
				cal.set(Calendar.MINUTE, 59);
				cal.set(Calendar.SECOND, 59);
				Date srcDt = cal.getTime();
				predicates.add(cb.lessThanOrEqualTo(from.get("dob"), srcDt));
			}

			if (!BaseUtil.isObjNull(dto.getPreRegId())) {
				predicates.add(cb.equal(from.get("preRegId"), dto.getPreRegId()));
			}

			if (!BaseUtil.isObjNull(dto.getEndtStatusId())) {
				predicates.add(cb.equal(from.get("endtStatusId"), dto.getEndtStatusId()));
			}

		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void joinFetch(From<?, ?> from, List<Predicate> predicates, MemberProfile dto,
			CriteriaQuery<BeMemberProfile> cq) {
		from.fetch("status", JoinType.LEFT);

	}

}
