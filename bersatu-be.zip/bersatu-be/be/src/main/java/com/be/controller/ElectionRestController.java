package com.be.controller;


import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.constants.ConfigConstants;
import com.be.core.AbstractRestController;
import com.be.model.BeConfig;
import com.be.model.BeElectionNot;
import com.be.model.BeElectionNotDtl;
import com.be.model.RefMetadata;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.constants.ReferenceConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.ElectionNot;
import com.be.sdk.model.ElectionNotDtl;
import com.be.sdk.model.MemberProfile;
import com.be.service.BeConfigService;
import com.be.service.BeElectionNotDtlService;
import com.be.service.BeElectionNotService;
import com.be.service.BeMemberProfileService;
import com.be.service.RefMetadataService;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.MediaType;
import com.util.UidGenerator;
import com.util.pagination.DataTableRequest;
import com.util.pagination.DataTableResults;


@RestController
@RequestMapping(BeUrlConstants.ELECTION)
public class ElectionRestController extends AbstractRestController {

	@Autowired
	BeElectionNotService beElectionNotSvc;

	@Autowired
	BeMemberProfileService beMemberProfileSvc;

	@Autowired
	RefMetadataService refMetadataSvc;

	@Autowired
	BeElectionNotDtlService beElectionNotDtlSvc;

	@Autowired
	BeConfigService beConfigSvc;


	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<ElectionNot> searchPaginated(@Valid @RequestBody ElectionNot dto,
			HttpServletRequest request) throws IOException {
		DataTableRequest<ElectionNot> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) beElectionNotSvc.getCount(dto);
		List<ElectionNot> filtered = beElectionNotSvc.searchPagination(dto, dataTableInRQ);
		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.SEARCH)
	public ElectionNot searchElectionNot(@RequestBody ElectionNot dto, HttpServletRequest request) throws IOException {
		// ELECTION_NOT_ID, TXN_ID
		return beElectionNotSvc.search(dto);
	}


	@PostMapping(value = BeUrlConstants.CREATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public ElectionNot createElectionNot(@RequestBody ElectionNot dto, HttpServletRequest request) {
		BeElectionNot beElectionNot = dozerMapper.map(dto, BeElectionNot.class);
		beElectionNot.setTxnId(UidGenerator.getMessageId());

		String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();

		MemberProfile memberProfile = new MemberProfile();
		memberProfile.setOrgStateCd(dto.getApplyOrgStateCd());
		memberProfile.setOrgDivisionCd(dto.getApplyOrgDivisionCd());
		memberProfile.setParliamentCode(dto.getParliamentCode());
		memberProfile.setDunCode(dto.getDunCode());
		memberProfile.setMemberCtrgyMtdtId(dto.getMemberCtrgyMtdtId());

		BeConfig beConfig = beConfigSvc.findByConfigCode(ConfigConstants.ELECTION_MIN_AGE);
		if (BaseUtil.isObjNull(beConfig)) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
		memberProfile.setDobTo(DateUtil.minusYearMonthDaysToDate(BaseUtil.getInt(beConfig.getConfigDesc()), 0, 0));

		List<Integer> voterRegMtdtList = null;
		RefMetadata metadata = new RefMetadata();
		metadata.setMtdtType(ReferenceConstants.MTDT_VOTER_REG);
		List<RefMetadata> metadataList = refMetadataSvc.findMetadataByCriteria(metadata);
		if (!BaseUtil.isListNull(metadataList)) {
			voterRegMtdtList = metadataList.stream()
					.filter(mtdt -> BaseUtil.isEquals(ReferenceConstants.MTDT_CD_VOTE_N, mtdt.getMtdtCd())
							|| BaseUtil.isEquals(ReferenceConstants.MTDT_CD_VOTE_NS, mtdt.getMtdtCd()))
					.map(mtdt -> {
						return mtdt.getMtdtId();
					}).collect(Collectors.toList());
		}
		memberProfile.setVoterRegMtdtIdList(voterRegMtdtList);
		List<MemberProfile> memberProfileList = null;
		try {
			memberProfileList = beMemberProfileSvc.searchPagination(memberProfile, null);
			if (!BaseUtil.isListNull(memberProfileList)) {
				List<BeElectionNotDtl> beElectionNotDtlList = memberProfileList.stream().map(electionDtl -> {
					BeElectionNotDtl beElectionNotDtl = dozerMapper.map(electionDtl, BeElectionNotDtl.class);
					beElectionNotDtl.setMemberId(electionDtl.getMemberId());
					beElectionNotDtl.setOrgDivisionCd(electionDtl.getOrgDivisionCd());
					beElectionNotDtl.setCreateId(userId);
					beElectionNotDtl.setCreateDt(currDt);
					beElectionNotDtl.setUpdateId(userId);
					beElectionNotDtl.setUpdateDt(currDt);

					return beElectionNotDtl;
				}).collect(Collectors.toList());

				if (BaseUtil.isListNull(beElectionNotDtlList)) {
					throw new BeException(BeErrorCodeEnum.E500C001);
				}
				beElectionNot.addBeElectionDtlNotList(beElectionNotDtlList);
				beElectionNot.setTotalMember(beElectionNotDtlList.size());
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BeException(BeErrorCodeEnum.E500C001);
		}

		beElectionNot.setOrgStateCd(dto.getApplyOrgStateCd());
		beElectionNot.setOrgDivisionCd(dto.getApplyOrgDivisionCd());
		beElectionNot.setNotifyInd(0);
		beElectionNot.setApplyBy(userId);
		beElectionNot.setApplyDt(currDt);
		beElectionNot.setCreateId(userId);
		beElectionNot.setCreateDt(currDt);
		beElectionNot.setUpdateId(userId);
		beElectionNot.setUpdateDt(currDt);
		beElectionNot = beElectionNotSvc.create(beElectionNot);
		return dozerMapper.map(beElectionNot, ElectionNot.class);
	}


	@PostMapping(value = BeUrlConstants.DETAIL + BeUrlConstants.SEARCH_PAGINATION, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DataTableResults<ElectionNotDtl> searchElectionNotDtlPaginated(@Valid @RequestBody ElectionNotDtl dto,
			HttpServletRequest request) throws IOException {
		DataTableRequest<ElectionNotDtl> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) beElectionNotDtlSvc.getCount(dto);
		List<ElectionNotDtl> filtered = beElectionNotDtlSvc.searchPagination(dto, dataTableInRQ);
		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.DETAIL + BeUrlConstants.SEARCH_LIST)
	public List<ElectionNotDtl> searchElectionNotDtlList(@RequestBody ElectionNotDtl dto, HttpServletRequest request)
			throws IOException {
		return beElectionNotDtlSvc.searchPagination(dto, null);
	}

}
