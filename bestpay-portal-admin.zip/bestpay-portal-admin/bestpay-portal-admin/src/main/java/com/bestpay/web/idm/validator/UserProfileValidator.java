/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.idm.validator;


import java.util.Date;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.idm.sdk.constants.IdmRoleConstants;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.dto.FileUpload;
import com.bestpay.web.idm.form.IdmUploadProfilePictureForm;
import com.bestpay.web.util.ValidationUtil;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
@Component("userProfileValidator")
public class UserProfileValidator extends AbstractController implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}


	@Override
	public void validate(Object object, Errors errors) {

		if (object instanceof IdmUploadProfilePictureForm) {
			IdmUploadProfilePictureForm up = (IdmUploadProfilePictureForm) object;

			// Validate if fields are empty or a whitespace
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "fullName", MessageConstants.ERROR_FIELDS_FULLNAME);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "email", MessageConstants.ERROR_FIELDS_EMAIL);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "mobPhoneNo", MessageConstants.ERROR_FIELDS_MOBILE);
			if (!BaseUtil.isEquals(up.getUserRoleGroupCode(), IdmRoleConstants.MER_ADMIN)) {
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "gender", MessageConstants.ERROR_FIELDS_GENDER);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "dob", MessageConstants.ERROR_DOB);
			}

			if (up.getDob() != null) {
				Date date = new Date();
				Date date1 = up.getDob();
				long diff = Math.abs(date.getTime() - date1.getTime());
				long diffDays = diff / (24 * 60 * 60 * 1000);
				if (diffDays < 18) {
					ValidationUtil.rejectIfInvalidAgeLessFormat(errors, "dob", MessageConstants.ERROR_AGE);
				}
			}

			if (!BaseUtil.isEqualsCaseIgnore("id", up.getUserId())) {
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "userRoleGroupCode",
						MessageConstants.ERROR_USER_ROLE_GROUP);
			}

			if (!BaseUtil.isObjNull(up.getFileUploads())) {
				for (FileUpload fileUpload : up.getFileUploads()) {
					if (!BaseUtil.isObjNull(fileUpload.getFile()) && fileUpload.getFile().getSize() > 102400) {
						ValidationUtil.rejectIfEmptyOrWhitespace(errors, "docRefNo",
								MessageConstants.ERROR_DOC_SIZE_100KB);
					}
				}
			}
		}

		// Validate email if format is valid
		ValidationUtil.rejectIfInvalidEmailFormat(errors, "email", MessageConstants.ERROR_EMAIL_FORMAT);
		if (!errors.hasErrors()) {
			ValidationUtil.rejectIfLengthIsInvalid(errors, "fullName", MessageConstants.ERROR_LENGTH_NAME, 8);
		}

	}

}