/**
 * Copyright 2018 Bestinet Sdn Bhd
 */
package com.portal.web.idm.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.idm.sdk.model.UserProfile;
import com.portal.constants.MessageConstants;
import com.portal.core.AbstractController;
import com.portal.web.mc.form.MedicalResultForm;
import com.portal.web.util.StaticData;
import com.portal.web.util.ValidationUtil;
import com.util.BaseUtil;


/**
 * @author Amirah Ibrahim
 * @since August 8, 2020
 */
@Component("UpdtAprvMedResValidator")
public class UpdtAprvMedResValidator extends AbstractController implements Validator {

	@Autowired
    StaticData staticData;

	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}

    @Override
    public void validate(Object object, Errors errors) {

        if (object instanceof MedicalResultForm) {
        	MedicalResultForm medicalResultForm = (MedicalResultForm) object;
        	
        	UserProfile currentUser = getCurrentUser();
        	
        	if (BaseUtil.isEquals(currentUser.getUserRoleGroup().getUserGroupCode(), "MC_DOCTOR")) {
        		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "collateDrCd", MessageConstants.ERR_MED_RESULT_REQ);
        	}else {
        		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "collateCd", MessageConstants.ERR_MED_RESULT_REQ);
        	}
        	
        	
        }
    }
}