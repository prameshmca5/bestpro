/**
 *
 */
package com.bestid.be.repo;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidSubscriberUser;


/**
 * @author mukhlis.hamzah
 * @since 1 Mar 2019
 */
@Repository
@RepositoryDefinition(domainClass = BidSubscriberUser.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_SUBSCRIBER_USER_REPOSITORY)
public interface BidSubscriberUserRepository extends GenericRepository<BidSubscriberUser> {

	@Query("select u from BidSubscriberUser u where u.subscrId= :subscrId and u.mobileNo= :mobileNo")
	public BidSubscriberUser findBySubIdNPhoneNo(@Param("subscrId") int subscrId, @Param("mobileNo") String mobileNo);


	@Query("select u from BidSubscriberUser u where u.secUserId= :secUserId and u.mobileNo= :mobileNo")
	public BidSubscriberUser findByProfIdNPhoneNo(@Param("secUserId") int secUserId,
			@Param("mobileNo") String mobileNo);
	
	@Query("select u from BidSubscriberUser u where u.subscrId= :subscrId and u.deviceId= :deviceId and u.secUserId= :secUserId")
	public List<BidSubscriberUser> findBySubscId(@Param("subscrId") int subscrId, @Param("deviceId") int deviceId, @Param("secUserId") int secUserId);
}
