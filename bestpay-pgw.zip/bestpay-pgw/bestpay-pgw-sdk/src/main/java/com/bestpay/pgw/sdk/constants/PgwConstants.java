/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class PgwConstants {

	private PgwConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String SLASH = "/";

	public static final String TRANS_STAT_SUCCESS = "success";

	public static final String TRANS_STAT_PENDING = "pending";

	public static final String TRANS_STAT_FAIL = "fail";

	public static final String TRANS_STAT_INVALID = "invalid";

	public static final String TRANS_STAT_CANCEL = "cancel";

	public static final String MERCHANT_STATUS_ACTIVE = "ACTIVE";

	public static final String PGW_CONFIG_GST = "GST";

	public static final String FPX_SCHEDULAR_TIME_BUFFER = "FPX_SCHEDULAR_TIME";
}