$(document).ready(function() {

	var start = $('input[name="pmtDtFrom"]').val('');
    var end =  $('input[name="pmtDtTo"]').val('');
    function cb(start, end) {
    	
    	if(start) {
    		$('input[name="pmtDtFrom"]').val(start.format('DD/MM/YYYY'));    		
    	}
    	
    	if(end) {
    		$('input[name="pmtDtTo"]').val(end.format('DD/MM/YYYY'));    		
    	}
    }

    $('#createDtRange').daterangepicker({
    	minDate: moment("2020-01-01"),
        startDate: start,
        endDate: end,
        minYear: 2019,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    });

    $('#createDtRange').on('apply.daterangepicker', function(ev, picker) {
    	$('input[name="pmtDtFrom"]').val(picker.startDate.format('DD/MM/YYYY'));   
    	$('input[name="pmtDtTo"]').val(picker.endDate.format('DD/MM/YYYY'));   
    });

    $('#createDtRange').on('cancel.daterangepicker', function(ev, picker) {
    	$('input[name="pmtDtFrom"]').val('');   
    	$('input[name="pmtDtTo"]').val('');   
    });
    
    var oTableUserLst = $('#tblTrvlrLst').DataTable({
		"processing": true,
	    "serverSide": true,
	    'responsive': true,
	    'destroy' : true,

	    'order' : [ [ 1, "desc" ] ],
	    "columns": [
	    		{ "data": null, "orderable" : false },
	    		{ "data": "tvlPayment.pmtDt",// //mcattendance Date
	    			 "render": function (data, type, row) {
	    		            if (data) {
	    		                     var date = new Date(data);
	    		                    var dd = date.getDate();
	    		                    var mm = date.getMonth()+1;
	    		                    var yyyy = date.getFullYear();
	    		                   
	    		                    if (dd<10) {
	    		                        dd = "0"+dd;
	    		                    }
	    		                    if (mm<10) {
	    		                        mm = "0"+mm;
	    		                    }
	    		               
	    		                    return dd+"/"+mm+"/"+yyyy;
	    		                }
	    		            return "-";
	    		        },
  	            },
	    		 { "data": "tvlProfile.acctPassport.passportNo" }, 
	    		 { "data": "tvlProfile.fullName",
	    				"orderable" : true,
						"searchable" : true,
						"render" : function(data, type, row) {
							if (data != null && data != "") {

								return data;

							}

							return "-";
						}
	    		 }, 
	    		 { "data": "tvlProfile.gender",
	  	            	"render": function (data, type, row) { 
	  	            		var gender = "-";
	  	            		if(data) {
	  	            			if(data == 'M') {
	  	            				gender = "Male";
	  	            			} else if(data == 'F') {
	  	            				gender = "Female";
	  	            			} 
	  	            		}
	            			return gender;
	  	            	},
	            	},
	    		 { "data": "tvlProfile.dob",
	            		 "render": function (data, type, row) {
	            	            if (data) {
	            	                     var date = new Date(data);
	            	                    var dd = date.getDate();
	            	                    var mm = date.getMonth()+1;
	            	                    var yyyy = date.getFullYear();
	            	                   
	            	                    if (dd<10) {
	            	                        dd = "0"+dd;
	            	                    }
	            	                    if (mm<10) {
	            	                        mm = "0"+mm;
	            	                    }
	            	               
	            	                    return dd+"/"+mm+"/"+yyyy;
	            	                }
	            	            return "-";
	            	        },		
	    		 },
	    		 { "data": "tvlProfile.acctPassport.nationality.cntryDesc", "searchable" : true, "orderable" : true,
	    			 "render": function (data, type, row) {
	    				if(data != null){
	    					 return data;
	    				 }else{
	    					 return "-";
	    				}
	  	            },
	    		 },
	            { "data": "status", "searchable" : true, "orderable" : true, 
  	            	"render": function (data, type, row) {
	            		return data!=null ? data.statusDesc : "-";
  	            	},
  	            },
	            { "data": null, "searchable" : false, "orderable" : false, 
  	            	"render": function ( data, type, row ) {
  	            		/*var transferCase ='<center><a title="View Profile" class="mr-2" href=' + contextPath + '/refund ><i class="fa fa-exchange fa-lg"></i></a>';*/
  	            		var transferCase = '<center><a title="Update Attendance" class="mr-2" href=' + contextPath + '/mcVerifyAttendance/'+ row.secCdId +'/update ><i class="fa fa-edit fa-lg"></i></a></center>';
  	            		/*transferCase = transferCase + '<center><a title="View Profile" class="mr-2" href=' + contextPath + '/mcVerifyAttendance/'+ row.secCdId +'/update><i class="fa fa-eye fa-lg"></i></a></center>';*/
  	            		return transferCase;
  	            	}
  	            },
	          ],
		"ajax": $.fn.dataTable.pipeline({
			"pages" : 1,
        	"type" : "GET",
            "url": contextPath + "/mcVerifyAttendance/paginated",
            "action": 'xhttp',
            'beforeSend': dtRequestHeader,
            "dataSrc": dtDataSrc,
            "data": function ( data ) {
            	data.pmtDtFrom = $('input[name="pmtDtFrom"]').val();
            	data.pmtDtTo = $('input[name="pmtDtTo"]').val();
            	data.passportNo = $("input#passportNo").val().toUpperCase();
            	data.fullName = $("input#fullName").val().toUpperCase();
            	data.statusCd = $("#statusCd").val();
            	
            },
            "error": function(){  // error handling
            	console.log("error");
            }
      	 }),
      	"initComplete": function(settings, json) {
      		$('input#fullName').unbind();
      		$('input#passportNo').unbind();
      		$('#searchFilter').bind('click', function(e) {
            	portalUtil.showMainLoading(true);
            	oTableUserLst
            	.column(1).search($('input[name="pmtDtFrom"]').val())
                .column(1).search($('input[name="pmtDtTo"]').val())
                .column(2).search($('input#passportNo').val())
            	.column(3).search($('input#fullName').val())
            	.column(4).search($('#statusCd').val())
                oTableUserLst.draw();
            	$(".em-toggle").click();
            });
            $('#searchClear').bind('click', function(e) {
            	$('input[name="pmtDtFrom"]').val("")
            	$('input[name="pmtDtTo"]').val("")
            	$('input#passportNo').val("")
            	$('input#fullName').val("")
            	$('#select2-statusCd-container').text("- Please Select -")
            	$("#statusCd").val("");
            	oTableUserLst.columns().search("").draw();
            	$(".em-toggle").click();
            });
           
        },
		"language" : {
			"emptyTable" : prop.dtbEmptyTable
		},
      	
      	"fnDrawCallback": function ( oSettings ) { processRowNum(oSettings); hidePagination(this,"#tblTrvlrLst");portalUtil.showMainLoading(false);} 
	});
});

