/** asynchronous call to retrieve service */
