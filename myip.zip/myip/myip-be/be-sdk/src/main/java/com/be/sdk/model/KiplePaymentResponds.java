/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author Ramesh Pongiannan
 *
 */
@JsonInclude(Include.NON_NULL)
public class KiplePaymentResponds implements Serializable {

	private static final long serialVersionUID = -387508328244978583L;

	private String ord_date;
	private double ord_totalamt;
	private double ord_gstamt;
	private String ord_shipname;
	private String ord_shipcountry;
	private String ord_mercref;
	private String ord_telephone;
	private String ord_email;
	private String ord_delcharges;
	private String ord_svccharges;
	private String ord_mercID;
	private String wcID;
	private String ord_key;
	private String returncode;
	private String payment_code;
	private String payment_type;
	private String ord_customfield1;
	private String ord_customfield2;
	private String ord_customfield3;
	private String displayStatus;
	private String version;
	private String raw_error_description;
	private String source_type;
	private String bank;
	private String bank_reference;
	private String entry_id;
	private String merchant_hashvalue;
	
	
	public String getOrd_date() {
		return ord_date;
	}
	public void setOrd_date(String ord_date) {
		this.ord_date = ord_date;
	}
	public double getOrd_totalamt() {
		return ord_totalamt;
	}
	public void setOrd_totalamt(double ord_totalamt) {
		this.ord_totalamt = ord_totalamt;
	}
	public double getOrd_gstamt() {
		return ord_gstamt;
	}
	public void setOrd_gstamt(double ord_gstamt) {
		this.ord_gstamt = ord_gstamt;
	}
	public String getOrd_shipname() {
		return ord_shipname;
	}
	public void setOrd_shipname(String ord_shipname) {
		this.ord_shipname = ord_shipname;
	}
	public String getOrd_shipcountry() {
		return ord_shipcountry;
	}
	public void setOrd_shipcountry(String ord_shipcountry) {
		this.ord_shipcountry = ord_shipcountry;
	}
	public String getOrd_mercref() {
		return ord_mercref;
	}
	public void setOrd_mercref(String ord_mercref) {
		this.ord_mercref = ord_mercref;
	}
	public String getOrd_telephone() {
		return ord_telephone;
	}
	public void setOrd_telephone(String ord_telephone) {
		this.ord_telephone = ord_telephone;
	}
	public String getOrd_email() {
		return ord_email;
	}
	public void setOrd_email(String ord_email) {
		this.ord_email = ord_email;
	}
	public String getOrd_delcharges() {
		return ord_delcharges;
	}
	public void setOrd_delcharges(String ord_delcharges) {
		this.ord_delcharges = ord_delcharges;
	}
	public String getOrd_svccharges() {
		return ord_svccharges;
	}
	public void setOrd_svccharges(String ord_svccharges) {
		this.ord_svccharges = ord_svccharges;
	}
	public String getOrd_mercID() {
		return ord_mercID;
	}
	public void setOrd_mercID(String ord_mercID) {
		this.ord_mercID = ord_mercID;
	}
	public String getWcID() {
		return wcID;
	}
	public void setWcID(String wcID) {
		this.wcID = wcID;
	}
	public String getOrd_key() {
		return ord_key;
	}
	public void setOrd_key(String ord_key) {
		this.ord_key = ord_key;
	}
	public String getReturncode() {
		return returncode;
	}
	public void setReturncode(String payment_code) {
		this.returncode = payment_code;
	}
	public String getPayment_code() {
		return payment_code;
	}
	public void setPayment_code(String payment_code) {
		this.payment_code = payment_code;
	}
	public String getOrd_customfield1() {
		return ord_customfield1;
	}
	public void setOrd_customfield1(String ord_customfield1) {
		this.ord_customfield1 = ord_customfield1;
	}
	public String getDisplayStatus() {
		return displayStatus;
	}
	public void setDisplayStatus(String displayStatus) {
		this.displayStatus = displayStatus;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getPayment_type() {
		return payment_type;
	}
	public void setPayment_type(String payment_type) {
		this.payment_type = payment_type;
	}
	public String getRaw_error_description() {
		return raw_error_description;
	}
	public void setRaw_error_description(String raw_error_description) {
		this.raw_error_description = raw_error_description;
	}
	public String getSource_type() {
		return source_type;
	}
	public void setSource_type(String source_type) {
		this.source_type = source_type;
	}
	public String getBank() {
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public String getBank_reference() {
		return bank_reference;
	}
	public void setBank_reference(String bank_reference) {
		this.bank_reference = bank_reference;
	}
	public String getEntry_id() {
		return entry_id;
	}
	public void setEntry_id(String entry_id) {
		this.entry_id = entry_id;
	}
	public String getMerchant_hashvalue() {
		return merchant_hashvalue;
	}
	public void setMerchant_hashvalue(String merchant_hashvalue) {
		this.merchant_hashvalue = merchant_hashvalue;
	}
	public String getOrd_customfield2() {
		return ord_customfield2;
	}
	public void setOrd_customfield2(String ord_customfield2) {
		this.ord_customfield2 = ord_customfield2;
	}
	public String getOrd_customfield3() {
		return ord_customfield3;
	}
	public void setOrd_customfield3(String ord_customfield3) {
		this.ord_customfield3 = ord_customfield3;
	}
	
	
}
