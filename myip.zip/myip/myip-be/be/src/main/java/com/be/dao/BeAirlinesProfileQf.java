/**
 * 
 */
package com.be.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeAirlinesAddress;
import com.be.model.BeAirlinesContact;
import com.be.model.BeAirlinesPic;
import com.be.model.BeAirlinesProfile;
import com.be.model.BeMcProfile;
import com.be.model.RefMetadata;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.AirlinesProfile;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Metadata;
import com.be.service.RefMetadataService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;

/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_AIRLINES_PROFILE_QF)
public class BeAirlinesProfileQf extends QueryFactory<BeAirlinesProfile> {

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;
	
	@Autowired
	RefMetadataService refMetadataSvc;
	
	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}
	
	@Override
	public Specification<BeAirlinesProfile> searchByProperty(BeAirlinesProfile t) {
		return (Root<BeAirlinesProfile> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}

	@Override
	public List<BeAirlinesProfile> searchAllByProperty(BeAirlinesProfile t) {
		CriteriaQuery<BeAirlinesProfile> cq = cb.createQuery(BeAirlinesProfile.class);
		Root<BeAirlinesProfile> from = cq.from(BeAirlinesProfile.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}

	public BeAirlinesProfile searchBeAirlinesProfile(AirlinesProfile dto) {

		BeAirlinesProfile result = null;
		CriteriaQuery<BeAirlinesProfile> cq = cb.createQuery(BeAirlinesProfile.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeAirlinesProfile> root = cq.from(BeAirlinesProfile.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeAirlinesProfile> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}
	
	public List<BeAirlinesProfile> searchBeAirlinesProfilePagination(AirlinesProfile dto, DataTableRequest<?> dataTableInRQ) {

		List<BeAirlinesProfile> result = new ArrayList<>();
		CriteriaQuery<BeAirlinesProfile> cq = cb.createQuery(BeAirlinesProfile.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeAirlinesProfile> root = cq.from(BeAirlinesProfile.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					cq.orderBy(getOrderByClause(cb, root, pagination));
				}
			}

			TypedQuery<BeAirlinesProfile> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}
	
	public Long getCount(AirlinesProfile dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeAirlinesProfile> root = cq.from(BeAirlinesProfile.class);
		predicates.addAll(generateCriteria(cb, root, dto));
		
		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}
	
	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			AirlinesProfile dto = JsonUtil.transferToObject(criteria, AirlinesProfile.class);
			if (!BaseUtil.isObjNull(dto.getAirlinesProfId())) {
				predicates.add(cb.equal(from.get("airlinesProfId"), dto.getAirlinesProfId()));
			}

			if (!BaseUtil.isObjNull(dto.getAirlinesName())) {
				predicates.add(cb.like(from.get("airlinesName"), "%" + dto.getAirlinesName() + "%"));
			}
			
			if (!BaseUtil.isObjNull(dto.getIataRegNo())) {
				predicates.add(cb.like(from.get("iataRegNo"), "%" + dto.getIataRegNo() + "%"));
			}
			
			if (!BaseUtil.isObjNull(dto.getIcaoRegNo())) {
				predicates.add(cb.like(from.get("icaoRegNo"), "%" + dto.getIcaoRegNo() + "%"));
			}
			
			if (!BaseUtil.isObjNull(dto.getEmail())) {
				predicates.add(cb.equal(from.get("email"), dto.getEmail()));
			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void joinFetch(From<?, ?> from, List<Predicate> predicates, AirlinesProfile dto, CriteriaQuery<BeAirlinesProfile> cq) {
		
		Join<BeAirlinesProfile, RefMetadata> orgTypeMtdt = (Join) from.fetch("airlinesTypeMtdt", JoinType.LEFT);
		if(!BaseUtil.isObjNull(dto.getAirlinesTypeMtdt())) {
			Metadata relationMtdtDto = new Metadata();
			relationMtdtDto.setMtdtCd(dto.getAirlinesTypeMtdt().getMtdtCd());
			predicates.addAll(refMetadataSvc.generateCriteria(cb, orgTypeMtdt, relationMtdtDto));
		}
		from.fetch("flightCoverageMtdt", JoinType.LEFT);
		
		if(dto.isEmbedContacts()) {
			Join<BeAirlinesProfile, BeAirlinesContact> airlinesContacts =(Join)from.fetch("airlinesContacts", JoinType.LEFT);
			airlinesContacts.fetch("titleTypeMtdt",JoinType.LEFT);
		}
		
		if(dto.isEmbedPICs()) {
			Join<BeAirlinesProfile, BeAirlinesPic> picContacts =(Join)from.fetch("airlinesPics", JoinType.LEFT);
			picContacts.fetch("titleTypeMtdt",JoinType.LEFT);
		}
		
		if(dto.isEmbedAddresses()) {
			Join<BeAirlinesProfile, BeAirlinesAddress> airlinesAddresses =(Join) from.fetch("airlinesAddresses", JoinType.LEFT);
			airlinesAddresses.fetch("country", JoinType.LEFT);
		}
	}

	public List<BeAirlinesProfile> searchExistByProperty(BeAirlinesProfile t) {
		CriteriaQuery<BeAirlinesProfile> cq = cb.createQuery(BeAirlinesProfile.class);
		Root<BeAirlinesProfile> from = cq.from(BeAirlinesProfile.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.having(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}
}
