package com.bestpay.be.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwMerchantProvider;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since March 28, 2019
 */

@Repository
@RepositoryDefinition(domainClass = PgwMerchantProvider.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MER_PROVIDER_DAO)
public interface PgwMerchantProviderRepository extends GenericRepository<PgwMerchantProvider> {

	@Query("select u from PgwMerchantProvider u where u.providerId = :providerId ")
	PgwMerchantProvider findByProviderId(@Param("providerId") int providerId);


	@Query("select u from PgwMerchantProvider u where u.providerPublicName = :channel ")
	PgwMerchantProvider findProviderByChannel(@Param("channel") String channel);


	@Query("select count(u) from PgwMerchantProvider u ")
	int totalRecords();


	@Query("select u from PgwMerchantProvider u ")
	List<PgwMerchantProvider> findProviderByAllDetails();


	@Query("select u from PgwMerchantProvider u where u.ssmId = :ssmId")
	List<PgwMerchantProvider> findByProviderSsmId(@Param("ssmId") String ssmId);


	@Query("select u from PgwMerchantProvider u where u.providerPublicName = :providerPublicName")
	List<PgwMerchantProvider> findByProviderPublicName(@Param("providerPublicName") String providerPublicName);

}