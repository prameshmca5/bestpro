package com.bestpay.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwRestriction;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */

@Repository
@RepositoryDefinition(domainClass = PgwRestriction.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_RESTRICTION_DAO)
public interface PgwRestrictionRepository extends GenericRepository<PgwRestriction> {

	@Query("select u from PgwRestriction u ")
	public PgwRestriction findAllRestriction();


	@Query("select u from PgwRestriction u where u.restrictId = :restrictId ")
	public PgwRestriction findByRestrictionId(@Param("restrictId") int restrict);


	@Query("select u from PgwRestriction u where u.merchantId = :merchantId ")
	public PgwRestriction findRestrictionByMerchantId(@Param("merchantId") String merchantId);


	@Query("select count(u) from PgwRestriction u ")
	public int totalRecords();

}