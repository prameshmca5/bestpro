package com.portal.web.mc.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.be.sdk.constants.FileUploadConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.MedicalCenter;
import com.portal.constants.PageConstants;
import com.portal.constants.PageTemplate;
import com.portal.core.AbstractController;
import com.util.model.RefDocuments;

@Controller
@RequestMapping(value = PageConstants.PAGE_MC_REGISTER)
public class MedicalCenterController extends AbstractController {
	
	
	@GetMapping
	public ModelAndView view(MedicalCenter medicalCenter, BindingResult result) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.MEDICAL_CENTER, "mc", null, null);
		mav.addObject("medicalcenter", medicalCenter);
		mav.addObject("refDocLst", getRefDocLst());
		return mav;
	}
	
	@ModelAttribute("refDocLst")
	public List<RefDocuments> getRefDocLst() {
		return staticData.refDocList("TEST");
	}
}
