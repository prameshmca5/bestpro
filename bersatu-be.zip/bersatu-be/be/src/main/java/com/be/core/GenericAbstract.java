/**
 * Copyright 2019
 */
package com.be.core;


import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.util.StringUtils;

import com.be.sdk.client.BeServiceClient;
import com.dm.sdk.client.DmServiceClient;
import com.idm.sdk.client.IdmServiceClient;
import com.notify.sdk.client.NotServiceClient;
import com.report.sdk.client.ReportServiceClient;
import com.util.constants.BaseConstants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public abstract class GenericAbstract {

	@Autowired
	protected MessageSource messageSource;

	@Autowired
	private IdmServiceClient idmService;

	@Autowired
	private NotServiceClient notifyService;

	@Autowired
	private DmServiceClient dmService;

	@Autowired
	private BeServiceClient beServiceClient;

	@Autowired
	private ReportServiceClient reportService;


	protected IdmServiceClient getIdmService(HttpServletRequest request) {
		idmService.setAuthToken(request.getHeader(BaseConstants.HEADER_AUTHORIZATION));
		idmService.setMessageId(StringUtils.hasText(request.getHeader(BaseConstants.HEADER_MESSAGE_ID))
				? request.getHeader(BaseConstants.HEADER_MESSAGE_ID)
				: String.valueOf(UUID.randomUUID()));
		return idmService;
	}


	public NotServiceClient getNotifyService(HttpServletRequest request) {
		notifyService.setAuthToken(request.getHeader(BaseConstants.HEADER_AUTHORIZATION));
		notifyService.setMessageId(StringUtils.hasText(request.getHeader(BaseConstants.HEADER_MESSAGE_ID))
				? request.getHeader(BaseConstants.HEADER_MESSAGE_ID)
				: String.valueOf(UUID.randomUUID()));
		return notifyService;
	}


	public DmServiceClient getDmService(HttpServletRequest request) {
		dmService.setAuthToken(request.getHeader(BaseConstants.HEADER_AUTHORIZATION));
		dmService.setMessageId(StringUtils.hasText(request.getHeader(BaseConstants.HEADER_MESSAGE_ID))
				? request.getHeader(BaseConstants.HEADER_MESSAGE_ID)
				: String.valueOf(UUID.randomUUID()));
		return dmService;
	}


	public DmServiceClient getDmService(HttpServletRequest request, String projId) {
		if (projId != null) {
			dmService.setProjId(projId);
		}
		dmService.setAuthToken(request.getHeader(BaseConstants.HEADER_AUTHORIZATION));
		dmService.setMessageId(StringUtils.hasText(request.getHeader(BaseConstants.HEADER_MESSAGE_ID))
				? request.getHeader(BaseConstants.HEADER_MESSAGE_ID)
				: String.valueOf(UUID.randomUUID()));
		return dmService;
	}


	public BeServiceClient getBeServiceClient(HttpServletRequest request) {
		beServiceClient.setAuthToken(request.getHeader(BaseConstants.HEADER_AUTHORIZATION));
		beServiceClient.setMessageId(StringUtils.hasText(request.getHeader(BaseConstants.HEADER_MESSAGE_ID))
				? request.getHeader(BaseConstants.HEADER_MESSAGE_ID)
				: String.valueOf(UUID.randomUUID()));
		return beServiceClient;
	}


	protected String getCurrUserId(HttpServletRequest request) {
		return String.valueOf(request.getAttribute("currUserId"));
	}


	public ReportServiceClient getReportService(HttpServletRequest request) {
		reportService.setAuthToken(request.getHeader(BaseConstants.HEADER_AUTHORIZATION));
		reportService.setMessageId(StringUtils.hasText(request.getHeader(BaseConstants.HEADER_MESSAGE_ID))
				? request.getHeader(BaseConstants.HEADER_MESSAGE_ID)
				: String.valueOf(UUID.randomUUID()));
		return reportService;
	}
}