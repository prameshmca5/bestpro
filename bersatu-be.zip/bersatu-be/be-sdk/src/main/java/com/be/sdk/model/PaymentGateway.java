package com.be.sdk.model;


import java.io.Serializable;


public class PaymentGateway implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 6723281272583273849L;

	private Integer pmtGwId;

	private Integer pmtId;

	private String gwRefNo;

	private String returnCd;

	private String pmtCd;

	private String errorDesc;

	private String srcType;

	private String gwResponse;


	public Integer getPmtGwId() {
		return pmtGwId;
	}


	public void setPmtGwId(Integer pmtGwId) {
		this.pmtGwId = pmtGwId;
	}


	public Integer getPmtId() {
		return pmtId;
	}


	public void setPmtId(Integer pmtId) {
		this.pmtId = pmtId;
	}


	/**
	 * @return the gwRefNo
	 */
	public String getGwRefNo() {
		return gwRefNo;
	}


	/**
	 * @param gwRefNo
	 *             the gwRefNo to set
	 */
	public void setGwRefNo(String gwRefNo) {
		this.gwRefNo = gwRefNo;
	}


	/**
	 * @return the returnCd
	 */
	public String getReturnCd() {
		return returnCd;
	}


	/**
	 * @param returnCd
	 *             the returnCd to set
	 */
	public void setReturnCd(String returnCd) {
		this.returnCd = returnCd;
	}


	/**
	 * @return the pmtCd
	 */
	public String getPmtCd() {
		return pmtCd;
	}


	/**
	 * @param pmtCd
	 *             the pmtCd to set
	 */
	public void setPmtCd(String pmtCd) {
		this.pmtCd = pmtCd;
	}


	/**
	 * @return the errorDesc
	 */
	public String getErrorDesc() {
		return errorDesc;
	}


	/**
	 * @param errorDesc
	 *             the errorDesc to set
	 */
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}


	/**
	 * @return the srcType
	 */
	public String getSrcType() {
		return srcType;
	}


	/**
	 * @param srcType
	 *             the srcType to set
	 */
	public void setSrcType(String srcType) {
		this.srcType = srcType;
	}


	public String getGwResponse() {
		return gwResponse;
	}


	public void setGwResponse(String gwResponse) {
		this.gwResponse = gwResponse;
	}

}
