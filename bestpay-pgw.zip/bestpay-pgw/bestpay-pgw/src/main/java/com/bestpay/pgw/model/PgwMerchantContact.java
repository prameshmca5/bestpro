package com.bestpay.pgw.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;


@Entity
@Table(name = "PGW_MERCHANT_CONTACT")
public class PgwMerchantContact extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -9209662119492823348L;

	@Id
	@Column(name = "CNTCT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer cntctId;

	@Column(name = "MERCHANT_ID")
	private String merchantId;

	@Column(name = "NAME")
	private String name;

	@Column(name = "ADDRESS")
	private String address;

	@Column(name = "POSTCODE")
	private String postcode;

	@Column(name = "CITY")
	private String city;

	@Column(name = "STATE")
	private String state;

	@Column(name = "COUNTRY")
	private String country;

	@Column(name = "PHONE")
	private String phone;

	@Column(name = "MPHONE")
	private String mobPhone;

	@Column(name = "FAX")
	private String fax;

	@Column(name = "EMAIL")
	private String email;

	/**
	 * @Column(name = "EMAIL2") private String email2;
	 */

	@Column(name = "EMAIL_MISC")
	private String emailMisc;

	@Column(name = "CC_EMAIL")
	private String emailcc;

	@Column(name = "CC_EMAIL_TO")
	private String emailccTo;

	@Column(name = "CC_PAY_NOTI")
	private String payNoticc;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;


	public Integer getCntctId() {
		return cntctId;
	}


	public void setCntctId(Integer cntctId) {
		this.cntctId = cntctId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getMobPhone() {
		return mobPhone;
	}


	public void setMobPhone(String mobPhone) {
		this.mobPhone = mobPhone;
	}


	public String getFax() {
		return fax;
	}


	public void setFax(String fax) {
		this.fax = fax;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getEmailMisc() {
		return emailMisc;
	}


	public void setEmailMisc(String emailMisc) {
		this.emailMisc = emailMisc;
	}


	public String getEmailcc() {
		return emailcc;
	}


	public void setEmailcc(String emailcc) {
		this.emailcc = emailcc;
	}


	public String getEmailccTo() {
		return emailccTo;
	}


	public void setEmailccTo(String emailccTo) {
		this.emailccTo = emailccTo;
	}


	public String getPayNoticc() {
		return payNoticc;
	}


	public void setPayNoticc(String payNoticc) {
		this.payNoticc = payNoticc;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
