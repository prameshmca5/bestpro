/**
 * 
 */
package com.be.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;

/**
 * @author michelle.angela
 *
 */
 @Entity
 @Table(name = "BE_TVL_INSURANCE")
public class BeTvlInsurance extends AbstractEntity implements Serializable, IQfCriteria<BeTvlInsurance> {
	 
	private static final long serialVersionUID = 6212867363997043104L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="TVL_INS_ID")
	private Integer tvlInsId;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="TVL_PROF_ID")
	private BeTvlProfile tvlProfile;
	 
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="TVL_PMT_DTL_ID")
	private BeTvlPaymentDtl tvlPaymentDtl;

	@Column(name = "COVERAGE_DTL")
	private String coverageDtl;
	
	@Column(name = "INSURANCE_VALIDITY")
	private String insuranceValidity;
	
	@Column(name = "DOC_REF_NO")
	private String docRefNo;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "STATUS_ID")
	private RefStatus status;
	
	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	public Integer getTvlInsId() {
		return tvlInsId;
	}

	public void setTvlInsId(Integer tvlInsId) {
		this.tvlInsId = tvlInsId;
	}

	public BeTvlProfile getTvlProfile() {
		return tvlProfile;
	}

	public void setTvlProfile(BeTvlProfile tvlProfile) {
		this.tvlProfile = tvlProfile;
	}

	public BeTvlPaymentDtl getTvlPaymentDtl() {
		return tvlPaymentDtl;
	}

	public void setTvlPaymentDtl(BeTvlPaymentDtl tvlPaymentDtl) {
		this.tvlPaymentDtl = tvlPaymentDtl;
	}

	public String getCoverageDtl() {
		return coverageDtl;
	}

	public void setCoverageDtl(String coverageDtl) {
		this.coverageDtl = coverageDtl;
	}

	public String getInsuranceValidity() {
		return insuranceValidity;
	}

	public void setInsuranceValidity(String insuranceValidity) {
		this.insuranceValidity = insuranceValidity;
	}

	public String getDocRefNo() {
		return docRefNo;
	}

	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public RefStatus getStatus() {
		return status;
	}

	public void setStatus(RefStatus status) {
		this.status = status;
	}
	
}
