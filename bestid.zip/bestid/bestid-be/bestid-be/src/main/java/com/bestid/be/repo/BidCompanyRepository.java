/**
 *
 */
package com.bestid.be.repo;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidCompany;
import com.bestid.be.model.SecUser;

/**
 * @author suhada
 * @since Feb 22, 2019
 */
@Repository
@RepositoryDefinition(domainClass = SecUser.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_CMPNY_REPOSITORY)
public interface BidCompanyRepository extends GenericRepository<BidCompany> {

	@Query("select u from BidCompany u where u.cmpnyRegNo= :cmpnyRegNo")
	BidCompany findByCmpnyRegNo(@Param("cmpnyRegNo") String cmpnyRegNo);

}
