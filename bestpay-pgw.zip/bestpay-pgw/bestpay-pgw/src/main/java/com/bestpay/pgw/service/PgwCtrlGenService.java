
package com.bestpay.pgw.service;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.PgwCtrlGenRepository;
import com.bestpay.pgw.model.PgwCtrlGen;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.pgw.util.QualifierConstants;
import com.bestpay.pgw.util.WebUtil;


/**
 * @author Chaithanya
 * @since 13/07/2018
 */
@Service(QualifierConstants.PGW_CTRL_GEN_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_CTRL_GEN_SVC)
@Transactional
public class PgwCtrlGenService extends AbstractService<PgwCtrlGen> {

	@Autowired
	private PgwCtrlGenRepository pgwCtrlGenDao;


	@Override
	public GenericRepository<PgwCtrlGen> primaryDao() {
		return pgwCtrlGenDao;
	}


	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public synchronized String generateRefNo() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		PgwCtrlGen pcg = pgwCtrlGenDao.findCtrlGenDt(sdf.format(new Date()));
		if (BaseUtil.isObjNull(pcg)) {
			pcg = new PgwCtrlGen();
			pcg.setCtrlGenDt(sdf.format(new Date()));
			pcg.setTrxnId(1);
		}
		logger.info("GenDt: {} - TrxnCd: {}", pcg.getCtrlGenDt(), pcg.getTrxnId());
		int trxnId = pcg.getTrxnId();
		pcg.setTrxnId(trxnId + 1);
		pgwCtrlGenDao.saveAndFlush(pcg);
		return WebUtil.genChksumNoDate(pcg.getCtrlGenDt(), trxnId);

	}

}