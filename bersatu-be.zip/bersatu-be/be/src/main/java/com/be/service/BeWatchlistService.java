/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.be.service;


import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeWatchlistQf;
import com.be.dao.BeWatchlistRepository;
import com.be.model.BeWatchlist;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Watchlist;


/**
 * @author mohd.naem
 * @since March 31 , 2021
 */
@Service(QualifierConstants.BE_WATCHLIST_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_WATCHLIST_SVC)
@Transactional
public class BeWatchlistService extends AbstractService<BeWatchlist> {

	protected static Logger logger = LoggerFactory.getLogger(BeWatchlistService.class);

	@Autowired
	private BeWatchlistRepository beWatchlistDao;

	@Autowired
	private BeWatchlistQf beWatchlistQf;


	@Override
	public GenericRepository<BeWatchlist> primaryDao() {
		return beWatchlistDao;
	}


	public long getCount(Watchlist dto) {
		return beWatchlistQf.getCount(dto);
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return null;
	}
}