/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;
import com.util.serializer.JsonTimestampDeserializer;
import com.util.serializer.JsonTimestampSerializer;


/**
 * @author michelle.angela
 *
 */
public class Payment implements Serializable, IQfCriteria<Payment> {

	private static final long serialVersionUID = -7196602477579065682L;

	private Integer tvlPmtId;

	private String pmtRefNo;

	private String cbsRefNo;

	private String invRefNo;

	private String rcptRefNo;

	@JsonSerialize(using = JsonTimestampSerializer.class)
	@JsonDeserialize(using = JsonTimestampDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH_TIME_S)
	private Timestamp trxnDt;

	private Channel channel;

	private String currency;

	private double amount;

	private PymntMsgCode statusPymntMsgCode;

	private PymntMsgCode respPymntMsgCode;

	private String pmtBy;

	private Date pmtDt;

	private Metadata pmtMthdMtdt;

	private List<PaymentDtl> beTvlPaymentDtls;

	private List<PaymentInfo> tvlPaymentInfos;

	private Integer statusCd;

	private boolean embedDtls;

	private boolean embedInfo;

	private List<Integer> acctTvlrIdList;

	private List<AcctTraveller> selectedAcctTvlr;

	private AcctProfile acctProfile;

	private String userPayId;

	private String createId;

	private String docRefNo;

	private Status status;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date pmtDtFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date pmtDtTo;

	private Metadata appsMtdt;


	public Integer getTvlPmtId() {
		return tvlPmtId;
	}


	public void setTvlPmtId(Integer tvlPmtId) {
		this.tvlPmtId = tvlPmtId;
	}


	public String getPmtRefNo() {
		return pmtRefNo;
	}


	public void setPmtRefNo(String pmtRefNo) {
		this.pmtRefNo = pmtRefNo;
	}


	public String getCbsRefNo() {
		return cbsRefNo;
	}


	public void setCbsRefNo(String cbsRefNo) {
		this.cbsRefNo = cbsRefNo;
	}


	public String getInvRefNo() {
		return invRefNo;
	}


	public void setInvRefNo(String invRefNo) {
		this.invRefNo = invRefNo;
	}


	public String getRcptRefNo() {
		return rcptRefNo;
	}


	public void setRcptRefNo(String rcptRefNo) {
		this.rcptRefNo = rcptRefNo;
	}


	public Timestamp getTrxnDt() {
		return trxnDt;
	}


	public void setTrxnDt(Timestamp trxnDt) {
		this.trxnDt = trxnDt;
	}


	public Channel getChannel() {
		return channel;
	}


	public void setChannel(Channel channel) {
		this.channel = channel;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public PymntMsgCode getStatusPymntMsgCode() {
		return statusPymntMsgCode;
	}


	public void setStatusPymntMsgCode(PymntMsgCode statusPymntMsgCode) {
		this.statusPymntMsgCode = statusPymntMsgCode;
	}


	public PymntMsgCode getRespPymntMsgCode() {
		return respPymntMsgCode;
	}


	public void setRespPymntMsgCode(PymntMsgCode respPymntMsgCode) {
		this.respPymntMsgCode = respPymntMsgCode;
	}


	public String getPmtBy() {
		return pmtBy;
	}


	public void setPmtBy(String pmtBy) {
		this.pmtBy = pmtBy;
	}


	public Date getPmtDt() {
		return pmtDt;
	}


	public void setPmtDt(Date pmtDt) {
		this.pmtDt = pmtDt;
	}


	public List<PaymentDtl> getBeTvlPaymentDtls() {
		return beTvlPaymentDtls;
	}


	public void setBeTvlPaymentDtls(List<PaymentDtl> beTvlPaymentDtls) {
		this.beTvlPaymentDtls = beTvlPaymentDtls;
	}


	public Metadata getPmtMthdMtdt() {
		return pmtMthdMtdt;
	}


	public void setPmtMthdMtdt(Metadata pmtMthdMtdt) {
		this.pmtMthdMtdt = pmtMthdMtdt;
	}


	public List<PaymentInfo> getTvlPaymentInfos() {
		return tvlPaymentInfos;
	}


	public void setTvlPaymentInfos(List<PaymentInfo> tvlPaymentInfos) {
		this.tvlPaymentInfos = tvlPaymentInfos;
	}


	public Integer getStatusCd() {
		return statusCd;
	}


	public void setStatusCd(Integer statusCd) {
		this.statusCd = statusCd;
	}


	public boolean isEmbedDtls() {
		return embedDtls;
	}


	public void setEmbedDtls(boolean embedDtls) {
		this.embedDtls = embedDtls;
	}


	public boolean isEmbedInfo() {
		return embedInfo;
	}


	public void setEmbedInfo(boolean embedInfo) {
		this.embedInfo = embedInfo;
	}


	public List<Integer> getAcctTvlrIdList() {
		return acctTvlrIdList;
	}


	public void setAcctTvlrIdList(List<Integer> acctTvlrIdList) {
		this.acctTvlrIdList = acctTvlrIdList;
	}


	public List<AcctTraveller> getSelectedAcctTvlr() {
		return selectedAcctTvlr;
	}


	public void setSelectedAcctTvlr(List<AcctTraveller> selectedAcctTvlr) {
		this.selectedAcctTvlr = selectedAcctTvlr;
	}


	public AcctProfile getAcctProfile() {
		return acctProfile;
	}


	public void setAcctProfile(AcctProfile acctProfile) {
		this.acctProfile = acctProfile;
	}


	public String getUserPayId() {
		return userPayId;
	}


	public void setUserPayId(String userPayId) {
		this.userPayId = userPayId;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}


	public Date getPmtDtFrom() {
		return pmtDtFrom;
	}


	public void setPmtDtFrom(Date pmtDtFrom) {
		this.pmtDtFrom = pmtDtFrom;
	}


	public Date getPmtDtTo() {
		return pmtDtTo;
	}


	public void setPmtDtTo(Date pmtDtTo) {
		this.pmtDtTo = pmtDtTo;
	}


	public Metadata getAppsMtdt() {
		return appsMtdt;
	}


	public void setAppsMtdt(Metadata appsMtdt) {
		this.appsMtdt = appsMtdt;
	}

}
