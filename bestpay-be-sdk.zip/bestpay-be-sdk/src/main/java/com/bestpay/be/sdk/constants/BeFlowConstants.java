/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BeFlowConstants {

	private BeFlowConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String PREV_FLOW = "prevFlow";

	public static final String CURR_FLOW = "currFlow";

	public static final String NEXT_FLOW = "nextFlow";

	public static final String FLOW_INTERVIEW = "interview";

	public static final String FLOW_PRE_MEDICAL = "premed";

	public static final String FLOW_PRE_MEDICAL_PAY = "premedpay";

	public static final String FLOW_TRAINING = "training";

	public static final String FLOW_TRAINING_ATTEND = "attendance";

	public static final String FLOW_TRAINING_PAY = "trainpay";

	public static final String FLOW_TRAINING_RESULT = "trainresult";

	public static final String FLOW_BMS = "bms";

	public static final String FLOW_BOOKING_PRE = "prebook";

	public static final String FLOW_BOOKING_POST = "postbook";

	public static final String FLOW_JOB_ORDER = "sector";

	public static final String FLOW_SIP = "sector";

	public static final String FLOW_VDR = "sector";

	public static final String FLOW_VDR_PAY = "sector";

	public static final String FLOW_ARRIVAL = "sector";

	public static final String FLOW_FOMEMA = "sector";

	public static final String FLOW_PLKS = "sector";

	public static final String FLOW_SECTOR = "sector";

	public static final String FLOW_EPF = "epf";

	public static final String FLOW_JCS = "jcs";

	public static final String FLOW_AGENCY = "agency";

	public static final String FLOW_FINANCIAL = "financial";

	public static final String FLOW_WORKER = "worker";

	public static final String FLOW_COMPANY = "company";

	public static final String FLOW_DATAQ = "dataq";

	public static final String FLOW_ASG_INTRVW = "manualInterview";

	public static final String FLOW_KDNV = "quotaVerify";

	public static final String FLOW_REG_AGENCY = "reg-agency";

	public static final String FLOW_JTK = "jtk";

	public static final String FLOW_KDN = "kdn";

	public static final String FLOW_LEVY = "levy";

	public static final String FLOW_SUMMARY = "summary";

	public static final String FLOW_UPDATE_REG = "status-reg";

	public static final String FLOW_QUOTA = "quota";

}