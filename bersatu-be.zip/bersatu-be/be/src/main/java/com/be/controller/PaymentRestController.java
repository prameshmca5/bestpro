package com.be.controller;


import java.io.IOException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.apache.commons.codec.digest.DigestUtils;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.be.constants.ConfigConstants;
import com.be.core.AbstractRestController;
import com.be.dao.BePaymentQf;
import com.be.model.BeConfig;
import com.be.model.BeMemberAddress;
import com.be.model.BeMemberProfile;
import com.be.model.BePayment;
import com.be.model.BePaymentDtl;
import com.be.model.BePaymentGateway;
import com.be.model.BePreReg;
import com.be.model.RefDocument;
import com.be.model.RefMetadata;
import com.be.model.RefStatus;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.constants.MailTemplateConstants;
import com.be.sdk.constants.ReferenceConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.Config;
import com.be.sdk.model.KiplePaymentRequest;
import com.be.sdk.model.MemberProfile;
import com.be.sdk.model.Payment;
import com.be.sdk.model.PaymentBreakdown;
import com.be.sdk.model.PaymentDtl;
import com.be.sdk.model.PreReg;
import com.be.sdk.model.SenangPayResponds;
import com.be.service.BeConfigService;
import com.be.service.BeCtrlGenService;
import com.be.service.BeMemberProfileService;
import com.be.service.BePaymentBreakdownService;
import com.be.service.BePaymentDtlService;
import com.be.service.BePaymentService;
import com.be.service.BePreRegService;
import com.be.service.RefMetadataService;
import com.be.service.RefStatusService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.idm.sdk.model.FcmDevice;
import com.idm.sdk.model.UserProfile;
import com.notify.sdk.constants.MailTypeEnum;
import com.notify.sdk.model.Notification;
import com.notify.sdk.util.MailUtil;
import com.report.sdk.constants.ReportTypeEnum;
import com.report.sdk.model.Report;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.JsonUtil;
import com.util.MediaType;
import com.util.UidGenerator;
import com.util.constants.BaseConstants;
import com.util.pagination.DataTableRequest;
import com.util.pagination.DataTableResults;


@RestController
@RequestMapping(BeUrlConstants.PAYMENT)
public class PaymentRestController extends AbstractRestController {

	@Autowired
	protected Mapper dozerMapper;

	@Autowired
	private BePaymentService bePaymentSvc;

	@Autowired
	private BePaymentDtlService bePaymentDtlSvc;

	@Autowired
	private BePreRegService bePreRegSvc;

	@Autowired
	private BePaymentBreakdownService bePaymentBreakdownSvc;

	@Autowired
	private RefStatusService refStatusSvc;

	@Autowired
	private RefMetadataService refMetadataSvc;

	@Autowired
	BePaymentQf bePaymentQf;

	@Autowired
	BeMemberProfileService beMemberProfileSvc;

	@Autowired
	private BeConfigService configSvc;

	@Autowired
	private BeCtrlGenService beCtrlGenSvc;

	private static DecimalFormat df = new DecimalFormat("0.00");

	@Value("${" + ConfigConstants.PORTAL_APP_URL + "}")
	private String portalAppUrl;

	@Value("${" + ConfigConstants.KIPLE_APP_URL + "}")
	private String kipleAppUrl;

	@Value("${" + ConfigConstants.SENANGPAY_APP_URL + "}")
	private String senangpayAppUrl;
	
	@Autowired
	BeConfigService beConfigSvc;



	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<Payment> searchPaginated(@Valid @RequestBody Payment dto, HttpServletRequest request)
			throws IOException {
		DataTableRequest<Payment> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) bePaymentSvc.getCount(dto);
		List<Payment> filtered = bePaymentSvc.searchPagination(dto, dataTableInRQ);
		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.SEARCH)
	public Payment searchPayment(@RequestBody Payment dto, HttpServletRequest request) throws IOException {
		// PMT_ID, TXN_ID, PMT_REF_NO
		return bePaymentSvc.search(dto);
	}


	@PostMapping(value = BeUrlConstants.CREATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Payment prePayment(@RequestBody Payment dto, HttpServletRequest request) throws IOException {
		BePayment crtPayment = dozerMapper.map(dto, BePayment.class);
		String appRefNo = UidGenerator.generateUidYear("PMT");
		crtPayment.setTxnId(UidGenerator.getMessageId());
		crtPayment.setPmtRefNo(appRefNo);

		String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();

		RefStatus refStatus = refStatusSvc.findByStatusCodeStatusType("PEND", "PMT_STATUS");
		crtPayment.setStatusId(refStatus.getStatusId());

		Integer statusIdMember = null;
		List<Integer> preRegList = null;

		if (!BaseUtil.isListNull(dto.getPaymentDtlList())) {
			RefStatus refStatusMember = refStatusSvc.findByStatusCodeStatusType("IP_PD", "REG_STATUS");
			statusIdMember = refStatusMember.getStatusId();

			AtomicInteger atomicInteger = new AtomicInteger(1);
			List<BePaymentDtl> paymentDtlList = dto.getPaymentDtlList().stream().map(payment -> {
				BePaymentDtl pmtDtl = dozerMapper.map(payment, BePaymentDtl.class);
				pmtDtl.setPmtDtlRefNo(appRefNo + "-" + atomicInteger.getAndIncrement());
				pmtDtl.setCreateId(userId);
				pmtDtl.setCreateDt(currDt);
				pmtDtl.setUpdateId(userId);
				pmtDtl.setUpdateDt(currDt);

				return pmtDtl;
			}).collect(Collectors.toList());

			preRegList = paymentDtlList.stream().map(paymentDtl -> {
				return BaseUtil.getInt(paymentDtl.getItemId());
			}).collect(Collectors.toList());

			crtPayment.addBePaymentDtlList(paymentDtlList);
		}

		crtPayment.setPmtBy(userId);
		crtPayment.setPmtDt(currDt);
		crtPayment.setCreateId(userId);
		crtPayment.setCreateDt(currDt);
		crtPayment.setUpdateId(userId);
		crtPayment.setUpdateDt(currDt);
		crtPayment = bePaymentSvc.createPayment(crtPayment, preRegList, statusIdMember);
		return dozerMapper.map(crtPayment, Payment.class);
	}


	@PostMapping(value = BeUrlConstants.CREATE + BeUrlConstants.PUBLIC, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public Payment createPaymentPublic(@RequestBody Payment dto, HttpServletRequest request) throws IOException {

		Payment pmtDto = dto;
		if (BaseUtil.isObjNull(pmtDto) || BaseUtil.isListNull(pmtDto.getPaymentDtlList())) {
			throw new BeException(BeErrorCodeEnum.E400C006);
		}

		// create payment (pre payment)
		BePayment crtPayment = dozerMapper.map(pmtDto, BePayment.class);
		String pmtRefNo = UidGenerator.generateUidYear("PMT");
		crtPayment.setTxnId(UidGenerator.getMessageId());
		crtPayment.setPmtRefNo(pmtRefNo);

		Timestamp currDt = DateUtil.getSQLTimestamp();

		RefStatus refStatus = refStatusSvc.findByStatusCodeStatusType("PEND", "PMT_STATUS");
		crtPayment.setStatusId(refStatus.getStatusId());
		crtPayment.setPmtBy(dto.getPmtBy());
		crtPayment.setPmtDt(currDt);
		crtPayment.setCreateId(dto.getPmtBy());
		crtPayment.setCreateDt(currDt);
		crtPayment.setUpdateId(dto.getPmtBy());
		crtPayment.setUpdateDt(currDt);

		RefMetadata refChannel = refMetadataSvc.findByMtdtTypeMtdtCd("REG_CHANNEL",
				ReferenceConstants.MTDT_CD_MOB_SELF);

		if (dto.getChannelMtdtId().equals(refChannel.getMtdtId())) {
			BeConfig beConfig = configSvc.findByConfigCode(ConfigConstants.PAYMENT_BATCH_ID);
			if (!BaseUtil.isObjNull(beConfig)) {
				crtPayment.setBatchId(BaseUtil.getInt(beConfig.getConfigVal()));
			}

			RefMetadata pmtTypeMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_PMT_TYPE,
					ReferenceConstants.MTDT_CD_PMT_CC);
			if (!BaseUtil.isObjNull(pmtTypeMtdt)) {
				crtPayment.setPmtTypeMtdtId(pmtTypeMtdt.getMtdtId());
			}

			RefMetadata channelMtdt = refMetadataSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_REG_CHANNEL,
					ReferenceConstants.MTDT_CD_MOB_SELF);
			if (!BaseUtil.isObjNull(channelMtdt)) {
				crtPayment.setChannelMtdtId(channelMtdt.getMtdtId());
			}
		}

		Integer statusIdMember = null;
		List<Integer> preRegList = null;

		if (!BaseUtil.isListNull(crtPayment.getPaymentDtlList())) {
			RefStatus refStatusMember = refStatusSvc.findByStatusCodeStatusType("IP_PD", "REG_STATUS");
			statusIdMember = refStatusMember.getStatusId();

			AtomicInteger atomicInteger = new AtomicInteger(1);
			List<BePaymentDtl> paymentDtlList = dto.getPaymentDtlList().stream().map(payment -> {
				BePaymentDtl pmtDtl = dozerMapper.map(payment, BePaymentDtl.class);
				pmtDtl.setPmtDtlRefNo(pmtRefNo + "-" + atomicInteger.getAndIncrement());
				pmtDtl.setCreateId(dto.getPmtBy());
				pmtDtl.setCreateDt(currDt);
				pmtDtl.setUpdateId(dto.getPmtBy());
				pmtDtl.setUpdateDt(currDt);

				return pmtDtl;
			}).collect(Collectors.toList());

			preRegList = paymentDtlList.stream().map(paymentDtl -> {
				return BaseUtil.getInt(paymentDtl.getItemId());
			}).collect(Collectors.toList());

			crtPayment.addBePaymentDtlList(paymentDtlList);
		}

		crtPayment = bePaymentSvc.createPayment(crtPayment, preRegList, statusIdMember);

		Payment paymentPub = dozerMapper.map(crtPayment, Payment.class);

		if (!BaseUtil.isObjNull(crtPayment)) {
			if (crtPayment.getChannelMtdtId().equals(refChannel.getMtdtId())) {
				PreReg preReg = new PreReg();
				preReg.setIdNo(crtPayment.getPmtBy());
				preReg.setPreRegId(Integer.parseInt(crtPayment.getPaymentDtlList().get(0).getItemId()));

				PreReg preRegExist = bePreRegSvc.search(preReg);
				if (!BaseUtil.isObjNull(preRegExist)) {
					KiplePaymentRequest kiplePaymentRequest = new KiplePaymentRequest();
					kiplePaymentRequest.setOrd_date(DateUtil.getCurrentDate());
					kiplePaymentRequest.setOrd_totalamt(crtPayment.getTotalAmount());
					kiplePaymentRequest.setOrd_gstamt(0.00);
					kiplePaymentRequest.setOrd_shipname(preRegExist.getFullName());
					kiplePaymentRequest.setOrd_shipcountry(null);
					kiplePaymentRequest.setOrd_telephone(preRegExist.getContactNo());
					kiplePaymentRequest.setOrd_email(preRegExist.getEmail());

					kiplePaymentRequest.setOrd_delcharges("0.00");
					kiplePaymentRequest.setOrd_svccharges("0.00");
					kiplePaymentRequest.setOrd_mercref(crtPayment.getPmtRefNo());
					BeConfig beConfigMerchantId = configSvc.findByConfigCode(ConfigConstants.MERCHANT_ID);
					kiplePaymentRequest.setOrd_mercID(beConfigMerchantId.getConfigVal());
					BeConfig beConfigMerchantSecret = configSvc.findByConfigCode(ConfigConstants.MERCHANT_SECRET);
					String kiphash = convtRequstHash(beConfigMerchantSecret.getConfigVal(),
							beConfigMerchantId.getConfigVal(), crtPayment.getPmtRefNo(),
							crtPayment.getTotalAmount(), "");
					// kiplePaymentRequest.setMerchant_hashvalue("187d8cf8b17161772524c6288ecd69885c862dc1");
					kiplePaymentRequest.setMerchant_hashvalue(kiphash);
					kiplePaymentRequest.setPayment_code(ConfigConstants.CC);

					kiplePaymentRequest.setOrd_returnURL(portalAppUrl + ConfigConstants.PATH_REDIRECT_MOBILE);
					kiplePaymentRequest.setOrd_key(null);
					kiplePaymentRequest.setReturncode(null);
					kiplePaymentRequest.setOrd_customfield1(crtPayment.getCreateId());

					kiplePaymentRequest.setKipleUrl(kipleAppUrl);
					kiplePaymentRequest.setPmtType("KIPLEPAY");

					// SenangPay Request Params
					BeConfig payTypeSenang = configSvc.findByConfigCode("SENANGPAY_PAYMENT");
					if (BaseUtil.isEquals(payTypeSenang.getConfigVal(), "Y")) {
						kiplePaymentRequest.setPmtType("SENANGPAY");
						kiplePaymentRequest.setSenangDesc("Membership Fees");
						// SenagPay Hash
						StringBuilder reqhashParam = new StringBuilder();
						String mercSecret = configSvc.findByConfigCode("SENANGPAY_SECRET").getConfigVal();
						reqhashParam.append(mercSecret).append("Membership Fees")
								.append(crtPayment.getTotalAmount())
								.append(crtPayment.getPmtRefNo());
						String convtHashKey = DigestUtils.md5Hex(reqhashParam.toString());
						kiplePaymentRequest.setMerchant_hashvalue(convtHashKey);
						BeConfig beConfigSenagMerchantId = configSvc.findByConfigCode("SENANGPAY_MERCHANT_ID");
						kiplePaymentRequest.setOrd_mercID(beConfigSenagMerchantId.getConfigVal());
						kiplePaymentRequest
								.setOrd_returnURL(portalAppUrl + ConfigConstants.PATH_SENAG_REDIRECT_MOBILE);
						kiplePaymentRequest
								.setSenangUrl(senangpayAppUrl + beConfigSenagMerchantId.getConfigVal());
					}

					paymentPub.setKiplePaymentRequest(kiplePaymentRequest);
				}
			}
		}

		return paymentPub;
	}


	@PostMapping(value = BeUrlConstants.BREAKDOWN, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<PaymentBreakdown> searchPaymentBreakdown(@RequestBody PaymentBreakdown dto, HttpServletRequest request)
			throws IOException {
		return bePaymentBreakdownSvc.searchPagination(dto, null);
	}


	@Transactional
	@PostMapping(value = BeUrlConstants.POST_PAYMENT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Payment postPayment2(@RequestBody Payment dto, HttpServletRequest request) throws IOException {

		BePayment bePayment = bePaymentSvc.find(dto.getPmtId());

		if (BaseUtil.isObjNull(bePayment)) {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}

		String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();

		if (!BaseUtil.isObjNull(dto.getPaymentGateway())) {
			BePaymentGateway bePaymentGw = new BePaymentGateway();
			bePaymentGw.setGwRefNo(dto.getPaymentGateway().getGwRefNo());
			bePaymentGw.setReturnCd(dto.getPaymentGateway().getReturnCd());
			bePaymentGw.setPmtCd(dto.getPaymentGateway().getPmtCd());
			if (!BaseUtil.isObjNull(dto.getPaymentGateway().getErrorDesc())) {
				bePaymentGw.setErrorDesc(dto.getPaymentGateway().getErrorDesc());
			}
			if (!BaseUtil.isObjNull(dto.getPaymentGateway().getSrcType())) {
				bePaymentGw.setSrcType(dto.getPaymentGateway().getSrcType());
			}
			if (!BaseUtil.isObjNull(dto.getPaymentGateway().getGwResponse())) {
				bePaymentGw.setGwResponse(dto.getPaymentGateway().getGwResponse());
			}
			bePaymentGw.setCreateId(userId);
			bePaymentGw.setCreateDt(currDt);
			bePaymentGw.setUpdateId(userId);
			bePaymentGw.setUpdateDt(currDt);
			
			if (BaseUtil.isEqualsCaseIgnore(bePayment.getPmtByLevel(), ReferenceConstants.HQ)) {
				bePaymentGw.setCreateId(bePayment.getPmtBy());
				bePaymentGw.setUpdateId(bePayment.getPmtBy());
			}
			
			bePayment.addBePaymentGateway(bePaymentGw);
		}

		bePayment.setStatusId(dto.getStatusId());
		bePayment.setPmtGwDt(currDt);
		bePayment.setUpdateId(userId);
		bePayment.setUpdateDt(currDt);
		if (BaseUtil.isEqualsCaseIgnore(bePayment.getPmtByLevel(), ReferenceConstants.HQ)) {
			bePayment.setUpdateId(bePayment.getPmtBy());
		}

		RefStatus refStatus = refStatusSvc.find(dto.getStatusId());
		if (BaseUtil.isObjNull(refStatus)) {
			throw new BeException(BeErrorCodeEnum.E500C002);
		}

		Integer statusIdMember = null;
		List<Integer> preRegList = null;
		List<BeMemberProfile> beMemberProfileList = null;
		List<BePreReg> bePreRegs = new ArrayList<>();
		RefMetadata channelMtdt = new RefMetadata();
		if (BaseUtil.isEqualsCaseIgnore("PD", refStatus.getStatusCd())
				|| BaseUtil.isEqualsCaseIgnore("REJ", refStatus.getStatusCd())) {
			preRegList = bePayment.getPaymentDtlList().stream().map(paymentDtl -> {
				return BaseUtil.getInt(paymentDtl.getItemId());
			}).collect(Collectors.toList());

			PreReg preReg = new PreReg();
			preReg.setPreRegIdList(preRegList);
			List<BePreReg> bePreRegList = bePreRegSvc.searchBePreReg(preReg);
			if (BaseUtil.isListNull(bePreRegList)) {
				throw new BeException(BeErrorCodeEnum.E500C002);
			}

			channelMtdt = refMetadataSvc.find(bePayment.getChannelMtdtId());
			if (BaseUtil.isObjNull(channelMtdt)) {
				throw new BeException(BeErrorCodeEnum.E500C002);
			}

			String statusCd = null;
			if (BaseUtil.isEqualsCaseIgnore("PD", refStatus.getStatusCd())) {
				if (BaseUtil.isEqualsCaseIgnore(channelMtdt.getMtdtCd(), ReferenceConstants.MTDT_CD_WEB_CNTR)) {
					statusCd = "VER";
					if (BaseUtil.isEqualsCaseIgnore(bePayment.getPmtByLevel(), ReferenceConstants.HQ) 
							|| BaseUtil.isEqualsCaseIgnore(bePayment.getPmtByLevel(), ReferenceConstants.DIV)) {
						statusCd = "PEND_APRV";
					}
				} else {
					statusCd = "PD";
				}
			} else if (BaseUtil.isEqualsCaseIgnore("REJ", refStatus.getStatusCd())) {

				if (BaseUtil.isEqualsCaseIgnore(channelMtdt.getMtdtCd(),ReferenceConstants.MTDT_CD_WEB_CNTR)) {
					statusCd = "PEND";
				} else {
					statusCd = "REJ";
				}
			}
			RefStatus refStatusMember = refStatusSvc.findByStatusCodeStatusType(statusCd, "REG_STATUS");
			statusIdMember = refStatusMember.getStatusId();

			if (BaseUtil.isEqualsCaseIgnore(channelMtdt.getMtdtCd(), ReferenceConstants.MTDT_CD_WEB_CNTR)
					&& BaseUtil.isEqualsCaseIgnore("PD", refStatus.getStatusCd())) {
				beMemberProfileList = new ArrayList<>();
				for (BePreReg bePreReg : bePreRegList) {
					BeMemberProfile beMemberProfile = dozerMapper.map(bePreReg, BeMemberProfile.class);
					// String memberNo =
					// UidGenerator.generateUidYear("MBR");
					String memberNo = beCtrlGenSvc.generateSeqNo("MEMBERNO", "MBR");
					beMemberProfile.setMemberRefNo(memberNo);
					beMemberProfile.setMemberNo(memberNo);
					beMemberProfile.setTxnId(UidGenerator.getMessageId());
					beMemberProfile.setStatusId(statusIdMember);
					beMemberProfile.setCredentialInd(0);
					beMemberProfile.setCreateId(userId);
					beMemberProfile.setCreateDt(currDt);
					beMemberProfile.setUpdateId(userId);
					beMemberProfile.setUpdateDt(currDt);
					if (BaseUtil.isEqualsCaseIgnore(bePayment.getPmtByLevel(), ReferenceConstants.HQ)) {
						beMemberProfile.setApproveBy(bePayment.getPmtBy());
						beMemberProfile.setApproveDt(bePayment.getPmtDt());
						RefMetadata existRegMtdt = refMetadataSvc.findByMtdtTypeMtdtCd("REG_EXIST", "EXIST_N");

						if (!BaseUtil.isObjNull(existRegMtdt)) {
							beMemberProfile.setRegExistMtdtId(existRegMtdt.getMtdtId());
						}
						if (BaseUtil.isStringNull(userId)) {
							beMemberProfile.setCreateId(bePayment.getPmtBy());
							beMemberProfile.setUpdateId(bePayment.getPmtBy());
						}
					}

					if (!BaseUtil.isListNull(bePreReg.getPreRegAddressList())) {
						List<BeMemberAddress> beMemberAddressList = bePreReg.getPreRegAddressList().stream()
								.map(address -> {
									BeMemberAddress beMemberAddress = dozerMapper.map(address,
											BeMemberAddress.class);
									beMemberAddress.setCreateId(userId);
									beMemberAddress.setCreateDt(currDt);
									beMemberAddress.setUpdateId(userId);
									beMemberAddress.setUpdateDt(currDt);
									return beMemberAddress;
								}).collect(Collectors.toList());

						beMemberProfile.addBeMemberAddressList(beMemberAddressList);
					}

					beMemberProfileList.add(beMemberProfile);
				}
			}

			for (BePreReg bePreReg : bePreRegList) {

				bePreReg.setStatus(new RefStatus());
				bePreReg.getStatus().setStatusId(statusIdMember);
				bePreReg.setStatusId(statusIdMember);
				if (BaseUtil.isEquals(statusCd, "PEND_APRV")) {
					bePreReg.setHqInd(1);
				}

				bePreRegs.add(bePreReg);
			}

		}

		Payment payment = bePaymentSvc.updatePostPayment2(bePayment, statusIdMember, beMemberProfileList, bePreRegs);

		if (!BaseUtil.isObjNull(payment)) {
			bePaymentSvc.processNotification(payment, refStatus, channelMtdt, request);
		}

		// if(BaseUtil.isEquals("PD", payment.getStatus().getStatusCd())) {
		if (dto.getStatusId() == 6
				&& BaseUtil.isEqualsCaseIgnore(channelMtdt.getMtdtCd(), ReferenceConstants.MTDT_CD_WEB_CNTR)) {
			bePaymentSvc.sendNotificationPaymentSuccess(payment, refStatus, channelMtdt, request);
		}
		// }

		return payment;
	}


	@Transactional
	@PostMapping(value = BeUrlConstants.POST_PAYMENT_2, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Payment postPayment(@RequestBody Payment dto, HttpServletRequest request) throws IOException {
		BePayment bePayment = bePaymentSvc.find(dto.getPmtId());
		if (BaseUtil.isObjNull(bePayment)) {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}

		String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();

		if (!BaseUtil.isObjNull(dto.getPaymentGateway())) {
			BePaymentGateway bePaymentGw = new BePaymentGateway();
			bePaymentGw.setGwRefNo(dto.getPaymentGateway().getGwRefNo());
			bePaymentGw.setReturnCd(dto.getPaymentGateway().getReturnCd());
			bePaymentGw.setPmtCd(dto.getPaymentGateway().getPmtCd());
			if (!BaseUtil.isObjNull(dto.getPaymentGateway().getErrorDesc())) {
				bePaymentGw.setErrorDesc(dto.getPaymentGateway().getErrorDesc());
			}
			if (!BaseUtil.isObjNull(dto.getPaymentGateway().getSrcType())) {
				bePaymentGw.setSrcType(dto.getPaymentGateway().getSrcType());
			}
			if (!BaseUtil.isObjNull(dto.getPaymentGateway().getGwResponse())) {
				bePaymentGw.setGwResponse(dto.getPaymentGateway().getGwResponse());
			}
			bePaymentGw.setCreateId(userId);
			bePaymentGw.setCreateDt(currDt);
			bePaymentGw.setUpdateId(userId);
			bePaymentGw.setUpdateDt(currDt);
			bePayment.addBePaymentGateway(bePaymentGw);
		}

		bePayment.setStatusId(dto.getStatusId());
		bePayment.setPmtGwDt(currDt);
		bePayment.setUpdateId(userId);
		bePayment.setUpdateDt(currDt);

		RefStatus refStatus = refStatusSvc.find(dto.getStatusId());
		if (BaseUtil.isObjNull(refStatus)) {
			throw new BeException(BeErrorCodeEnum.E500C002);
		}

		Integer statusIdMember = null;
		List<Integer> preRegList = null;
		List<BeMemberProfile> beMemberProfileList = null;
		List<BePreReg> bePreRegs = new ArrayList<>();
		RefMetadata channelMtdt = new RefMetadata();
		if (BaseUtil.isEqualsCaseIgnore("PD", refStatus.getStatusCd())
				|| BaseUtil.isEqualsCaseIgnore("REJ", refStatus.getStatusCd())) {
			preRegList = bePayment.getPaymentDtlList().stream().map(paymentDtl -> {
				return BaseUtil.getInt(paymentDtl.getItemId());
			}).collect(Collectors.toList());

			PreReg preReg = new PreReg();
			preReg.setPreRegIdList(preRegList);
			List<PreReg> bePreRegList = bePreRegSvc.searchList(preReg);
			if (BaseUtil.isListNull(bePreRegList)) {
				throw new BeException(BeErrorCodeEnum.E500C002);
			}

			channelMtdt = refMetadataSvc.find(bePayment.getChannelMtdtId());
			if (BaseUtil.isObjNull(channelMtdt)) {
				throw new BeException(BeErrorCodeEnum.E500C002);
			}

			String statusCd = null;
			if (BaseUtil.isEqualsCaseIgnore("PD", refStatus.getStatusCd())) {
				if (BaseUtil.isEqualsCaseIgnore(channelMtdt.getMtdtCd(), ReferenceConstants.MTDT_CD_WEB_CNTR)) {
					statusCd = "VER";
					if (BaseUtil.isEqualsCaseIgnore(dto.getPmtByLevel(), ReferenceConstants.DIV)) {
						statusCd = "PEND_APRV";
					}
				} else {
					statusCd = "PD";
				}
			} else if (BaseUtil.isEqualsCaseIgnore("REJ", refStatus.getStatusCd())) {

				if (BaseUtil.isEqualsCaseIgnore(channelMtdt.getMtdtCd(),ReferenceConstants.MTDT_CD_WEB_CNTR)) {
					statusCd = "PEND";
				} else {
					statusCd = "REJ";
				}
			}
			RefStatus refStatusMember = refStatusSvc.findByStatusCodeStatusType(statusCd, "REG_STATUS");
			statusIdMember = refStatusMember.getStatusId();

			if (BaseUtil.isEqualsCaseIgnore(channelMtdt.getMtdtCd(), ReferenceConstants.MTDT_CD_WEB_CNTR)
					&& BaseUtil.isEqualsCaseIgnore("PD", refStatus.getStatusCd())) {
				beMemberProfileList = new ArrayList<>();
				for (PreReg bePreReg : bePreRegList) {
					BeMemberProfile beMemberProfile = dozerMapper.map(bePreReg, BeMemberProfile.class);
					// String memberNo =
					// UidGenerator.generateUidYear("MBR");
					String memberNo = beCtrlGenSvc.generateSeqNo("MEMBERNO", "MBR");
					beMemberProfile.setMemberRefNo(memberNo);
					beMemberProfile.setMemberNo(memberNo);
					beMemberProfile.setTxnId(UidGenerator.getMessageId());
					beMemberProfile.setStatusId(statusIdMember);
					beMemberProfile.setCredentialInd(0);
					beMemberProfile.setCreateId(userId);
					beMemberProfile.setCreateDt(currDt);
					beMemberProfile.setUpdateId(userId);
					beMemberProfile.setUpdateDt(currDt);

					if (!BaseUtil.isListNull(bePreReg.getPreRegAddressList())) {
						List<BeMemberAddress> beMemberAddressList = bePreReg.getPreRegAddressList().stream()
								.map(address -> {
									BeMemberAddress beMemberAddress = dozerMapper.map(address,
											BeMemberAddress.class);
									beMemberAddress.setCreateId(userId);
									beMemberAddress.setCreateDt(currDt);
									beMemberAddress.setUpdateId(userId);
									beMemberAddress.setUpdateDt(currDt);
									return beMemberAddress;
								}).collect(Collectors.toList());

						beMemberProfile.addBeMemberAddressList(beMemberAddressList);
					}

					beMemberProfileList.add(beMemberProfile);
				}
			}

			for (PreReg bePreReg : bePreRegList) {

				BePreReg bePrReg = bePreRegSvc.find(bePreReg.getPreRegId());
				bePrReg.setStatus(new RefStatus());
				bePrReg.getStatus().setStatusId(statusIdMember);
				bePrReg.setStatusId(statusIdMember);
				if (BaseUtil.isEquals(statusCd, "PEND_APRV")) {
					bePreReg.setHqInd(1);
				}
				bePreRegs.add(bePrReg);
			}

		}

		bePayment = bePaymentSvc.updatePostPayment(bePayment, preRegList, statusIdMember, beMemberProfileList,
				bePreRegs);

		if (!BaseUtil.isObjNull(bePayment) && BaseUtil.isEqualsCaseIgnore("PD", refStatus.getStatusCd())) {
			// notification
			if (BaseUtil.isEqualsCaseIgnore(channelMtdt.getMtdtCd(), ReferenceConstants.MTDT_CD_WEB_CNTR)) {
				if (!BaseUtil.isEquals(bePayment.getPmtBy(), "")) {
					try {

						// UserProfile userProf1 =
						// getIdmService(request).getUserProfileById(bePayment.getPmtBy(),
						// false, false);
						MemberProfile memProf = new MemberProfile();
						memProf.setIdNo(bePayment.getPmtBy());
						memProf = beMemberProfileSvc.search(memProf);

						// Payment paymentSummary = new Payment();
						// paymentSummary =
						// JsonUtil.transferToObject(bePayment,
						// Payment.class);

						if (!BaseUtil.isObjNull(memProf)) {
							Map<String, Object> map = new HashMap<>();
							map.put("paymentDate",
									!BaseUtil.isObjNull(bePayment.getPmtDt()) ? DateUtil.convertDate(
											bePayment.getPmtDt(), BaseConstants.DT_DD_MM_YYYY_SLASH) : null);

							if (bePayment.getPaymentDtlList().size() != 0) {
								map.put("memberCount", bePayment.getPaymentDtlList().size());
								for (BePaymentDtl paymentDtl : bePayment.getPaymentDtlList()) {
									int itemId = Integer.parseInt(paymentDtl.getItemId());

									MemberProfile memberProfile = new MemberProfile();
									memberProfile.setPreRegId(itemId);

									MemberProfile memberPro = beMemberProfileSvc.search(memberProfile);

									// email official receipt
									if (!BaseUtil.isObjNull(memberPro.getEmail())) {
										map.put("fullName", memberPro.getFullName());
										map.put("summaryReceiptNo", paymentDtl.getPmtDtlRefNo());
										map.put("summaryCurrency", paymentDtl.getCurrency());
										map.put("summaryAmount", df.format(paymentDtl.getItemAmount()));

										Notification notification = new Notification();
										notification.setNotifyTo(memberPro.getEmail());
										notification.setMetaData(MailUtil.convertMapToJson(map));
										notification.setAttachments(new ArrayList<>());

										Report officialReceipt = null;
										RefDocument officialReceiptDoc = new RefDocument();
										PaymentDtl payOfficialReceipt = new PaymentDtl();
										payOfficialReceipt.setItemId(paymentDtl.getItemId());

										// summary receipt
										officialReceiptDoc.setDocDesc("Official Receipt");
										officialReceiptDoc.setType(ReportTypeEnum.PDF.getMimeType());

										officialReceipt = getReportService(request).report()
												.genIndividualPaymentSlip(payOfficialReceipt,
														ReportTypeEnum.PDF);

										if (!BaseUtil.isObjNull(officialReceipt)) {
											notification.setAttachments(new ArrayList<>());
											notification.getAttachments().add(setNotificationAttachments(
													officialReceipt, officialReceiptDoc));
										}
										getNotifyService(request).addNotification(notification,
												MailTemplateConstants.PAYMENT_SUCCESSFUL_EMAIL);
									}

									// sms
									if (!BaseUtil.isObjNull(memberPro.getContactNo())) {
										map.put("fullName", memberPro.getFullName());

										Notification notification = new Notification();
										notification.setNotifyTo(memberPro.getContactNo());
										notification.setMetaData(MailUtil.convertMapToJson(map));
										notification.setNotifyType(MailTypeEnum.SMS.getType());

										getNotifyService(request).addNotification(notification,
												MailTemplateConstants.PAYMENT_SUCCESSFUL_SMS);
									}

									// fcm
									if (!BaseUtil.isObjNull(memberPro.getMemberId())) {

										UserProfile userProfile = new UserProfile();
										try {
											userProfile = getIdmService(request).getUserProfileByProfId(
													memberPro.getMemberId(), false, false);
										} catch (Exception e) {

										}

										if (!BaseUtil.isObjNull(userProfile)) {
											Map<String, Object> datamap = new LinkedHashMap<>();
											datamap.put("invoiceNo", bePayment.getPmtRefNo());
											datamap.put("paymentAmount",
													df.format(bePayment.getTotalAmount()));
											datamap.put("noOfMember", 1);
											datamap.put("paymentDate",
													!BaseUtil.isObjNull(bePayment.getPmtDt())
															? DateUtil.convertDate(bePayment.getPmtDt(),
																	BaseConstants.DT_DD_MM_YYYY_SLASH)
															: null);
											List<FcmDevice> devices = bePaymentSvc
													.searchAllDevice(userProfile, request);

											bePaymentSvc.addFCMNotification(devices, userProfile, datamap,
													MailTemplateConstants.PAYMENT_SUCCESSFUL_FCM, request);
										}

									}

								}

							}

							// sms
							if (!BaseUtil.isObjNull(memProf.getContactNo())) {
								map.put("fullName", memProf.getFullName());

								Notification notification = new Notification();
								notification.setNotifyTo(memProf.getContactNo());
								notification.setMetaData(MailUtil.convertMapToJson(map));
								notification.setNotifyType(MailTypeEnum.SMS.getType());

								getNotifyService(request).addNotification(notification,
										MailTemplateConstants.PAYMENT_SUCCESSFUL_SMS);
							}

							// email summary receipt
							if (!BaseUtil.isObjNull(memProf.getEmail())) {
								map.put("fullName", memProf.getFullName());
								map.put("summaryReceiptNo", bePayment.getPmtRefNo());
								map.put("summaryCurrency", bePayment.getCurrency());
								map.put("summaryAmount", df.format(bePayment.getTotalAmount()));

								Notification notification = new Notification();
								notification.setNotifyTo(memProf.getEmail());
								notification.setMetaData(MailUtil.convertMapToJson(map));
								notification.setAttachments(new ArrayList<>());

								Report summaryReceipt = null;
								RefDocument summaryReceiptDoc = new RefDocument();
								Payment paySummaryReceipt = new Payment();
								paySummaryReceipt.setTxnId(bePayment.getTxnId());

								// summary receipt
								summaryReceiptDoc.setDocDesc("Summary Receipt");
								summaryReceiptDoc.setType(ReportTypeEnum.PDF.getMimeType());

								summaryReceipt = getReportService(request).report()
										.genPaymentSlip(paySummaryReceipt, ReportTypeEnum.PDF);

								if (!BaseUtil.isObjNull(summaryReceipt)) {
									notification.setAttachments(new ArrayList<>());
									notification.getAttachments().add(
											setNotificationAttachments(summaryReceipt, summaryReceiptDoc));
								}
								getNotifyService(request).addNotification(notification,
										MailTemplateConstants.PAYMENT_SUCCESSFUL_EMAIL);
							}

							// fcm
							if (!BaseUtil.isObjNull(memProf.getMemberId())) {

								UserProfile userProfile = new UserProfile();
								try {
									userProfile = getIdmService(request)
											.getUserProfileByProfId(memProf.getMemberId(), false, false);
								} catch (Exception e) {

								}
								if (!BaseUtil.isObjNull(userProfile)) {
									Map<String, Object> datamap = new LinkedHashMap<>();
									datamap.put("invoiceNo", bePayment.getPmtRefNo());
									datamap.put("paymentAmount", df.format(bePayment.getTotalAmount()));
									datamap.put("noOfMember", bePayment.getPaymentDtlList().size());
									List<FcmDevice> devices = bePaymentSvc.searchAllDevice(userProfile,
											request);

									bePaymentSvc.addFCMNotification(devices, userProfile, datamap,
											MailTemplateConstants.PAYMENT_SUCCESSFUL_FCM, request);
								}

							}

						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} else {

				try {

					// Payment paymentSummary = new Payment();
					// paymentSummary =
					// JsonUtil.transferToObject(bePayment, Payment.class);

					Map<String, Object> map = new HashMap<>();
					map.put("paymentDate", !BaseUtil.isObjNull(bePayment.getPmtDt())
							? DateUtil.convertDate(bePayment.getPmtDt(), BaseConstants.DT_DD_MM_YYYY_SLASH)
							: null);

					// sms
					if (!BaseUtil.isObjNull(bePreRegs.get(0).getContactNo())) {
						map.put("fullName", bePreRegs.get(0).getFullName());

						Notification notification = new Notification();
						notification.setNotifyTo(bePreRegs.get(0).getContactNo());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setNotifyType(MailTypeEnum.SMS.getType());

						getNotifyService(request).addNotification(notification,
								MailTemplateConstants.PAYMENT_SUCCESSFUL_SMS);
					}

					// email summary receipt
					if (!BaseUtil.isObjNull(bePreRegs.get(0).getEmail())) {
						map.put("fullName", bePreRegs.get(0).getFullName());
						map.put("summaryReceiptNo", bePayment.getPmtRefNo());
						map.put("summaryCurrency", bePayment.getCurrency());
						map.put("summaryAmount", df.format(bePayment.getTotalAmount()));

						Notification notification = new Notification();
						notification.setNotifyTo(bePreRegs.get(0).getEmail());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setAttachments(new ArrayList<>());

						Report officialReceipt = null;
						RefDocument officialReceiptDoc = new RefDocument();
						PaymentDtl payOfficialReceipt = new PaymentDtl();
						payOfficialReceipt.setItemId(bePayment.getPaymentDtlList().get(0).getItemId());

						officialReceiptDoc.setDocDesc("Official Receipt");
						officialReceiptDoc.setType(ReportTypeEnum.PDF.getMimeType());

						officialReceipt = getReportService(request).report()
								.genIndividualPaymentSlip(payOfficialReceipt, ReportTypeEnum.PDF);

						if (!BaseUtil.isObjNull(officialReceipt)) {
							notification.setAttachments(new ArrayList<>());
							notification.getAttachments()
									.add(setNotificationAttachments(officialReceipt, officialReceiptDoc));
						}
						getNotifyService(request).addNotification(notification,
								MailTemplateConstants.PAYMENT_SUCCESSFUL_EMAIL);
					}

				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		}
		return dozerMapper.map(bePayment, Payment.class);

	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Payment updatePaymentfo(@RequestBody Payment dto, HttpServletRequest request) throws IOException {

		try {

			if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getPmtRefNo())) {
				throw new BeException(BeErrorCodeEnum.E400C913);
			}

			Payment searchDto = new Payment();
			searchDto.setPmtRefNo(dto.getPmtRefNo());
			searchDto.setEmbedDtls(true);
			BePayment bePayment = bePaymentQf.searchPayment(searchDto);

			if (bePayment.getStatusId() == 5) {
				RefStatus refStatus = refStatusSvc.find(dto.getStatusId());
				RefMetadata channelMtdt = refMetadataSvc.find(bePayment.getChannelMtdtId());
				if (BaseUtil.isObjNull(channelMtdt)) {
					throw new BeException(BeErrorCodeEnum.E500C002);
				}
				String statusCd = null;
				if (BaseUtil.isEqualsCaseIgnore("PD", refStatus.getStatusCd())) {
					if (BaseUtil.isEqualsCaseIgnore(channelMtdt.getMtdtCd(),
							ReferenceConstants.MTDT_CD_WEB_CNTR)) {
						statusCd = "VER";
						if (BaseUtil.isEqualsCaseIgnore(dto.getPmtByLevel(), ReferenceConstants.DIV)) {
							statusCd = "PEND_APRV";
						}
					} else {
						statusCd = "PD";
					}
				} else if (BaseUtil.isEqualsCaseIgnore("REJ", refStatus.getStatusCd())) {
					
					if (BaseUtil.isEqualsCaseIgnore(channelMtdt.getMtdtCd(),ReferenceConstants.MTDT_CD_WEB_CNTR)) {
						statusCd = "FAILED";
					} else {
						statusCd = "FAILED";
					}
				}
				RefStatus refStatusMember = refStatusSvc.findByStatusCodeStatusType(statusCd, "REG_STATUS");
				Integer statusIdMember = refStatusMember.getStatusId();
				if(BaseUtil.isEquals("yes", dto.getAbortPmtStatus())) {
					dto.setStatusId(refStatusSvc.findByStatusCodeStatusType(statusCd, "PMT_STATUS").getStatusId());	
				}
				bePaymentSvc.updatePaymentInfo(dto, bePayment, request, statusIdMember);
			}

			return JsonUtil.transferToObject(bePayment, Payment.class);

		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	@PostMapping(value = BeUrlConstants.GET_DETAIL + BeUrlConstants.PMT_DTL, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public PaymentDtl getPmtDetail(@RequestBody PaymentDtl dto, HttpServletRequest request) throws IOException {
		PaymentDtl paymentDtl = bePaymentDtlSvc.searchDtl(dto.getItemId());
		if (!BaseUtil.isObjNull(paymentDtl) && !BaseUtil.isObjNull(paymentDtl.getPreReg())) {
			MemberProfile memberProfile = new MemberProfile();

			memberProfile.setFullName(paymentDtl.getPreReg().getFullName());
			memberProfile.setIdNo(paymentDtl.getPreReg().getIdNo());
			memberProfile.setPmtDtlRefNo(paymentDtl.getPmtDtlRefNo());
			memberProfile.setItemAmount(paymentDtl.getItemAmount());
			memberProfile.setCurrency(paymentDtl.getCurrency());
			paymentDtl.setMemberProfile(memberProfile);
		}
		return paymentDtl;
	}


	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.GET_DETAIL + BeUrlConstants.RECEIPT, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<PaymentDtl> getPaymentDetail(@RequestBody Payment dto, HttpServletRequest request) throws IOException {
		Payment payment = bePaymentSvc.search(dto);
		payment = JsonUtil.transferToObject(payment, Payment.class);
		List<PaymentDtl> paymentDtlList = JsonUtil.transferToList(payment.getPaymentDtlList(), PaymentDtl.class);
		PaymentDtl payDtl = new PaymentDtl();
		List<PaymentDtl> payDtlList = new ArrayList<>();

		if (!BaseUtil.isListNull(payment.getPaymentDtlList())) {
			List<MemberProfile> memberProfileList = new ArrayList<>();
			for (PaymentDtl paymentDtl : paymentDtlList) {
				MemberProfile memberProfile = new MemberProfile();

				// payDtl.setPmtDtlRefNo(paymentDtl.getPmtDtlRefNo());

				int itemId = Integer.parseInt(paymentDtl.getItemId());
				memberProfile.setPreRegId(itemId);

				MemberProfile memberPro = beMemberProfileSvc.search(memberProfile);
				memberProfile.setFullName(memberPro.getFullName());
				memberProfile.setIdNo(memberPro.getIdNo());
				memberProfile.setPmtDtlRefNo(paymentDtl.getPmtDtlRefNo());
				memberProfile.setItemAmount(paymentDtl.getItemAmount());
				memberProfile.setCurrency(paymentDtl.getCurrency());

				memberProfileList.add(memberProfile);

				LOGGER.info("paymentDtl {}", paymentDtl);
			}
			payDtl.setMemberProfileList(memberProfileList);
			payDtl.setPmtGwDt(payment.getPmtGwDt());
			payDtlList.add(payDtl);
		}

		return payDtlList;
	}


	@PostMapping(value = "/getbeConfValue", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Config getbeConfValue(@RequestBody Config dto, HttpServletRequest request) throws IOException {
		String confCode = dto.getConfigCode();
		BeConfig beConfig = configSvc.findByConfigCode(confCode);
		return JsonUtil.transferToObject(beConfig, Config.class);
	}
	

	@PostMapping(value = BeUrlConstants.FIND_BE_PAYMENT_DTL_BY_PRE_REG_ID, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Payment findPaymentDetailByPreRegId(@Valid @RequestBody PreReg dto,
			HttpServletRequest request) throws IOException {
		
		Payment pmt = null;
		
		if (BaseUtil.isObjNull(dto)) {
			throw new BeException(BeErrorCodeEnum.E400C003);
		}

		if (BaseUtil.isObjNull(dto.getPreRegId())) {
			return pmt;
		}

		Payment payment = new Payment();
		
		if(!BaseUtil.isObjNull(dto.getStatusId())) {
			RefStatus refStatus = refStatusSvc.find(dto.getStatusId());
			if (BaseUtil.isEqualsCaseIgnore("PEND", refStatus.getStatusCd())){
				
			} else {
				
				RefStatus status = refStatusSvc.findByStatusCodeStatusType("PD", "PMT_STATUS");
				if (!BaseUtil.isObjNull(status)) {
					payment.setStatusId(status.getStatusId());
				}
			}
			
		}
		
		PaymentDtl pmtDtl = new PaymentDtl();
		if (!BaseUtil.isObjNull(dto.getPreRegId())) {
			pmtDtl.setItemId(dto.getPreRegId().toString());
		}
		
		List<BePaymentDtl> paymentDtlList = bePaymentDtlSvc.findByPreRegId(pmtDtl,null);
		
		if (BaseUtil.isListNull(paymentDtlList)) {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}
		
		List<PaymentDtl> pmtDList = new ArrayList<PaymentDtl>();
		
		paymentDtlList.forEach(pmtDLst -> {
			PaymentDtl pd = new PaymentDtl();
			pd.setPmtId(pmtDLst.getPayment().getPmtId());
			pmtDList.add(pd);
		});
		
		payment.setPaymentDtlList(pmtDList);
		
		pmt = dozerMapper.map(bePaymentSvc.search(payment), Payment.class);
		
		if (BaseUtil.isObjNull(pmt)) {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}

		List<PaymentDtl> tempPmtDList = new ArrayList<PaymentDtl>();
		for(PaymentDtl oneDetail : pmt.getPaymentDtlList()) {
			if (oneDetail.getItemId().equals(dto.getPreRegId().toString())) {
				tempPmtDList.add(oneDetail);
			}
		}

		pmt.setPaymentDtlList(tempPmtDList);
		
		return pmt;
		
	}


	public static String convtRequstHash(String mercSecret, String mercId, String paymtRefno, Double amount,
			String respods) {
		LOGGER.info("===================================================");
		LOGGER.info("Request info");
		LOGGER.info("PARAMS mercSecret {}", mercSecret);
		LOGGER.info("PARAMS mercId {}", mercId);
		LOGGER.info("PARAMS paymtRefno {}", paymtRefno);
		LOGGER.info("PARAMS amount {}", amount);
		LOGGER.info("PARAMS respods {}", respods);
		LOGGER.info("==================================================");

		StringBuilder reqhashParam = new StringBuilder();
		StringBuilder amountBuilder = new StringBuilder();
		// Remove (.) value
		String ctamt = amount.toString();
		String[] splitamt = ctamt.split("\\.", 0);
		String leftdigit = splitamt[0];
		String rightdigt = splitamt[1];
		String contwithoutspaceamt = leftdigit + rightdigt;
		if (rightdigt.length() == 1) {
			rightdigt = rightdigt + '0';
		}
		amountBuilder.append(leftdigit).append(rightdigt);
		LOGGER.info("=====================================================");
		LOGGER.info("Convertion info");
		LOGGER.info("PARAMS paymtRefno {}", paymtRefno);
		LOGGER.info("PARAMS amount {}", amount);
		LOGGER.info("PARAMS respods {}", respods);
		LOGGER.info("Convert mercSecret {}", mercSecret);
		LOGGER.info("Convert mercId {}", mercId);
		LOGGER.info("Convert convtamt {}", contwithoutspaceamt);
		LOGGER.info("======================================================");

		if (!BaseUtil.isEquals(respods, "")) {

			reqhashParam.append(mercSecret).append(mercId).append(paymtRefno).append(contwithoutspaceamt)
					.append(respods);
		} else {
			reqhashParam.append(mercSecret).append(mercId).append(paymtRefno).append(contwithoutspaceamt);
		}
		String hashCal = DigestUtils.sha1Hex(reqhashParam.toString());
		LOGGER.info("calculated hash value " + hashCal);
		return hashCal;
	}
	
	@PostMapping(value = BeUrlConstants.GET_SENENGPAY_ENQUIRY_STATUS, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public SenangPayResponds getRequestQuery(@RequestBody Payment payment, HttpServletRequest request) throws Exception {
		SenangPayResponds  respds = new SenangPayResponds();
		if(!BaseUtil.isStringNull(payment.getPmtRefNo())) {
			//SET PARAMS TO SENANGPAY ENQUERY
			 
			// GET MERCHANT ID
			BeConfig merchId = beConfigSvc.findByConfigCode(ConfigConstants.SENANGPAY_MERCHANT_ID);
			String merchnatId = merchId.getConfigVal();
			BeConfig segSecrt = beConfigSvc.findByConfigCode(ConfigConstants.SENANGPAY_SECRET);
			String secret = segSecrt.getConfigVal();
			String order_id = payment.getPmtRefNo();
			// GET KIPLE URL
			//RefMetadata klpUrl = refMetadataService.findByMtdtId(55);
			StringBuilder reqhashParam = new StringBuilder();
			reqhashParam.append(merchnatId).append(secret).append(order_id);
			String hashCal = DigestUtils.md5Hex(reqhashParam.toString());
			
			Map<String, String> params = new HashMap<String, String>();
			params.put("order_id", order_id);
			params.put("merchant_id", merchnatId);
			params.put("hash", hashCal);
			BeConfig enqUrl = beConfigSvc.findByConfigCode(ConfigConstants.SENANGPAY_ENQUERY_URL);
			String url = enqUrl.getConfigVal();
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
			for (Map.Entry<String, String> entry : params.entrySet()) {
			    builder.queryParam(entry.getKey(), entry.getValue());
			}
			//System.out.println("builder==>"+builder.toUriString());
			RestTemplate restTemplate = new RestTemplate();
			String getjson = restTemplate.getForObject(builder.toUriString(), String.class);
			ObjectMapper objectMapper = new ObjectMapper();
			respds = objectMapper.readValue(getjson, SenangPayResponds.class);
			return respds;	
		}
		return respds;
	}

}
