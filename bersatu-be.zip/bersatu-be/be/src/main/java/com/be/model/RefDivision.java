/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;


/**
 * @author Ramesh Pongiannan
 *
 */
@Entity
@Table(name = "REF_DIVISION")
public class RefDivision extends AbstractEntity implements Serializable, IQfCriteria<RefDivision> {

	private static final long serialVersionUID = 5466589728737397061L;

	@Id
	@Column(name = "DIVISION_CD")
	private String divisionCd;

	@Column(name = "DIVISION_DESC")
	private String divisionDesc;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "STATE_CD", insertable = false, updatable = false)
	private RefState state;

	@Column(name = "STATE_CD")
	private String stateCd;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;


	public String getDivisionCd() {
		return divisionCd;
	}


	public void setDivisionCd(String divisionCd) {
		this.divisionCd = divisionCd;
	}


	public String getDivisionDesc() {
		return divisionDesc;
	}


	public void setDivisionDesc(String divisionDesc) {
		this.divisionDesc = divisionDesc;
	}


	public RefState getState() {
		return state;
	}


	public void setState(RefState state) {
		this.state = state;
	}


	public String getStateCd() {
		return stateCd;
	}


	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
