package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 *
 *
 * @author Zia Ur Rahman Baig
 * @since Feb 22, 2018
 */
public class PaymentType implements Serializable {

	private static final long serialVersionUID = -6510355585641387606L;

	private Integer id;

	private String paymentTypeCode;

	private Double paymentAmount;

	private Double paymentDescEn;

	private String payType;


	public String getPaymentType() {
		return payType;
	}


	public void setPaymentType(String payType) {
		this.payType = payType;
	}


	private String createId;

	private Timestamp createDt;

	private String updateId;

	private Timestamp updateDt;


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;

	}


	public String getPaymentTypeCode() {
		return paymentTypeCode;
	}


	public void setPaymentTypeCode(String paymentTypeCode) {
		this.paymentTypeCode = paymentTypeCode;
	}


	public Double getPaymentAmount() {
		return paymentAmount;
	}


	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}


	public Double getPaymentDescEn() {
		return paymentDescEn;
	}


	public void setPaymentDescEn(Double paymentDescEn) {
		this.paymentDescEn = paymentDescEn;
	}

}