package com.bestpay.pgw.sdk.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class MerCompBankDetails implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private Integer compBankId;

	private String compRefId;

	private String bankName;

	private String bankAccName;

	private String bankAccNo;

	private String bankBranch;

	private String bankLocation;

	private String bankCountry;
	
	private String bankAgentId;
	
	private String bankCurrency;
	
	private String bankId;
	
	private String compBankBranchId;

	private String createId;

	private Timestamp createDt;

	private Timestamp updateDt;

	private String updateId;

	public Integer getCompBankId() {
		return compBankId;
	}

	public void setCompBankId(Integer compBankId) {
		this.compBankId = compBankId;
	}

	public String getCompRefId() {
		return compRefId;
	}

	public void setCompRefId(String compRefId) {
		this.compRefId = compRefId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankAccName() {
		return bankAccName;
	}

	public void setBankAccName(String bankAccName) {
		this.bankAccName = bankAccName;
	}

	public String getBankAccNo() {
		return bankAccNo;
	}

	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}

	public String getBankBranch() {
		return bankBranch;
	}

	public void setBankBranch(String bankBranch) {
		this.bankBranch = bankBranch;
	}

	public String getBankLocation() {
		return bankLocation;
	}

	public void setBankLocation(String bankLocation) {
		this.bankLocation = bankLocation;
	}

	public String getBankCountry() {
		return bankCountry;
	}

	public void setBankCountry(String bankCountry) {
		this.bankCountry = bankCountry;
	}
	
	public String getBankAgentId() {
		return bankAgentId;
	}

	public void setBankAgentId(String bankAgentId) {
		this.bankAgentId = bankAgentId;
	}

	public String getBankCurrency() {
		return bankCurrency;
	}

	public void setBankCurrency(String bankCurrency) {
		this.bankCurrency = bankCurrency;
	}

	public String getBankId() {
		return bankId;
	}

	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	public String getCompBankBranchId() {
		return compBankBranchId;
	}

	public void setCompBankBranchId(String compBankBranchId) {
		this.compBankBranchId = compBankBranchId;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
