package com.bestpay.pgw.controller;


import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.dm.sdk.model.Documents;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwMerchantContact;
import com.bestpay.pgw.model.PgwMerchantProfile;
import com.bestpay.pgw.model.PgwPaymentSetting;
import com.bestpay.pgw.sdk.constants.PgwErrorCodeEnum;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.exception.PgwException;
import com.bestpay.pgw.sdk.model.MerchantContact;
import com.bestpay.pgw.sdk.model.MerchantInfoDto;
import com.bestpay.pgw.sdk.model.MerchantProfile;
import com.bestpay.pgw.service.PgwMerchantContactService;
import com.bestpay.pgw.service.PgwMerchantProfileService;
import com.bestpay.pgw.service.PgwPaymentSettingService;
import com.bestpay.pgw.service.RefCountryService;
import com.bestpay.pgw.service.RefStateService;
import com.bestpay.pgw.util.ProjectEnum;


@RestController
@RequestMapping(PgwUrlConstants.MERCHANT_PROFILE)
public class PgwMerchantProfileRestController extends AbstractRestController {

	private static final Logger logger = LoggerFactory.getLogger(PgwMerchantProfileRestController.class);

	@Autowired
	public PgwMerchantContactService pgwMerchantContactService;

	@Autowired
	public PgwMerchantProfileService pgwMerchantProfileService;

	@Autowired
	public PgwPaymentSettingService paymentSettingService;

	@Autowired
	public RefCountryService refCountryService;

	@Autowired
	public RefStateService refStateService;


	@GetMapping(value = PgwUrlConstants.FIND_BY_MERCHANT_ID, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MerchantInfoDto getMerchantInfo(@RequestParam String merchantId, HttpServletRequest request) {

		MerchantInfoDto merchantInfoDto = new MerchantInfoDto();
		merchantInfoDto.setMerchantLogo(null);

		if (StringUtils.hasText(merchantId)) {
			PgwMerchantContact pgwMerchantContact = pgwMerchantContactService.findbyMerchantId(merchantId);
			if (!BaseUtil.isObjNull(pgwMerchantContact)) {
				merchantInfoDto.setMerchantContact(new MerchantContact());
				merchantInfoDto.setMerchantContact(dozerMapper.map(pgwMerchantContact, MerchantContact.class));
				try {
					merchantInfoDto.setCountry(StringUtils.hasText(pgwMerchantContact.getCountry())
							? refCountryService.getCntryDescByCntry2Cd(pgwMerchantContact.getCountry())
							: null);
					merchantInfoDto.setState(StringUtils.hasText(pgwMerchantContact.getState())
							? refStateService.getStateDescByStateCd(pgwMerchantContact.getState())
							: null);
				} catch (Exception e) {
					logger.error(e.getMessage());
				}

			} else {
				throw new PgwException(PgwErrorCodeEnum.E400PGW012, new String[] { merchantId });
			}

			PgwMerchantProfile pgwMerchantProfile = pgwMerchantProfileService.findbyMerchantId(merchantId);
			if (!BaseUtil.isObjNull(pgwMerchantProfile)) {
				merchantInfoDto.setMerchantProfile(new MerchantProfile());
				merchantInfoDto.setMerchantProfile(dozerMapper.map(pgwMerchantProfile, MerchantProfile.class));
			} else {
				throw new PgwException(PgwErrorCodeEnum.E400PGW012, new String[] { merchantId });
			}

			// get merchantLogo
			PgwPaymentSetting paymentSetting = paymentSettingService.findByMerchantId(merchantId);
			if (!BaseUtil.isObjNull(paymentSetting) && !BaseUtil.isObjNull(paymentSetting.getDocMgtId())) {
				try {
					Documents pgwMerchantDoc = getDmService(ProjectEnum.BESTPAY)
							.download(paymentSetting.getDocMgtId());

					if (!BaseUtil.isObjNull(pgwMerchantDoc)) {
						String merchantLogo = Base64.encodeBase64String(pgwMerchantDoc.getContent());
						merchantInfoDto
								.setMerchantLogo(pgwMerchantDoc.getContentType() + ";base64," + merchantLogo);
					} else {
						logger.info("merchantLogo has no logo: {}",merchantId);
					}

				} catch (Exception e) {
					logger.info("merchantLogo to download : {}", merchantId);
				}
			}

		}

		return merchantInfoDto;
	}

}
