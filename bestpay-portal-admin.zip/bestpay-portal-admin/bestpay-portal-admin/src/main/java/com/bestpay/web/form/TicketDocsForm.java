/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.web.form;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import com.bestpay.be.sdk.constants.BaseConstants;
import com.bestpay.be.sdk.model.TrxnDocuments;
import com.bestpay.be.sdk.util.JsonTimestampSerializerDash;
import com.bestpay.dm.sdk.model.Documents;
import com.bestpay.web.dto.FileUpload;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author Atiqah Khairuddin
 * @since November 21, 2018
 */
public class TicketDocsForm implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1864073233598003483L;

	private int ticketId;

	private String merchantId;
	
	@JsonSerialize(using = JsonTimestampSerializerDash.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_DASH_TIME_A, locale = "ms_MY", timezone = "Asia/Kuala_Lumpur")
	private Timestamp issuerDate;
 
	private String name;

	private String contact;

	private String email;

	private String subject;

	private String title;

	private String description;

	private String status;

	private Timestamp modifyDate;

	private String fileName;

	private String category;

	private String supportId;

	private String cc;

	private String comment;

	private String feedback;

	private String module;

	private String createId;

	private Timestamp createDt;

	private String updateId;

	private Timestamp updateDt;

	private String userId;

	private String transactionType; // user create =C, update= U, profile
	// update = UP

	private List<FileUpload> fileUploads;

	private String docMgtId;

	// added for upload profile picture///
	private List<TrxnDocuments> trxnDocuments;

	private String refNo;

	private Documents ticketAttach;

	private String docRefNo;

	private Integer merProfId;

	private String userType;

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public List<FileUpload> getFileUploads() {
		return fileUploads;
	}

	public void setFileUploads(List<FileUpload> fileUploads) {
		this.fileUploads = fileUploads;
	}

	public String getDocMgtId() {
		return docMgtId;
	}

	public void setDocMgtId(String docMgtId) {
		this.docMgtId = docMgtId;
	}

	public List<TrxnDocuments> getTrxnDocuments() {
		return trxnDocuments;
	}

	public void setTrxnDocuments(List<TrxnDocuments> trxnDocuments) {
		this.trxnDocuments = trxnDocuments;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public int getTicketId() {
		return ticketId;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	public Timestamp getIssuerDate() {
		return issuerDate;
	}

	public void setIssuerDate(Timestamp issuerDate) {
		this.issuerDate = issuerDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Timestamp modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSupportId() {
		return supportId;
	}

	public void setSupportId(String supportId) {
		this.supportId = supportId;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Documents getTicketAttach() {
		return ticketAttach;
	}

	public void setTicketAttach(Documents ticketAttach) {
		this.ticketAttach = ticketAttach;
	}

	public String getDocRefNo() {
		return docRefNo;
	}

	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}

	public Integer getMerProfId() {
		return merProfId;
	}

	public void setMerProfId(Integer merProfId) {
		this.merProfId = merProfId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

}