package com.bestpay.be.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwMerchantCompanyBankDetails;
import com.bestpay.be.util.QualifierConstants;

@Repository
@RepositoryDefinition(domainClass = PgwMerchantCompanyBankDetails.class, idClass = Integer.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_COMPANY_BANK_DETAILS_SVC)
public interface PgwMerchantCompanyBankDetailsRepository extends GenericRepository<PgwMerchantCompanyBankDetails> {

	@Query("select u from PgwMerchantCompanyBankDetails u ")
	public PgwMerchantCompanyBankDetails findAllMerchantCompanyBankDetails();

	@Query("select count(u) from PgwMerchantCompanyBankDetails u ")
	public int totalRecords();

	@Query("select t from PgwMerchantCompanyBankDetails t where t.compRefId = :compRefId ")
	public PgwMerchantCompanyBankDetails findBeneficiaryByCompRefId(@Param("compRefId") String compRefId);
	
	@Query("select t from PgwMerchantCompanyBankDetails t where t.compBankId = :compBankId ")
	public PgwMerchantCompanyBankDetails findBeneficiaryByCompBankId(@Param("compBankId") Integer compBankId);

}
