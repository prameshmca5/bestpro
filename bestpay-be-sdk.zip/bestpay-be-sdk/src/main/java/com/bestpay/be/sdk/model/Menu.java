/**
 * Copyright 2018 Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author Atiqah Khairuddin
 * @since December 3, 2018
 */
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Menu implements Serializable {

	private static final long serialVersionUID = -6234620539956436222L;

	private String menuCode;

	private String menuDesc;


	public Menu() {
		// menu dto model
	}


	public String getMenuCode() {
		return menuCode;
	}


	public void setMenuCode(String menuCode) {
		this.menuCode = menuCode;
	}


	public String getMenuDesc() {
		return menuDesc;
	}


	public void setMenuDesc(String menuDesc) {
		this.menuDesc = menuDesc;
	}

}