package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author Chaithanya Kumar
 * @since 10/07/2018
 *
 */

public class PgwTransactionHistroyDto implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -3443448823587082521L;

	private Integer id;

	private String transId;

	private String refId;
	
	private String pinNo;

	private String channel;

	private String merchantId;

	private String submerId;

	private String exhangeId;

	private String sellerId;

	private String billingName;

	private String billingEmail;

	private String billingMobile;

	private String billingInfo;

	private String orderId;

	private Float billAmt;

	private Timestamp paymentDt;

	private Float transAmt;

	private Float transRate;

	private String actCur;

	private Float actAmt;

	private String convertCur;

	private Float convertAmt;

	private String bankCode;

	private String bankName;

	private String bankCntry;

	private String status;

	private String reqCode;

	private String resCode;

	private String resMsg;

	private Integer retryCnt;

	private String createId;

	private Timestamp createDt;

	private Timestamp updateDt;

	private String updateId;

	private String errorCode;

	private String errorDesc;

	private String payMethod;
	
	private String pid;
	
	private String beneficiaryId;
	
	private float tax;

	private String flagDummy;
	
	private float transactionFee;
	
	private Integer currencyUnit;
	
	private String paydat;
	
	private String ccName;
	
	private String ccNo;
	
	private Integer paymentId;

	

	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getTransId() {
		return transId;
	}


	public void setTransId(String transId) {
		this.transId = transId;
	}


	public String getRefId() {
		return refId;
	}


	public void setRefId(String refId) {
		this.refId = refId;
	}


	public String getPinNo() {
		return pinNo;
	}


	public void setPinNo(String pinNo) {
		this.pinNo = pinNo;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getSubmerId() {
		return submerId;
	}


	public void setSubmerId(String submerId) {
		this.submerId = submerId;
	}


	public String getExhangeId() {
		return exhangeId;
	}


	public void setExhangeId(String exhangeId) {
		this.exhangeId = exhangeId;
	}


	public String getSellerId() {
		return sellerId;
	}


	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}


	public String getBillingName() {
		return billingName;
	}


	public void setBillingName(String billingName) {
		this.billingName = billingName;
	}


	public String getBillingEmail() {
		return billingEmail;
	}


	public void setBillingEmail(String billingEmail) {
		this.billingEmail = billingEmail;
	}


	public String getBillingMobile() {
		return billingMobile;
	}


	public void setBillingMobile(String billingMobile) {
		this.billingMobile = billingMobile;
	}


	public String getBillingInfo() {
		return billingInfo;
	}


	public void setBillingInfo(String billingInfo) {
		this.billingInfo = billingInfo;
	}


	public String getOrderId() {
		return orderId;
	}


	public String getFlagDummy() {
		return flagDummy;
	}


	public String getPaydat() {
		return paydat;
	}


	public void setPaydat(String paydat) {
		this.paydat = paydat;
	}


	public void setFlagDummy(String flagDummy) {
		this.flagDummy = flagDummy;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public Float getBillAmt() {
		return billAmt;
	}


	public void setBillAmt(Float billAmt) {
		this.billAmt = billAmt;
	}


	public Timestamp getPaymentDt() {
		return paymentDt;
	}


	public void setPaymentDt(Timestamp paymentDt) {
		this.paymentDt = paymentDt;
	}


	public Float getTransAmt() {
		return transAmt;
	}


	public void setTransAmt(Float transAmt) {
		this.transAmt = transAmt;
	}


	public Float getTransRate() {
		return transRate;
	}


	public void setTransRate(Float transRate) {
		this.transRate = transRate;
	}


	public String getActCur() {
		return actCur;
	}


	public void setActCur(String actCur) {
		this.actCur = actCur;
	}


	public Float getActAmt() {
		return actAmt;
	}


	public void setActAmt(Float actAmt) {
		this.actAmt = actAmt;
	}


	public String getConvertCur() {
		return convertCur;
	}


	public void setConvertCur(String convertCur) {
		this.convertCur = convertCur;
	}


	public Float getConvertAmt() {
		return convertAmt;
	}


	public void setConvertAmt(Float convertAmt) {
		this.convertAmt = convertAmt;
	}


	public String getBankCode() {
		return bankCode;
	}


	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getBankCntry() {
		return bankCntry;
	}


	public void setBankCntry(String bankCntry) {
		this.bankCntry = bankCntry;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getReqCode() {
		return reqCode;
	}


	public void setReqCode(String reqCode) {
		this.reqCode = reqCode;
	}


	public String getResCode() {
		return resCode;
	}


	public void setResCode(String resCode) {
		this.resCode = resCode;
	}


	public String getResMsg() {
		return resMsg;
	}


	public void setResMsg(String resMsg) {
		this.resMsg = resMsg;
	}


	public Integer getRetryCnt() {
		return retryCnt;
	}


	public void setRetryCnt(Integer retryCnt) {
		this.retryCnt = retryCnt;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public String getErrorCode() {
		return errorCode;
	}


	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}


	public String getErrorDesc() {
		return errorDesc;
	}


	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}


	public String getPayMethod() {
		return payMethod;
	}


	public void setPayMethod(String payMethod) {
		this.payMethod = payMethod;
	}


	public String getPid() {
		return pid;
	}


	public void setPid(String pid) {
		this.pid = pid;
	}


	public String getBeneficiaryId() {
		return beneficiaryId;
	}


	public void setBeneficiaryId(String beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}


	public float getTax() {
		return tax;
	}


	public void setTax(float tax) {
		this.tax = tax;
	}

	public float getTransactionFee() {
		return transactionFee;
	}


	public void setTransactionFee(float transactionFee) {
		this.transactionFee = transactionFee;
	}


	public Integer getCurrencyUnit() {
		return currencyUnit;
	}


	public void setCurrencyUnit(Integer currencyUnit) {
		this.currencyUnit = currencyUnit;
	}


	public String getCcName() {
		return ccName;
	}


	public void setCcName(String ccName) {
		this.ccName = ccName;
	}


	public String getCcNo() {
		return ccNo;
	}


	public void setCcNo(String ccNo) {
		this.ccNo = ccNo;
	}


	public Integer getPaymentId() {
		return paymentId;
	}


	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}

	
}
