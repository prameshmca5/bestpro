/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.model.PgwMultiChannel;
import com.bestpay.be.model.PgwReferralMultiChannel;
import com.bestpay.be.model.RefChannel;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Channel;
import com.bestpay.be.sdk.model.MerChanSet;
import com.bestpay.be.sdk.model.MerChanSetWrapper;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;


/**
 * @author Afif Saman
 * @since July 11, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.CHAN_SET)
public class ChannelSettingRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ChannelSettingRestController.class);


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public boolean updateChannelSettings(@Valid @RequestBody MerChanSetWrapper merChanSetWrapper,
			HttpServletRequest request, HttpServletResponse response) throws BeException {

		List<RefChannel> refChannels = refChannelSvc.findAll();
		int index = 0;
		boolean isUpdated = false;
		LOGGER.info("Create new Channel Settings ... ");
		if (merChanSetWrapper == null) {// multi channel null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		List<PgwMultiChannel> multiChannel = getDeletedChannels(merChanSetWrapper);
		for (PgwMultiChannel channel : multiChannel) {
			super.pgwMultiChannelService.primaryDao().delete(channel);
		}

		for (MerChanSet channelSetting : merChanSetWrapper.getMerChanSets()) {
			PgwMultiChannel newChannel = dozerMapper.map(channelSetting, PgwMultiChannel.class);
			newChannel.setMerchantId(merChanSetWrapper.getMerchantId());
			newChannel.setEnable(1);
			newChannel.setStatus("A");
			newChannel.setCreateId(merChanSetWrapper.getUserId());
			newChannel.setUpdateId(merChanSetWrapper.getUserId());

			if (!BaseUtil.isObjNull(channelSetting.getChannel())) {
				PgwMultiChannel mulChannel = pgwMultiChannelService.findActiveMultiChannelByMerIdAndChannel(
						merChanSetWrapper.getMerchantId(), channelSetting.getChannel());
				if (!BaseUtil.isObjNull(mulChannel)) {
					if ((!BaseUtil.isObjNull(mulChannel.getRate())
							&& Double.compare(mulChannel.getRate(), channelSetting.getRate()) != 0)
							|| !BaseUtil.isObjNull(channelSetting.getRate())
							|| (!BaseUtil.isObjNull(mulChannel.getCost())
									&& Double.compare(mulChannel.getCost(), channelSetting.getCost()) != 0)
							|| !BaseUtil.isObjNull(channelSetting.getCost()) || mulChannel.getEnable() == 0) {
						mulChannel.setStatus("I");
						super.pgwMultiChannelService.update(mulChannel);
						isUpdated = true;
					}
				} else {
					super.pgwMultiChannelService.create(newChannel);
					isUpdated = true;
				}
			} else if (BaseUtil.isObjNull(channelSetting.getChannel())
					&& (!BaseUtil.isObjNull(channelSetting.getRate())
							|| !BaseUtil.isObjNull(channelSetting.getCost()))) {
				String channel = refChannels.get(index).getPublicName();
				PgwMultiChannel mulChannel = pgwMultiChannelService
						.findActiveMultiChannelByMerIdAndChannel(merChanSetWrapper.getMerchantId(), channel);
				if (!BaseUtil.isObjNull(mulChannel) && mulChannel.getEnable() == 1) {
					mulChannel.setStatus("I");
					newChannel.setEnable(0);
					newChannel.setChannel(channel);
					super.pgwMultiChannelService.update(mulChannel);
					super.pgwMultiChannelService.create(newChannel);
					isUpdated = true;
				}
			} else if (BaseUtil.isObjNull(channelSetting.getChannel())) {
				PgwMultiChannel mulChannel = pgwMultiChannelService
						.findActiveMultiChannelByMerIdAndChannel(merChanSetWrapper.getMerchantId(), null);
				if (!BaseUtil.isObjNull(mulChannel)) {
					mulChannel.setStatus("I");
					newChannel.setEnable(0);
					super.pgwMultiChannelService.update(mulChannel);
					super.pgwMultiChannelService.create(newChannel);
					isUpdated = true;
				}
			}
			index++;
		}
		if (isUpdated) {
			return true;
		}
		return isUpdated;
	}


	@GetMapping(value = "/{merchantId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerChanSetWrapper getMerChanSetWrapperById(@PathVariable String merchantId) {

		List<MerChanSet> merChanSets = new ArrayList<>();
		PgwMerchantProfile pgwMerchantProfile = pgwMerchantProfileService.findMerProfileByMerchantId(merchantId);
		MerChanSetWrapper merChanSetWrapper = new MerChanSetWrapper();
		merChanSetWrapper.setMerchantId(merchantId);
		if (pgwMerchantProfile == null) {
			return merChanSetWrapper;
		}
		List<PgwReferralMultiChannel> refChannels = pgwReferralMultiChannelService
				.findMultiChannelByCompRefId(pgwMerchantProfile.getCompanyRefId());

		List<PgwMultiChannel> multiChannel = pgwMultiChannelService.findMultiChannelByMerchantId(merchantId);
		for (PgwReferralMultiChannel refChannel : refChannels) {
			boolean match = false;
			MerChanSet merChanSet = new MerChanSet();
			for (PgwMultiChannel channel : multiChannel) {
				if (BaseUtil.isEqualsCaseIgnore(refChannel.getChannel(), channel.getChannel())) {
					match = true;
					merChanSet = dozerMapper.map(channel, MerChanSet.class);
					if (channel.getEnable() == 0) {
						merChanSet.setChannel(null);
					} else {
						merChanSetWrapper.setChannelCheck(true);
					}
				}
			}
			if (match) {
				merChanSets.add(merChanSet);
			} else {
				merChanSets.add(new MerChanSet());
			}

		}
		merChanSetWrapper.setMerChanSets(merChanSets);
		return merChanSetWrapper;
	}


	private List<PgwMultiChannel> getDeletedChannels(MerChanSetWrapper merChanSetWrapper) {
		List<PgwMultiChannel> deletedChannels = new ArrayList<>();

		List<PgwMultiChannel> merChanSets = getMatchedSets(merChanSetWrapper);

		boolean isExists = false;
		for (PgwMultiChannel channel : merChanSets) {
			for (MerChanSet channelSetting : merChanSetWrapper.getMerChanSets()) {
				if (channelSetting.getChannel() != null && channelSetting.getChannel().equals(channel.getChannel())
						&& channelSetting.getDeleted().equals("true")) {
					isExists = true;
				}
			}
			if (!isExists) {
				deletedChannels.add(channel);
			}
			isExists = false;
		}
		return deletedChannels;
	}


	private List<PgwMultiChannel> getMatchedSets(MerChanSetWrapper merChanSetWrapper) {
		List<PgwMultiChannel> merChanSets = new ArrayList<>();
		List<RefChannel> refChannels = refChannelSvc.findAll();
		List<PgwMultiChannel> multiChannel = pgwMultiChannelService
				.findMultiChannelByMerchantId(merChanSetWrapper.getMerchantId());
		for (RefChannel refChannel : refChannels) {
			boolean match = false;
			PgwMultiChannel merChanSet1 = new PgwMultiChannel();
			for (PgwMultiChannel channel : multiChannel) {
				if (BaseUtil.isEqualsCaseIgnore(refChannel.getPublicName(), channel.getChannel())) {
					match = true;
					merChanSet1 = channel;

				}
			}
			if (match) {
				merChanSets.add(merChanSet1);
			}
		}
		return merChanSets;
	}


	// @Add by Ramesh Pongiannan
	@PostMapping(value = BeUrlConstants.CHAL_LIST, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<MerChanSet> getMerChantgetWrapperById(@Valid @RequestBody MerChanSet merChanSet,
			HttpServletRequest request, HttpServletResponse response) throws BeException {
		List<MerChanSet> multichannelList = new ArrayList<>();
		String merchantId = merChanSet.getMerchantId();
		List<PgwMultiChannel> channelLst = pgwMultiChannelService.findMultiChannelByMerchantIdAndStatus(merchantId);
		if (BaseUtil.isListNullAndZero(channelLst)) {

			throw new BeException(BeErrorCodeEnum.E400PGW012, new String[] { merchantId });
		}
		for (PgwMultiChannel c : channelLst) {
			multichannelList.add(dozerMapper.map(c, MerChanSet.class));
		}
		return multichannelList;
	}


	@PostMapping(value = BeUrlConstants.CHANNEL_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<Channel> searchChannelsPaginated(@Valid @RequestBody Channel channel,
			HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<RefChannel> result = refChannelSvc.searchChannelByPagination(channel, dataTableInRQ);
		DataTableResults<Channel> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			dataTableInResp.setDraw(result.getDraw());
			dataTableInResp.setError(result.getError());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<Channel> chLst = new ArrayList<>();
				for (RefChannel bbp : result.getData()) {
					Channel chnl = dozerMapper.map(bbp, Channel.class);
					chLst.add(chnl);
				}
				dataTableInResp.setData(chLst);
			}
		}
		return dataTableInResp;
	}


	@PostMapping(value = BeUrlConstants.ADD_CHANNEL, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public boolean addChannel(@Valid @RequestBody Channel channel, HttpServletRequest request) throws BeException {
		boolean isUpdated = true;
		if (channel == null) {
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		RefChannel newChannel = dozerMapper.map(channel, RefChannel.class);
		newChannel.setPrivateName(channel.getPublicName());

		super.refChannelSvc.update(newChannel);
		return isUpdated;
	}


	@GetMapping(value = BeUrlConstants.DEL_CHANNEL + "/{channelId}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public boolean deleteChannel(@PathVariable Integer channelId, HttpServletRequest request) {
		try {
			if (channelId == null) {
				throw new BeException(BeErrorCodeEnum.E404BLC002);
			}

			super.refChannelSvc.primaryDao().delete(super.refChannelSvc.find(channelId));
			return true;
		} catch (BeException ex) {
			LOGGER.info("{}", ex.getMessage());
		}
		return false;
	}


	@GetMapping(value = BeUrlConstants.GET_CHANNEL + "/{channelId}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public Channel searchChannelById(@PathVariable Integer channelId, HttpServletRequest request) throws BeException {
		if (channelId == null) {
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		RefChannel refChannel = super.refChannelSvc.find(channelId);
		return dozerMapper.map(refChannel, Channel.class);
	}


	@GetMapping(value = BeUrlConstants.GET_CHANNEL_BYNAME + "/{publicName}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public Channel searchChannelByPublicName(@PathVariable String publicName, HttpServletRequest request)
			throws BeException {
		if (publicName == null) {
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		RefChannel refChannel = refChannelSvc.findRefChannelByPublicName(publicName);
		if (refChannel == null) {
			return null;
		}
		return dozerMapper.map(refChannel, Channel.class);
	}


	// get channel code
	@PostMapping(value = BeUrlConstants.GET_CHANNEL_PUBLIC_NAME, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<Channel> getChannelPublicName(@Valid @RequestBody Channel channel, HttpServletRequest request,
			HttpServletResponse response) {
		List<Channel> channelList = new ArrayList<>();
		String publicName = channel.getPublicName();
		List<RefChannel> refChannel = super.refChannelSvc.findChannelByPublicName(publicName);
		if (!BaseUtil.isListNullAndZero(refChannel)) {
			for (RefChannel c : refChannel) {
				channelList.add(dozerMapper.map(c, Channel.class));
			}
		}
		return channelList;
	}


	// get channel name
	@PostMapping(value = BeUrlConstants.GET_CHANNEL_NAME, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<Channel> getChannelName(@Valid @RequestBody Channel channel, HttpServletRequest request,
			HttpServletResponse response) {
		List<Channel> channelList = new ArrayList<>();
		String name = channel.getName();
		List<RefChannel> refChannel = super.refChannelSvc.findChannelByName(name);
		if (!BaseUtil.isListNullAndZero(refChannel)) {
			for (RefChannel c : refChannel) {
				channelList.add(dozerMapper.map(c, Channel.class));
			}
		}
		return channelList;
	}

}
