package com.bestpay.pgw.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.dao.PgwMerchantProviderRepository;
import com.bestpay.pgw.model.PgwMerchantProvider;
import com.bestpay.pgw.util.QualifierConstants;


@Transactional
@Service(QualifierConstants.PGW_MERCHANT_PROVIDER_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_PROVIDER_SVC)
public class PgwMerchantProviderService extends AbstractService<PgwMerchantProvider> {

	@Autowired
	private PgwMerchantProviderRepository merchantProviderDao;


	@Override
	public PgwMerchantProviderRepository primaryDao() {
		return merchantProviderDao;
	}


	public PgwMerchantProvider findByMerchantBenefId(String providerPublicName) {
		return merchantProviderDao.findPgwMerchantProviderByName(providerPublicName);
	}
}
