/**
 * 
 */
package com.be.service;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeConfigPaymentStageQf;
import com.be.dao.BeConfigPaymentStageRepository;
import com.be.model.BeConfigPaymentStage;
import com.be.sdk.model.ConfigPaymentStage;
import com.be.sdk.model.IQfCriteria;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_CONFIG_PAYMENT_STAGE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_CONFIG_PAYMENT_STAGE_SVC)
public class BeConfigPaymentStageService extends AbstractService<BeConfigPaymentStage> {

	@Autowired
	private BeConfigPaymentStageRepository beConfigPaymentStageDao;
	
	@Autowired
	BeConfigPaymentStageQf beConfigPaymentStageQf;
	
	@Override
	public GenericRepository<BeConfigPaymentStage> primaryDao() {
		return beConfigPaymentStageDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beConfigPaymentStageQf.generateCriteria(cb, from, criteria);
	}

	public BeConfigPaymentStage searchBeConfigPaymentStage(ConfigPaymentStage dto) {
		return beConfigPaymentStageQf.searchBeConfigPaymentStage(dto);
	}
}
