/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;

import com.bestpay.be.sdk.constants.BaseConstants;
import com.bestpay.be.sdk.util.JsonTimestampSerializerDash;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;


/**
 * N.N. Shuhada 05 June 2018
 */
public class Transaction implements Serializable {

	private static final long serialVersionUID = -2426654437596656263L;

	private Integer id;

	private String transId;

	private String refId;

	private String channel;

	private String merchantId;

	private String submerId;

	private String exhangeId;

	private String sellerId;

	private String billingName;

	private String billingEmail;

	private String billingMobile;

	private String billingInfo;

	private String orderId;

	private Float billAmt;

	private Timestamp paymentDt;

	private Float transAmt;

	private Float transRate;

	private String actCur;

	private Float actAmt;

	private String convertCur;

	private Float convertAmt;

	private String bankCode;

	private String bankName;

	private String bankCntry;

	private String status;

	private String reqCode;

	private String resCode;

	private String resMsg;

	private Integer retryCnt;

	private String createId;

	private Integer setId;

	private String channelName;

	@JsonSerialize(using = JsonTimestampSerializerDash.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_DASH_TIME_A)
	private Timestamp createDt;

	private Timestamp updateDt;

	private String updateId;

	private String appCode;

	private String fraudScan;

	private Integer fraudScore;

	private String memo;

	@JsonSerialize(using = JsonTimestampSerializerDash.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_DASH_TIME_A)
	private Timestamp createDate;

	private String txnId;

	private String top10;

	private Float transFee;

	private Float tax;

	private Integer curUnit;

	private String pinNo;

	private String paymentType;


	public Transaction() {
		// transaction dto model
	}


	public String getChannelName() {
		return channelName;
	}


	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getTransId() {
		return transId;
	}


	public void setTransId(String transId) {
		this.transId = transId;
	}


	public String getRefId() {
		return refId;
	}


	public void setRefId(String refId) {
		this.refId = refId;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getSubmerId() {
		return submerId;
	}


	public void setSubmerId(String submerId) {
		this.submerId = submerId;
	}


	public String getExhangeId() {
		return exhangeId;
	}


	public void setExhangeId(String exhangeId) {
		this.exhangeId = exhangeId;
	}


	public String getSellerId() {
		return sellerId;
	}


	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}


	public String getBillingName() {
		return billingName;
	}


	public void setBillingName(String billingName) {
		this.billingName = billingName;
	}


	public String getBillingEmail() {
		return billingEmail;
	}


	public void setBillingEmail(String billingEmail) {
		this.billingEmail = billingEmail;
	}


	public String getBillingMobile() {
		return billingMobile;
	}


	public void setBillingMobile(String billingMobile) {
		this.billingMobile = billingMobile;
	}


	public String getBillingInfo() {
		return billingInfo;
	}


	public void setBillingInfo(String billingInfo) {
		this.billingInfo = billingInfo;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public Float getBillAmt() {
		return billAmt;
	}


	public void setBillAmt(Float billAmt) {
		this.billAmt = billAmt;
	}


	public Timestamp getPaymentDt() {
		return paymentDt;
	}


	public void setPaymentDt(Timestamp paymentDt) {
		this.paymentDt = paymentDt;
	}


	public Float getTransAmt() {
		return transAmt;
	}


	public void setTransAmt(Float transAmt) {
		this.transAmt = transAmt;
	}


	public Float getTransRate() {
		return transRate;
	}


	public void setTransRate(Float transRate) {
		this.transRate = transRate;
	}


	public String getActCur() {
		return actCur;
	}


	public void setActCur(String actCur) {
		this.actCur = actCur;
	}


	public Float getActAmt() {
		return actAmt;
	}


	public void setActAmt(Float actAmt) {
		this.actAmt = actAmt;
	}


	public String getConvertCur() {
		return convertCur;
	}


	public void setConvertCur(String convertCur) {
		this.convertCur = convertCur;
	}


	public Float getConvertAmt() {
		return convertAmt;
	}


	public void setConvertAmt(Float convertAmt) {
		this.convertAmt = convertAmt;
	}


	public String getBankCode() {
		return bankCode;
	}


	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getBankCntry() {
		return bankCntry;
	}


	public void setBankCntry(String bankCntry) {
		this.bankCntry = bankCntry;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getReqCode() {
		return reqCode;
	}


	public void setReqCode(String reqCode) {
		this.reqCode = reqCode;
	}


	public String getResCode() {
		return resCode;
	}


	public void setResCode(String resCode) {
		this.resCode = resCode;
	}


	public String getResMsg() {
		return resMsg;
	}


	public void setResMsg(String resMsg) {
		this.resMsg = resMsg;
	}


	public Integer getRetryCnt() {
		return retryCnt;
	}


	public void setRetryCnt(Integer retryCnt) {
		this.retryCnt = retryCnt;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public String getAppCode() {
		return appCode;
	}


	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}


	public String getFraudScan() {
		return fraudScan;
	}


	public void setFraudScan(String fraudScan) {
		this.fraudScan = fraudScan;
	}


	public Integer getFraudScore() {
		return fraudScore;
	}


	public void setFraudScore(Integer fraudScore) {
		this.fraudScore = fraudScore;
	}


	public String getMemo() {
		return memo;
	}


	public void setMemo(String memo) {
		this.memo = memo;
	}


	public Timestamp getCreateDate() {
		return createDate;
	}


	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}


	public String getTxnId() {
		return txnId;
	}


	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}


	public String getTop10() {
		return top10;
	}


	public void setTop10(String top10) {
		this.top10 = top10;
	}


	public Integer getSetId() {
		return setId;
	}


	public void setSetId(Integer setId) {
		this.setId = setId;
	}


	public Float getTransFee() {
		return transFee;
	}


	public void setTransFee(Float transFee) {
		this.transFee = transFee;
	}


	public Float getTax() {
		return tax;
	}


	public void setTax(Float tax) {
		this.tax = tax;
	}


	public Integer getCurUnit() {
		return curUnit;
	}


	public void setCurUnit(Integer curUnit) {
		this.curUnit = curUnit;
	}


	public String getPinNo() {
		return pinNo;
	}


	public void setPinNo(String pinNo) {
		this.pinNo = pinNo;
	}


	public String getPaymentType() {
		return paymentType;
	}


	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

}