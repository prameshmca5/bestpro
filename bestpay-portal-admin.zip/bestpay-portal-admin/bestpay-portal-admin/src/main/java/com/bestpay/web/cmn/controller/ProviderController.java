package com.bestpay.web.cmn.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Channel;
import com.bestpay.be.sdk.model.Provider;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;


@Controller
@RequestMapping(value = PageConstants.PAGE_PROVIDER_LIST)
public class ProviderController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProviderController.class);

	private static final String PROVIDER = "provider";

	private static final String PROVIDER_LIST_SCRIPT = "provider-list-script";

	private static final String CHANNEL_LIST = "channelList";

	private static final String COUNTRY_LIST = "countryList";

	private static final String STATE_LIST = "stateList";

	private static final String CITY_LIST = "cityList";

	@Autowired
	@Qualifier("providerValidator")
	private Validator providerValidator;


	@Override
	protected void bindingPreparation(WebDataBinder binder) {
		binder.setValidator(providerValidator);
		super.bindingPreparation(binder);
	}


	/**
	 * View Provider List
	 *
	 * @param provider
	 */
	@GetMapping
	public ModelAndView providerList(Provider provider, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_PROVIDER_LIST, PROVIDER, null, PROVIDER_LIST_SCRIPT);
		mav.addObject(PROVIDER, provider);

		return mav;
	}


	/**
	 * Get Provider List paginated
	 *
	 * @param provider
	 */
	@GetMapping(value = "/paginated")
	public @ResponseBody String searchPaginated(@ModelAttribute(PROVIDER) Provider provider,
			HttpServletRequest request) throws BeException {
		getDefaultMav(PageTemplate.TEMP_PROVIDER_LIST, PROVIDER, null, PROVIDER_LIST_SCRIPT);
		DataTableResults<Provider> tasks = getBeService().searchProvider(provider,
				getPaginationRequest(request, true));
		return new Gson().toJson(tasks);
	}


	/**
	 * Search Provider List
	 *
	 * @param merchantCompany
	 */
	@PostMapping(params = "search")
	public ModelAndView search(Provider provider, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_PROVIDER_LIST, PROVIDER, null, PROVIDER_LIST_SCRIPT);
		LOGGER.info("search provider");
		mav.addObject(PROVIDER, provider);
		return mav;
	}


	/**
	 * Reset search Provider List
	 *
	 * @param provider
	 * @throws BeException
	 */
	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute(PROVIDER) @Validated Provider provider, BindingResult result,
			HttpServletRequest request, HttpSession session) {
		Provider prov = new Provider();
		LOGGER.info("--reset--");
		return providerList(prov, result, request, session);
	}


	/**
	 * View Provider create form
	 *
	 * @param provider
	 */
	@GetMapping(value = "/new")
	public ModelAndView newProvider(Provider provider, BindingResult result, HttpServletRequest request,
			HttpSession session) throws BeException {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_PROVIDER_NEW);
		List<Channel> channelList = getBeService().getRefChannelList();
		mav.addObject(CHANNEL_LIST, channelList);
		mav.addObject(COUNTRY_LIST, staticData.countryList());
		mav.addObject(STATE_LIST, staticData.stateList("MYS"));
		mav.addObject(CITY_LIST, staticData.cityList());
		return mav;
	}


	/**
	 * Save new Provider
	 *
	 * @param provider
	 */
	@PostMapping(value = "/addProvider", params = "createProviderInfo")
	public ModelAndView addNewProvider(@Valid @ModelAttribute("provider") Provider provider, BindingResult result,
			HttpServletRequest request, HttpSession session) throws BeException {
		ModelAndView mav = newProvider(provider, result, request, session);
		UserProfile authUser = getCurrentUser();
		new Provider();
		List<Provider> ssmId = getBeService().getProviderSsmId(provider);
		List<Provider> providerPublicName = getBeService().getProviderPublicName(provider);
		int ssmIdSize = ssmId.size();
		int providerPublicNameSize = providerPublicName.size();
		if (ssmIdSize > 0 || providerPublicNameSize > 0) {
			List<Channel> channelList = getBeService().getRefChannelList();
			mav.addObject(CHANNEL_LIST, channelList);
			mav.addObject(COUNTRY_LIST, staticData.countryList());
			mav.addObject(STATE_LIST, staticData.stateList("MYS"));
			mav.addObject(CITY_LIST, staticData.cityList());
			mav.addAllObjects(com.bstsb.util.PopupBox.error("createdError", null,
					messageService.getMessage(MessageConstants.ERROR_FIELDS_PROVIDER_SSM_ID_EXISTS)));
		} else {
			if (result.hasErrors()) {
				return newProvider(provider, result, request, session);
			}
			provider.setCreateId(authUser.getUserId());
			try {
				if (BaseUtil.isEqualsCaseIgnore(provider.getCountry(), "MYS")) {
					provider.setState(provider.getStateMy());
					provider.setCity(provider.getCityMy());
				} else {
					provider.setState(provider.getStateNonMy());
					provider.setCity(provider.getCityNonMy());
				}
				getBeService().addProvider(provider);
				mav.addAllObjects(PopupBox.success(PROVIDER, null,
						messageService.getMessage(MessageConstants.SUCC_CREATE_PROVIDER),
						PageConstants.PAGE_PROVIDER_LIST));
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
		return mav;
	}


	/**
	 * View merchant company update form
	 *
	 * @param provId
	 */
	@GetMapping(value = "/update/{provId}")
	public ModelAndView updateProvider(@PathVariable("provId") Integer provId, HttpServletRequest request,
			HttpSession session) throws BeException {
		Provider provider = getBeService().getProviderById(provId);
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_PROVIDER_NEW);
		List<Channel> channelList = getBeService().getRefChannelList();
		mav.addObject(PROVIDER, provider);
		mav.addObject(CHANNEL_LIST, channelList);
		mav.addObject(COUNTRY_LIST, staticData.countryList());
		mav.addObject(STATE_LIST, staticData.stateList("MYS"));
		mav.addObject(CITY_LIST, staticData.cityList());
		return mav;
	}


	/**
	 * update existing Provider
	 *
	 * @param provider
	 */
	@PostMapping(value = "/addProvider", params = "updateProviderInfo")
	public ModelAndView updateProvider(@Valid @ModelAttribute("provider") Provider provider, BindingResult result,
			HttpServletRequest request, HttpSession session) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_PROVIDER_NEW);
		UserProfile authUser = getCurrentUser();
		List<Channel> channelList = getBeService().getRefChannelList();
		provider.setUpdateId(authUser.getUserId());
		boolean isCreated = false;
		if (result.hasErrors()) {
			return newProvider(provider, result, request, session);
		}
		try {
			if (BaseUtil.isEqualsCaseIgnore(provider.getCountry(), "MYS")) {
				provider.setState(provider.getStateMy());
				provider.setCity(provider.getCityMy());
			} else {
				provider.setState(provider.getStateNonMy());
				provider.setCity(provider.getCityNonMy());
			}
			getBeService().addProvider(provider);

			isCreated = true;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		if (isCreated) {
			mav.addAllObjects(PopupBox.success(PROVIDER, null,
					messageService.getMessage(MessageConstants.SUCC_UPDATE_PROVIDER),
					PageConstants.PAGE_PROVIDER_LIST));
		} else {
			return newProvider(provider, result, request, session);
		}
		mav.addObject(PROVIDER, provider);
		mav.addObject(CHANNEL_LIST, channelList);
		mav.addObject(COUNTRY_LIST, staticData.countryList());
		mav.addObject(STATE_LIST, staticData.stateList("MYS"));
		mav.addObject(CITY_LIST, staticData.cityList());
		return mav;
	}

}
