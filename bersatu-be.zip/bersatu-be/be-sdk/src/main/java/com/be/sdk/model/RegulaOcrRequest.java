/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.util.List;


/**
 * @author nurul.naimma
 *
 * @since Jun 2, 2021
 */
public class RegulaOcrRequest implements Serializable {

	private static final long serialVersionUID = -5821881795821497122L;

	private String scenario;

	private List<Object> resultTypeOutput;

	private Boolean doublePageSpread;

	private Boolean log;

	private String image;

	private String format;

	private int light;

	private int page_idx;

	private Object systemInfo;

	private boolean embedImage;


	/**
	 * @return the scenario
	 */
	public String getScenario() {
		return scenario;
	}


	/**
	 * @param scenario
	 *             the scenario to set
	 */
	public void setScenario(String scenario) {
		this.scenario = scenario;
	}


	/**
	 * @return the resultTypeOutput
	 */
	public List<Object> getResultTypeOutput() {
		return resultTypeOutput;
	}


	/**
	 * @param resultTypeOutput
	 *             the resultTypeOutput to set
	 */
	public void setResultTypeOutput(List<Object> resultTypeOutput) {
		this.resultTypeOutput = resultTypeOutput;
	}


	/**
	 * @return the doublePageSpread
	 */
	public Boolean getDoublePageSpread() {
		return doublePageSpread;
	}


	/**
	 * @param doublePageSpread
	 *             the doublePageSpread to set
	 */
	public void setDoublePageSpread(Boolean doublePageSpread) {
		this.doublePageSpread = doublePageSpread;
	}


	/**
	 * @return the log
	 */
	public Boolean getLog() {
		return log;
	}


	/**
	 * @param log
	 *             the log to set
	 */
	public void setLog(Boolean log) {
		this.log = log;
	}


	/**
	 * @return the image
	 */
	public String getImage() {
		return image;
	}


	/**
	 * @param image
	 *             the image to set
	 */
	public void setImage(String image) {
		this.image = image;
	}


	/**
	 * @return the format
	 */
	public String getFormat() {
		return format;
	}


	/**
	 * @param format
	 *             the format to set
	 */
	public void setFormat(String format) {
		this.format = format;
	}


	/**
	 * @return the light
	 */
	public int getLight() {
		return light;
	}


	/**
	 * @param light
	 *             the light to set
	 */
	public void setLight(int light) {
		this.light = light;
	}


	/**
	 * @return the page_idx
	 */
	public int getPage_idx() {
		return page_idx;
	}


	/**
	 * @param page_idx
	 *             the page_idx to set
	 */
	public void setPage_idx(int page_idx) {
		this.page_idx = page_idx;
	}


	/**
	 * @return the systemInfo
	 */
	public Object getSystemInfo() {
		return systemInfo;
	}


	/**
	 * @param systemInfo
	 *             the systemInfo to set
	 */
	public void setSystemInfo(Object systemInfo) {
		this.systemInfo = systemInfo;
	}


	/**
	 * @return the embedImage
	 */
	public boolean isEmbedImage() {
		return embedImage;
	}


	/**
	 * @param embedImage
	 *             the embedImage to set
	 */
	public void setEmbedImage(boolean embedImage) {
		this.embedImage = embedImage;
	}

}
