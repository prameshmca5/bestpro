/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class TimeZone implements Serializable, IQfCriteria<TimeZone> {

	private static final long serialVersionUID = -6255425222614429634L;

	private String tzid;

	private String utcCode;

	private String timeZoneId;

	private String timeZoneDesc;

	private String cntryCd;


	public TimeZone() {
	}


	public String getTzid() {
		return tzid;
	}


	public void setTzid(String tzid) {
		this.tzid = tzid;
	}


	public String getUtcCode() {
		return utcCode;
	}


	public void setUtcCode(String utcCode) {
		this.utcCode = utcCode;
	}


	public String getTimeZoneId() {
		return timeZoneId;
	}


	public void setTimeZoneId(String timeZoneId) {
		this.timeZoneId = timeZoneId;
	}


	public String getTimeZoneDesc() {
		return timeZoneDesc;
	}


	public void setTimeZoneDesc(String timeZoneDesc) {
		this.timeZoneDesc = timeZoneDesc;
	}


	public String getCntryCd() {
		return cntryCd;
	}


	public void setCntryCd(String cntryCd) {
		this.cntryCd = cntryCd;
	}

}