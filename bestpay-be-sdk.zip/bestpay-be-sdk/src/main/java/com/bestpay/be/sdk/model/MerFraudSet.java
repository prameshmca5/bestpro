/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;


/**
 * @author Atiqah
 * @since June 7, 2018
 */
public class MerFraudSet implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1864073233598003483L;

	private String merchantId;

	private Integer maxallowFraudscore;

	private String allowMyIp;

	private String allowMyCc;

	private String allowIpccMatch;

	private String userId;


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public Integer getMaxallowFraudscore() {
		return maxallowFraudscore;
	}


	public void setMaxallowFraudscore(Integer maxallowFraudscore) {
		this.maxallowFraudscore = maxallowFraudscore;
	}


	public String getAllowMyIp() {
		return allowMyIp;
	}


	public void setAllowMyIp(String allowMyIp) {
		this.allowMyIp = allowMyIp;
	}


	public String getAllowMyCc() {
		return allowMyCc;
	}


	public void setAllowMyCc(String allowMyCc) {
		this.allowMyCc = allowMyCc;
	}


	public String getAllowIpccMatch() {
		return allowIpccMatch;
	}


	public void setAllowIpccMatch(String allowIpccMatch) {
		this.allowIpccMatch = allowIpccMatch;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}

}