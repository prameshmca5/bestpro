/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidSubscriberUser;
import com.bestid.be.qf.BidSubscriberUserQf;
import com.bestid.be.repo.BidSubscriberUserRepository;
import com.bestid.be.repo.GenericRepository;


/**
 * @author mukhlis.hamzah
 * @since 1 Mar 2019
 */
@Transactional
@Service(QualifierConstants.BID_SUBSCRIBER_USER_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_SUBSCRIBER_USER_SVC)
public class BidSubscriberUserService extends AbstractService<BidSubscriberUser> {

	@Autowired
	@Qualifier(QualifierConstants.BID_SUBSCRIBER_USER_REPOSITORY)
	BidSubscriberUserRepository bidSubscriberUserDao;

	@Autowired
	@Qualifier(QualifierConstants.BID_SUBSCRIBER_USER_QF)
	BidSubscriberUserQf bidSubscriberUserQf;


	@Override
	public GenericRepository<BidSubscriberUser> primaryDao() {
		return bidSubscriberUserDao;
	}


	public BidSubscriberUser findBySubIdNPhoneNo(int subscrId, String mobileNo) {
		return bidSubscriberUserDao.findBySubIdNPhoneNo(subscrId, mobileNo);
	}


	public BidSubscriberUser findByProfIdNPhoneNo(int secUserId, String mobileNo) {
		return bidSubscriberUserDao.findByProfIdNPhoneNo(secUserId, mobileNo);
	}


	public List<BidSubscriberUser> findBySubscId(int subscrId, int deviceId, int secUserId) {
		return bidSubscriberUserDao.findBySubscId(subscrId, deviceId, secUserId);
	}


	public List<BidSubscriberUser> searchByProperty(BidSubscriberUser bidSubscriberUser) {
		return bidSubscriberUserDao.findAll(bidSubscriberUserQf.searchByProperty(bidSubscriberUser));
	}
}
