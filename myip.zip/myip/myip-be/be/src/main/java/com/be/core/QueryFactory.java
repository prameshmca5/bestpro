/**
 * Copyright 2019
 */
package com.be.core;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;
import com.util.pagination.PaginationCriteria;
import com.util.pagination.SortOrder;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 17, 2016
 */
public abstract class QueryFactory<T> {

	public abstract Specification<T> searchByProperty(T t);


	public abstract List<T> searchAllByProperty(T t);


	public abstract List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria);


	@SuppressWarnings("unchecked")
	protected List<Order> getOrderByClause(CriteriaBuilder cb, From<?, ?> from, PaginationCriteria pagination) {
		List<Order> orderList = new ArrayList<>();
		if (!pagination.isSortByEmpty()) {
			Iterator<Entry<String, SortOrder>> sbit = pagination.getSortBy().getSortBys().entrySet().iterator();
			while (sbit.hasNext()) {
				Map.Entry<String, SortOrder> pair = sbit.next();
				String[] colList = pair.getKey().split("\\.");
				Path<Object> path = null;
				String colName = null;
				if(colList.length == 2) {
					if(colList[0].contains("[")) {
						 colList[0] = colList[0].substring(0, colList[0].indexOf("["));
					}
					path = (Path<Object>) from.fetch(colList[0]); 
					colName = colList[1];
				}else if(colList.length == 3) {
					if(colList[1].contains("[")) {
						colList[1] = colList[1].substring(0, colList[1].indexOf("["));
					}
					path = (Path<Object>) from.fetch(colList[0]).fetch(colList[1]); 
					colName = colList[2];
				}
				if (BaseUtil.isEqualsCaseIgnoreAny("asc", pair.getValue().toString())) {
					if(pair.getKey().contains(".")) {
						if(!BaseUtil.isObjNull(colName)) { 
							orderList.add(cb.asc(path.get(colName)));
//							orderList.add(cb.asc(from.get(colName[0]).get(colName[1])));
						}
					}else {
						orderList.add(cb.asc(from.get(pair.getKey())));
					}
				} else if (BaseUtil.isEqualsCaseIgnoreAny("desc", pair.getValue().toString())) {
					if(pair.getKey().contains(".")) {
						if(!BaseUtil.isObjNull(colName)) { 
							orderList.add(cb.desc(path.get(colName)));
//							orderList.add(cb.desc(from.get(colName[0]).get(colName[1])));
						}
					}else {
						orderList.add(cb.desc(from.get(pair.getKey())));
					}
				}
			}
		}
		return orderList;
	}

}
