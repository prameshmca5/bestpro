/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dialect.constants;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.thymeleaf.dom.Element;
import org.thymeleaf.dom.Node;
import org.thymeleaf.dom.Text;
import org.thymeleaf.util.StringUtils;

import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.util.MessageService;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class ElementHelper {

	private ElementHelper() {
		throw new IllegalStateException("Utility class");
	}


	private static final Logger LOGGER = LoggerFactory.getLogger(ElementHelper.class);

	private static final String ACCEPT = "accept";

	private static final String EMAIL = "email";

	private static final String FILE_UPLOAD = "fileupload";

	private static final String HIDDEN = "hidden";

	private static final String LBL_CHNG_FILE = "lbl.chng.file";

	private static final String LBL_SLCT_FILE = "lbl.slct.file";

	private static final String MOBILE = "mobile";

	private static final String ONCLICK = "onclick";

	private static final String PLACEHOLDER = "placeholder";

	private static final String TH_FIELD = "th:field";

	private static final String TH_ONCLICK = "th:onclick";

	private static final String TH_TITLE = "th:title";

	private static final String VERIFY = "verify";


	public static Element processOTP(Element element, MessageService messageService) {
		Element otp = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_DIV, false);
		otp.clearChildren();

		final Element inputMobile = new Element(ElementConstants.HTML_INPUT);
		inputMobile.setAttribute(AttributeConstants.ATTR_ID, "otpMobile");
		inputMobile.setAttribute(AttributeConstants.ATTR_CLASS, ElementEnum.INPUT.getStyle());
		inputMobile.setAttribute(AttributeConstants.ATTR_TYPE, AttributeConstants.ATTR_TYPE_HIDDEN);

		if (!StringUtils.isEmptyOrWhitespace(otp.getAttributeValue(MOBILE))) {
			inputMobile.setAttribute(AttributeConstants.ATTR_TH_VALUE, otp.getAttributeValue(MOBILE));
			otp.removeAttribute(MOBILE);
		}

		final Element input = new Element(ElementConstants.HTML_INPUT);
		input.setAttribute(AttributeConstants.ATTR_ID, "otpEmail");
		input.setAttribute(AttributeConstants.ATTR_CLASS, ElementEnum.INPUT.getStyle());
		input.setAttribute(AttributeConstants.ATTR_TYPE, AttributeConstants.ATTR_TYPE_HIDDEN);

		if (!StringUtils.isEmptyOrWhitespace(otp.getAttributeValue(EMAIL))) {
			input.setAttribute(AttributeConstants.ATTR_TH_VALUE, otp.getAttributeValue(EMAIL));
			otp.removeAttribute(EMAIL);
		}

		final Element span = new Element(ElementConstants.HTML_SPAN);
		span.setAttribute(AttributeConstants.ATTR_ID, "requestTacLink");
		span.setAttribute(AttributeConstants.ATTR_CLASS, "btn btn-default");
		span.setAttribute(AttributeConstants.ATTR_VALUE, VERIFY);
		span.addChild(new Text(messageService.getMessage("btn.cmn.ver")));

		final Element errLbl = new Element(ElementConstants.HTML_P);
		errLbl.setAttribute(AttributeConstants.ATTR_CLASS, "errors");
		errLbl.setAttribute(AttributeConstants.ATTR_ID, "lblEmailRequired");

		final Element otpVal = new Element(ElementConstants.HTML_INPUT);
		otpVal.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		otpVal.setAttribute(AttributeConstants.ATTR_ID, "otpVal");
		otpVal.setAttribute(AttributeConstants.ATTR_TH_VALUE, "${isOptVal}");

		final Element otpType = new Element(ElementConstants.HTML_INPUT);
		otpType.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		otpType.setAttribute(AttributeConstants.ATTR_ID, "otpType");
		otpType.setAttribute(AttributeConstants.ATTR_TH_VALUE, "otp");

		otp.addChild(input);
		otp.addChild(inputMobile);
		otp.addChild(span);
		otp.getParent().addChild(errLbl);
		otp.getParent().addChild(otpVal);
		otp.getParent().addChild(otpType);
		otp.setRecomputeProcessorsImmediately(true);
		return otp;
	}


	public static Element processOTPEmail(Element element, MessageService messageService) {
		Element otp = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_DIV, false);
		otp.clearChildren();

		final Element input = new Element(ElementConstants.HTML_INPUT);
		input.setAttribute(AttributeConstants.ATTR_ID, "otpEmail");
		input.setAttribute(AttributeConstants.ATTR_CLASS, ElementEnum.INPUT.getStyle());
		input.setAttribute(AttributeConstants.ATTR_TYPE, AttributeConstants.ATTR_TYPE_TEXT);

		if (!StringUtils.isEmptyOrWhitespace(otp.getAttributeValue(TH_FIELD))) {
			input.setAttribute(TH_FIELD, otp.getAttributeValue(TH_FIELD));
			otp.removeAttribute(TH_FIELD);
		}

		final Element spanReset = new Element(ElementConstants.HTML_SPAN);
		spanReset.setAttribute(AttributeConstants.ATTR_ID, "rstOtpEmail");
		spanReset.setAttribute(AttributeConstants.ATTR_CLASS, "input-group-addon btn btn-default");
		spanReset.setAttribute(AttributeConstants.ATTR_VALUE, VERIFY);
		spanReset.setAttribute("style", "display:none");

		final Element refresh = new Element(ElementConstants.HTML_I);
		refresh.setAttribute(AttributeConstants.ATTR_CLASS, "fa fa-refresh");
		spanReset.addChild(refresh);

		final Element span = new Element(ElementConstants.HTML_SPAN);
		span.setAttribute(AttributeConstants.ATTR_ID, "requestTacLink");
		span.setAttribute(AttributeConstants.ATTR_CLASS, "input-group-addon btn btn-default");
		span.setAttribute(AttributeConstants.ATTR_VALUE, VERIFY);
		span.addChild(new Text(messageService.getMessage("btn.cmn.activate")));

		final Element errLbl = new Element(ElementConstants.HTML_P);
		errLbl.setAttribute(AttributeConstants.ATTR_CLASS, "errors");
		errLbl.setAttribute(AttributeConstants.ATTR_ID, "lblEmailRequired");

		final Element otpVal = new Element(ElementConstants.HTML_INPUT);
		otpVal.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		otpVal.setAttribute(AttributeConstants.ATTR_ID, "otpVal");
		otpVal.setAttribute(AttributeConstants.ATTR_TH_VALUE, "${isOptVal}");

		final Element otpType = new Element(ElementConstants.HTML_INPUT);
		otpType.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		otpType.setAttribute(AttributeConstants.ATTR_ID, "otpType");
		otpType.setAttribute(AttributeConstants.ATTR_TH_VALUE, EMAIL);

		otp.addChild(input);
		otp.addChild(spanReset);
		otp.addChild(span);
		otp.getParent().addChild(errLbl);
		otp.getParent().addChild(otpVal);
		otp.getParent().addChild(otpType);
		otp.setRecomputeProcessorsImmediately(true);
		return otp;
	}


	public static Element processPortlet(Element element) {
		Element portlet = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_DIV, false);
		portlet.clearChildren();

		final Element spanBody = new Element(ElementConstants.HTML_DIV);
		spanBody.setAttribute(AttributeConstants.ATTR_CLASS, "span12");

		final Element grid = new Element(ElementConstants.HTML_DIV);
		grid.setAttribute(AttributeConstants.ATTR_CLASS, "grid simple");

		final Element portletBody = new Element(ElementConstants.HTML_DIV);
		portletBody.setAttribute(AttributeConstants.ATTR_CLASS, "grid-body");

		List<Element> nodeLst = element.getElementChildren();
		for (Element node : nodeLst) {
			portletBody.addChild(node);
		}

		if (element.getAttributeValue(AttributeConstants.ATTR_TITLE) != null
				|| element.getAttributeValue(TH_TITLE) != null) {
			final Element portletHeader = new Element(ElementConstants.HTML_DIV);
			portletHeader.setAttribute(AttributeConstants.ATTR_CLASS, "grid-title no-border");

			final Element portletTitle = new Element(ElementConstants.HTML_H4);
			portletTitle.setAttribute(AttributeConstants.ATTR_CLASS, "semi-bold");

			if (element.getAttributeValue(AttributeConstants.ATTR_TITLE) != null) {
				portletTitle.addChild(new Text(element.getAttributeValue(AttributeConstants.ATTR_TITLE)));
			} else if (element.getAttributeValue(TH_TITLE) != null) {
				portletTitle.setAttribute(TH_TITLE, element.getAttributeValue(TH_TITLE));
			}

			final Element divTools = new Element(ElementConstants.HTML_DIV);
			divTools.setAttribute(AttributeConstants.ATTR_CLASS, "tools");

			final Element aTools = new Element(ElementConstants.HTML_ANCHOR);
			aTools.setAttribute(AttributeConstants.ATTR_CLASS, "collapse");
			aTools.setAttribute(AttributeConstants.ATTR_HREF, "javascript:;");
			divTools.insertChild(0, aTools);

			portletHeader.insertChild(0, portletTitle);
			portletHeader.insertChild(1, divTools);
			portletHeader.setRecomputeProcessorsImmediately(true);

			grid.removeAttribute(AttributeConstants.ATTR_TITLE);
			grid.insertChild(0, portletHeader);
			grid.insertChild(1, portletBody);
			grid.setRecomputeProcessorsImmediately(true);
		} else {
			grid.insertChild(0, portletBody);
		}
		spanBody.insertChild(0, grid);
		portlet.insertChild(0, spanBody);
		portlet.setRecomputeProcessorsImmediately(true);
		return portlet;
	}


	public static Element processTimePicker(Element element) {
		final Element inpGrp = new Element(ElementConstants.HTML_DIV);
		inpGrp.setAttribute(AttributeConstants.ATTR_CLASS, "input-group bootstrap-timepicker");

		final Element addOn = new Element(ElementConstants.HTML_SPAN);
		addOn.setAttribute(AttributeConstants.ATTR_CLASS, "input-group-addon");

		final Element icon = new Element(ElementConstants.HTML_I);
		icon.setAttribute(AttributeConstants.ATTR_CLASS, "fa fa-clock-o");

		addOn.insertChild(0, icon);
		inpGrp.insertChild(0, element);
		inpGrp.insertChild(1, addOn);

		inpGrp.setRecomputeProcessorsImmediately(true);
		return inpGrp;
	}


	public static Element processDatePicker(Element element) {
		final Element inpGrp = new Element(ElementConstants.HTML_DIV);
		inpGrp.setAttribute(AttributeConstants.ATTR_CLASS, "input-group date");
		inpGrp.setAttribute(AttributeConstants.ATTR_ID, element.getAttributeValue("id"));

		final Element addOn = new Element(ElementConstants.HTML_SPAN);
		addOn.setAttribute(AttributeConstants.ATTR_CLASS, "input-group-addon cursor-pointer");

		final Element icon = new Element(ElementConstants.HTML_I);
		icon.setAttribute(AttributeConstants.ATTR_CLASS, "fa fa-calendar");

		addOn.insertChild(0, icon);
		inpGrp.insertChild(0, element);
		inpGrp.insertChild(1, addOn);

		inpGrp.setRecomputeProcessorsImmediately(true);
		return inpGrp;
	}


	public static Element processRadioButton(Element element) {
		final Element inpGrp = new Element(ElementConstants.HTML_LABEL);
		inpGrp.setAttribute(AttributeConstants.ATTR_CLASS, "radio-inline");
		inpGrp.insertChild(0, element);
		inpGrp.setRecomputeProcessorsImmediately(true);
		return inpGrp;
	}


	public static Element processCheckboxButton(Element element) {
		final Element inpGrp = new Element(ElementConstants.HTML_LABEL);
		inpGrp.setAttribute(AttributeConstants.ATTR_CLASS, "checkbox-inline");
		inpGrp.insertChild(0, element);
		inpGrp.setRecomputeProcessorsImmediately(true);
		return inpGrp;
	}


	public static Element processFileButton(Element element, MessageService messageService) {
		Element file = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_DIV, false);
		file.setAttribute(AttributeConstants.ATTR_DATA_PROVIDES, "fileinput");
		String attrClass = file.getAttributeValue(AttributeConstants.ATTR_CLASS);

		final Element spanfile = new Element(ElementConstants.HTML_SPAN);
		spanfile.setAttribute(AttributeConstants.ATTR_CLASS, "btn btn-white btn-cons btn-file");

		final Element spanfileNew = new Element(ElementConstants.HTML_SPAN);
		spanfileNew.setAttribute(AttributeConstants.ATTR_CLASS, "fileinput-new");
		spanfileNew.addChild(new Text(messageService.getMessage(LBL_SLCT_FILE)));

		final Element spanfileExsts = new Element(ElementConstants.HTML_SPAN);
		spanfileExsts.setAttribute(AttributeConstants.ATTR_CLASS, "fileinput-exists");
		spanfileExsts.addChild(new Text(messageService.getMessage(LBL_CHNG_FILE)));

		final Element fileInput = new Element(ElementConstants.HTML_INPUT);
		fileInput.setAttribute(AttributeConstants.ATTR_TYPE, "file");
		fileInput.setAttribute(AttributeConstants.ATTR_NAME, "...");
		if (!StringUtils.isEmptyOrWhitespace(file.getAttributeValue(TH_FIELD))) {
			fileInput.setAttribute(TH_FIELD, file.getAttributeValue(TH_FIELD));
			file.removeAttribute(TH_FIELD);
		}
		if (!StringUtils.isEmptyOrWhitespace(file.getAttributeValue(ACCEPT))) {
			fileInput.setAttribute(ACCEPT, file.getAttributeValue(ACCEPT));
			file.removeAttribute(ACCEPT);
		}

		spanfile.addChild(spanfileNew);
		spanfile.addChild(spanfileExsts);
		spanfile.addChild(fileInput);

		final Element spanFileName = new Element(ElementConstants.HTML_SPAN);
		spanFileName.setAttribute(AttributeConstants.ATTR_CLASS, "fileinput-filename");
		if (!StringUtils.isEmptyOrWhitespace(file.getAttributeValue(PLACEHOLDER))) {
			spanFileName.addChild(new Text(file.getAttributeValue(PLACEHOLDER)));
			file.setAttribute(AttributeConstants.ATTR_CLASS, attrClass + " fileinput-exists");
		} else {
			file.setAttribute(AttributeConstants.ATTR_CLASS, attrClass + " fileinput-new");
		}
		if (!StringUtils.isEmptyOrWhitespace(file.getAttributeValue(ONCLICK))) {
			spanFileName.setAttribute(ONCLICK, file.getAttributeValue(ONCLICK));
			file.removeAttribute(ONCLICK);
		}

		final Element aClose = new Element(ElementConstants.HTML_ANCHOR);
		aClose.setAttribute(AttributeConstants.ATTR_CLASS, "close fileinput-exists");
		aClose.setAttribute(AttributeConstants.ATTR_HREF, "#");
		aClose.setAttribute(AttributeConstants.ATTR_DATA_DISMISS, "fileinput");
		aClose.setAttribute(AttributeConstants.ATTR_STYLE, "float: none");
		aClose.addChild(new Text("×"));

		file.clearChildren();
		file.addChild(spanfile);
		file.addChild(spanFileName);
		file.addChild(aClose);
		file.setRecomputeProcessorsImmediately(true);
		return file;
	}


	public static Element processFileView(Element element) {
		Element file = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_DIV, false);
		List<Node> nodes = file.getChildren();

		final Element fileInput = new Element(ElementConstants.HTML_I);
		fileInput.setAttribute(AttributeConstants.ATTR_CLASS, "glyphicon glyphicon-file file-view");

		file.clearChildren();
		file.addChild(fileInput);

		for (Node node : nodes) {
			file.addChild(node);
		}

		file.removeAttribute(AttributeConstants.ATTR_CLASS);
		file.setAttribute(AttributeConstants.ATTR_CLASS, "cursor-pointer file-view ");
		file.setRecomputeProcessorsImmediately(true);
		return file;
	}


	public static Element processFile(Element element, MessageService messageService) {
		Element file = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_DIV, false);
		String attrClass = file.getAttributeValue(AttributeConstants.ATTR_CLASS);
		file.clearChildren();

		String fieldAttr = file.getAttributeValue(TH_FIELD);
		String value = fieldAttr.replace("*{", "").replace("}", "");
		LOGGER.debug("FIELD ATTR: {}", value);

		file.setAttribute("data-provides", FILE_UPLOAD);

		final Element fileInput = new Element(ElementConstants.HTML_DIV);
		fileInput.setAttribute(AttributeConstants.ATTR_CLASS, "form-control");
		if (!StringUtils.isEmptyOrWhitespace(file.getAttributeValue(ONCLICK))) {
			fileInput.setAttribute(ONCLICK, file.getAttributeValue(ONCLICK));
			file.removeAttribute(ONCLICK);
		}

		final Element i = new Element(ElementConstants.HTML_I);
		i.setAttribute(AttributeConstants.ATTR_CLASS, "glyphicon glyphicon-file fileupload-exists");

		final Element span = new Element(ElementConstants.HTML_SPAN);
		span.setAttribute(AttributeConstants.ATTR_CLASS, "fileinput-filename");
		if (!StringUtils.isEmptyOrWhitespace(file.getAttributeValue(PLACEHOLDER))) {
			span.addChild(new Text(file.getAttributeValue(PLACEHOLDER)));
			file.setAttribute(AttributeConstants.ATTR_CLASS, attrClass + " fileinput-exists");
		} else {
			file.setAttribute(AttributeConstants.ATTR_CLASS, attrClass + " fileinput-new");
		}

		fileInput.addChild(i);
		fileInput.addChild(span);

		final Element fileBtn = new Element(ElementConstants.HTML_SPAN);
		fileBtn.setAttribute(AttributeConstants.ATTR_CLASS, "input-group-addon btn btn-white btn-cons btn-file");

		final Element newInput = new Element(ElementConstants.HTML_SPAN);
		newInput.setAttribute(AttributeConstants.ATTR_CLASS, "fileinput-new");
		newInput.addChild(new Text(messageService.getMessage(LBL_SLCT_FILE)));

		final Element exstsInput = new Element(ElementConstants.HTML_SPAN);
		exstsInput.setAttribute(AttributeConstants.ATTR_CLASS, "fileinput-exists");
		exstsInput.addChild(new Text(messageService.getMessage(LBL_CHNG_FILE)));

		final Element hiddenInput = new Element(ElementConstants.HTML_INPUT);
		hiddenInput.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		hiddenInput.setAttribute(AttributeConstants.ATTR_NAME, "...");

		String newField = !BaseUtil.isObjNull(fieldAttr) ? fieldAttr.substring(2, fieldAttr.length() - 1) : "";

		final Element contentInput = new Element(ElementConstants.HTML_INPUT);
		contentInput.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		contentInput.setAttribute(AttributeConstants.ATTR_CLASS, "fileinput-upload-content");
		contentInput.setAttribute(AttributeConstants.ATTR_TH_FIELD, "*{" + newField + ".content}");

		final Element fnameInput = new Element(ElementConstants.HTML_INPUT);
		fnameInput.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		fnameInput.setAttribute(AttributeConstants.ATTR_CLASS, "fileinput-upload");
		fnameInput.setAttribute(AttributeConstants.ATTR_TH_FIELD, "*{" + newField + ".filename}");

		final Element sizeInput = new Element(ElementConstants.HTML_INPUT);
		sizeInput.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		sizeInput.setAttribute(AttributeConstants.ATTR_CLASS, "fileinput-upload-size");
		sizeInput.setAttribute(AttributeConstants.ATTR_TH_FIELD, "*{" + newField + ".size}");

		final Element ctypeInput = new Element(ElementConstants.HTML_INPUT);
		ctypeInput.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		ctypeInput.setAttribute(AttributeConstants.ATTR_CLASS, "fileinput-upload-type");
		ctypeInput.setAttribute(AttributeConstants.ATTR_TH_FIELD, "*{" + newField + ".contentType}");

		final Element oldInput = new Element(ElementConstants.HTML_INPUT);
		oldInput.setAttribute(AttributeConstants.ATTR_TYPE, "file");
		oldInput.setAttribute(AttributeConstants.ATTR_NAME, file.getAttributeValue(AttributeConstants.ATTR_NAME));
		oldInput.setAttribute(AttributeConstants.ATTR_ID, file.getAttributeValue(AttributeConstants.ATTR_NAME));
		if (!StringUtils.isEmptyOrWhitespace(file.getAttributeValue(TH_FIELD))) {
			oldInput.setAttribute(TH_FIELD, file.getAttributeValue(TH_FIELD));
			file.removeAttribute(TH_FIELD);
		}
		if (!StringUtils.isEmptyOrWhitespace(file.getAttributeValue(ACCEPT))) {
			oldInput.setAttribute(ACCEPT, file.getAttributeValue(ACCEPT));
			file.removeAttribute(ACCEPT);
		}

		fileBtn.addChild(newInput);
		fileBtn.addChild(oldInput);
		fileBtn.addChild(exstsInput);
		fileBtn.addChild(hiddenInput);
		fileBtn.addChild(fnameInput);
		fileBtn.addChild(sizeInput);
		fileBtn.addChild(ctypeInput);
		fileBtn.addChild(contentInput);

		final Element aBtn = new Element(ElementConstants.HTML_ANCHOR);
		aBtn.setAttribute(AttributeConstants.ATTR_HREF, "#");
		aBtn.setAttribute(AttributeConstants.ATTR_CLASS,
				"input-group-addon btn btn-white btn-cons fileupload-exists");
		aBtn.setAttribute("data-dismiss", FILE_UPLOAD);
		aBtn.addChild(new Text("Remove"));

		file.addChild(fileInput);
		file.addChild(fileBtn);
		file.addChild(aBtn);

		file.removeAttribute(AttributeConstants.ATTR_NAME);
		file.setRecomputeProcessorsImmediately(true);
		return file;
	}


	public static Element processFileThumbnail(Element element, MessageService messageService) {
		Element file = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_DIV, false);
		String attrClass = file.getAttributeValue(AttributeConstants.ATTR_CLASS);
		file.clearChildren();

		String fieldAttr = file.getAttributeValue(TH_FIELD);
		String value = fieldAttr.replace("*{", "").replace("}", "");
		LOGGER.debug("FIELD ATTR: {}", value);

		file.setAttribute("data-provides", FILE_UPLOAD);

		// THUMBNAIL
		final Element div = new Element(ElementConstants.HTML_DIV);
		div.setAttribute(AttributeConstants.ATTR_CLASS, "fileupload-preview thumbnail");

		String onclickAttr = file.getAttributeValue(ONCLICK);
		String thclickAttr = file.getAttributeValue(TH_ONCLICK);

		if (!BaseUtil.isObjNull(onclickAttr) || !BaseUtil.isObjNull(thclickAttr)) {
			div.setAttribute(AttributeConstants.ATTR_CLASS,
					div.getAttributeValue(AttributeConstants.ATTR_CLASS) + " cursor-pointer");
			if (!BaseUtil.isObjNull(thclickAttr)) {
				div.setAttribute(TH_ONCLICK, thclickAttr);
				file.removeAttribute(TH_ONCLICK);
			}
			if (!BaseUtil.isObjNull(onclickAttr)) {
				div.setAttribute(ONCLICK, onclickAttr);
				file.removeAttribute(ONCLICK);
			}
		}

		String content = null;
		final Element img = new Element(ElementConstants.HTML_IMG);
		if (!StringUtils.isEmptyOrWhitespace(file.getAttributeValue(PLACEHOLDER))) {
			String docMgtId = file.getAttributeValue(PLACEHOLDER);
			file.setAttribute(AttributeConstants.ATTR_CLASS, attrClass + " fileupload-exists");
			img.setAttribute(AttributeConstants.ATTR_CLASS, "fileupload-img-thumbnail-view");
			img.setAttribute("th:src", "@{/documents/download/content/" + docMgtId + "}");
		} else {
			content = "/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wgARCAEsASwDASIAAhEBAxEB/8QAGwAAAwADAQEAAAAAAAAAAAAAAAECAwQFBgf/2gAIAQEAAAAA+wWNtjbGDAABCEhISxaPRyNtttsY2AAgQkkJY9XBi6eRttttsbAaAEJJCjWwTOLpZHTbbbbGMAEISROHXiVODpZW6bdNjYxgIQhLHgxzMzODpZKdN022xjABCFOLFMzMzOt0stOm6bbY2AAIUYplRMzM6vSyuqbpuhtj0ubm69JERMyomZidTpZap06bpsb0/No3/RIiVMqJmYmNTpZap06dNtcl63OGej5PW2kpmZmYmJ0ullqqp06bfC5W3WmC3vMZfoGSVMzMTExpdLLVU6pum/JYL6nJI0e75o9n11KmJmJiNHpZaqqqnRT8tpnX0NLn+k4Oue46cqZmJiYjR6OaqqnVN0aXmdjoanm93s8rm9T25KmZmImI0Ojmqqqqpt4ePn53G1AMvoDq9OVMzExMRz+jmqrp1TrS8v0tXlaoAP0nm/ReplTMTERPO6Oarqqp0eOwd3y+uAAbe9xva9aZmYmIjn9DNV1VU6x8O65QAAHX5HU7imJmIiOf0M1VdVVNsAAAACVMxMRE87oZbq6qqbYAAAAEqZiYiI5+/mq6q3VNgAAAASomYmIjn7+W7d15z0PE6vndn1D87u8P1PBz9/x3o8/lb9H5c723ERMc/ey3dVXj+3xNvtcH02547pee9T5npdvyvXdZsvm/YExMRHP3s1XV15WtbY9FwO90fHdLm1h2tjPxehs8rreY3fR55iInn7ua3d15Le5m/wBfz/qtzx3S1eV2sGqavavW2eP6qyYiY0NzNVXVcTq8rscHY9HXA3MGHpaWj6jh7XGvpcg621MRMaO5kurp1VOm2xgISUqZmYmInR28tXTqqquH0bwafU0+nPPvV2ehyK6kqJmJidLayXVOqql5fs8zd5vW0fQczWrXz9zz3Q6KmYmYmNPZy1Tqqt87VzcbrRhrd0k7je0envTMzEzE6mxkp1V06MklXjqachACmZmJmNXPkp1VVVU3Q2ACSSmVMzEzOtmt1VVVU6bbGCEJSplTMxM6+W3VVVU6bbbAEJJSpmVMzOC7p1VU6dNsYAJJJSpmVMzhuqp1Tp022MAEhSlKmVMrDdOnVN022xjQISSlSpUqcabGMYxgMAEAhCEJC//EABQBAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf//EABQBAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf//EAEAQAAEDAgEIBgYIBgMBAAAAAAIAAQMEERIFEyExMlFSkRUwQWFxgRAgIjRQchQjMzVAkrHRQlNic4LBJCWh8P/aAAgBAQABPwERHC2htSwDwtyWAeFuSwDwtyWAeFuSwDwtyWAeFuSwDwtyWAOFuSwBwtyWbDhHks2HCPJZsOEeSzYcA8lmw4B5LNhwDyWbDgHks2HAPJZsOAeSzYcA8lmw4B5LNhwDyWbDgHks2HAPJZsOAeSzYcA8lmw4R5LNhwtyWAOFuSwBwtyWAeFuSwDwtyWAeFuSwDwtyWAeFuSwDwtyRZtuxkWvQ1kGw3h8CImFEbv3eh9aDYbw+AO7NrRG76vULWg2B8Px5HuT+qWtBsN4fjXeyd7+uetBsD4fjHfqT1oNgfD8U7p+qPWg2B8PwM1SMWjWW5PWSf0t5IK3T7Y+bIXYmuz3b1X6yTaQbA+H4ColzUejafV6lLNm5ML7L/gZNpBsD4da7sLXfUjrtNgHzdRVhHIwuLadyrSvNbc3qvOwU4yPpuiyqzFbN3bxUFRHUDcH8WfrpdpBsD4dbWy3LNtqbX6Kb3gFV+8l6juzNd1UP/1Qd7+iKQoZGMdbKM2ljEx1E1+tl2kGwPh1sz3nP5n9AlhNi3PdVo3wStqdvSRsLaV7U0jC2t3szLKTtHFDTt2afTkwsVJbcTt1su15INgfDraoMFQXfp9NMbSxvTn/AIqWIoSsXk6ORh8U7uT96pKdqUHqZ9D9jKeV55ikLt9OT48FGN9Zaetl2vJBsD4dbUwZ4NG02pEJAViazqKnkl1NZt7oMxSvfHjPuU+UtGFohf5kT3e9rKnqfo73aICfe+tPlCGojeOYCFn7W0oqI3HFCTSj/Tr5J2s9nVHRlUGzu1o21vvWrrZtvyQbA+HWSShE1zeyOvJ/sxZvFCz5vO1RaOwbKaqKXQ3shuZHJ2N6schxFiAnF1HLFW6DYQn7CtodPXz08mbljHRu0KCuhn0XwlufrZtvyQbA+HV1FQ0A7yfUyIyMsRPd1RwsTvKeyKqJ3mkv/C2pkcnY3r6nQO2UKVwL7cNT70+h7PrVFXuztFM+jsLd1k235IPsx8OrmleWVy5eipfMUoQt260Z30N1NNLmKgT7O3wWUos3U4m1Hp9GT589T2faDR1c235INgfDqpBc4iFns7tZdHHxigoCExdzGzOq2lmqJGcHHDa2l10XPvDmui594c10XPvDmui594c10XPvDmui594c10XPvDmui594c10XPvDmui594c1VUkk9PELO2MNd10XPvDmqKkmppSc3HC7dj9XNt+Sj2B8Pgs235INgfD4LNt+SDYHw+Czbfkg2B8PX+mz3fY17lCeciE96GtmeoYPZs54dXeqqpalixO1yfQLb01XWyv7JW7gC6gyhIJ4ZrOO+1nb01lZNDU5uPDbDfSy+kSdHPPox4b9y6Rqt8f5VAedgA31u2lVVdNHVHHHgwjbWyoqqaeZxkw2w30N6OkqgndxwYb6NHYqSZ56diK2LU9lLKMERSHqZPXVcx/V+xuERu6CvqIztL7W9nazopP8AjlKHDdl0hUu2uP8AKukKneH5VSyHLAxna9+z15tvyQbA+Hrs1zdm3uqCS4kHmyi99b+7/tZTK9UA8IXVAOGkF9+lV44a0u9mdUhYqWN+70ZR99f5GT/cz/KhG8Zlw2dZOLFTW4XX2000nZ7RLJnvBfIq2TNUchdtrN5qKLFTTFwCyyWe2HmsrF7EQbyusmB7Bn23squiKeVjFxbRZ7rNvDQGBOzuwkqLTUx3WEeEeS8Gt68235INgfD14Peh+dM/0bKFv4b/APjqL31v7v8AtZQ99f5GVH7pH4LKXvrf22/V1Q+5x+f6+jKPvr/Iyf7mf5VRhnRmDfGqKfNwTv8A0YmVMFqOoLdHZZM94f5P2WVT9mKLe+J1QxXoyv8Ax3VCbx1IX+V1lX7SD/L/AEqB3ajkdtd3/RfTqtmbE7NfeKilOaglKR2d7Pq8FEJG4iG0+qy+h1XCf5lTgQU4CV8Ta7+vNt+SDYbw9eB/+WPzrKUekJf8XUHvMfzt+qykNqkC3jb/AO5qgNipWHtHQq42OtO2nCzCqUcNLGz7vRlH31/kZP8Acz/Ksl/bF8qlHNyyx9l7eSjDDkiV+JndZM94f5P2Vcecrj3A2FdHTGzPgbmiAoJMD6CFZR+sgglbV+6yYbWMO3WyynIxTxgz6RZ7qm+7Zf8AL9FROw1Ebu9mX0iL+aH5kxibXEmdu5/Xm2/JBsN4evDQSBM0jkFsV9aqIs/CQdr6vFRZPlCUCcg0Oz61PANRHhLRufcnydMz+y7eT2UGTcLs8rtbhb01VFJPUZwXG2G2lPTn9AeC7YrW7lR0klPI5G4vdraFVUJzVDyA4szs2tHA70TwDa+DCqOjkp5XI3F2w20Lo2Z5HIyD2iu+l/RV0Rzz5wHFtFnugpr0mYls/eyLJ0zP7Li/feybJhNG/tDnHUVOUdIcTuOIr6k2TJrbcfNdFycUapoHp4XAnG7lfR68u15INhvD4LLteSHZbw6uSvMZjEQZxF7XuqmYoYM4DM+rWoZ8dNnSa2u7KjqTqWJyBhZtyDKJFKzYGwYrXv2KqmeCBzZrvdtaOsMKSObAOIitbmojeSITdrO7XU8uZgOTcypaw55MBgw6L6FWVRU7xsIsWK+tPXTxu2cgszqpq3hjjIBYse9AWIBd+1rqeskjqM0EbEo56kpBYqfCPa9n6uXaQ7LeHVETABE+pmuowcqGWV9rEz/uh+vyc49uGyCW2TZm8uaifMZMM+172/RZrBk8D/rVWePJzFvwqb7tp/7n7qn93j+VZTP6oI+Iv0RN9HrId2FrrKf2kP8Al/pVM5zZsCDNiz3u6rmFoKdhe7dj+Sj+yD5WVQWDKOK17W0KKsKWVgzTjftv1cm0h2W6quPDSu3aT4VHRyHA31ziL/w3WTz9kw80bOBHF2YlXexTww8/JHRyZi7yvhYb4LunPFkwh4SZTfd1P/c/dR10McQC+K7NuU5fSq0BF9GFreelVNMcQtIcrnptpfUq0841MW8X/wBKrqwmiGMLu99dtSqRcKWnYtd3Q18IgLPiuzblKbDlBjfVZnQ18Zmwtiu+jV1cm0h2W6pxEtoRK29l/wCIRAdkBZ97MsEd7vGDvvsiADe5AJP3stazcVrZsLbsKcAdmFwHC2prLNRfyg/KmCNixNGLPvsnESaxCztudPHG9rxho1aNSYIxe7Rgz9zIhE9sRLxZZuL+VH+VOEbvd4wd+9lhjZ7tEDP8vVybSHU3wU9abU3wU9abU3wUtabV8FLWm+ClrTfBXV1dYlidY3WN1jdZx+5Zx+5Z1+5Z1+5Z0u5Z0u5Z4u5Z4u5Z4u5Z4tzLPF3LPF3LPF3LPF3LPFuZZ4u5Z4u5Z4u5Z0u5Z0u5Z1+5Zx+5Zx+5Zx+5Y3WN1idYnWJX9H//xAApEAEBAQAAAwgCAwEBAQAAAAABABEQITFBUWFxkaGx8cHRIIHw4UAw/9oACAEBAAE/EHOso7L6FfQr6VfSr6dfXr69fVr6tfRL6JfRL6BfQL6BfQL6BfQL6BfQL6BfQL6BfQL6BfRL6NfVr6tfXr69fXr6dP8AzV9Ku0s9wTHYDOhexfwz+OWWcMssss4ZZZZwzhln8+qPPuLk5yeE8L2Lgf8AwyzhllnDLLLOOcM4Z/EjVlyTkPeZJL4L2COBwOBxzhlllllnHLLOGWWcM4OBrdh6rS6uySSSXxXsXE4HA4Flllln8sssss4ZwyPxMy5ySSSSSXw3sHxEcCDgcDhlnDLP5ZZxzg4HOd6ciSSSSSSSS6fleyfEcDgcCOGccs/hlnHOOWHnaeskkkkkkkkl0/K9k+I4kFnAOGWWcM4pZPCdnnLeQHdG5Cz0f6h5k6JZZZMt6SSSSSSSSSSSXQ8r2z4iIiCOAcMss4ZZc/7j4PGVVV1evDZATn4+D32WTPOSSSSSSSSSSSS6Xle2fEREREcc4ZMXAc1YhCQ/s/qbe1g8mXgcj+3n/ETVAOXfn/LHH2if8y7mzuSWSWSSSSSSTJMl0fK9s+IiCIiP4BwQW7TxPBhv3/i0ePnwW8VSYFzfmZ56r8cFnxP6fBujUB4eFkkkkkkkkkkkl0fK9s+IiIiOB/DJkvce/BiupeiJczm33P8AeHDbZf0O+0k0APGcnQi8gw/PFBXZHs/mySSSSZmSSZunPbPiIiI4BwOGcG7g8/3/AN49GF6u6ely/oYnOvYLRuquRzHP6m/luTArkdx2HDJMpEWefT2zgyTMkzMkzdOe2fERERERwOIlyHWPb4Tp4djc9/qYk9LDOTp/vONXfnWnpa+Gnob+by0AceTvKC4uaYPHvkRv2rB5rnIgInJHskLK1PYQAAMDkBwZmZmZmZuhPbPiIiIiIiOGbPcO1nME7+dkgCebD4truw7Q8bPX59r/ABEiPaNmFPUL4KNvn8zR3j0z+pQLXw98nt4szMzMzN0J7Z8REREREcOUc+0MyWna2AHXN6L/AMkWk5HdHfba/Ltf5igiidEsEAd7hBYEDiPZbsXyb2PhwZmZmZmbpT2j4iIiIiOGgKuBMvcXB3HZdbpMTzeXX3ue6fa9/wD8X08DnjXWPDw/V2/v++Daepp7zs/3hwZmZmZm6U9s+IiI4HA4GGS030zLUAUx5mwkgPMD1fC+/fq+/fq+/fq+/fq+/fq+/fq+/fq+/fq+/fq+/fqxUYEnHlz7O8vv36nCMaI895dnnMzMzMzN0v8AOreyfERERERwP/CzMzMzM3S/zq3tnxERwIiOB/4GZmZmZmbpf51b2z4iI4ERHA/8DwZmZmZm6X+dW9s+IiIjg4Y4EHP3+d3vDnnf2yFemtbnJ33PkmF6v1Jlsc0APUYbzViP0EImjpwfISOaXVfHwkGbK6Ore65H5H7lwGNx03tlBwBUXU3v8ZzmUNh3Tx8ZcNZZJS53vNy7bqTriw36yeDD1zq9wWKwHoGXjo22AjhIen6jWBN7eWwY9Q737vsX7t2TRyYTMzM3SntnxEREcELauXq2wvT0u38eslZtOzsHmqfgjAMWr1z8RYDD50/Ejzry+nL8cP8AI7297+bwMf0KH5vHanrz/NvaSf6Tc/Fz+c+SzJxf3uQ+bMTqD119hua71Ans/iTneTI78P8AsRj5gX3/ADd47Y590c9QY8liBAnc+TP/ABlyDAHcGTMzM3QnsHxEREcH6n5nRchn/Xdvtctf+x3t7x8vCh/s8XD/ACO9ve/mxLqwefLPe5xcx+YH/S5b9Q/3zfgvevmcsPXDwP8Ar7RF6WHyzP3dB+r/AGcvnL2sdJgx54lQmO5sKhdGcoECh1Mb/D/cCIBwterMzMzdCexRDERw3M6H52BDk/sPzbXXVZfHE3YPrhWEJ1FH96fMrPCj4mr8ycpOX158P8jvb3v5v8fiSD8tcebT8XIrn+G/F718zlh5AefV+c/q0FxNNE5AYOHZ2k+0B9Mb+ISUEhd/f+LaYsTs3M+L2ECKDqrgcmf+OmAE5uhMszM3QnsUQwxDbYebli3N3uuY4BqegOZIljgLeTvdbSUOj1U01neqnzDd6u+bxejsYTum+HjK51vWvNvlGpsW17fEtbMgkdOXd3ZIIHgvTc6zBYuaruneeEL70z7R1zldIaGSDTmL3Egrhpr056PPtLk9OwaTvzAzVwO3XObLXABTnMzugEeh3v1fav6nwEc3l0D8SzMzN057FbDDDDDDDEMNtvDbbeG28N4bbLLLLMszLLN04/TQwxDbDDDDDc9rEWvf77dUV1rDHt+JCAgQPIzbOtGaXVsO7y23mzYc5Biw5uR2TV04f4RGAkHZcuBdge17D1nPQUrdl5xTrMzP3IB+KRfLSIMLlrOWbIKBBB4k35KE1dV8p+yOdAPSWWWWWWWWZbo+V7dDDDbDDDDDdcNLyDbniL+xu/K74af2On4uevNQek/djvIF5uj3lBderyzPkvGknz0294q9JYmeeyeHN85M3oj83R/EvRglXrjd5Z0zpzske4HadqX+DsurWLx2z/Nrm3mG90sssssssss3S8r2hDDDDDDDDDZC8kPz7DKoB3CB8y2RyxAPo/iE3IdPeC58zzXmpjwHP3SG3uxRy55nS5odi8lH93vl5YdjmybChoTo9T0y21eOjzeflcx9Uvn1RRkCrBiO5AiPZutyEpHPDb3ZVy55c7O42rLLLLLLLLLdLyl6BDDbDDDDDDYfPGgTkJgAAMAMCVVd1CLbNh5qKv8AcFPOQk5OBEEeyCZJ5uGOdJeNNU4PeH9t9O/V3KVBE5Z1ucltw0gio3hOa65ABjoiMkOJzMnL6JaPgzRXIKFOYgElllllllllluh5S9KGGGGGGGGGG22222222222222WWWWWWWWWWWW6flP0obYYYYYYYYYbbbbbbbbbbbbZbbZZZZZZZZZZbo+V7S2GGGGGGG22G2222222222222WWWWWWWWWWWW+OXJ5Wwwwwwww22w22222222222222yy2yyyyyyyy3xXQeUMMMMMMMNsMNtttttttttttttsstsssssssst8F0EMMMMNsMNtttttttttttttttttstsssssssst1wi34WvC8IvALwC8IvBnhzwZ4PovC9F4XovA9F4HovC9F9TeF6G8L0N4XobwvQ31N4HovA9F4HovC9F4XovBnhzw54M8IvALwi8i14W/CXb/8QAFBEBAAAAAAAAAAAAAAAAAAAAgP/aAAgBAgEBPwA0/wD/xAAUEQEAAAAAAAAAAAAAAAAAAACA/9oACAEDAQE/ADT/AP/Z";
			file.setAttribute(AttributeConstants.ATTR_CLASS, attrClass + " fileupload-new");
			img.setAttribute("src", BaseUtil.isObjNull(content) ? "#" : "data:image/jpg;base64," + content);
		}

		div.addChild(img);

		final Element divBtn = new Element(ElementConstants.HTML_DIV);

		final Element fileBtn = new Element(ElementConstants.HTML_SPAN);
		fileBtn.setAttribute(AttributeConstants.ATTR_CLASS, "btn btn-white btn-cons btn-file");

		final Element newInput = new Element(ElementConstants.HTML_SPAN);
		newInput.setAttribute(AttributeConstants.ATTR_CLASS, "fileupload-new");
		newInput.addChild(new Text(messageService.getMessage(LBL_SLCT_FILE)));

		final Element exstsInput = new Element(ElementConstants.HTML_SPAN);
		exstsInput.setAttribute(AttributeConstants.ATTR_CLASS, "fileupload-exists");
		exstsInput.addChild(new Text(messageService.getMessage(LBL_CHNG_FILE)));

		final Element hiddenInput = new Element(ElementConstants.HTML_INPUT);
		hiddenInput.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		hiddenInput.setAttribute(AttributeConstants.ATTR_NAME, "...");

		String newField = !BaseUtil.isObjNull(fieldAttr) ? fieldAttr.substring(2, fieldAttr.length() - 1) : "";

		final Element contentInput = new Element(ElementConstants.HTML_INPUT);
		contentInput.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		contentInput.setAttribute(AttributeConstants.ATTR_CLASS, "fileupload-upload-content");
		contentInput.setAttribute(AttributeConstants.ATTR_TH_FIELD, "*{" + newField + ".content}");

		final Element fnameInput = new Element(ElementConstants.HTML_INPUT);
		fnameInput.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		fnameInput.setAttribute(AttributeConstants.ATTR_CLASS, "fileupload-upload");
		fnameInput.setAttribute(AttributeConstants.ATTR_TH_FIELD, "*{" + newField + ".filename}");

		final Element sizeInput = new Element(ElementConstants.HTML_INPUT);
		sizeInput.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		sizeInput.setAttribute(AttributeConstants.ATTR_CLASS, "fileupload-upload-size");
		sizeInput.setAttribute(AttributeConstants.ATTR_TH_FIELD, "*{" + newField + ".size}");

		final Element ctypeInput = new Element(ElementConstants.HTML_INPUT);
		ctypeInput.setAttribute(AttributeConstants.ATTR_TYPE, HIDDEN);
		ctypeInput.setAttribute(AttributeConstants.ATTR_CLASS, "fileupload-upload-type");
		ctypeInput.setAttribute(AttributeConstants.ATTR_TH_FIELD, "*{" + newField + ".contentType}");

		final Element oldInput = new Element(ElementConstants.HTML_INPUT);
		oldInput.setAttribute(AttributeConstants.ATTR_TYPE, "file");
		oldInput.setAttribute(AttributeConstants.ATTR_NAME, file.getAttributeValue(AttributeConstants.ATTR_NAME));
		oldInput.setAttribute(AttributeConstants.ATTR_ID, file.getAttributeValue(AttributeConstants.ATTR_NAME));
		if (!StringUtils.isEmptyOrWhitespace(file.getAttributeValue(TH_FIELD))) {
			oldInput.setAttribute(TH_FIELD, file.getAttributeValue(TH_FIELD));
			file.removeAttribute(TH_FIELD);
		}
		if (!StringUtils.isEmptyOrWhitespace(file.getAttributeValue(ACCEPT))) {
			oldInput.setAttribute(ACCEPT, file.getAttributeValue(ACCEPT));
			file.removeAttribute(ACCEPT);
		}

		fileBtn.addChild(newInput);
		fileBtn.addChild(oldInput);
		fileBtn.addChild(exstsInput);
		fileBtn.addChild(hiddenInput);
		fileBtn.addChild(fnameInput);
		fileBtn.addChild(sizeInput);
		fileBtn.addChild(ctypeInput);
		fileBtn.addChild(contentInput);

		final Element aBtn = new Element(ElementConstants.HTML_ANCHOR);
		aBtn.setAttribute(AttributeConstants.ATTR_HREF, "#");
		aBtn.setAttribute(AttributeConstants.ATTR_CLASS, "btn btn-white btn-cons fileupload-exists");
		aBtn.setAttribute("data-dismiss", FILE_UPLOAD);
		aBtn.addChild(new Text(messageService.getMessage("lbl.file.rmv")));

		divBtn.addChild(fileBtn);
		divBtn.addChild(aBtn);

		file.addChild(div);
		file.addChild(divBtn);
		file.removeAttribute(AttributeConstants.ATTR_NAME);
		file.setRecomputeProcessorsImmediately(true);
		return file;
	}


	public static Element processFileThumbnailView(Element element) {
		Element file = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_DIV, false);
		String attrClass = file.getAttributeValue(AttributeConstants.ATTR_CLASS);
		List<Node> nodes = file.getChildren();

		final Element div = new Element(ElementConstants.HTML_DIV);
		div.setAttribute(AttributeConstants.ATTR_CLASS, "fileupload-preview thumbnail");

		String content = null;
		final Element img = new Element(ElementConstants.HTML_IMG);
		if (!StringUtils.isEmptyOrWhitespace(file.getAttributeValue(PLACEHOLDER))) {
			String docMgtId = file.getAttributeValue(PLACEHOLDER);
			file.setAttribute(AttributeConstants.ATTR_CLASS, attrClass + " fileupload-exists");
			img.setAttribute(AttributeConstants.ATTR_CLASS, "fileupload-img-thumbnail-view");
			img.setAttribute("th:attr", "data-src=@{/documents/download/content/" + docMgtId + "}");
		} else {
			content = "/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wgARCAEsASwDASIAAhEBAxEB/8QAGwAAAwADAQEAAAAAAAAAAAAAAAECAwQFBgf/2gAIAQEAAAAA+wWNtjbGDAABCEhISxaPRyNtttsY2AAgQkkJY9XBi6eRttttsbAaAEJJCjWwTOLpZHTbbbbGMAEISROHXiVODpZW6bdNjYxgIQhLHgxzMzODpZKdN022xjABCFOLFMzMzOt0stOm6bbY2AAIUYplRMzM6vSyuqbpuhtj0ubm69JERMyomZidTpZap06bpsb0/No3/RIiVMqJmYmNTpZap06dNtcl63OGej5PW2kpmZmYmJ0ullqqp06bfC5W3WmC3vMZfoGSVMzMTExpdLLVU6pum/JYL6nJI0e75o9n11KmJmJiNHpZaqqqnRT8tpnX0NLn+k4Oue46cqZmJiYjR6OaqqnVN0aXmdjoanm93s8rm9T25KmZmImI0Ojmqqqqpt4ePn53G1AMvoDq9OVMzExMRz+jmqrp1TrS8v0tXlaoAP0nm/ReplTMTERPO6Oarqqp0eOwd3y+uAAbe9xva9aZmYmIjn9DNV1VU6x8O65QAAHX5HU7imJmIiOf0M1VdVVNsAAAACVMxMRE87oZbq6qqbYAAAAEqZiYiI5+/mq6q3VNgAAAASomYmIjn7+W7d15z0PE6vndn1D87u8P1PBz9/x3o8/lb9H5c723ERMc/ey3dVXj+3xNvtcH02547pee9T5npdvyvXdZsvm/YExMRHP3s1XV15WtbY9FwO90fHdLm1h2tjPxehs8rreY3fR55iInn7ua3d15Le5m/wBfz/qtzx3S1eV2sGqavavW2eP6qyYiY0NzNVXVcTq8rscHY9HXA3MGHpaWj6jh7XGvpcg621MRMaO5kurp1VOm2xgISUqZmYmInR28tXTqqquH0bwafU0+nPPvV2ehyK6kqJmJidLayXVOqql5fs8zd5vW0fQczWrXz9zz3Q6KmYmYmNPZy1Tqqt87VzcbrRhrd0k7je0envTMzEzE6mxkp1V06MklXjqachACmZmJmNXPkp1VVVU3Q2ACSSmVMzEzOtmt1VVVU6bbGCEJSplTMxM6+W3VVVU6bbbAEJJSpmVMzOC7p1VU6dNsYAJJJSpmVMzhuqp1Tp022MAEhSlKmVMrDdOnVN022xjQISSlSpUqcabGMYxgMAEAhCEJC//EABQBAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf//EABQBAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf//EAEAQAAEDAgEIBgYIBgMBAAAAAAIAAQMEERIFEyExMlFSkRUwQWFxgRAgIjRQchQjMzVAkrHRQlNic4LBJCWh8P/aAAgBAQABPwERHC2htSwDwtyWAeFuSwDwtyWAeFuSwDwtyWAeFuSwDwtyWAOFuSwBwtyWbDhHks2HCPJZsOEeSzYcA8lmw4B5LNhwDyWbDgHks2HAPJZsOAeSzYcA8lmw4B5LNhwDyWbDgHks2HAPJZsOAeSzYcA8lmw4R5LNhwtyWAOFuSwBwtyWAeFuSwDwtyWAeFuSwDwtyWAeFuSwDwtyRZtuxkWvQ1kGw3h8CImFEbv3eh9aDYbw+AO7NrRG76vULWg2B8Px5HuT+qWtBsN4fjXeyd7+uetBsD4fjHfqT1oNgfD8U7p+qPWg2B8PwM1SMWjWW5PWSf0t5IK3T7Y+bIXYmuz3b1X6yTaQbA+H4ColzUejafV6lLNm5ML7L/gZNpBsD4da7sLXfUjrtNgHzdRVhHIwuLadyrSvNbc3qvOwU4yPpuiyqzFbN3bxUFRHUDcH8WfrpdpBsD4dbWy3LNtqbX6Kb3gFV+8l6juzNd1UP/1Qd7+iKQoZGMdbKM2ljEx1E1+tl2kGwPh1sz3nP5n9AlhNi3PdVo3wStqdvSRsLaV7U0jC2t3szLKTtHFDTt2afTkwsVJbcTt1su15INgfDraoMFQXfp9NMbSxvTn/AIqWIoSsXk6ORh8U7uT96pKdqUHqZ9D9jKeV55ikLt9OT48FGN9Zaetl2vJBsD4dbUwZ4NG02pEJAViazqKnkl1NZt7oMxSvfHjPuU+UtGFohf5kT3e9rKnqfo73aICfe+tPlCGojeOYCFn7W0oqI3HFCTSj/Tr5J2s9nVHRlUGzu1o21vvWrrZtvyQbA+HWSShE1zeyOvJ/sxZvFCz5vO1RaOwbKaqKXQ3shuZHJ2N6schxFiAnF1HLFW6DYQn7CtodPXz08mbljHRu0KCuhn0XwlufrZtvyQbA+HV1FQ0A7yfUyIyMsRPd1RwsTvKeyKqJ3mkv/C2pkcnY3r6nQO2UKVwL7cNT70+h7PrVFXuztFM+jsLd1k235IPsx8OrmleWVy5eipfMUoQt260Z30N1NNLmKgT7O3wWUos3U4m1Hp9GT589T2faDR1c235INgfDqpBc4iFns7tZdHHxigoCExdzGzOq2lmqJGcHHDa2l10XPvDmui594c10XPvDmui594c10XPvDmui594c10XPvDmui594c10XPvDmui594c1VUkk9PELO2MNd10XPvDmqKkmppSc3HC7dj9XNt+Sj2B8Pgs235INgfD4LNt+SDYHw+Czbfkg2B8PX+mz3fY17lCeciE96GtmeoYPZs54dXeqqpalixO1yfQLb01XWyv7JW7gC6gyhIJ4ZrOO+1nb01lZNDU5uPDbDfSy+kSdHPPox4b9y6Rqt8f5VAedgA31u2lVVdNHVHHHgwjbWyoqqaeZxkw2w30N6OkqgndxwYb6NHYqSZ56diK2LU9lLKMERSHqZPXVcx/V+xuERu6CvqIztL7W9nazopP8AjlKHDdl0hUu2uP8AKukKneH5VSyHLAxna9+z15tvyQbA+Hrs1zdm3uqCS4kHmyi99b+7/tZTK9UA8IXVAOGkF9+lV44a0u9mdUhYqWN+70ZR99f5GT/cz/KhG8Zlw2dZOLFTW4XX2000nZ7RLJnvBfIq2TNUchdtrN5qKLFTTFwCyyWe2HmsrF7EQbyusmB7Bn23squiKeVjFxbRZ7rNvDQGBOzuwkqLTUx3WEeEeS8Gt68235INgfD14Peh+dM/0bKFv4b/APjqL31v7v8AtZQ99f5GVH7pH4LKXvrf22/V1Q+5x+f6+jKPvr/Iyf7mf5VRhnRmDfGqKfNwTv8A0YmVMFqOoLdHZZM94f5P2WVT9mKLe+J1QxXoyv8Ax3VCbx1IX+V1lX7SD/L/AEqB3ajkdtd3/RfTqtmbE7NfeKilOaglKR2d7Pq8FEJG4iG0+qy+h1XCf5lTgQU4CV8Ta7+vNt+SDYbw9eB/+WPzrKUekJf8XUHvMfzt+qykNqkC3jb/AO5qgNipWHtHQq42OtO2nCzCqUcNLGz7vRlH31/kZP8Acz/Ksl/bF8qlHNyyx9l7eSjDDkiV+JndZM94f5P2Vcecrj3A2FdHTGzPgbmiAoJMD6CFZR+sgglbV+6yYbWMO3WyynIxTxgz6RZ7qm+7Zf8AL9FROw1Ebu9mX0iL+aH5kxibXEmdu5/Xm2/JBsN4evDQSBM0jkFsV9aqIs/CQdr6vFRZPlCUCcg0Oz61PANRHhLRufcnydMz+y7eT2UGTcLs8rtbhb01VFJPUZwXG2G2lPTn9AeC7YrW7lR0klPI5G4vdraFVUJzVDyA4szs2tHA70TwDa+DCqOjkp5XI3F2w20Lo2Z5HIyD2iu+l/RV0Rzz5wHFtFnugpr0mYls/eyLJ0zP7Li/feybJhNG/tDnHUVOUdIcTuOIr6k2TJrbcfNdFycUapoHp4XAnG7lfR68u15INhvD4LLteSHZbw6uSvMZjEQZxF7XuqmYoYM4DM+rWoZ8dNnSa2u7KjqTqWJyBhZtyDKJFKzYGwYrXv2KqmeCBzZrvdtaOsMKSObAOIitbmojeSITdrO7XU8uZgOTcypaw55MBgw6L6FWVRU7xsIsWK+tPXTxu2cgszqpq3hjjIBYse9AWIBd+1rqeskjqM0EbEo56kpBYqfCPa9n6uXaQ7LeHVETABE+pmuowcqGWV9rEz/uh+vyc49uGyCW2TZm8uaifMZMM+172/RZrBk8D/rVWePJzFvwqb7tp/7n7qn93j+VZTP6oI+Iv0RN9HrId2FrrKf2kP8Al/pVM5zZsCDNiz3u6rmFoKdhe7dj+Sj+yD5WVQWDKOK17W0KKsKWVgzTjftv1cm0h2W6quPDSu3aT4VHRyHA31ziL/w3WTz9kw80bOBHF2YlXexTww8/JHRyZi7yvhYb4LunPFkwh4SZTfd1P/c/dR10McQC+K7NuU5fSq0BF9GFreelVNMcQtIcrnptpfUq0841MW8X/wBKrqwmiGMLu99dtSqRcKWnYtd3Q18IgLPiuzblKbDlBjfVZnQ18Zmwtiu+jV1cm0h2W6pxEtoRK29l/wCIRAdkBZ97MsEd7vGDvvsiADe5AJP3stazcVrZsLbsKcAdmFwHC2prLNRfyg/KmCNixNGLPvsnESaxCztudPHG9rxho1aNSYIxe7Rgz9zIhE9sRLxZZuL+VH+VOEbvd4wd+9lhjZ7tEDP8vVybSHU3wU9abU3wU9abU3wUtabV8FLWm+ClrTfBXV1dYlidY3WN1jdZx+5Zx+5Z1+5Z1+5Z0u5Z0u5Z4u5Z4u5Z4u5Z4tzLPF3LPF3LPF3LPF3LPFuZZ4u5Z4u5Z4u5Z0u5Z0u5Z1+5Zx+5Zx+5Zx+5Y3WN1idYnWJX9H//xAApEAEBAQAAAwgCAwEBAQAAAAABABEQITFBUWFxkaGx8cHRIIHw4UAw/9oACAEBAAE/EHOso7L6FfQr6VfSr6dfXr69fVr6tfRL6JfRL6BfQL6BfQL6BfQL6BfQL6BfQL6BfQL6BfRL6NfVr6tfXr69fXr6dP8AzV9Ku0s9wTHYDOhexfwz+OWWcMssss4ZZZZwzhln8+qPPuLk5yeE8L2Lgf8AwyzhllnDLLLOOcM4Z/EjVlyTkPeZJL4L2COBwOBxzhlllllnHLLOGWWcM4OBrdh6rS6uySSSXxXsXE4HA4Flllln8sssss4ZwyPxMy5ySSSSSXw3sHxEcCDgcDhlnDLP5ZZxzg4HOd6ciSSSSSSSS6fleyfEcDgcCOGccs/hlnHOOWHnaeskkkkkkkkl0/K9k+I4kFnAOGWWcM4pZPCdnnLeQHdG5Cz0f6h5k6JZZZMt6SSSSSSSSSSSXQ8r2z4iIiCOAcMss4ZZc/7j4PGVVV1evDZATn4+D32WTPOSSSSSSSSSSSS6Xle2fEREREcc4ZMXAc1YhCQ/s/qbe1g8mXgcj+3n/ETVAOXfn/LHH2if8y7mzuSWSWSSSSSSTJMl0fK9s+IiCIiP4BwQW7TxPBhv3/i0ePnwW8VSYFzfmZ56r8cFnxP6fBujUB4eFkkkkkkkkkkkl0fK9s+IiIiOB/DJkvce/BiupeiJczm33P8AeHDbZf0O+0k0APGcnQi8gw/PFBXZHs/mySSSSZmSSZunPbPiIiI4BwOGcG7g8/3/AN49GF6u6ely/oYnOvYLRuquRzHP6m/luTArkdx2HDJMpEWefT2zgyTMkzMkzdOe2fERERERwOIlyHWPb4Tp4djc9/qYk9LDOTp/vONXfnWnpa+Gnob+by0AceTvKC4uaYPHvkRv2rB5rnIgInJHskLK1PYQAAMDkBwZmZmZmZuhPbPiIiIiIiOGbPcO1nME7+dkgCebD4truw7Q8bPX59r/ABEiPaNmFPUL4KNvn8zR3j0z+pQLXw98nt4szMzMzN0J7Z8REREREcOUc+0MyWna2AHXN6L/AMkWk5HdHfba/Ltf5igiidEsEAd7hBYEDiPZbsXyb2PhwZmZmZmbpT2j4iIiIiOGgKuBMvcXB3HZdbpMTzeXX3ue6fa9/wD8X08DnjXWPDw/V2/v++Daepp7zs/3hwZmZmZm6U9s+IiI4HA4GGS030zLUAUx5mwkgPMD1fC+/fq+/fq+/fq+/fq+/fq+/fq+/fq+/fq+/fq+/fqxUYEnHlz7O8vv36nCMaI895dnnMzMzMzN0v8AOreyfERERERwP/CzMzMzM3S/zq3tnxERwIiOB/4GZmZmZmbpf51b2z4iI4ERHA/8DwZmZmZm6X+dW9s+IiIjg4Y4EHP3+d3vDnnf2yFemtbnJ33PkmF6v1Jlsc0APUYbzViP0EImjpwfISOaXVfHwkGbK6Ore65H5H7lwGNx03tlBwBUXU3v8ZzmUNh3Tx8ZcNZZJS53vNy7bqTriw36yeDD1zq9wWKwHoGXjo22AjhIen6jWBN7eWwY9Q737vsX7t2TRyYTMzM3SntnxEREcELauXq2wvT0u38eslZtOzsHmqfgjAMWr1z8RYDD50/Ejzry+nL8cP8AI7297+bwMf0KH5vHanrz/NvaSf6Tc/Fz+c+SzJxf3uQ+bMTqD119hua71Ans/iTneTI78P8AsRj5gX3/ADd47Y590c9QY8liBAnc+TP/ABlyDAHcGTMzM3QnsHxEREcH6n5nRchn/Xdvtctf+x3t7x8vCh/s8XD/ACO9ve/mxLqwefLPe5xcx+YH/S5b9Q/3zfgvevmcsPXDwP8Ar7RF6WHyzP3dB+r/AGcvnL2sdJgx54lQmO5sKhdGcoECh1Mb/D/cCIBwterMzMzdCexRDERw3M6H52BDk/sPzbXXVZfHE3YPrhWEJ1FH96fMrPCj4mr8ycpOX158P8jvb3v5v8fiSD8tcebT8XIrn+G/F718zlh5AefV+c/q0FxNNE5AYOHZ2k+0B9Mb+ISUEhd/f+LaYsTs3M+L2ECKDqrgcmf+OmAE5uhMszM3QnsUQwxDbYebli3N3uuY4BqegOZIljgLeTvdbSUOj1U01neqnzDd6u+bxejsYTum+HjK51vWvNvlGpsW17fEtbMgkdOXd3ZIIHgvTc6zBYuaruneeEL70z7R1zldIaGSDTmL3Egrhpr056PPtLk9OwaTvzAzVwO3XObLXABTnMzugEeh3v1fav6nwEc3l0D8SzMzN057FbDDDDDDDEMNtvDbbeG28N4bbLLLLMszLLN04/TQwxDbDDDDDc9rEWvf77dUV1rDHt+JCAgQPIzbOtGaXVsO7y23mzYc5Biw5uR2TV04f4RGAkHZcuBdge17D1nPQUrdl5xTrMzP3IB+KRfLSIMLlrOWbIKBBB4k35KE1dV8p+yOdAPSWWWWWWWWZbo+V7dDDDbDDDDDdcNLyDbniL+xu/K74af2On4uevNQek/djvIF5uj3lBderyzPkvGknz0294q9JYmeeyeHN85M3oj83R/EvRglXrjd5Z0zpzske4HadqX+DsurWLx2z/Nrm3mG90sssssssss3S8r2hDDDDDDDDDZC8kPz7DKoB3CB8y2RyxAPo/iE3IdPeC58zzXmpjwHP3SG3uxRy55nS5odi8lH93vl5YdjmybChoTo9T0y21eOjzeflcx9Uvn1RRkCrBiO5AiPZutyEpHPDb3ZVy55c7O42rLLLLLLLLLdLyl6BDDbDDDDDDYfPGgTkJgAAMAMCVVd1CLbNh5qKv8AcFPOQk5OBEEeyCZJ5uGOdJeNNU4PeH9t9O/V3KVBE5Z1ucltw0gio3hOa65ABjoiMkOJzMnL6JaPgzRXIKFOYgElllllllllluh5S9KGGGGGGGGGG22222222222222WWWWWWWWWWWW6flP0obYYYYYYYYYbbbbbbbbbbbbZbbZZZZZZZZZZbo+V7S2GGGGGGG22G2222222222222WWWWWWWWWWWW+OXJ5Wwwwwwww22w22222222222222yy2yyyyyyyy3xXQeUMMMMMMMNsMNtttttttttttttsstsssssssst8F0EMMMMNsMNtttttttttttttttttstsssssssst1wi34WvC8IvALwC8IvBnhzwZ4PovC9F4XovA9F4HovC9F9TeF6G8L0N4XobwvQ31N4HovA9F4HovC9F4XovBnhzw54M8IvALwi8i14W/CXb/8QAFBEBAAAAAAAAAAAAAAAAAAAAgP/aAAgBAgEBPwA0/wD/xAAUEQEAAAAAAAAAAAAAAAAAAACA/9oACAEDAQE/ADT/AP/Z";
			file.setAttribute(AttributeConstants.ATTR_CLASS, attrClass + " fileupload-new");
			img.setAttribute("src", BaseUtil.isObjNull(content) ? "#" : "data:image/jpg;base64," + content);
		}

		div.addChild(img);
		file.addChild(div);

		for (Node node : nodes) {
			file.addChild(node);
		}

		file.removeAttribute(AttributeConstants.ATTR_CLASS);
		file.setAttribute(AttributeConstants.ATTR_CLASS, "cursor-pointer file-view ");
		file.setRecomputeProcessorsImmediately(true);
		return file;
	}

}
