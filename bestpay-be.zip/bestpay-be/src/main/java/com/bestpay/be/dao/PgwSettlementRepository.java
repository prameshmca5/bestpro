package com.bestpay.be.dao;


import java.util.Date;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwSettlement;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Afif Saman
 * @since 5th June 2018
 */

@Repository
@RepositoryDefinition(domainClass = PgwSettlement.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_SETTLEMENT_DAO)
public interface PgwSettlementRepository extends GenericRepository<PgwSettlement> {

	@Query("select count(u) from PgwSettlement u ")
	public int totalRecords();


	@Query(" select u.settlementId from PgwSettlement u where u.merchantId=:merchantId and u.settleDate=:date")
	public int findSetId(@Param("merchantId") String merchantId, @Param("date") Date date);


	@Query(" select u from PgwSettlement u where u.settlementId=:settlementId")
	public PgwSettlement findSettlementBySetId(@Param("settlementId") int settlementId);


	@Query(" select u.settlementId from PgwSettlement u where u.channel=:channel and u.settleDate=:date")
	public int findSetIdByChannel(@Param("channel") String channel, @Param("date") Date date);

}