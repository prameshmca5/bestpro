package com.bestpay.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwMerchantContact;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */

@Repository
@RepositoryDefinition(domainClass = PgwMerchantContact.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MER_CONTACT_DAO)
public interface PgwMerchantContactRepository extends GenericRepository<PgwMerchantContact> {

	@Query("select u from PgwMerchantContact u ")
	public PgwMerchantContact findAllMerchantContact();


	@Query("select u from PgwMerchantContact u where u.cntctId = :cntctId ")
	public PgwMerchantContact findByMerchantContactId(@Param("cntctId") int genInfo);


	@Query("select u from PgwMerchantContact u where u.merchantId = :merchantId ")
	public PgwMerchantContact findMerContactByMerchantId(@Param("merchantId") String merchantId);


	@Query("select u from PgwMerchantContact u where u.email = :email")
	public PgwMerchantContact findMerchantForBlacklistByEmail(@Param("email") String email);


	@Query("select u from PgwMerchantContact u where u.mphone = :mphone")
	public PgwMerchantContact findMerchantForBlacklistByMobile(@Param("mphone") String mphone);


	@Query("select count(u) from PgwMerchantContact u ")
	public int totalRecords();

}