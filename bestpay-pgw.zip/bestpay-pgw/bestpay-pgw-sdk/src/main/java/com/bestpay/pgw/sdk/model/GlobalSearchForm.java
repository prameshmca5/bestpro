/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.util.Date;


/**
 * @author Mary Jane Buenaventura
 * @since Aug 29, 2016
 */
public class GlobalSearchForm implements Serializable {

	private static final long serialVersionUID = -6228256064374507575L;

	private Date applyDtFrom;

	private Date applyDtTo;

	private Date apprvdDtFrom;

	private Date apprvdDtTo;

	private String cmpnyRegNo;

	private String appRefNo;

	private String errorMsg;


	public Date getApplyDtFrom() {
		return applyDtFrom;
	}


	public void setApplyDtFrom(Date applyDtFrom) {
		this.applyDtFrom = applyDtFrom;
	}


	public Date getApplyDtTo() {
		return applyDtTo;
	}


	public void setApplyDtTo(Date applyDtTo) {
		this.applyDtTo = applyDtTo;
	}


	public String getCmpnyRegNo() {
		return cmpnyRegNo;
	}


	public void setCmpnyRegNo(String cmpnyRegNo) {
		this.cmpnyRegNo = cmpnyRegNo;
	}


	public String getAppRefNo() {
		return appRefNo;
	}


	public void setAppRefNo(String appRefNo) {
		this.appRefNo = appRefNo;
	}


	public Date getApprvdDtFrom() {
		return apprvdDtFrom;
	}


	public void setApprvdDtFrom(Date apprvdDtFrom) {
		this.apprvdDtFrom = apprvdDtFrom;
	}


	public Date getApprvdDtTo() {
		return apprvdDtTo;
	}


	public void setApprvdDtTo(Date apprvdDtTo) {
		this.apprvdDtTo = apprvdDtTo;
	}


	public String getErrorMsg() {
		return errorMsg;
	}


	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

}