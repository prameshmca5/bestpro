/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwMerchantSubscriptionRepository;
import com.bestpay.be.model.PgwMerchantSubscription;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since June 25, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_MERCHANT_SUBSCRIPTION_PLAN_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_SUBSCRIPTION_PLAN_SVC)
public class PgwMerchantSubscriptionService extends AbstractService<PgwMerchantSubscription> {

	@Autowired
	private PgwMerchantSubscriptionRepository merchantSubscriptionDao;


	@Override
	public PgwMerchantSubscriptionRepository primaryDao() {
		return merchantSubscriptionDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantSubscription findSubscriptionPlanByMerchantId(String merchantId) {
		return merchantSubscriptionDao.findSubscriptionPlanByMerchantId(merchantId);
	}
}