/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
@JsonIgnoreProperties(ignoreUnknown = false)
@JsonInclude(Include.NON_NULL)
public class Documents implements Serializable {

	private static final long serialVersionUID = 106316930304813799L;

	private Integer docId;

	private String trxnNo;

	private String title;

	private String type;

	private int size;

	private boolean isCompulsary;

	private boolean isDimensionCompulsary;

	private Integer minWidth;

	private Integer maxWidth;

	private Integer minHeight;

	private Integer maxHeight;

	private String docDescEn;

	private String docDescMy;

	private int sortOrder;


	public Integer getDocId() {
		return docId;
	}


	public void setDocId(Integer docId) {
		this.docId = docId;
	}


	public String getTrxnNo() {
		return trxnNo;
	}


	public void setTrxnNo(String trxnNo) {
		this.trxnNo = trxnNo;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public int getSize() {
		return size;
	}


	public void setSize(int size) {
		this.size = size;
	}


	public boolean isCompulsary() {
		return isCompulsary;
	}


	public void setCompulsary(boolean isCompulsary) {
		this.isCompulsary = isCompulsary;
	}


	public boolean isDimensionCompulsary() {
		return isDimensionCompulsary;
	}


	public void setDimensionCompulsary(boolean isDimensionCompulsary) {
		this.isDimensionCompulsary = isDimensionCompulsary;
	}


	public Integer getMinWidth() {
		return minWidth;
	}


	public void setMinWidth(Integer minWidth) {
		this.minWidth = minWidth;
	}


	public Integer getMaxWidth() {
		return maxWidth;
	}


	public void setMaxWidth(Integer maxWidth) {
		this.maxWidth = maxWidth;
	}


	public Integer getMinHeight() {
		return minHeight;
	}


	public void setMinHeight(Integer minHeight) {
		this.minHeight = minHeight;
	}


	public Integer getMaxHeight() {
		return maxHeight;
	}


	public void setMaxHeight(Integer maxHeight) {
		this.maxHeight = maxHeight;
	}


	public String getDocDescEn() {
		return docDescEn;
	}


	public void setDocDescEn(String docDescEn) {
		this.docDescEn = docDescEn;
	}


	public String getDocDescMy() {
		return docDescMy;
	}


	public void setDocDescMy(String docDescMy) {
		this.docDescMy = docDescMy;
	}


	public int getSortOrder() {
		return sortOrder;
	}


	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}

}