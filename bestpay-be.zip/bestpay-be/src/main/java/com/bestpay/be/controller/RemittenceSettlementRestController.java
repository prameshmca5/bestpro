package com.bestpay.be.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwSettlement;
import com.bestpay.be.model.RefChannel;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.SettlementInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;


/**
 * @author Ramesh Pogiannan
 * @since June 6, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.REMITTENCE_SETTLEMENT)
public class RemittenceSettlementRestController extends AbstractRestController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());


	@PostMapping(value = BeUrlConstants.SETTLEMENT_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<PgwSettlement> settlementListPaginated(@Valid @RequestBody SettlementInfo settlementInfo,
			HttpServletRequest request) {

		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwSettlement> result = pgwSettlementService.searchRemittenceSettlement(settlementInfo,
				dataTableInRQ);

		DataTableResults<PgwSettlement> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<PgwSettlement> bpLst = new ArrayList<>();
				for (PgwSettlement bbp : result.getData()) {
					RefChannel channel = refChannelSvc.findRefChannelByPublicName(bbp.getChannel());
					if (!BaseUtil.isObjNull(bbp.getChannel())) {
						bbp.setChannel(channel.getName());
					}
					PgwSettlement trustee = dozerMapper.map(bbp, PgwSettlement.class);
					logger.info("getModifyDate - {}", bbp.getModifyDate());
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		return dataTableInResp;
	}


	@GetMapping(value = "/{settlementId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public SettlementInfo findSettlementBySetId(@PathVariable Integer settlementId) {

		PgwSettlement pgwSettlement = super.pgwSettlementService.findSettlementBySetId(settlementId);

		SettlementInfo settlementInfo = new SettlementInfo();
		if (!BaseUtil.isObjNull(pgwSettlement)) {
			settlementInfo = dozerMapper.map(pgwSettlement, SettlementInfo.class);
		}

		return settlementInfo;
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public SettlementInfo updateSettlementStatus(@Valid @RequestBody SettlementInfo settlementInfo,
			HttpServletRequest request, HttpServletResponse response) throws BeException {

		if (settlementInfo == null) {// settlement null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}

		if (StringUtils.isBlank(settlementInfo.getStatus())) {// no status
			throw new BeException(BeErrorCodeEnum.I400IDM137, new String[] { "Status", "Status" });
		}

		PgwSettlement settlement = super.pgwSettlementService.findSettlementBySetId(settlementInfo.getSettlementId());

		if (!BaseUtil.isObjNull(settlement)) {
			settlement.setStatus(settlementInfo.getStatus());
			settlement.setUpdateId(settlementInfo.getUserId());
			super.pgwSettlementService.update(settlement);
		}

		SettlementInfo sttlmtInfo = new SettlementInfo();
		PgwSettlement updateSettlement = super.pgwSettlementService
				.findSettlementBySetId(settlementInfo.getSettlementId());
		if (!BaseUtil.isObjNull(updateSettlement)) {
			sttlmtInfo = dozerMapper.map(updateSettlement, SettlementInfo.class);
		}
		return sttlmtInfo;
	}
}
