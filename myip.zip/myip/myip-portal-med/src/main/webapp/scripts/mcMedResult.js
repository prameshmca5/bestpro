/** MedicalResultController **/
$(document).ready(function() {

	/* COUNTDOWN SECTION*/
	/**
	 * Fuction countdown - return in selector defined
	 * @param {Date} endDateTime - example "Jan 5, 2021 15:37:25"
	 * @param {*} element - pass selector 'demo' for <p id="demo"></p> -> var demo = $("#demo");
	 * @param {string} endMessage - default to "EXPIRED". 
	 */
	function countdownTimer (endDateTime, element, endMessage) {
		// Set the date we're counting down to
		var countDownDate = new Date(endDateTime).getTime();
	
		// Update the count down every 1 second
		var x = setInterval(function() {
	
			// Get today's date and time
			var now = new Date().getTime();
	
			// Find the distance between now and the count down date
			var distance = countDownDate - now;
	
			// Time calculations for days, hours, minutes and seconds
			var days = Math.floor(distance / (1000 * 60 * 60 * 24));
			var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
			var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
			var seconds = Math.floor((distance % (1000 * 60)) / 1000);
	
			var lblDay = days > 1 ? " days  " : " day  ";
	        var lblHour = hours > 1 ? " hours  " : " hour  ";
	        var lblMinute = minutes > 1 ? " minutes " : " minute ";
	        var lblSecond = seconds > 1 ? " seconds " : " second ";
	        // Display the result in the element with id="demo"
	//        $(element).val( days + lblDay + hours + lblHour + minutes + lblMinute + seconds + lblSecond);
	        $(element).val( days + lblDay + hours + lblHour + minutes + lblMinute);
	
			// If the count down is finished, write some text
			if (distance < 0) {
				clearInterval(x);
				if (endMessage) {
					$(element).val( endMessage );
				} else {
					$(element).val( "EXPIRED" );
				}
			}
		}, 100);
	}
	
	if($("#addedTimeMedTest").length > 0) countdownTimer($("#addedTimeMedTest").val(), ".countdown", "0 Day 0 Hour 0 Minute");
	/* END COUNTDOWN SECTION */

	/*****Medical Date Start***/
	var start = $('input[name="attendanceDtFrom"]').val('');
	var end =  $('input[name="attendanceDtTo"]').val('');
	function cb(start, end) {
	    if(start) {
	        $('input[name="attendanceDtFrom"]').val(start.format('DD/MM/YYYY'));            
	    }
	    
	    if(end) {
	        $('input[name="attendanceDtTo"]').val(end.format('DD/MM/YYYY'));            
	    }
	}

	$('#createDtRange').daterangepicker({
	    minDate: moment("2020-01-01"),
	    startDate: start,
	    endDate: end,
	    minYear: 2019,
	    ranges: {
	       'Today': [moment(), moment()],
	       'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
	       'Last 7 Days': [moment().subtract(6, 'days'), moment()],
	       'Last 30 Days': [moment().subtract(29, 'days'), moment()],
	       'This Month': [moment().startOf('month'), moment().endOf('month')],
	       'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
	    }
	});

	$('#createDtRange').on('apply.daterangepicker', function(ev, picker) {
	    $('input[name="attendanceDtFrom"]').val(picker.startDate.format('DD/MM/YYYY'));   
	    $('input[name="attendanceDtTo"]').val(picker.endDate.format('DD/MM/YYYY'));   
	});

	$('#createDtRange').on('cancel.daterangepicker', function(ev, picker) {
	    $('input[name="attendanceDtFrom"]').val('');   
	    $('input[name="attendanceDtTo"]').val('');   
	});

/*****Medical Date End***/

	/*// date drop down
	$('#dateProfRegDob').daterangepicker({
		singleDatePicker: true,
		showDropdowns: true,
		endDate : new Date(),
		maxDate: new Date(),
		minYear: 1901,
		maxYear: parseInt(moment().format('YYYY'), 15),
		locale: { format: "DD/MM/YYYY" },
	}, function(start, end, label) {
		$('input[name="dob"]').val(start.format('DD/MM/YYYY'))
	});
	// date dropdown
	$('#dateProfRegPassportExpiryDt').daterangepicker({
		singleDatePicker: true,
		showDropdowns: true,
		endDate : new Date(),
		// maxDate: new Date(),
		minYear: 1901,
		maxYear: parseInt(moment().format('YYYY'), 15),
		locale: { format: "DD/MM/YYYY" },
	}, function(start, end, label) {
		$('input[name="passportExpiryDt"]').val(start.format('DD/MM/YYYY'))
	});	
	// date drop down
	$('#dateFromMedicalResult').daterangepicker({
		singleDatePicker: true,
		showDropdowns: true,
		endDate : new Date(),
		// maxDate: new Date(),
		minYear: 1901,
		maxYear: parseInt(moment().format('YYYY'), 15),
		locale: { format: "DD/MM/YYYY" },
	}, function(start, end, label) {
		$('input[name="dateFromMedicalResult"]').val(start.format('DD/MM/YYYY'))
	});
	// date dropdown
	$('#dateToMedicalResult').daterangepicker({
		singleDatePicker: true,
		showDropdowns: true,
		endDate : new Date(),
		// maxDate: new Date(),
		minYear: 1901,
		maxYear: parseInt(moment().format('YYYY'), 15),
		locale: { format: "DD/MM/YYYY" },
	}, function(start, end, label) {
		$('input[name="dateToMedicalResult"]').val(start.format('DD/MM/YYYY'))
	});	
	
	var start = $('input[name="createDtFrom"]').val('');
    var end =  $('input[name="createDtTo"]').val('');
    function cb(start, end) {
    	
    	if(start) {
    		$('input[name="createDtFrom"]').val(start.format('DD/MM/YYYY'));    		
    	}
    	
    	if(end) {
    		$('input[name="createDtTo"]').val(end.format('DD/MM/YYYY'));    		
    	}
    }

    $('#createDtRange').daterangepicker({
    	minDate: moment("2020-01-01"),
        startDate: start,
        endDate: end,
        minYear: 2019,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    });

    $('#createDtRange').on('apply.daterangepicker', function(ev, picker) {
    	$('input[name="createDtFrom"]').val(picker.startDate.format('DD/MM/YYYY'));   
    	$('input[name="createDtTo"]').val(picker.endDate.format('DD/MM/YYYY'));   
    });

    $('#createDtRange').on('cancel.daterangepicker', function(ev, picker) {
    	$('input[name="createDtFrom"]').val('');   
    	$('input[name="createDtTo"]').val('');   
    });*/

	// form validation
	/*$('#medResultFormId').validate({ // initialize the plugin
        rules: {
			'tvl.tvlProfile.fullName' : {
				required: true
			},
			'tvl.tvlProfile.acctPassport.passportNo' : {
				required: true
			},
            'tvl.tvlProfile.email' : {
				required: true,
                email: true
            },
            'emailToCompare': {
				required: true,
				email: true,
				equalTo: '#tvl\\.tvlProfile\\.email'
			},
			'tvl.tvlProfile.stateDesc' : {
				required: true
			},
			'tvl.tvlProfile.zipcode' : {
				required: true
			},
			'tvl.tvlProfile.cityDesc' : {
				required: true
			}
		},
		messages : {
			'tvl.tvlProfile.fullName': {
				required: "Please enter full name."
			},
            'emailToCompare': {
				equalTo: "Please enter the same email as above."
            }
		}
	});*/

	// search datatable - start
    var oTableMedRstLst = $('#tblMedicalResultLst').DataTable({
		"processing": true,
	    "serverSide": true,
	    'responsive': true,
	    'destroy' : true,
	    "columns": [
	    		{ "data": null, "orderable" : false },
	    		{ "data": "tvlProfile.tvlMcAttendances[0].createDt",// //mcattendance Date
	    			 "render": function (data, type, row) {
	    		            if (data) {
	    		                     var date = new Date(data);
	    		                    var dd = date.getDate();
	    		                    var mm = date.getMonth()+1;
	    		                    var yyyy = date.getFullYear();
	    		                   
	    		                    if (dd<10) {
	    		                        dd = "0"+dd;
	    		                    }
	    		                    if (mm<10) {
	    		                        mm = "0"+mm;
	    		                    }
	    		               
	    		                    return dd+"/"+mm+"/"+yyyy;
	    		                }
	    		            return "-";
	    		        },
  	            },
	    		 { "data": "tvlProfile.acctPassport.passportNo" }, 
	    		 { "data": "tvlProfile.fullName" }, 
	    		 { "data": "tvlProfile.gender",
	  	            	"render": function (data, type, row) { 
	  	            		var gender = "-";
	  	            		if(data) {
	  	            			if(data == 'M') {
	  	            				gender = "Male";
	  	            			} else if(data == 'F') {
	  	            				gender = "Female";
	  	            			} 
	  	            		}
	            			return gender;
	  	            	},
	            	},
	    		 { "data": "tvlProfile.dob",
		    			 "render": function (data, type, row) {
		    		            if (data) {
		    		                     var date = new Date(data);
		    		                    var dd = date.getDate();
		    		                    var mm = date.getMonth()+1;
		    		                    var yyyy = date.getFullYear();
		    		                   
		    		                    if (dd<10) {
		    		                        dd = "0"+dd;
		    		                    }
		    		                    if (mm<10) {
		    		                        mm = "0"+mm;
		    		                    }
		    		               
		    		                    return dd+"/"+mm+"/"+yyyy;
		    		                }
		    		            return "-";
		    		        },		
	    		 },
	    		 { "data": "tvlProfile.acctPassport.nationality.cntryDesc", "searchable" : true, "orderable" : true,
	    			 "render": function (data, type, row) {
	    				if(data != null){
	    					 return data;
	    				 }else{
	    					 return "-";
	    				}
	  	            },
	    		 },
	    		 
	    		 { "data": "status.statusDesc", "searchable" : true, "orderable" : true,
	    			 "render": function (data, type, row) {
	    				if(data != null){
	    					 return data;
	    				 }else{
	    					 return "-";
	    				}
	  	            },
	    		 },
	           
//	            { "data": "status", "searchable" : true, "orderable" : true, 
//  	            	"render": function (data, type, row) {
//  	            		return data!=null ? data.statusDesc : "-";
//  	            	},
//  	            },
	            { "data": null, "searchable" : false, "orderable" : false, 
  	            	"render": function ( data, type, row ) {
  	            		
  	            		var isCanUpdate = $("#isDrAccess").val();
  	            		var title = "Update Medical Result";
  	            		
  	            		if(isCanUpdate == "true" || data.status.statusCd=="MC_PEND"){
  	            			var title = "Approve Medical Result";
  	            			iconStr = '<i class="mdi mdi-checkbox-multiple-marked"></i>';
  	            			
  	            		}else{
  	            			iconStr = '<i class="mdi mdi-clipboard-check"></i>';
  	            		}
  	            		
  	            		if(data.status.statusCd =="MC_APR" || data.status.statusCd =="MC_REJ"){
  	            			var transferCase = '<center><a title="View Profile" class="mr-2" href=' + contextPath + '/mcTest/view/'+ row.secCdId +'><i class="fa fa-eye fa-lg"></i></a></center>';
  	            		}else{
  	            			var transferCase ='<center><a title="'+title+'" class="mr-2" href=' + contextPath + '/mcTest/'+ row.secCdId + '/update >'+iconStr+'</i></a>';
  	            		}
  	            		
  	            		return transferCase;
  	            	}
  	            },
	          ],
		"ajax": $.fn.dataTable.pipeline({
			"pages" : 1,
        	"type" : "GET",
            "url": contextPath + "/mcTest/paginated",
            "action": 'xhttp',
            'beforeSend': dtRequestHeader,
            "dataSrc": dtDataSrc,
            "data": function ( data ) {
            	data.attendanceDtFrom = $('input[name="attendanceDtFrom"]').val();
            	data.attendanceDtTo = $('input[name="attendanceDtTo"]').val();
            	data.passportNo = $("#passportNo").val().toUpperCase();
            	data.fullName = $("#fullName").val().toUpperCase();
            	data.statusCd = $("#statusCd").val();
            	
            },
            "error": function(){  // error handling
            	console.log("error");
            }
      	 }),
      	"initComplete": function(settings, json) {
      		/*$('input#attendanceDtFrom').unbind();
      		$('input#attendanceDtTo').unbind();*/
      		$('input#fullName').unbind();
      		$('input#passportNo').unbind();
      		$('#searchFilter').bind('click', function(e) {
            	portalUtil.showMainLoading(true);
            	oTableMedRstLst
            	.column(1).search($('input[name="attendanceDtFrom"]').val())
                .column(1).search($('input[name="attendanceDtTo"]').val())
                .column(2).search($('input#passportNo').val())
            	.column(3).search($('input#fullName').val())
            	.column(7).search($('#statusCd').val())
                oTableMedRstLst.draw();
            	$(".em-toggle").click();
            });
            $('#searchClear').bind('click', function(e) {
            	$('input[name="attendanceDtFrom"]').val("")
            	$('input[name="attendanceDtTo"]').val("")
            	$('input#passportNo').val("")
            	$('input#fullName').val("")
            	$('#select2-statusCd-container').text("- Please Select -")
            	$("#statusCd").val("");
            	oTableMedRstLst.columns().search("").draw();
            	$(".em-toggle").click();
            });
           
        },

		"language" : {
			"emptyTable" : prop.dtbEmptyTable
		},
      	"fnDrawCallback": function ( oSettings ) { processRowNum(oSettings); hidePagination(this,"#tblMedicalResultLst");portalUtil.showMainLoading(false);} 
	});
	// search datatable - end
});

function documentViewMedicalReport(reportName) {
	var tvlProf = $('#profId').val();
	var path = '/mcTest/medicalReport/viewreport.pdf';
	var url = contextPath + path + "?tvlProfId="+tvlProf;
	console.log("url",url);
	title = "MEDICAL REPORT"
	jQuery("#rptTtl").html(title);
	var object = '<div id="pdfUrlId" width="100%" height="100%"></div>';

	jQuery("#pdfUrl").replaceWith(object);
	
	PDFObject.embed(url, "#pdfUrlId", {
		pdfOpenParams: {
			width: "100%",
			height: "100%"
		}
	});
	
  jQuery("#rptDialog" ).modal( "show" );
}


$(document).on('click','#radiobutton-medResult',function(){
	// console.log($(this).prop("checked"));
	       $('#submitFormBtn').removeAttr('disabled');
});



function documentViewMedicalReport(reportName) {
	var tvlProf = $('#profId').val();
	var path = '/mcTest/medicalReport/viewreport.pdf';
	var url = contextPath + path + '?reportName=' + reportName +"&tvlProfId="+tvlProf;
	title = "MEDICAL REPORT"
	jQuery("#rptTtl").html(title);
	var object = '<div id="pdfUrlId" width="100%" height="100%"></div>';

	jQuery("#pdfUrl").replaceWith(object);
	
	PDFObject.embed(url, "#pdfUrlId", {
		pdfOpenParams: {
			width: "100%",
			height: "100%"
		}
	});
	
  jQuery("#rptDialog" ).modal( "show" );
}

function genReportMedical(reportPath,title) {
	
	if ($('#medicalDocMgtId').val() != '' ) {
		var docMgtId = $('#medicalDocMgtId').val();
	}
	
	var path = '/mcTest/report/viewreport.pdf';
	var url = contextPath + path + "?docMgtId="+docMgtId;
	title = "MEDICAL REPORT"
	jQuery("#rptTtl").html(title);
	var object = '<div id="pdfUrlId" width="100%" height="100%"></div>';

	jQuery("#pdfUrl").replaceWith(object);
	
	PDFObject.embed(url, "#pdfUrlId", {
		height: "500px",
		pdfOpenParams: {
			width: "100%",
			height: "100%"
		}
	});
	
  jQuery("#rptDialog" ).modal( "show" );
}

function genTahss(reportPath,title) {
	
	if($('#myIpSlipDocMgtId').val() != '' ){
		var docMgtId = $('#myIpSlipDocMgtId').val();
	}
	
	var path = '/mcTest/report/viewreport.pdf';
	var url = contextPath + path + "?docMgtId="+docMgtId;
	title = "TAHSS SLIP"
	jQuery("#rptTtl").html(title);
	var object = '<div id="pdfUrlId" width="100%" height="100%"></div>';

	jQuery("#pdfUrl").replaceWith(object);
	
	PDFObject.embed(url, "#pdfUrlId", {
		height: "500px",
		pdfOpenParams: {
			width: "100%",
			height: "100%"
		}
	});
	
  jQuery("#rptDialog" ).modal( "show" );
}

function genReport(reportPath, title) {

	var url = contextPath + reportPath;
	jQuery("#rptTtl").html(title);
	var object = '<div id="pdfUrlId" width="100%" height="100%"></div>';

	jQuery("#pdfUrl").replaceWith(object);

	PDFObject.embed(url, "#pdfUrlId", {
		height : "500px",
		pdfOpenParams : {
			width : "100%",
			height : "100%"
		}
	});

	jQuery("#rptDialog").modal("show");
}

function genReportPayment(reportName,title,path) {
	var pmtRef = $('#pmtRefId').val();
	var url = contextPath + path + '?reportName=' + reportName +"&pmtRefNo="+pmtRef;
	jQuery("#rptTtl").html(title);
	var object = '<div id="pdfUrlId" width="100%" height="100%"></div>';

	jQuery("#pdfUrl").replaceWith(object);
	
	PDFObject.embed(url, "#pdfUrlId", {
		height: "500px",
		pdfOpenParams: {
			width: "100%",
			height: "100%"
		}
	});
	
  jQuery("#rptDialog" ).modal( "show" );
}
