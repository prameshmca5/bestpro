package com.bestpay.be.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */

@Repository
@RepositoryDefinition(domainClass = PgwMerchantProfile.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MER_PROFILE_DAO)
public interface PgwMerchantProfileRepository extends GenericRepository<PgwMerchantProfile> {

	@Query("select u from PgwMerchantProfile u ")
	PgwMerchantProfile findAllMerchantProfile();


	@Query("select u from PgwMerchantProfile u where u.merProfId = :merProfId ")
	PgwMerchantProfile findByMerchantProfileId(@Param("merProfId") int accInfo);


	@Query("select u from PgwMerchantProfile u where u.merchantId = :merchantId ")
	PgwMerchantProfile findMerProfileByMerchantId(@Param("merchantId") String merchantId);


	@Query("select count(u) from PgwMerchantProfile u ")
	int totalRecords();


	@Query("select u from PgwMerchantProfile u where u.acStatus='ACTIVE'")
	List<PgwMerchantProfile> findAllMerchantProfileList();


	@Query("select u from PgwMerchantProfile u where u.expireDate=SUBDATE(CURDATE(),1) and acStatus='ACTIVE' ")
	List<PgwMerchantProfile> findExpiredMerchantList();


	@Query("select concat(u.acStatus, '-',cast(count(*) as int)) from PgwMerchantProfile u group by u.acStatus ")
	List<String> getCountByStatus();


	@Query("select u from PgwMerchantProfile u where u.ownerDirectorNationalId = :ownerDirectorNationalId")
	List<PgwMerchantProfile> findByOwnerNationalId(@Param("ownerDirectorNationalId") String ownerDirectorNationalId);
}