/**
 * 
 */
package com.be.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author michelle.angela
 *
 */
 @Entity
 @Table(name = "BE_TVL_PAYMENT_DTL")
public class BeTvlPaymentDtl extends AbstractEntity implements Serializable, IQfCriteria<BeTvlPaymentDtl> {

	private static final long serialVersionUID = -7111654706871384033L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="TVL_PMT_DTL_ID")
	private Integer tvlPmtDtlId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TVL_PMT_ID")
	private BeTvlPayment tvlPayment;
	
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="TVL_PROF_ID")
	private BeTvlProfile tvlProfile;
	
	@Column(name = "AMOUNT")
	private double amount;
	
	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;
	
	@JsonIgnoreProperties("tvlPaymentDtl")
	@OneToMany(mappedBy = "tvlPaymentDtl", fetch = FetchType.LAZY)
	private Set<BeTvlPaymentInfo> tvlPaymentInfos;
	
	@JsonIgnoreProperties("tvlPaymentDtl")
	@OneToMany(mappedBy = "tvlPaymentDtl", fetch = FetchType.LAZY)
	private Set<BeTvlRefund> tvlRefunds;
	
	@Transient
	private BeAcctTraveller acctTraveller;

	public Integer getTvlPmtDtlId() {
		return tvlPmtDtlId;
	}

	public void setTvlPmtDtlId(Integer tvlPmtDtlId) {
		this.tvlPmtDtlId = tvlPmtDtlId;
	}

	public BeTvlPayment getTvlPayment() {
		return tvlPayment;
	}

	public void setTvlPayment(BeTvlPayment tvlPayment) {
		this.tvlPayment = tvlPayment;
	}

	public BeTvlProfile getTvlProfile() {
		return tvlProfile;
	}

	public void setTvlProfile(BeTvlProfile tvlProfile) {
		this.tvlProfile = tvlProfile;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public Set<BeTvlPaymentInfo> getTvlPaymentInfos() {
		return tvlPaymentInfos;
	}

	public void setTvlPaymentInfos(Set<BeTvlPaymentInfo> tvlPaymentInfos) {
		this.tvlPaymentInfos = tvlPaymentInfos;
	}

	public Set<BeTvlRefund> getTvlRefunds() {
		return tvlRefunds;
	}

	public void setTvlRefunds(Set<BeTvlRefund> tvlRefunds) {
		this.tvlRefunds = tvlRefunds;
	}

	public BeAcctTraveller getAcctTraveller() {
		return acctTraveller;
	}

	public void setAcctTraveller(BeAcctTraveller acctTraveller) {
		this.acctTraveller = acctTraveller;
	}
	
}
