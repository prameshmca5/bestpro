/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dialect.processor;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.thymeleaf.Arguments;
import org.thymeleaf.dom.Element;
import org.thymeleaf.dom.Text;
import org.thymeleaf.exceptions.TemplateProcessingException;
import org.thymeleaf.processor.ProcessorResult;
import org.thymeleaf.spring4.context.SpringWebContext;

import com.bestpay.idm.sdk.client.IdmServiceClient;
import com.bestpay.idm.sdk.constants.IdmErrorCodeEnum;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.UserMenu;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.config.ConfigConstants;
import com.bestpay.web.config.iam.CustomUserDetails;
import com.bestpay.web.dialect.AbstractBstElement;
import com.bestpay.web.dialect.constants.AttributeConstants;
import com.bestpay.web.dialect.constants.ElementConstants;
import com.bestpay.web.dialect.constants.ElementEnum;
import com.bestpay.web.util.MessageService;
import com.bestpay.web.util.WebUtil;
import com.bstsb.util.UidGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class MenuElementProcessor extends AbstractBstElement {

	private static final Logger LOGGER = LoggerFactory.getLogger(MenuElementProcessor.class);


	public MenuElementProcessor() {
		super("menu");
	}


	public MenuElementProcessor(String elementName) {
		super(elementName);
	}


	public IdmServiceClient getIdmService(Arguments arguments) {
		final ApplicationContext appCtx = ((SpringWebContext) arguments.getContext()).getApplicationContext();
		IdmServiceClient idmService = appCtx.getBean(IdmServiceClient.class);
		MessageService messageService = appCtx.getBean(MessageService.class);
		if (!BaseUtil.isObjNull(messageService) && !BaseUtil.isObjNull(idmService)) {
			String authToken = getAuthToken();
			LOGGER.debug("authToken: {}", authToken);
			if (BaseUtil.isObjNull(idmService)) {
				idmService = new IdmServiceClient(messageService.getMessage(ConfigConstants.SVC_IDM_URL));
			}
			if (authToken != null) {
				idmService.setToken(authToken);
			} else {
				idmService.setToken(messageService.getMessage("idm.service.skey"));
			}
			idmService.setClientId(messageService.getMessage("idm.service.client"));
			idmService.setMessageId(UidGenerator.getMessageId());
		}
		return idmService;
	}


	@Override
	protected ProcessorResult processElement(Arguments arguments, Element element) {
		String elementNm = getElementName(element);
		if (elementNm.contains(ElementEnum.MENU.getName())) {
			Element newElement = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_UL,
					false);
			newElement.setRecomputeProcessorsImmediately(true);
			newElement.setAttribute(AttributeConstants.ATTR_CLASS, ElementEnum.findStyleByName(elementNm));

			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			if (auth.isAuthenticated() && auth.getPrincipal() instanceof CustomUserDetails) {
				CustomUserDetails cud = (CustomUserDetails) auth.getPrincipal();
				if (!BaseUtil.isEqualsCaseIgnore(cud.getProfile().getStatus(), "F")) {
					LOGGER.debug("CustomUserDetails: {}", cud.getUsername());
					LOGGER.debug("CustomUserDetails: {}", new ObjectMapper().valueToTree(cud));
					UserProfile up = cud.getProfile();
					List<UserMenu> menuList = null;
					if (!BaseUtil.isObjNull(up) && !BaseUtil.isListNull(up.getMenusList())
							&& !BaseUtil.isListZero(up.getMenusList())) {
						try {
							IdmServiceClient idmService = getIdmService(arguments);
							menuList = idmService.findAllMenusByUserId(up.getUserId());
						} catch (IdmException e) {
							if (WebUtil.checkTokenError(e)) {
								throw new TemplateProcessingException(e.getInternalErrorCode());
							}
							LOGGER.error("IdmException: {}", e.getInternalErrorCode());
							if (BaseUtil.isEqualsCaseIgnore(IdmErrorCodeEnum.E503IDM000.name(),
									e.getInternalErrorCode())) {
								throw new TemplateProcessingException(e.getInternalErrorCode());
							}
						} catch (Exception e) {
							LOGGER.error("Exception: {}", e.getMessage());
							menuList = up.getMenusList();
						}
						LOGGER.debug("menuList: {}", new ObjectMapper().valueToTree(menuList));
						processMenu(newElement, menuList, 1);
					}
				}
			}

			element.getParent().insertAfter(element, newElement);
		}
		element.getParent().removeChild(element);
		return ProcessorResult.OK;
	}


	@Override
	public int getPrecedence() {
		return 0;
	}


	private Element rootMenuElement() {
		return new Element(ElementConstants.HTML_LI);
	}


	private Element subMenuElement() {
		Element li = new Element(ElementConstants.HTML_UL);
		li.setAttribute(AttributeConstants.ATTR_CLASS, "sub-menu");
		return li;
	}


	private Element labelMenuElement(UserMenu menuNode, int level) {
		Element a = new Element(ElementConstants.HTML_ANCHOR);
		Element i = new Element(ElementConstants.HTML_I);
		if (!BaseUtil.isObjNull(menuNode.getMenuIcon())) {
			i.setAttribute(AttributeConstants.ATTR_CLASS, menuNode.getMenuIcon());
			a.addChild(i);
		}
		Element spanTitle = new Element(ElementConstants.HTML_SPAN);
		spanTitle.setAttribute(AttributeConstants.ATTR_CLASS, "title");
		int chldCnt = !BaseUtil.isObjNull(menuNode.getMenuChild()) ? menuNode.getMenuChild().size() : 0;
		spanTitle.addChild(new Text(menuNode.getMenuDesc()));
		a.addChild(spanTitle);
		if (chldCnt > 0) {
			Element spanArrow = new Element(ElementConstants.HTML_SPAN);
			spanArrow.setAttribute(AttributeConstants.ATTR_CLASS, "arrow");
			a.addChild(spanArrow);
		}
		if (!BaseUtil.isObjNull(menuNode.getMenuUrlCd())) {
			String url = "@{" + menuNode.getMenuUrlCd() + "}";
			a.setAttribute(AttributeConstants.ATTR_TH_HREF, url);
		} else {
			a.setAttribute(AttributeConstants.ATTR_HREF, "#");
		}

		if (chldCnt > 0 && level == 1) {
			a.addChild(caretElement());
		}
		return a;
	}


	private Element caretElement() {
		Element li = new Element(ElementConstants.HTML_SPAN);
		li.setAttribute(AttributeConstants.ATTR_CLASS, "mainnav-caret");
		return li;
	}


	private Element processMenu(Element element, List<UserMenu> menuLst, int level) {
		if (!BaseUtil.isListNull(menuLst) && !BaseUtil.isListZero(menuLst)) {
			for (UserMenu lvlOne : menuLst) {
				int totChild = !BaseUtil.isObjNull(lvlOne.getMenuChild()) ? lvlOne.getMenuChild().size() : 0;
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Level: {} - Menu Level: {} - Menu: {} - Children: {} - URL: {}",
							lvlOne.getMenuLevel(), lvlOne.getMenuLevel(), lvlOne.getMenuDesc(), totChild,
							lvlOne.getMenuUrlCd());
				}
				if (lvlOne.getMenuLevel() == level) {
					List<UserMenu> lvlOneChild = lvlOne.getMenuChild();
					final Element liOne = rootMenuElement();
					liOne.addChild(labelMenuElement(lvlOne, lvlOne.getMenuLevel()));
					if (totChild > 0) {
						final Element lvlOneElement = subMenuElement();
						processMenu(lvlOneElement, lvlOneChild, lvlOne.getMenuLevel() + 1);
						liOne.addChild(lvlOneElement);
					}
					element.addChild(liOne);
				}
			}
		}
		return element;
	}

}