package com.bestid.be.model;


import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;


/**
 * @author mukhlis.hamzah
 * @since 1 Mar 2019
 */
@Entity
@Table(name = "BID_SUBSCRIBER")
public class BidSubscriber implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 735244180220203237L;

	@Id
	@Column(name = "SUBSCR_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer subscrId;

	@Column(name = "SUBSCR_CD")
	private String subscrCd;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "SYS_NAME")
	private String sysName;

	@Column(name = "CMPNY_ID")
	private Integer cmpnyId;

	@Column(name = "SUBSCR_TYPE")
	private String subscrType;
	
	@Column(name = "SYS_LOGO")
	private String sysLogo;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Transient
	private List<Integer> subscrIdList;


	public Integer getSubscrId() {
		return subscrId;
	}


	public void setSubscrId(Integer subscrId) {
		this.subscrId = subscrId;
	}


	public String getSubscrCd() {
		return subscrCd;
	}


	public void setSubscrCd(String subscrCd) {
		this.subscrCd = subscrCd;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getSysName() {
		return sysName;
	}


	public void setSysName(String sysName) {
		this.sysName = sysName;
	}


	public Integer getCmpnyId() {
		return cmpnyId;
	}


	public void setCmpnyId(Integer cmpnyId) {
		this.cmpnyId = cmpnyId;
	}


	public String getSubscrType() {
		return subscrType;
	}


	public void setSubscrType(String subscrType) {
		this.subscrType = subscrType;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public List<Integer> getSubscrIdList() {
		return subscrIdList;
	}


	public void setSubscrIdList(List<Integer> subscrIdList) {
		this.subscrIdList = subscrIdList;
	}


	public String getSysLogo() {
		return sysLogo;
	}


	public void setSysLogo(String sysLogo) {
		this.sysLogo = sysLogo;
	}
	
}
