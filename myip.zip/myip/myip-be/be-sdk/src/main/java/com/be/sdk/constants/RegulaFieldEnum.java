package com.be.sdk.constants;

public enum RegulaFieldEnum {

	COUNTRY(1, "country"),
	DOC_NO(2, "document_no"),
	EXP_DATE(3, "date_of_expiry"),
	ISSUE_DATE(4, "issueDate"),
	DOB(5, "date_of_birth"),
	GENDER(12, "gender"),
	NATIONALITY(26, "nationality"),
	NAME(25, "first_name");
	
	public final int code;

	public final String field;


	RegulaFieldEnum(int code, String field) {
		this.code = code;
		this.field = field;
	}

	public static String findFieldByCode(int code) {
		for (RegulaFieldEnum v : RegulaFieldEnum.values()) {
			if (v.getCode() == code) {
				return v.getField();
			}
		}
		return null;
	}
	
	

	public int getCode() {
		return code;
	}

	public String getField() {
		return field;
	}
	
}
