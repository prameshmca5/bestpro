/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_ACCT_TRAVELLER")
public class BeAcctTraveller extends AbstractEntity implements Serializable, IQfCriteria<BeAcctTraveller> {

	private static final long serialVersionUID = 8286500431185682478L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ACCT_TVLR_ID")
	private Integer acctTvlrId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ACCT_PROF_ID")
	private BeAcctProfile acctProfile;

	@Column(name = "FULL_NAME")
	private String fullName;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "CONTACT_NO")
	private String contactNo;

	@Column(name = "GENDER")
	private String gender;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	@Temporal(TemporalType.DATE)
	@Column(name = "DOB")
	private Date dob;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BIRTH_PLACE")
	private RefCountry birthPlace;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "NATIONALITY")
	private RefCountry nationality;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PASSPORT_ID")
	private BeAcctPassport acctPassport;

	@Column(name = "FACE_ID")
	private Integer faceId;

	@Column(name = "PHOTO_ID")
	private String photoId;

	@Column(name = "PASSPORT_FACE_ID")
	private Integer passportFaceId;

	@Column(name = "PASSPORT_PHOTO_ID")
	private String passportPhotoId;

	@Column(name = "DOC_REF_NO")
	private String docRefNo;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "RELATION_MTDT_ID")
	private RefMetadata relationMtdt;

	@Column(name = "EC_NAME")
	private String emrgncyCntctName;

	@Column(name = "EC_CONTACT_NO")
	private String emrgncyCntctNo;

	@Column(name = "EC_EMAIL")
	private String ecEmail;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EC_RELATION_MTDT_ID")
	private RefMetadata ecRelationMtdt;

	@Column(name = "ADDR_1")
	private String addr1;

	@Column(name = "ADDR_2")
	private String addr2;

	@Column(name = "ADDR_3")
	private String addr3;

	@Column(name = "ADDR_4")
	private String addr4;

	@Column(name = "CITY_DESC")
	private String cityDesc;

	@Column(name = "STATE_DESC")
	private String stateDesc;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNTRY_CD")
	private RefCountry country;

	@Column(name = "ZIPCODE")
	private String zipcode;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TYPE_MTDT_ID")
	private RefMetadata typeMtdt;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "PAID")
	private Boolean isPaid;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "APPS_MTDT_ID")
	private RefMetadata appsMtdt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@JsonIgnoreProperties("acctTraveller")
	@OneToMany(mappedBy = "acctTraveller", fetch = FetchType.LAZY)
	private Set<BeTvlProfile> tvlProfiles;


	public Integer getAcctTvlrId() {
		return acctTvlrId;
	}


	public void setAcctTvlrId(Integer acctTvlrId) {
		this.acctTvlrId = acctTvlrId;
	}


	public BeAcctProfile getAcctProfile() {
		return acctProfile;
	}


	public void setAcctProfile(BeAcctProfile acctProfile) {
		this.acctProfile = acctProfile;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public RefCountry getNationality() {
		return nationality;
	}


	public void setNationality(RefCountry nationality) {
		this.nationality = nationality;
	}


	public BeAcctPassport getAcctPassport() {
		return acctPassport;
	}


	public void setAcctPassport(BeAcctPassport acctPassport) {
		this.acctPassport = acctPassport;
	}


	public Integer getFaceId() {
		return faceId;
	}


	public void setFaceId(Integer faceId) {
		this.faceId = faceId;
	}


	public String getPhotoId() {
		return photoId;
	}


	public void setPhotoId(String photoId) {
		this.photoId = photoId;
	}


	public Integer getPassportFaceId() {
		return passportFaceId;
	}


	public void setPassportFaceId(Integer passportFaceId) {
		this.passportFaceId = passportFaceId;
	}


	public String getPassportPhotoId() {
		return passportPhotoId;
	}


	public void setPassportPhotoId(String passportPhotoId) {
		this.passportPhotoId = passportPhotoId;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public RefMetadata getRelationMtdt() {
		return relationMtdt;
	}


	public void setRelationMtdt(RefMetadata relationMtdt) {
		this.relationMtdt = relationMtdt;
	}


	public String getEmrgncyCntctName() {
		return emrgncyCntctName;
	}


	public void setEmrgncyCntctName(String emrgncyCntctName) {
		this.emrgncyCntctName = emrgncyCntctName;
	}


	public String getEmrgncyCntctNo() {
		return emrgncyCntctNo;
	}


	public void setEmrgncyCntctNo(String emrgncyCntctNo) {
		this.emrgncyCntctNo = emrgncyCntctNo;
	}


	public String getEcEmail() {
		return ecEmail;
	}


	public void setEcEmail(String ecEmail) {
		this.ecEmail = ecEmail;
	}


	public RefMetadata getEcRelationMtdt() {
		return ecRelationMtdt;
	}


	public void setEcRelationMtdt(RefMetadata ecRelationMtdt) {
		this.ecRelationMtdt = ecRelationMtdt;
	}


	public RefCountry getBirthPlace() {
		return birthPlace;
	}


	public void setBirthPlace(RefCountry birthPlace) {
		this.birthPlace = birthPlace;
	}


	public String getAddr1() {
		return addr1;
	}


	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}


	public String getAddr2() {
		return addr2;
	}


	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}


	public String getAddr3() {
		return addr3;
	}


	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}


	public String getAddr4() {
		return addr4;
	}


	public void setAddr4(String addr4) {
		this.addr4 = addr4;
	}


	public String getCityDesc() {
		return cityDesc;
	}


	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc;
	}


	public String getStateDesc() {
		return stateDesc;
	}


	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc;
	}


	public RefCountry getCountry() {
		return country;
	}


	public void setCountry(RefCountry country) {
		this.country = country;
	}


	public String getZipcode() {
		return zipcode;
	}


	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}


	public RefMetadata getTypeMtdt() {
		return typeMtdt;
	}


	public void setTypeMtdt(RefMetadata typeMtdt) {
		this.typeMtdt = typeMtdt;
	}


	public Boolean getIsPaid() {
		return isPaid;
	}


	public void setIsPaid(Boolean isPaid) {
		this.isPaid = isPaid;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Set<BeTvlProfile> getTvlProfiles() {
		return tvlProfiles;
	}


	public void setTvlProfiles(Set<BeTvlProfile> tvlProfiles) {
		this.tvlProfiles = tvlProfiles;
	}


	public RefMetadata getAppsMtdt() {
		return appsMtdt;
	}


	public void setAppsMtdt(RefMetadata appsMtdt) {
		this.appsMtdt = appsMtdt;
	}

}
