/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author Ilhomjon
 * @since Feb 22, 2018
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Country implements Serializable {

	private static final long serialVersionUID = -6255425222614429634L;

	private String cntryCode;

	private String cntryDesc;

	private String cntryInd;

	private String mobileCode;

	private String intCallCode;

	private String crncyCode;


	public String getCntryCode() {
		return cntryCode;
	}


	public void setCntryCode(String cntryCode) {
		this.cntryCode = cntryCode;
	}


	public String getCntryDesc() {
		return cntryDesc;
	}


	public void setCntryDesc(String cntryDesc) {
		this.cntryDesc = cntryDesc;
	}


	public String getCntryInd() {
		return cntryInd;
	}


	public void setCntryInd(String cntryInd) {
		this.cntryInd = cntryInd;
	}


	public String getMobileCode() {
		return mobileCode;
	}


	public void setMobileCode(String mobileCode) {
		this.mobileCode = mobileCode;
	}


	public String getIntCallCode() {
		return intCallCode;
	}


	public void setIntCallCode(String intCallCode) {
		this.intCallCode = intCallCode;
	}


	public String getCrncyCode() {
		return crncyCode;
	}


	public void setCrncyCode(String crncyCode) {
		this.crncyCode = crncyCode;
	}

}