/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;

import java.io.Serializable;
import java.sql.Timestamp;

import com.bestpay.be.sdk.constants.BaseConstants;
import com.bestpay.be.sdk.util.JsonTimestampSerializerDash;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author Atiqah Khairuddin
 * @since November 13, 2018
 */
public class Ticket implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private int ticketId;

	private String merchantId;
	
	@JsonSerialize(using = JsonTimestampSerializerDash.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_DASH_TIME_A, locale = "ms_MY", timezone = "Asia/Kuala_Lumpur")
	private Timestamp issuerDate;

	private String name;

	private String contact;

	private String email;

	private String subject;

	private String title;

	private String description;

	private String status;

	private Timestamp modifyDate;

	private String fileName;

	private String category;

	private String supportId;

	private String cc;

	private String comment;

	private String feedback;

	private String module;

	private String createId;

	private Timestamp createDt;

	private String updateId;

	private Timestamp updateDt;

	private String userId;

	private String docMgtId;

	private Integer merProfId;

	private String userRoleGroupCode;

	private String userType;

	public int getTicketId() {
		return ticketId;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public Timestamp getIssuerDate() {
		return issuerDate;
	}

	public void setIssuerDate(Timestamp issuerDate) {
		this.issuerDate = issuerDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Timestamp modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSupportId() {
		return supportId;
	}

	public void setSupportId(String supportId) {
		this.supportId = supportId;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDocMgtId() {
		return docMgtId;
	}

	public void setDocMgtId(String docMgtId) {
		this.docMgtId = docMgtId;
	}

	public Integer getMerProfId() {
		return merProfId;
	}

	public void setMerProfId(Integer merProfId) {
		this.merProfId = merProfId;
	}

	public String getUserRoleGroupCode() {
		return userRoleGroupCode;
	}

	public void setUserRoleGroupCode(String userRoleGroupCode) {
		this.userRoleGroupCode = userRoleGroupCode;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

}
