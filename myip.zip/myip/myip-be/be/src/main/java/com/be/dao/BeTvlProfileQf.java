/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractRestController;
import com.be.core.QueryFactory;
import com.be.model.BeAcctTraveller;
import com.be.model.BeTvlProfile;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.TvlProfile;
import com.be.service.BeAcctPassportService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;


/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_PROFILE_QF)
public class BeTvlProfileQf extends QueryFactory<BeTvlProfile> {

	protected static final Logger LOGGER = LoggerFactory.getLogger(AbstractRestController.class);

	@Autowired
	BeAcctPassportService acctPassportSvc;

	@Autowired
	BeAcctTravellerQf beAcctTravellerQf;

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BeTvlProfile> searchByProperty(BeTvlProfile t) {
		return (Root<BeTvlProfile> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}


	@Override
	public List<BeTvlProfile> searchAllByProperty(BeTvlProfile t) {
		CriteriaQuery<BeTvlProfile> cq = cb.createQuery(BeTvlProfile.class);
		Root<BeTvlProfile> from = cq.from(BeTvlProfile.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public List<BeTvlProfile> searchBeTvlProfilePagination(TvlProfile dto, DataTableRequest<?> dataTableInRQ) {

		List<BeTvlProfile> result = new ArrayList<>();
		CriteriaQuery<BeTvlProfile> cq = cb.createQuery(BeTvlProfile.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlProfile> root = cq.from(BeTvlProfile.class);

			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause if
			// (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				cq.orderBy(getOrderByClause(cb, root, pagination));
			}
		}

		TypedQuery<BeTvlProfile> tQuery = em.createQuery(cq);

		// first result & max Results if (!BaseUtil.isObjNull(dataTableInRQ))
		// {
		PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
		if (!BaseUtil.isObjNull(pagination)) {
			tQuery.setFirstResult(pagination.getPageNumber());
			tQuery.setMaxResults(pagination.getPageSize());
		}

		result = tQuery.getResultList();
		return result;

	}


	public BeTvlProfile searchBeTvlProfile(TvlProfile dto) {

		BeTvlProfile result = null;
		CriteriaQuery<BeTvlProfile> cq = cb.createQuery(BeTvlProfile.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlProfile> root = cq.from(BeTvlProfile.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeTvlProfile> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}


	private void joinFetch(Root<BeTvlProfile> root, List<Predicate> predicates, TvlProfile dto,
			CriteriaQuery<BeTvlProfile> cq) {
		// TODO Auto-generated method stub

	}


	public Long getCount(TvlProfile dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeTvlProfile> root = cq.from(BeTvlProfile.class);
		predicates.addAll(generateCriteria(cb, root, dto));

		Join<BeTvlProfile, BeAcctTraveller> acctTraveller = root.join("acctTraveller", JoinType.LEFT);
		predicates.addAll(beAcctTravellerQf.generateCriteria(cb, acctTraveller, dto.getAcctTraveller()));

		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}


	@SuppressWarnings("rawtypes")
	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			if (!BaseUtil.isObjNull(criteria)) {
				BeTvlProfile dto = JsonUtil.transferToObject(criteria, BeTvlProfile.class);

				if (!BaseUtil.isObjNull(dto.getTvlProfId())) {
					predicates.add(cb.equal(from.get("tvlProfId"), dto.getTvlProfId()));
				}

				if (!BaseUtil.isObjNull(dto.getDisabled()) && dto.getDisabled() == true) {
					predicates.add(cb.or((cb.notEqual(from.get("isDisabled"), dto.getDisabled())),
							(cb.isNull(from.get("isDisabled")))));
				}

				if (!BaseUtil.isObjNull(dto.getTrxnRefNo())) {
					predicates.add(cb.equal(from.get("trxnRefNo"), dto.getTrxnRefNo()));
				}

				if (!BaseUtil.isObjNull(dto.getFullName())) {
					predicates.add(cb.like(from.get("fullName"), "%" + dto.getFullName() + "%"));
				}
			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}
}
