/**
 *
 */
package com.bestid.be.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author roziana
 * @since Feb 26, 2019
 */
@Entity
@Table(name = "BID_ICAO_CONFIG")
public class BidIcaoConfig implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 2085680842493850957L;

	@Id
	@Column(name = "CONFIG_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int configId;

	@Column(name = "CONFIG_CODE")
	private String configCd;

	@Column(name = "CONFIG_DESC")
	private String configDesc;

	@Column(name = "CONFIG_VAL")
	private String configVal;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public int getConfigId() {
		return configId;
	}


	public void setConfigId(int configId) {
		this.configId = configId;
	}


	public String getConfigCd() {
		return configCd;
	}


	public void setConfigCd(String configCd) {
		this.configCd = configCd;
	}


	public String getConfigDesc() {
		return configDesc;
	}


	public void setConfigDesc(String configDesc) {
		this.configDesc = configDesc;
	}


	public String getConfigVal() {
		return configVal;
	}


	public void setConfigVal(String configVal) {
		this.configVal = configVal;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}
