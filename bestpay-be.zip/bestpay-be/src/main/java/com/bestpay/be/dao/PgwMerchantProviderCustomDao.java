/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.bestpay.be.model.PgwMerchantProvider;
import com.bestpay.be.sdk.model.Provider;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.pagination.PaginationCriteria;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since March 28, 2019
 */
@Repository
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MER_PROVIDER_DAO)
public class PgwMerchantProviderCustomDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(PgwMerchantProviderCustomDao.class);

	private static final String WHERE_1_EQUALS_TO_1 = " where 1=1 ";

	@Autowired
	private PgwMerchantProviderRepository providerDao;

	//
	@PersistenceContext
	private EntityManager entityManager;


	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}


	public DataTableResults<PgwMerchantProvider> searchByPagination(Provider provider,
			DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append("from PgwMerchantProvider r ");
		sb.append(WHERE_1_EQUALS_TO_1);

		if (!BaseUtil.isObjNull(provider.getProviderName())) {
			sb.append(" and r.providerName like :providerName ");
		}

		if (!BaseUtil.isObjNull(provider.getSsmId())) {
			sb.append(" and r.ssmId like :ssmId ");
		}

		sb.append(" order by r.createDt desc ");

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause("r"));
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<PgwMerchantProvider> query = entityManager.createQuery(sb.toString(), PgwMerchantProvider.class);
		// Original Query
		TypedQuery<PgwMerchantProvider> query2 = entityManager.createQuery(sb.toString(), PgwMerchantProvider.class);

		if (!BaseUtil.isObjNull(provider.getProviderName())) {
			query.setParameter("providerName", "%" + provider.getProviderName() + "%");
			query2.setParameter("providerName", "%" + provider.getProviderName() + "%");
		}

		if (!BaseUtil.isObjNull(provider.getSsmId())) {
			query.setParameter("ssmId", "%" + provider.getSsmId() + "%");
			query2.setParameter("ssmId", "%" + provider.getSsmId() + "%");
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwMerchantProvider> dataTableResult = new DataTableResults<>();
		List<PgwMerchantProvider> svcResp = query.getResultList();
		List<PgwMerchantProvider> svcResp2 = query2.getResultList();
		LOGGER.debug("Filtered Size: {}", svcResp.size());
		LOGGER.debug("Original Size: {}", svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : providerDao.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		LOGGER.debug("isFilterByEmpty: {}", dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}
		return dataTableResult;
	}

}