/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeAcctPassport;
import com.be.model.BeAcctProfile;
import com.be.model.BeAcctTraveller;
import com.be.model.BeConfigPaymentBreakdown;
import com.be.model.BeTvlPayment;
import com.be.model.BeTvlPaymentDtl;
import com.be.model.BeTvlPaymentInfo;
import com.be.model.BeTvlProfile;
import com.be.model.RefPymntMsgCode;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Payment;
import com.be.service.BeAcctProfileService;
import com.be.service.RefPymntMsgCodeService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;
import com.util.pagination.SortBy;
import com.util.pagination.SortOrder;


/**
 * @author Ramesh Pongiannan
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_PAYMENT_QF)
public class BeTvlPaymentQf extends QueryFactory<BeTvlPayment> {

	@Autowired
	RefPymntMsgCodeService refPymntMsgCodeSvc;

	@Autowired
	BeAcctProfileService beAcctProfileSvc;

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BeTvlPayment> searchByProperty(BeTvlPayment t) {
		return (Root<BeTvlPayment> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}


	@Override
	public List<BeTvlPayment> searchAllByProperty(BeTvlPayment t) {
		CriteriaQuery<BeTvlPayment> cq = cb.createQuery(BeTvlPayment.class);
		Root<BeTvlPayment> from = cq.from(BeTvlPayment.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	@SuppressWarnings("static-access")
	public List<BeTvlPayment> searchPaymentPagination(Payment dto, DataTableRequest<?> dataTableInRQ) {

		List<BeTvlPayment> result = new ArrayList<>();
		CriteriaQuery<BeTvlPayment> cq = cb.createQuery(BeTvlPayment.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlPayment> root = cq.from(BeTvlPayment.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq, false);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					if (BaseUtil.isObjNull(pagination.getSortBy())) {
						SortBy sortBy = new SortBy();
						SortOrder sortOrder = null;

						sortBy.addSort("pmtDt", sortOrder.fromValue("DESC"));

						pagination.setSortBy(sortBy);
					}

					cq.orderBy(getOrderByClause(cb, root, pagination));
				}
			}

			TypedQuery<BeTvlPayment> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}


	public BeTvlPayment searchPayment(Payment dto) {

		BeTvlPayment result = null;
		CriteriaQuery<BeTvlPayment> cq = cb.createQuery(BeTvlPayment.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlPayment> root = cq.from(BeTvlPayment.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq, true);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeTvlPayment> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}


	public Long getCount(Payment dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeTvlPayment> root = cq.from(BeTvlPayment.class);
		predicates.addAll(generateCriteria(cb, root, dto));

		if (!BaseUtil.isObjNull(dto.getStatusCd())) {
			Join<BeTvlPayment, RefPymntMsgCode> statusPymntMsgCode = root.join("statusPymntMsgCode", JoinType.LEFT);
			RefPymntMsgCode msgCode = new RefPymntMsgCode();
			msgCode.setStatusCd(dto.getStatusCd());
			predicates.addAll(refPymntMsgCodeSvc.generateCriteria(cb, statusPymntMsgCode, msgCode));
		}

		if (dto.isEmbedDtls() && !BaseUtil.isObjNull(dto.getAcctProfile())) {
			Join<BeTvlPayment, BeTvlPaymentDtl> beTvlPaymentDtls = root.join("beTvlPaymentDtls", JoinType.LEFT);

			Join<BeTvlPaymentDtl, BeTvlProfile> tvlProfile = beTvlPaymentDtls.join("tvlProfile", JoinType.LEFT);

			Join<BeTvlProfile, BeAcctTraveller> acctTraveller = tvlProfile.join("acctTraveller", JoinType.LEFT);

			Join<BeAcctTraveller, BeAcctProfile> acctProfile = acctTraveller.join("acctProfile", JoinType.LEFT);
			predicates.addAll(beAcctProfileSvc.generateCriteria(cb, acctProfile, dto.getAcctProfile()));
		}

		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			Payment dto = JsonUtil.transferToObject(criteria, Payment.class);
			if (!BaseUtil.isObjNull(dto.getTvlPmtId())) {
				predicates.add(cb.equal(from.get("tvlPmtId"), dto.getTvlPmtId()));
			}
			if (!BaseUtil.isObjNull(dto.getPmtDt())) {
				predicates.add(cb.equal(from.get("pmtDt"), dto.getPmtDt()));
			}

			if (!BaseUtil.isObjNull(dto.getPmtRefNo())) {
				predicates.add(cb.equal(from.get("pmtRefNo"), dto.getPmtRefNo()));
			}

			if (!BaseUtil.isObjNull(dto.getPmtDtFrom())) {
				predicates.add(cb.greaterThanOrEqualTo(cb.function("date", Date.class, from.get("pmtDt")),
						dto.getPmtDtFrom()));
			}

			if (!BaseUtil.isObjNull(dto.getPmtDtTo())) {
				predicates.add(cb.lessThanOrEqualTo(cb.function("date", Date.class, from.get("pmtDt")),
						dto.getPmtDtTo()));
			}

		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void joinFetch(From<?, ?> from, List<Predicate> predicates, Payment dto, CriteriaQuery<?> cq,
			boolean allDtls) {

		from.fetch("pmtMthdMtdt", JoinType.LEFT);

		Join<BeTvlPayment, RefPymntMsgCode> statusPymntMsgCode = (Join) from.fetch("statusPymntMsgCode",
				JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getStatusCd())) {
			RefPymntMsgCode msgCode = new RefPymntMsgCode();
			msgCode.setStatusCd(dto.getStatusCd());
			predicates.addAll(refPymntMsgCodeSvc.generateCriteria(cb, statusPymntMsgCode, msgCode));
		}

		if (allDtls) {
			from.fetch("channel", JoinType.LEFT);
			from.fetch("respPymntMsgCode", JoinType.LEFT);
		}

		if (dto.isEmbedDtls()) {
			Join<BeTvlPayment, BeTvlPaymentDtl> beTvlPaymentDtls = (Join) from.fetch("beTvlPaymentDtls",
					JoinType.LEFT);

			Join<BeTvlPaymentDtl, BeTvlProfile> tvlProfile = (Join) beTvlPaymentDtls.fetch("tvlProfile",
					JoinType.LEFT);
			tvlProfile.fetch("country", JoinType.LEFT);

			Join<BeTvlProfile, BeAcctPassport> acctPassport = (Join) tvlProfile.fetch("acctPassport", JoinType.LEFT);
			acctPassport.fetch("nationality", JoinType.LEFT);

			Join<BeTvlProfile, BeAcctTraveller> acctTraveller = (Join) tvlProfile.fetch("acctTraveller",
					JoinType.LEFT);
			acctTraveller.fetch("relationMtdt", JoinType.LEFT);

			if (!BaseUtil.isObjNull(dto.getAcctProfile())) {
				Join<BeAcctTraveller, BeAcctProfile> acctProfile = (Join) acctTraveller.fetch("acctProfile",
						JoinType.LEFT);
				predicates.addAll(beAcctProfileSvc.generateCriteria(cb, acctProfile, dto.getAcctProfile()));
			}

			if (dto.isEmbedInfo()) {
				Join<BeTvlPaymentDtl, BeTvlPaymentInfo> tvlPaymentInfos = (Join) beTvlPaymentDtls
						.fetch("tvlPaymentInfos", JoinType.LEFT);
				Join<BeTvlPaymentInfo, BeConfigPaymentBreakdown> pmtBreakdown = (Join) tvlPaymentInfos
						.fetch("pmtBreakdown", JoinType.LEFT);
				pmtBreakdown.fetch("country", JoinType.LEFT);
			}
		}
	}

}
