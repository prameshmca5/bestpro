/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.web.util.constants;


import com.bstsb.util.BaseUtil;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class PageConstants {

	private PageConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String PAGE_SRC = "/";

	public static final String PAGE_MAIN = "/main";

	public static final String PAGE_LOGIN = "/login";

	public static final String PAGE_LOGIN_SUC = "/login-success";

	public static final String PAGE_LOGIN_ERR = "/login-error";

	public static final String PAGE_LOGOUT = "/logout-process";

	public static final String PAGE_ERROR = "/error";

	public static final String PAGE_ERROR_403 = "/403";

	public static final String PAGE_HOME = "/home";

	public static final String PAGE_DASHBOARD = "/dashboard";

	public static final String PAGE_WELCOME = "/welcome";

	// User Management
	public static final String PAGE_IDM_PROFILE = "/profile";

	public static final String PAGE_IDM_USR_LST = "/user-list";

	public static final String PAGE_IDM_USR_UPD_LOGIN = "/user-list/id";

	public static final String PAGE_IDM_FRGT_PWORD = "/password/reset";

	public static final String PAGE_IDM_USR_CHNG_PWORD = "/user/password/change";

	public static final String PAGE_UPDATE_PROFILE = "/updateProfile";

	public static final String PAGE_COMPONENTS = "/components/{item}";

	public static final String PAGE_CMN_OTP = "/otp";

	public static final String PAGE_CMN_CAPTCHA = "/captcha";

	public static final String SERVICE_CHECK = "/serviceCheck";

	public static final String PAGE_CMN_STATIC = "/static-list";

	public static final String DOCUMENTS = "/documents";

	// Subscriber
	public static final String SUBSCRIBER = "/subscriber";

	public static final String SUBSCRIBER_LIST = SUBSCRIBER + "/listSubscriber";


	public static String getRedirectUrl(String url) {
		return getRedirectUrl(url, null);
	}


	public static String getRedirectUrl(String url, String pathVar) {
		String newURL = "redirect:" + url;
		if (!BaseUtil.isObjNull(pathVar)) {
			newURL = newURL + "/" + pathVar;
		}
		return newURL;
	}


	// Maintenance
	public static final String PAGE_MAINTENANCE = "/maintenance";

	public static final String PAGE_BID_CONFIG = "/bidConfig";

	public static final String PAGE_BID_CONFIG_EDIT = "/bidConfig/create";

	public static final String PAGE_BID_CONFIG_REG = "/bidConfig/register";

}
