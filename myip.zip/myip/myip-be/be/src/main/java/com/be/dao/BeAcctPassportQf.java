/**
 * 
 */
package com.be.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeAcctPassport;
import com.be.model.BeAcctTraveller;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;
import com.util.JsonUtil;

/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_ACCT_PASSPORT_QF)
public class BeAcctPassportQf extends QueryFactory<BeAcctPassport> {

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;

	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}
	
	@Override
	public Specification<BeAcctPassport> searchByProperty(BeAcctPassport t) {
		return (Root<BeAcctPassport> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}

	@Override
	public List<BeAcctPassport> searchAllByProperty(BeAcctPassport t) {
		CriteriaQuery<BeAcctPassport> cq = cb.createQuery(BeAcctPassport.class);
		Root<BeAcctPassport> from = cq.from(BeAcctPassport.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			if(!BaseUtil.isObjNull(criteria)) {
				BeAcctPassport dto = JsonUtil.transferToObject(criteria, BeAcctPassport.class);
				if (!BaseUtil.isObjNull(dto.getPassportNo())) {
					predicates.add(cb.like(from.get("passportNo"), "%" + dto.getPassportNo() + "%"));
				}
			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

	public BeAcctPassport searchBeAcctPassport(BeAcctPassport dto) {

		BeAcctPassport result = null;
		CriteriaQuery<BeAcctPassport> cq = cb.createQuery(BeAcctPassport.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeAcctPassport> root = cq.from(BeAcctPassport.class);
			predicates.addAll(generateCriteria(cb, root, dto));

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeAcctPassport> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}
}
