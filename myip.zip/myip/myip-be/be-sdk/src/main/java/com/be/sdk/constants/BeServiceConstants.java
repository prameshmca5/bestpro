/**
 * Copyright 2019
 */
package com.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since March 01, 2018
 */
public class BeServiceConstants {

	private BeServiceConstants() {
		throw new IllegalStateException(BeServiceConstants.class.getName());
	}


	public static final String MC_PREFIX = "MC";

	public static final String STATUS_CD_INS_UPD = "INS";

	public static final String STATUS_CD_INS_PNDG = "INS_PNDG";

	public static final String BE_CONFIG_MRZ_SVC = "MRZ_SVC";

	public static final String MRZ_SVC_ACCURA = "ACCURA";

	public static final String MRZ_SVC_REGULA = "REGULA";

	public static final String REGULA_TYPE = "REGULA_TYPE";

	public static final String RESP_CODE_PROCESSING = "02";

	public static final String URL_REGULA_SUB = "URL_REGULA_SUB";

	public static final String URL_REGULA_GET = "URL_REGULA_GET";

	public static final String URL_ACCURA = "URL_ACCURA";

	public static final String URL_DIGI_SIGN = "URL_DIGI_SIGN";
}