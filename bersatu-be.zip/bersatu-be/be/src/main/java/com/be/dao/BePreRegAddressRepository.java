/**
 * Copyright 2019. Bestinet Sdn Bhd
 */
package com.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.BePreRegAddress;


/**
 * @author mohd.naem
 *
 * @since 31 March 2021
 */

@Repository
@RepositoryDefinition(domainClass = BePreRegAddress.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_PRE_REG_ADDRESS_DAO)
public interface BePreRegAddressRepository extends GenericRepository<BePreRegAddress> {

}
