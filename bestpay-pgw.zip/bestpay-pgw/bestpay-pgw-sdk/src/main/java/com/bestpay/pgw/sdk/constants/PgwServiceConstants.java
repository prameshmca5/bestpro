/**
 * Copyright 2014. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.constants;

/**
 * @author Mary Jane Buenaventura
 * @since March 01, 2018
 */
public interface PgwServiceConstants {

}