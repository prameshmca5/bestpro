package com.bestpay.be.sdk.model;

import java.io.Serializable;

public class MerchantDetails implements Serializable {
	
	private String tab;
	
	public String getTab() {
		return tab;
	}

	public void setTab(String tab) {
		this.tab = tab;
	}

}
