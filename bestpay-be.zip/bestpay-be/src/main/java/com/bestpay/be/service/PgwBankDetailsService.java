/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwBankDetailsRepository;
import com.bestpay.be.model.PgwBankDetails;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since June 25, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_ACC_SET_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_ACC_SET_SVC)
public class PgwBankDetailsService extends AbstractService<PgwBankDetails> {

	@Autowired
	private PgwBankDetailsRepository bankDetailsDao;


	@Override
	public PgwBankDetailsRepository primaryDao() {
		return bankDetailsDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwBankDetails findBankDetailsByMerchantId(String merchantId) {
		return bankDetailsDao.findBankDetailsByMerchantId(merchantId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwBankDetails> findBankDetailsByIcTypeAndIcNum(String icType, String icNum) {
		return bankDetailsDao.findBankDetailsByIcTypeAndIcNum(icType, icNum);
	}
}