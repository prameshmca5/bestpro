/**
 * 
 */
package com.be.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;

/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "REF_PYMNT_MSG_CODE")
public class RefPymntMsgCode extends AbstractEntity implements Serializable, IQfCriteria<RefPymntMsgCode> {
	
	private static final long serialVersionUID = -4805020426914172159L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PYMNT_MSG_CODE_ID")
	private Integer pymntMsgCodeId;

	@Column(name = "RESP_CD")
	private String respCd;

	@Column(name = "RESP_DESCRIPTION")
	private String respDescription;
	
	@Column(name = "STATUS_CD")
	private Integer statusCd;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="CHANNEL_CODE")
	private RefChannel channel;
	
	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	public Integer getPymntMsgCodeId() {
		return pymntMsgCodeId;
	}

	public void setPymntMsgCodeId(Integer pymntMsgCodeId) {
		this.pymntMsgCodeId = pymntMsgCodeId;
	}

	public String getRespCd() {
		return respCd;
	}

	public void setRespCd(String respCd) {
		this.respCd = respCd;
	}

	public String getRespDescription() {
		return respDescription;
	}

	public void setRespDescription(String respDescription) {
		this.respDescription = respDescription;
	}

	public Integer getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(Integer statusCd) {
		this.statusCd = statusCd;
	}

	public RefChannel getChannel() {
		return channel;
	}

	public void setChannel(RefChannel channel) {
		this.channel = channel;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	
}
