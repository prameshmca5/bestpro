/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author nurul.naimma
 *
 * @since Apr 9, 2021
 */

@JsonInclude(Include.NON_NULL)
public class KiplePaymentRequest implements Serializable {

	private static final long serialVersionUID = 4004249552047349455L;

	private String ord_date;

	private double ord_totalamt;

	private double ord_gstamt;

	private String ord_shipname;

	private String ord_shipcountry;

	private String ord_mercref;

	private String ord_telephone;

	private String ord_email;

	private String ord_delcharges;

	private String ord_svccharges;

	private String ord_customfield1;

	private String ord_customfield2;

	private String ord_customfield3;

	private String ord_customfield4;

	private String ord_mercID;

	private String wcID;

	private String ord_key;

	private String returncode;

	private String version;

	private String merchant_hashvalue;

	private String payment_code;

	private String ord_returnURL;

	private String kipleUrl;
	
	// SenangPay Request URL
	private String senangUrl;
	
	private String senangDesc;
	
	private String pmtType;
	


	/**
	 * @return the ord_date
	 */
	public String getOrd_date() {
		return ord_date;
	}


	/**
	 * @param ord_date
	 *             the ord_date to set
	 */
	public void setOrd_date(String ord_date) {
		this.ord_date = ord_date;
	}


	/**
	 * @return the ord_totalamt
	 */
	public double getOrd_totalamt() {
		return ord_totalamt;
	}


	/**
	 * @param ord_totalamt
	 *             the ord_totalamt to set
	 */
	public void setOrd_totalamt(double ord_totalamt) {
		this.ord_totalamt = ord_totalamt;
	}


	/**
	 * @return the ord_gstamt
	 */
	public double getOrd_gstamt() {
		return ord_gstamt;
	}


	/**
	 * @param ord_gstamt
	 *             the ord_gstamt to set
	 */
	public void setOrd_gstamt(double ord_gstamt) {
		this.ord_gstamt = ord_gstamt;
	}


	/**
	 * @return the ord_shipname
	 */
	public String getOrd_shipname() {
		return ord_shipname;
	}


	/**
	 * @param ord_shipname
	 *             the ord_shipname to set
	 */
	public void setOrd_shipname(String ord_shipname) {
		this.ord_shipname = ord_shipname;
	}


	/**
	 * @return the ord_shipcountry
	 */
	public String getOrd_shipcountry() {
		return ord_shipcountry;
	}


	/**
	 * @param ord_shipcountry
	 *             the ord_shipcountry to set
	 */
	public void setOrd_shipcountry(String ord_shipcountry) {
		this.ord_shipcountry = ord_shipcountry;
	}


	/**
	 * @return the ord_mercref
	 */
	public String getOrd_mercref() {
		return ord_mercref;
	}


	/**
	 * @param ord_mercref
	 *             the ord_mercref to set
	 */
	public void setOrd_mercref(String ord_mercref) {
		this.ord_mercref = ord_mercref;
	}


	/**
	 * @return the ord_telephone
	 */
	public String getOrd_telephone() {
		return ord_telephone;
	}


	/**
	 * @param ord_telephone
	 *             the ord_telephone to set
	 */
	public void setOrd_telephone(String ord_telephone) {
		this.ord_telephone = ord_telephone;
	}


	/**
	 * @return the ord_email
	 */
	public String getOrd_email() {
		return ord_email;
	}


	/**
	 * @param ord_email
	 *             the ord_email to set
	 */
	public void setOrd_email(String ord_email) {
		this.ord_email = ord_email;
	}


	/**
	 * @return the ord_delcharges
	 */
	public String getOrd_delcharges() {
		return ord_delcharges;
	}


	/**
	 * @param ord_delcharges
	 *             the ord_delcharges to set
	 */
	public void setOrd_delcharges(String ord_delcharges) {
		this.ord_delcharges = ord_delcharges;
	}


	/**
	 * @return the ord_svccharges
	 */
	public String getOrd_svccharges() {
		return ord_svccharges;
	}


	/**
	 * @param ord_svccharges
	 *             the ord_svccharges to set
	 */
	public void setOrd_svccharges(String ord_svccharges) {
		this.ord_svccharges = ord_svccharges;
	}


	/**
	 * @return the ord_customfield1
	 */
	public String getOrd_customfield1() {
		return ord_customfield1;
	}


	/**
	 * @param ord_customfield1
	 *             the ord_customfield1 to set
	 */
	public void setOrd_customfield1(String ord_customfield1) {
		this.ord_customfield1 = ord_customfield1;
	}


	/**
	 * @return the ord_customfield2
	 */
	public String getOrd_customfield2() {
		return ord_customfield2;
	}


	/**
	 * @param ord_customfield2
	 *             the ord_customfield2 to set
	 */
	public void setOrd_customfield2(String ord_customfield2) {
		this.ord_customfield2 = ord_customfield2;
	}


	/**
	 * @return the ord_customfield3
	 */
	public String getOrd_customfield3() {
		return ord_customfield3;
	}


	/**
	 * @param ord_customfield3
	 *             the ord_customfield3 to set
	 */
	public void setOrd_customfield3(String ord_customfield3) {
		this.ord_customfield3 = ord_customfield3;
	}


	/**
	 * @return the ord_customfield4
	 */
	public String getOrd_customfield4() {
		return ord_customfield4;
	}


	/**
	 * @param ord_customfield4
	 *             the ord_customfield4 to set
	 */
	public void setOrd_customfield4(String ord_customfield4) {
		this.ord_customfield4 = ord_customfield4;
	}


	/**
	 * @return the ord_mercID
	 */
	public String getOrd_mercID() {
		return ord_mercID;
	}


	/**
	 * @param ord_mercID
	 *             the ord_mercID to set
	 */
	public void setOrd_mercID(String ord_mercID) {
		this.ord_mercID = ord_mercID;
	}


	/**
	 * @return the wcID
	 */
	public String getWcID() {
		return wcID;
	}


	/**
	 * @param wcID
	 *             the wcID to set
	 */
	public void setWcID(String wcID) {
		this.wcID = wcID;
	}


	/**
	 * @return the ord_key
	 */
	public String getOrd_key() {
		return ord_key;
	}


	/**
	 * @param ord_key
	 *             the ord_key to set
	 */
	public void setOrd_key(String ord_key) {
		this.ord_key = ord_key;
	}


	/**
	 * @return the returncode
	 */
	public String getReturncode() {
		return returncode;
	}


	/**
	 * @param returncode
	 *             the returncode to set
	 */
	public void setReturncode(String returncode) {
		this.returncode = returncode;
	}


	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}


	/**
	 * @param version
	 *             the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}


	/**
	 * @return the merchant_hashvalue
	 */
	public String getMerchant_hashvalue() {
		return merchant_hashvalue;
	}


	/**
	 * @param merchant_hashvalue
	 *             the merchant_hashvalue to set
	 */
	public void setMerchant_hashvalue(String merchant_hashvalue) {
		this.merchant_hashvalue = merchant_hashvalue;
	}


	/**
	 * @return the payment_code
	 */
	public String getPayment_code() {
		return payment_code;
	}


	/**
	 * @param payment_code
	 *             the payment_code to set
	 */
	public void setPayment_code(String payment_code) {
		this.payment_code = payment_code;
	}


	/**
	 * @return the ord_returnURL
	 */
	public String getOrd_returnURL() {
		return ord_returnURL;
	}


	/**
	 * @param ord_returnURL
	 *             the ord_returnURL to set
	 */
	public void setOrd_returnURL(String ord_returnURL) {
		this.ord_returnURL = ord_returnURL;
	}


	/**
	 * @return the kipleUrl
	 */
	public String getKipleUrl() {
		return kipleUrl;
	}


	/**
	 * @param kipleUrl
	 *             the kipleUrl to set
	 */
	public void setKipleUrl(String kipleUrl) {
		this.kipleUrl = kipleUrl;
	}


	public String getSenangUrl() {
		return senangUrl;
	}


	public void setSenangUrl(String senangUrl) {
		this.senangUrl = senangUrl;
	}


	public String getSenangDesc() {
		return senangDesc;
	}


	public void setSenangDesc(String senangDesc) {
		this.senangDesc = senangDesc;
	}


	public String getPmtType() {
		return pmtType;
	}


	public void setPmtType(String pmtType) {
		this.pmtType = pmtType;
	}
	
	
	
}
