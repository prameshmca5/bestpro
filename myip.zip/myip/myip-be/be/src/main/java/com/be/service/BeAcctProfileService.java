/**
 *
 */
package com.be.service;


import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeAcctProfileQf;
import com.be.dao.BeAcctProfileRepository;
import com.be.model.BeAcctPassport;
import com.be.model.BeAcctProfile;
import com.be.sdk.model.AcctProfile;
import com.be.sdk.model.IQfCriteria;
import com.idm.sdk.model.CustomNotification;
import com.idm.sdk.model.UserProfile;
import com.idm.sdk.model.UserType;
import com.util.BaseUtil;
import com.util.JsonUtil;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_ACCT_PROFILE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_ACCT_PROFILE_SVC)
public class BeAcctProfileService extends AbstractService<BeAcctProfile> {

	@Autowired
	private BeAcctProfileRepository beAcctProfileDao;

	@Autowired
	BeAcctPassportService beAcctPassportSvc;

	@Autowired
	BeAcctProfileQf beAcctProfileQf;


	@Override
	public GenericRepository<BeAcctProfile> primaryDao() {
		return beAcctProfileDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beAcctProfileQf.generateCriteria(cb, from, criteria);
	}


	public BeAcctProfile findByEmail(String email) {
		return beAcctProfileDao.findByEmail(email);
	}


	public BeAcctProfile searchBeAcctProfile(AcctProfile dto) {
		return beAcctProfileQf.searchBeAcctProfile(dto);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class })
	public BeAcctProfile createUpdate(AcctProfile dto, BeAcctProfile beAcctProfileOri, HttpServletRequest request)
			throws IOException {

		String userId = getCurrUserId(request);
		if (BaseUtil.isObjNull(userId) || BaseUtil.isEqualsCaseIgnore(userId, "null")) {
			userId = "system";
		}
		BeAcctProfile beAcctProfile = JsonUtil.transferToObject(dto, BeAcctProfile.class);

		if (BaseUtil.isObjNull(beAcctProfileOri)) {
			beAcctProfile.setCreateId(userId);
		} else {
			beAcctProfile.setAcctProfId(beAcctProfileOri.getAcctProfId());
			beAcctProfile.setCreateId(beAcctProfileOri.getCreateId());
			beAcctProfile.setCreateDt(beAcctProfileOri.getCreateDt());
		}

		if (!BaseUtil.isObjNull(dto.getAcctPassport()) && !BaseUtil.isObjNull(dto.getAcctPassport())) {
			BeAcctPassport passport = beAcctPassportSvc.createUpdate(beAcctProfile.getAcctPassport(), userId);
			beAcctProfile.setAcctPassport(passport);
		}

		beAcctProfile.setUpdateId(userId);
		beAcctProfile = update(beAcctProfile);

		if (BaseUtil.isObjNull(beAcctProfileOri)) {
			UserProfile userProfile = new UserProfile();
			UserType userType = new UserType();
			if (!BaseUtil.isObjNull(dto.getAcctPassport())) {
				userProfile.setNationalId(dto.getAcctPassport().getPassportNo());
			}
			userProfile.setFirstName(dto.getFullName());
			userProfile.setDob(dto.getDob());
			userProfile.setGender(dto.getGender());
			userProfile.setEmail(dto.getEmail());
			userProfile.setContactNo(dto.getContactNo());
			userType.setUserTypeCode("TVL");
			userProfile.setUserType(userType);
			userProfile.setUserRoleGroupCode("TRAVELLER");
			userProfile.setCntryCd(dto.getCountry().getCntryCd());
			userProfile.setProfId(beAcctProfile.getAcctProfId());
			userProfile.setUserId(dto.getEmail());
			userProfile.setSystemType("myip");
			
			CustomNotification cn = new CustomNotification();
			cn.setTemplateCode("IDM_ACTIVATE_SUCCESS_TVL");
			cn.setTemplateParams(new HashMap<String, Object>());
			userProfile.setCustomNotification(cn);
			
			getIdmService(request).createUser(userProfile, true);
		}

		return beAcctProfile;
	}

}
