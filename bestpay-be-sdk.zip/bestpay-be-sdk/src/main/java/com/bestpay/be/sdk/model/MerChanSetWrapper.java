/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.util.List;


/**
 * @author Afif saman
 * @since Jul 11, 2018
 */
public class MerChanSetWrapper implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1551931728403608316L;

	/**
	 *
	 */
	private List<MerChanSet> merChanSets;

	private String merchantId;

	private String userId;

	private Boolean channelCheck;
	
	private List<ReferralMultiChannel> referralMultiChannel;

	private String compRefId;
	
	private Integer pdpa;


	public Boolean getChannelCheck() {
		return channelCheck;
	}


	public void setChannelCheck(Boolean channelCheck) {
		this.channelCheck = channelCheck;
	}


	public List<MerChanSet> getMerChanSets() {
		return merChanSets;
	}


	public void setMerChanSets(List<MerChanSet> merChanSets) {
		this.merChanSets = merChanSets;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public List<ReferralMultiChannel> getReferralMultiChannel() {
		return referralMultiChannel;
	}


	public void setReferralMultiChannel(List<ReferralMultiChannel> referralMultiChannel) {
		this.referralMultiChannel = referralMultiChannel;
	}


	public String getCompRefId() {
		return compRefId;
	}


	public void setCompRefId(String compRefId) {
		this.compRefId = compRefId;
	}


	public Integer getPdpa() {
		return pdpa;
	}


	public void setPdpa(Integer pdpa) {
		this.pdpa = pdpa;
	}
}