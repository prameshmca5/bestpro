/**
 * 
 */
package com.be.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeAcctProfile;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.AcctProfile;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;
import com.util.JsonUtil;

/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_ACCT_PROFILE_QF)
public class BeAcctProfileQf extends QueryFactory<BeAcctProfile> {

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;

	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}
	
	@Override
	public Specification<BeAcctProfile> searchByProperty(BeAcctProfile t) {
		return (Root<BeAcctProfile> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}

	@Override
	public List<BeAcctProfile> searchAllByProperty(BeAcctProfile t) {
		CriteriaQuery<BeAcctProfile> cq = cb.createQuery(BeAcctProfile.class);
		Root<BeAcctProfile> from = cq.from(BeAcctProfile.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}

	public BeAcctProfile searchBeAcctProfile(AcctProfile dto) {

		BeAcctProfile result = null;
		CriteriaQuery<BeAcctProfile> cq = cb.createQuery(BeAcctProfile.class);
		List<Predicate> predicates = new ArrayList<>();
		dto.setView(true);
		if (cq != null) {
			Root<BeAcctProfile> root = cq.from(BeAcctProfile.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeAcctProfile> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}catch (Exception e) {
				return null;
			}
		}
		return result;
	}
	
	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			AcctProfile dto = JsonUtil.transferToObject(criteria, AcctProfile.class);
			if (!BaseUtil.isObjNull(dto.getAcctProfId())) {
				predicates.add(cb.equal(from.get("acctProfId"), dto.getAcctProfId()));
			}

			if (!BaseUtil.isObjNull(dto.getFullName())) {
				predicates.add(cb.like(from.get("fullName"), "%" + dto.getFullName() + "%"));
			}
			
			if (!BaseUtil.isObjNull(dto.getEmail())) {
				predicates.add(cb.equal(from.get("email"), dto.getEmail()));
			}
			
			if(!BaseUtil.isObjNull(dto.getAcctPassport())) {
				predicates.add(cb.equal(from.get("acctPassport"), dto.getAcctPassport().getPassportId()));
			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

	private void joinFetch(From<?, ?> from, List<Predicate> predicates, AcctProfile dto, CriteriaQuery<BeAcctProfile> cq) {
		
		from.fetch("nationality", JoinType.LEFT);
		from.fetch("acctPassport", JoinType.LEFT);
		from.fetch("country", JoinType.LEFT);
		
		if(dto.isView()) {
			from.fetch("birthPlace", JoinType.LEFT);
			from.fetch("residentPlace", JoinType.LEFT);
			from.fetch("ecRelationMtdt", JoinType.LEFT);
		}
	}
}
