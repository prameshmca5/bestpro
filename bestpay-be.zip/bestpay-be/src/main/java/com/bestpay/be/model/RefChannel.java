package com.bestpay.be.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;

/**
 * @author Afif Saman
 * @since Jul 10, 2018
 */

@Entity
@Table(name = "REF_CHANNEL")
public class RefChannel extends AbstractEntity implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CHANNEL_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer channelId;

	@Column(name = "PUBLIC_NAME")
	private String publicName;

	@Column(name = "PRIVATE_NAME")
	private String privateName;

	@Column(name = "TYPE")
	private String type;

	@Column(name = "LOGO")
	private String logo;

	@Column(name = "MIN_CUR")
	private String minCur;

	@Column(name = "MIN_AMT")
	private Float minAmt;

	@Column(name = "MAX_CUR")
	private String maxCur;

	@Column(name = "MAX_AMT")
	private Float maxAmt;

	@Column(name = "CURRENCY")
	private String currency;

	@Column(name = "NAME")
	private String name;
	
	@Column(name = "EXPIRY_TIME")
	private Integer expiryTime;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Integer getChannelId() {
		return channelId;
	}

	public String getPublicName() {
		return publicName;
	}

	public void setPublicName(String publicName) {
		this.publicName = publicName;
	}

	public String getPrivateName() {
		return privateName;
	}

	public void setPrivateName(String privateName) {
		this.privateName = privateName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getMinCur() {
		return minCur;
	}

	public void setMinCur(String minCur) {
		this.minCur = minCur;
	}

	public Float getMinAmt() {
		return minAmt;
	}

	public void setMinAmt(Float minAmt) {
		this.minAmt = minAmt;
	}

	public String getMaxCur() {
		return maxCur;
	}

	public void setMaxCur(String maxCur) {
		this.maxCur = maxCur;
	}

	public Float getMaxAmt() {
		return maxAmt;
	}

	public void setMaxAmt(Float maxAmt) {
		this.maxAmt = maxAmt;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setChannelId(Integer channelId) {
		this.channelId = channelId;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}
	
	public Integer getExpiryTime() {
		return expiryTime;
	}

	public void setExpiryTime(Integer expiryTime) {
		this.expiryTime = expiryTime;
	}


}
