package com.bestpay.be.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.model.PgwSettlement;
import com.bestpay.be.sdk.model.SettlementInfo;
import com.bestpay.be.sdk.model.SettlementRptInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.pagination.PaginationCriteria;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.DateUtil;


@Repository
@Scope("prototype")
@Qualifier("settlementCustomDao")
public class SettlementCustomDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(SettlementCustomDao.class);

	private static final String MERCHANTID_MERCHANTID = " and pgwstmt.merchantId = :merchantId ";

	private static final String FROM_PGWSETTLEMENT = " from PgwSettlement pgwstmt ";

	private static final String WHERE_1_EQUALS_TO_1 = " where 1=1 ";

	private static final String MERCHANTID = "merchantId";

	private static final String SELECT_PGWSETTLEMENT = "select pgwstmt ";

	private static final String STATUS = "status";

	private static final String SETTLE_DATE = "settleDate";

	private static final String SETTLE_DATE_FROM = "sttleDateFrom";

	private static final String SETTLE_DATE_TO = "sttleDateTo";

	@PersistenceContext
	private EntityManager entityManager;


	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}


	@Autowired
	private PgwSettlementRepository pgwSettlementRepository;


	public DataTableResults<PgwSettlement> searchSettlementList(SettlementInfo settlementListInfo,
			DataTableRequest dataTableInRQ) {
		LOGGER.info("Search date {}", settlementListInfo.getSettleDate());
		StringBuilder sb = new StringBuilder(SELECT_PGWSETTLEMENT);
		sb.append(FROM_PGWSETTLEMENT);
		sb.append(WHERE_1_EQUALS_TO_1);

		if (!BaseUtil.isObjNull(settlementListInfo.getSettleDate())) {
			sb.append(" and pgwstmt.settleDate = :settleDate ");
		}

		if (!BaseUtil.isObjNull(settlementListInfo.getStatus())) {
			sb.append(" and pgwstmt.status = :status ");
		}

		if (!BaseUtil.isObjNull(settlementListInfo.getMerchantId())) {
			sb.append(MERCHANTID_MERCHANTID);
		}

		sb.append(" order by pgwstmt.createDt desc ");

		if (LOGGER.isDebugEnabled()) {
			LOGGER.info(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<PgwSettlement> query = entityManager.createQuery(sb.toString(), PgwSettlement.class);
		// Original Query
		TypedQuery<PgwSettlement> query2 = entityManager.createQuery(sb.toString(), PgwSettlement.class);

		if (!BaseUtil.isObjNull(settlementListInfo.getStatus())) {
			query.setParameter(STATUS, settlementListInfo.getStatus());
			query2.setParameter(STATUS, settlementListInfo.getStatus());
		}

		if (!BaseUtil.isObjNull(settlementListInfo.getSettleDate())) {
			query.setParameter(SETTLE_DATE, settlementListInfo.getSettleDate(), TemporalType.DATE);
			query2.setParameter(SETTLE_DATE, settlementListInfo.getSettleDate(), TemporalType.DATE);
		}

		if (!BaseUtil.isObjNull(settlementListInfo.getMerchantId())) {
			query.setParameter(MERCHANTID, settlementListInfo.getMerchantId());
			query2.setParameter(MERCHANTID, settlementListInfo.getMerchantId());
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.info(query.toString());
			LOGGER.info(query2.toString());
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {

			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();

			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwSettlement> dataTableResult = new DataTableResults<>();
		List<PgwSettlement> svcResp = query.getResultList();
		List<PgwSettlement> svcResp2 = query2.getResultList();

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : pgwSettlementRepository.totalRecords();

		dataTableResult.setDraw(dataTableInRQ.getDraw());

		dataTableResult.setData(svcResp);
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));

		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}

		return dataTableResult;

	}


	public PgwSettlement findRecentSettlementByMerchId(String merchantId) {
		StringBuilder sb = new StringBuilder(SELECT_PGWSETTLEMENT);
		sb.append(FROM_PGWSETTLEMENT);
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(MERCHANTID_MERCHANTID);
		sb.append(" and pgwstmt.status = :status ORDER BY pgwstmt.settleDate DESC");

		TypedQuery<PgwSettlement> query = entityManager.createQuery(sb.toString(), PgwSettlement.class);
		query.setParameter(MERCHANTID, merchantId);
		query.setParameter(STATUS, "settled");
		query.setMaxResults(1);

		List<PgwSettlement> svcResp = query.getResultList();
		PgwSettlement pgwSettlement = null;
		if (!svcResp.isEmpty()) {
			pgwSettlement = svcResp.get(0);
		}
		return pgwSettlement;
	}


	public PgwSettlement findNextSettlementByMerchId(String merchantId) {
		StringBuilder sb = new StringBuilder(SELECT_PGWSETTLEMENT);
		sb.append(FROM_PGWSETTLEMENT);
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(MERCHANTID_MERCHANTID);
		sb.append(" and pgwstmt.status = :status ORDER BY pgwstmt.settleDate ASC");

		TypedQuery<PgwSettlement> query = entityManager.createQuery(sb.toString(), PgwSettlement.class);
		query.setParameter(MERCHANTID, merchantId);
		query.setParameter(STATUS, "not settled");
		query.setMaxResults(1);

		List<PgwSettlement> svcResp = query.getResultList();
		PgwSettlement pgwSettlement = null;
		if (!svcResp.isEmpty()) {
			pgwSettlement = svcResp.get(0);
		}
		return pgwSettlement;
	}


	public List<PgwSettlement> loadSettleRptInfo(SettlementRptInfo settlementRptInfo,
			PgwMerchantProfile pgwMerchantProfile) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append(" from PgwSettlement r ");
		sb.append(WHERE_1_EQUALS_TO_1);

		if (!BaseUtil.isObjNull(pgwMerchantProfile.getMerchantId())) {
			sb.append(" and r.merchantId = :merchantId ");
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())) {
			sb.append(" and r.settleDate>=:sttleDateFrom ");
		}
		if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			sb.append(" and r.settleDate<=:sttleDateTo ");
		}
		if (!BaseUtil.isObjNull(settlementRptInfo.getAmount())) {
			sb.append(" and r.amount like :amount ");
		}
		if (!BaseUtil.isObjNull(settlementRptInfo.getActualAmount())) {
			sb.append(" and r.actualAmount like :actualAmount ");
		}

		LOGGER.info("settlement report export = {}", sb);

		TypedQuery<PgwSettlement> query = entityManager.createQuery(sb.toString(), PgwSettlement.class);

		if (!BaseUtil.isObjNull(pgwMerchantProfile.getMerchantId())) {
			query.setParameter(MERCHANTID, pgwMerchantProfile.getMerchantId());
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			query.setParameter(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom(), TemporalType.DATE);
		} else if (BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& !BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			query.setParameter(SETTLE_DATE_TO, DateUtil.addDayToTimestamp(settlementRptInfo.getSttleDateTo(), 1),
					TemporalType.DATE);
		} else if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& !BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			query.setParameter(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom(), TemporalType.DATE);
			query.setParameter(SETTLE_DATE_TO, settlementRptInfo.getSttleDateTo(), TemporalType.DATE);
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getAmount())) {
			query.setParameter("amount", settlementRptInfo.getAmount());
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getActualAmount())) {
			query.setParameter("actualAmount", settlementRptInfo.getActualAmount());
		}

		return query.getResultList();
	}


	public DataTableResults<PgwSettlement> searchRemittenceSettlementList(SettlementInfo settlementListInfo,
			DataTableRequest dataTableInRQ) {
		LOGGER.info("Search date {}", settlementListInfo.getSettleDate());
		StringBuilder sb = new StringBuilder(SELECT_PGWSETTLEMENT);
		sb.append(FROM_PGWSETTLEMENT);
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(" and pgwstmt.channel is not null");

		if (!BaseUtil.isObjNull(settlementListInfo.getSettleDate())) {
			sb.append(" and pgwstmt.settleDate = :settleDate ");
		}

		if (!BaseUtil.isObjNull(settlementListInfo.getStatus())) {
			sb.append(" and pgwstmt.status = :status ");
		}
		sb.append(" order by pgwstmt.createDt desc ");

		if (LOGGER.isDebugEnabled()) {
			LOGGER.info(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<PgwSettlement> query = entityManager.createQuery(sb.toString(), PgwSettlement.class);
		// Original Query
		TypedQuery<PgwSettlement> query2 = entityManager.createQuery(sb.toString(), PgwSettlement.class);

		if (!BaseUtil.isObjNull(settlementListInfo.getStatus())) {
			query.setParameter(STATUS, settlementListInfo.getStatus());
			query2.setParameter(STATUS, settlementListInfo.getStatus());
		}

		if (!BaseUtil.isObjNull(settlementListInfo.getSettleDate())) {
			query.setParameter(SETTLE_DATE, settlementListInfo.getSettleDate(), TemporalType.DATE);
			query2.setParameter(SETTLE_DATE, settlementListInfo.getSettleDate(), TemporalType.DATE);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.info(query.toString());
			LOGGER.info(query2.toString());
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {

			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();

			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwSettlement> dataTableResult = new DataTableResults<>();
		List<PgwSettlement> svcResp = query.getResultList();
		List<PgwSettlement> svcResp2 = query2.getResultList();

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : pgwSettlementRepository.totalRecords();

		dataTableResult.setDraw(dataTableInRQ.getDraw());

		dataTableResult.setData(svcResp);
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));

		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}

		return dataTableResult;

	}


	public List<PgwSettlement> loadRemitSettleRptInfo(SettlementRptInfo settlementRptInfo) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append(" from PgwSettlement r ");
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(" and r.channel != '' ");

		if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())) {
			sb.append(" and r.settleDate>=:sttleDateFrom ");
		}
		if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			sb.append(" and r.settleDate<=:sttleDateTo ");
		}

		LOGGER.info("settlement report export = {}", sb);

		TypedQuery<PgwSettlement> query = entityManager.createQuery(sb.toString(), PgwSettlement.class);

		if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			query.setParameter(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom(), TemporalType.DATE);
		} else if (BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& !BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			query.setParameter(SETTLE_DATE_TO, DateUtil.addDayToTimestamp(settlementRptInfo.getSttleDateTo(), 1),
					TemporalType.DATE);
		} else if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& !BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			query.setParameter(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom(), TemporalType.DATE);
			query.setParameter(SETTLE_DATE_TO, settlementRptInfo.getSttleDateTo(), TemporalType.DATE);
		}

		return query.getResultList();
	}

}
