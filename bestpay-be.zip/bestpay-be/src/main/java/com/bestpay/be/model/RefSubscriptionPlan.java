package com.bestpay.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * The persistent class for the REF_SUBSCRIPTION_PLAN database table.
 *
 * @author Atiqah Khairuddin
 * @since Sept 13, 2018
 */
@Entity
@Table(name = "REF_SUBSCRIPTION_PLAN")
public class RefSubscriptionPlan extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -6510355585641387606L;

	@Id
	@Column(name = "SUB_PLAN_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer subPlanId;

	@Column(name = "PLAN_TYPE")
	private String planType;

	@Column(name = "PLAN_DESC")
	private String planDesc;

	@Column(name = "PLAN_RATIO")
	private String planRatio;

	@Column(name = "PLAN_VALUE")
	private String planValue;

	@Column(name = "PLAN_DATA_TYPE")
	private String planDataType;

	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getSubPlanId() {
		return subPlanId;
	}


	public void setSubPlanId(Integer subPlanId) {
		this.subPlanId = subPlanId;
	}


	public String getPlanType() {
		return planType;
	}


	public void setPlanType(String planType) {
		this.planType = planType;
	}


	public String getPlanDesc() {
		return planDesc;
	}


	public void setPlanDesc(String planDesc) {
		this.planDesc = planDesc;
	}


	public String getPlanRatio() {
		return planRatio;
	}


	public void setPlanRatio(String planRatio) {
		this.planRatio = planRatio;
	}


	public String getPlanValue() {
		return planValue;
	}


	public void setPlanValue(String planValue) {
		this.planValue = planValue;
	}


	public String getPlanDataType() {
		return planDataType;
	}


	public void setPlanDataType(String planDataType) {
		this.planDataType = planDataType;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}