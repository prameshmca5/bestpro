package com.bestpay.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwOfflineRequestPayment;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Raemsh Pongiannan
 * @since June 15, 2018
 */

@Repository
@RepositoryDefinition(domainClass = PgwOfflineRequestPayment.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_PAYLK_DAO)
public interface PgwOfflineRequestPaymentRepository extends GenericRepository<PgwOfflineRequestPayment> {

	@Query("select count(u) from PgwOfflineRequestPayment u ")
	public int totalRecords();


	@Query("select u from PgwOfflineRequestPayment u where u.orderId = :orderId ")
	public PgwOfflineRequestPayment findOrderIdByValue(@Param("orderId") String orderId);


	@Query("select u from PgwOfflineRequestPayment u where u.orderId = :orderId ")
	public PgwOfflineRequestPayment findPayLinkByTraceId(@Param("orderId") String orderId);


	@Query("select count(u) from PgwOfflineRequestPayment u where u.merchantId = :merchantId")
	public int totalmerchantRecords(@Param("merchantId") String merchantId);

}