/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Dashboard;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.google.gson.Gson;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_DASHBOARD)
public class DashboardController extends AbstractController {

	@GetMapping
	public ModelAndView dashboard(Dashboard dashboard, HttpSession session) throws BeException {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_DASHBOARD);
		dashboard.setUserRoleGroup(getCurrentUser().getUserRoleGroupCode());
		List<String> values = getBeService().getTransListByMonth(null);
		dashboard.setTransList(new Gson().toJson(values));
		dashboard.setTotalTodaysTransactions(getBeService().getTodaysCountSuccessfulTransactions(null));
		String sumAndCount = getBeService().getSumAndCountOfTransOfMonth(null);
		if (sumAndCount != null) {
			String transAmt = String.format("%.2f", Double.valueOf(sumAndCount.split("-")[0]));
			dashboard.setTransactionAmt(transAmt);
			dashboard.setTotalMonthlyTransactions(Integer.valueOf(sumAndCount.split("-")[1]));
		} else {
			dashboard.setTransactionAmt("0.00");
		}
		List<String> countList = getBeService().getCountByMerchantStatus();
		for (String s : countList) {
			if (!BaseUtil.isObjNull(s)) {
				String status = s.split("-")[0];
				int value = Integer.parseInt(s.split("-")[1]);
				if (status.equalsIgnoreCase("ACTIVE")) {
					dashboard.setActiveMerchants(value);
				}
				if (status.equalsIgnoreCase("INACTIVE")) {
					dashboard.setInActiveMerchants(value);
				}
				if (status.equalsIgnoreCase("NEW")) {
					dashboard.setNewMerchants(value);
				}
			}
		}
		String sumBillAmt = String.format("%.2f", getBeService().getSumOfBillAmt());
		dashboard.setSumOfSettlementAmt(sumBillAmt);
		List<String> statusTicketCountList = getBeService().getCountAllStatusOfTickets(null);
		for (String status : statusTicketCountList) {
			if (!BaseUtil.isObjNull(status)) {
				String stat = status.split("-")[0];
				int count = Integer.parseInt(status.split("-")[1]);
				if (stat.equalsIgnoreCase("OPEN")) {
					dashboard.setOpenTickets(count);
				} else if (stat.equalsIgnoreCase("INP")) {
					dashboard.setInProgressTickets(count);
				} else if (stat.equalsIgnoreCase("SOLVED")) {
					dashboard.setResolvedTickets(count);
				}
			}
		}
		mav.addObject("dashboard", dashboard);
		return mav;
	}

}