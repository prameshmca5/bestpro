package com.bestpay.web.cmn.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Ticket;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.google.gson.Gson;

@Controller
@RequestMapping(value = PageConstants.DASHBOARD_TICKET)
public class DashboardTicketController extends AbstractController {

	@GetMapping(value = "/{paramName}")
	public ModelAndView getTransListView(@PathVariable String paramName, HttpServletRequest request) {
		return getDefaultMav(PageTemplate.TEMP_DASH_TKT_VIEW, "ticket", null, "dashboard-ticket-list-script");
	}

	@GetMapping(value = "/openList")
	public @ResponseBody String searchPaginatedOpen(HttpServletRequest request) throws BeException {
		return getSearchList("OPEN", request);
	}

	@GetMapping(value = "/inprogressList")
	public @ResponseBody String searchPaginatedInprogress(HttpServletRequest request) throws BeException {
		return getSearchList("INP", request);
	}

	@GetMapping(value = "/resolvedList")
	public @ResponseBody String searchPaginatedResolved(HttpServletRequest request) throws BeException {
		return getSearchList("SOLVED", request);
	}

	private String getSearchList(String status, HttpServletRequest request) throws BeException {
		DataTableResults<Ticket> tasks = new DataTableResults<>();
		Ticket ticket = new Ticket();
		if (BaseUtil.isEquals(status, "OPEN") || BaseUtil.isEquals(status, "INP")
				|| BaseUtil.isEquals(status, "SOLVED")) {
			ticket.setStatus(status);
			ticket.setUserType(getCurrentUser().getUserRoleGroupCode());
			tasks = getBeService().searchTicket(ticket, getPaginationRequest(request, true));
		}
		return new Gson().toJson(tasks);
	}

}
