/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.util.List;


/**
 * @author Atiqah
 * @since June 20, 2018
 */
public class MerBusCat implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1864073233598003483L;

	private Integer merCatId;

	private String merchantId;

	private String roc;

	private String dba;

	private String reseller;

	private String newMerCat;

	private Integer addNewCat;

	private String category;

	private List<String> catList;

	private String userId;
	
	private Integer pdpa;


	public Integer getMerCatId() {
		return merCatId;
	}


	public void setMerCatId(Integer merCatId) {
		this.merCatId = merCatId;
	}


	public String getRoc() {
		return roc;
	}


	public void setRoc(String roc) {
		this.roc = roc;
	}


	public String getDba() {
		return dba;
	}


	public void setDba(String dba) {
		this.dba = dba;
	}


	public String getReseller() {
		return reseller;
	}


	public void setReseller(String reseller) {
		this.reseller = reseller;
	}


	public String getNewMerCat() {
		return newMerCat;
	}


	public void setNewMerCat(String newMerCat) {
		this.newMerCat = newMerCat;
	}


	public Integer getAddNewCat() {
		return addNewCat;
	}


	public void setAddNewCat(Integer addNewCat) {
		this.addNewCat = addNewCat;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public List<String> getCatList() {
		return catList;
	}


	public void setCatList(List<String> catList) {
		this.catList = catList;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public Integer getPdpa() {
		return pdpa;
	}


	public void setPdpa(Integer pdpa) {
		this.pdpa = pdpa;
	}
	
	

}