package com.bestpay.pgw.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;

/**
 * @author Atiqah Khairuddin
 * @since May 23, 2019
 */

@Entity
@Table(name = "PGW_MERCHANT_BENEFICIARY")
public class PgwMerchantBeneficiary extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "BEN_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer benId;

	@Column(name = "MERCHANTID")
	private String merchantId;

	@Column(name = "MTO_ID")
	private String mtoId;

	@Column(name = "BENEFICIARY_ID")
	private String benefeciaryId;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	public Integer getBenId() {
		return benId;
	}

	public void setBenId(Integer benId) {
		this.benId = benId;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getMtoId() {
		return mtoId;
	}

	public void setMtoId(String mtoId) {
		this.mtoId = mtoId;
	}

	public String getBenefeciaryId() {
		return benefeciaryId;
	}

	public void setBenefeciaryId(String benefeciaryId) {
		this.benefeciaryId = benefeciaryId;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


}
