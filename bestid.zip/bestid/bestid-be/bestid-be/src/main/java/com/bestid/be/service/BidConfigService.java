/**
 *
 */
package com.bestid.be.service;


import java.io.Serializable;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidConfig;
import com.bestid.be.qf.BidConfigQf;
import com.bestid.be.repo.BidConfigRepository;
import com.bestid.be.repo.GenericRepository;
import com.bestid.be.sdk.model.RefBidConfig;
import com.bstsb.util.pagination.DataTableRequest;
import com.bstsb.util.pagination.DataTableResults;


/**
 * @author roziana
 * @author mohd.faisal
 * @since Feb 26, 2019
 */
@Transactional
@Service(QualifierConstants.BID_CONFIG_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_CONFIG_SVC)
public class BidConfigService extends AbstractService<BidConfig> {

	@Autowired
	@Qualifier(QualifierConstants.BID_CONFIG_REPOSITORY)
	BidConfigRepository bidConfigDao;

	@Autowired
	@Qualifier(QualifierConstants.BID_CONFIG_QF)
	BidConfigQf bidConfigQf;


	@Override
	public GenericRepository<BidConfig> primaryDao() {
		return bidConfigDao;
	}


	public DataTableResults<BidConfig> bidConfigPaginated(DataTableRequest<BidConfig> dataTableRequest,
			RefBidConfig config) {
		return bidConfigQf.getBidConfigPaginated(dataTableRequest, config);
	}


	public BidConfig findConfigCd(String configCd) {
		return bidConfigDao.findByConfigCd(configCd);
	}


	public BidConfig findByConfigCd(String configCd) {
		return bidConfigDao.findByConfigCd(configCd);
	}


	public BidConfig findByConfigId(Integer configId) {
		return bidConfigDao.findByConfigId(configId);
	}


	public Map<String, Serializable> countRecord(String configCd) {
		return bidConfigQf.countRecord(configCd);
	}

}
