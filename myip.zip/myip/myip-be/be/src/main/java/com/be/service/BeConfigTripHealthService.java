/**
 *
 */
package com.be.service;


import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.ConfigConstants;
import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeConfigTripHealthQf;
import com.be.dao.BeConfigTripHealthRepository;
import com.be.model.BeConfigTripHealth;
import com.be.sdk.model.IQfCriteria;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_CONFIG_TRIP_HEALTH_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_CONFIG_TRIP_HEALTH_SVC)
public class BeConfigTripHealthService extends AbstractService<BeConfigTripHealth> {

	@Autowired
	BeConfigTripHealthRepository beConfigTripHealthDao;

	@Autowired
	BeConfigTripHealthQf beConfigTripHealthQf;


	@Override
	public GenericRepository<BeConfigTripHealth> primaryDao() {
		return beConfigTripHealthDao;
	}


	@Override
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beConfigTripHealthQf.generateCriteria(cb, from, criteria);
	}


	@Override
	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_CONFIG_TRIP_HEALTH_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<BeConfigTripHealth> findAll() {
		return beConfigTripHealthDao.findAll();
	}


	public List<BeConfigTripHealth> searchAllByProperty(BeConfigTripHealth beConfigTripHealth) {
		return beConfigTripHealthQf.searchAllByProperty(beConfigTripHealth);
	}

}
