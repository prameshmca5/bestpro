/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.core;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.web.constants.AppConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bstsb.util.BaseUtil;

/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
@Controller
public class StaticContentController extends AbstractController {

	@GetMapping(value = PageConstants.PAGE_SRC)
	public ModelAndView home(@RequestParam(value = "portal", required = false) String portal, HttpSession session) {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_DASHBOARD);
		if (portal == null) {
			portal = messageService.getMessage("app.portal.type");
		}

		if (BaseUtil.isObjNull(portal) && isUserAuthenticated()) {
			return new ModelAndView("redirect:" + PageConstants.PAGE_DASHBOARD);
		} else {
			mav.setViewName(PageTemplate.TEMP_LOGIN);
		}
		return mav;
	}

	@GetMapping(value = PageConstants.PAGE_COMPONENTS)
	public ModelAndView components() {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_COMPONENTS, "components", null, "components-script");
		mav.addObject(AppConstants.PAGE_TITLE, "Components");
		return mav;
	}

	@GetMapping(value = "/favicon.ico")
	public String favicon() {
		return "forward:/images/favicon.ico";
	}

}