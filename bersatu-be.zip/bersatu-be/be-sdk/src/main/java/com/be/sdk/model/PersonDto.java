/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.util.List;


/**
 * @author nurul.naimma
 *
 * @since Jul 13, 2021
 */
public class PersonDto implements Serializable {

	private static final long serialVersionUID = 1126886434347227429L;

	private String personId;

	private String faceId;

	private double confidence;

	private String person;

	private String face;

	private String name;

	private List<String> details;

	private String creation;

	private String code;

	private String message;

	private List<FacesDto> faces;

	private String result;

	private double similarity;


	/**
	 * @return the personId
	 */
	public String getPersonId() {
		return personId;
	}


	/**
	 * @param personId
	 *             the personId to set
	 */
	public void setPersonId(String personId) {
		this.personId = personId;
	}


	/**
	 * @return the faceId
	 */
	public String getFaceId() {
		return faceId;
	}


	/**
	 * @param faceId
	 *             the faceId to set
	 */
	public void setFaceId(String faceId) {
		this.faceId = faceId;
	}


	/**
	 * @return the confidence
	 */
	public double getConfidence() {
		return confidence;
	}


	/**
	 * @param confidence
	 *             the confidence to set
	 */
	public void setConfidence(double confidence) {
		this.confidence = confidence;
	}


	/**
	 * @return the person
	 */
	public String getPerson() {
		return person;
	}


	/**
	 * @param person
	 *             the person to set
	 */
	public void setPerson(String person) {
		this.person = person;
	}


	/**
	 * @return the face
	 */
	public String getFace() {
		return face;
	}


	/**
	 * @param face
	 *             the face to set
	 */
	public void setFace(String face) {
		this.face = face;
	}


	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}


	/**
	 * @param name
	 *             the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}


	/**
	 * @return the details
	 */
	public List<String> getDetails() {
		return details;
	}


	/**
	 * @param details
	 *             the details to set
	 */
	public void setDetails(List<String> details) {
		this.details = details;
	}


	/**
	 * @return the creation
	 */
	public String getCreation() {
		return creation;
	}


	/**
	 * @param creation
	 *             the creation to set
	 */
	public void setCreation(String creation) {
		this.creation = creation;
	}


	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}


	/**
	 * @param code
	 *             the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}


	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}


	/**
	 * @param message
	 *             the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}


	/**
	 * @return the faces
	 */
	public List<FacesDto> getFaces() {
		return faces;
	}


	/**
	 * @param faces
	 *             the faces to set
	 */
	public void setFaces(List<FacesDto> faces) {
		this.faces = faces;
	}


	/**
	 * @return the result
	 */
	public String getResult() {
		return result;
	}


	/**
	 * @param result
	 *             the result to set
	 */
	public void setResult(String result) {
		this.result = result;
	}


	/**
	 * @return the similarity
	 */
	public double getSimilarity() {
		return similarity;
	}


	/**
	 * @param similarity
	 *             the similarity to set
	 */
	public void setSimilarity(double similarity) {
		this.similarity = similarity;
	}

}
