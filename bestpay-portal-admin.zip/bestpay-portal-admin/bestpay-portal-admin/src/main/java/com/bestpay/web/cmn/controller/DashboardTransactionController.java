package com.bestpay.web.cmn.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Channel;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.sdk.model.Transaction;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.google.gson.Gson;

@Controller
@RequestMapping(value = PageConstants.DASHBOARD_TRANSACTIONS)
public class DashboardTransactionController extends AbstractController {

	@GetMapping(value = "/{paramName}")
	public ModelAndView getTransListView(@PathVariable String paramName, HttpServletRequest request)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_DASH_TRANS_VIEW, "transactions", null,
				"dashboard-transaction-list-script");
		List<Status> status = staticData.status("TRANSTAT");
		List<Channel> channel = staticData.channelList();
		mav.addObject("statusList", status);
		mav.addObject("channelList", channel);
		return mav;
	}

	@GetMapping(value = "/monthlyTransactionsList")
	public @ResponseBody String searchPaginated(HttpServletRequest request) throws BeException {
		DataTableResults<Transaction> tasks = getBeService().getMonthlySuccessfulTransactions(null,
				getPaginationRequest(request, true));
		return new Gson().toJson(tasks);
	}

	@GetMapping(value = "/todaysTransactionsList")
	public @ResponseBody String todayTransactions(HttpServletRequest request) throws BeException {
		DataTableResults<Transaction> tasks = getBeService().getTodaysSuccessfulTransactions(null,
				getPaginationRequest(request, true));
		return new Gson().toJson(tasks);
	}

	@GetMapping(value = "/settlementsList")
	public @ResponseBody String searchTransList(HttpServletRequest request) throws BeException {
		Transaction transaction = new Transaction();
		transaction.setSetId(0);
		transaction.setStatus("success");
		DataTableResults<Transaction> tasks = getBeService().searchTransList(transaction,
				getPaginationRequest(request, true));
		return new Gson().toJson(tasks);
	}

}
