/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.sdk.constants;


/**
 * @author nurul.naimma
 *
 * @since Jun 2, 2021
 */
public enum RegulaFieldEnum {

	ID_NO(2, "idNo"),
	NAME(25, "fullName"),
	DOB(5, "dob"),
	GENDER(12, "gender"),
	ADDRESS(17, "address"),
	RELIGION(363, "religion");


	public final int code;

	public final String field;


	RegulaFieldEnum(int code, String field) {
		this.code = code;
		this.field = field;
	}


	public static String findFieldByCode(int code) {
		for (RegulaFieldEnum v : RegulaFieldEnum.values()) {
			if (v.getCode() == code) {
				return v.getField();
			}
		}
		return null;
	}


	public int getCode() {
		return code;
	}


	public String getField() {
		return field;
	}

}
