/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.model;


import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@Entity
@Table(name = "PGW_SETTLEMENT_CONFIG")
public class PgwSettlementConfig extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SETID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer setId;

	@Column(name = "RESERVE_DAY")
	private Integer reserveDay;

	@Column(name = "SETTLE_DAY")
	private String settleDay;

	@Column(name = "RECENT_SETTLE_DATE")
	private Date recentSettleDate;

	@Column(name = "NEXT_SETTLE_DATE")
	private Date nextSettleDate;

	@Column(name = "MERCHANTID")
	private String merchantId;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public PgwSettlementConfig() {
		// pgwSettlementConfig backend model
	}


	public Integer getSetId() {
		return setId;
	}


	public void setSetId(Integer setId) {
		this.setId = setId;
	}


	public Integer getReserveDay() {
		return reserveDay;
	}


	public void setReserveDay(Integer reserveDay) {
		this.reserveDay = reserveDay;
	}


	public String getSettleDay() {
		return settleDay;
	}


	public void setSettleDay(String settleDay) {
		this.settleDay = settleDay;
	}


	public Date getRecentSettleDate() {
		return recentSettleDate;
	}


	public void setRecentSettleDate(Date recentSettleDate) {
		this.recentSettleDate = recentSettleDate;
	}


	public Date getNextSettleDate() {
		return nextSettleDate;
	}


	public void setNextSettleDate(Date nextSettleDate) {
		this.nextSettleDate = nextSettleDate;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}