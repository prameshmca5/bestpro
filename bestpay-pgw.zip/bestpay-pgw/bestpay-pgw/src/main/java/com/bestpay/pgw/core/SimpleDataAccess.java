/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.core;


import java.util.List;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public interface SimpleDataAccess<S extends AbstractEntity> {

	public S create(final S s);


	public S update(final S s);


	public S find(final Integer id);


	public List<S> findAll();


	public boolean delete(final Integer id);

}
