/**
 *
 */
package com.bestpay.be.core;


import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AdviceMode;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Mary Jane Buenaventura
 * @since May 15, 2018
 */
@EnableTransactionManagement(mode = AdviceMode.PROXY, proxyTargetClass = true)
@Transactional(QualifierConstants.TRANS_MANAGER)
public abstract class AbstractService<S extends AbstractEntity> implements SimpleDataAccess<S> {

	protected Logger logger = LoggerFactory.getLogger(AbstractService.class);

	@Autowired
	protected Mapper dozerMapper;

	@Autowired
	@Qualifier(QualifierConstants.TRANS_MANAGER)
	protected PlatformTransactionManager transactionManager;


	public abstract GenericRepository<S> primaryDao();


	@Override
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = BeException.class)
	public S create(S s) {
		try {
			this.primaryDao().save(s);
			return s;
		} catch (RuntimeException e) {
			logger.error("create Exception", e);
			return null;
		}
	}


	@Override
	@Modifying(clearAutomatically = true)
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = BeException.class)
	public S update(S s) {
		try {
			this.primaryDao().saveAndFlush(s);
			return s;
		} catch (RuntimeException e) {
			logger.error("update Exception", e);
			return null;
		}
	}


	@Override
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = true, rollbackFor = BeException.class)
	public S find(java.lang.Integer id) {
		try {
			return this.primaryDao().findOne(id);
		} catch (RuntimeException e) {
			logger.error("find Exception", e);
			return null;
		}
	}


	@Override
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = true, rollbackFor = BeException.class)
	public List<S> findAll() {
		try {
			return this.primaryDao().findAll();
		} catch (RuntimeException e) {
			logger.error("findAll Exception", e);
			return Collections.emptyList();
		}
	}


	@Override
	@Modifying(clearAutomatically = true)
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = BeException.class)
	public boolean delete(java.lang.Integer id) {
		try {
			this.primaryDao().delete(id);
			return true;
		} catch (RuntimeException e) {
			logger.error("delete Exception", e);
			return false;
		}
	}


	protected Timestamp getSQLTimestamp() {
		Calendar calendar = Calendar.getInstance();
		java.util.Date now = calendar.getTime();
		return new java.sql.Timestamp(now.getTime());
	}

}
