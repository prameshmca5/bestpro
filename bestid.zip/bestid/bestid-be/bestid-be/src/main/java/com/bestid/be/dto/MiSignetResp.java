/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.dto;


import java.io.Serializable;


/**
 * @author Naem Othman
 * @since Feb 12, 2019
 */
public class MiSignetResp implements Serializable {

	private static final long serialVersionUID = -423519805431834764L;

	private String statusCode;

	private String data;


	public MiSignetResp() {
	}


	public MiSignetResp(String statusCode, String data) {
		this.statusCode = statusCode;
		this.data = data;
	}


	public String getStatusCode() {
		return statusCode;
	}


	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}


	public Object getData() {
		return data;
	}


	public void setData(String data) {
		this.data = data;
	}

}
