/**
 * Copyright 2019
 */
package com.be.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 17, 2018
 */
public class QualifierConstants {

	private QualifierConstants() {
		throw new IllegalStateException(QualifierConstants.class.getName());
	}


	public static final String TRANS_MANAGER = "transactionManager";

	public static final String ENTITY_MANAGER = "entityManagerFactory";

	public static final String ENTITY_MANAGER_UNIT = "emf";

	public static final String SCOPE_PROTOTYPE = "prototype";

	public static final String MESSAGE_SVC = "messageService";

	public static final String REF_STATUS_DAO = "refStatusDao";

	public static final String REF_STATUS_CUSTOM_DAO = "refStatusCustomDao";

	public static final String REF_STATUS_SVC = "refStatusSvc";

	public static final String REF_COUNTRY_DAO = "refCountryDao";

	public static final String REF_COUNTRY_QF = "refCountryQf";

	public static final String REF_COUNTRY_SVC = "refCountrySvc";

	public static final String REF_DOCUMENT_DAO = "refDocumentDao";

	public static final String BE_DOCUMENT_QF = "beDocumentQf";

	public static final String REF_DOCUMENT_SVC = "refDocumentSvc";

	public static final String REF_STATE_SVC = "refStateSvc";

	public static final String REF_STATE_DAO = "refStateDao";

	public static final String REF_STATE_QF = "refStateQf";

	public static final String REF_CITY_DAO = "refCityDao";

	public static final String REF_CITY_QF = "refCityQf";

	public static final String REF_CITY_SVC = "refCitySvc";

	public static final String BE_AUDIT_TRAIL_DAO = "beAuditTrailDao";

	public static final String BE_AUDIT_TRAIL_SVC = "beAuditTrailSvc";

	public static final String BE_CONFIG_DAO = "beConfigDao";

	public static final String BE_CONFIG_SVC = "beConfigSvc";

	public static final String BE_CTRL_GEN_SERVICE = "beCtrlGenSvc";

	public static final String BE_CTRL_GEN_DAO = "beCtrlGenDao";

	public static final String BE_TRXN_DOC_DAO = "beTrxnDocumentDao";

	public static final String BE_TRXN_DOC_QF = "beTrxnDocumentQf";

	public static final String BE_TRXN_DOC_SVC = "beTrxnDocumentSvc";

	public static final String REF_METADATA_DAO = "refMetadataDao";

	public static final String REF_METADATA_QF = "refMetadataQf";

	public static final String REF_METADATA_SVC = "refMetadataSvc";

	public static final String REF_REASON_DAO = "refReasonDao";

	public static final String REF_REASON_QF = "refReasonQf";

	public static final String REF_REASON_SVC = "refReasonSvc";

	public static final String BE_ACCT_PROFILE_DAO = "beAcctProfileDao";

	public static final String BE_ACCT_PROFILE_QF = "beAcctProfileQf";

	public static final String BE_ACCT_PROFILE_SVC = "beAcctProfileSvc";

	public static final String BE_ACCT_TRAVELLER_DAO = "beAcctTravellerDao";

	public static final String BE_ACCT_TRAVELLER_QF = "beAcctTravellerQf";

	public static final String BE_ACCT_TRAVELLER_SVC = "beAcctTravellerSvc";

	public static final String BE_ACCT_PASSPORT_DAO = "beAcctPassportDao";

	public static final String BE_ACCT_PASSPORT_QF = "beAcctPassportQf";

	public static final String BE_ACCT_PASSPORT_SVC = "beAcctPassportSvc";

	public static final String BE_TVL_DAO = "beTvlDao";

	public static final String BE_TVL_QF = "beTvlDaoQf";

	public static final String BE_TVL_SVC = "beTvlSvc";

	public static final String BE_TVL_PROFILE_DAO = "beTvlProfileDao";

	public static final String BE_TVL_PROFILE_QF = "beTvlProfileQf";

	public static final String BE_TVL_PROFILE_SVC = "beTvlProfileSvc";

	public static final String BE_TVL_PAYMENT_DAO = "beTvlPaymentDao";

	public static final String BE_TVL_PAYMENT_QF = "beTvlPaymentQf";

	public static final String BE_TVL_PAYMENT_SVC = "beTvlPaymentSvc";

	public static final String BE_TVL_PAYMENT_DTL_DAO = "beTvlPaymentDtlDao";

	public static final String BE_TVL_PAYMENT_DTL_QF = "beTvlPaymentDtlQf";

	public static final String BE_TVL_PAYMENT_DTL_SVC = "beTvlPaymentDtlSvc";

	public static final String BE_TVL_PAYMENT_KIPLE_DAO = "beTvlPaymentKipleDao";

	public static final String BE_TVL_PAYMENT_KIPLE_QF = "beTvlPaymentKipleQf";

	public static final String BE_TVL_PAYMENT_KIPLE_SVC = "beTvlPaymentKipleSvc";

	public static final String BE_TVL_TRIP_DAO = "beTvlTripDao";

	public static final String BE_TVL_TRIP_QF = "beTvlTripQf";

	public static final String BE_TVL_TRIP_SVC = "beTvlTripSvc";

	public static final String BE_TVL_INSURANCE_DAO = "beTvlInsuranceDao";

	public static final String BE_TVL_INSURANCE_QF = "beTvlInsuranceQf";

	public static final String BE_TVL_INSURANCE_SVC = "beTvlInsuranceSvc";

	public static final String BE_TVL_MC_ATTENDANCE_DAO = "beTvalMcAttendanceDao";

	public static final String BE_TVL_MC_ATTENDANCE_QF = "beTvalMcAttendanceQf";

	public static final String BE_TVL_TEST_RESULT_SVC = "beTvlTestResultSvc";

	public static final String BE_TVL_TEST_RESULT_DAO = "beTvlTestResultDao";

	public static final String BE_TVL_TEST_RESULT_QF = "beTvlTestResultQf";

	public static final String BE_TVL_MC_ATTENDANCE_SVC = "beTvalMcAttendanceSvc";

	public static final String BE_CONFIG_PAYMENT_BREAKDOWN_DAO = "beConfigPaymentBreakdownDao";

	public static final String BE_CONFIG_PAYMENT_BREAKDOWN_QF = "beConfigPaymentBreakdownQf";

	public static final String BE_CONFIG_PAYMENT_BREAKDOWN_SVC = "beConfigPaymentBreakdownSvc";

	public static final String BE_CONFIG_PAYMENT_STAGE_DAO = "beConfigPaymentStageDao";

	public static final String BE_CONFIG_PAYMENT_STAGE_QF = "beConfigPaymentStageQf";

	public static final String BE_CONFIG_PAYMENT_STAGE_SVC = "beConfigPaymentStageSvc";

	public static final String BE_CONFIG_MC_COLLATE_DAO = "beConfigMcCollateDao";

	public static final String BE_CONFIG_MC_COLLATE_QF = "beConfigMcCollateQf";

	public static final String BE_CONFIG_MC_COLLATE_SVC = "beConfigMcCollateSvc";

	public static final String REF_CHANNEL_DAO = "refChannelDao";

	public static final String REF_CHANNEL_QF = "refChannelQf";

	public static final String REF_CHANNEL_SVC = "refChannelSvc";

	public static final String REF_PYMNT_MSG_CODE_DAO = "refPymntMsgCodeDao";

	public static final String REF_PYMNT_MSG_CODE_QF = "refPymntMsgCodeQf";

	public static final String REF_PYMNT_MSG_CODE_SVC = "refPymntMsgCodeSvc";

	public static final String BE_TVL_MC_COLLATE_SVC = "beTvlMcCollateSvc";

	public static final String BE_TVL_MC_COLLATE_DAO = "beTvlMcCollateDao";

	public static final String BE_TVL_MC_COLLATE_QF = "beTvlMcCollateQf";

	public static final String BE_TVL_TRIP_HEALTH_SVC = "beTripHealthSvc";

	public static final String BE_TVL_TRIP_HEALTH_DAO = "beTripHealthDao";

	public static final String BE_TVL_TRIP_HEALTH_QF = "beTripHealthQf";

	public static final String BE_TRIP_ACCOMMODATION_SVC = "beTripAccommodationSvc";

	public static final String BE_TRIP_ACCOMMODATION_DAO = "beTripAccommodationDao";

	public static final String BE_TRIP_ACCOMMODATION_QF = "beTripAccommodationQf";

	public static final String BE_CONFIG_TRIP_HEALTH_SVC = "beConfigTripHealthSvc";

	public static final String BE_CONFIG_TRIP_HEALTH_DAO = "beConfigTripHealthDao";

	public static final String BE_CONFIG_TRIP_HEALTH_QF = "beConfigTripHealthQf";

	public static final String BE_TVL_PAYMENTDTL_QF = "beTvlPaymentDtlQf";

	public static final String BE_TVL_PAYMENTBKDWN_QF = "beTvlPaymentBreakdownQf";

	public static final String BE_MC_PROFILE_DAO = "beMcProfileDao";

	public static final String BE_MC_PROFILE_QF = "beMcProfileQf";

	public static final String BE_MC_PROFILE_SVC = "beMcProfileSvc";

	public static final String BE_MC_PIC_DAO = "beMcPicDao";

	public static final String BE_MC_PIC_QF = "beMcPicQf";

	public static final String BE_MC_PIC_SVC = "beMcPicSvc";

	public static final String BE_MC_OWNER_DAO = "beMcOwnerDao";

	public static final String BE_MC_OWNER_QF = "beMcOwnerQf";

	public static final String BE_MC_OWNER_SVC = "beMcOwnerSvc";

	public static final String BE_MC_ADDRESS_DAO = "beMcAddressDao";

	public static final String BE_MC_ADDRESS_QF = "beMcAddressQf";

	public static final String BE_MC_ADDRESS_SVC = "beMcAddressSvc";

	public static final String BE_AIRLINES_PROFILE_DAO = "beAirlinesProfileDao";

	public static final String BE_AIRLINES_PROFILE_QF = "beAirlinesProfileQf";

	public static final String BE_AIRLINES_PROFILE_SVC = "beAirlinesProfileSvc";

	public static final String BE_AIRLINES_PIC_DAO = "beAirlinesPicDao";

	public static final String BE_AIRLINES_PIC_QF = "beAirlinesPicQf";

	public static final String BE_AIRLINES_PIC_SVC = "beAirlinesPicSvc";

	public static final String BE_AIRLINES_CONTACT_DAO = "beAirlinesContactDao";

	public static final String BE_AIRLINES_CONTACT_QF = "beAirlinesContactQf";

	public static final String BE_AIRLINES_CONTACT_SVC = "beAirlinesContactSvc";

	public static final String BE_AIRLINES_ADDRESS_DAO = "beAirlinesAddressDao";

	public static final String BE_AIRLINES_ADDRESS_QF = "beAirlinesAddressQf";

	public static final String BE_AIRLINES_ADDRESS_SVC = "beAirlinesAddressSvc";

	public static final String BE_TVL_REFUND_SVC = "beTvlRefundSvc";

	public static final String BE_TVL_REFUND_DAO = "beTvlRefundDao";

	public static final String BE_TVL_REFUND_QF = "beTvlRefundQf";

	public static final String BE_TVL_STAT_SVC = "beTvlStatSvc";

	public static final String BE_TVL_STAT_DAO = "beTvlStatDao";

	public static final String BE_TVL_STAT_QF = "beTvlStatQf";

	public static final String REF_INT_AIRPORT_DAO = "refIntAirportDao";

	public static final String REF_INT_AIRPORT_QF = "refIntAirportQf";

	public static final String REF_INT_AIRPORT_SVC = "refIntAirportSvc";

	public static final String BE_TVL_PAYMENT_INFO_SVC = "beTvlPaymentInfoSvc";

	public static final String BE_TVL_PAYMENT_INFO_DAO = "beTvlPaymentInfoDao";

	public static final String BE_TVL_PAYMENT_INFO_QF = "beTvlPaymentInfoQf";

	public static final String BE_DOCTOR_PROFILE_SVC = "beDoctorProfileSvc";

	public static final String BE_DOCTOR_PROFILE_DAO = "beDoctorProfileDao";

	public static final String BE_DOCTOR_PROFILE_QF = "beDoctorProfileQf";

	public static final String INTEGRATION_SVC = "integrationSvc";

	public static final String BE_CONFIG_RISK_STATUS_SVC = "beConfigRiskStatusSvc";

	public static final String BE_CONFIG_RISK_STATUS_DAO = "beConfigRiskStatusDao";

	public static final String BE_CONFIG_RISK_STATUS_QF = "beConfigRiskStatusQf";

	public static final String REF_TIMEZONE_DAO = "refTimeZoneDao";

	public static final String REF_TIMEZONE_QF = "refTimeZoneQf";

	public static final String REF_TIMEZONE_SVC = "refTimeZoneSvc";
}