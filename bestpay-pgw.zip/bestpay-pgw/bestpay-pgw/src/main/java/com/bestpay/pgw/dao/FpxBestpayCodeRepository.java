/**
e * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.RefFpxBestpayCode;
import com.bestpay.pgw.util.QualifierConstants;
/**
 * @author Atiqah Khairuddin
 * @since 22/02/2019
 */
@Repository
@RepositoryDefinition(domainClass=RefFpxBestpayCode.class, idClass=String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.FPX_BESTPAY_CODE_DAO)
public interface FpxBestpayCodeRepository extends GenericRepository<RefFpxBestpayCode>{
	
	@Query("select u from RefFpxBestpayCode u, RefFpxResponseCode v where v.fpxCode =:bestpayCode and u.bestpayCode = v.bestpayCode")
	public RefFpxBestpayCode findBestpayCodeDescr(@Param("bestpayCode") String bestpayCode);
	
}