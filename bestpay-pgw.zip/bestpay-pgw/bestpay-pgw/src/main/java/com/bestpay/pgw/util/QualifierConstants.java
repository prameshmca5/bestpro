/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.util;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public class QualifierConstants {

	private QualifierConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String SCOPE_PROTOTYPE = "prototype";

	public static final String TRANS_MANAGER = "transactionManager";

	public static final String ENTITY_MANAGER = "entityManagerFactory";

	public static final String ENTITY_MANAGER_UNIT = "emf";

	public static final String MESSAGE_SVC = "messageService";

	public static final String CONFIG_PGW_CONFIG_DAO = "pgwPayConfigDao";

	public static final String CONFIG_PGW_CONFIG_SVC = "pgwPayConfigSvc";

	public static final String REF_STATUS_DAO = "refStatusDao";

	public static final String REF_STATUS_SVC = "refStatusService";

	public static final String REF_COUNTRY_DAO = "refCountryDao";

	public static final String REF_COUNTRY_SVC = "refCountryService";

	public static final String REF_DOCUMENT_DAO = "refDocumentDao";

	public static final String REF_DOCUMENT_SVC = "refDocumentSvc";

	public static final String APJ_COMMON_SVC = "apjCmnSvc";

	public static final String APJ_COMMON_DAO = "apjCmnDao";

	public static final String REF_PAYMENT_TYPE_SVC = "paymentTypeSvc";

	public static final String REF_PAYMENT_TYPE_DAO = "paymentTypeDao";

	public static final String REF_STATE_SVC = "refStateSvc";

	public static final String REF_STATE_DAO = "refStateDao";

	public static final String APJ_CITY_DAO = "apjCityDao";

	public static final String APJ_CITY_SVC = "apjCitySvc";

	public static final String REF_NATIONALITY_DAO = "refNationalityDao";

	public static final String REF_NATIONALITY_SVC = "refNationalitySvc";

	public static final String REF_RELATIONSHIP_DAO = "refRelationshipDao";

	public static final String APJ_RELATIONSHIP_SVC = "apjRelationshipSvc";

	public static final String PGW_TRAIL_DAO = "pgwAuditTrailDao";

	public static final String PGW_TRAIL_SVC = "pgwAuditTrailSvc";

	public static final String REF_BANK_FPX_DAO = "refBankFpxDao";

	public static final String REF_BANK_FPX_SVC = "refBankFpxSvc";

	public static final String FPX_RESPONSE_CODE_DAO = "refFpxResponseCodeDao";

	public static final String FPX_RESPONSE_CODE_SVC = "refFpxResponseCodeSvc";

	public static final String ONLINE_PAYMENT_DAO = "onlinePaymentDao";

	public static final String ONLINE_PAYMENT_SVC = "onlinePaymentSvc";

	public static final String PGW_TRANSACTION_DAO = "pgwTransationDao";

	public static final String PGW_TRANSACTION_SVC = "pgwTransationSvc";

	public static final String PGW_CTRL_GEN_DAO = "pgwCtrlGenDao";

	public static final String PGW_CTRL_GEN_SVC = "pgwCtrlGenSvc";

	public static final String PGW_PAY_SETTING_DAO = "pgwPaySettingDao";

	public static final String PGW_PAY_SETTING_SVC = "pgwPaySettingSvc";

	public static final String PGW_TRANSACTION_HIS_DAO = "pgwTransationHisDao";

	public static final String PGW_TRANSACTION_HIS_SVC = "pgwTransationHisSvc";

	public static final String PGW_MULTIRATE_DAO = "pgwMultirateDao";

	public static final String PGW_MULTIRATE_SVC = "pgwMultirateSvc";

	public static final String PGW_MULTI_CHANNEL_DAO = "pgwMultiChannelDao";

	public static final String PGW_MULTI_CHANNEL_SVC = "pgwMultiChannelSvc";

	public static final String PGW_BANKDETIALS_DAO = "pgwBankDetailsDao";

	public static final String PGW_BANKDETIALS_SVC = "pgwBankDetailsSvc";

	public static final String PGW_MERCHANT_PROFILE_DAO = "pgwMerchantProfileDao";

	public static final String PGW_MERCHANT_PROFILE_SVC = "pgwMerchantProfileSvc";

	public static final String PGW_MERCHANT_CONTACT_DAO = "pgwMerchantContactDao";

	public static final String PGW_MERCHANT_CONTACT_SVC = "pgwMerchantContactSvc";

	public static final String REF_CHANNEL_DAO = "refChannelDao";

	public static final String REF_CHANNEL_SVC = "refChannelSvc";

	public static final String FPX_BESTPAY_CODE_SVC = "refFpxBestpayCodeSvc";

	public static final String FPX_BESTPAY_CODE_DAO = "refFpxBestpayCodeDao";

	public static final String PGW_MERCHANT_PID_DAO = "pgwMerchantPidDao";

	public static final String PGW_MERCHANT_PID_SVC = "pgwMerchantPidSvc";

	public static final String PGW_MERCHANT_BENEFICIARY_SVC = "pgwMerchantBeneficiarySvc";

	public static final String PGW_MERCHANT_BENEFICIARY_DAO = "pgwMerchantBeneficiaryDao";

	public static final String PGW_MERCHANT_COMPANY_DAO = "pgwMerchantCompanyDao";

	public static final String PGW_MERCHANT_COMPANY_SVC = "pgwMerchantCompanyService";

	public static final String PGW_MERCHANT_COMPANY_BANK_DETAILS_SVC = "pgwMerchantCompanyBankDetailsService";

	public static final String PGW_MERCHANT_COMPANY_BANK_DETAILS_DAO = "pgwMerchantCompanyBankDetailsDao";

	public static final String PGW_MERCHANT_PROVIDER_DAO = "pgwMerchantProviderDao";

	public static final String PGW_MERCHANT_PROVIDER_SVC = "pgwMerchantProviderService";

}