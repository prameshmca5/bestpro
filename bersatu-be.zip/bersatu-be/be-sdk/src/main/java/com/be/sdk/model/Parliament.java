/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author Ramesh Pongiannan
 *
 */
public class Parliament implements Serializable, IQfCriteria<Parliament> {

	private static final long serialVersionUID = 5466589728737397061L;

	private String parliamentCd;

	private String parliamentDesc;

	private String stateCd;

	private State state;
	
	private String divisionCd;

	private String status;

	private Timestamp createDt;

	private String createId;

	private Timestamp updateDt;

	private String updateId;


	public String getParliamentCd() {
		return parliamentCd;
	}


	public void setParliamentCd(String parliamentCd) {
		this.parliamentCd = parliamentCd;
	}


	public String getParliamentDesc() {
		return parliamentDesc;
	}


	public void setParliamentDesc(String parliamentDesc) {
		this.parliamentDesc = parliamentDesc;
	}


	public String getStateCd() {
		return stateCd;
	}


	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}


	public State getState() {
		return state;
	}


	public void setState(State state) {
		this.state = state;
	}


	public String getDivisionCd() {
		return divisionCd;
	}


	public void setDivisionCd(String divisionCd) {
		this.divisionCd = divisionCd;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
