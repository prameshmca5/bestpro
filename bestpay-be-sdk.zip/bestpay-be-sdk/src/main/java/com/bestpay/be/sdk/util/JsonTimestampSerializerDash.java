/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestpay.be.sdk.util;


import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import com.bestpay.be.sdk.constants.BaseConstants;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;


/**
 * @author N.N.Shuhada
 * @since June 29, 2018
 */
public class JsonTimestampSerializerDash extends JsonSerializer<Timestamp> {

	private SimpleDateFormat dateFormat = new SimpleDateFormat(BaseConstants.DT_DD_MM_YYYY_DASH_TIME_A);


	@Override
	public void serialize(Timestamp timestamp, JsonGenerator gen, SerializerProvider provider) throws IOException {
		gen.writeString(dateFormat.format(timestamp));
	}

}
