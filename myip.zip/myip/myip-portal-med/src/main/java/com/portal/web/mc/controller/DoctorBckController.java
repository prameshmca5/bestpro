package com.portal.web.mc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.Doctor;
import com.be.sdk.model.DoctorProfile;
import com.be.sdk.model.McProfile;
import com.be.sdk.model.Status;
import com.google.gson.Gson;
import com.idm.sdk.model.UserProfile;
import com.portal.constants.AppConstants;
import com.portal.constants.PageConstants;
import com.portal.constants.PageTemplate;
import com.portal.core.AbstractController;
import com.util.PopupBox;
import com.util.model.RefDocuments;
import com.util.pagination.DataTableResults;

@Controller
@RequestMapping(value = PageConstants.PAGE_SEARCH_DOCTOR_BCK)
public class DoctorBckController extends AbstractController {
	 
	  
	/*
	 * @Autowired
	 * 
	 * @Qualifier("doctorProfileValidator") private Validator
	 * doctorProfileValidator;
	 * 
	 * @Override
	 * 
	 * @InitBinder public void bindingPreparation(WebDataBinder binder) {
	 * binder.setValidator(doctorProfileValidator);
	 * binder.registerCustomEditor(String.class, new StringTrimmerEditor(false)); }
	 */
	
	@Autowired
    @Qualifier("doctorProfileValidator")
    private Validator validator;

 

    @Override
    protected void bindingPreparation(WebDataBinder binder) {
        binder.setValidator(validator);
        super.bindingPreparation(binder);
    }
	 
	 
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DoctorBckController.class);
	private static final String JS_FILENAME = "doctor";
	//private static final String url_path_string = "doc-search";
	private static final String MODULE = "";
	
	@GetMapping
	public ModelAndView list(@ModelAttribute("doctorProfile") DoctorProfile doctorProfile, BindingResult result,
			HttpServletRequest request) {
		String url_path_string = "doc-search";
		//ModelAndView mav = getDefaultMav(PageTemplate.PAGE_DOC_SRCH, MODULE, null, null, JS_FILENAME);
		ModelAndView mav = getDefaultMav(PageTemplate.PAGE_DOC_SRCH, MODULE, null, null, JS_FILENAME);

		//mav.addObject("doctor", doctor);
		mav.addObject(AppConstants.PORTAL_MODULE, url_path_string);
		//mav.addObject("refDocLst", getRefDocLst());
		return mav;
	}
	
	@GetMapping(value = "/paginated")
	public @ResponseBody String getDocList(@ModelAttribute("doctorProfile") DoctorProfile doctorProfile, BindingResult result, HttpServletRequest request) {
		
		LOGGER.info("getDocListPaginated....");
		//tvl.setEmbedTrip(true);
		DataTableResults<DoctorProfile> tasks = getBeService().profileService().searchDoctorPagination(doctorProfile, getPaginationRequest(request, true));
		return new Gson().toJson(tasks);
	}
	
	
	
	  @RequestMapping(value = "/addDr", method = RequestMethod.GET) public
	  ModelAndView index(@ModelAttribute("doctorProfile") DoctorProfile
	  doctorProfile, BindingResult result) throws Exception { String
	  url_path_string = "doc-add"; ModelAndView mav =
	  getDefaultMav(PageTemplate.PAGE_DOC_ADD, MODULE, null, null, JS_FILENAME);
	  
	  LOGGER.info("as1");
	  
	  mav.addObject(AppConstants.PORTAL_MODULE, url_path_string);
	  mav.addObject("addType", true); return mav; }
	 
	

	
	@PostMapping(value = "/addDr" , params = "submit")
	public ModelAndView create(@Valid @ModelAttribute("doctorProfile") DoctorProfile doctorProfile, BindingResult result,
			HttpServletRequest request, HttpSession session) throws BeException {

		ModelAndView mav = getDefaultMav(PageTemplate.PAGE_DOC_ADD, MODULE, null, null, JS_FILENAME);
		
			try {
				doctorProfile.getBeMcProfile().setMcProfId(getCurrentUser().getProfId());
				
				/*
				 * UserProfile up = getCurrentUser();
				 * doctorProfile.getBeMcProfile().setMcProfId(up .getProfId());
				 */
				
				doctorProfile = getBeService().profileService().registerDoctor(doctorProfile);
				LOGGER.info("payload--" + doctorProfile );
				if(doctorProfile.getDocProfId()!=null) {
					mav.addAllObjects(PopupBox.success("Register", null,
							"Record successfully created",
							PageConstants.PAGE_SEARCH_DOCTOR));
				}else {
					mav.addAllObjects(PopupBox.error("Register", null,
							"Record insersion failed"));
				}
			}catch(BeException beEx) {
				mav.addAllObjects(PopupBox.error("Register", null,
						"Exception occurred while inserting data"));
			}
		
		mav.addObject("doctorProfile", doctorProfile);
		//mav.addObject("refDocLst", getRefDocLst());
		return mav;
	}
	
	
	/*
	 * private DoctorProfile setDocProfileValues(DoctorProfile dp) { DoctorProfile
	 * doctorProfile = new DoctorProfile();
	 * doctorProfile.setDoctorId(dp.getDoctorId());
	 * doctorProfile.setFullName(dp.getFullName());
	 * doctorProfile.setIdentityNo(dp.getIdentityNo());
	 * doctorProfile.setGender(dp.getGender());
	 * doctorProfile.setDesignation(dp.getDesignation());
	 * doctorProfile.setDepartment(dp.getDepartment());
	 * doctorProfile.setDivision(dp.getDivision());
	 * doctorProfile.setEmail(dp.getEmail());
	 * doctorProfile.setContactNo(dp.getContactNo());
	 * doctorProfile.setFaxNo(dp.getFaxNo()); doctorProfile.setExt(dp.getExt());
	 * //doctorProfile.beMcProfile.getMcRegNo(dp.getBeMcProfile().getMcRegNo());
	 * doctorProfile.getBeMcProfile().getMcRegNo(dp.getBeMcProfile().getMcRegNo());
	 */
		

		/*
		 * List<TrxnDocuments> docList = new ArrayList<>(); TrxnDocuments doc1 = new
		 * TrxnDocuments(); if
		 * (!BaseUtil.isListNullZero(mc.getFileUploadsSupportingDoc1()) &&
		 * mc.getFileUploadsSupportingDoc1().size() == 1) { FileUpload fu =
		 * mc.getFileUploadsSupportingDoc1().get(0); doc1 = dozerMapper.map(fu,
		 * TrxnDocuments.class); doc1.setContent(fu.getFileData()); docList.add(doc1); }
		 * TrxnDocuments doc2 = new TrxnDocuments(); if
		 * (!BaseUtil.isListNullZero(mc.getFileUploadsSupportingDoc2()) &&
		 * mc.getFileUploadsSupportingDoc2().size() == 1) { FileUpload fu =
		 * mc.getFileUploadsSupportingDoc2().get(0); doc2 = dozerMapper.map(fu,
		 * TrxnDocuments.class); doc2.setContent(fu.getFileData()); docList.add(doc2); }
		 * TrxnDocuments doc3 = new TrxnDocuments(); if
		 * (!BaseUtil.isListNullZero(mc.getFileUploadsSupportingDoc3()) &&
		 * mc.getFileUploadsSupportingDoc3().size() == 1) { FileUpload fu =
		 * mc.getFileUploadsSupportingDoc3().get(0); doc3 = dozerMapper.map(fu,
		 * TrxnDocuments.class); doc3.setContent(fu.getFileData()); docList.add(doc3); }
		 * if(docList.size()>0) { doctorProfile.setTrxnDocuments(docList); }
		 */
		
	/*
	 * return doctorProfile; }
	 */
	
	
	/*
	 * @ModelAttribute("refDocLst") public List<RefDocuments> getRefDocLst() {
	 * return staticData.refDocList("SYSLOGO1"); }
	 */
	
	@ModelAttribute("appStatList")
	public List<Status> getAppStatusList() throws Exception {
		List<Status> statusList = staticData.findAllStatus();
		LOGGER.info("<<<<<< statLst size >>>>>>" + statusList.size());

		return statusList;
	}

}
