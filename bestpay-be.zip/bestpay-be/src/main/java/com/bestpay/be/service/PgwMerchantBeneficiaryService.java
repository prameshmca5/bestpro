package com.bestpay.be.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwMerchantBeneficiaryRepository;
import com.bestpay.be.model.PgwMerchantBeneficiary;
import com.bestpay.be.util.QualifierConstants;
 
@Transactional
@Service(QualifierConstants.PGW_MERCHANT_BENEFICIARY_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_BENEFICIARY_SVC)
public class PgwMerchantBeneficiaryService extends AbstractService<PgwMerchantBeneficiary> {

	@Autowired
	private PgwMerchantBeneficiaryRepository merchantBeneficiaryDao;


	@Override
	public PgwMerchantBeneficiaryRepository primaryDao() {
		return merchantBeneficiaryDao;
	}


	public PgwMerchantBeneficiary findByMerchantBenefId(String merchantId) {
		return merchantBeneficiaryDao.findByMerchantBenefId(merchantId);
	}
	
	public PgwMerchantBeneficiary findByMerchantBenefId(String merchantId,String mtoId) {
		 return merchantBeneficiaryDao.findByMerchantBenefIdMtoid(merchantId,mtoId);
	}
}
