/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;

/**
 * @author michelle.angela
 *
 */
public class ConfigMcCollate implements Serializable {

	private static final long serialVersionUID = -1630052236470942134L;

	private Integer mcCollateId;
	
	private String mcCollateCd;

	private String mcCollateDesc;
	
	private Boolean isActive;

	public Integer getMcCollateId() {
		return mcCollateId;
	}

	public void setMcCollateId(Integer mcCollateId) {
		this.mcCollateId = mcCollateId;
	}

	public String getMcCollateCd() {
		return mcCollateCd;
	}

	public void setMcCollateCd(String mcCollateCd) {
		this.mcCollateCd = mcCollateCd;
	}

	public String getMcCollateDesc() {
		return mcCollateDesc;
	}

	public void setMcCollateDesc(String mcCollateDesc) {
		this.mcCollateDesc = mcCollateDesc;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
}
