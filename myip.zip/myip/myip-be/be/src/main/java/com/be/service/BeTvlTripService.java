/**
 *
 */
package com.be.service;


import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTvlTripQf;
import com.be.dao.BeTvlTripRepository;
import com.be.model.BeTvl;
import com.be.model.BeTvlProfile;
import com.be.model.BeTvlTrip;
import com.be.model.RefStatus;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.FileUploadConstants;
import com.be.sdk.constants.MailTemplateConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Trip;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlProfile;
import com.idm.sdk.exception.IdmException;
import com.idm.sdk.model.Fcm;
import com.idm.sdk.model.FcmDevice;
import com.idm.sdk.model.UserProfile;
import com.notify.sdk.constants.MailTypeEnum;
import com.notify.sdk.model.Notification;
import com.notify.sdk.util.MailUtil;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.UidGenerator;
import com.util.pagination.DataTableRequest;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_TRIP_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_TRIP_SVC)
public class BeTvlTripService extends AbstractService<BeTvlTrip> {

	public static final String PREFIX_TRIP = "TRIP";

	@Autowired
	private BeTvlTripRepository beTvlTripDao;

	@Autowired
	BeTvlTripQf beTvlTripQf;

	@Autowired
	BeTvlTripHealthService beTvlTripHealthSvc;

	@Autowired
	BeTripAccommodationService beTripAccommodationSvc;

	@Autowired
	BeTrxnDocumentService beTrxnDocumentSvc;

	@Autowired
	BeTvlService beTvlSvc;

	@Autowired
	BeConfigService beConfigSvc;

	@Autowired
	BeTvlProfileService beTvlProfileSvc;


	@Override
	public GenericRepository<BeTvlTrip> primaryDao() {
		return beTvlTripDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beTvlTripQf.generateCriteria(cb, from, criteria);
	}


	@SuppressWarnings("unchecked")
	public List<Trip> searchTripPagination(Trip dto, DataTableRequest<?> dataTableInRQ) throws IOException {
		return JsonUtil.transferToList(beTvlTripQf.searchBeTvlTripPagination(dto, dataTableInRQ), Trip.class);
	}


	public BeTvlTrip searchBeTvlTrip(Trip dto) {
		return beTvlTripQf.searchBeTvlTrip(dto);
	}


	public long getCount(Trip dto) {
		return beTvlTripQf.getCount(dto);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { BeException.class,
			Exception.class })
	public List<Trip> addTripInfo(Trip dto, String userId, HttpServletRequest request) throws IOException {

		List<Trip> tripList = new ArrayList<>();

		UserProfile profile = getIdmService(request).getUserProfileById(userId, false, false);

		if (BaseUtil.isObjNull(profile)) {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}

		Integer count = 0;
		String tripCodeNo = null;
		String docRefNo = null;

		if (BaseUtil.isObjNull(dto.getTvlTripId())) {

			Trip tp = new Trip();
			tp.setAcctProfId(profile.getProfId());
			List<BeTvlTrip> tvlTripList = beTvlTripQf.searchByPropertyGroupByTvlTripCodeNo(tp);

			if (!BaseUtil.isListNull(tvlTripList)) {
				count = tvlTripList.size();
			}

			tripCodeNo = generateTripCode(profile.getCntryCd(), count);
			docRefNo = UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC);
		}

		for (Integer tvlProfId : dto.getTvlProfIdList()) {
			BeTvlTrip beTvlTrip = new BeTvlTrip();
			BeTvlTrip tvlTrip = new BeTvlTrip();

			BeTvlProfile beTvlProfile = beTvlProfileSvc.find(tvlProfId);
			if (BaseUtil.isObjNull(beTvlProfile)) {
				throw new BeException(BeErrorCodeEnum.I404C001);
			}

			if (BaseUtil.isObjNull(dto.getTvlTripId())) {
				beTvlTrip = JsonUtil.transferToObject(dto, BeTvlTrip.class);
				if (BaseUtil.isObjNull(beTvlTrip)) {
					throw new BeException(BeErrorCodeEnum.I404C001);
				}
				beTvlTrip.setTvlProfile(beTvlProfile);
				beTvlTrip.setTvlTripCodeNo(tripCodeNo);
				beTvlTrip.setDocRefNo(docRefNo);
				beTvlTrip.setCreateId(userId);
				beTvlTrip.setSubmitDt(getSQLTimestamp());
				beTvlTrip.setUpdateId(userId);
				beTvlTrip = update(beTvlTrip);
			} else {
				beTvlTrip = JsonUtil.transferToObject(dto, BeTvlTrip.class);
				if (BaseUtil.isObjNull(beTvlTrip)) {
					throw new BeException(BeErrorCodeEnum.I404C001);
				}
				tvlTrip = beTvlTripDao.findByTvlProfId(dto.getTvlProfId());
				tvlTrip.setTvlProfile(beTvlProfile);
				if (!BaseUtil.isObjNull(beTvlTrip.getTvlMode())) {
					tvlTrip.setTvlMode(beTvlTrip.getTvlMode());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getFlightNo())) {
					tvlTrip.setFlightNo(beTvlTrip.getFlightNo());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getAirlines())) {
					tvlTrip.setAirlines(beTvlTrip.getAirlines());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getDepartureAirport())) {
					tvlTrip.setDepartureAirport(beTvlTrip.getDepartureAirport());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getDepartureDt())) {
					tvlTrip.setDepartureDt(beTvlTrip.getDepartureDt());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getDepartureTime())) {
					tvlTrip.setDepartureTime(beTvlTrip.getDepartureTime());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getArrivalAirport())) {
					tvlTrip.setArrivalAirport(beTvlTrip.getArrivalAirport());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getArrivalDt())) {
					tvlTrip.setArrivalDt(beTvlTrip.getArrivalDt());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getArrivalTime())) {
					tvlTrip.setArrivalTime(beTvlTrip.getArrivalTime());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getTvlPurpose())) {
					tvlTrip.setTvlPurpose(beTvlTrip.getTvlPurpose());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getStayDuration())) {
					tvlTrip.setStayDuration(beTvlTrip.getStayDuration());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getStayAddress())) {
					tvlTrip.setStayAddress(beTvlTrip.getStayAddress());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getSubmitDt())) {
					tvlTrip.setSubmitDt(beTvlTrip.getSubmitDt());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getTripPlanMtdt())) {
					tvlTrip.setTripPlanMtdt(beTvlTrip.getTripPlanMtdt());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getTvlModeRtn())) {
					tvlTrip.setTvlModeRtn(beTvlTrip.getTvlModeRtn());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getFlightNoRtn())) {
					tvlTrip.setFlightNoRtn(beTvlTrip.getFlightNoRtn());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getAirlinesRtn())) {
					tvlTrip.setAirlinesRtn(beTvlTrip.getAirlinesRtn());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getDepartureAirportRtn())) {
					tvlTrip.setDepartureAirportRtn(beTvlTrip.getDepartureAirportRtn());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getDepartureDtRtn())) {
					tvlTrip.setDepartureDtRtn(beTvlTrip.getDepartureDtRtn());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getDepartureTimeRtn())) {
					tvlTrip.setDepartureTimeRtn(beTvlTrip.getDepartureTimeRtn());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getArrivalAirportRtn())) {
					tvlTrip.setArrivalAirportRtn(beTvlTrip.getArrivalAirportRtn());
				}
				if (!BaseUtil.isObjNull(beTvlTrip.getDocRefNo())) {
					tvlTrip.setDocRefNo(beTvlTrip.getDocRefNo());
				}

				if (!BaseUtil.isObjNull(beTvlTrip.getAppsMtdt())) {
					tvlTrip.setAppsMtdt(beTvlTrip.getAppsMtdt());
				}

				tvlTrip.setUpdateId(userId);
				tvlTrip = update(tvlTrip);
				beTvlTrip = JsonUtil.transferToObject(tvlTrip, BeTvlTrip.class);

			}

			if (!BaseUtil.isObjNull(dto.getTripAccommodations())) {
				beTripAccommodationSvc.createUpdate(dto.getTripAccommodations().get(0), beTvlTrip, userId);
			}

			if (!BaseUtil.isListNull(dto.getTripHealths())) {
				beTvlTripHealthSvc.createUpdate(dto.getTripHealths(), beTvlTrip, userId);
			}

			if (!BaseUtil.isListNull(dto.getTrxnDocumentList())) {
				beTrxnDocumentSvc.createUpdate(dto.getTrxnDocumentList(), userId, beTvlTrip.getDocRefNo());
			}

			Tvl tvl = new Tvl();
			tvl.setTvlProfile(new TvlProfile());
			tvl.getTvlProfile().setTvlProfId(tvlProfId);
			tvl.setEmbedAcctProfile(true);
			tvl.setEmbedPayment(true);
			BeTvl beTvl = beTvlSvc.searchBeTravel(tvl);
			beTvl.setTvlTrip(beTvlTrip);
			beTvl.setTvlStats(null);
			beTvl.setStatus(new RefStatus());
			beTvl.getStatus().setStatusId(dto.getStatusId());
			beTvlSvc.update(beTvl);

			Trip newTrip = JsonUtil.transferToObject(beTvlTrip, Trip.class);

			// add fcm notification
			sendingNotification(newTrip, beTvlProfile, request);

			tripList.add(newTrip);
		}

		return tripList;
	}


	private String generateTripCode(String cntryCd, Integer count) {

		String length = beConfigSvc.findByConfigCode("ID_LENGTH").getConfigVal();
		return generateRandomRefNo(Integer.parseInt(length), "TC", cntryCd, count);
	}


	private List<FcmDevice> searchAllDevice(UserProfile userProfile, HttpServletRequest request) throws IdmException {
		FcmDevice fcmDevice = new FcmDevice();
		fcmDevice.setStatus(true);

		Fcm fcm = new Fcm();
		fcm.setUserId(userProfile.getUserId());
		fcm.setStatus(true);
		fcmDevice.setFcm(fcm);

		return getIdmService(request).searchFcmDevice(fcmDevice);
	}


	private void addFCMNotification(List<FcmDevice> devices, UserProfile userProfile, Map<String, Object> map,
			String template, HttpServletRequest request) {
		if (!BaseUtil.isObjNull(userProfile)) {
			if (!BaseUtil.isListNull(devices)) {
				for (FcmDevice device : devices) {
					if (!BaseUtil.isObjNull(device.getFcmToken())) {

						Notification notification = new Notification();
						notification.setNotifyTo(userProfile.getUserId());
						notification.setNotifyCc(device.getFcmToken());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setNotifyType(MailTypeEnum.FCM.getType());

						getNotifyService(request).addNotification(notification, template);
					}
				}
			}

		}
	}


	private void sendingNotification(Trip trip, BeTvlProfile beTvlProfile, HttpServletRequest request) {
		try {

			// any error here will be consume by void
			String templateFcm = MailTemplateConstants.FCM_TRAVEL_TRIP_SUBMITTED;

			Tvl tvlDto = new Tvl();
			tvlDto.setTvlProfile(new TvlProfile());
			tvlDto.getTvlProfile().setTvlProfId(trip.getTvlProfile().getTvlProfId());
			tvlDto.setEmbedTraveller(true);
			BeTvl beTvl = beTvlSvc.searchBeTravel(tvlDto);
			Integer profId = beTvl.getAcctProfile().getAcctProfId();
			// Integer profId =
			// beTvlProfile.getAcctTraveller().getAcctProfile().getAcctProfId();
			// UserProfile profile =
			// getIdmService(request).getUserProfileByProfId(profId, false,
			// false);
			String userType = "TVL";
			// UserProfile profile =
			// getIdmService(request).getUserProfileByProfId(profId, false,
			// false);
			UserProfile profile = getIdmService(request).getUserProfileByProfIdUserType(profId, userType, false,
					false);

			Map<String, Object> datamap = new LinkedHashMap<>();
			datamap.put("tripCodeNo", trip.getTvlTripCodeNo());
			datamap.put("noOfTraveller", trip.getTvls() != null ? trip.getTvls().size() : 1);
			List<FcmDevice> devices = searchAllDevice(profile, request);
			addFCMNotification(devices, profile, datamap, templateFcm, request);
		} catch (Exception e) {
			// safety reason : ignore and check if
			// payload created
		}
	}
}
