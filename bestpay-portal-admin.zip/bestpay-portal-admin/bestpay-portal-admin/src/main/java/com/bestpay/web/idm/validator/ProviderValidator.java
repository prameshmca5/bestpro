package com.bestpay.web.idm.validator;


import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.be.sdk.model.Provider;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ValidationUtil;


@Component("providerValidator")
public class ProviderValidator extends AbstractController implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}


	@Override
	public void validate(Object object, Errors errors) {
		if (object instanceof Provider) {

			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "providerPublicName",
					MessageConstants.ERROR_FIELDS_PROVIDER_ID);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "providerName", MessageConstants.ERROR_NAME_REQUIRED);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "country", MessageConstants.ERROR_FIELDS_COUNTRY);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "address1", MessageConstants.ERROR_FIELDS_ADDRESS);
			Object countryValue = errors.getFieldValue("country");
			if ((!BaseUtil.isObjNull(countryValue) && BaseUtil.isEqualsCaseIgnore(countryValue.toString(), "MYS"))) {
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "stateMy", MessageConstants.ERROR_FIELDS_STATE);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "cityMy", MessageConstants.ERROR_FIELDS_CITY);
			} else {
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "stateNonMy", MessageConstants.ERROR_FIELDS_STATE);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "cityNonMy", MessageConstants.ERROR_FIELDS_CITY);
			}
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "postcode", MessageConstants.ERROR_FIELD_POSTCODE);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "email", MessageConstants.ERROR_APPLCNT_EML);
			ValidationUtil.rejectIfInvalidEmailFormat(errors, "email", MessageConstants.ERROR_EMAIL_FORMAT);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "phone", MessageConstants.ERROR_PHONE_REQUIRED);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "ssmId", MessageConstants.ERROR_FIELDS_SSM_ID);

		}

	}

}
