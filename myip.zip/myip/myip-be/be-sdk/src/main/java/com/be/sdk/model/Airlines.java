/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.util.model.FileUpload;


@JsonIgnoreProperties(ignoreUnknown = true)
public class Airlines implements Serializable {

	private static final long serialVersionUID = -6255425222614429634L;

	private Integer airlinesProfId;
	
	private String type;

	private String flightCoverageType;

	private String iataRegistrationNo;

	private String icaoRegistrationNo;

	private String name;

	private String callsign;

	private String telCntryCode;

	private String telephoneNo;

	private String telCntryCodeOptional;

	private String telephoneNoOptional;
	
	private String faxCntryCode;

	private String faxNo;

	private String email;

	private String emailOptional;

	private String website;

	private String yearOfCommencedOperations;
	
	private Integer correspondanceAddressId;
	
	private String correspondanceAddress1;
	
	private String correspondanceAddress2;
	
	private String correspondanceAddress3;
	
	private String correspondanceAddress4;
	
	private String correspondanceAddress5;
	
	private String country;
	
	private String state;
	
	private String city;
	
	private String postalCode;
	
	private Integer headQuartersAddressId;
	
	private String headQuartersAddress1;

	private String headQuartersAddress2;
	
	private String headQuartersAddress3;
	
	private String headQuartersAddress4;
	
	private String headQuartersAddress5;
	
	private String countryHeadquarters;
	
	private String stateHeadquarters;
	
	private String cityHeadquarters;
	
	private String postalCodeHeadquarters;
	
	private Integer airlinesContactId;
	
	private String contactTitle;
	
	private String contactName;
	
	private String contactEmail;
	
	private String contactCountryCode;
	
	private String contactNo;
	
	private Integer airlinesPicId;
	
	private String picTitle;
	
	private String picName;
	
	private String picEmail;
	
	private String picContactNoCountryCode;
	
	private String picContactNo;
	
	private String picDesignation;
	
	private String supportingDoc1;
	
	private String supportingDoc2;
	
	private String supportingDoc3;
	
	private String supportingDoc4;
	
	private String supportingDoc5;
	
	private List<FileUpload> fileUploadsSupportingDoc1;
	
	private String docMgtIdSupportingDoc1;
	
	private List<FileUpload> fileUploadsSupportingDoc2;
	
	private String docMgtIdSupportingDoc2;
	
	private List<FileUpload> fileUploadsSupportingDoc3;
	
	private String docMgtIdSupportingDoc3;
	
	private List<FileUpload> fileUploadsSupportingDoc4;
	
	private String docMgtIdSupportingDoc4;
	
	private List<FileUpload> fileUploadsSupportingDoc5;
	
	private String docMgtIdSupportingDoc5;
	
	private Double latitude;

	private Double longitude;

	public Airlines() {
	}

	public Integer getAirlinesProfId() {
		return airlinesProfId;
	}

	public void setAirlinesProfId(Integer airlinesProfId) {
		this.airlinesProfId = airlinesProfId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getFlightCoverageType() {
		return flightCoverageType;
	}

	public void setFlightCoverageType(String flightCoverageType) {
		this.flightCoverageType = flightCoverageType;
	}

	public String getIataRegistrationNo() {
		return iataRegistrationNo;
	}

	public void setIataRegistrationNo(String iataRegistrationNo) {
		this.iataRegistrationNo = iataRegistrationNo;
	}

	public String getIcaoRegistrationNo() {
		return icaoRegistrationNo;
	}

	public void setIcaoRegistrationNo(String icaoRegistrationNo) {
		this.icaoRegistrationNo = icaoRegistrationNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name.toUpperCase();
	}

	public String getCallsign() {
		return callsign;
	}

	public void setCallsign(String callsign) {
		this.callsign = callsign.toUpperCase();
	}

	public String getTelCntryCode() {
		return telCntryCode;
	}

	public void setTelCntryCode(String telCntryCode) {
		this.telCntryCode = telCntryCode;
	}

	public String getTelephoneNo() {
		return telephoneNo;
	}

	public void setTelephoneNo(String telephoneNo) {
		this.telephoneNo = telephoneNo;
	}

	public String getTelCntryCodeOptional() {
		return telCntryCodeOptional;
	}

	public void setTelCntryCodeOptional(String telCntryCodeOptional) {
		this.telCntryCodeOptional = telCntryCodeOptional;
	}

	public String getTelephoneNoOptional() {
		return telephoneNoOptional;
	}

	public void setTelephoneNoOptional(String telephoneNoOptional) {
		this.telephoneNoOptional = telephoneNoOptional;
	}

	public String getFaxCntryCode() {
		return faxCntryCode;
	}

	public void setFaxCntryCode(String faxCntryCode) {
		this.faxCntryCode = faxCntryCode;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmailOptional() {
		return emailOptional;
	}

	public void setEmailOptional(String emailOptional) {
		this.emailOptional = emailOptional;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getYearOfCommencedOperations() {
		return yearOfCommencedOperations;
	}

	public void setYearOfCommencedOperations(String yearOfCommencedOperations) {
		this.yearOfCommencedOperations = yearOfCommencedOperations;
	}

	public String getCorrespondanceAddress1() {
		return correspondanceAddress1;
	}

	public void setCorrespondanceAddress1(String correspondanceAddress1) {
		this.correspondanceAddress1 = correspondanceAddress1.toUpperCase();
	}

	public String getCorrespondanceAddress2() {
		return correspondanceAddress2;
	}

	public void setCorrespondanceAddress2(String correspondanceAddress2) {
		this.correspondanceAddress2 = correspondanceAddress2.toUpperCase();
	}

	public String getCorrespondanceAddress3() {
		return correspondanceAddress3;
	}

	public void setCorrespondanceAddress3(String correspondanceAddress3) {
		this.correspondanceAddress3 = correspondanceAddress3;
	}

	public String getCorrespondanceAddress4() {
		return correspondanceAddress4;
	}

	public void setCorrespondanceAddress4(String correspondanceAddress4) {
		this.correspondanceAddress4 = correspondanceAddress4;
	}

	public String getCorrespondanceAddress5() {
		return correspondanceAddress5;
	}

	public void setCorrespondanceAddress5(String correspondanceAddress5) {
		this.correspondanceAddress5 = correspondanceAddress5;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state.toUpperCase();
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getHeadQuartersAddress1() {
		return headQuartersAddress1;
	}

	public void setHeadQuartersAddress1(String headQuartersAddress1) {
		this.headQuartersAddress1 = headQuartersAddress1.toUpperCase();
	}

	public String getHeadQuartersAddress2() {
		return headQuartersAddress2;
	}

	public void setHeadQuartersAddress2(String headQuartersAddress2) {
		this.headQuartersAddress2 = headQuartersAddress2.toUpperCase();
	}

	public String getHeadQuartersAddress3() {
		return headQuartersAddress3;
	}

	public void setHeadQuartersAddress3(String headQuartersAddress3) {
		this.headQuartersAddress3 = headQuartersAddress3;
	}

	public String getHeadQuartersAddress4() {
		return headQuartersAddress4;
	}

	public void setHeadQuartersAddress4(String headQuartersAddress4) {
		this.headQuartersAddress4 = headQuartersAddress4;
	}

	public String getHeadQuartersAddress5() {
		return headQuartersAddress5;
	}

	public void setHeadQuartersAddress5(String headQuartersAddress5) {
		this.headQuartersAddress5 = headQuartersAddress5;
	}

	public String getCountryHeadquarters() {
		return countryHeadquarters;
	}

	public void setCountryHeadquarters(String countryHeadquarters) {
		this.countryHeadquarters = countryHeadquarters;
	}

	public String getStateHeadquarters() {
		return stateHeadquarters;
	}

	public void setStateHeadquarters(String stateHeadquarters) {
		this.stateHeadquarters = stateHeadquarters.toUpperCase();
	}

	public String getPostalCodeHeadquarters() {
		return postalCodeHeadquarters;
	}

	public void setPostalCodeHeadquarters(String postalCodeHeadquarters) {
		this.postalCodeHeadquarters = postalCodeHeadquarters;
	}

	public String getContactTitle() {
		return contactTitle;
	}

	public void setContactTitle(String contactTitle) {
		this.contactTitle = contactTitle;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName.toUpperCase();
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactCountryCode() {
		return contactCountryCode;
	}

	public void setContactCountryCode(String contactCountryCode) {
		this.contactCountryCode = contactCountryCode;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getPicTitle() {
		return picTitle;
	}

	public void setPicTitle(String picTitle) {
		this.picTitle = picTitle;
	}

	public String getPicName() {
		return picName;
	}

	public void setPicName(String picName) {
		this.picName = picName.toUpperCase();
	}

	public String getPicEmail() {
		return picEmail;
	}

	public void setPicEmail(String picEmail) {
		this.picEmail = picEmail;
	}

	public String getPicContactNoCountryCode() {
		return picContactNoCountryCode;
	}

	public void setPicContactNoCountryCode(String picContactNoCountryCode) {
		this.picContactNoCountryCode = picContactNoCountryCode;
	}

	public String getPicContactNo() {
		return picContactNo;
	}

	public void setPicContactNo(String picContactNo) {
		this.picContactNo = picContactNo;
	}

	public String getPicDesignation() {
		return picDesignation;
	}

	public void setPicDesignation(String picDesignation) {
		this.picDesignation = picDesignation.toUpperCase();
	}

	public String getSupportingDoc1() {
		return supportingDoc1;
	}

	public void setSupportingDoc1(String supportingDoc1) {
		this.supportingDoc1 = supportingDoc1;
	}

	public String getSupportingDoc2() {
		return supportingDoc2;
	}

	public void setSupportingDoc2(String supportingDoc2) {
		this.supportingDoc2 = supportingDoc2;
	}

	public String getSupportingDoc3() {
		return supportingDoc3;
	}

	public void setSupportingDoc3(String supportingDoc3) {
		this.supportingDoc3 = supportingDoc3;
	}

	public String getSupportingDoc4() {
		return supportingDoc4;
	}

	public void setSupportingDoc4(String supportingDoc4) {
		this.supportingDoc4 = supportingDoc4;
	}

	public String getSupportingDoc5() {
		return supportingDoc5;
	}

	public void setSupportingDoc5(String supportingDoc5) {
		this.supportingDoc5 = supportingDoc5;
	}

	public List<FileUpload> getFileUploadsSupportingDoc1() {
		return fileUploadsSupportingDoc1;
	}

	public void setFileUploadsSupportingDoc1(List<FileUpload> fileUploadsSupportingDoc1) {
		this.fileUploadsSupportingDoc1 = fileUploadsSupportingDoc1;
	}

	public String getDocMgtIdSupportingDoc1() {
		return docMgtIdSupportingDoc1;
	}

	public void setDocMgtIdSupportingDoc1(String docMgtIdSupportingDoc1) {
		this.docMgtIdSupportingDoc1 = docMgtIdSupportingDoc1;
	}

	public List<FileUpload> getFileUploadsSupportingDoc2() {
		return fileUploadsSupportingDoc2;
	}

	public void setFileUploadsSupportingDoc2(List<FileUpload> fileUploadsSupportingDoc2) {
		this.fileUploadsSupportingDoc2 = fileUploadsSupportingDoc2;
	}

	public String getDocMgtIdSupportingDoc2() {
		return docMgtIdSupportingDoc2;
	}

	public void setDocMgtIdSupportingDoc2(String docMgtIdSupportingDoc2) {
		this.docMgtIdSupportingDoc2 = docMgtIdSupportingDoc2;
	}

	public List<FileUpload> getFileUploadsSupportingDoc3() {
		return fileUploadsSupportingDoc3;
	}

	public void setFileUploadsSupportingDoc3(List<FileUpload> fileUploadsSupportingDoc3) {
		this.fileUploadsSupportingDoc3 = fileUploadsSupportingDoc3;
	}

	public String getDocMgtIdSupportingDoc3() {
		return docMgtIdSupportingDoc3;
	}

	public void setDocMgtIdSupportingDoc3(String docMgtIdSupportingDoc3) {
		this.docMgtIdSupportingDoc3 = docMgtIdSupportingDoc3;
	}

	public List<FileUpload> getFileUploadsSupportingDoc4() {
		return fileUploadsSupportingDoc4;
	}

	public void setFileUploadsSupportingDoc4(List<FileUpload> fileUploadsSupportingDoc4) {
		this.fileUploadsSupportingDoc4 = fileUploadsSupportingDoc4;
	}

	public String getDocMgtIdSupportingDoc4() {
		return docMgtIdSupportingDoc4;
	}

	public void setDocMgtIdSupportingDoc4(String docMgtIdSupportingDoc4) {
		this.docMgtIdSupportingDoc4 = docMgtIdSupportingDoc4;
	}

	public List<FileUpload> getFileUploadsSupportingDoc5() {
		return fileUploadsSupportingDoc5;
	}

	public void setFileUploadsSupportingDoc5(List<FileUpload> fileUploadsSupportingDoc5) {
		this.fileUploadsSupportingDoc5 = fileUploadsSupportingDoc5;
	}

	public String getDocMgtIdSupportingDoc5() {
		return docMgtIdSupportingDoc5;
	}

	public void setDocMgtIdSupportingDoc5(String docMgtIdSupportingDoc5) {
		this.docMgtIdSupportingDoc5 = docMgtIdSupportingDoc5;
	}

	public Integer getAirlinesPicId() {
		return airlinesPicId;
	}

	public void setAirlinesPicId(Integer airlinesPicId) {
		this.airlinesPicId = airlinesPicId;
	}

	public String getCityHeadquarters() {
		return cityHeadquarters;
	}

	public void setCityHeadquarters(String cityHeadquarters) {
		this.cityHeadquarters = cityHeadquarters.toUpperCase();
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city.toUpperCase();
	}

	public Integer getCorrespondanceAddressId() {
		return correspondanceAddressId;
	}

	public void setCorrespondanceAddressId(Integer correspondanceAddressId) {
		this.correspondanceAddressId = correspondanceAddressId;
	}

	public Integer getHeadQuartersAddressId() {
		return headQuartersAddressId;
	}

	public void setHeadQuartersAddressId(Integer headQuartersAddressId) {
		this.headQuartersAddressId = headQuartersAddressId;
	}

	public Integer getAirlinesContactId() {
		return airlinesContactId;
	}

	public void setAirlinesContactId(Integer airlinesContactId) {
		this.airlinesContactId = airlinesContactId;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	
}