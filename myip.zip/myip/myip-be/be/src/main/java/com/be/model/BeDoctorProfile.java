/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;


/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_DOCTOR_PROFILE")
public class BeDoctorProfile extends AbstractEntity implements Serializable, IQfCriteria<BeDoctorProfile> {

	private static final long serialVersionUID = 3416438226834103018L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DOCTOR_PROF_ID")
	private Integer docProfId;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MC_PROF_ID")
	private BeMcProfile beMcProfile;

	@Column(name = "DOCTOR_ID")
	private String doctorId;

	@Column(name = "FULL_NAME")
	private String fullName;

	@Column(name = "IDENTITY_NO")
	private String identityNo;

	@Column(name = "MED_CERT_NO")
	private String medCertNo;

	@Column(name = "GENDER")
	private String gender;

	@Column(name = "DESIGNATION")
	private String designation;

	@Column(name = "DEPARTMENT")
	private String department;

	@Column(name = "DIVISION")
	private String division;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "CONTACT_NO")
	private String contactNo;

	@Column(name = "FAX_NO")
	private String faxNo;

	@Column(name = "EXT")
	private String ext;

	@Column(name = "DOC_REF_NO")
	private String docRefNo;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "STATUS")
	private Boolean isActive;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getDocProfId() {
		return docProfId;
	}


	public void setDocProfId(Integer docProfId) {
		this.docProfId = docProfId;
	}


	public BeMcProfile getBeMcProfile() {
		return beMcProfile;
	}


	public void setBeMcProfile(BeMcProfile beMcProfile) {
		this.beMcProfile = beMcProfile;
	}


	public String getDoctorId() {
		return doctorId;
	}


	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getIdentityNo() {
		return identityNo;
	}


	public void setIdentityNo(String identityNo) {
		this.identityNo = identityNo;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getDesignation() {
		return designation;
	}


	public void setDesignation(String designation) {
		this.designation = designation;
	}


	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department;
	}


	public String getDivision() {
		return division;
	}


	public void setDivision(String division) {
		this.division = division;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public String getFaxNo() {
		return faxNo;
	}


	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}


	public String getExt() {
		return ext;
	}


	public void setExt(String ext) {
		this.ext = ext;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public Boolean getIsActive() {
		return isActive;
	}


	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getMedCertNo() {
		return medCertNo;
	}


	public void setMedCertNo(String medCertNo) {
		this.medCertNo = medCertNo;
	}
}
