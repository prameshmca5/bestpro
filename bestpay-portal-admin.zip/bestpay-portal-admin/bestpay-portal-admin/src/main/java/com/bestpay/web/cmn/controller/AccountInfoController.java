/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;


import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.constants.FileUploadConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.ApsProfile;
import com.bestpay.be.sdk.model.ApsProfileResponse;
import com.bestpay.be.sdk.model.Category;
import com.bestpay.be.sdk.model.IRProfile;
import com.bestpay.be.sdk.model.IRProfileResponse;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.model.MerAccSet;
import com.bestpay.be.sdk.model.MerBusCat;
import com.bestpay.be.sdk.model.MerChanSetWrapper;
import com.bestpay.be.sdk.model.MerCompany;
import com.bestpay.be.sdk.model.MerFraudSet;
import com.bestpay.be.sdk.model.MerGenInfo;
import com.bestpay.be.sdk.model.MerPayPageSet;
import com.bestpay.be.sdk.model.MerRepSet;
import com.bestpay.be.sdk.model.MerRestriction;
import com.bestpay.be.sdk.model.MerSendAccInfo;
import com.bestpay.be.sdk.model.MerSettlementSet;
import com.bestpay.be.sdk.model.MerSubscriptionPlan;
import com.bestpay.be.sdk.model.MerchantPid;
import com.bestpay.be.sdk.model.RefDocuments;
import com.bestpay.be.sdk.model.ReferralMultiChannel;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.dm.sdk.exception.DmException;
import com.bestpay.dm.sdk.model.Documents;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.web.constants.AppConstants;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.constants.ProjectEnum;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.dto.CustomMultipartFile;
import com.bestpay.web.dto.FileUpload;
import com.bestpay.web.form.MerchantLogoPaymentSettingForm;
import com.bestpay.web.util.WebUtil;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.DateUtil;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_ACC_INFO)
public class AccountInfoController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AccountInfoController.class);

	private static final String ACTSTAT = "ACTSTAT";

	private static final String MALAYSIA = "MALAYSIA";

	private static final String SUBPLAN = "SUBPLAN";

	private static final String MERCHANTID = "merchantId";

	private static final String STATUS_ACC_LIST = "statusAccList";

	private static final String STATUS_LIST = "statusList";

	private static final String ACCOUNT_INFO = "accountInfo";

	private static final String BUS_CATEGORY = "busCategory";

	private static final String MER_ACC_INFO = "merAccInfo";

	private static final String MER_BUS_CAT = "merBusCat";

	private static final String MER_MGMT = "mer_mgmt";

	@Autowired
	@Qualifier("accountInfoValidator")
	private Validator accInfoValidator;

	@Autowired
	@Qualifier("payPageSettingValidator")
	private Validator payPgSetValidator;

	@Autowired
	@Qualifier("generalInfoValidator")
	private Validator genInfoValidator;

	@Autowired
	@Qualifier("fraudSettingValidator")
	private Validator fraudSettingValidator;

	@Autowired
	@Qualifier("accountSettingValidator")
	private Validator accountSettingValidator;

	@Autowired
	@Qualifier("businessCategoryValidator")
	private Validator businessCategoryValidator;

	@Autowired
	@Qualifier("settlementSettingValidator")
	private Validator settlementSettingValidator;

	@Autowired
	@Qualifier("merChanSetWrapperValidator")
	private Validator merChanSetWrapperValidator;

	@Autowired
	@Qualifier("sendAcctInfoValidator")
	private Validator sendAcctInfoWrapperValidator;


	@InitBinder(MER_ACC_INFO)
	protected void merAccInfoBindingPreparation(WebDataBinder binder) {
		binder.setValidator(accInfoValidator);
		super.bindingPreparation(binder);
	}


	@InitBinder("merPayPageSet")
	protected void payPageSettingBindingPreparation(WebDataBinder binder) {
		binder.setValidator(payPgSetValidator);
		super.bindingPreparation(binder);
	}


	@InitBinder("merGenInfo")
	protected void merGenInfoBindingPreparation(WebDataBinder binder) {
		binder.setValidator(genInfoValidator);
		super.bindingPreparation(binder);
	}


	@InitBinder("merFraudSet")
	protected void merFraudSetBindingPreparation(WebDataBinder binder) {
		binder.setValidator(fraudSettingValidator);
		super.bindingPreparation(binder);
	}


	@InitBinder(MER_BUS_CAT)
	protected void merBusCatBindingPreparation(WebDataBinder binder) {
		binder.setValidator(businessCategoryValidator);
		super.bindingPreparation(binder);
	}


	@InitBinder("merSettlementSet")
	protected void merSettlementSetBindingPreparation(WebDataBinder binder) {
		binder.setValidator(settlementSettingValidator);
		super.bindingPreparation(binder);
	}


	@InitBinder("merSendAccInfo")
	protected void sendAcctInfoBindingPreparation(WebDataBinder binder) {
		binder.setValidator(sendAcctInfoWrapperValidator);
		// binder.setValidator(accInfoValidator);
		super.bindingPreparation(binder);
	}


	@GetMapping
	public ModelAndView accountInfo(MerAccInfo merAccInfo, HttpSession session) throws BeException {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_ACC_INFO);
		mav.addObject(STATUS_LIST, staticData.statusList());
		return mav;
	}


	@InitBinder("merAccSet")
	protected void merAccSetBindingPreparation(WebDataBinder binder) {
		binder.setValidator(accountSettingValidator);
		super.bindingPreparation(binder);
	}


	@InitBinder("merChanSetWrapper")
	protected void merChan(WebDataBinder binder) {
		binder.setValidator(merChanSetWrapperValidator);
		super.bindingPreparation(binder);
	}


	@PostMapping(value = "/{merchantId}", params = "create")
	public ModelAndView create(@PathVariable String merchantId,
			@Valid @ModelAttribute(MER_ACC_INFO) MerAccInfo merAccInfo, BindingResult result) throws BeException {
		ModelAndView mav = new ModelAndView();
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.acc.info.crt"));
		UserProfile authUser = getCurrentUser();
		MerAccInfo accInfo = new MerAccInfo();
		UserProfile createUserProfile = new UserProfile();
		// Check OwnernationalID
		List<MerAccInfo> ownerId = getBeService().getOwenerNationalId(merAccInfo);
		int ownerIdSize = ownerId.size();
		if (ownerIdSize > 0) {
			mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, ACCOUNT_INFO);
			mav.addObject(MER_ACC_INFO, merAccInfo);
			mav.addObject(MERCHANTID, merchantId);
			mav.addObject(STATUS_LIST, staticData.status(SUBPLAN));
			mav.addObject(STATUS_ACC_LIST, staticData.status(ACTSTAT));
			mav.addAllObjects(com.bstsb.util.PopupBox.error("createdError", null,
					messageService.getMessage(MessageConstants.ERROR_FIELDS_COMPANY_OWNERID_EXISTS)));
		} else {
			MerSubscriptionPlan createMerSubPlan = new MerSubscriptionPlan();
			boolean isCreated = false;
			if (!result.hasErrors()) {
				merAccInfo.setUserId(authUser.getUserId());

				accInfo = getBeService().createMerAccInfo(merAccInfo);

				createUserProfile.setFullName(accInfo.getCompany());
				createUserProfile.setEmail(accInfo.getEmail());
				createUserProfile.setProfId(accInfo.getMerProfId());
				createUserProfile.setUserType("MER");
				createUserProfile.setUserRoleGroupCode("MER_ADMIN");
				getIdmService().createMerchantUser(createUserProfile, "true");

				if (!BaseUtil.isObjNull(accInfo.getSubscriptionPlan())) {
					createMerSubPlan.setMerchantId(accInfo.getMerchantId());
					createMerSubPlan.setSubPlanId(Integer.valueOf(accInfo.getSubscriptionPlan()));
					createMerSubPlan.setExpiryDate(accInfo.getExpireDate());
					createMerSubPlan.setUserId(authUser.getUserId());
					getBeService().createMerSubPlan(createMerSubPlan);
				}

				isCreated = true;
			}
			if (isCreated) {
				mav = updatedInfo(accInfo.getMerchantId(), PageTemplate.TEMP_MER_CRED, MER_MGMT, ACCOUNT_INFO);
				mav.addObject(MERCHANTID, accInfo.getMerchantId());
				mav.addAllObjects(com.bstsb.util.PopupBox.success("usrCreate", null,
						messageService.getMessage(MessageConstants.SUCC_CRE_ACC_INFO)));
			} else {
				mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, ACCOUNT_INFO);
				mav.addObject(MER_ACC_INFO, merAccInfo);
				mav.addObject(MERCHANTID, merchantId);
				mav.addObject(STATUS_LIST, staticData.status(SUBPLAN));
				mav.addObject(STATUS_ACC_LIST, staticData.status(ACTSTAT));
			}
		}
		return mav;
	}


	@PostMapping(value = "/{merchantId}", params = "reset")
	public ModelAndView reset(@RequestParam String reset, @PathVariable String merchantId,
			@ModelAttribute(MER_ACC_INFO) MerAccInfo merAccInfo, MerGenInfo merGenInfo, MerFraudSet merFraudSet,
			MerAccSet merAccSet, MerBusCat merBusCat, MerchantLogoPaymentSettingForm merPayPageSet,
			MerRepSet merRepSet, MerRestriction merRestriction, MerSettlementSet merSettlementSet,
			MerSendAccInfo merSendAccInfo, MerChanSetWrapper merChanSetWrapper, MerchantPid merchantPid,
			BindingResult result, HttpSession session) throws BeException {
		return viewMerchant(merchantId, merAccInfo, merGenInfo, merFraudSet, merAccSet, merBusCat, merPayPageSet,
				merRepSet, merRestriction, merSettlementSet, merSendAccInfo, merChanSetWrapper, merchantPid,
				result);
	}


	@GetMapping(value = "/{merchantId}")
	public ModelAndView viewMerchant(@PathVariable String merchantId,
			@ModelAttribute(MER_ACC_INFO) MerAccInfo merAccInfo, MerGenInfo merGenInfo, MerFraudSet merFraudSet,
			MerAccSet merAccSet, MerBusCat merBusCat, MerchantLogoPaymentSettingForm merPayPageSet,
			MerRepSet merRepSet, MerRestriction merRestriction, MerSettlementSet merSettlementSet,
			MerSendAccInfo merSendAccInfo, MerChanSetWrapper merChanSetWrapper, MerchantPid merchantPid,
			BindingResult result) throws BeException {

		return updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, ACCOUNT_INFO);
	}


	@PostMapping(value = "/{merchantId}", params = "update=updateAccInfo")
	public ModelAndView update(@PathVariable String merchantId,
			@Valid @ModelAttribute(MER_ACC_INFO) MerAccInfo merAccInfo, BindingResult result) throws BeException {
		new MerAccInfo();
		UserProfile userProfile = getIdmService().getUserprofileByMerchantProfileId(merAccInfo.getMerProfId());
		MerSubscriptionPlan updateMerSubPlan = getBeService().getMerSubPlanById(merchantId);
		if (!result.hasErrors()) {
			UserProfile authUser = getCurrentUser();
			merAccInfo.setUserId(authUser.getUserId());
			merAccInfo.setOldMerchantId(merchantId);
			getBeService().updateMerAccInfo(merAccInfo);
			if (!BaseUtil.isObjNull(merAccInfo) && !BaseUtil.isObjNull(userProfile)) {
				userProfile.setFullName(merAccInfo.getSalesPic());
				userProfile.setEmail(merAccInfo.getEmail());
				getIdmService().updateProfile(userProfile);

				updateMerSubPlan.setSubPlanId(Integer.valueOf(merAccInfo.getSubscriptionPlan()));
				updateMerSubPlan.setExpiryDate(merAccInfo.getExpireDate());
				updateMerSubPlan.setMerchantId(merAccInfo.getMerchantId());
				updateMerSubPlan.setUserId(authUser.getUserId());
				getBeService().createMerSubPlan(updateMerSubPlan);
			}
			ModelAndView mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, ACCOUNT_INFO);
			mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.acc.info.crt"));
			mav.addAllObjects(com.bstsb.util.PopupBox.success("usrCreate", null,
					messageService.getMessage(MessageConstants.SUCC_UPD_ACC_INFO)));
			return mav;
		} else {
			ModelAndView mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, ACCOUNT_INFO);
			mav.addObject(MER_ACC_INFO, merAccInfo);
			return mav;
		}
	}


	@PostMapping(value = "/{merchantId}", params = "update=saveChnnlSetting")
	public ModelAndView updateChannelSetting(@PathVariable String merchantId,
			@Valid @ModelAttribute("merChanSetWrapper") MerChanSetWrapper merChanSetWrapper, BindingResult result)
			throws BeException {
		ModelAndView mav = new ModelAndView();
		merChanSetWrapper.setMerchantId(merchantId);
		UserProfile authUser = getCurrentUser();
		merChanSetWrapper.setUserId(authUser.getUserId());
		boolean isUpdated = false;
		if (!result.hasErrors()) {
			try {
				isUpdated = getBeService().updateChannelSetting(merChanSetWrapper);
				mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "channelSetting");
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		} else {
			mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "channelSetting");
			mav.addObject("merChanSetWrapper", merChanSetWrapper);
		}

		if (isUpdated) {
			mav.addAllObjects(com.bstsb.util.PopupBox.success("chnlSetting", null,
					messageService.getMessage(MessageConstants.SUCC_UPD_CHNL_SET)));
			LOGGER.info("Successfully create/update multi channel");
		}

		return mav;
	}


	@PostMapping(value = "/{merchantId}", params = "update=savePymtSetting")
	public ModelAndView updatePaymentPageSetting(@PathVariable String merchantId,
			@Valid @ModelAttribute("merPayPageSet") MerchantLogoPaymentSettingForm merPayPageSet,
			BindingResult result) throws BeException {
		UserProfile authUser = getCurrentUser();
		merPayPageSet.setMerchantId(merchantId);
		MerAccInfo accInfo = getBeService().getAccInfoById(merchantId);
		UserProfile userProfile = getIdmService().getUserprofileByMerchantProfileId(accInfo.getMerProfId());
		boolean isUpdated = false;
		if (!result.hasErrors()) {
			MerPayPageSet updatePayPageSet = dozerMapper.map(merPayPageSet, MerPayPageSet.class);
			updatePayPageSet.setUserId(authUser.getUserId());

			// Saving Logo
			try {
				if (!BaseUtil.isListNullZero(merPayPageSet.getFileUploads())
						&& merPayPageSet.getFileUploads().size() == 1) {
					// Merchant Logo is only one
					FileUpload fu = merPayPageSet.getFileUploads().get(0);
					com.bestpay.web.dto.CustomMultipartFile file = fu.getFile();
					if (file != null) {
						Documents doc = new Documents();
						new Documents();
						doc.setContentType(file.getContentType());
						doc.setFilename(file.getFilename());
						doc.setDocid(fu.getDocId());
						if (!BaseUtil.isObjNull(fu.getDocMgtId())) {
							doc.setId(fu.getDocMgtId());
						}
						doc.setLength(file.getSize());
						doc.setRefno(merchantId);
						doc.setContent(file.getContent());
						if (!BaseUtil.isObjNull(doc.getContent()) && (doc.getContent().length != 0)
								|| (BaseUtil.isObjNull(doc.getId()) && (doc.getContent().length != 0))) {
							fetchObjectData1(doc, updatePayPageSet, result);
						}
					}
				}
				isUpdated = getBeService().updatePaymentPageSetting(updatePayPageSet);
				if (!BaseUtil.isObjNull(updatePayPageSet) && !BaseUtil.isObjNull(userProfile)) {
					getIdmService().updateProfile(userProfile);
				}
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}

		if (isUpdated) {
			ModelAndView mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "payPageSetting");
			mav.addAllObjects(com.bstsb.util.PopupBox.success("pymtPageSetting", null,
					messageService.getMessage(MessageConstants.SUCC_UPD_PYMT_PG_SET)));
			LOGGER.info("Successfully update Payment Page Setting");
			return mav;
		} else {
			ModelAndView mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "payPageSetting");
			mav.addObject("merPayPageSet", merPayPageSet);
			return mav;
		}

	}


	private void fetchObjectData1(Documents doc, MerPayPageSet updatePayPageSet, BindingResult result) {
		try {
			Documents newDoc = getDmService(ProjectEnum.BESTPAY).upload(doc);
			LOGGER.info("Merchant Logo DocMgtId: {}", newDoc.getId());
			updatePayPageSet.setDocMgtId(newDoc.getId());
		} catch (IdmException e) {
			LOGGER.error("IdmException: {}", e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
		} catch (DmException e) {
			String errorCode = null;
			errorCode = e.getInternalErrorCode();
			LOGGER.error("DOM Response Error: {} - {}", errorCode, e.getMessage());
			result.rejectValue("fileUpload", "", "Unable to process your request [" + errorCode + "]");
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
		} catch (Exception e) {
			String errorCode = null;
			result.rejectValue("fileUpload", "", "Unable to process your request [" + errorCode + "]");
		}
	}


	@PostMapping(value = "/{merchantId}", params = "update=saveGenInfo")
	public ModelAndView updateGeneralInfo(@PathVariable String merchantId,
			@Valid @ModelAttribute("merGenInfo") MerGenInfo merGenInfo, BindingResult result) throws BeException {
		ModelAndView mav = new ModelAndView();
		merGenInfo.setMerchantId(merchantId);
		merGenInfo.setState(!BaseUtil.isObjNull(merGenInfo.getStateMy()) ? merGenInfo.getStateMy()
				: merGenInfo.getStateNonMy().toUpperCase());
		merGenInfo.setCity(!BaseUtil.isObjNull(merGenInfo.getCityMy()) ? merGenInfo.getCityMy()
				: merGenInfo.getCityNonMy().toUpperCase());
		if (!result.hasErrors()) {
			try {
				getBeService().updateGeneralInfo(merGenInfo);
				mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "generalInfo");
				mav.addAllObjects(com.bstsb.util.PopupBox.success("genInfo", null,
						messageService.getMessage(MessageConstants.SUCC_UPD_GEN_INFO)));
				LOGGER.info("Successfully save general info");
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		} else {
			mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "generalInfo");
			mav.addObject("merGenInfo", merGenInfo);
		}

		return mav;
	}


	@PostMapping(value = "/{merchantId}", params = "update=saveFraudSet")
	public ModelAndView updateFraudSet(@PathVariable String merchantId,
			@Valid @ModelAttribute("merFraudSet") MerFraudSet merFraudSet, BindingResult result) throws BeException {
		ModelAndView mav = new ModelAndView();
		merFraudSet.setMerchantId(merchantId);
		if (!result.hasErrors()) {
			try {
				getBeService().updateFraudSet(merFraudSet);
				mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "fraudSetting");
				mav.addAllObjects(com.bstsb.util.PopupBox.success("frdSet", null,
						messageService.getMessage(MessageConstants.SUCC_UPD_FRAUD_SET)));
				LOGGER.info("Successfully save fraud setting");
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		} else {
			mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "fraudSetting");
			mav.addObject("merFraudSet", merFraudSet);
		}

		return mav;
	}


	@PostMapping(value = "/{merchantId}", params = "update=saveAccSet")
	public ModelAndView updateAccSet(@PathVariable String merchantId,
			@Valid @ModelAttribute("merAccSet") MerAccSet merAccSet, BindingResult result) throws BeException {
		ModelAndView mav = new ModelAndView();
		merAccSet.setMerchantId(merchantId);
		if (!result.hasErrors()) {
			try {
				getBeService().updateAccSet(merAccSet);
				mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "accSetting");
				mav.addAllObjects(com.bstsb.util.PopupBox.success("accSet", null,
						messageService.getMessage(MessageConstants.SUCC_UPD_ACC_SET)));
				LOGGER.info("Successfully save account setting");
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		} else {
			mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "accSetting");
			mav.addObject("merAccSet", merAccSet);
		}

		return mav;
	}


	@PostMapping(value = "/{merchantId}", params = "update=saveRestriction")
	public ModelAndView updateRestriction(@PathVariable String merchantId,
			@ModelAttribute("merRestriction") MerRestriction merRestriction, BindingResult result)
			throws BeException {
		ModelAndView mav = new ModelAndView();
		merRestriction.setMerchantId(merchantId);
		if (!result.hasErrors()) {
			try {
				getBeService().updateRestriction(merRestriction);
				mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "restrictions");
				mav.addAllObjects(com.bstsb.util.PopupBox.success("restrict", null,
						messageService.getMessage(MessageConstants.SUCC_UPD_RESTRICTION)));
				LOGGER.info("Successfully save restriction");
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}

		return mav;
	}


	@PostMapping(value = "/{merchantId}", params = "update=saveBusCat")
	public ModelAndView updateBusinessCategory(@PathVariable String merchantId,
			@Valid @ModelAttribute(MER_BUS_CAT) MerBusCat merBusCat, BindingResult result) throws BeException {
		// Not using staticData as category can be updated by merchant admin
		List<Category> categoryList = getBeService().getLatestCategory();
		UserProfile authUser = getCurrentUser();
		merBusCat.setUserId(authUser.getUserId());
		merBusCat.setMerchantId(merchantId);
		boolean isUpdated = false;
		boolean isCategoryExist = false;
		StringBuilder sb = new StringBuilder();
		for (String cat : merBusCat.getCatList()) {
			sb.append(cat);
			if (merBusCat.getCatList().indexOf(cat) != (merBusCat.getCatList().size() - 1)) {
				sb.append(",");
			}
		}
		merBusCat.setCategory(sb.toString());
		if (!BaseUtil.isObjNull(merBusCat.getAddNewCat()) && merBusCat.getAddNewCat() == 1) {
			for (Category cat : categoryList) {
				if (BaseUtil.isEqualsCaseIgnore(cat.getCategoryName(), merBusCat.getNewMerCat())) {
					isCategoryExist = true;
				}
			}
		}

		if (!result.hasErrors() && !isCategoryExist) {
			try {
				isUpdated = getBeService().updateBusinessCategory(merBusCat);
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}

		ModelAndView mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, BUS_CATEGORY);
		if (isUpdated) {

			mav.addAllObjects(com.bstsb.util.PopupBox.success(BUS_CATEGORY, null,
					messageService.getMessage(MessageConstants.SUCC_UPD_BUS_CAT)));
			LOGGER.info("Successfully create/update business category");
		} else {
			mav.addObject(MER_BUS_CAT, merBusCat);
		}

		if (isCategoryExist) {
			mav.addObject(MER_BUS_CAT, merBusCat);
			mav.addAllObjects(com.bstsb.util.PopupBox.error(BUS_CATEGORY, null,
					messageService.getMessage(MessageConstants.ERROR_ADD_BUS_CAT)));
			LOGGER.info("Newly added category already existed");
		}

		return mav;
	}


	@PostMapping(value = "/{merchantId}", params = "update=saveRptSetting")
	public ModelAndView updateRepSet(@PathVariable String merchantId, @ModelAttribute("merRepSet") MerRepSet merRepSet,
			BindingResult result) throws BeException {
		UserProfile authUser = getCurrentUser();
		merRepSet.setUserId(authUser.getUserId());
		merRepSet.setMerchantId(merchantId);
		if (BaseUtil.isObjNull(merRepSet.getFreqD())) {
			merRepSet.setFreqD(0);
		}
		if (BaseUtil.isObjNull(merRepSet.getFreqW())) {
			merRepSet.setFreqW(0);
		}
		if (BaseUtil.isObjNull(merRepSet.getFreqM())) {
			merRepSet.setFreqM(0);
		}

		boolean isUpdated = false;
		if (!result.hasErrors()) {
			try {
				isUpdated = getBeService().updateReportSetting(merRepSet);
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
		ModelAndView mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "reportSetting");
		if (isUpdated) {
			mav.addAllObjects(com.bstsb.util.PopupBox.success("rptSetting", null,
					messageService.getMessage(MessageConstants.SUCC_UPD_RPT_SET)));
			LOGGER.info("Successfully create/update report setting");
		}

		return mav;
	}


	@PostMapping(value = "/{merchantId}", params = "update=saveSttlmntSetting")
	public ModelAndView updateSttlmntSet(@PathVariable String merchantId,
			@Valid @ModelAttribute("merSettlementSet") MerSettlementSet merSettlementSet, BindingResult result)
			throws BeException {
		UserProfile authUser = getCurrentUser();
		merSettlementSet.setUserId(authUser.getUserId());
		merSettlementSet.setMerchantId(merchantId);

		boolean isUpdated = false;
		if (!result.hasErrors()) {
			try {
				isUpdated = getBeService().updateSettlementSetting(merSettlementSet);
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
		ModelAndView mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "settlementSetting");
		if (isUpdated) {
			mav.addAllObjects(com.bstsb.util.PopupBox.success("sttlmntSetting", null,
					messageService.getMessage(MessageConstants.SUCC_UPD_STTLMNT_SET)));
			LOGGER.info("Successfully create/update settlement setting");
		} else {
			mav.addObject("merSettlementSet", merSettlementSet);
		}

		return mav;
	}


	@PostMapping(value = "/{merchantId}", params = "update=sendAccInfo")
	public ModelAndView sendAccInfo(@PathVariable String merchantId,
			@ModelAttribute("merSendAccInfo") MerSendAccInfo merSendAccInfo, BindingResult result)
			throws BeException {
		MerAccInfo accInfo = getBeService().getAccInfoById(merchantId);
		UserProfile merchUser = getIdmService().getUserprofileByMerchantProfileId(accInfo.getMerProfId());
		boolean isSent = false;
		if (!result.hasErrors()) {
			try {
				// this merchUser is used to
				merchUser = getIdmService().activateUser(merchUser);
				LOGGER.info("User {} is activated", merchUser.getUserId());
				isSent = true;
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
		ModelAndView mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "sendAccountInfo");
		if (isSent) {
			mav.addAllObjects(com.bstsb.util.PopupBox.success("sendAccountInfo", null,
					messageService.getMessage(MessageConstants.SUCC_SEND_ACC_INFO) + " "
							+ merSendAccInfo.getEmail()));
			LOGGER.info("Successfully send account info to merchant");
		}

		return mav;
	}


	@GetMapping(value = "/mer-mto-list/paginated")
	public @ResponseBody String getApplicationInfoPaginated(
			@RequestParam(value = MERCHANTID, required = true) String merchantId, HttpServletRequest request) {
		LOGGER.info("GET PAGINATED MERCHANT LIST....");
		DataTableResults<MerchantPid> tasks = new DataTableResults<>();
		if (BaseUtil.isObjNull(merchantId)) {
			merchantId = "new";
		}
		try {
			LOGGER.info("status merchant = {}", merchantId);
			tasks = getBeService().getMtoMappingByMerchant(merchantId, getPaginationRequest(request, true));
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(e.getMessage());
			tasks.setError(e.getMessage());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			tasks.setError(e.getMessage());
		}
		return new Gson().toJson(tasks);
	}


	private ModelAndView updatedInfo(String merchantId, String template, String title, String tab) throws BeException {
		ModelAndView mav = getDefaultMav(template, title, null, "merchant-mto-mapping-script");
		boolean planExpired = false;
		MerAccInfo merAccInfo = getBeService().getAccInfoById(merchantId);
		MerGenInfo merGenInfo = getBeService().getGenInfoById(merchantId);
		if (BaseUtil.isObjNull(merGenInfo.getEmail()) && !BaseUtil.isObjNull(merAccInfo.getEmail())) {
			merGenInfo.setEmail(merAccInfo.getEmail());
		}
		MerFraudSet merFraudSet = getBeService().getFraudSetById(merchantId);
		MerAccSet merAccSet = getBeService().getAccSetById(merchantId);
		merGenInfo.setRocNo(merAccSet.getIcNumber());
		MerBusCat merBusCat = getBeService().getMerBusCatById(merchantId);
		MerPayPageSet payPageSet = getBeService().getMerPayPageSetById(merchantId);
		MerchantLogoPaymentSettingForm merPayPageSet = dozerMapper.map(payPageSet,
				MerchantLogoPaymentSettingForm.class);
		MerRepSet merRepSet = getBeService().getMerRepSetById(merchantId);
		MerRestriction merRestriction = getBeService().getRestrictionById(merchantId);
		MerSettlementSet merSettlementSet = getBeService().getMerSettlementSetById(merchantId);
		MerSendAccInfo merSendAccInfo = new MerSendAccInfo();
		MerChanSetWrapper merChanSetWrapper = getBeService().getMerChanSetWrapperById(merchantId);
		UserProfile merchProfile = new UserProfile();
		UserProfile merUser = new UserProfile();
		MerchantPid merchantPid = new MerchantPid();
		new MerSubscriptionPlan();
		if (!BaseUtil.isObjNull(merAccInfo)) {
			merchProfile = getIdmService().getUserprofileByMerchantProfileId(merAccInfo.getMerProfId());
		}
		if (!BaseUtil.isObjNull(merchProfile)) {
			merSendAccInfo.setLoginId(merchProfile.getUserId());
			merSendAccInfo.setEmail(merchProfile.getEmail());
		}
		merSendAccInfo.setPdpa(merAccInfo.getPdpa());

		// Not using staticData as category can be updated by merchant admin
		List<Category> categoryList = getBeService().getLatestCategory();

		// Retrieve Merchant Logo
		List<FileUpload> fileUpload = new ArrayList<>();
		List<RefDocuments> refDocLst = getRefDocLst();
		for (RefDocuments refDoc : refDocLst) {
			FileUpload file = new FileUpload();
			Documents docs = null;
			if (!BaseUtil.isObjNull(merPayPageSet.getDocMgtId())) {
				try {
					docs = getDmService(ProjectEnum.BESTPAY).getMetadata(merPayPageSet.getDocMgtId());
				} catch (IdmException e) {
					LOGGER.error("IdmException: {}", e.getMessage());
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (DmException e) {
					LOGGER.error("DmException: {}", e.getMessage());
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error("Exception: {}", e.getMessage());
				}
			}

			if (docs != null && Integer.valueOf(docs.getDocid()).equals(Integer.valueOf(refDoc.getDocId()))) {
				file = dozerMapper.map(docs, FileUpload.class);
				CustomMultipartFile fl = new CustomMultipartFile();
				fl.setFilename(file.getFileName());
				file.setFile(fl);
			}
			file.setDocId(refDoc.getDocId());
			file.setDocMgtId(merPayPageSet.getDocMgtId());
			if (refDoc.getCompulsary() != null && "Y".equalsIgnoreCase(refDoc.getCompulsary())) {
				file.setCompulsary(true);
			}
			fileUpload.add(file);
		}

		if (!BaseUtil.isObjNull(merAccInfo.getExpireDate())) {
			Date date = new Date();
			if (DateUtil.compareDates(merAccInfo.getExpireDate(), date) == -1) {
				planExpired = true;
			}
		}

		IRProfile irProfile = new IRProfile();
		staticData.multiChannelList(merAccInfo.getCompanyRefId());
		boolean updateMerAccInfo = !BaseUtil.isObjNull(merAccInfo.getMerchantId());
		merPayPageSet.setFileUploads(fileUpload);
		mav.addObject(MER_ACC_INFO, merAccInfo);
		mav.addObject("merGenInfo", merGenInfo);
		mav.addObject("merFraudSet", merFraudSet);
		mav.addObject("merAccSet", merAccSet);
		mav.addObject(MER_BUS_CAT, merBusCat);
		mav.addObject("merPayPageSet", merPayPageSet);
		mav.addObject("merRepSet", merRepSet);
		mav.addObject("merRestriction", merRestriction);
		mav.addObject("merSettlementSet", merSettlementSet);
		mav.addObject("merSendAccInfo", merSendAccInfo);
		mav.addObject("merChanSetWrapper", merChanSetWrapper);
		mav.addObject("statusPlanList", staticData.status(SUBPLAN));
		mav.addObject(STATUS_ACC_LIST, staticData.status(ACTSTAT));
		mav.addObject("statusAccTypeList", staticData.status("ACTTYPE"));
		mav.addObject("statusIcTypeList", staticData.status("ICTYPE"));
		mav.addObject("channelList", staticData.multiChannelList(merAccInfo.getCompanyRefId()));
		mav.addObject("remittanceChannelList", getRemittanceChannelList(merAccInfo.getCompanyRefId()));
		mav.addObject("stateList", staticData.stateList("MYS"));
		mav.addObject("countryList", staticData.countryList());
		mav.addObject("bankList", staticData.bankList());
		mav.addObject("subPlanList", staticData.subPlanList());
		mav.addObject("categoryList", categoryList);
		mav.addObject("tab", tab);
		mav.addObject("updateMerAccInfo", updateMerAccInfo);
		mav.addObject("merUser", merUser);
		mav.addObject("canUpdateSttlmntSet", planExpired || BaseUtil.isObjNull(merSettlementSet.getReserveDay()));
		mav.addObject("rday", merSettlementSet.getReserveDay());
		mav.addObject("cityList", staticData.cityList());
		mav.addObject("merchantPid", merchantPid);
		MerchantPid merpid = getBeService().findMerchantPidByMerchantIdUsingMTOID(merchantId, "INCENTIVE_REMIT");
		mav.addObject("incentmtoid", merpid.getPid());
		mav.addObject("irProfile", irProfile);
		return mav;
	}


	@ModelAttribute("refDocLst")
	public List<RefDocuments> getRefDocLst() throws BeException {
		return staticData.refDocList(FileUploadConstants.PROFILE_PIC);
	}


	@PostMapping(value = "/search/{refCode}")
	public @ResponseBody String findByStatusType(@PathVariable("refCode") String refCode, HttpServletRequest request)
			throws BeException {

		if (!BaseUtil.isObjNull(refCode)) {
			return new Gson().toJson(getBeService().getRefStatusStaticList(refCode));
		}
		return null;
	}


	@ModelAttribute("merCompanyLst")
	public List<MerCompany> getMerCompanyLst() throws BeException {
		return getBeService().getMerchantCompanyDetails();
	}


	@PostMapping(value = "/{merchantId}", params = "update=registerMaxmoney")
	public ModelAndView registerMaxmoney(@PathVariable String merchantId,
			@ModelAttribute("merPayPageSet") MerchantLogoPaymentSettingForm merPayPageSet, IRProfile irProfile,
			BindingResult result) throws BeException {
		MerAccInfo accInfo = getBeService().getAccInfoById(merchantId);
		UserProfile merchUser = getIdmService().getUserprofileByMerchantProfileId(accInfo.getMerProfId());
		MerGenInfo merGenInfo = getBeService().getGenInfoById(merchantId);
		ModelAndView mav = new ModelAndView();
		// Set Parameter into INCENTIVE REMIT.
		ApsProfile apsProfile = new ApsProfile();

		apsProfile.setRegistrationNo("K-12034");
		apsProfile.setApsName(merchUser.getFullName()); // "SIME DARBY BERHAD"
		apsProfile.setOwnerName(accInfo.getOwnerDirectorName()); // "MIZAN
														// FARIDAH
														// MOHAMAD"
		apsProfile.setOwnerNationalId(accInfo.getOwnerDirectorNationalId());
		String phone = merGenInfo.getMphone();
		if (phone == null) {
			phone = merGenInfo.getPhone();
		} else {
			phone = merGenInfo.getMphone();
		}
		apsProfile.setOwnerPhoneNo(phone);
		apsProfile.setOwnerEmail(merchUser.getEmail());
		apsProfile.setOwnerAddress(merGenInfo.getAddress());
		merGenInfo.setCity(staticData.cityDesc(merGenInfo.getCity()));
		merGenInfo.setState(staticData.stateDesc(merGenInfo.getState()));
		apsProfile.setOwnerState(merGenInfo.getState());
		apsProfile.setOwnerCity(merGenInfo.getCity());
		apsProfile.setOwnerPostCode(merGenInfo.getPostcode());
		apsProfile.setOwnerCountry(MALAYSIA);
		apsProfile.setOwnerNationality(MALAYSIA);
		apsProfile.setPicName(accInfo.getSalesPic());
		apsProfile.setPicNationalId("");
		apsProfile.setPicPhoneNo(phone);
		apsProfile.setPicEmail(merchUser.getEmail());
		MerCompany merCompany = getBeService().getMerchantCompanyByCompanyId(accInfo.getCompanyRefId());
		apsProfile.setApsBankName("Bank Mandiri");
		apsProfile.setApsBankAccountNo("123455667");
		apsProfile.setApsBankAddress(merCompany.getAddress1());
		apsProfile.setApsState(merCompany.getState());
		apsProfile.setApsCity(merCompany.getCity());
		apsProfile.setNatureOfBusiness("IT Tech");
		apsProfile.setApsPostCode(merCompany.getPostcode());
		apsProfile.setApsType("Foreign Domestic Helper Agency");
		apsProfile.setApsCountry(merCompany.getCountry());
		apsProfile.setCompanyReferenceId(accInfo.getCompanyRefId());
		apsProfile.setMerchantId(merchantId);
		ApsProfileResponse irRespods = getBeService().saveMMInternalProfile(apsProfile);
		String str = irRespods.getUrl();
		LOGGER.info("Maxmoney URL {}", str);
		return mav;
	}


	@PostMapping(value = "/{merchantId}", params = "update=registerMTO")
	public ModelAndView sendMTORegisterInfo(@PathVariable String merchantId,
			@ModelAttribute("merPayPageSet") MerchantLogoPaymentSettingForm merPayPageSet, IRProfile irProfile,
			BindingResult result) throws BeException {
		MerAccInfo accInfo = getBeService().getAccInfoById(merchantId);
		UserProfile merchUser = getIdmService().getUserprofileByMerchantProfileId(accInfo.getMerProfId());
		MerGenInfo merGenInfo = getBeService().getGenInfoById(merchantId);
		ModelAndView mav = new ModelAndView();
		// Set Parameter into INCENTIVE REMIT.
		byte[] fileContent = null;
		if (!result.hasErrors()) {
			try {

				if (!BaseUtil.isListNullZero(merPayPageSet.getFileUploads())
						&& merPayPageSet.getFileUploads().size() == 1) {
					// Merchant Logo is only one
					FileUpload fu = merPayPageSet.getFileUploads().get(0);
					com.bestpay.web.dto.CustomMultipartFile file = fu.getFile();
					if (file != null) {
						Documents doc = new Documents();
						doc.setContentType(file.getContentType());
						doc.setFilename(file.getFilename());
						doc.setDocid(fu.getDocId());
						if (!BaseUtil.isObjNull(fu.getDocMgtId())) {
							doc.setId(fu.getDocMgtId());
						}
						doc.setLength(file.getSize());
						doc.setRefno(merchantId);
						doc.setContent(file.getContent());
						fileContent = file.getContent();

					}
				}
			} catch (Exception e) {
				LOGGER.error("Error : {}", e.getMessage());
			}
		}

		String fileUploadPhoto = Base64.encodeBase64String(fileContent);

		irProfile.setRegistrationNo("K-12034");
		irProfile.setApsName(merchUser.getFullName()); // "SIME DARBY BERHAD"
		irProfile.setOwnerName(accInfo.getOwnerDirectorName()); // "MIZAN
														// FARIDAH
														// MOHAMAD"
		irProfile.setOwnerNationalId(accInfo.getOwnerDirectorNationalId());
		String phone = merGenInfo.getMphone();
		if (phone == null) {
			phone = merGenInfo.getPhone();
		} else {
			phone = merGenInfo.getMphone();
		}
		irProfile.setOwnerPhoneNo(phone);
		irProfile.setOwnerEmail(merGenInfo.getEmail());
		irProfile.setOwnerAddress(merGenInfo.getAddress());
		merGenInfo.setCity(staticData.cityDesc(merGenInfo.getCity()));
		merGenInfo.setState(staticData.stateDesc(merGenInfo.getState()));
		irProfile.setOwnerState(merGenInfo.getState());
		irProfile.setOwnerCity(merGenInfo.getCity());
		irProfile.setOwnerPostCode(merGenInfo.getPostcode());
		irProfile.setOwnerCountry(MALAYSIA);
		irProfile.setOwnerNationality(MALAYSIA);
		irProfile.setPicName(accInfo.getSalesPic());
		irProfile.setPicNationalId("");
		irProfile.setPicPhoneNo(phone);
		irProfile.setPicEmail(merGenInfo.getEmail());
		MerCompany merCompany = getBeService().getMerchantCompanyByCompanyId(accInfo.getCompanyRefId());
		irProfile.setApsBankName("Bank Mandiri");
		irProfile.setApsBankAccountNo("123455667");
		irProfile.setApsBankAddress(merCompany.getAddress1());
		irProfile.setApsState(merCompany.getState());
		irProfile.setApsCity(merCompany.getCity());
		irProfile.setApsPostCode(merCompany.getPostcode());
		irProfile.setNatureOfBusiness("Non - Bank");
		irProfile.setApsType("Foreign Domestic Helper Agency");
		irProfile.setApsCountry(merCompany.getCountry());
		irProfile.setCompanyReferenceId(accInfo.getCompanyRefId());
		irProfile.setSenderPhoto(fileUploadPhoto);
		irProfile.setSenderPhoto1("");
		irProfile.setMerchantId(merchantId);
		IRProfileResponse irRespods = getBeService().saveIRInternalProfile(irProfile);
		LOGGER.info("IRMESSAGE ==> {}", irRespods.getMessage());
		String returnRespds = irRespods.getMessage();
		try {
			mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "remitRegister");
			mav.addAllObjects(PopupBox.success("Incentive", null, messageService.getMessage(returnRespds)));
			LOGGER.info("Successfully created MTO Incentive Remit.");
			MerchantPid merpid = getBeService().findMerchantPidByMerchantIdUsingMTOID(merchantId, "INCENTIVE_REMIT");
			String mtid = merpid.getPid();
			LOGGER.info("WELECOME FOR MERPID ==> {} ", mtid);
			mav.addObject("incentmtoid", mtid);
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return mav;
	}


	@PostMapping(value = "/{merchantId}", params = "update=accInfo")
	public ModelAndView activateAccInfo(@PathVariable String merchantId,
			@Valid @ModelAttribute("merSendAccInfo") MerSendAccInfo merSendAccInfo, BindingResult sendAccInfoResult)
			throws BeException {
		ModelAndView mav = updatedInfo(merchantId, PageTemplate.TEMP_MER_CRED, MER_MGMT, "sendAccountInfo");
		if (sendAccInfoResult.hasErrors()) {
			StringBuilder msg = new StringBuilder("");
			for (int i = sendAccInfoResult.getErrorCount(); i >= 1; i--) {
				msg.append(messageService.getMessage(sendAccInfoResult.getAllErrors().get(i - 1).getCode())
						+ "</br>");
			}
			mav.addAllObjects(com.bstsb.util.PopupBox.error("sendAccountInfo", null, msg));
		} else {
			MerAccInfo accInfo = getBeService().sendActivationEmail(merchantId);
			LOGGER.info(" Successfully sent mail to merchant {} ", accInfo.getCompany());
			mav.addAllObjects(com.bstsb.util.PopupBox.success("sendAccountInfo", null,
					messageService.getMessage(MessageConstants.SUCC_SEND_ACC_INFO) + " "
							+ merSendAccInfo.getEmail()));
		}
		return mav;
	}


	private List<ReferralMultiChannel> getRemittanceChannelList(String companyRefId) throws BeException {
		List<ReferralMultiChannel> list = staticData.multiChannelList(companyRefId);
		Iterator<ReferralMultiChannel> iter = list.iterator();
		while (iter.hasNext()) {
			ReferralMultiChannel channel = iter.next();
			if (channel.getChannelName().indexOf("REMITTANCE") == -1) {
				iter.remove();
			}
		}
		return list;
	}

}