package com.bestpay.be.controller;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.config.ConfigConstants;
import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.MMResponse;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.model.ApsProfile;
import com.bestpay.be.sdk.model.BeneficiaryAccount;
import com.bestpay.be.sdk.model.BeneficiaryDetail;
import com.bestpay.be.sdk.model.CustomerDetail;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@RestController
@RequestMapping(BeUrlConstants.MAXMONEY_SERVICE)
public class MaxMoneyRestController extends AbstractRestController {

	private static final Logger logger = LoggerFactory.getLogger(MaxMoneyRestController.class);
	
	private String baseurl = "https://api-staging.maxmoney.com/v1";
 	private String apiKey = "3993d7f0a85f7e06ee9049b954702e4491b94d33";
	private String uploadpath = "usr/share/tomcat/tmp/";
 
	
	
	@PostMapping(value = "/getSessionWithPID")
	public String getSessionWithPID(String pid) {
		String sessionId = null;
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(baseurl);
			sbUrl.append(ConfigConstants.MAX_MONEY_CUSTOMER);

			HttpPost request = new HttpPost(sbUrl.toString());

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("maxMoneyId", pid));

			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);

			if (response.getStatusLine().getStatusCode() == 200 || response.getStatusLine().getStatusCode() == 201) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					BufferedReader rd = new BufferedReader(
							new InputStreamReader(response.getEntity().getContent()));
					StringBuilder jsonString = new StringBuilder();
					String line = "";
					while ((line = rd.readLine()) != null) {
						jsonString.append(line);
					}
					JSONObject jsonObject = new JSONObject(jsonString.toString());
					sessionId = (String) jsonObject.get("session");
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("getSessionWithPID Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
				}
			}

		}   catch (ClientProtocolException e) {
			logger.info("getSessionWithPID ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("getSessionWithPID JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("getSessionWithPIDJsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("getSessionWithPID IOException: {}", e.getMessage());
		}

		return sessionId;
	}

  
	/** CUSTOMER REGISTRATION **/
	@PostMapping(value = "/customerRegistration")
	public CustomerDetail customerRegistration(ApsProfile apsProfile) {
		CustomerDetail customerDetail = null;
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(baseurl);
			sbUrl.append(ConfigConstants.MAX_MONEY_CUSTOMER);

			HttpPost request = new HttpPost(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY, apiKey);

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_IDTYPE, "NRIC"));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_IDNO, apsProfile.getOwnerNationalId()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_CUSTOMERNAME,apsProfile.getOwnerName()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_EMAIL, apsProfile.getOwnerEmail()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_MOBILE, apsProfile.getOwnerPhoneNo()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_ADDRESS, apsProfile.getOwnerAddress()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_CITY, apsProfile.getOwnerCity()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_STATE, apsProfile.getOwnerState()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_POSTALCODE,apsProfile.getOwnerPostCode()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_COUNTRY, "Malaysia"));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_NATIONALITY, "Malaysian"));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_COMPANYNAME, apsProfile.getApsName()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_NATUREOFBUSINESS,apsProfile.getNatureOfBusiness()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_COMPANYTYPE, apsProfile.getApsType()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_CONTACTPERSON,apsProfile.getPicName()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_BENEFICIARYID,apsProfile.getBeneficiaryId()));
			params.add(new BasicNameValuePair("type", "SME"));
			params.add(new BasicNameValuePair("registeredThrough", "Agent"));

			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					customerDetail = objectMapper.readValue(instream, CustomerDetail.class);
					instream.close();
				}
			} else {
				customerDetail = new CustomerDetail();
				customerDetail.setIdNo(apsProfile.getOwnerNationalId());

				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("customerRegistration Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
					customerDetail.setResponseCode(mmResponse.getCode());
					customerDetail.setDescriptions(mmResponse.getMessage() + "(" + mmResponse.getDescription() + ")");
				} else {
					customerDetail.setResponseCode(String.valueOf(response.getStatusLine().getStatusCode()));
					customerDetail.setDescriptions(response.getStatusLine().getReasonPhrase());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("customerRegistration UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("customerRegistration ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("customerRegistration JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("customerRegistration JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("customerRegistration IOException: {}", e.getMessage());
		}

		return customerDetail;
	}


	@PostMapping(value = "/createBeneficiary")
	public BeneficiaryDetail createBeneficiary(String name, String address, String country, String relationship,
			String mobile, String email, String customerName) {
		BeneficiaryDetail beneficiaryDetail = null;
		MMResponse mmResponse = null;

		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(baseurl);
			sbUrl.append(ConfigConstants.MAX_MONEY_CREATE_BENEFICIARY);

			HttpPost request = new HttpPost(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					apiKey);

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("name", name));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_ADDRESS, address));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_COUNTRY, country));
			params.add(new BasicNameValuePair("relationship", relationship));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_MOBILE, mobile));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_EMAIL, email));
			params.add(new BasicNameValuePair("orderPurpose", "Business"));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_CUSTOMERNAME, customerName));

			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					beneficiaryDetail = objectMapper.readValue(instream, BeneficiaryDetail.class);
					instream.close();
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("createBeneficiary Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("createBeneficiary UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("createBeneficiary ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("createBeneficiary JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("createBeneficiary JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("createBeneficiary IOException: {}", e.getMessage());
		}
		return beneficiaryDetail;
	}


	 

	@PostMapping(value = "/createBeneficiaryAccount")
	public BeneficiaryAccount createBeneficiaryAccount(String beneficiaryId, String acctNo, String acctName,
			String name, String branch, String location, String country, String bankName) {
		BeneficiaryAccount beneficiaryAcc = null;
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(baseurl);
			sbUrl.append("/beneficiaries/" + beneficiaryId + "/accounts");

			HttpPost request = new HttpPost(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					apiKey);

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("acctNo", acctNo));
			params.add(new BasicNameValuePair("acctName", acctName));
			params.add(new BasicNameValuePair("name", name));
			params.add(new BasicNameValuePair("branch", branch));
			params.add(new BasicNameValuePair("location", location));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_COUNTRY, country));
			params.add(new BasicNameValuePair("bankName", bankName));
			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					beneficiaryAcc = objectMapper.readValue(instream, BeneficiaryAccount.class);
					instream.close();
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("createBeneficiaryAccount Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("createBeneficiaryAccount UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("createBeneficiaryAccount ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("createBeneficiaryAccount JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("createBeneficiaryAccount JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("createBeneficiaryAccount IOException: {}", e.getMessage());
		}
		return beneficiaryAcc;
	}

 
	@PostMapping(value = BeUrlConstants.UPLOAD_DOCS, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public CustomerDetail uploadDocs(@RequestBody  ApsProfile apsProfile,
			HttpServletRequest req, HttpServletResponse res) {
		CustomerDetail customerDetail = null;
		MMResponse mmResponse = null;
		try {

			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(baseurl);
			sbUrl.append(ConfigConstants.MAX_MONEY_CUSTOMER + "/" + apsProfile.getOwnerNationalId());

			HttpPut request = new HttpPut(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					apiKey);

			MultipartEntityBuilder builder = MultipartEntityBuilder.create();
			builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
			addOwnerSupportingDocs(builder, apsProfile);
			addCompSupportingDocs(builder, apsProfile);

			HttpEntity entityBuilder = builder.build();
			request.setEntity(entityBuilder);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					customerDetail = objectMapper.readValue(instream, CustomerDetail.class);
					instream.close();
				}
			} else {
				customerDetail = new CustomerDetail();
				customerDetail.setIdNo(apsProfile.getOwnerNationalId());

				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("uploadDocs Response {}", mmResponse.getCode() + " : " + mmResponse.getMessage()
							+ " : " + mmResponse.getDescription());
					customerDetail.setResponseCode(mmResponse.getCode());
					customerDetail
							.setDescriptions(mmResponse.getMessage() + "(" + mmResponse.getDescription() + ")");
				} else {
					customerDetail.setResponseCode(String.valueOf(response.getStatusLine().getStatusCode()));
					customerDetail.setDescriptions(response.getStatusLine().getReasonPhrase());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("uploadDocs UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("uploadDocs ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("uploadDocs JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("uploadDocs JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("uploadDocs IOException: {}", e.getMessage());
		}
		return customerDetail;
	}


	private void addOwnerSupportingDocs(MultipartEntityBuilder builder,
			 ApsProfile apsProfile) throws IOException {
		String serverPath = uploadpath;
		if (apsProfile.getFileUploadsIcFront().get(0) != null
				&& apsProfile.getFileUploadsIcFront().get(0).getFile() != null
				&& apsProfile.getFileUploadsIcFront().get(0).getFile().getContent() != null) {
			File icFront = getFile(apsProfile.getFileUploadsIcFront().get(0).getFile().getContent(),
					serverPath + "icFront.png");
			builder.addBinaryBody("front", icFront);
		}

		if (apsProfile.getFileUploadsIcBack().get(0) != null
				&& apsProfile.getFileUploadsIcBack().get(0).getFile() != null
				&& apsProfile.getFileUploadsIcBack().get(0).getFile().getContent() != null) {
			File icBack = getFile(apsProfile.getFileUploadsIcBack().get(0).getFile().getContent(),
					serverPath + "icBack.png");
			builder.addBinaryBody("back", icBack);
		}
		if (apsProfile.getFileUploadsDirectorFront().get(0) != null
				&& apsProfile.getFileUploadsDirectorFront().get(0).getFile() != null
				&& apsProfile.getFileUploadsDirectorFront().get(0).getFile().getContent() != null) {
			File directorIDFront = getFile(apsProfile.getFileUploadsDirectorFront().get(0).getFile().getContent(),
					serverPath + "directorIDFront.png");
			builder.addBinaryBody("directorIDFront", directorIDFront);
		}
		if (apsProfile.getFileUploadsDirectorBack().get(0) != null
				&& apsProfile.getFileUploadsDirectorBack().get(0).getFile() != null
				&& apsProfile.getFileUploadsDirectorBack().get(0).getFile().getContent() != null) {
			File directorIDBack = getFile(apsProfile.getFileUploadsDirectorBack().get(0).getFile().getContent(),
					serverPath + "directorIDBack.png");
			builder.addBinaryBody("directorIDBack", directorIDBack);
		}
	}


	private void addCompSupportingDocs(MultipartEntityBuilder builder, ApsProfile apsProfile)
			throws IOException {
		String serverPath = uploadpath;

		if (apsProfile.getFileUploadsLor().get(0) != null && apsProfile.getFileUploadsLor().get(0).getFile() != null
				&& apsProfile.getFileUploadsLor().get(0).getFile().getContent() != null) {
			File lor = getFile(apsProfile.getFileUploadsLor().get(0).getFile().getContent(), serverPath + "lor.png");
			builder.addBinaryBody("lor", lor);
		}
		if (apsProfile.getFileUploadsForm241().get(0) != null
				&& apsProfile.getFileUploadsForm241().get(0).getFile() != null
				&& apsProfile.getFileUploadsForm241().get(0).getFile().getContent() != null) {
			File form241 = getFile(apsProfile.getFileUploadsForm241().get(0).getFile().getContent(),
					serverPath + "form24_1.png");
			builder.addBinaryBody("form24_1", form241);
		}
		if (apsProfile.getFileUploadsForm242().get(0) != null
				&& apsProfile.getFileUploadsForm242().get(0).getFile() != null
				&& apsProfile.getFileUploadsForm242().get(0).getFile().getContent() != null) {
			File form242 = getFile(apsProfile.getFileUploadsForm242().get(0).getFile().getContent(),
					serverPath + "form24_2.png");
			builder.addBinaryBody("form24_2", form242);
		}
		if (apsProfile.getFileUploadsForm243().get(0) != null
				&& apsProfile.getFileUploadsForm243().get(0).getFile() != null
				&& apsProfile.getFileUploadsForm243().get(0).getFile().getContent() != null) {
			File form243 = getFile(apsProfile.getFileUploadsForm243().get(0).getFile().getContent(),
					serverPath + "form24_3.png");
			builder.addBinaryBody("form24_3", form243);
		}
		if (apsProfile.getFileUploadsForm491().get(0) != null
				&& apsProfile.getFileUploadsForm491().get(0).getFile() != null
				&& apsProfile.getFileUploadsForm491().get(0).getFile().getContent() != null) {
			File form491 = getFile(apsProfile.getFileUploadsForm491().get(0).getFile().getContent(),
					serverPath + "form49_1.png");
			builder.addBinaryBody("form49_1", form491);
		}
		if (apsProfile.getFileUploadsForm492().get(0) != null
				&& apsProfile.getFileUploadsForm492().get(0).getFile() != null
				&& apsProfile.getFileUploadsForm492().get(0).getFile().getContent() != null) {
			File form492 = getFile(apsProfile.getFileUploadsForm492().get(0).getFile().getContent(),
					serverPath + "form49_2.png");
			builder.addBinaryBody("form49_2", form492);
		}
	}

             

	private File getFile(byte[] content, String name) throws IOException {
		File f = new File(name);
		try (OutputStream pdfout = new FileOutputStream(name)) {

			pdfout.write(content);
		} catch (IOException e) {
			logger.info("Exception: {}", e.getMessage());
		}
		return f;
	}

   
}
