package com.bestpay.be.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.bestpay.be.model.RefSubscriptionPlan;
import com.bestpay.be.sdk.model.SubscriptionPlan;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.pagination.PaginationCriteria;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;


@Repository
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_SUB_PLAN_CUSTOM_DAO)
public class RefSubscriptionPlanCustomDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(MerchantProfileCustomDao.class);

	@Autowired
	private RefSubscriptionPlanRepository refSubscriptionPlanRepository;

	@PersistenceContext
	private EntityManager entityManager;


	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}


	public DataTableResults<RefSubscriptionPlan> searchSubscriptionByPagination(SubscriptionPlan subscriptionPlan,
			DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append("from RefSubscriptionPlan r ");
		sb.append(" where 1=1 ");

		if (!BaseUtil.isObjNull(subscriptionPlan.getPlanType())) {
			sb.append(" and r.planType LIKE :planType ");
		}

		if (!BaseUtil.isObjNull(subscriptionPlan.getPlanValue())) {
			sb.append(" and r.planValue = :planValue ");
		}

		if (!BaseUtil.isObjNull(subscriptionPlan.getPlanDataType())) {
			sb.append(" and r.planDataType = :planDataType ");
		}

		sb.append(" order by r.createDt desc ");

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause("r"));
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<RefSubscriptionPlan> query = entityManager.createQuery(sb.toString(), RefSubscriptionPlan.class);
		// Original Query
		TypedQuery<RefSubscriptionPlan> query2 = entityManager.createQuery(sb.toString(), RefSubscriptionPlan.class);

		if (!BaseUtil.isObjNull(subscriptionPlan.getPlanType())) {
			query.setParameter("planType", "%" + subscriptionPlan.getPlanType() + "%");
			query2.setParameter("planType", "%" + subscriptionPlan.getPlanType() + "%");
		}

		if (!BaseUtil.isObjNull(subscriptionPlan.getPlanValue())) {
			query.setParameter("planValue", subscriptionPlan.getPlanValue());
			query2.setParameter("planValue", subscriptionPlan.getPlanValue());
		}

		if (!BaseUtil.isObjNull(subscriptionPlan.getPlanDataType())) {
			query.setParameter("planDataType", subscriptionPlan.getPlanDataType());
			query2.setParameter("planDataType", subscriptionPlan.getPlanDataType());
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<RefSubscriptionPlan> dataTableResult = new DataTableResults<>();
		List<RefSubscriptionPlan> svcResp = query.getResultList();
		List<RefSubscriptionPlan> svcResp2 = query2.getResultList();
		LOGGER.debug("Filtered Size: {}", svcResp.size());
		LOGGER.debug("Original Size: {}", svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size()
				: refSubscriptionPlanRepository.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		LOGGER.debug("isFilterByEmpty: {}", dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}
		return dataTableResult;
	}

}
