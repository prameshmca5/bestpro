package com.bestpay.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * @author Md Asif Aftab
 * @since 13th March 2018
 */

@Entity
@Table(name = "REF_NATIONALITY")
public class RefNationality extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = 2270425911125487517L;

	@Id
	@Column(name = "NTNLTY_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String ntnltyId;

	@Column(name = "NTNLTY_CODE")
	private String ntnltyCode;

	@Column(name = "NTNLTY_DESC_EN")
	private String ntnltyDescEn;

	@Column(name = "NTNLTY_DESC_MY")
	private String ntnltyDescMy;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public String getNtnltyId() {
		return ntnltyId;
	}


	public void setNtnltyId(String ntnltyId) {
		this.ntnltyId = ntnltyId;
	}


	public String getNtnltyCode() {
		return ntnltyCode;
	}


	public void setNtnltyCode(String ntnltyCode) {
		this.ntnltyCode = ntnltyCode;
	}


	public String getNtnltyDescEn() {
		return ntnltyDescEn;
	}


	public void setNtnltyDescEn(String ntnltyDescEn) {
		this.ntnltyDescEn = ntnltyDescEn;
	}


	public String getNtnltyDescMy() {
		return ntnltyDescMy;
	}


	public void setNtnltyDescMy(String ntnltyDescMy) {
		this.ntnltyDescMy = ntnltyDescMy;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Integer getId() {
		return null;
	}


	public void setId(Integer id) {
		// expect return nothing
	}

}
