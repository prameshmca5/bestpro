/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.config;


import java.io.File;
import java.util.Locale;
import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaDialect;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.bestpay.be.core.PersistenceUnitProcessor;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;
import com.bstsb.util.CryptoUtil;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = ConfigConstants.BASE_PACKAGE_REPO, entityManagerFactoryRef = QualifierConstants.ENTITY_MANAGER, transactionManagerRef = QualifierConstants.TRANS_MANAGER)
public class PersistenceConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(PersistenceConfig.class);


	@Bean
	public PersistenceAnnotationBeanPostProcessor persistenceAnnotationBeanPostProcessor() {
		PersistenceAnnotationBeanPostProcessor pa = new PersistenceAnnotationBeanPostProcessor();
		pa.setDefaultPersistenceUnitName("Authorization");
		return pa;
	}


	@Bean
	public PersistenceExceptionTranslationPostProcessor persistenceExceptionTranslationPostProcessor() {
		return new PersistenceExceptionTranslationPostProcessor();
	}


	@Bean
	@PersistenceContext(name = QualifierConstants.ENTITY_MANAGER)
	public EntityManagerFactory entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean entityManagerFactory = new LocalContainerEntityManagerFactoryBean();
		entityManagerFactory.setDataSource(dataSource());
		entityManagerFactory.setPackagesToScan(ConfigConstants.BASE_PACKAGE_MODEL);
		entityManagerFactory.setPersistenceUnitName(QualifierConstants.ENTITY_MANAGER_UNIT);

		entityManagerFactory.setJpaVendorAdapter(vendorAdapter());
		entityManagerFactory.afterPropertiesSet();
		entityManagerFactory.setJpaDialect(new HibernateJpaDialect());
		entityManagerFactory.setJpaProperties(additionalProperties());
		entityManagerFactory.setPersistenceUnitPostProcessors(new PersistenceUnitProcessor());
		entityManagerFactory.setLoadTimeWeaver(new InstrumentationLoadTimeWeaver());
		entityManagerFactory.afterPropertiesSet();
		return entityManagerFactory.getObject();
	}


	HibernateJpaVendorAdapter vendorAdapter() {
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		vendorAdapter.setGenerateDdl(false);
		vendorAdapter.setShowSql(false);
		vendorAdapter.setDatabasePlatform("org.hibernate.dialect.MySQLDialect");
		vendorAdapter.setDatabase(Database.MYSQL);
		return vendorAdapter;
	}


	final Properties additionalProperties() {
		Properties jpaProperties = new Properties();
		jpaProperties.setProperty("hibernate.cache.use_second_level_cache", "true");
		jpaProperties.setProperty("hibernate.cache.region.factory_class",
				"org.hibernate.cache.ehcache.EhCacheRegionFactory");
		jpaProperties.setProperty("hibernate.cache.use_query_cache", "true");
		jpaProperties.setProperty("hibernate.connection.autocommit", "false");
		return jpaProperties;
	}


	@Bean
	@Qualifier(value = QualifierConstants.TRANS_MANAGER)
	public PlatformTransactionManager transactionManager() {
		JpaTransactionManager transactionManager = new JpaTransactionManager(entityManagerFactory());
		transactionManager.setDataSource(dataSource());
		transactionManager.setJpaDialect(new HibernateJpaDialect());
		transactionManager.afterPropertiesSet();
		return transactionManager;
	}


	@Bean
	public DataSource dataSource() {
		String skey = messageSource().getMessage(ConfigConstants.SVC_IDM_SKEY, null, Locale.getDefault());
		String mysqlDriver = messageSource().getMessage(ConfigConstants.DB_CONF_DRIVER, null, Locale.getDefault());
		String mysqlUrl = messageSource().getMessage(ConfigConstants.DB_CONF_URL, null, Locale.getDefault());
		String mysqlUname = messageSource().getMessage(ConfigConstants.DB_CONF_UNAME, null, Locale.getDefault());
		String mysqlPword = messageSource().getMessage(ConfigConstants.DB_CONF_PWORD, null, Locale.getDefault());
		LOGGER.debug("\n[MySQL Credentials :: \n\tDriver : {} \n\tUrl: {} \n\tUsername : {} \n\tPassword : {} \n]",
				mysqlDriver, mysqlUrl, mysqlUname, mysqlPword);

		String poolDs = messageSource().getMessage(ConfigConstants.DB_CONF_POOL, null, Locale.getDefault());
		if (BaseUtil.isEqualsCaseIgnore("hikaricp", poolDs)) {
			HikariConfig config = new HikariConfig();
			config.setDriverClassName(mysqlDriver);
			config.setJdbcUrl(mysqlUrl);
			config.setUsername(mysqlUname);
			config.setPassword(CryptoUtil.decrypt(mysqlPword, skey));
			config.addDataSourceProperty("connectionTimeout", BaseUtil.getInt(messageSource()
					.getMessage(ConfigConstants.DB_CONF_HIKARI_CONN_TIMEOUT, null, Locale.getDefault())));
			config.addDataSourceProperty("idleTimeout", BaseUtil.getInt(messageSource()
					.getMessage(ConfigConstants.DB_CONF_HIKARI_IDLE_TIMEOUT, null, Locale.getDefault())));
			config.addDataSourceProperty("maxLifetime", BaseUtil.getInt(messageSource()
					.getMessage(ConfigConstants.DB_CONF_HIKARI_MAX_LIFETIME, null, Locale.getDefault())));
			config.addDataSourceProperty("connectionTestQuery", messageSource()
					.getMessage(ConfigConstants.DB_CONF_HIKARI_CONN_QUERY, null, Locale.getDefault()));
			config.addDataSourceProperty("maximumPoolSize", messageSource()
					.getMessage(ConfigConstants.DB_CONF_HIKARI_MIN_IDLE, null, Locale.getDefault()));
			config.addDataSourceProperty("connectionInitSql", messageSource()
					.getMessage(ConfigConstants.DB_CONF_HIKARI_MAX_POOL_SIZE, null, Locale.getDefault()));
			config.addDataSourceProperty("connectionInitSql", messageSource()
					.getMessage(ConfigConstants.DB_CONF_HIKARI_INIT_SQL, null, Locale.getDefault()));
			config.addDataSourceProperty("validationTimeout", BaseUtil.getInt(messageSource()
					.getMessage(ConfigConstants.DB_CONF_HIKARI_VALID_TIMEOUT, null, Locale.getDefault())));
			config.addDataSourceProperty("leakDetectionThreshold", BaseUtil.getInt(messageSource()
					.getMessage(ConfigConstants.DB_CONF_HIKARI_LEAK_DETECT, null, Locale.getDefault())));
			return new HikariDataSource(config);
		}

		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setDriverClassName(mysqlDriver);
		dataSource.setUrl(mysqlUrl);
		dataSource.setUsername(mysqlUname);
		dataSource.setPassword(CryptoUtil.decrypt(mysqlPword, skey));
		dataSource.setRemoveAbandoned(Boolean
				.valueOf(messageSource().getMessage(ConfigConstants.DB_CONF_ABANDONED, null, Locale.getDefault())));
		dataSource.setRemoveAbandonedTimeout(BaseUtil.getInt(
				messageSource().getMessage(ConfigConstants.DB_CONF_ABANDONED_TIMEOUT, null, Locale.getDefault())));
		dataSource.setLogAbandoned(Boolean.valueOf(
				messageSource().getMessage(ConfigConstants.DB_CONF_ABANDONED_LOG, null, Locale.getDefault())));
		dataSource.setMinIdle(BaseUtil
				.getInt(messageSource().getMessage(ConfigConstants.DB_CONF_MIN_IDLE, null, Locale.getDefault())));
		dataSource.setTestWhileIdle(Boolean
				.valueOf(messageSource().getMessage(ConfigConstants.DB_CONF_TEST_IDLE, null, Locale.getDefault())));
		dataSource.setTestOnBorrow(Boolean.valueOf(
				messageSource().getMessage(ConfigConstants.DB_CONF_TEST_ONBORROW, null, Locale.getDefault())));
		dataSource.setTestOnReturn(Boolean.valueOf(
				messageSource().getMessage(ConfigConstants.DB_CONF_TEST_ONRETURN, null, Locale.getDefault())));
		dataSource.setValidationQuery(
				messageSource().getMessage(ConfigConstants.DB_CONF_VALIDATION_QRY, null, Locale.getDefault()));
		dataSource.setValidationQueryTimeout(BaseUtil.getInt(
				messageSource().getMessage(ConfigConstants.DB_CONF_VALIDATION_TIMEOUT, null, Locale.getDefault())));
		dataSource.setMinEvictableIdleTimeMillis(BaseUtil.getInt(
				messageSource().getMessage(ConfigConstants.DB_CONF_MIN_IDLE_EVICT, null, Locale.getDefault())));
		dataSource.setTimeBetweenEvictionRunsMillis(BaseUtil.getInt(
				messageSource().getMessage(ConfigConstants.DB_CONF_TIME_BW_EVICT, null, Locale.getDefault())));
		dataSource.setMaxActive(BaseUtil
				.getInt(messageSource().getMessage(ConfigConstants.DB_CONF_MAX_ACTIVE, null, Locale.getDefault())));
		dataSource.setInitialSize(BaseUtil
				.getInt(messageSource().getMessage(ConfigConstants.DB_CONF_INIT_SIZE, null, Locale.getDefault())));
		dataSource.setMaxWait(BaseUtil
				.getInt(messageSource().getMessage(ConfigConstants.DB_CONF_MAX_WAIT, null, Locale.getDefault())));
		return dataSource;
	}


	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		PropertySourcesPlaceholderConfigurer ppc = new PropertySourcesPlaceholderConfigurer();
		FileSystemResource[] resources = new FileSystemResource[] {
				new FileSystemResource(getPropertyPath() + ConfigConstants.PROPERTIES_EXT) };
		ppc.setLocations(resources);
		ppc.setIgnoreUnresolvablePlaceholders(false);
		return ppc;
	}


	@Bean
	@Qualifier("messageSource")
	public MessageSource messageSource() {
		ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
		messageSource.setBasenames("classpath:report/messages/jasper", ConfigConstants.FILE_PFX + getPropertyPath());
		messageSource.setUseCodeAsDefaultMessage(true);
		messageSource.setDefaultEncoding("UTF-8");
		messageSource.setCacheSeconds(1800);
		messageSource.setFallbackToSystemLocale(false);
		return messageSource;
	}


	private static String propertyPath;


	private static String getPropertyPath() {
		if (!BaseUtil.isObjNull(propertyPath)) {
			return propertyPath;
		}
		// Get from PROJECT CONFIGURATION server
		String propertyHome = System.getProperty(ConfigConstants.PATH_PROJ_CONFIG) != null
				? System.getProperty(ConfigConstants.PATH_PROJ_CONFIG)
				: System.getenv(ConfigConstants.PATH_PROJ_CONFIG);
		LOGGER.debug("PROJECT CONFIGURATION HOME >> {}", propertyHome);
		File file = new File(propertyHome + ConfigConstants.FILE_SYS_RESOURCE);
		if (!file.exists()) {
			propertyHome = null;
		}

		// Get from TOMCAT server
		if (BaseUtil.isObjNull(propertyHome)) {
			propertyHome = System.getProperty(ConfigConstants.PATH_CATALINA_HOME) != null
					? System.getProperty(ConfigConstants.PATH_CATALINA_HOME)
					: System.getProperty(ConfigConstants.PATH_CATALINA_BASE);
			if (!BaseUtil.isObjNull(propertyHome)) {
				propertyHome = propertyHome + File.separator + "conf";
			}
			LOGGER.debug("CATALINA HOME >> {}", propertyHome);
			file = new File(propertyHome + ConfigConstants.FILE_SYS_RESOURCE);
			if (!file.exists()) {
				propertyHome = null;
			}
		}

		// Get from JBOSS server
		if (BaseUtil.isObjNull(propertyHome)) {
			propertyHome = System.getProperty(ConfigConstants.PROJ_JBOSS_HOME);
			LOGGER.debug("JBOSS HOME >>  {}", propertyHome);
			file = new File(propertyHome + ConfigConstants.FILE_SYS_RESOURCE);
			if (!file.exists()) {
				propertyHome = null;
			}
		}

		if (!BaseUtil.isObjNull(propertyHome)) {
			file = new File(propertyHome + ConfigConstants.FILE_SYS_RESOURCE);
			if (file.exists() && !file.isDirectory()) {
				propertyPath = propertyHome + File.separator + ConfigConstants.PROPERTY_FILENAME;
			} else {
				LOGGER.error("Missing properties file >> {} - {}", propertyHome, ConfigConstants.FILE_SYS_RESOURCE);
			}
		}

		// Get from Application CLASSPATH
		propertyPath = propertyPath != null ? propertyPath : ConfigConstants.PROPERTY_CLASSPATH;

		LOGGER.info("\n[Application Properties :: \n\tPath : {} \\n]", propertyPath);

		return propertyPath;
	}

}