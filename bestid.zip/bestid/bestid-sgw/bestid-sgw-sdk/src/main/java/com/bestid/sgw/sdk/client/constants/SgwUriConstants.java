/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.sgw.sdk.client.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
public class SgwUriConstants {

	private SgwUriConstants() {
		throw new IllegalStateException("Constants class");
	}


	public static final String SERVICES = "/services";

	public static final String REFERENCES = "/references";

	public static final String MOBILE_SERVICES = SERVICES + "/mobile";

	public static final String API_SERVICES = SERVICES + "/api";

	public static final String GENERATE_QR_CODE_DIGITALID = API_SERVICES + "/digitalid/qr/generate";

	public static final String MOBILE_REGISTRATION_CERT = MOBILE_SERVICES + "/registration/cert";

	public static final String MOBILE_STORE_CERT = MOBILE_SERVICES + "/store/cert";

	public static final String MOBILE_SUBMIT_CERT = MOBILE_SERVICES + "/submit/cert";

	public static final String MOBILE_REVOKE_CERT = MOBILE_SERVICES + "/revoke/cert";

	public static final String MOBILE_LOGIN = MOBILE_SERVICES + "/login";

	public static final String MOBILE_LOGOUT = MOBILE_SERVICES + "/logout";

	public static final String SEARCH_DEVICE = API_SERVICES + "/device/search";

	public static final String SEARCH_USER = API_SERVICES + "/user/search";

	public static final String REGISTER_USER = API_SERVICES + "/user/register";

	public static final String UPDATE_CONTACT = API_SERVICES + "/contact/update";

	public static final String GEN_ACTIVATION_CODE = API_SERVICES + "/activationCode/generate";

	public static final String VERIFY_ACTIVATION_CODE = API_SERVICES + "/activationCode/verify";

	public static final String VERIFY_QR_CODE_DIGITALID = API_SERVICES + "/qr/verify";

	public static final String VERIFY_PHOTO = API_SERVICES + "/photo/verify";

	public static final String MOBILE_SEARCH_FACE = MOBILE_SERVICES + "/face/search";

	public static final String MOBILE_PINCODE_VERIFY = MOBILE_SERVICES + "/pinCode/verify";

	public static final String MOBILE_PINCODE_UPDATE = MOBILE_SERVICES + "/pinCode/update";

	public static final String MOBILE_GEN_INVITATION_CODE = MOBILE_SERVICES + "/invCode/generate";

	public static final String MOBILE_VERIFY_INVITATION_CODE = MOBILE_SERVICES + "/invCode/verify";

	public static final String MOBILE_SEARCH_PROFILE = MOBILE_SERVICES + "/profile/search";
	
    public static final String MOBILE_VERIFY_DIGITALID = MOBILE_SERVICES + "/digitalId/verify";
	
	public static final String MOBILE_VERIFY_AUTH = MOBILE_SERVICES + "/auth/verify";
	
	public static final String MOBILE_REGISTER_PROFILE = MOBILE_SERVICES + "/profile/register";
	
	public static final String DIGITALID_STATUS_CHECK = API_SERVICES + "/digitalId/status/check";

}