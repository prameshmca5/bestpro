package com.bestpay.web.cmn.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.RefStatus;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;


@Controller
@RequestMapping(value = PageConstants.PAGE_CMS_STATUS_LST)
public class CMSStatusController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CMSSubscriptionController.class);

	private static final String STATUS_LIST_SCRIPT = "status-list-script";

	private static final String STATUS = "refStatus";


	@GetMapping
	public ModelAndView status(RefStatus refStatus, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMS_STATUS, STATUS, null, STATUS_LIST_SCRIPT);
		mav.addObject(STATUS, refStatus);
		return mav;
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String searchPaginated(@ModelAttribute(STATUS) RefStatus refStatus,
			HttpServletRequest request) throws BeException {
		getDefaultMav(PageTemplate.TEMP_CMS_STATUS, null, null, STATUS_LIST_SCRIPT);
		DataTableResults<RefStatus> tasks = getBeService().searchStatus(refStatus,
				getPaginationRequest(request, true));
		return new Gson().toJson(tasks);
	}


	// Search status
	@PostMapping(params = "search")
	public ModelAndView search(RefStatus refStatus, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMS_STATUS, null, null, STATUS_LIST_SCRIPT);
		mav.addObject(STATUS, refStatus);
		return mav;
	}


	// Reset searching merchant
	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute(STATUS) @Validated RefStatus refStatus, BindingResult result,
			HttpServletRequest request, HttpSession session) {
		RefStatus status = new RefStatus();
		LOGGER.info("--reset--");
		return status(status, result, request, session);
	}


	@GetMapping(value = "/new")
	public ModelAndView newStatus(RefStatus refStatus, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_CMS_STATUS_NEW);
		RefStatus status = new RefStatus();
		mav.addObject(STATUS, status);
		return mav;
	}


	@PostMapping(value = "/addStatus")
	public ModelAndView addNewStatus(@Valid @ModelAttribute("refStatus") RefStatus refStatus, BindingResult result,
			HttpServletRequest request, HttpSession session) throws BeException {
		ModelAndView mav;
		boolean isUpdated = getBeService().addStatus(refStatus);
		LOGGER.info("Update status {}", isUpdated);
		String msg;
		if (refStatus.getId() != null) {
			msg = messageService.getMessage(MessageConstants.SUCC_UPDATE_STATUS);
		} else {
			msg = messageService.getMessage(MessageConstants.SUCC_CREATE_STATUS);
		}
		mav = getDefaultMav(PageTemplate.TEMP_CMS_STATUS, null, null, STATUS_LIST_SCRIPT);
		refStatus = new RefStatus();
		mav.addAllObjects(PopupBox.success(STATUS, null, msg));
		mav.addAllObjects(PopupBox.success(null, null, msg, PageConstants.PAGE_CMS_STATUS_LST));
		mav.addObject(STATUS, refStatus);
		return mav;
	}


	@GetMapping(value = "/update/{statusId}")
	public ModelAndView updateStatus(@PathVariable("statusId") Integer statusId, HttpServletRequest request,
			HttpSession session) throws BeException {
		RefStatus refStatus = getBeService().getStatusById(statusId);
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_CMS_STATUS_NEW);
		mav.addObject(STATUS, refStatus);
		return mav;
	}


	@PostMapping(value = "/addStatus", params = "reset")
	public ModelAndView resetStatus(@RequestParam String reset, @ModelAttribute("refStatus") RefStatus refStatus,
			BindingResult result, HttpServletRequest request, HttpSession session) throws BeException {
		if (refStatus.getId() != null) {
			refStatus = getBeService().getStatusById(refStatus.getId());
		} else {
			refStatus = new RefStatus();
		}
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_CMS_STATUS_NEW);
		mav.addObject(STATUS, refStatus);
		return mav;
	}


	@GetMapping(value = "/delete/{statusId}")
	public ModelAndView deleteSubscription(@PathVariable("statusId") Integer statusId, HttpServletRequest request,
			HttpSession session) throws BeException {
		boolean isDeleted = getBeService().deleteStatus(statusId);
		LOGGER.info("Delete channel {}", isDeleted);
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMS_STATUS, null, null, STATUS_LIST_SCRIPT);

		mav.addAllObjects(
				PopupBox.success(STATUS, null, messageService.getMessage(MessageConstants.SUCC_DELETE_STATUS)));
		mav.addAllObjects(PopupBox.success(null, null, messageService.getMessage(MessageConstants.SUCC_DELETE_STATUS),
				PageConstants.PAGE_CMS_STATUS_LST));
		RefStatus status = new RefStatus();
		mav.addObject(STATUS, status);
		return mav;
	}

}
