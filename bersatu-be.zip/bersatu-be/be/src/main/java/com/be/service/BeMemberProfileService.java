/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.be.service;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeMemberProfileQf;
import com.be.dao.BeMemberProfileRepository;
import com.be.dao.BePreRegRepository;
import com.be.model.BeMemberProfile;
import com.be.model.BePreReg;
import com.be.model.BeTrxnDocument;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.MemberAddress;
import com.be.sdk.model.MemberProfile;
import com.be.sdk.model.TrxnDocuments;
import com.idm.sdk.model.UserProfile;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;


/**
 * @author mohd.naem
 * @since March 31 , 2021
 */
@Service(QualifierConstants.BE_MEMBER_PROFILE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_MEMBER_PROFILE_SVC)
@Transactional
public class BeMemberProfileService extends AbstractService<BeMemberProfile> {

	protected static Logger logger = LoggerFactory.getLogger(BeMemberProfileService.class);

	@Autowired
	private BeMemberProfileRepository beMemberProfileDao;

	@Autowired
	private BeMemberProfileQf beMemberProfileQf;

	@Autowired
	private BeTrxnDocumentsService beTrxnDocumentsSvc;

	@Autowired
	private BePreRegRepository bePreRegDao;


	@Override
	public GenericRepository<BeMemberProfile> primaryDao() {
		return beMemberProfileDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return null;
	}


	public long getCount(MemberProfile dto) {
		return beMemberProfileQf.getCount(dto);
	}


	@SuppressWarnings("unchecked")
	public List<MemberProfile> searchPagination(MemberProfile dto, DataTableRequest<?> dataTableInRQ)
			throws IOException {
		return JsonUtil.transferToList(beMemberProfileQf.searchAllByProperty(dto, dataTableInRQ),
				MemberProfile.class);
	}


	@SuppressWarnings("unchecked")
	public MemberProfile search(MemberProfile dto) throws IOException {
		List<BeMemberProfile> beMemberProfileList = beMemberProfileQf.searchAllByProperty(dto, null);
		MemberProfile memberProfile = null;
		if (!BaseUtil.isListNull(beMemberProfileList)) {
			BeMemberProfile beMemberProfile = beMemberProfileList.stream()
					.sorted(Comparator.comparingInt(BeMemberProfile::getMemberId).reversed()).findFirst()
					.orElse(null);
			if (!BaseUtil.isObjNull(beMemberProfile)) {
				memberProfile = JsonUtil.transferToObject(beMemberProfile, MemberProfile.class);
				memberProfile.setMemberAddressList(
						JsonUtil.transferToList(beMemberProfile.getMemberAddressList(), MemberAddress.class));
				if (!BaseUtil.isListNull(beMemberProfile.getTrxnDocumentsList())) {
					memberProfile.setTrxnDocumentList(beMemberProfile.getTrxnDocumentsList().stream().map(doc -> {
						TrxnDocuments docTrxn = new TrxnDocuments();
						docTrxn.setDocRefNo(doc.getId().getDocRefNo());
						docTrxn.setDocId(doc.getId().getDocId());
						docTrxn.setDocMgtId(doc.getId().getDocMgtId());
						docTrxn.setAppRefNo(doc.getAppRefNo());
						docTrxn.setAppType(doc.getAppType());
						docTrxn.setDocContentType(doc.getDocContentType());
						return docTrxn;
					}).collect(Collectors.toList()));
				}
			}
		}
		return memberProfile;
	}


	@SuppressWarnings("unchecked")
	public List<MemberProfile> searchMemberProfileList(MemberProfile dto) throws IOException {
		List<BeMemberProfile> beMemberProfileList = beMemberProfileQf.searchAllByProperty(dto, null);
		List<MemberProfile> memberProfiles = new ArrayList<>();

		if (!BaseUtil.isListNull(beMemberProfileList)) {
			for (BeMemberProfile memberProf : beMemberProfileList) {
				MemberProfile memberProfile = JsonUtil.transferToObject(memberProf, MemberProfile.class);
				memberProfile.setMemberAddressList(
						JsonUtil.transferToList(memberProf.getMemberAddressList(), MemberAddress.class));
				if (!BaseUtil.isListNull(memberProf.getTrxnDocumentsList())) {
					memberProfile.setTrxnDocumentList(memberProf.getTrxnDocumentsList().stream().map(doc -> {
						TrxnDocuments docTrxn = new TrxnDocuments();
						docTrxn.setDocRefNo(doc.getId().getDocRefNo());
						docTrxn.setDocId(doc.getId().getDocId());
						docTrxn.setDocMgtId(doc.getId().getDocMgtId());
						docTrxn.setAppRefNo(doc.getAppRefNo());
						docTrxn.setAppType(doc.getAppType());
						docTrxn.setDocContentType(doc.getDocContentType());
						return docTrxn;
					}).collect(Collectors.toList()));
				}
				memberProfiles.add(memberProfile);
			}

		}

		return memberProfiles;
	}


	@SuppressWarnings("unchecked")
	public List<BeMemberProfile> searchList(MemberProfile dto) throws IOException {
		return beMemberProfileQf.searchAllByProperty(dto, null);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public BeMemberProfile create(BeMemberProfile beMemberProfile, Collection<BeTrxnDocument> beTrxnDocumentList,
			BePreReg bePreReg) {
		if (beTrxnDocumentList != null && !beTrxnDocumentList.isEmpty()) {
			beTrxnDocumentsSvc.updateAll(beTrxnDocumentList);
		}

		if (!BaseUtil.isObjNull(bePreReg)) {
			bePreRegDao.save(bePreReg);
		}

		return beMemberProfileDao.save(beMemberProfile);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public BeMemberProfile update(BeMemberProfile beMemberProfile, Collection<BeTrxnDocument> beTrxnDocumentList,
			Collection<BeTrxnDocument> beTrxnDocumentDelList) {
		if (beTrxnDocumentList != null && !beTrxnDocumentList.isEmpty()) {
			beTrxnDocumentsSvc.deleteAll(beTrxnDocumentDelList);
			beTrxnDocumentsSvc.updateAll(beTrxnDocumentList);
		}
		return beMemberProfileDao.save(beMemberProfile);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public BeMemberProfile updateTransfer(BeMemberProfile dto, String utype, String role, HttpServletRequest request) {
		String state = dto.getOrgStateCd();
		String div = dto.getOrgDivisionCd();
		String branch = dto.getOrgBranchCd();
		String transRemark = dto.getTransferRemarks();
		String idNo = dto.getIdNo();
		try {
			// Member profile update
			beMemberProfileDao.updateTransferByMemberId(state, div, branch, transRemark, idNo);
			// PreReg profile Update
			bePreRegDao.updateTransferByPreRegId(state, div, branch, dto.getPreRegId());
			// IDM ROLE UPDATE
			String userId = idNo;
			UserProfile userProfile = getIdmService(request).getUserProfileById(userId, false, false);
			userProfile.setUserTypeCode(utype);
			userProfile.setUserRoleGroupCode(role);
			userProfile.setCntryCd(state);
			getIdmService(request).updateProfile(userProfile);
		} catch (BeException ex) {
			ex.getMessage();
		}
		// PreRef Update

		return dto;

	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public BeMemberProfile blockMemberProfile(MemberProfile dto) {
		BeMemberProfile searchdto = new BeMemberProfile();
		searchdto.setMemberId(dto.getMemberId());
		searchdto.setTxnId(dto.getTxnId());
		List<BeMemberProfile> beMemprofList = beMemberProfileQf.searchAllByProperty(searchdto);
		if (!BaseUtil.isListNull(beMemprofList)) {
			BeMemberProfile preReg = beMemprofList.get(0);
			preReg.setStatusId(dto.getStatusId());
			return update(preReg);
		}
		return null;
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public BeMemberProfile updateEndorsement(MemberProfile dto) {
		BeMemberProfile searchdto = new BeMemberProfile();
		searchdto.setMemberId(dto.getMemberId());
		List<BeMemberProfile> beMemprofList = beMemberProfileQf.searchAllByProperty(searchdto);
		if (!BaseUtil.isListNull(beMemprofList)) {
			BeMemberProfile preReg = beMemprofList.get(0);
			preReg.setEndtStatusId(dto.getEndtStatusId());
			return update(preReg);
		}
		return null;
	}

}