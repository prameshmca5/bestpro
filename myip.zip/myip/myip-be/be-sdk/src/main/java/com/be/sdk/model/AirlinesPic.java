/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;

/**
 * @author michelle.angela
 *
 */
public class AirlinesPic implements Serializable {

	private static final long serialVersionUID = -4253088278231126743L;

	private Integer airlinesPicId;

	private AirlinesProfile airlinesProfile;
	 
	private Metadata titleTypeMtdt;
	
	private String fullName;
	
	private String contactNo;
	
	private String designation;
	
	private String email;
	
	private Boolean isActive;

	public Integer getAirlinesPicId() {
		return airlinesPicId;
	}

	public void setAirlinesPicId(Integer airlinesPicId) {
		this.airlinesPicId = airlinesPicId;
	}

	public AirlinesProfile getAirlinesProfile() {
		return airlinesProfile;
	}

	public void setAirlinesProfile(AirlinesProfile airlinesProfile) {
		this.airlinesProfile = airlinesProfile;
	}

	public Metadata getTitleTypeMtdt() {
		return titleTypeMtdt;
	}

	public void setTitleTypeMtdt(Metadata titleTypeMtdt) {
		this.titleTypeMtdt = titleTypeMtdt;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
}
