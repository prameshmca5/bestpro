/**
 * Copyright 2019
 */
package com.be.config;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.be.client.OcrRegulaServiceClient;
import com.be.sdk.client.BeServiceClient;
import com.be.sdk.client.IFaceServiceClient;
import com.dm.sdk.client.DmServiceClient;
import com.icao.sdk.client.RegularServiceClient;
import com.idm.sdk.client.IdmServiceClient;
import com.notify.sdk.client.NotServiceClient;
import com.report.sdk.client.ReportServiceClient;
import com.util.constants.BaseConfigConstants;
import com.util.constants.BaseConstants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
@Configuration
public class ServiceConfig implements InitializingBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceConfig.class);

	@Value("${" + BaseConfigConstants.SVC_IDM_URL + "}")
	private String idmUrl;

	@Value("${" + BaseConfigConstants.SVC_IDM_TIMEOUT + "}")
	private int idmTimeout;

	@Value("${" + BaseConfigConstants.SVC_NOT_URL + "}")
	private String notUrl;

	@Value("${" + BaseConfigConstants.SVC_NOT_TIMEOUT + "}")
	private int notTimeout;

	@Value("${" + BaseConfigConstants.SVC_WFW_URL + "}")
	private String wfwUrl;

	@Value("${" + BaseConfigConstants.SVC_WFW_TIMEOUT + "}")
	private int wfwTimeout;

	@Value("${" + BaseConfigConstants.SVC_DM_URL + "}")
	private String dmUrl;

	@Value("${" + BaseConfigConstants.SVC_DM_TIMEOUT + "}")
	private int dmTimeout;

	@Value("${" + BaseConfigConstants.SVC_RPT_URL + "}")
	private String rptUrl;

	@Value("${" + BaseConfigConstants.SVC_RPT_TIMEOUT + "}")
	private int rptTimeout;

	@Value("${" + BaseConfigConstants.SVC_REGULAR_URL + "}")
	private String regularUrl;

	@Value("${" + BaseConfigConstants.SVC_REGULAR_KEY + "}")
	private String regularKey;

	@Value("${" + BaseConfigConstants.SVC_REGULAR_TIMEOUT + "}")
	private int regularTimeout;

	@Value("${" + BaseConfigConstants.SVC_IFACE_URL + "}")
	private String ifaceUrl;

	@Value("${" + BaseConfigConstants.SVC_IFACE_UNAME + "}")
	private String ifaceUname;

	@Value("${" + BaseConfigConstants.SVC_IFACE_PWRD + "}")
	private String ifacePwrd;

	@Value("${" + BaseConfigConstants.SVC_IFACE_MIN_VAL + "}")
	private String ifaceMinVal;


	@Bean
	public IdmServiceClient idmService() {
		return new IdmServiceClient(idmUrl, idmTimeout);
	}


	@Bean
	public BeServiceClient beService() {
		return new BeServiceClient(null, 0);
	}


	@Bean
	public NotServiceClient notifyService() {
		return new NotServiceClient(notUrl, notTimeout);
	}


	@Bean
	public DmServiceClient dmService() {
		return new DmServiceClient(dmUrl, dmTimeout);
	}


	@Bean
	public ReportServiceClient reportService() {
		return new ReportServiceClient(rptUrl, rptTimeout);
	}


	@Bean
	public RegularServiceClient regularService() {
		return new RegularServiceClient(regularUrl, regularKey, regularTimeout);
	}


	@Bean
	public OcrRegulaServiceClient ocrRegulaService() {
		return new OcrRegulaServiceClient(regularUrl, regularKey, regularTimeout);
	}


	@Bean
	public IFaceServiceClient iFaceService() {
		return new IFaceServiceClient(ifaceUrl, ifaceUname, ifacePwrd, Double.parseDouble(ifaceMinVal));
	}


	@Override
	public void afterPropertiesSet() throws Exception {
		final String TIMEOUT = "\t- Timeout (seconds): ";
		StringBuilder sb = new StringBuilder();
		sb.append(BaseConstants.NEW_LINE + BaseConstants.NEW_LINE);
		sb.append(BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("Integration Service");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("IDM Service URL: " + idmUrl + TIMEOUT + idmTimeout + BaseConstants.NEW_LINE);
		sb.append("NOT edit Service URL: " + notUrl + TIMEOUT + notTimeout + BaseConstants.NEW_LINE);
		sb.append("WFW Service URL: " + wfwUrl + TIMEOUT + wfwTimeout + BaseConstants.NEW_LINE);
		sb.append("RPT Service URL: " + rptUrl + TIMEOUT + rptTimeout + BaseConstants.NEW_LINE);
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("REGULAR Credentials");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("URL:  " + regularUrl + BaseConstants.NEW_LINE);
		sb.append("Key:  " + regularKey + BaseConstants.NEW_LINE);
		sb.append("Timeout: " + regularTimeout);
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("IFACE Service");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("URL:  " + ifaceUrl + BaseConstants.NEW_LINE);
		sb.append("Min Value:  " + ifaceMinVal + BaseConstants.NEW_LINE);
		LOGGER.info("{}", sb);
	}

}