/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeAcctPassport;
import com.be.model.BeAcctProfile;
import com.be.model.BeAcctTraveller;
import com.be.model.BeConfigRiskStatus;
import com.be.model.BeTripAccommodation;
import com.be.model.BeTvl;
import com.be.model.BeTvlMcAttendance;
import com.be.model.BeTvlPayment;
import com.be.model.BeTvlPaymentDtl;
import com.be.model.BeTvlProfile;
import com.be.model.BeTvlStat;
import com.be.model.BeTvlTrip;
import com.be.model.RefCountry;
import com.be.model.RefStatus;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeServiceConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.AcctProfile;
import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.Country;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Tvl;
import com.be.service.BeAcctPassportService;
import com.be.service.BeAcctProfileService;
import com.be.service.BeConfigRiskStatusService;
import com.be.service.BeTvlProfileService;
import com.be.service.RefCountryService;
import com.be.service.RefStatusService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;


/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_QF)
public class BeTvlQf extends QueryFactory<BeTvl> {

	@Autowired
	RefStatusService refStatusSvc;

	@Autowired
	BeTvlProfileService beTvlProfileSvc;

	@Autowired
	BeAcctPassportService beAcctPassportSvc;

	@Autowired
	BeAcctProfileService beAcctProfileSvc;

	@Autowired
	BeTvlTripQf beTvlTripQf;

	@Autowired
	BeAcctTravellerQf beAcctTravellerQf;

	@Autowired
	BeTvlMcAttendanceQf beTvlMcAttendanceQf;

	@Autowired
	BeTvlPaymentQf beTvlPaymentQf;

	@Autowired
	RefCountryService refCountrySvc;

	@Autowired
	BeConfigRiskStatusService beConfigRiskStatusSvc;

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BeTvl> searchByProperty(BeTvl t) {
		return (Root<BeTvl> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}


	@Override
	public List<BeTvl> searchAllByProperty(BeTvl t) {
		CriteriaQuery<BeTvl> cq = cb.createQuery(BeTvl.class);
		Root<BeTvl> from = cq.from(BeTvl.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public List<BeTvl> searchBeTravelPagination(Tvl dto, DataTableRequest<?> dataTableInRQ) {

		List<BeTvl> result = new ArrayList<>();
		CriteriaQuery<BeTvl> cq = cb.createQuery(BeTvl.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvl> root = cq.from(BeTvl.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					cq.orderBy(getOrderByClause(cb, root, pagination));
				}
			}

			TypedQuery<BeTvl> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}


	public BeTvl searchBeTravel(Tvl dto) {

		BeTvl result = null;
		CriteriaQuery<BeTvl> cq = cb.createQuery(BeTvl.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvl> root = cq.from(BeTvl.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeTvl> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}


	public Long getCount(Tvl dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeTvl> from = cq.from(BeTvl.class);
		predicates.addAll(generateCriteria(cb, from, dto));
		// joinFetch(root, predicates, dto, cq);

		Join<BeTvl, BeTvlProfile> tvlProfile = from.join("tvlProfile", JoinType.LEFT);
		predicates.addAll(beTvlProfileSvc.generateCriteria(cb, tvlProfile, dto.getTvlProfile()));

		if (!BaseUtil.isObjNull(dto.getAcctProfId())) {
			dto.setAcctProfile(new AcctProfile());
			dto.getAcctProfile().setAcctProfId(dto.getAcctProfId());
			Join<BeTvl, BeAcctProfile> acctProfile = from.join("acctProfile", JoinType.LEFT);
			predicates.addAll(beAcctProfileSvc.generateCriteria(cb, acctProfile, dto.getAcctProfile()));
		}

		Join<BeTvlProfile, BeAcctPassport> acctPassport = tvlProfile.join("acctPassport", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getTvlProfile()) && !BaseUtil.isObjNull(dto.getTvlProfile().getAcctPassport())) {
			predicates.addAll(
					beAcctPassportSvc.generateCriteria(cb, acctPassport, dto.getTvlProfile().getAcctPassport()));
		}

		Join<BeTvl, RefStatus> status = from.join("status", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getStatusId()) || !BaseUtil.isListNull(dto.getStatusIdList())
				|| !BaseUtil.isObjNull(dto.getStatusIdNotInList())) {
			predicates.addAll(refStatusSvc.generateCriteria(cb, status, dto));
		} else if (!BaseUtil.isObjNull(dto.getStatus())) {
			predicates.addAll(refStatusSvc.generateCriteria(cb, status, dto.getStatus()));
		}

		if (dto.isEmbedTrip()) {
			Join<BeTvl, BeTvlTrip> tvlTrip = from.join("tvlTrip", JoinType.LEFT);
			predicates.addAll(beTvlTripQf.generateCriteria(cb, tvlTrip, dto));
		}

		if (dto.isEmbedMedical()) {
			Join<BeTvlProfile, BeTvlMcAttendance> tvlMcAttendances = tvlProfile.join("tvlMcAttendances",
					JoinType.LEFT);
			if (!BaseUtil.isObjNull(dto.getAttendanceDtFrom()) || !BaseUtil.isObjNull(dto.getAttendanceDtTo())
					|| !BaseUtil.isObjNull(dto.getMcProfId())) {
				predicates.addAll(beTvlMcAttendanceQf.generateCriteria(cb, tvlMcAttendances, dto));
			}
		}

		if (dto.isEmbedPayment() && !BaseUtil.isObjNull(dto.getTvlPayment())) {
			Join<BeTvl, BeTvlPayment> payment = from.join("tvlPayment", JoinType.LEFT);
			predicates.addAll(beTvlPaymentQf.generateCriteria(cb, payment, dto.getTvlPayment()));
		}

		if (!BaseUtil.isObjNull(dto.getCountryCd())) {
			Country countryDto = null;
			if (!BaseUtil.isObjNull(dto.getCountryCd())) {
				countryDto = new Country();
				countryDto.setCntryCd(dto.getCountryCd());
			}
			Join<BeTvlProfile, RefCountry> country = tvlProfile.join("country", JoinType.LEFT);
			predicates.addAll(refCountrySvc.generateCriteria(cb, country, countryDto));
		}

		if (!BaseUtil.isObjNull(dto.getStatusCd())) {
			if (BaseUtil.isEquals(BeServiceConstants.STATUS_CD_INS_UPD, dto.getStatusCd())) {
				predicates.add(from.get("tvlInsurance").isNotNull());
			} else if (BaseUtil.isEquals(BeServiceConstants.STATUS_CD_INS_PNDG, dto.getStatusCd())) {
				predicates.add(from.get("tvlInsurance").isNull());
			}
		}

		cq.select(cb.count(from));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			Tvl dto = JsonUtil.transferToObject(criteria, Tvl.class);
			if (!BaseUtil.isObjNull(dto.getTvlId())) {
				predicates.add(cb.equal(from.get("tvlId"), dto.getTvlId()));
			}

			if (!BaseUtil.isObjNull(dto.getIsActive())) {
				predicates.add(cb.equal(from.get("isActive"), dto.getIsActive()));
			}

			if (!BaseUtil.isObjNull(dto.getCreateDtFrom())) {
				predicates.add(cb.greaterThanOrEqualTo(from.get("createDt"), dto.getCreateDtFrom()));
			}

			if (!BaseUtil.isObjNull(dto.getCreateDtTo())) {
				predicates.add(cb.lessThanOrEqualTo(from.get("createDt"), dto.getCreateDtTo()));
			}

		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void joinFetch(From<?, ?> from, List<Predicate> predicates, Tvl dto, CriteriaQuery<?> cq) {

		Join<BeTvl, BeTvlProfile> tvlProfile = (Join) from.fetch("tvlProfile", JoinType.LEFT);
		predicates.addAll(beTvlProfileSvc.generateCriteria(cb, tvlProfile, dto.getTvlProfile()));
		tvlProfile.fetch("nationality", JoinType.LEFT);
		tvlProfile.fetch("relationMtdt", JoinType.LEFT);
		tvlProfile.fetch("typeMtdt", JoinType.LEFT);
		tvlProfile.fetch("ecRelationMtdt", JoinType.LEFT);
		tvlProfile.fetch("birthPlace", JoinType.LEFT);
		// tvlProfile.fetch("riskStatus", JoinType.LEFT);
		Join<BeTvlProfile, BeAcctPassport> acctPassport = (Join) tvlProfile.fetch("acctPassport", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getTvlProfile()) && !BaseUtil.isObjNull(dto.getTvlProfile().getAcctPassport())) {
			predicates.addAll(
					beAcctPassportSvc.generateCriteria(cb, acctPassport, dto.getTvlProfile().getAcctPassport()));
		}
		acctPassport.fetch("nationality", JoinType.LEFT);

		Join<BeTvl, BeConfigRiskStatus> riskStatus = (Join) from.fetch("riskStatus", JoinType.LEFT);
		predicates.addAll(beConfigRiskStatusSvc.generateCriteria(cb, riskStatus, dto));

		if (!BaseUtil.isObjNull(dto.getCountryCd())) {
			Country countryDto = null;
			if (!BaseUtil.isObjNull(dto.getCountryCd())) {
				countryDto = new Country();
				countryDto.setCntryCd(dto.getCountryCd());
			}
			Join<BeTvlProfile, RefCountry> country = (Join) tvlProfile.fetch("country", JoinType.LEFT);
			predicates.addAll(refCountrySvc.generateCriteria(cb, country, countryDto));
		}

		if (dto.isEmbedTraveller()) {
			tvlProfile.fetch("acctTraveller", JoinType.LEFT);
		} else if (!BaseUtil.isObjNull(dto.getAcctTvlrId())) {
			AcctTraveller atDto = new AcctTraveller();
			atDto.setAcctTvlrId(dto.getAcctTvlrId());
			Join<BeTvlProfile, BeAcctTraveller> acctTraveller = (Join) tvlProfile.fetch("acctTraveller",
					JoinType.LEFT);
			predicates.addAll(beAcctTravellerQf.generateCriteria(cb, acctTraveller, dto));
		}

		if (!BaseUtil.isObjNull(dto.getAcctProfId()) || !BaseUtil.isObjNull(dto.getAcctProfile())) {
			if (BaseUtil.isObjNull(dto.getAcctProfile())) {
				dto.setAcctProfile(new AcctProfile());
				dto.getAcctProfile().setAcctProfId(dto.getAcctProfId());
			}
			Join<BeTvl, BeAcctProfile> acctProfile = (Join) from.fetch("acctProfile", JoinType.INNER);
			predicates.addAll(beAcctProfileSvc.generateCriteria(cb, acctProfile, dto.getAcctProfile()));
		} else if (dto.isEmbedAcctProfile()) {
			from.fetch("acctProfile", JoinType.INNER);
		}

		Join<BeTvl, RefStatus> status = (Join) from.fetch("status", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getStatusId()) || !BaseUtil.isListNull(dto.getStatusIdList())
				|| !BaseUtil.isObjNull(dto.getStatusIdNotInList())) {
			predicates.addAll(refStatusSvc.generateCriteria(cb, status, dto));
		} else if (!BaseUtil.isObjNull(dto.getStatus())) {
			predicates.addAll(refStatusSvc.generateCriteria(cb, status, dto.getStatus()));
		}

		if (dto.isEmbedTrip()) {
			Join<BeTvl, BeTvlTrip> tvlTrip = (Join) from.fetch("tvlTrip", JoinType.LEFT);
			tvlTrip.fetch("departureAirport", JoinType.LEFT);
			tvlTrip.fetch("arrivalAirport", JoinType.LEFT);
			tvlTrip.fetch("tripHealths", JoinType.LEFT);
			tvlTrip.fetch("departureAirportRtn", JoinType.LEFT);
			tvlTrip.fetch("arrivalAirportRtn", JoinType.LEFT);
			predicates.addAll(beTvlTripQf.generateCriteria(cb, tvlTrip, dto));

			Join<BeTvlTrip, BeTripAccommodation> tripAccomodation = (Join) tvlTrip.fetch("tripAccommodations",
					JoinType.LEFT);
			tripAccomodation.fetch("typeMtdt", JoinType.LEFT);

		}

		if (dto.isEmbedPayment()) {

			Join<BeTvl, BeTvlPayment> payment = (Join) from.fetch("tvlPayment", JoinType.LEFT);
			if (!BaseUtil.isObjNull(dto.getTvlPayment())) {
				predicates.addAll(beTvlPaymentQf.generateCriteria(cb, payment, dto.getTvlPayment()));
			}
			payment.fetch("pmtMthdMtdt", JoinType.LEFT);
			if (dto.isEmbedPaymentDtl()) {
				Join<BeTvlPayment, BeTvlPaymentDtl> paymentDtl = (Join) payment.fetch("beTvlPaymentDtls",
						JoinType.LEFT);
				paymentDtl.fetch("tvlPaymentInfos", JoinType.LEFT);
				paymentDtl.fetch("tvlRefunds", JoinType.LEFT);
			}
		}

		if (dto.isEmbedInsurance()) {
			from.fetch("tvlInsurance", JoinType.LEFT);
			if (!BaseUtil.isObjNull(dto.getStatusCd())) {
				if (BaseUtil.isEquals(BeServiceConstants.STATUS_CD_INS_UPD, dto.getStatusCd())) {
					predicates.add(from.get("tvlInsurance").isNotNull());
				} else if (BaseUtil.isEquals(BeServiceConstants.STATUS_CD_INS_PNDG, dto.getStatusCd())) {
					predicates.add(from.get("tvlInsurance").isNull());
				}
			}
		}

		if (dto.isEmbedMedical()) {
			Join<BeTvlProfile, BeTvlMcAttendance> tvlMcAttendances = (Join) tvlProfile.fetch("tvlMcAttendances",
					JoinType.LEFT);
			if (!BaseUtil.isObjNull(dto.getAttendanceDtFrom()) || !BaseUtil.isObjNull(dto.getAttendanceDtTo())
					|| !BaseUtil.isObjNull(dto.getMcProfId())) {
				predicates.addAll(beTvlMcAttendanceQf.generateCriteria(cb, tvlMcAttendances, dto));
			}
			// tvlProfile.fetch("tvlMcAttendances", JoinType.LEFT);
			tvlProfile.fetch("tvlTestResults", JoinType.LEFT);
		}

		if (dto.isEmbedDQStat()) {
			from.fetch("tvlStats", JoinType.LEFT);
			Join<BeTvl, BeTvlStat> stat = (Join) from.fetch("tvlStats", JoinType.LEFT);
			if (dto.isEmbedDQStat()) {
				stat.fetch("dqStatMtdt", JoinType.LEFT);
				stat.fetch("remarksMtdt", JoinType.LEFT);
			}
		}
	}
}
