/**
 *
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author roziana
 * @since Feb 15, 2019
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class DigitalIdInfo implements Serializable {

	private static final long serialVersionUID = 253291042445333790L;

	private String ownerName;

	private String deviceName;

	private String certStatus;

	private Date expiryDate;

	private Date generateDate;

	private Integer certId;

	private String certRefNo;

	private Integer applId;

	private String refno;

	private Integer userType;

	private String email;

	private String phoneNo;

	private String title;

	private String firstName;

	private String lastName;

	private String address;

	private String postcode;

	private String cert;

	private Date generateDt;

	private Date expiredDt;

	private Date approveDt;

	private Date revokeDt;

	private String status;

	private String remarks;


	public String getOwnerName() {
		return ownerName;
	}


	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}


	public String getDeviceName() {
		return deviceName;
	}


	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}


	public String getCertStatus() {
		return certStatus;
	}


	public void setCertStatus(String certStatus) {
		this.certStatus = certStatus;
	}


	public Date getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}


	public Date getGenerateDate() {
		return generateDate;
	}


	public void setGenerateDate(Date generateDate) {
		this.generateDate = generateDate;
	}


	public Integer getCertId() {
		return certId;
	}


	public void setCertId(Integer certId) {
		this.certId = certId;
	}


	public String getCertRefNo() {
		return certRefNo;
	}


	public void setCertRefNo(String certRefNo) {
		this.certRefNo = certRefNo;
	}


	public Integer getApplId() {
		return applId;
	}


	public void setApplId(Integer applId) {
		this.applId = applId;
	}


	public String getRefno() {
		return refno;
	}


	public void setRefno(String refno) {
		this.refno = refno;
	}


	public Integer getUserType() {
		return userType;
	}


	public void setUserType(Integer userType) {
		this.userType = userType;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getCert() {
		return cert;
	}


	public void setCert(String cert) {
		this.cert = cert;
	}


	public Date getGenerateDt() {
		return generateDt;
	}


	public void setGenerateDt(Date generateDt) {
		this.generateDt = generateDt;
	}


	public Date getExpiredDt() {
		return expiredDt;
	}


	public void setExpiredDt(Date expiredDt) {
		this.expiredDt = expiredDt;
	}


	public Date getApproveDt() {
		return approveDt;
	}


	public void setApproveDt(Date approveDt) {
		this.approveDt = approveDt;
	}


	public Date getRevokeDt() {
		return revokeDt;
	}


	public void setRevokeDt(Date revokeDt) {
		this.revokeDt = revokeDt;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
