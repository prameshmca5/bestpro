package com.bestpay.web.idm.validator;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.model.MerGenInfo;
import com.bestpay.be.sdk.model.MerPayPageSet;
import com.bestpay.be.sdk.model.MerSendAccInfo;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ValidationUtil;


@Component("sendAcctInfoValidator")
public class SendAcctInfoValidator extends AbstractController implements Validator {

	private static final Logger LOGGER = LoggerFactory.getLogger(SendAcctInfoValidator.class);


	@Override
	public boolean supports(Class<?> clazz) {
		return MerSendAccInfo.class.equals(clazz);
	}


	@Override
	public void validate(Object object, Errors errors) {
		if (object instanceof MerSendAccInfo) {
			MerSendAccInfo sendAccInfo = (MerSendAccInfo) object;
			MerAccInfo merAccInfo = null;
			MerGenInfo merGenInfo = null;
			MerPayPageSet payPageSet = null;
			try {
				merAccInfo = getBeService().getAccInfoById(sendAccInfo.getMerchantId());
				merGenInfo = getBeService().getGenInfoById(sendAccInfo.getMerchantId());
				payPageSet = getBeService().getMerPayPageSetById(sendAccInfo.getMerchantId());
			} catch (BeException e) {
				LOGGER.info(e.getMessage());
			}
			validateAccInfo(merAccInfo, errors);
			validateGenInfo(merGenInfo, errors);
			validatePayPageSet(payPageSet, errors);
		}
	}


	private void validateAccInfo(MerAccInfo merAccInfo, Errors errors) {
		if (merAccInfo != null && merAccInfo.getEmail() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa", MessageConstants.ERROR_FIELDS_ACTV_EMAIL);
		}
		if (merAccInfo != null && merAccInfo.getCompany() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa", MessageConstants.ERROR_FIELDS_ACTV_COMPANY);
		}
		if (merAccInfo != null && merAccInfo.getOwnerDirectorNationalId() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa",
					MessageConstants.ERROR_FIELDS_ACTV_COMPANY_OWNERID);
		}
		if (merAccInfo != null && merAccInfo.getAcStatus() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa", MessageConstants.ERROR_FIELDS_ACTV_ACC_STATUS);
		}
		if (merAccInfo != null && merAccInfo.getCompanyRefId() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa",
					MessageConstants.ERROR_FIELDS_ACTV_COMPANY_REFERRAL);
		}

	}


	private void validateGenInfo(MerGenInfo merGenInfo, Errors errors) {
		if (merGenInfo != null && merGenInfo.getCountry() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa", MessageConstants.ERROR_FIELDS_ACTV_COUNTRY);
		}
		if (merGenInfo != null && merGenInfo.getAddress() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa", MessageConstants.ERROR_FIELDS_ACTV_ADDRESS);
		}
		if (merGenInfo != null && merGenInfo.getState() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa", MessageConstants.ERROR_FIELDS_ACTV_STATE);
		}
		if (merGenInfo != null && merGenInfo.getCity() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa", MessageConstants.ERROR_FIELDS_ACTV_CITY);
		}
		if (merGenInfo != null && merGenInfo.getPostcode() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa", MessageConstants.ERROR_FIELDS_ACTV_POST_CODE);
		}
	}


	private void validatePayPageSet(MerPayPageSet merPayPageSet, Errors errors) {
		if (merPayPageSet != null && merPayPageSet.getVerifyKey() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa", MessageConstants.ERROR_FIELDS_ACTV_VERIFY_KEY);
		}
		if (merPayPageSet != null && merPayPageSet.getReturnUrl() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa", MessageConstants.ERROR_FIELDS_ACTV_RETURN_URL);
		}
		if (merPayPageSet != null && merPayPageSet.getCallbackUrl() == null) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa",
					MessageConstants.ERROR_FIELDS_ACTV_CALLBACK_URL);
		}
	}

}
