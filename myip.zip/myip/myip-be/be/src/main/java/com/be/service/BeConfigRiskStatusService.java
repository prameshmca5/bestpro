/**
 *
 */
package com.be.service;


import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeConfigRiskStatusQf;
import com.be.dao.BeConfigRiskStatusRepository;
import com.be.model.BeConfigRiskStatus;
import com.be.sdk.model.IQfCriteria;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_CONFIG_RISK_STATUS_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_CONFIG_RISK_STATUS_SVC)
public class BeConfigRiskStatusService extends AbstractService<BeConfigRiskStatus> {

	@Autowired
	BeConfigRiskStatusRepository beConfigRiskStatusDao;

	@Autowired
	BeConfigRiskStatusQf beConfigRiskStatusQf;


	@Override
	public GenericRepository<BeConfigRiskStatus> primaryDao() {
		return beConfigRiskStatusDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beConfigRiskStatusQf.generateCriteria(cb, from, criteria);
	}

}
