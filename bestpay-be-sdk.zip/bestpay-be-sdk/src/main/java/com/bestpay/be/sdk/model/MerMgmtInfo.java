/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;


/**
 * @author Atiqah
 * @since June 7, 2018
 */
public class MerMgmtInfo implements Serializable {

	private String merchantName;

	private String company;

	private String status;


	public String getMerchantName() {
		return merchantName;
	}


	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}


	public String getCompany() {
		return company;
	}


	public void setCompany(String company) {
		this.company = company;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}
}