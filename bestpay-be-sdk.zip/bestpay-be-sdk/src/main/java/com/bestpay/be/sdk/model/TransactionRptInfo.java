/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import com.bestpay.be.sdk.constants.BaseConstants;
import com.bstsb.util.serializer.JsonDateSerializer;
import com.bstsb.util.serializer.JsonTimestampSerializer;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;


/**
 * Afif Saman 21 June 2018
 */
public class TransactionRptInfo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -1890927632233838184L;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH)
	private Date fromDate;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH)
	private Date toDate;

	@JsonSerialize(using = JsonTimestampSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH_TIME_A)
	private Timestamp createDt;

	private String transId;

	private String orderId;

	private String channel;

	private String billingName;

	private Float billAmt;

	private Float actAmt;

	private String status;

	private String actCur;

	private String billingEmail;

	private String billingInfo;

	private Float transRate;

	private String addField;

	private String merchantId;

	private Integer merProfId;

	private Integer setId;

	private Boolean isAdmin;

	// Create Date for printed report. Default format.
	private Timestamp createDateReport;


	public TransactionRptInfo() {
		// transaction report info dto model
	}


	public Date getFromDate() {
		return fromDate;
	}


	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}


	public Date getToDate() {
		return toDate;
	}


	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}


	public String getTransId() {
		return transId;
	}


	public void setTransId(String transId) {
		this.transId = transId;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public String getBillingName() {
		return billingName;
	}


	public void setBillingName(String billingName) {
		this.billingName = billingName;
	}


	public String getBillingEmail() {
		return billingEmail;
	}


	public void setBillingEmail(String billingEmail) {
		this.billingEmail = billingEmail;
	}


	public String getBillingInfo() {
		return billingInfo;
	}


	public void setBillingInfo(String billingInfo) {
		this.billingInfo = billingInfo;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public Float getBillAmt() {
		return billAmt;
	}


	public void setBillAmt(Float billAmt) {
		this.billAmt = billAmt;
	}


	public Float getTransRate() {
		return transRate;
	}


	public void setTransRate(Float transRate) {
		this.transRate = transRate;
	}


	public String getActCur() {
		return actCur;
	}


	public void setActCur(String actCur) {
		this.actCur = actCur;
	}


	public Float getActAmt() {
		return actAmt;
	}


	public void setActAmt(Float actAmt) {
		this.actAmt = actAmt;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getAddField() {
		return addField;
	}


	public void setAddField(String addField) {
		this.addField = addField;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public Timestamp getCreateDateReport() {
		return createDateReport;
	}


	public void setCreateDateReport(Timestamp createDateReport) {
		this.createDateReport = createDateReport;
	}


	public Integer getMerProfId() {
		return merProfId;
	}


	public void setMerProfId(Integer merProfId) {
		this.merProfId = merProfId;
	}


	public Integer getSetId() {
		return setId;
	}


	public void setSetId(Integer setId) {
		this.setId = setId;
	}


	public Boolean getIsAdmin() {
		return isAdmin;
	}


	public void setIsAdmin(boolean isAdmin2) {
		isAdmin = isAdmin2;
	}

}