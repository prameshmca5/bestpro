package com.bestpay.be.sdk.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "RegisterBeneficiaryResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class RegisterBeneficiaryResult {

	@XmlElement(name = "CODE")
	private String code;

	@XmlElement(name = "MESSAGE")
	private String message;

	@XmlElement(name = "SenderCustomerID")
	private String senderCustomerId;

	@XmlElement(name = "BeneficiarySno")
	private String beneficiarySno;


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public String getSenderCustomerId() {
		return senderCustomerId;
	}


	public void setSenderCustomerId(String senderCustomerId) {
		this.senderCustomerId = senderCustomerId;
	}


	public String getBeneficiarySno() {
		return beneficiarySno;
	}


	public void setBeneficiarySno(String beneficiarySno) {
		this.beneficiarySno = beneficiarySno;
	}

}
