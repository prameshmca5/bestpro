/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
@JsonIgnoreProperties(ignoreUnknown = false)
@JsonInclude(Include.NON_NULL)
public class Documents implements Serializable {

	private static final long serialVersionUID = 106316930304813799L;

	private String id;

	private String refno;

	private String docid;

	private String txnno;

	private String filesId;

	private String filename;

	private long length;

	private String contentType;

	private String version;

	private Timestamp uploadDate;

	private byte[] content;


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getRefno() {
		return refno;
	}


	public void setRefno(String refno) {
		this.refno = refno;
	}


	public String getDocid() {
		return docid;
	}


	public void setDocid(String docid) {
		this.docid = docid;
	}


	public String getTxnno() {
		return txnno;
	}


	public void setTxnno(String txnno) {
		this.txnno = txnno;
	}


	public String getFilesId() {
		return filesId;
	}


	public void setFilesId(String filesId) {
		this.filesId = filesId;
	}


	public String getFilename() {
		return filename;
	}


	public void setFilename(String filename) {
		this.filename = filename;
	}


	public long getLength() {
		return length;
	}


	public void setLength(long length) {
		this.length = length;
	}


	public String getContentType() {
		return contentType;
	}


	public void setContentType(String contentType) {
		this.contentType = contentType;
	}


	public String getVersion() {
		return version;
	}


	public void setVersion(String version) {
		this.version = version;
	}


	public Timestamp getUploadDate() {
		return uploadDate;
	}


	public void setUploadDate(Timestamp uploadDate) {
		this.uploadDate = uploadDate;
	}


	public byte[] getContent() {
		return content;
	}


	public void setContent(byte[] content) {
		this.content = content;
	}
}