package com.bestpay.web.cmn.controller;


import java.io.IOException;
import java.util.List;

import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;


@Controller
@RequestMapping(value = PageConstants.PAGE_EXCHANGE_RATE)
public class ExchangeRateController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExchangeRateController.class);

	private static final String CLASS = "class";


	@GetMapping
	public ModelAndView view() {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_EXCHANGE_RATE, "exchangeRate", null, null);
		String instarem;
		int count = 0;
		do {

			instarem = instarem();
			count++;
		} while (instarem.length() <= 10 || count <= 5);
		mav.addObject("instarem", instarem);
		mav.addObject("incentiveRemit", moneyConverterIncentiveRemit());
		return mav;
	}


	public String monito() {
		System.setProperty("webdriver.chrome.driver", "c:\\venu\\chromedriver.exe");
		WebDriver browser = new ChromeDriver();
		browser.get(
				"https://www.monito.com/send-money/malaysia/indonesia/myr/idr/1?mail=&location=Homepage&location_page=null");

		List<WebElement> spanList = browser.findElements(By.tagName("span"));
		for (WebElement el : spanList) {
			if (el.getAttribute(CLASS) != null && (el.getAttribute(CLASS)
					.equals("m-text-h3 m-text-secondary result-psp-info_received_amount_1bT90")
					|| el.getAttribute(CLASS).equals("rate-amount color-primary"))) {
				LOGGER.info(el.getText());
			}
			if (el.getAttribute(CLASS) != null && (el.getAttribute(CLASS)
					.equals("result-psp-info_received_amount_1bT90 m-text-h3 m-text-secondary mr-2")
					|| el.getAttribute(CLASS).equals("rate-amount color-primary"))) {
				LOGGER.info(el.getText());
			}
		}

		return null;
	}


	// Instarem exchange rate pulled from monito.com
	public String instarem() {

		StringBuilder sb = new StringBuilder(" 1 MYR = ");
		try {

			System.setProperty("https.protocols", "TLSv1.2");
			// 2. Fetch the HTML code
			Response res = Jsoup.connect(
					"https://www.monito.com/send-money/malaysia/indonesia/myr/idr/1?mail=&location=Homepage&location_page=null")
					.followRedirects(false).timeout(0).data("is_check", "1").execute();
			Document document = res.parse();

			// 3. Parse the HTML to extract links to other URLs
			Elements linksOnPage = document
					.getElementsByClass("m-text-h3 m-text-secondary result-psp-info_received_amount_1bT90");

			Elements linksOnPage1 = document
					.getElementsByClass("result-psp-info_received_amount_1bT90 m-text-h3 m-text-secondary mr-2");

			Elements linksOnPage2 = document
					.getElementsByClass("result-psp-info_received_amount_1Dtxs f-28 f-33-md fw-bold mr-2");

			// 5. For each extracted URL... go back to Step 4.
			for (Element page : linksOnPage) {
				sb.append(page.text());
			}
			for (Element page : linksOnPage1) {
				sb.append(page.text());
			}

			for (Element page : linksOnPage2) {
				sb.append(page.text());
			}
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}

		return sb.toString();
	}


	// IncentiveRemit exchange rate pulled from themoneyconverter
	public String moneyConverterIncentiveRemit() {

		StringBuilder sb = new StringBuilder(" ");
		try {

			System.setProperty("https.protocols", "TLSv1.2");
			Document document = Jsoup.connect("https://themoneyconverter.com/MYR/IDR").get();
			Elements linksOnPage = document.getElementsByClass("cc-rate");

			for (Element page : linksOnPage) {
				sb.append(page.text());
			}
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		}

		return sb.toString();
	}

}
