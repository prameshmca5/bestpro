/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


public class OnlinePaymentInfoDto implements Serializable {

	private static final long serialVersionUID = -3186445980890420147L;

	private int id;

	private int refid;

	private String paymentType;

	private Date paymentDate;

	private BigDecimal amount;

	private String sellerExOrderNo;

	private String sellerOrderNo;

	private String fpxSellerTxnTime;

	private String buyerEmail;

	private String buyerName;

	private String buyerBankId;

	private String buyerId;

	private String fpxProdDesc;

	private String fpxVersion;

	private String requestCode;

	private String responseCode;

	private String responseMsg;

	private int retryCount;

	private String fpxDebitAuthCode;

	private String fpxDebitAuthNo;

	private String fpxFpxTxId;

	private String createId;

	private Date createDate;

	private String updateId;

	private Date updateDate;

	private String fpxMsgtoken;

	private String sellerId;

	private String sellerExchangeId;


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getRefid() {
		return refid;
	}


	public void setRefid(int refid) {
		this.refid = refid;
	}


	public String getPaymentType() {
		return paymentType;
	}


	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}


	public Date getPaymentDate() {
		return paymentDate;
	}


	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}


	public BigDecimal getAmount() {
		return amount;
	}


	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}


	public String getSellerExOrderNo() {
		return sellerExOrderNo;
	}


	public void setSellerExOrderNo(String sellerExOrderNo) {
		this.sellerExOrderNo = sellerExOrderNo;
	}


	public String getSellerOrderNo() {
		return sellerOrderNo;
	}


	public void setSellerOrderNo(String sellerOrderNo) {
		this.sellerOrderNo = sellerOrderNo;
	}


	public String getFpxSellerTxnTime() {
		return fpxSellerTxnTime;
	}


	public void setFpxSellerTxnTime(String fpxSellerTxnTime) {
		this.fpxSellerTxnTime = fpxSellerTxnTime;
	}


	public String getBuyerEmail() {
		return buyerEmail;
	}


	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}


	public String getBuyerName() {
		return buyerName;
	}


	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}


	public String getBuyerBankId() {
		return buyerBankId;
	}


	public void setBuyerBankId(String buyerBankId) {
		this.buyerBankId = buyerBankId;
	}


	public String getBuyerId() {
		return buyerId;
	}


	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}


	public String getFpxProdDesc() {
		return fpxProdDesc;
	}


	public void setFpxProdDesc(String fpxProdDesc) {
		this.fpxProdDesc = fpxProdDesc;
	}


	public String getFpxVersion() {
		return fpxVersion;
	}


	public void setFpxVersion(String fpxVersion) {
		this.fpxVersion = fpxVersion;
	}


	public String getResponseCode() {
		return responseCode;
	}


	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}


	public String getResponseMsg() {
		return responseMsg;
	}


	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}


	public String getFpxDebitAuthCode() {
		return fpxDebitAuthCode;
	}


	public void setFpxDebitAuthCode(String fpxDebitAuthCode) {
		this.fpxDebitAuthCode = fpxDebitAuthCode;
	}


	public String getFpxDebitAuthNo() {
		return fpxDebitAuthNo;
	}


	public void setFpxDebitAuthNo(String fpxDebitAuthNo) {
		this.fpxDebitAuthNo = fpxDebitAuthNo;
	}


	public String getFpxFpxTxId() {
		return fpxFpxTxId;
	}


	public void setFpxFpxTxId(String fpxFpxTxId) {
		this.fpxFpxTxId = fpxFpxTxId;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Date getCreateDate() {
		return createDate;
	}


	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Date getUpdateDate() {
		return updateDate;
	}


	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}


	public String getRequestCode() {
		return requestCode;
	}


	public void setRequestCode(String requestCode) {
		this.requestCode = requestCode;
	}


	public int getRetryCount() {
		return retryCount;
	}


	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}


	public String getFpxMsgtoken() {
		return fpxMsgtoken;
	}


	public void setFpxMsgtoken(String fpxMsgtoken) {
		this.fpxMsgtoken = fpxMsgtoken;
	}


	public String getSellerId() {
		return sellerId;
	}


	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}


	public String getSellerExchangeId() {
		return sellerExchangeId;
	}


	public void setSellerExchangeId(String sellerExchangeId) {
		this.sellerExchangeId = sellerExchangeId;
	}

}
