/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * @author
 * @since 27/09/2018
 */
@Entity
@Table(name = "REF_FPX_RESPONSE_CODE")
public class RefFpxResponseCode extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -3186445980890420147L;

	@Id
	@Column(name = "FPX_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@Column(name = "FPX_CODE")
	private String fpxCode;

	@Column(name = "FPX_DESCRIPTION")
	private String fpxDescription;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	/*
	 * 00- success 01- pending 02- fail
	 */
	@Column(name = "RESP_CODE")
	private String respCode;


	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}


	/**
	 * @param id
	 *             the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}


	/**
	 * @return the fpxCode
	 */
	public String getFpxCode() {
		return fpxCode;
	}


	/**
	 * @param fpxCode
	 *             the fpxCode to set
	 */
	public void setFpxCode(String fpxCode) {
		this.fpxCode = fpxCode;
	}


	/**
	 * @return the fpxDescription
	 */
	public String getFpxDescription() {
		return fpxDescription;
	}


	/**
	 * @param fpxDescription
	 *             the fpxDescription to set
	 */
	public void setFpxDescription(String fpxDescription) {
		this.fpxDescription = fpxDescription;
	}


	/**
	 * @return the createId
	 */
	@Override
	public String getCreateId() {
		return createId;
	}


	/**
	 * @param createId
	 *             the createId to set
	 */
	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	/**
	 * @return the createDt
	 */
	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	/**
	 * @param createDt
	 *             the createDt to set
	 */
	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	/**
	 * @return the updateDt
	 */
	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	/**
	 * @param updateDt
	 *             the updateDt to set
	 */
	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	/**
	 * @return the updateId
	 */
	@Override
	public String getUpdateId() {
		return updateId;
	}


	/**
	 * @param updateId
	 *             the updateId to set
	 */
	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public String getRespCode() {
		return respCode;
	}


	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

}
