/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.TextLayout;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bestpay.idm.sdk.constants.BaseConstants;
import com.bestpay.idm.sdk.util.BaseUtil;


/**
 * @author Mary Jane Buenaventura
 * @since May 17, 2018
 */
public class CaptchaGenerator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CaptchaGenerator.class);

	public static final String CPTCHVAL = "CPTCHVAL";

	public static final String CPTCHIMG = "CPTCHIMG";

	char[] chars = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U',
			'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'm', 'n', 'p', 'q', 'r', 's',
			't', 'v', 'w', 'x', 'y', 'z' };

	char[] digits = { '1', '2', '3', '4', '5', '6', '7', '8', '9' };

	private int width = 400;

	private int height = 120;

	StringBuilder captchaVal = new StringBuilder();

	private String fontType = "Arial";

	private int fontStyle = Font.BOLD;

	private int fontSize = 72;

	Random r = new Random();


	public CaptchaGenerator() {
	}


	public CaptchaGenerator(String fontType, Integer fontStyle, Integer fontSize) {
		if (!BaseUtil.isObjNull(fontType)) {
			this.fontType = fontType;
		}
		if (!BaseUtil.isObjNull(fontStyle)) {
			this.fontStyle = fontStyle;
		}
		if (!BaseUtil.isObjNull(fontSize)) {
			this.fontSize = fontSize;
		}
	}


	private char[] getText(int digit) {
		char[] selected = new char[digit];
		for (int i = 0; i < digit; i++) {
			int selectArr = (int) Math.floor((double) r.nextInt() * digit);
			if (selectArr > 5) {
				int selectDigit = (int) Math.floor((double) r.nextInt() * digit);
				selectDigit = (selectDigit == 9) ? 8 : selectDigit;
				selected[i] = digits[selectDigit];
			} else {
				int selectChar = (int) Math.floor((double) r.nextInt() * (chars.length - 1));
				selected[i] = chars[selectChar];
			}
		}
		return selected;
	}


	public Map<String, Object> getCaptchaShadowedText(int digit) {
		Map<String, Object> map = new HashMap<>();
		String stringDigit = Integer.toString(digit);
		map.put(CPTCHIMG, createImage(stringDigit));
		LOGGER.debug("captchaVal: {}", captchaVal);
		map.put(CPTCHVAL, captchaVal);
		return map;
	}


	public Map<String, Object> getCaptchaSplitTwo(int digit) {
		Map<String, Object> map = new HashMap<>();
		map.put(CPTCHIMG, createImage(digit));
		LOGGER.debug("captchaVal: {}", captchaVal);
		map.put(CPTCHVAL, captchaVal);
		return map;
	}


	private BufferedImage createImage(int digit) {
		int x = 50;
		int y = 80;

		captchaVal = new StringBuilder(BaseConstants.EMPTY_STRING);

		char[] selected = new char[digit];

		for (char element : selected) {
			captchaVal.append(String.valueOf(element));
		}

		Font font = new Font(fontType, fontStyle, fontSize);

		BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

		Graphics2D g1 = image.createGraphics();
		setRenderingHints(g1);

		TextLayout textLayout = new TextLayout(captchaVal.toString(), font, g1.getFontRenderContext());
		g1.setPaint(Color.LIGHT_GRAY);
		g1.fillRect(0, 0, width, height);
		g1.setPaint(new Color(150, 150, 150));
		textLayout.draw(g1, (float) x + 5, (float) y + 5);
		g1.dispose();

		float[] kernel = { 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f };

		ConvolveOp op = new ConvolveOp(new Kernel(3, 3, kernel), ConvolveOp.EDGE_NO_OP, null);
		BufferedImage image2 = op.filter(image, null);

		Graphics2D g2 = image2.createGraphics();
		setRenderingHints(g2);
		g2.setPaint(Color.BLACK);
		textLayout.draw(g2, x, y);

		return image2;
	}


	private BufferedImage createImage(String digit) {
		int x = 50;
		int y = 80;

		captchaVal = new StringBuilder(BaseConstants.EMPTY_STRING);

		char[] selected = getText(Integer.parseInt(digit));

		for (char element : selected) {
			captchaVal.append(String.valueOf(element));
		}

		Font font = new Font(fontType, fontStyle, fontSize);

		BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

		Graphics2D g1 = image.createGraphics();
		setRenderingHints(g1);

		TextLayout textLayout = new TextLayout(captchaVal.toString(), font, g1.getFontRenderContext());
		g1.setPaint(Color.LIGHT_GRAY);
		g1.fillRect(0, 0, width, height);
		g1.setPaint(new Color(150, 150, 150));
		textLayout.draw(g1, (float) x + 5, (float) y + 5);
		g1.dispose();

		float[] kernel = { 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f };

		ConvolveOp op = new ConvolveOp(new Kernel(3, 3, kernel), ConvolveOp.EDGE_NO_OP, null);
		BufferedImage image2 = op.filter(image, null);

		Graphics2D g2 = image2.createGraphics();
		setRenderingHints(g2);
		g2.setPaint(Color.BLACK);
		textLayout.draw(g2, x, y);

		return image2;
	}


	private void setRenderingHints(Graphics2D g) {
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
	}

}