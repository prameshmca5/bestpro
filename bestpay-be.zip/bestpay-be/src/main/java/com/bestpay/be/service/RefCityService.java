package com.bestpay.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.RefCityRepository;
import com.bestpay.be.model.RefCity;
import com.bestpay.be.sdk.constants.BeCacheConstants;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Md Asif Aftab
 * @since 27th Feb 2018
 */

@Service(QualifierConstants.APJ_CITY_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.APJ_CITY_SVC)
@Transactional
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
public class RefCityService extends AbstractService<RefCity> {

	@Autowired
	private RefCityRepository cityDao;


	@Cacheable(key = "T(com.bestpay.be.sdk.constants.BeCacheConstants).CACHE_KEY_CITY_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	@Override
	public List<RefCity> findAll() {
		return cityDao.findAll();
	}


	@Cacheable(key = "T(com.bestpay.be.sdk.constants.BeCacheConstants).CACHE_KEY_CITY.concat(#cityCode)", condition = "#cityCode != null and #result != null")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public RefCity findByCityCode(String cityCode) {
		return cityDao.findByCityCode(cityCode);
	}


	@Cacheable(key = "T(com.bestpay.be.sdk.constants.BeCacheConstants).CACHE_KEY_CITY_STATE.concat(#cityCode)", condition = "#cityCode != null and #state!=null and #result != null")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public RefCity findByCityStateCode(String cityCode, String stateCode) {
		return cityDao.findByCityStateCode(cityCode, stateCode);
	}


	@Override
	@Caching(evict = {
			@CacheEvict(beforeInvocation = true, key = "T(com.bestpay.be.sdk.constants.BeCacheConstants).CACHE_KEY_CITY_ALL"), }, put = {
					@CachePut(key = "T(com.bestpay.be.sdk.constants.BeCacheConstants).CACHE_KEY_CITY.concat(#s.cityCode)") })
	public RefCity create(RefCity s) {
		return super.create(s);
	}


	@Override
	@Caching(evict = {
			@CacheEvict(beforeInvocation = true, key = "T(com.bestpay.be.sdk.constants.BeCacheConstants).CACHE_KEY_CITY_ALL"),
			@CacheEvict(beforeInvocation = true, key = "T(com.bestpay.be.sdk.constants.BeCacheConstants).CACHE_KEY_CITY.concat(#s.cityCode)") })
	public RefCity update(RefCity s) {
		return super.update(s);
	}


	@Override
	@Caching(evict = { @CacheEvict(key = "T(com.bestpay.be.sdk.constants.BeCacheConstants).CACHE_KEY_CITY_ALL"), })
	public boolean delete(Integer id) {
		return super.delete(id);
	}


	@Override
	public GenericRepository<RefCity> primaryDao() {
		return cityDao;
	}

}