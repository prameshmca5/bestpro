/**
 * 
 */

$("#backButton").click(function(e){
	e.preventDefault();
	var newURL =  "/" + window.location.pathname.split("/")[2] + "/" + window.location.pathname.split("/")[3];
	redirectURL(newURL);
})


