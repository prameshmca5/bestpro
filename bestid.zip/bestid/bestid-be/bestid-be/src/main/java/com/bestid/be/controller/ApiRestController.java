/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.controller;


import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestid.be.constants.CacheConstants;
import com.bestid.be.constants.ConfigConstants;
import com.bestid.be.constants.ProjectEnum;
import com.bestid.be.constants.TxnCodeConstants;
import com.bestid.be.constants.UriConstants;
import com.bestid.be.model.BidCertInfo;
import com.bestid.be.model.BidConfig;
import com.bestid.be.model.BidEnrollAppl;
import com.bestid.be.model.BidUserProfile;
import com.bestid.be.model.SecUserDevice;
import com.bestid.be.sdk.constants.BeErrorCodeEnum;
import com.bestid.be.sdk.constants.MailTemplateConstants;
import com.bestid.be.sdk.model.CounterResponse;
import com.bestid.be.sdk.model.Device;
import com.bestid.be.sdk.model.DigitalIdInfo;
import com.bestid.be.sdk.model.KioskCounter;
import com.bestid.be.sdk.model.MessageResponse;
import com.bestid.be.sdk.model.MobileUser;
import com.bestid.be.sdk.model.QrDigitalId;
import com.bestid.be.service.BidCertInfoService;
import com.bestid.be.service.BidConfigService;
import com.bestid.be.service.BidEnrollApplService;
import com.bestid.be.service.BidUserProfileService;
import com.bestid.be.service.SecUserDeviceService;
import com.bestid.be.util.CryptoHelper;
import com.bstsb.camvi.sdk.client.CamviServiceClient;
import com.bstsb.dm.sdk.model.Documents;
import com.bstsb.idm.sdk.exception.IdmException;
import com.bstsb.notify.sdk.model.Notification;
import com.bstsb.notify.sdk.util.MailUtil;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.DateUtil;
import com.bstsb.util.QRGenerator;
import com.bstsb.util.UidGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * This Rest Controller is specific for BestID API Integration Service
 *
 * @author mary.jane
 * @since Nov 14, 2018
 */
@Lazy
@RestController
public class ApiRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ApiRestController.class);

	@Autowired
	private CacheManager cacheManager;

	@Autowired
	RedisTemplate<String, String> redisTemplate;

	@Autowired
	private SecUserDeviceService secUserDeviceSvc;

	@Autowired
	private BidEnrollApplService bidEnrollApplSvc;

	@Autowired
	private BidCertInfoService bidCertInfoSvc;

	@Autowired
	private BidUserProfileService bidUserProfileSvc;

	@Autowired
	private BidConfigService bidConfigSvc;

	@Autowired
	private CamviServiceClient camviService;


	@PostMapping(value = UriConstants.API_AUTHENTICATE_CHECK, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse logout(@RequestParam(defaultValue = TxnCodeConstants.API_AUTH_CHECK) String trxnNo,
			@RequestParam(value = "license") String license, @RequestParam(value = "guid") String guid,
			HttpServletRequest request) {
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI());
	}


	@GetMapping(value = UriConstants.API_QR_IMAGE, produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody ResponseEntity<byte[]> printSticker(
			@RequestParam(defaultValue = TxnCodeConstants.API_QR_IMAGE) String trxnNo,
			@RequestParam(value = "license") String license, @RequestParam(value = "guid") String guid,
			HttpSession session) {

		String cacheKey = CacheConstants.CACHE_KEY_API_QR.concat(license).concat("~").concat(guid);
		Cache cache = cacheManager.getCache(CacheConstants.CACHE_BUCKET);

		// Evict existing cachekey
		Set<String> redisKeys = redisTemplate.keys("*" + cacheKey + "*");
		Iterator<String> it = redisKeys.iterator();
		while (it.hasNext()) {
			String data = it.next();
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("redisKey: {}", data);
			}
			cache.evict(data);
		}

		Map<String, Object> map = new HashMap<>();
		map.put("license", license);
		map.put("guid", guid);
		BufferedImage bi = QRGenerator.generateQRCode(300, "bmi", license);
		byte[] fb = null;
		if (bi != null) {
			try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
				ImageIO.write(bi, "jpg", baos);
				baos.flush();
				fb = baos.toByteArray();
				// Save value to Cache for later validation
				cache.put(cacheKey, map);
			} catch (IOException e) {
				LOGGER.error(e.getMessage());
			}
		}

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.parseMediaType(MediaType.IMAGE_PNG_VALUE));
		String filename = cacheKey + ".png";
		headers.setContentDispositionFormData(filename, filename);
		headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
		return new ResponseEntity<>(fb, headers, HttpStatus.OK);
	}


	@PostMapping(value = UriConstants.API_QR_CODE_GENERATE, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse generateQRCodeDigitalidInfo(
			@RequestParam(defaultValue = TxnCodeConstants.API_QR_CODE_GENERATE) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody QrDigitalId qrDigitalId, HttpSession session)
			throws Exception {

		if (BaseUtil.isObjNull(qrDigitalId.getQrKey()) && BaseUtil.isObjNull(qrDigitalId.getInd())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		LOGGER.info("request ::{}", qrDigitalId);
		BidEnrollAppl bidEnrAppl = new BidEnrollAppl();
		BidCertInfo bidCertInfo = new BidCertInfo();
		BidUserProfile bidUserProfile = new BidUserProfile();
		SecUserDevice secUserDevice = new SecUserDevice();
		String uuid = BaseUtil.getStr(UUID.randomUUID());

		if (BaseUtil.isEqualsCaseIgnore(qrDigitalId.getInd(), "1")) {
			secUserDevice = secUserDeviceSvc.findDeviceByMachineId(qrDigitalId.getQrKey());
			if (BaseUtil.isObjNull(secUserDevice)) {
				qrDigitalId.setStatus("I");
			}
		}
		if (BaseUtil.isEqualsCaseIgnore(qrDigitalId.getInd(), "2")) {
			String appIdStr = qrDigitalId.getQrKey();
			int applid = Integer.parseInt(appIdStr);
			bidEnrAppl = bidEnrollApplSvc.findByApplId(applid);
			qrDigitalId.setApplId(appIdStr);
			if (!BaseUtil.isObjNull(bidEnrAppl)) {
				secUserDevice = secUserDeviceSvc.findDeviceId(bidEnrAppl.getDeviceId());
				bidCertInfo = bidCertInfoSvc.findByApplId(bidEnrAppl.getApplId());
				bidUserProfile = bidUserProfileSvc.findByUserId(bidEnrAppl.getUserId());
			} else {
				return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
			}
		}
		if (!BaseUtil.isObjNull(secUserDevice)) {
			Device dvc = new Device();
			dvc.setDeviceId(secUserDevice.getDeviceId());
			dvc.setBrand(secUserDevice.getBrand());
			dvc.setMachineId(secUserDevice.getMachineId());
			dvc.setSdkVersion(secUserDevice.getSdkVersion());
			dvc.setModel(secUserDevice.getModel());
			dvc.setManufacturer(secUserDevice.getManufacturer());
			dvc.setGeoLocation(secUserDevice.getGeoLocation());
			qrDigitalId.setDeviceInfo(dvc);
			qrDigitalId.setStatus(secUserDevice.getStatus());
		} else {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}
		if (!BaseUtil.isObjNull(bidEnrAppl) && !BaseUtil.isObjNull(bidCertInfo)
				&& !BaseUtil.isObjNull(bidUserProfile)) {
			DigitalIdInfo dgI = new DigitalIdInfo();
			dgI.setExpiryDate(bidCertInfo.getExpiredDt());
			dgI.setGenerateDate(bidCertInfo.getGenerateDt());
			dgI.setOwnerName(bidUserProfile.getFullName());
			dgI.setDeviceName(secUserDevice.getModel());
			dgI.setCertStatus(bidCertInfo.getStatus());
			qrDigitalId.setDigitalIdInfo(dgI);
		}
		String cacheKey = CacheConstants.CACHE_KEY_API_QR.concat(uuid);
		Cache cache = cacheManager.getCache(CacheConstants.CACHE_BUCKET);

		// Evict existing cachekey
		Set<String> redisKeys = redisTemplate.keys("*" + cacheKey + "*");
		Iterator<String> it = redisKeys.iterator();
		while (it.hasNext()) {
			String data = it.next();
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("redisKey qrDigitalId: {}", data);
			}
			cache.evict(data);
		}
		Map<String, Object> qrDetail = new LinkedHashMap<>();
		qrDetail.put("uuid", uuid);
		qrDetail.put("refNo", bidUserProfile.getRefNo());
		qrDetail.put("fullName", bidUserProfile.getFullName());
		qrDetail.put("applId", bidEnrAppl.getApplId());

		String encryptUuid = CryptoHelper.encrypt(new JSONObject(qrDetail).toString());
		Map<String, Object> map = new HashMap<>();
		map.put("uuid", uuid);
		map.put("refNo", bidUserProfile.getRefNo());
		map.put("fullName", bidUserProfile.getFullName());
		map.put("applId", bidEnrAppl.getApplId());

		BufferedImage bi = QRGenerator.generateQRCode(300, "bmi", encryptUuid);
		byte[] fb = null;
		if (bi != null) {
			try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
				ImageIO.write(bi, "jpg", baos);
				baos.flush();
				fb = baos.toByteArray();
				// Save value to Cache for later validation
				cache.put(cacheKey, map);
			} catch (IOException e) {
				LOGGER.error(e.getMessage());
			}
		}

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.parseMediaType(MediaType.IMAGE_PNG_VALUE));
		String filename = cacheKey + ".png";
		headers.setContentDispositionFormData(filename, filename);
		headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
		Timestamp currDtTime = DateUtil.getSQLTimestamp();
		String imgBase64Str = Base64.encodeBase64String(fb);
		if (!BaseUtil.isObjNull(secUserDevice.getDeviceId())) {
			secUserDevice.setUuid(uuid);
			secUserDevice.setUpdateId(qrDigitalId.getQrKey());
			secUserDevice.setUpdateDt(currDtTime);
			secUserDeviceSvc.update(secUserDevice);
			qrDigitalId.setUuid(uuid);
		}
		qrDigitalId.setQrCodeImage(imgBase64Str);
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), qrDigitalId);
	}


	@PostMapping(value = UriConstants.API_QR_CODE_VERIFY, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse verifyQrCode(@RequestParam(defaultValue = TxnCodeConstants.API_DEVICE_SEARCH) String trxnNo,
			@RequestBody QrDigitalId qrDigitalId, HttpServletRequest request) {

		if (BaseUtil.isObjNull(qrDigitalId.getUuid()) && BaseUtil.isObjNull(qrDigitalId.getRefNo())
				&& BaseUtil.isObjNull(qrDigitalId.getMachineId())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		BidUserProfile bidUserProfile = bidUserProfileSvc.findUserByRefNo(qrDigitalId.getRefNo());
		SecUserDevice secUserDevice = secUserDeviceSvc
				.findDeviceByUidMachineId(qrDigitalId.getDeviceInfo().getMachineId(), qrDigitalId.getUuid());

		if (BaseUtil.isObjNull(bidUserProfile) || BaseUtil.isObjNull(secUserDevice)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}

		String cacheKey = CacheConstants.CACHE_KEY_API_QR.concat(qrDigitalId.getUuid());
		Cache cache = cacheManager.getCache(CacheConstants.CACHE_BUCKET);
		Cache.ValueWrapper cv = cache.get(cacheKey);
		if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
			LOGGER.info(" CV NOT NULL");
			qrDigitalId.setRespFlag(true);
		} else {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}

		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), null);
	}


	/**
	 * Search Device
	 */
	@PostMapping(value = UriConstants.API_DEVICE_SEARCH, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse searchDevice(@RequestParam(defaultValue = TxnCodeConstants.API_DEVICE_SEARCH) String trxnNo,
			@RequestBody KioskCounter kioskCounter, HttpServletRequest request) {
		if (BaseUtil.isObjNull(kioskCounter.getMachineId())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI());
		}

		SecUserDevice secUsrDvc = secUserDeviceSvc.findDeviceByMachineId(kioskCounter.getMachineId());
		if (BaseUtil.isObjNull(secUsrDvc)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI());
		}

		CounterResponse response = new CounterResponse();
		response.setId(String.valueOf(secUsrDvc.getDeviceId()));
		response.setStatus(secUsrDvc.getStatus());
		response.setCreateDate(DateUtil.convertTimestampToDate(secUsrDvc.getCreateDt()));
		response.setCertStatus(secUsrDvc.getCertStatus());

		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), response);
	}


	/**
	 * Search User
	 */
	@PostMapping(value = UriConstants.API_USER_SEARCH, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse searchUser(@RequestParam(defaultValue = TxnCodeConstants.API_USER_SEARCH) String trxnNo,
			@RequestBody KioskCounter kioskCounter, HttpServletRequest request) {
		List<CounterResponse> respList = new ArrayList<>();
		if (BaseUtil.isObjNull(kioskCounter.getIcNo()) || BaseUtil.isObjNull(kioskCounter.getUserType())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI());
		}
		List<BidUserProfile> secUsr = bidUserProfileSvc.findUserByIdNType(kioskCounter.getIcNo(),
				Integer.parseInt(kioskCounter.getUserType()));
		if (BaseUtil.isListNull(secUsr)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI());
		}

		for (BidUserProfile bup : secUsr) {
			CounterResponse response = new CounterResponse();
			response.setId(String.valueOf(bup.getUserId()));
			response.setIcNo(bup.getRefNo());
			response.setStatus(bup.getStatus());
			response.setCreateDate(DateUtil.convertTimestampToDate(bup.getCreateDt()));
			respList.add(response);
		}

		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), respList);
	}


	/**
	 * Register User
	 */
	@PostMapping(value = UriConstants.API_USER_REGISTER, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse registerUser(@RequestParam(defaultValue = TxnCodeConstants.API_USER_REGISTER) String trxnNo,
			@RequestBody KioskCounter kioskCounter, HttpServletRequest request) {
		CounterResponse response = new CounterResponse();
		BidUserProfile bUsrProf = null;
		KioskCounter respCont = null;
		if (BaseUtil.isObjNull(kioskCounter.getIcNo())
				// ||
				// BaseUtil.isObjNull(kioskCounter.getDeviceInfo().getMachineId())
				|| BaseUtil.isObjNull(kioskCounter.getUserType()) || BaseUtil.isObjNull(kioskCounter.getFullname())
				|| BaseUtil.isObjNull(kioskCounter.getDob()) || BaseUtil.isObjNull(kioskCounter.getGender())
				|| BaseUtil.isObjNull(kioskCounter.getIssueDate())
				|| BaseUtil.isObjNull(kioskCounter.getCntryIssue())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI());
		}
		List<BidUserProfile> bidUsrLst = bidUserProfileSvc.findUserByrefNoType(kioskCounter.getIcNo(),
				Integer.parseInt(kioskCounter.getUserType()));
		SecUserDevice secUserDevice = secUserDeviceSvc
				.findDeviceByMachineId(kioskCounter.getDeviceInfo().getMachineId());

		// if (!BaseUtil.isObjNull(secUserDevice)) {
		// BidEnrollAppl bidEnrAppl =
		// bidEnrollApplSvc.findByDeviceId(secUserDevice.getDeviceId(), "A");
		// if (!BaseUtil.isObjNull(bidEnrAppl)) {
		// return new MessageResponse(BeErrorCodeEnum.E409BST002,
		// request.getRequestURI());
		// }
		// }

		if (BaseUtil.isListNull(bidUsrLst)) {
			bUsrProf = new BidUserProfile();
			bUsrProf.setRefNo(kioskCounter.getIcNo());
			bUsrProf.setUserType(Integer.parseInt(kioskCounter.getUserType()));
			bUsrProf.setFullName(kioskCounter.getFullname());
			bUsrProf.setDob(DateUtil.convertStrDateToDate(kioskCounter.getDob(), "dd/MM/yyyy"));
			bUsrProf.setPob(kioskCounter.getPob());
			bUsrProf.setGender(setGndr(kioskCounter));
			bUsrProf.setRace(kioskCounter.getRace());
			bUsrProf.setReligion(kioskCounter.getReligion());
			bUsrProf.setCitizenship(kioskCounter.getCitizenship());
			bUsrProf.setAddres(kioskCounter.getAddress());
			bUsrProf.setPostcode(kioskCounter.getPostcode());
			bUsrProf.setCity(kioskCounter.getCity());
			bUsrProf.setState(kioskCounter.getState());
			bUsrProf.setCountry(kioskCounter.getNationality());
			bUsrProf.setIssueDate(DateUtil.convertStrDateToDate(kioskCounter.getIssueDate(), "dd/MM/yyyy"));
			bUsrProf.setCntryIssue(kioskCounter.getCntryIssue());
			bUsrProf.setSecUserId(0);

			byte[] raw = Base64.decodeBase64(kioskCounter.getImage());
			Documents photo = new Documents();
			photo.setContent(raw);
			if (!BaseUtil.isObjNull(kioskCounter.getIcNo())
					&& !BaseUtil.isEqualsCaseIgnore(kioskCounter.getIcNo(), "null")) {
				photo.setId(kioskCounter.getIcNo());
			}
			photo.setDocid(1);
			photo.setContentType(MediaType.IMAGE_PNG_VALUE);
			photo.setRefno(kioskCounter.getIcNo());
			photo = getDmService(ProjectEnum.BESTID).upload(photo);
			LOGGER.info("PersonDto: {}", new ObjectMapper().valueToTree(photo));
			bUsrProf.setPhotoDocId(photo.getFilesId());

			bUsrProf.setStatus("A");
			bUsrProf.setCreateId(kioskCounter.getDeviceInfo().getMachineId());
			bUsrProf.setUpdateId(kioskCounter.getDeviceInfo().getMachineId());
		}

		String actvNo = UidGenerator.generateRandomNoInStr();
		try {
			if (BaseUtil.isObjNull(bUsrProf)) {
				respCont = bidUserProfileSvc.saveUserInfo(null, secUserDevice, kioskCounter, actvNo);
			} else {
				respCont = bidUserProfileSvc.saveUserInfo(bUsrProf, secUserDevice, kioskCounter, actvNo);
			}
		} catch (Exception e) {
			return new MessageResponse(BeErrorCodeEnum.E500BST001, request.getRequestURI());
		}
		if (BaseUtil.isObjNull(respCont)) {
			return new MessageResponse(BeErrorCodeEnum.E500BST001, request.getRequestURI());
		}
		if (!BaseUtil.isObjNull(kioskCounter.getPhoneNo())) {
			String newmobile = kioskCounter.getPhoneNo();
			Map<String, Object> map = new HashMap<>();
			map.put("actvNo", actvNo);
			Notification notification = new Notification();
			notification.setNotifyTo(newmobile);
			notification.setMetaData(MailUtil.convertMapToJson(map));
			try {
				getNotifyService().addNotification(notification, MailTemplateConstants.GEN_ACTIVATION_CODE_SMS);
			} catch (IdmException e) {
				LOGGER.error("IdmException: {}", e.getMessage());
			} catch (Exception e) {
				LOGGER.error("Exception: {}", e.getMessage());
			}
		}
		response.setId(String.valueOf(respCont.getIdUser()));
		response.setApplId(String.valueOf(respCont.getApplId()));
		response.setCreateDate(DateUtil.convertTimestampToDate(DateUtil.getSQLTimestamp()));
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), response);
	}


	private String setGndr(KioskCounter kioskCounter) {
		if (BaseUtil.isEquals(kioskCounter.getGender(), "L")
				|| BaseUtil.isEquals(kioskCounter.getGender(), "LELAKI")) {
			return "M";
		} else if (BaseUtil.isEquals(kioskCounter.getGender(), "P")
				|| BaseUtil.isEquals(kioskCounter.getGender(), "PEREMPUAN")) {
			return "F";
		} else {
			return kioskCounter.getGender();
		}
	}


	/**
	 * Update contact
	 */
	@PostMapping(value = UriConstants.API_CONTACT_UPDATE, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse updateContact(
			@RequestParam(defaultValue = TxnCodeConstants.API_CONTACT_UPDATE) String trxnNo,
			@RequestBody KioskCounter kioskCounter, HttpServletRequest request) {
		if (BaseUtil.isObjNull(kioskCounter.getDeviceInfo().getMachineId())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI());
		}
		SecUserDevice secUserDvc = secUserDeviceSvc
				.findDeviceByMachineId(kioskCounter.getDeviceInfo().getMachineId());
		if (BaseUtil.isObjNull(secUserDvc)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI());
		}

		secUserDvc.setMobileNo(kioskCounter.getPhoneNo());
		secUserDvc.setEmail(kioskCounter.getEmail());
		secUserDvc.setUpdateDt(DateUtil.getSQLTimestamp());
		secUserDeviceSvc.update(secUserDvc);
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI());
	}


	/**
	 * Generate activation code
	 */
	@PostMapping(value = UriConstants.API_ACTIVATION_CODE_GENERATE, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse genActCode(
			@RequestParam(defaultValue = TxnCodeConstants.API_ACTIVATION_CODE_GENERATE) String trxnNo,
			@RequestBody KioskCounter kioskCounter, HttpServletRequest request) {
		CounterResponse response = new CounterResponse();
		if (BaseUtil.isObjNull(kioskCounter.getIcNo()) && BaseUtil.isObjNull(kioskCounter.getPhoneNo())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI());
		}
		BidUserProfile bup = bidUserProfileSvc.findUserByRefNo(kioskCounter.getIcNo());
		SecUserDevice secUserDvc = secUserDeviceSvc.findDeviceByMobileNo(kioskCounter.getPhoneNo());
		if (BaseUtil.isObjNull(bup) || BaseUtil.isObjNull(secUserDvc)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI());
		}
		BidEnrollAppl bidEnrAppl = bidEnrollApplSvc.findByUsrNDeviceId(secUserDvc.getDeviceId(), bup.getUserId());
		if (BaseUtil.isObjNull(bidEnrAppl)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI());
		}

		String actvNo = UidGenerator.generateRandomNoInStr();
		response.setActivationCode(actvNo);
		bidEnrAppl.setActivationCode(actvNo);
		bidEnrAppl.setStatus("A");
		try {
			kioskCounter = bidEnrollApplSvc.saveActvCd(bidEnrAppl, kioskCounter);
		} catch (Exception e) {
			return new MessageResponse(BeErrorCodeEnum.E500BST001, request.getRequestURI());
		}

		if (!BaseUtil.isObjNull(kioskCounter.getPhoneNo())) {
			String newmobile = kioskCounter.getPhoneNo();
			Map<String, Object> map = new HashMap<>();
			map.put("actvNo", actvNo);
			Notification notification = new Notification();
			notification.setNotifyTo(newmobile);
			notification.setMetaData(MailUtil.convertMapToJson(map));
			try {
				getNotifyService().addNotification(notification, MailTemplateConstants.GEN_ACTIVATION_CODE_SMS);
			} catch (IdmException e) {
				LOGGER.error("IdmException: {}", e.getMessage());
			} catch (Exception e) {
				LOGGER.error("Exception: {}", e.getMessage());
			}
		}
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), response);
	}


	@PostMapping(value = UriConstants.API_ACTIVATION_CODE_VERIFY, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse verifyActCode(
			@RequestParam(defaultValue = TxnCodeConstants.API_ACTIVATION_CODE_VERIFY) String trxnNo,
			@RequestBody KioskCounter kioskCounter, HttpServletRequest request) {
		if (BaseUtil.isObjNull(kioskCounter.getActivationCode())
				|| BaseUtil.isObjNull(kioskCounter.getDeviceInfo().getMachineId())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}
		BidEnrollAppl bidEnrAppl = bidEnrollApplSvc.findByActvCd(kioskCounter.getActivationCode());
		if (BaseUtil.isObjNull(bidEnrAppl)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}
		SecUserDevice sud = secUserDeviceSvc.findDeviceId(bidEnrAppl.getDeviceId());
		if (BaseUtil.isObjNull(sud)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}
		sud.setMachineId(kioskCounter.getDeviceInfo().getMachineId());
		sud.setStatus("A");
		secUserDeviceSvc.update(sud);
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), null);
	}


	private Timestamp getExpiryDate() {
		int second = 0;

		BidConfig bidConfig = bidConfigSvc.findConfigCd(ConfigConstants.BID_CHCK_QR_EXP_DT);

		if (!BaseUtil.isObjNull(bidConfig)) {
			second = Integer.parseInt(bidConfig.getConfigVal());
		}
		Date expiryDt = DateUtil.addHourMinutesSecondToDate(0, 0, second);
		return new Timestamp(expiryDt.getTime());
	}


	@PostMapping(value = UriConstants.API_UUID_VALIDATION, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse verifyUuid(@RequestParam(defaultValue = TxnCodeConstants.API_UUID_VERIFY) String trxnNo,
			@RequestBody QrDigitalId qrDigitalId, HttpServletRequest request) {

		if (BaseUtil.isObjNull(qrDigitalId.getUuid()) || BaseUtil.isObjNull(qrDigitalId.getRefNo())
				|| BaseUtil.isObjNull(qrDigitalId.getFullName()) || BaseUtil.isObjNull(qrDigitalId.getApplId())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}
		BidUserProfile bidUserProfile = bidUserProfileSvc.findUserByRefNo(qrDigitalId.getRefNo());
		BidEnrollAppl bidEnrApplId = bidEnrollApplSvc.findByApplId(Integer.parseInt(qrDigitalId.getApplId()));

		if (!BaseUtil.isObjNull(bidUserProfile) && !BaseUtil.isObjNull(bidEnrApplId)) {
			SecUserDevice secUserDevice = secUserDeviceSvc.findByUuid(qrDigitalId.getUuid());
			if (!BaseUtil.isObjNull(secUserDevice)) {
				Timestamp expiryDate = getExpiryDate();
				secUserDevice.setUuidExpDt(expiryDate);
				secUserDevice.setUpdateId(qrDigitalId.getRefNo());
				secUserDeviceSvc.update(secUserDevice);
				qrDigitalId.setUuid(qrDigitalId.getUuid());
				qrDigitalId.setUuidExpDt(expiryDate.toString());
			} else {
				return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
			}
		} else {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), qrDigitalId);
	}


	@PostMapping(value = UriConstants.API_PHOTO_VALIDATION, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse verifyPhoto(@RequestParam(defaultValue = TxnCodeConstants.API_UUID_VERIFY) String trxnNo,
			@RequestBody KioskCounter kioskCounter, HttpServletRequest request) {

		if (BaseUtil.isObjNull(kioskCounter.getImageMy()) || BaseUtil.isObjNull(kioskCounter.getImageLv())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		CounterResponse response = new CounterResponse();
		boolean resp = camviService.compareFaceImage(kioskCounter.getImageMy(), kioskCounter.getImageLv());
		if (resp == true) {
			response.setImageResult(resp);
		} else {
			return new MessageResponse(BeErrorCodeEnum.E500BST007, request.getRequestURI(), null);
		}

		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), response);
	}
	
	@PostMapping(value = UriConstants.API_DIGITALID_STATUS_CHECK, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MessageResponse digitalIdStatusCheck(
			@RequestParam(defaultValue = TxnCodeConstants.API_DIGITALID_STATUS_CHECK) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody KioskCounter kioskCounter) {

		if (BaseUtil.isObjNull(kioskCounter.getApplId())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}
		
		Integer applId = Integer.valueOf(kioskCounter.getApplId());

		BidCertInfo certInfo = bidCertInfoSvc.findByApplId(applId);
		if (BaseUtil.isObjNull(certInfo)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}
		
		BidEnrollAppl enrollAppl = bidEnrollApplSvc.findByApplId(applId);
		if (BaseUtil.isObjNull(enrollAppl)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}
		
		SecUserDevice userDevice = secUserDeviceSvc.findDeviceId(enrollAppl.getDeviceId());
		if (BaseUtil.isObjNull(userDevice)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}
		
		DigitalIdInfo didInfo = new DigitalIdInfo();
		didInfo.setOwnerName(certInfo.getFirstName());
		didInfo.setCertStatus(userDevice.getIsCertInstall());
		didInfo.setCertRefNo(certInfo.getCertRefNo());
		didInfo.setExpiryDate(certInfo.getExpiredDt());
		didInfo.setGenerateDate(certInfo.getGenerateDt());		
		
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), didInfo);
	}
}
