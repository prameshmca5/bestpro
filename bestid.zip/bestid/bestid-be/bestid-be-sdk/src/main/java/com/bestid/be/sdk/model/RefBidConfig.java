/**
 * Copyright 2019. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author mohd.faisal
 * @since Mar 5, 2019
 */
public class RefBidConfig implements Serializable {

	private static final long serialVersionUID = 1507768373255315497L;

	private Integer configId;

	private String configCd;

	private String configDesc;

	private String configVal;

	private String createId;

	private Timestamp createDt;

	private String updateId;

	private Timestamp updateDt;


	public Integer getConfigId() {
		return configId;
	}


	public void setConfigId(Integer configId) {
		this.configId = configId;
	}


	public String getConfigCd() {
		return configCd;
	}


	public void setConfigCd(String configCd) {
		this.configCd = configCd;
	}


	public String getConfigDesc() {
		return configDesc;
	}


	public void setConfigDesc(String configDesc) {
		this.configDesc = configDesc;
	}


	public String getConfigVal() {
		return configVal;
	}


	public void setConfigVal(String configVal) {
		this.configVal = configVal;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}
