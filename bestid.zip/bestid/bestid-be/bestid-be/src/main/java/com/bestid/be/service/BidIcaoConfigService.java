/**
 *
 */
package com.bestid.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidIcaoConfig;
import com.bestid.be.repo.BidIcaoConfigRepository;
import com.bestid.be.repo.GenericRepository;


/**
 * @author roziana
 * @since Feb 26, 2019
 */
@Transactional
@Service(QualifierConstants.BID_ICAO_CONFIG_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_ICAO_CONFIG_SVC)
public class BidIcaoConfigService extends AbstractService<BidIcaoConfig> {

	@Autowired
	@Qualifier(QualifierConstants.BID_ICAO_CONFIG_REPOSITORY)
	BidIcaoConfigRepository bidIcaoConfigDao;


	@Override
	public GenericRepository<BidIcaoConfig> primaryDao() {
		return bidIcaoConfigDao;
	}


	public BidIcaoConfig findConfigCd(String configCd) {
		return bidIcaoConfigDao.findByConfigCd(configCd);
	}


	public List<BidIcaoConfig> findConfigVal(String configCd) {
		return bidIcaoConfigDao.findByConfigVal(configCd);
	}

}
