/**
 * 
 */
package com.be.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.be.core.AbstractEntity;

/**
 * @author michelle.angela
 *
 */
 @Entity
 @Table(name = "REF_CHANNEL")
public class RefChannel extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = 5363892043107853167L;

	@Id
	@Column(name = "CHANNEL_CODE")
	private String channelCode;

	@Column(name = "CHANNEL_NAME")
	private String channelName;
	
	@Column(name = "MIN_AMT")
	private double minAmt;

	@Column(name = "MAX_AMT")
	private double maxAmt;
	
	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public double getMinAmt() {
		return minAmt;
	}

	public void setMinAmt(double minAmt) {
		this.minAmt = minAmt;
	}

	public double getMaxAmt() {
		return maxAmt;
	}

	public void setMaxAmt(double maxAmt) {
		this.maxAmt = maxAmt;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	
}
