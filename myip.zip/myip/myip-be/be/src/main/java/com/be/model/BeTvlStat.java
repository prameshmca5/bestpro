/**
 * 
 */
package com.be.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.util.BaseUtil;

/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_TVL_STAT")
public class BeTvlStat extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -1442665663761120812L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="TVL_STAT_ID")
	private Integer tvlStatId;
	
	@JsonIgnoreProperties("tvlStats")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TVL_ID")
	private BeTvl tvl;
	
	@Column(name="STATUS_IND")
	private Integer statusInd;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DQ_STAT_MTDT_ID")
	private RefMetadata dqStatMtdt;
	
	@Column(name = "APPROVED_DT")
	private Timestamp approvedDt;
	
	@Column(name = "REMARKS")
	private String remarks;
	
	@Column(name = "REMARKS_MTDT_ID")
	private Integer remarksMtdtId;
	
	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "REMARKS_MTDT_ID",insertable = false, updatable = false)
	private RefMetadata remarksMtdt;

	public Integer getTvlStatId() {
		return tvlStatId;
	}

	public void setTvlStatId(Integer tvlStatId) {
		this.tvlStatId = tvlStatId;
	}

	public BeTvl getTvl() {
		return tvl;
	}

	public void setTvl(BeTvl tvl) {
		this.tvl = tvl;
	}

	public Integer getStatusInd() {
		return statusInd;
	}

	public void setStatusInd(Integer statusInd) {
		this.statusInd = statusInd;
	}

	public RefMetadata getDqStatMtdt() {
		return dqStatMtdt;
	}

	public void setDqStatMtdt(RefMetadata dqStatMtdt) {
		this.dqStatMtdt = dqStatMtdt;
	}

	public Timestamp getApprovedDt() {
		return approvedDt;
	}

	public void setApprovedDt(Timestamp approvedDt) {
		this.approvedDt = approvedDt;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getRemarks() {
		return BaseUtil.getStrUpperWithNull(remarks);
	}

	public void setRemarks(String remarks) {
		this.remarks = BaseUtil.getStrUpperWithNull(remarks);
	}

	public Integer getRemarksMtdtId() {
		return remarksMtdtId;
	}

	public void setRemarksMtdtId(Integer remarksMtdtId) {
		this.remarksMtdtId = remarksMtdtId;
	}

	public RefMetadata getRemarksMtdt() {
		return remarksMtdt;
	}

	public void setRemarksMtdt(RefMetadata remarksMtdt) {
		this.remarksMtdt = remarksMtdt;
	}
	
}
