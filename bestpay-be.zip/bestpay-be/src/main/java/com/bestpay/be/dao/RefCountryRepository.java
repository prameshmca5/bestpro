package com.bestpay.be.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.RefCountry;
import com.bestpay.be.model.RefStatus;
import com.bestpay.be.util.QualifierConstants;

@Repository
@RepositoryDefinition(domainClass = RefStatus.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_COUNTRY_DAO)
public interface RefCountryRepository extends GenericRepository<RefCountry> {
	@Query("select u from RefCountry u where u.cntryCode = :cntryCode ")
	public RefCountry findRefCountryByCountryCode(@Param("cntryCode") String cntryCode);
}