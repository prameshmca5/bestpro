/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dialect;


import java.util.LinkedHashSet;
import java.util.Set;

import org.thymeleaf.dialect.AbstractDialect;
import org.thymeleaf.processor.IProcessor;
import org.thymeleaf.util.StringUtils;

import com.bestpay.web.dialect.constants.ElementConstants;
import com.bestpay.web.dialect.constants.ElementEnum;
import com.bestpay.web.dialect.processor.ButtonElementProcessor;
import com.bestpay.web.dialect.processor.DivElementProcessor;
import com.bestpay.web.dialect.processor.FormElementProcessor;
import com.bestpay.web.dialect.processor.InputElementProcessor;
import com.bestpay.web.dialect.processor.MenuElementProcessor;
import com.bestpay.web.dialect.processor.SelectElementController;
import com.bestpay.web.dialect.processor.SpanElementProcessor;
import com.bestpay.web.dialect.processor.TableElementProcessor;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class CustomBstDialect extends AbstractDialect {

	public static final String DEFAULT_PREFIX = "bst";

	protected static final Set<IProcessor> PROCESSORS = new LinkedHashSet<>();

	static {
		for (ElementEnum v : ElementEnum.values()) {
			if (StringUtils.equalsIgnoreCase(ElementConstants.HTML_FORM, v.getProcessor())) {
				PROCESSORS.add(new FormElementProcessor(v.getName()));

			} else if (StringUtils.equalsIgnoreCase(ElementConstants.HTML_INPUT, v.getProcessor())) {
				PROCESSORS.add(new InputElementProcessor(v.getName()));

			} else if (StringUtils.equalsIgnoreCase(ElementConstants.HTML_DIV, v.getProcessor())) {
				PROCESSORS.add(new DivElementProcessor(v.getName()));

			} else if (StringUtils.equalsIgnoreCase(ElementConstants.HTML_BUTTON, v.getProcessor())) {
				PROCESSORS.add(new ButtonElementProcessor(v.getName()));

			} else if (StringUtils.equalsIgnoreCase(ElementConstants.HTML_SPAN, v.getProcessor())) {
				PROCESSORS.add(new SpanElementProcessor(v.getName()));

			} else if (StringUtils.equalsIgnoreCase(ElementConstants.HTML_TABLE, v.getProcessor())) {
				PROCESSORS.add(new TableElementProcessor(v.getName()));

			} else if (StringUtils.equalsIgnoreCase(ElementConstants.HTML_UL, v.getProcessor())
					|| StringUtils.equalsIgnoreCase(ElementConstants.HTML_LI, v.getProcessor())) {
				PROCESSORS.add(new MenuElementProcessor(v.getName()));

			} else if (StringUtils.equalsIgnoreCase(ElementConstants.HTML_SELECT, v.getProcessor())) {
				PROCESSORS.add(new SelectElementController(v.getName()));

			}
		}

	}


	@Override
	public String getPrefix() {
		return DEFAULT_PREFIX;
	}


	@Override
	public Set<IProcessor> getProcessors() {
		return PROCESSORS;
	}

}