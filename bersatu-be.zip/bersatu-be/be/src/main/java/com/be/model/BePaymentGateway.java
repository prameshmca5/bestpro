package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "BE_PAYMENT_GATEWAY")
public class BePaymentGateway extends AbstractEntity implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 6723281272583273849L;

	@Id
	@Column(name = "PMT_GW_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer pmtGwId;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "PMT_ID")
	private BePayment payment;

	@Column(name = "GW_REF_NO")
	private String gwRefNo;

	@Column(name = "RETURN_CD")
	private String returnCd;

	@Column(name = "PMT_CD")
	private String pmtCd;

	@Column(name = "ERROR_DESC")
	private String errorDesc;

	@Column(name = "SRC_TYPE")
	private String srcType;

	@Column(name = "GW_RESPONSE")
	private String gwResponse;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getPmtGwId() {
		return pmtGwId;
	}


	public void setPmtGwId(Integer pmtGwId) {
		this.pmtGwId = pmtGwId;
	}


	/**
	 * @return the gwRefNo
	 */
	public String getGwRefNo() {
		return gwRefNo;
	}


	/**
	 * @param gwRefNo
	 *             the gwRefNo to set
	 */
	public void setGwRefNo(String gwRefNo) {
		this.gwRefNo = gwRefNo;
	}


	/**
	 * @return the returnCd
	 */
	public String getReturnCd() {
		return returnCd;
	}


	/**
	 * @param returnCd
	 *             the returnCd to set
	 */
	public void setReturnCd(String returnCd) {
		this.returnCd = returnCd;
	}


	/**
	 * @return the pmtCd
	 */
	public String getPmtCd() {
		return pmtCd;
	}


	/**
	 * @param pmtCd
	 *             the pmtCd to set
	 */
	public void setPmtCd(String pmtCd) {
		this.pmtCd = pmtCd;
	}


	/**
	 * @return the errorDesc
	 */
	public String getErrorDesc() {
		return errorDesc;
	}


	/**
	 * @param errorDesc
	 *             the errorDesc to set
	 */
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc.toUpperCase();
	}


	/**
	 * @return the srcType
	 */
	public String getSrcType() {
		return srcType;
	}


	/**
	 * @param srcType
	 *             the srcType to set
	 */
	public void setSrcType(String srcType) {
		this.srcType = srcType.toUpperCase();
	}


	public BePayment getPayment() {
		return payment;
	}


	public void setPayment(BePayment payment) {
		this.payment = payment;
	}


	public String getGwResponse() {
		return gwResponse;
	}


	public void setGwResponse(String gwResponse) {
		this.gwResponse = gwResponse;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}
