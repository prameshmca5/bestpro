/**
 *
 */
package com.be.service;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTvlProfileQf;
import com.be.dao.BeTvlProfileRepository;
import com.be.model.BeAcctTraveller;
import com.be.model.BeTvl;
import com.be.model.BeTvlProfile;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.TvlProfile;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_PROFILE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_PROFILE_SVC)
public class BeTvlProfileService extends AbstractService<BeTvlProfile> {

	@Autowired
	private BeTvlProfileRepository beTvlProfileDao;

	@Autowired
	BeTvlProfileQf beTvlProfileQf;

	// @Autowired
	// BeAcctTravellerService beAcctTravellerSvc;


	@Override
	public GenericRepository<BeTvlProfile> primaryDao() {
		return beTvlProfileDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beTvlProfileQf.generateCriteria(cb, from, criteria);
	}

	/*
	 * @javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn =
	 * Exception.class) public DataTableResults<BeTvlProfile>
	 * searchBeTvlProfilePagination(TvlProfile tvlProfile, DataTableRequest
	 * dataTableInRQ) { return
	 * beTvlProfileQf.searchBeTvlProfilePagination(tvlProfile, dataTableInRQ);
	 * }
	 */


	@SuppressWarnings("unchecked")
	public List<TvlProfile> searchBeTvlProfilePagination(TvlProfile dto, DataTableRequest<?> dataTableInRQ)
			throws IOException {
		return JsonUtil.transferToList(beTvlProfileQf.searchBeTvlProfilePagination(dto, dataTableInRQ),
				TvlProfile.class);
	}


	public BeTvlProfile searchBeTvlProfile(TvlProfile dto) {
		return beTvlProfileQf.searchBeTvlProfile(dto);
	}


	public long getCount(TvlProfile dto) {
		return beTvlProfileQf.getCount(dto);
	}

	// public List<BeTvlProfile> createUpdate(List<Integer> acctTvlrIdList)
	// throws IOException{
	//
	// List<BeTvlProfile> beTvlProfiles = new ArrayList<>();
	// for(Integer id: acctTvlrIdList) {
	// BeAcctTraveller traveller = beAcctTravellerSvc.find(id);
	// if(!BaseUtil.isObjNull(traveller)) {
	// beTvlProfiles.add(JsonUtil.transferToObject(traveller,
	// BeTvlProfile.class));
	// }
	// }
	// return beTvlProfileDao.save(beTvlProfiles);
	// }


	public List<BeTvlProfile> updateTvlProfile(BeTvlProfile dto, BeAcctTraveller acctTraveller, List<BeTvl> beTvls,
			String userId) {

		List<BeTvlProfile> beTvlProfiles = new ArrayList<>();
		for (BeTvl beTvl : beTvls) {
			BeTvlProfile beTvlProfile = new BeTvlProfile();
			if (!BaseUtil.isObjNull(beTvl.getTvlProfile())) {
				beTvlProfile = dto;
				beTvlProfile.setAcctTraveller(acctTraveller);
				beTvlProfile.setTvlProfId(beTvl.getTvlProfile().getTvlProfId());
				beTvlProfile.setTrxnRefNo(beTvl.getTvlProfile().getTrxnRefNo());
				beTvlProfile.setTrxnDt(beTvl.getTvlProfile().getTrxnDt());
				beTvlProfile.setCreateId(beTvl.getTvlProfile().getCreateId());
				beTvlProfile.setCreateDt(beTvl.getTvlProfile().getCreateDt());
				beTvlProfile.setUpdateId(userId);
				beTvlProfiles.add(update(beTvlProfile));
			}
		}
		return beTvlProfiles;
	}


	public List<BeTvlProfile> saveList(List<BeTvlProfile> infoList) {
		return beTvlProfileDao.save(infoList);
	}


	public List<BeTvlProfile> searchBeTvlProfileByAcctTvlrIdAndStatusCd(Integer acctTvlrId, String statusCd) {
		return beTvlProfileDao.findByAcctTvlrIdAndStatusCode(acctTvlrId, statusCd);
	}
}
