package com.bestpay.be.util;

/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public enum ProjectEnum {

	MIPSS("bestpay", "APJATIGO"), ;

	private final String name;
	private final String prefix;

	ProjectEnum(String name, String prefix) {
		this.name = name;
		this.prefix = prefix;
	}

	public String getName() {
		return name;
	}

	public String getPrefix() {
		return prefix;
	}

}
