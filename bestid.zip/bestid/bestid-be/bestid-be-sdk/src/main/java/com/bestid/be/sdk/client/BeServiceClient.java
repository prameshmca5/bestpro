/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.client;

import java.io.IOException;
import java.util.Map;

import org.apache.http.impl.client.CloseableHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bestid.be.sdk.builder.ApiService;
import com.bestid.be.sdk.builder.MaintenanceService;
import com.bestid.be.sdk.builder.MobileService;
import com.bestid.be.sdk.builder.ReferenceService;
import com.bestid.be.sdk.builder.SubscriberService;
import com.bestid.be.sdk.constants.BeErrorCodeEnum;
import com.bestid.be.sdk.constants.BeUrlConstants;
import com.bestid.be.sdk.constants.ServiceConstants;
import com.bestid.be.sdk.exception.BeException;
import com.bestid.be.sdk.model.ServiceCheck;
import com.bestid.be.sdk.model.StaticList;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.UriUtil;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BeServiceClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(BeServiceClient.class);

	private BeRestTemplate restTemplate;

	private String url;

	private String clientId;

	private String token;

	private String authToken;

	private String messageId;

	private int readTimeout;

	public BeServiceClient(String url) {
		this.url = url;
		initialize();
	}

	public BeServiceClient(String url, int readTimeout) {
		this.url = url;
		this.readTimeout = readTimeout;
		initialize();
	}

	public BeServiceClient(String url, String clientId, int readTimeout) {
		this.url = url;
		this.clientId = clientId;
		this.readTimeout = readTimeout;
		initialize();
	}

	private void initialize() {
		restTemplate = new BeRestTemplate();
	}

	private BeRestTemplate getRestTemplate() {
		CloseableHttpClient httpClient = null;
		if (messageId == null) {
			throw new BeException(BeErrorCodeEnum.E400BST001);
		}
		if (authToken != null) {
			httpClient = new HttpAuthClient(authToken, messageId, readTimeout).getHttpClient();
		} else {
			httpClient = new HttpAuthClient(clientId, token, messageId, readTimeout).getHttpClient();
		}
		restTemplate.setHttpClient(httpClient);
		return restTemplate;
	}

	private String getServiceURI(String serviceName) {
		String uri = url + serviceName;
		LOGGER.info("Service Rest URL: {} ", uri);
		return uri;
	}

	protected String getServiceURI(String serviceName, Object obj) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);

		JsonNode jnode = mapper.valueToTree(obj);
		boolean isFirst = true;
		StringBuilder sb = new StringBuilder();
		sb.append(getServiceURI(serviceName));

		if (!BaseUtil.isObjNull(obj)) {
			try {
				Map<String, Object> maps = mapper.readValue(jnode.toString(),
						new TypeReference<Map<String, Object>>() {
						});
				for (Map.Entry<String, Object> entry : maps.entrySet()) {
					String mKey = entry.getKey();
					Object mValue = entry.getValue();
					if (!BaseUtil.isObjNull(mValue) && !BaseUtil.isEquals(mKey, "serialVersionUID")) {
						if (isFirst) {
							sb.append("?");
							isFirst = false;
						}
						if (mValue instanceof String) {
							mValue = UriUtil.getVariableValueAsString(mValue);
						}
						sb.append(mKey + "=" + mValue + "&");
					}
				}
			} catch (JsonParseException e) {
				LOGGER.error("JsonParseException: {}", e.getMessage());
			} catch (JsonMappingException e) {
				LOGGER.error("JsonMappingException: {}", e.getMessage());
			} catch (IOException e) {
				LOGGER.error("IOException: {}", e.getMessage());
			}
		}
		return !isFirst ? (sb.toString()).substring(0, sb.length() - 1) : sb.toString();
	}


	public void setClientId(String clientId) {
		this.clientId = clientId;
	}


	public void setToken(String token) {
		this.token = token;
	}


	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}


	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public void setRestTemplate(BeRestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}


	public String checkConnection() {
		return getRestTemplate().getForObject(getServiceURI(BeUrlConstants.SERVICE_CHECK + "/test"), String.class);
	}


	public ServiceCheck serviceTest() {
		return getRestTemplate().getForObject(getServiceURI(BeUrlConstants.SERVICE_CHECK), ServiceCheck.class);
	}


	public ReferenceService reference() {
		return new ReferenceService(getRestTemplate(), url);
	}


	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	public StaticList getStaticList() {
		return reference().all();
	}


	public StaticList getStaticList(String staticlistType) {
		StaticList staticLst = new StaticList();

		if (staticlistType.equalsIgnoreCase(ServiceConstants.STAT_LST_CITY)) {
			staticLst.setCityList(reference().findByAllCities());
		} else if (staticlistType.equalsIgnoreCase(ServiceConstants.STAT_LST_RELATIONSHIP)) {
			staticLst.setRelationList(reference().findAllRelationShips());
		} else if (staticlistType.equalsIgnoreCase(ServiceConstants.STAT_LST_NATIONALITY)) {
			staticLst.setNationalityList(reference().findAllNationality());
		} else if (staticlistType.equalsIgnoreCase(ServiceConstants.STAT_LST_COUNTRY)) {
			staticLst.setCountryList(reference().allCountry());
		} else if (staticlistType.equalsIgnoreCase(ServiceConstants.STAT_LST_STATE)) {
			staticLst.setStateList(reference().findAllState());
		} else if (staticlistType.equalsIgnoreCase(ServiceConstants.STAT_LST_DOCUMENT)) {
			staticLst.setDocumentList(reference().findAllDocuments());
		}

		return staticLst;
	}


	public ApiService apiService() {
		return new ApiService(restTemplate, url);
	}


	public MobileService mobileService() {
		return new MobileService(getRestTemplate(), url);
	}


	public SubscriberService subscriberService() {
		return new SubscriberService(getRestTemplate(), url);
	}


	public MaintenanceService maintenanceService() {
		return new MaintenanceService(getRestTemplate(), url);
	}

}