/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
public enum PgwAppStatusEnum {

	INTRVW_APPLY("APPLY_INTRVW", 1, null, PgwFlowConstants.FLOW_SECTOR, PgwFlowConstants.FLOW_AGENCY),

	DFT_SECTOR("DFT0", 1, null, PgwFlowConstants.FLOW_SECTOR, PgwFlowConstants.FLOW_AGENCY),
	DFT_REG_AGNCY("DFT1", 2, PgwFlowConstants.FLOW_SECTOR, PgwFlowConstants.FLOW_AGENCY,
			PgwFlowConstants.FLOW_FINANCIAL),
	DFT_FINANCIAL("DFT2", 3, PgwFlowConstants.FLOW_AGENCY, PgwFlowConstants.FLOW_FINANCIAL,
			PgwFlowConstants.FLOW_WORKER),
	DFT_WORKER("DFT3", 4, PgwFlowConstants.FLOW_FINANCIAL, PgwFlowConstants.FLOW_WORKER,
			PgwFlowConstants.FLOW_COMPANY),
	DFT_COMPANY("DFT4", 5, PgwFlowConstants.FLOW_WORKER, PgwFlowConstants.FLOW_COMPANY, null),
	SUMMARY("DFT4", 5, PgwFlowConstants.FLOW_COMPANY, PgwFlowConstants.FLOW_SUMMARY, null),
	DQ("DQ", 6, PgwFlowConstants.FLOW_COMPANY, PgwFlowConstants.FLOW_DATAQ, null),
	AKS_ASGNMNT("ASG1", 7, PgwFlowConstants.FLOW_COMPANY, PgwFlowConstants.FLOW_ASG_INTRVW, null),
	KDN_VERIFY("VER1", 7, PgwFlowConstants.FLOW_COMPANY, PgwFlowConstants.FLOW_KDNV, PgwFlowConstants.FLOW_JTK),
	JTK_APPRV("JTK", 8, PgwFlowConstants.FLOW_COMPANY, PgwFlowConstants.FLOW_JTK, PgwFlowConstants.FLOW_REG_AGENCY),
	CONSTRCTN_CIDB("AKS1", 9, PgwFlowConstants.FLOW_JTK, PgwFlowConstants.FLOW_REG_AGENCY, PgwFlowConstants.FLOW_KDN),
	MNFCTRE_MITI("AKS2", 9, PgwFlowConstants.FLOW_JTK, PgwFlowConstants.FLOW_REG_AGENCY, PgwFlowConstants.FLOW_KDN),
	AGRCLTRE_MOA("AKS3", 9, PgwFlowConstants.FLOW_JTK, PgwFlowConstants.FLOW_REG_AGENCY, PgwFlowConstants.FLOW_KDN),
	SRVCS_KPDNKK("AKS4", 9, PgwFlowConstants.FLOW_JTK, PgwFlowConstants.FLOW_REG_AGENCY, PgwFlowConstants.FLOW_KDN),
	PLNTTN_MPIC("AKS5", 9, PgwFlowConstants.FLOW_JTK, PgwFlowConstants.FLOW_REG_AGENCY, PgwFlowConstants.FLOW_KDN),
	SRVCS_MOTAC("AKS6", 9, PgwFlowConstants.FLOW_JTK, PgwFlowConstants.FLOW_REG_AGENCY, PgwFlowConstants.FLOW_KDN),
	KDN_APPRV("KDN", 10, PgwFlowConstants.FLOW_REG_AGENCY, PgwFlowConstants.FLOW_KDN, null),
	RETURN("RTN", 0, null, null, null),
	ABORTED("ABT", 0, null, null, null),
	APPRVD("APR", 11, null, null, null),
	AMND("AMND", 11, null, null, null),
	RJCTD("REJ", 11, null, null, null),
	PEND_LEVY_AMT("QSUB", 11, null, null, null),
	PAID("PAID", 11, null, null, null),
	COMPLETED("CMP", 11, null, null, null),
	COMPANY_EMP("DFT4", 0, PgwFlowConstants.FLOW_FINANCIAL, PgwFlowConstants.FLOW_COMPANY,
			PgwFlowConstants.FLOW_QUOTA),
	CANCEL("CAN", 0, null, null, null),
	KEEP_IN_VIEW("KIV", 0, null, null, null)

	;

	private final String status;

	private final Integer indicator;

	private final String prevFlow;

	private final String currFlow;

	private final String nextFlow;


	PgwAppStatusEnum(String status, Integer indicator, String prevFlow, String currFlow, String nextFlow) {
		this.status = status;
		this.indicator = indicator;
		this.prevFlow = prevFlow;
		this.currFlow = currFlow;
		this.nextFlow = nextFlow;
	}


	public static PgwAppStatusEnum findByIndicator(Integer indicator) {
		for (PgwAppStatusEnum v : PgwAppStatusEnum.values()) {
			if (v.getIndicator().equals(indicator)) {
				return v;
			}
		}

		return null;
	}


	public static PgwAppStatusEnum findByStatus(String status) {
		for (PgwAppStatusEnum v : PgwAppStatusEnum.values()) {
			if (v.getStatus().equals(status)) {
				return v;
			}
		}

		return null;
	}


	public static String getStatus(String status) {
		StringBuilder sb = new StringBuilder();
		for (PgwAppStatusEnum v : PgwAppStatusEnum.values()) {
			if (v.getStatus().equals(status)) {
				sb.append(v.getStatus());
				break;
			}
			sb.append(v.getStatus()).append(",");
		}
		return sb.toString();
	}


	public String getStatus() {
		return status;
	}


	public Integer getIndicator() {
		return indicator;
	}


	public String getCurrFlow() {
		return currFlow;
	}


	public String getNextFlow() {
		return nextFlow;
	}


	public String getPrevFlow() {
		return prevFlow;
	}

}
