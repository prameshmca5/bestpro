package com.bestpay.pgw.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.PgwMerchantContact;
import com.bestpay.pgw.util.QualifierConstants;

@Repository
@RepositoryDefinition(domainClass = PgwMerchantContact.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_CONTACT_DAO)
public interface PgwMerchantContactRepository extends GenericRepository<PgwMerchantContact> {
	
	@Query("select u from PgwMerchantContact u where u.merchantId = :merchantId ")
	public PgwMerchantContact findbyMerchantId(@Param("merchantId") String merchantId);

}
