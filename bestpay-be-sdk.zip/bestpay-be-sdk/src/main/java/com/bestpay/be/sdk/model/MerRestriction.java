/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;


/**
 * @author Atiqah
 * @since June 20, 2018
 */
public class MerRestriction implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1864073233598003483L;

	private String merchantId;

	private String allowCountryIp;

	private String acceptedCountryIp;

	private String allowCountryCc;

	private String acceptedCountryCc;

	private String userId;


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getAllowCountryIp() {
		return allowCountryIp;
	}


	public void setAllowCountryIp(String allowCountryIp) {
		this.allowCountryIp = allowCountryIp;
	}


	public String getAcceptedCountryIp() {
		return acceptedCountryIp;
	}


	public void setAcceptedCountryIp(String acceptedCountryIp) {
		this.acceptedCountryIp = acceptedCountryIp;
	}


	public String getAllowCountryCc() {
		return allowCountryCc;
	}


	public void setAllowCountryCc(String allowCountryCc) {
		this.allowCountryCc = allowCountryCc;
	}


	public String getAcceptedCountryCc() {
		return acceptedCountryCc;
	}


	public void setAcceptedCountryCc(String acceptedCountryCc) {
		this.acceptedCountryCc = acceptedCountryCc;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}

}