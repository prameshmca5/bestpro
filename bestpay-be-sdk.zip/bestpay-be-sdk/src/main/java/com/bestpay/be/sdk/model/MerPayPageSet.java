/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author Atiqah
 * @since June 21, 2018
 */
public class MerPayPageSet implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1864073233598003483L;

	private Integer paymentId;

	private String protocolReturnUrl;

	private String returnUrl;

	private String returnUrlWithIpn;

	private String protocolCallbackUrl;

	private String callbackUrl;

	private String callbackUrlWithIpn;

	private String verifyKey;

	private Integer enableVerify;

	private String emailNotification;

	private String receipt;

	private Integer canModifyOid;

	private Integer canModifyAmt;

	private String cantModifyDesc;

	private String emailLock;

	private String nameLock;

	private String phoneLock;

	private String merchantId;

	private String docMgtId;

	private String userId;

	private String sellerId;

	private Timestamp createDt;

	private Timestamp updateDt;
	
	private Integer pdpa;


	public String getProtocolReturnUrl() {
		return protocolReturnUrl;
	}


	public void setProtocolReturnUrl(String protocolReturnUrl) {
		this.protocolReturnUrl = protocolReturnUrl;
	}


	public String getReturnUrl() {
		return returnUrl;
	}


	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}


	public String getReturnUrlWithIpn() {
		return returnUrlWithIpn;
	}


	public void setReturnUrlWithIpn(String returnUrlWithIpn) {
		this.returnUrlWithIpn = returnUrlWithIpn;
	}


	public String getProtocolCallbackUrl() {
		return protocolCallbackUrl;
	}


	public void setProtocolCallbackUrl(String protocolCallbackUrl) {
		this.protocolCallbackUrl = protocolCallbackUrl;
	}


	public String getCallbackUrl() {
		return callbackUrl;
	}


	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}


	public String getCallbackUrlWithIpn() {
		return callbackUrlWithIpn;
	}


	public void setCallbackUrlWithIpn(String callbackUrlWithIpn) {
		this.callbackUrlWithIpn = callbackUrlWithIpn;
	}


	public String getVerifyKey() {
		return verifyKey;
	}


	public void setVerifyKey(String verifyKey) {
		this.verifyKey = verifyKey;
	}


	public Integer getEnableVerify() {
		return enableVerify;
	}


	public void setEnableVerify(Integer enableVerify) {
		this.enableVerify = enableVerify;
	}


	public String getEmailNotification() {
		return emailNotification;
	}


	public void setEmailNotification(String emailNotification) {
		this.emailNotification = emailNotification;
	}


	public String getReceipt() {
		return receipt;
	}


	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}


	public Integer getCanModifyOid() {
		return canModifyOid;
	}


	public void setCanModifyOid(Integer canModifyOid) {
		this.canModifyOid = canModifyOid;
	}


	public Integer getCanModifyAmt() {
		return canModifyAmt;
	}


	public void setCanModifyAmt(Integer canModifyAmt) {
		this.canModifyAmt = canModifyAmt;
	}


	public String getCantModifyDesc() {
		return cantModifyDesc;
	}


	public void setCantModifyDesc(String cantModifyDesc) {
		this.cantModifyDesc = cantModifyDesc;
	}


	public String getEmailLock() {
		return emailLock;
	}


	public void setEmailLock(String emailLock) {
		this.emailLock = emailLock;
	}


	public String getNameLock() {
		return nameLock;
	}


	public void setNameLock(String nameLock) {
		this.nameLock = nameLock;
	}


	public String getPhoneLock() {
		return phoneLock;
	}


	public void setPhoneLock(String phoneLock) {
		this.phoneLock = phoneLock;
	}


	public Integer getPaymentId() {
		return paymentId;
	}


	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getDocMgtId() {
		return docMgtId;
	}


	public void setDocMgtId(String docMgtId) {
		this.docMgtId = docMgtId;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getSellerId() {
		return sellerId;
	}


	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Integer getPdpa() {
		return pdpa;
	}


	public void setPdpa(Integer pdpa) {
		this.pdpa = pdpa;
	}

	
}