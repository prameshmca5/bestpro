/**
 * 
 */
package com.be.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.apache.http.annotation.Experimental;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTrxnDocumentRepository;
import com.be.model.BeTrxnDocument;
import com.be.model.BeTrxnDocumentPK;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.TrxnDocuments;
import com.dm.sdk.model.Documents;
import com.util.BaseUtil;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_TRXN_DOC_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TRXN_DOC_SVC)
public class BeTrxnDocumentService extends AbstractService<BeTrxnDocument> {

	@Autowired
	BeTrxnDocumentRepository beTrxnDocumentDao;
	 
	@Override
	public GenericRepository<BeTrxnDocument> primaryDao() {
		return beTrxnDocumentDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<BeTrxnDocument> createUpdate(List<TrxnDocuments> dtoList, String userId, String docRefNo) {

		List<BeTrxnDocument> beTrxnDocuments = new ArrayList<>();
		for(TrxnDocuments dto : dtoList) {
			if(!BaseUtil.isObjNull(dto.getDocMgtId())) {
				BeTrxnDocument trxnDocument = beTrxnDocumentDao.findTxnDocByRefNoDocId(docRefNo, dto.getDocId(),
						dto.getDocMgtId());
	
				if (BaseUtil.isObjNull(trxnDocument)) {
					trxnDocument = new BeTrxnDocument();
					trxnDocument.setId(new BeTrxnDocumentPK(docRefNo, dto.getDocId(), dto.getDocMgtId()));
					trxnDocument.setCreateId(userId);
				}
	
				trxnDocument.setDocContentType(dto.getDocContentType());
				trxnDocument.setUpdateId(userId);
				beTrxnDocuments.add(trxnDocument);
			}
		}
		return beTrxnDocumentDao.save(beTrxnDocuments);
	}
	
	public List<BeTrxnDocument> createUpdateDoc(List<Documents> docList, String userId, String docRefNo) {

		List<BeTrxnDocument> beTrxnDocuments = new ArrayList<>();
		for(Documents doc : docList) {
			BeTrxnDocument trxnDocument = beTrxnDocumentDao.findTxnDocByRefNoDocId(docRefNo, doc.getDocid(),
					doc.getId());

			if (BaseUtil.isObjNull(trxnDocument)) {
				trxnDocument = new BeTrxnDocument();
				trxnDocument.setId(new BeTrxnDocumentPK(docRefNo, doc.getDocid(), doc.getId()));
				trxnDocument.setCreateId(userId);
			}

			trxnDocument.setDocContentType(doc.getContentType());
			trxnDocument.setUpdateId(userId);
			beTrxnDocuments.add(trxnDocument);
		}
		return beTrxnDocumentDao.save(beTrxnDocuments);
	}
	
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public BeTrxnDocument findTrxnDocumentsByRefNo(String docRefNo) {
		
		BeTrxnDocument beTrxnDocument = new BeTrxnDocument();
		List<BeTrxnDocument> beTrxnDocuments = new ArrayList<>();
		beTrxnDocuments = beTrxnDocumentDao.findByDocRefNo(docRefNo);
		if(!BaseUtil.isObjNull(beTrxnDocuments) && beTrxnDocuments.size() > 0) {
			beTrxnDocument = beTrxnDocuments.get(0);
		}
		return  beTrxnDocument;
	}
	
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<BeTrxnDocument> findTrxnDocumentsByDocRefNo(String docRefNo) {
		return beTrxnDocumentDao.findByDocRefNo(docRefNo);
	}
	
	@Experimental
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public BeTrxnDocument findTrxnDocumentsByRefNoAndDocId(String docRefNo, Integer docId) { 
		return beTrxnDocumentDao.findTrxnDocumentsByRefNoAndDocId(docRefNo, docId);
	}
	
}
