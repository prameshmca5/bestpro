/**
 *
 */
package com.bestpay.pgw.sdk.client;


import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bestpay.pgw.sdk.constants.PgwUrlConstants;


/**
 * @author hafidz 9 July 2018
 */
public class PgwPaymentVerifyHashUrl {

	private static final Logger logger = LoggerFactory.getLogger(PgwPaymentVerifyHashUrl.class);

	private String originalUrl;

	private String urlWithoutHash;

	private boolean isUrlHashVerified = false;

	private String requestHash; // either reqhash or reshash

	private String queryString;


	public PgwPaymentVerifyHashUrl(String url) {
		originalUrl = url;
		initialise();
	}


	private void initialise() {
		URL urlnew;
		try {
			urlnew = new URL(originalUrl);
			queryString = urlnew.getQuery();
		} catch (MalformedURLException e1) {
			logger.error(e1.getLocalizedMessage());
		}

		// look for reqhash in url
		Pattern pattern = Pattern.compile(PgwUrlConstants.PGW_PAYMENT_REQHASH_PATTERN);
		Matcher m = pattern.matcher(originalUrl);
		while (m.find()) {
			// assign hash value
			requestHash = m.group(1);
		}
		// if pattern above found means reqhash exist in url
		if (requestHash != null && !requestHash.isEmpty()) {
			// reset url without hash parameter
			urlWithoutHash = originalUrl.replaceAll(PgwUrlConstants.PGW_PAYMENT_REQHASH_PATTERN, "");
		} else { // else look for reshash in url
			pattern = Pattern.compile(PgwUrlConstants.PGW_PAYMENT_RESHASH_PATTERN);
			m = pattern.matcher(originalUrl);
			while (m.find()) {
				// assign hash value
				requestHash = m.group(1);
			}
			// if pattern above found means reshash exist in url
			if (requestHash != null && !requestHash.isEmpty()) {
				// reset url without hash parameter
				urlWithoutHash = originalUrl.replaceAll(PgwUrlConstants.PGW_PAYMENT_RESHASH_PATTERN, "");
			}
		}
		// assume default similar to passing url
		if (urlWithoutHash == null || urlWithoutHash.isEmpty()) {
			urlWithoutHash = originalUrl;
		}

	}


	/**
	 *
	 * @param text
	 * @return
	 */
	private String messageDigest(String text) {
		MessageDigest digest;
		try {
			digest = MessageDigest.getInstance("SHA-256");
			byte[] hash = digest.digest(text.getBytes(StandardCharsets.UTF_8));
			return new String(Hex.encodeHex(hash));
		} catch (NoSuchAlgorithmException e) {
			logger.error(e.getLocalizedMessage());
		}
		return "";
	}


	/**
	 *
	 * @return
	 *
	 * 		Trim url by removing &reqhash query String example
	 *         http://localhost:8060/bestpay-portal-pgw/bestpay/verify?
	 *         &merchantId=bestpay_dev2&orderId=asdfsdfas&amount=3000
	 *         &currency=MYR
	 *         &reqhash=b8bdaf9755540cce647d7ea0116ad2c48a06dcfe9d83b533e0f40847c15728db
	 *
	 *
	 */
	public String getUrlWithoutHash() {
		return urlWithoutHash;
	}


	/**
	 *
	 * @param txnId
	 * @param orderId
	 * @param status
	 * @param merchantId
	 * @param amount
	 * @param currency
	 * @return
	 *
	 * 		first_hash = hash (sha256, b4u_tranId + b4u_orderId + b4u_status
	 *         + b4u_merchantId + b4u_amount + b4u_currency)
	 */
	private String generateFirstHash(String txnId, String orderId, String status, String merchantId, double amount,
			String currency) {
		String hexString = null;
		StringBuilder sb = new StringBuilder(txnId).append(orderId).append(status).append(merchantId)
				.append(String.valueOf(amount)).append(currency);
		hexString = messageDigest(sb.toString());
		return hexString;
	}


	/**
	 *
	 * @param paymentDate
	 * @param merchantId
	 * @param firstHash
	 * @param paymentCode
	 * @param verifyKey
	 * @return
	 *
	 * 		final_hash = hash (sha256, b4u_txndate + b4u_merchantId +
	 *         first_hash + b4u_paymentcode + verify_key)
	 */
	private String generateFinalHash(String paymentDate, String merchantId, String firstHash, String paymentCode,
			String verifyKey) {
		String hexString = null;
		StringBuilder sb = new StringBuilder(paymentDate).append(merchantId).append(firstHash).append(paymentCode)
				.append(verifyKey);
		hexString = messageDigest(sb.toString());
		return hexString;

	}


	/**
	 *
	 * @param merchantId
	 * @param currency
	 * @param orderId
	 * @param amount
	 * @param verifyKey
	 * @return
	 *
	 * 		b4u_reqhash = hash (sha256, merchantId + currency + orderId +
	 *         amount + verify_key)
	 */
	public String generateReqhash(String merchantId, String currency, String orderId, double amount,
			String verifyKey) {
		String hexString = null;
		StringBuilder sb = new StringBuilder(merchantId).append(currency).append(orderId)
				.append(String.valueOf(amount)).append(verifyKey);
		hexString = messageDigest(sb.toString());
		return hexString;
	}


	/**
	 *
	 * @param merchantId
	 * @param currency
	 * @param orderId
	 * @param amount
	 * @param verifyKey
	 * @return
	 */
	public boolean isUrlReqhashVerified(String merchantId, String currency, String orderId, double amount,
			String verifyKey) {

		// requestHash value should be retrieved from url query string passed
		// from constructor
		if (urlWithoutHash == null || urlWithoutHash.isEmpty() || requestHash == null || requestHash.isEmpty()) {
			if (logger.isDebugEnabled()) {
				logger.debug("RequestHash is empty : {}", requestHash);
			}
			isUrlHashVerified = false;
		}

		// generate new reqhash
		String hexString = generateReqhash(merchantId, currency, orderId, amount, verifyKey);

		if (logger.isDebugEnabled()) {
			StringBuilder buff = new StringBuilder();
			buff.append("Inside PgwPaymentVerifyHashUrl.getUrlWithReqhash() ").append("\n merchantId: ")
					.append(merchantId).append("\n currency: ").append(currency).append("\n orderId: ")
					.append(orderId).append("\n amount: ").append(amount).append("\n reqhash from url: ")
					.append(requestHash).append("\n verifyKey: ").append(verifyKey)
					.append("\n hash string generated: ").append(hexString);

			logger.debug(buff.toString());
		}

		// if validate success new generated reqhash vs url reqhash
		if (hexString.equals(requestHash)) {
			isUrlHashVerified = true;
		}
		return isUrlHashVerified;
	}


	/**
	 *
	 * @param merchantId
	 * @param currency
	 * @param orderId
	 * @param amount
	 * @param verifyKey
	 * @return
	 *
	 * 		return url with &reqhash=generated hex value
	 */
	public String getUrlWithReqhash(String merchantId, String currency, String orderId, double amount,
			String verifyKey) {
		// check if Query String already contains reqhash, change nothing
		Pattern pattern = Pattern.compile(PgwUrlConstants.PGW_PAYMENT_REQHASH_PATTERN);
		Matcher m = pattern.matcher(queryString);
		if (m.find()) {
			logger.info("{}  hash is available. Print url : {}", PgwUrlConstants.PGW_PAYMENT_REQHASH_KEY,
					originalUrl);
			return originalUrl;
		}

		String hexString = generateReqhash(merchantId, currency, orderId, amount, verifyKey);

		if (logger.isDebugEnabled()) {
			StringBuilder buff = new StringBuilder();
			buff.append("Inside PgwPaymentVerifyHashUrl.getUrlWithReqhash() ").append("\n merchantId: ")
					.append(merchantId).append("\n currency: ").append(currency).append("\n orderId: ")
					.append(orderId).append("\n amount: ").append(amount).append("\n reqhash from url: ")
					.append(requestHash).append("\n verifyKey: ").append(verifyKey)
					.append("\n hash string generated: ").append(hexString);

			logger.debug(buff.toString());
		}

		StringBuilder urlWithHash = new StringBuilder(urlWithoutHash).append("&")
				.append(PgwUrlConstants.PGW_PAYMENT_REQHASH_KEY).append("=").append(hexString);
		return urlWithHash.toString();
	}


	/**
	 *
	 * @param txnId
	 * @param orderId
	 * @param status
	 * @param merchantId
	 * @param amount
	 * @param currency
	 * @param paymentDate
	 * @param paymentCode
	 * @param verifyKey
	 * @return
	 *
	 * 		first_hash = hash (sha256, b4u_tranId + b4u_orderId + b4u_status
	 *         + b4u_merchantId + b4u_amount + b4u_currency) final_hash = hash
	 *         (sha256, b4u_txndate + b4u_merchantId + first_hash +
	 *         b4u_paymentcode + verify_key) b4u_reshash = final_hash
	 *
	 */
	public String generateReshash(String txnId, String orderId, String status, String merchantId, double amount,
			String currency, String paymentDate, String paymentCode, String verifyKey) {
		String finalHash = null;
		String firstHash = generateFirstHash(txnId, orderId, status, merchantId, amount, currency);
		finalHash = generateFinalHash(paymentDate, merchantId, firstHash, paymentCode, verifyKey);
		return finalHash;
	}


	/**
	 *
	 * @param txnId
	 * @param orderId
	 * @param status
	 * @param merchantId
	 * @param amount
	 * @param currency
	 * @param paymentDate
	 * @param paymentCode
	 * @param verifyKey
	 * @return
	 */
	public boolean isUrlReshashVerified(String txnId, String orderId, String status, String merchantId, double amount,
			String currency, String paymentDate, String paymentCode, String verifyKey) {
		// requestHash value should be retrieved from url query string passed
		// from constructor
		if (urlWithoutHash == null || urlWithoutHash.isEmpty() || requestHash == null || requestHash.isEmpty()) {
			if (logger.isDebugEnabled()) {
				logger.debug("RequestHash is empty : {}", requestHash);
			}
			isUrlHashVerified = false;
		}

		// generate new reshash
		String hexString = generateReshash(txnId, orderId, status, merchantId, amount, currency, paymentDate,
				paymentCode, verifyKey);

		// if validate success new generated reqhash vs url reqhash
		if (hexString.equals(requestHash)) {
			isUrlHashVerified = true;
		}
		return isUrlHashVerified;
	}


	/**
	 *
	 * @param txnId
	 * @param orderId
	 * @param status
	 * @param merchantId
	 * @param amount
	 * @param currency
	 * @param paymentDate
	 * @param paymentCode
	 * @param verifyKey
	 * @return
	 *
	 * 		return url with &reshash=generated hex value
	 */
	public String getUrlWithReshash(String txnId, String orderId, String status, String merchantId, double amount,
			String currency, String paymentDate, String paymentCode, String verifyKey) {
		// check if Query String already contains reqhash, change nothing
		Pattern pattern = Pattern.compile(PgwUrlConstants.PGW_PAYMENT_RESHASH_PATTERN);
		Matcher m = pattern.matcher(queryString);
		if (m.find()) {
			logger.info("{}  hash is available. Print url : {}", PgwUrlConstants.PGW_PAYMENT_RESHASH_KEY,
					originalUrl);
			return originalUrl;
		}

		// generate new reshash
		String hexString = generateReshash(txnId, orderId, status, merchantId, amount, currency, paymentDate,
				paymentCode, verifyKey);
		StringBuilder urlWithHash = new StringBuilder(urlWithoutHash).append("&")
				.append(PgwUrlConstants.PGW_PAYMENT_RESHASH_KEY).append("=").append(hexString);
		return urlWithHash.toString();

	}

}
