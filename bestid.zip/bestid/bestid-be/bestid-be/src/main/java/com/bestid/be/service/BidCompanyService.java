/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidCompany;
import com.bestid.be.repo.BidCompanyRepository;
import com.bestid.be.repo.GenericRepository;

/**
 * @author suhada
 * @since Feb 22, 2019
 */
@Transactional
@Service(QualifierConstants.BID_CMPNY_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_CMPNY_SVC)
public class BidCompanyService extends AbstractService<BidCompany> {

	@Autowired
	@Qualifier(QualifierConstants.BID_CMPNY_REPOSITORY)
	BidCompanyRepository bidCompanyDao;

	@Override
	public GenericRepository<BidCompany> primaryDao() {
		return bidCompanyDao;
	}

	public BidCompany findByCmpnyRegNo(String cmpnyRegNo) {
		return bidCompanyDao.findByCmpnyRegNo(cmpnyRegNo);
	}

}
