/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_TVL_PAYMENT_KIPLE")
public class BeTvlPaymentKiple extends AbstractEntity implements Serializable, IQfCriteria<BeTvlPaymentKiple> {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TVL_PMT_KIPLE_ID")
	private Integer tvlPmtKipleId;

	@Column(name = "PMT_REF_NO")
	private String pmtRefNo;

	@Column(name = "CBS_REF_NO")
	private String cbsRefNo;

	@Column(name = "RCPT_REF_NO")
	private String rcptRefNo;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	@Temporal(TemporalType.DATE)
	@Column(name = "TRXN_DT")
	private Date trxnDt;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CHANNEL_CODE")
	private RefChannel channel;

	@Column(name = "CURRENCY")
	private String currency;

	@Column(name = "AMOUNT")
	private double amount;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATUS_CD")
	private RefPymntMsgCode statusPymntMsgCode;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "RESP_CD")
	private RefPymntMsgCode respPymntMsgCode;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PMT_MTHD_MTDT_ID")
	private RefMetadata pmtMthdMtdt;

	@Column(name = "PMT_BY")
	private String pmtBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "PMT_DT")
	private Date pmtDt;

	@Column(name = "DOC_REF_NO")
	private String docRefNo;

	@Column(name = "MESSAGE_ID")
	private String messageId;

	@Column(name = "REQ_DATA")
	private String reqData;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getTvlPmtKipleId() {
		return tvlPmtKipleId;
	}


	public void setTvlPmtKipleId(Integer tvlPmtKipleId) {
		this.tvlPmtKipleId = tvlPmtKipleId;
	}


	public String getPmtRefNo() {
		return pmtRefNo;
	}


	public void setPmtRefNo(String pmtRefNo) {
		this.pmtRefNo = pmtRefNo;
	}


	public String getCbsRefNo() {
		return cbsRefNo;
	}


	public void setCbsRefNo(String cbsRefNo) {
		this.cbsRefNo = cbsRefNo;
	}


	public Date getTrxnDt() {
		return trxnDt;
	}


	public void setTrxnDt(Date trxnDt) {
		this.trxnDt = trxnDt;
	}


	public RefChannel getChannel() {
		return channel;
	}


	public void setChannel(RefChannel channel) {
		this.channel = channel;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}

	public RefPymntMsgCode getStatusPymntMsgCode() {
		return statusPymntMsgCode;
	}


	public void setStatusPymntMsgCode(RefPymntMsgCode statusPymntMsgCode) {
		this.statusPymntMsgCode = statusPymntMsgCode;
	}


	public RefPymntMsgCode getRespPymntMsgCode() {
		return respPymntMsgCode;
	}


	public void setRespPymntMsgCode(RefPymntMsgCode respPymntMsgCode) {
		this.respPymntMsgCode = respPymntMsgCode;
	}


	public String getPmtBy() {
		return pmtBy;
	}


	public void setPmtBy(String pmtBy) {
		this.pmtBy = pmtBy;
	}


	public Date getPmtDt() {
		return pmtDt;
	}


	public void setPmtDt(Date pmtDt) {
		this.pmtDt = pmtDt;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getRcptRefNo() {
		return rcptRefNo;
	}


	public void setRcptRefNo(String rcptRefNo) {
		this.rcptRefNo = rcptRefNo;
	}


	public RefMetadata getPmtMthdMtdt() {
		return pmtMthdMtdt;
	}


	public void setPmtMthdMtdt(RefMetadata pmtMthdMtdt) {
		this.pmtMthdMtdt = pmtMthdMtdt;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public String getMessageId() {
		return messageId;
	}


	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}


	public String getReqData() {
		return reqData;
	}


	public void setReqData(String reqData) {
		this.reqData = reqData;
	}

}
