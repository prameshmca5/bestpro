/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 * @author michelle.angela
 *
 */
public class AcctTraveller implements Serializable, IQfCriteria<AcctTraveller> {

	private static final long serialVersionUID = 4065733882849446740L;

	private Integer acctTvlrId;

	private AcctProfile acctProfile;

	private String fullName;

	private String email;

	private String contactNo;

	private String gender;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date dob;

	private Country birthPlace;

	private Country nationality;

	private AcctPassport acctPassport;

	private Integer faceId;

	private String photoId;

	private Integer passportFaceId;

	private String passportPhotoId;

	private Metadata relationMtdt;

	private String emrgncyCntctName;

	private String emrgncyCntctNo;

	private String ecEmail;

	private Metadata ecRelationMtdt;

	private String addr1;

	private String addr2;

	private String addr3;

	private String addr4;

	private String cityDesc;

	private String stateDesc;

	private Country country;

	private String zipcode;

	private Metadata typeMtdt;

	private String passportNo;

	private List<TrxnDocuments> trxnDocumentList;

	private boolean isView;

	private Integer acctProfId;

	private List<Integer> acctTvlrIdList;

	private Boolean isPaid;

	private String typeMtdtCd;

	private String relationMtdtCd;

	public String emailToCompare;

	public String dobStr;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date passportExp;

	private String passportExpStr;

	private String nationalityCd;

	private Metadata appsMtdt;


	public String getEmailToCompare() {
		return emailToCompare;
	}


	public void setEmailToCompare(String emailToCompare) {
		this.emailToCompare = emailToCompare;
	}


	public Integer getAcctTvlrId() {
		return acctTvlrId;
	}


	public void setAcctTvlrId(Integer acctTvlrId) {
		this.acctTvlrId = acctTvlrId;
	}


	public AcctProfile getAcctProfile() {
		return acctProfile;
	}


	public void setAcctProfile(AcctProfile acctProfile) {
		this.acctProfile = acctProfile;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName.toUpperCase();
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender.toUpperCase();
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public Country getBirthPlace() {
		return birthPlace;
	}


	public void setBirthPlace(Country birthPlace) {
		this.birthPlace = birthPlace;
	}


	public Country getNationality() {
		return nationality;
	}


	public void setNationality(Country nationality) {
		this.nationality = nationality;
	}


	public AcctPassport getAcctPassport() {
		return acctPassport;
	}


	public void setAcctPassport(AcctPassport acctPassport) {
		this.acctPassport = acctPassport;
	}


	public Integer getFaceId() {
		return faceId;
	}


	public void setFaceId(Integer faceId) {
		this.faceId = faceId;
	}


	public String getPhotoId() {
		return photoId;
	}


	public void setPhotoId(String photoId) {
		this.photoId = photoId;
	}


	public String getPassportNo() {
		return passportNo;
	}


	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo.toUpperCase();
	}


	public List<TrxnDocuments> getTrxnDocumentList() {
		return trxnDocumentList;
	}


	public void setTrxnDocumentList(List<TrxnDocuments> trxnDocumentList) {
		this.trxnDocumentList = trxnDocumentList;
	}


	public Integer getPassportFaceId() {
		return passportFaceId;
	}


	public void setPassportFaceId(Integer passportFaceId) {
		this.passportFaceId = passportFaceId;
	}


	public String getPassportPhotoId() {
		return passportPhotoId;
	}


	public void setPassportPhotoId(String passportPhotoId) {
		this.passportPhotoId = passportPhotoId;
	}


	public Metadata getRelationMtdt() {
		return relationMtdt;
	}


	public void setRelationMtdt(Metadata relationMtdt) {
		this.relationMtdt = relationMtdt;
	}


	public String getEmrgncyCntctName() {
		return emrgncyCntctName;
	}


	public void setEmrgncyCntctName(String emrgncyCntctName) {
		this.emrgncyCntctName = emrgncyCntctName.toUpperCase();
	}


	public String getEmrgncyCntctNo() {
		return emrgncyCntctNo;
	}


	public void setEmrgncyCntctNo(String emrgncyCntctNo) {
		this.emrgncyCntctNo = emrgncyCntctNo;
	}


	public String getEcEmail() {
		return ecEmail;
	}


	public void setEcEmail(String ecEmail) {
		this.ecEmail = ecEmail;
	}


	public Metadata getEcRelationMtdt() {
		return ecRelationMtdt;
	}


	public void setEcRelationMtdt(Metadata ecRelationMtdt) {
		this.ecRelationMtdt = ecRelationMtdt;
	}


	public String getAddr1() {
		return addr1;
	}


	public void setAddr1(String addr1) {
		this.addr1 = addr1.toUpperCase();
	}


	public String getAddr2() {
		return addr2;
	}


	public void setAddr2(String addr2) {
		this.addr2 = addr2.toUpperCase();
	}


	public String getAddr3() {
		return addr3;
	}


	public void setAddr3(String addr3) {
		this.addr3 = addr3.toUpperCase();
	}


	public String getAddr4() {
		return addr4;
	}


	public void setAddr4(String addr4) {
		this.addr4 = addr4.toUpperCase();
	}


	public String getCityDesc() {
		return cityDesc;
	}


	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc.toUpperCase();
	}


	public String getStateDesc() {
		return stateDesc;
	}


	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc.toUpperCase();
	}


	public Country getCountry() {
		return country;
	}


	public void setCountry(Country country) {
		this.country = country;
	}


	public String getZipcode() {
		return zipcode;
	}


	public Metadata getTypeMtdt() {
		return typeMtdt;
	}


	public void setTypeMtdt(Metadata typeMtdt) {
		this.typeMtdt = typeMtdt;
	}


	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}


	public boolean isView() {
		return isView;
	}


	public void setView(boolean isView) {
		this.isView = isView;
	}


	public Integer getAcctProfId() {
		return acctProfId;
	}


	public void setAcctProfId(Integer acctProfId) {
		this.acctProfId = acctProfId;
	}


	public List<Integer> getAcctTvlrIdList() {
		return acctTvlrIdList;
	}


	public void setAcctTvlrIdList(List<Integer> acctTvlrIdList) {
		this.acctTvlrIdList = acctTvlrIdList;
	}


	public Boolean getIsPaid() {
		return isPaid;
	}


	public void setIsPaid(Boolean isPaid) {
		this.isPaid = isPaid;
	}


	public String getTypeMtdtCd() {
		return typeMtdtCd;
	}


	public void setTypeMtdtCd(String typeMtdtCd) {
		this.typeMtdtCd = typeMtdtCd;
	}


	public String getRelationMtdtCd() {
		return relationMtdtCd;
	}


	public void setRelationMtdtCd(String relationMtdtCd) {
		this.relationMtdtCd = relationMtdtCd;
	}


	public String getDobStr() {
		return dobStr;
	}


	public void setDobStr(String dobStr) {
		this.dobStr = dobStr;
	}


	public Date getPassportExp() {
		return passportExp;
	}


	public void setPassportExp(Date passportExp) {
		this.passportExp = passportExp;
	}


	public String getPassportExpStr() {
		return passportExpStr;
	}


	public void setPassportExpStr(String passportExpStr) {
		this.passportExpStr = passportExpStr;
	}


	public String getNationalityCd() {
		return nationalityCd;
	}


	public void setNationalityCd(String nationalityCd) {
		this.nationalityCd = nationalityCd;
	}


	public Metadata getAppsMtdt() {
		return appsMtdt;
	}


	public void setAppsMtdt(Metadata appsMtdt) {
		this.appsMtdt = appsMtdt;
	}

}
