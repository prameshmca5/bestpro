/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwMerchantBlacklist;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.BlacklistInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.DateUtil;
import com.bstsb.util.MediaType;

/**
 * @author Afif Saman
 * @since June 6, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.BLCKLST)
public class BlacklistRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BlacklistRestController.class);

	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<BlacklistInfo> searchBlacklistPaginated(@Valid @RequestBody BlacklistInfo blacklistInfo,
			HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwMerchantBlacklist> result = pgwMerchantBlacklistService.searchBlacklist(blacklistInfo,
				dataTableInRQ);
		DataTableResults<BlacklistInfo> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			dataTableInResp.setDraw(result.getDraw());
			dataTableInResp.setError(result.getError());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<BlacklistInfo> bpLst = new ArrayList<>();
				for (PgwMerchantBlacklist bbp : result.getData()) {
					BlacklistInfo trustee = dozerMapper.map(bbp, BlacklistInfo.class);
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		return dataTableInResp;
	}

	@PostMapping(value = BeUrlConstants.CREATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public BlacklistInfo addBlacklist(@Valid @RequestBody BlacklistInfo blacklistInfo, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		String value = "";
		LOGGER.info("Create new blacklist ... ");
		if (blacklistInfo == null) {// blacklistInfo null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		if (StringUtils.isBlank(blacklistInfo.getTag())) {// no tag
			throw new BeException(BeErrorCodeEnum.I400IDM137, new String[] { "Tag", "Blacklist" });
		}

		PgwMerchantBlacklist blcklst = new PgwMerchantBlacklist();
		BlacklistInfo blcklstInfo = new BlacklistInfo();
		Date date = new Date();
		if (BaseUtil.isEqualsCaseIgnore(blacklistInfo.getTag(), "email")) {
			value = blacklistInfo.getEmailValue();
		} else {
			value = blacklistInfo.getMobileValue();
		}

		if (StringUtils.isBlank(value)) {// no values
			throw new BeException(BeErrorCodeEnum.I400IDM137, new String[] { "Value", "Blacklist" });
		}

		PgwMerchantBlacklist blacklist = super.pgwMerchantBlacklistService.findBlacklistByValue(value);

		if (BaseUtil.isObjNull(blacklist)) {
			blcklst.setValue(value);
			blcklst.setTag(blacklistInfo.getTag());
			blcklst.setMerchantId(blacklistInfo.getMerchantId());
			blcklst.setBan(1);
			blcklst.setCreateId(blacklistInfo.getUserId());
			blcklst.setUpdateId(blacklistInfo.getUserId());
			blcklst.setCreateDate(DateUtil.convertDate2SqlTimeStamp(date));
			super.pgwMerchantBlacklistService.create(blcklst);
		} else {
			throw new BeException(BeErrorCodeEnum.I404APJ110);
		}

		return blcklstInfo;
	}

	@DeleteMapping(value = "{blcklstId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public boolean delete(@PathVariable String blcklstId) throws BeException {
		if (StringUtils.isBlank(blcklstId)) {
			throw new BeException(BeErrorCodeEnum.E400APJ246, new String[] { "blcklstId" });
		}
		PgwMerchantBlacklist pgwMerchantBlacklist = pgwMerchantBlacklistService.findByBlacklistId(blcklstId);
		if (pgwMerchantBlacklist == null) {
			throw new BeException(BeErrorCodeEnum.E404BLC001, new String[] { "blcklstId" });
		}
		pgwMerchantBlacklistService.primaryDao().delete(pgwMerchantBlacklist);
		return true;
	}

}
