/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.constants;


/**
 * Constants for Mail Template Code
 *
 * @author mary.jane
 * @since Dec 21, 2018
 */
public class MailTemplateConstants {

	private MailTemplateConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String CMN_OTP = "CMN_OTP";

	public static final String IDM_REG_SUCCESS = "IDM_REGISTER_SUCCESS";

	public static final String EVISA_APP_INTERVIEW = "EVISA_APP_INTERVIEW";

	public static final String EVISA_PMT_UNSUCCESSFULL = "EVISA_PMT_UNSUCCESSFULL";

	public static final String EVISA_PMT_SUCCESSFULL = "EVISA_PMT_SUCCESSFULL";

	public static final String EVISA_INTERVIEW_REMINDER = "EVISA_INTERVIEW_REMINDER";

	public static final String EVISA_APP_SUCCESSFULL = "EVISA_APP_SUCCESSFULL";

	public static final String EVISA_APP_UNSUCCESSFULL = "EVISA_APP_UNSUCCESSFULL";

	public static final String EVISA_DQ_SL_FAIL = "EVISA_DQ_SL_FAIL";

	public static final String GEN_ACTIVATION_CODE_SMS = "GEN_ACTIVATION_CODE_SMS";

	public static final String GEN_INVITATION_CODE_SMS = "GEN_INVITATION_CODE_SMS";

}
