/**
 *  
 */
package com.bestpay.pgw.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.PgwTransactionHistory;
import com.bestpay.pgw.util.QualifierConstants;

/**
 * @author Chaithanya Kumar
 * @since 17/07/2018
 */
@Repository
@RepositoryDefinition(domainClass = PgwTransactionHistory.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_TRANSACTION_HIS_DAO)
public interface PgwTransactionHistoryRepository extends GenericRepository<PgwTransactionHistory> {
	
	@Query("select u from PgwTransactionHistory u where u.orderId=:orderId")
	public List<PgwTransactionHistory> findByOrderIDGetDetails (@Param("orderId") String orderId);

	  
}