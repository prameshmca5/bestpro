/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.RefConfigRepository;
import com.bestpay.pgw.model.PgwConfig;
import com.bestpay.pgw.util.QualifierConstants;

/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
@Service(QualifierConstants.CONFIG_PGW_CONFIG_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.CONFIG_PGW_CONFIG_SVC)
@Transactional(QualifierConstants.TRANS_MANAGER)
public class RefConfigService extends AbstractService<PgwConfig> {

	@Autowired
	private RefConfigRepository pgwPayConfigDao;

	@Override
	public GenericRepository<PgwConfig> primaryDao() {
		return pgwPayConfigDao;
	}

	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = true, rollbackFor = Exception.class)
	public PgwConfig findByConfigCode(String configCode) {
		return pgwPayConfigDao.findByConfigCode(configCode);
	}

	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = Exception.class)
	public List<PgwConfig> updateAll(List<PgwConfig> configs) {
		for (PgwConfig config : configs) {
			pgwPayConfigDao.saveAndFlush(config);
		}
		return configs;
	}

}