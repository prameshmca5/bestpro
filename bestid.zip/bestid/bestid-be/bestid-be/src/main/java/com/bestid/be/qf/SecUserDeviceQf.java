/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.qf;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.SecUserDevice;
import com.bstsb.util.BaseUtil;


/**
 * @author Naem Othman
 * @since March 04, 2019
 */
@Service(QualifierConstants.SEC_USER_DEVICE_QF)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.SEC_USER_DEVICE_QF)
@Transactional
public class SecUserDeviceQf extends QueryFactory<SecUserDevice> {

	protected Logger logger = LoggerFactory.getLogger(this.getClass());

	@PersistenceContext
	private EntityManager em;


	@Override
	public Specification<SecUserDevice> searchByProperty(final SecUserDevice t) {
		return new Specification<SecUserDevice>() {

			@Override
			public Predicate toPredicate(Root<SecUserDevice> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<Predicate> predLst = new ArrayList<>();

				if (!BaseUtil.isObjNull(t.getDeviceId())) {
					predLst.add(cb.and(cb.equal(root.get("deviceId"), t.getDeviceId())));
				}

				if (!BaseUtil.isObjNull(t.getUserId())) {
					predLst.add(cb.and(cb.equal(root.get("userId"), t.getUserId())));
				}

				if (!BaseUtil.isObjNull(t.getUserName())) {
					predLst.add(cb.and(cb.equal(root.get("userName"), t.getUserName())));
				}

				if (!BaseUtil.isObjNull(t.getMachineId())) {
					predLst.add(cb.and(cb.equal(root.get("machineId"), t.getMachineId())));
				}

				if (!BaseUtil.isObjNull(t.getSdkVersion())) {
					predLst.add(cb.and(cb.equal(root.get("sdkVersion"), t.getSdkVersion())));
				}

				if (!BaseUtil.isObjNull(t.getModel())) {
					predLst.add(cb.and(cb.equal(root.get("model"), t.getModel())));
				}

				if (!BaseUtil.isObjNull(t.getBrand())) {
					predLst.add(cb.and(cb.equal(root.get("brand"), t.getBrand())));
				}

				if (!BaseUtil.isObjNull(t.getManufacturer())) {
					predLst.add(cb.and(cb.equal(root.get("manufacturer"), t.getManufacturer())));
				}

				if (!BaseUtil.isObjNull(t.getGeoLocation())) {
					predLst.add(cb.and(cb.equal(root.get("geoLocation"), t.getGeoLocation())));
				}

				if (!BaseUtil.isObjNull(t.getStatus())) {
					predLst.add(cb.and(cb.equal(root.get("status"), t.getStatus())));
				}

				if (!BaseUtil.isObjNull(t.getCertStatus())) {
					predLst.add(cb.and(cb.equal(root.get("certStatus"), t.getCertStatus())));
				}

				if (!BaseUtil.isObjNull(t.getIsCertInstall())) {
					predLst.add(cb.and(cb.equal(root.get("isCertInstall"), t.getIsCertInstall())));
				}

				if (!BaseUtil.isObjNull(t.getMobileNo())) {
					predLst.add(cb.and(cb.equal(root.get("mobileNo"), t.getMobileNo())));
				}

				if (!BaseUtil.isObjNull(t.getEmail())) {
					predLst.add(cb.and(cb.equal(root.get("email"), t.getEmail())));
				}

				if (!BaseUtil.isObjNull(t.getUuid())) {
					predLst.add(cb.and(cb.equal(root.get("uuid"), t.getUuid())));
				}

				if (!BaseUtil.isListNull(predLst)) {
					return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
				}
				return query.getRestriction();
			}
		};
	}

}
