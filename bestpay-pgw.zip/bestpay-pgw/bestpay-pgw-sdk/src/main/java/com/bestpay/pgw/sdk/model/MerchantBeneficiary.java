package com.bestpay.pgw.sdk.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author Ramesh Pongiannan
 * @since June 22, 2019
 */
public class MerchantBeneficiary implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private Integer benId;

	private String merchantId;

	private String mtoId;

	private String benefeciaryId;

	private String country;

	private String createId;

	private Timestamp createDt;

	private Timestamp updateDt;

	private String updateId;

	public Integer getBenId() {
		return benId;
	}

	public void setBenId(Integer benId) {
		this.benId = benId;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getMtoId() {
		return mtoId;
	}

	public void setMtoId(String mtoId) {
		this.mtoId = mtoId;
	}

	public String getBenefeciaryId() {
		return benefeciaryId;
	}

	public void setBenefeciaryId(String benefeciaryId) {
		this.benefeciaryId = benefeciaryId;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
