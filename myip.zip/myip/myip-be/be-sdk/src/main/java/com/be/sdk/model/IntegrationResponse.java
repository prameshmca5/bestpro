/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author michelle.angela
 *
 */
public class IntegrationResponse implements Serializable {

	private static final long serialVersionUID = -4407251036185622142L;

	@JsonProperty("Status")
	private String status;

	@JsonProperty("Message")
	private String message;

	private Data data;
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	public class Data {
		
		@JsonProperty("MRZdata")
		private MRZdata mrzData;

		public MRZdata getMrzData() {
			return mrzData;
		}

		public void setMrzData(MRZdata mrzData) {
			this.mrzData = mrzData;
		}
		
	}
}
