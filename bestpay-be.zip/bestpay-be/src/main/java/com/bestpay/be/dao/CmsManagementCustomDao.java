package com.bestpay.be.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.bestpay.be.model.RefChannel;
import com.bestpay.be.sdk.model.Channel;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.pagination.PaginationCriteria;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;


@Repository
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.CMS_MGMT_CUSTOM_DAO)
public class CmsManagementCustomDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(MerchantProfileCustomDao.class);

	@Autowired
	private RefChannelRepository refChannelRepository;

	@PersistenceContext
	private EntityManager entityManager;


	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}


	public DataTableResults<RefChannel> searchChannelByPagination(Channel channel, DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append("from RefChannel r ");
		sb.append(" where 1=1 ");

		if (!BaseUtil.isObjNull(channel.getName())) {
			sb.append(" and r.name LIKE :name ");
		}

		if (!BaseUtil.isObjNull(channel.getPublicName())) {
			sb.append(" and r.publicName = :publicName ");
		}

		if (!BaseUtil.isObjNull(channel.getType())) {
			sb.append(" and r.type = :type ");
		}

		sb.append(" order by r.createDt desc ");

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause("r"));
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<RefChannel> query = entityManager.createQuery(sb.toString(), RefChannel.class);
		// Original Query
		TypedQuery<RefChannel> query2 = entityManager.createQuery(sb.toString(), RefChannel.class);

		if (!BaseUtil.isObjNull(channel.getName())) {
			query.setParameter("name", "%" + channel.getName() + "%");
			query2.setParameter("name", "%" + channel.getName() + "%");
		}

		if (!BaseUtil.isObjNull(channel.getPublicName())) {
			query.setParameter("publicName", "%" + channel.getPublicName() + "%");
			query2.setParameter("publicName", "%" + channel.getPublicName() + "%");
		}

		if (!BaseUtil.isObjNull(channel.getType())) {
			query.setParameter("type", channel.getType());
			query2.setParameter("type", channel.getType());
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<RefChannel> dataTableResult = new DataTableResults<>();
		List<RefChannel> svcResp = query.getResultList();
		List<RefChannel> svcResp2 = query2.getResultList();
		LOGGER.debug("Filtered Size: {}", svcResp.size());
		LOGGER.debug("Original Size: {}", svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : refChannelRepository.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		LOGGER.debug("isFilterByEmpty: {}", dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}
		return dataTableResult;
	}

}
