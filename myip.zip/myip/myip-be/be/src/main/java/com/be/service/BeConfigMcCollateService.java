/**
 *
 */
package com.be.service;


import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.ConfigConstants;
import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeConfigMcCollateQf;
import com.be.dao.BeConfigMcCollateRepository;
import com.be.model.BeConfigMcCollate;
import com.be.sdk.model.IQfCriteria;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_CONFIG_MC_COLLATE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_CONFIG_MC_COLLATE_SVC)
public class BeConfigMcCollateService extends AbstractService<BeConfigMcCollate> {

	@Autowired
	private BeConfigMcCollateRepository beConfigMcCollateDao;

	@Autowired
	private BeConfigMcCollateQf beConfigMcCollateQf;


	@Override
	public GenericRepository<BeConfigMcCollate> primaryDao() {
		return beConfigMcCollateDao;
	}


	@Override
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beConfigMcCollateQf.generateCriteria(cb, from, criteria);
	}


	@Override
	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_CONFIG_MC_COLLATE_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<BeConfigMcCollate> findAll() {
		return beConfigMcCollateDao.findAll();
	}


	public List<BeConfigMcCollate> searchAllByProperty(BeConfigMcCollate beConfigMcCollate) {
		return beConfigMcCollateQf.searchAllByProperty(beConfigMcCollate);
	}

}
