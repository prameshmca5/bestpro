/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.controller;


import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestid.be.model.RefDocument;
import com.bestid.be.sdk.constants.BeErrorCodeEnum;
import com.bestid.be.sdk.constants.BeUrlConstants;
import com.bestid.be.sdk.exception.BeException;
import com.bestid.be.sdk.model.RefDocuments;
import com.bestid.be.service.RefDocumentService;
import com.bstsb.util.BaseUtil;



/**
 * @author Mary Jane Buenaventura
 * @since Nov 3, 2016
 */
@RestController
@RequestMapping(BeUrlConstants.REFERENCE)
public class ReferenceRestController extends AbstractRestController {

	@Autowired
	private RefDocumentService refDocumentService;



	@GetMapping(value = "/refDocList", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<RefDocuments> getRefDocList(HttpServletRequest request) {
		List<RefDocuments> resList = new ArrayList<>();
		List<RefDocument> paymentTypeList = refDocumentService.findAll();

		RefDocuments doc;
		for (RefDocument cnt : paymentTypeList) {
			doc = dozerMapper.map(cnt, RefDocuments.class);
			resList.add(doc);
		}
		return resList;
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_DOCUMENTS_ID + "/{docId}", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public RefDocuments findDocById(@PathVariable Integer docId, HttpServletRequest request) throws BeException {

		RefDocument refdoc = refDocumentService.find(docId);

		if (BaseUtil.isObjNull(refdoc)) {
			throw new BeException(BeErrorCodeEnum.E404BST004);
		}

		return dozerMapper.map(refdoc, RefDocuments.class);
	}

}