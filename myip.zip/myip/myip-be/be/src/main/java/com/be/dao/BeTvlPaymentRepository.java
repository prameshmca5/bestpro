/**
 * 
 */
package com.be.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.BeTvlPayment;

/**
 * @author michelle.angela
 *
 */
@Lazy
@Repository
@RepositoryDefinition(domainClass = BeTvlPayment.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_PAYMENT_DAO)
public interface BeTvlPaymentRepository extends GenericRepository<BeTvlPayment> {

	@Query("select u from BeTvlPayment u where u.pmtRefNo = :pmtRefNo")
	public BeTvlPayment findByReferenceNo(@Param("pmtRefNo") String pmtRefNo);
}
