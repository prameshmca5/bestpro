/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 * @author michelle.angela
 *
 */
public class Trip implements Serializable, IQfCriteria<Trip> {

	private static final long serialVersionUID = -1743045478321851012L;

	private Integer tvlTripId;

	private String tvlTripCodeNo;

	private TvlProfile tvlProfile;

	private String tvlMode;

	private String flightNo;

	private String airlines;

	private IntAirport departureAirport;

	private Date departureDt;

	private String departureTime;

	private IntAirport arrivalAirport;

	private Date arrivalDt;

	private String arrivalTime;

	private String tvlPurpose;

	private String stayDuration;

	private String stayAddress;

	private String docRefNo;

	private String passportNo;

	private String fullName;

	private List<TrxnDocuments> trxnDocumentList;

	private List<TripAccommodation> tripAccommodations;

	private List<TripHealth> tripHealths;

	private Integer tvlProfId;

	private Integer statusId;

	private Date submitDt;

	private List<FileUpload> fileUploads;

	private boolean embedTvl;

	private List<Tvl> tvls;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date submittedDateFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date submittedDateTo;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date departureDtFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date departureDtTo;

	private String trxnRefNo;

	private boolean embedTvlStats;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date arrivalDtFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date arrivalDtTo;

	private Metadata tripPlanMtdt;

	private String tvlModeRtn;

	private String flightNoRtn;

	private String airlinesRtn;

	private IntAirport departureAirportRtn;

	private Date departureDtRtn;

	private String departureTimeRtn;

	private IntAirport arrivalAirportRtn;

	private Integer acctProfId;

	private List<Integer> tvlProfIdList;

	private Metadata appsMtdt;


	public Integer getTvlTripId() {
		return tvlTripId;
	}


	public void setTvlTripId(Integer tvlTripId) {
		this.tvlTripId = tvlTripId;
	}


	public String getTvlTripCodeNo() {
		return tvlTripCodeNo;
	}


	public void setTvlTripCodeNo(String tvlTripCodeNo) {
		this.tvlTripCodeNo = tvlTripCodeNo;
	}


	public TvlProfile getTvlProfile() {
		return tvlProfile;
	}


	public void setTvlProfile(TvlProfile tvlProfile) {
		this.tvlProfile = tvlProfile;
	}


	public String getTvlMode() {
		return tvlMode;
	}


	public void setTvlMode(String tvlMode) {
		this.tvlMode = tvlMode.toUpperCase();
	}


	public String getFlightNo() {
		return flightNo;
	}


	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo.toUpperCase();
	}


	public String getAirlines() {
		return airlines;
	}


	public void setAirlines(String airlines) {
		this.airlines = airlines.toUpperCase();
	}


	public Date getDepartureDt() {
		return departureDt;
	}


	public void setDepartureDt(Date departureDt) {
		this.departureDt = departureDt;
	}


	public String getDepartureTime() {
		return departureTime;
	}


	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}


	public Date getArrivalDt() {
		return arrivalDt;
	}


	public void setArrivalDt(Date arrivalDt) {
		this.arrivalDt = arrivalDt;
	}


	public String getArrivalTime() {
		return arrivalTime;
	}


	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}


	public String getTvlPurpose() {
		return tvlPurpose;
	}


	public void setTvlPurpose(String tvlPurpose) {
		this.tvlPurpose = tvlPurpose;
	}


	public String getStayDuration() {
		return stayDuration;
	}


	public void setStayDuration(String stayDuration) {
		this.stayDuration = stayDuration;
	}


	public String getStayAddress() {
		return stayAddress;
	}


	public void setStayAddress(String stayAddress) {
		this.stayAddress = stayAddress.toUpperCase();
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public String getPassportNo() {
		return passportNo;
	}


	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public List<TrxnDocuments> getTrxnDocumentList() {
		return trxnDocumentList;
	}


	public void setTrxnDocumentList(List<TrxnDocuments> trxnDocumentList) {
		this.trxnDocumentList = trxnDocumentList;
	}


	public List<TripAccommodation> getTripAccommodations() {
		return tripAccommodations;
	}


	public void setTripAccommodations(List<TripAccommodation> tripAccommodations) {
		this.tripAccommodations = tripAccommodations;
	}


	public List<TripHealth> getTripHealths() {
		return tripHealths;
	}


	public void setTripHealths(List<TripHealth> tripHealths) {
		this.tripHealths = tripHealths;
	}


	public Integer getTvlProfId() {
		return tvlProfId;
	}


	public void setTvlProfId(Integer tvlProfId) {
		this.tvlProfId = tvlProfId;
	}


	public Integer getStatusId() {
		return statusId;
	}


	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}


	public IntAirport getDepartureAirport() {
		return departureAirport;
	}


	public void setDepartureAirport(IntAirport departureAirport) {
		this.departureAirport = departureAirport;
	}


	public IntAirport getArrivalAirport() {
		return arrivalAirport;
	}


	public void setArrivalAirport(IntAirport arrivalAirport) {
		this.arrivalAirport = arrivalAirport;
	}


	public Date getSubmitDt() {
		return submitDt;
	}


	public void setSubmitDt(Date submitDt) {
		this.submitDt = submitDt;
	}


	public List<FileUpload> getFileUploads() {
		return fileUploads;
	}


	public void setFileUploads(List<FileUpload> fileUploads) {
		this.fileUploads = fileUploads;
	}


	public boolean isEmbedTvl() {
		return embedTvl;
	}


	public void setEmbedTvl(boolean embedTvl) {
		this.embedTvl = embedTvl;
	}


	public List<Tvl> getTvls() {
		return tvls;
	}


	public void setTvls(List<Tvl> tvls) {
		this.tvls = tvls;
	}


	public Date getSubmittedDateFrom() {
		return submittedDateFrom;
	}


	public void setSubmittedDateFrom(Date submittedDateFrom) {
		this.submittedDateFrom = submittedDateFrom;
	}


	public Date getSubmittedDateTo() {
		return submittedDateTo;
	}


	public void setSubmittedDateTo(Date submittedDateTo) {
		this.submittedDateTo = submittedDateTo;
	}


	public Date getDepartureDtFrom() {
		return departureDtFrom;
	}


	public void setDepartureDtFrom(Date departureDtFrom) {
		this.departureDtFrom = departureDtFrom;
	}


	public Date getDepartureDtTo() {
		return departureDtTo;
	}


	public void setDepartureDtTo(Date departureDtTo) {
		this.departureDtTo = departureDtTo;
	}


	public String getTrxnRefNo() {
		return trxnRefNo;
	}


	public void setTrxnRefNo(String trxnRefNo) {
		this.trxnRefNo = trxnRefNo;
	}


	public boolean isEmbedTvlStats() {
		return embedTvlStats;
	}


	public void setEmbedTvlStats(boolean embedTvlStats) {
		this.embedTvlStats = embedTvlStats;
	}


	public Date getArrivalDtFrom() {
		return arrivalDtFrom;
	}


	public void setArrivalDtFrom(Date arrivalDtFrom) {
		this.arrivalDtFrom = arrivalDtFrom;
	}


	public Date getArrivalDtTo() {
		return arrivalDtTo;
	}


	public void setArrivalDtTo(Date arrivalDtTo) {
		this.arrivalDtTo = arrivalDtTo;
	}


	public Metadata getTripPlanMtdt() {
		return tripPlanMtdt;
	}


	public void setTripPlanMtdt(Metadata tripPlanMtdt) {
		this.tripPlanMtdt = tripPlanMtdt;
	}


	public String getTvlModeRtn() {
		return tvlModeRtn;
	}


	public void setTvlModeRtn(String tvlModeRtn) {
		this.tvlModeRtn = tvlModeRtn.toUpperCase();
	}


	public String getFlightNoRtn() {
		return flightNoRtn;
	}


	public void setFlightNoRtn(String flightNoRtn) {
		this.flightNoRtn = flightNoRtn.toUpperCase();
	}


	public String getAirlinesRtn() {
		return airlinesRtn;
	}


	public void setAirlinesRtn(String airlinesRtn) {
		this.airlinesRtn = airlinesRtn.toUpperCase();
	}


	public IntAirport getDepartureAirportRtn() {
		return departureAirportRtn;
	}


	public void setDepartureAirportRtn(IntAirport departureAirportRtn) {
		this.departureAirportRtn = departureAirportRtn;
	}


	public Date getDepartureDtRtn() {
		return departureDtRtn;
	}


	public void setDepartureDtRtn(Date departureDtRtn) {
		this.departureDtRtn = departureDtRtn;
	}


	public String getDepartureTimeRtn() {
		return departureTimeRtn;
	}


	public void setDepartureTimeRtn(String departureTimeRtn) {
		this.departureTimeRtn = departureTimeRtn;
	}


	public IntAirport getArrivalAirportRtn() {
		return arrivalAirportRtn;
	}


	public void setArrivalAirportRtn(IntAirport arrivalAirportRtn) {
		this.arrivalAirportRtn = arrivalAirportRtn;
	}


	public Integer getAcctProfId() {
		return acctProfId;
	}


	public void setAcctProfId(Integer acctProfId) {
		this.acctProfId = acctProfId;
	}


	public List<Integer> getTvlProfIdList() {
		return tvlProfIdList;
	}


	public void setTvlProfIdList(List<Integer> tvlProfIdList) {
		this.tvlProfIdList = tvlProfIdList;
	}


	public Metadata getAppsMtdt() {
		return appsMtdt;
	}


	public void setAppsMtdt(Metadata appsMtdt) {
		this.appsMtdt = appsMtdt;
	}

}
