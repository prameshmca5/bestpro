package com.bestpay.be.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwMerchantCompany;
import com.bestpay.be.util.QualifierConstants;


@Repository
@RepositoryDefinition(domainClass = PgwMerchantCompany.class, idClass = Integer.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_COMPANY_DAO)
public interface PgwMerchantCompanyRepository extends GenericRepository<PgwMerchantCompany> {

	@Query("select u from PgwMerchantCompany u ")
	public List<PgwMerchantCompany> findAllMerchantCompany();


	@Query("select count(u) from PgwMerchantCompany u ")
	public int totalRecords();


	@Query("select t from PgwMerchantCompany t where t.companyId = :companyId ")
	public PgwMerchantCompany findCompanyByCompanyId(@Param("companyId") Integer companyId);
	
	
	@Query("select t from PgwMerchantCompany t where t.compRefId = :compRefId ")
	public PgwMerchantCompany findCompanyByCompRefId(@Param("compRefId") String compRefId);

}
