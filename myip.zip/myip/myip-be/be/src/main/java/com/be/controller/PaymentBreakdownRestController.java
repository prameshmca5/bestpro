/**
 * 
 */
package com.be.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.model.BeConfigPaymentBreakdown;
 
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.ConfigPaymentBreakdown;
import com.be.sdk.model.PaymentDtl;
import com.be.service.BeConfigPaymentBreakdownService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;
import com.util.pagination.DataTableRequest;
import com.util.pagination.DataTableResults;

/**
 * @author Ramesh Pongianann
 *
 */
@Lazy
@RestController
@RequestMapping(BeUrlConstants.PAYMENTBREAKDOWN)
public class PaymentBreakdownRestController extends AbstractRestController {

	@Autowired
	private BeConfigPaymentBreakdownService beConfigPaymentBreakdownSvc;
	
	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<ConfigPaymentBreakdown> searchPaymentPaginated(@RequestBody ConfigPaymentBreakdown dto,
			HttpServletRequest request) throws IOException {

		DataTableRequest<ConfigPaymentBreakdown> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) beConfigPaymentBreakdownSvc.getCount(dto);
		List<ConfigPaymentBreakdown> filtered = beConfigPaymentBreakdownSvc.searchBeTvlPaymentbrkdownPagination(dto, dataTableInRQ);
		
		if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("ALL DATA: {}", totalCount);
            LOGGER.debug("ALL filtered DATA : {}", filtered);
        }

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}
	
	@PostMapping(value = BeUrlConstants.GET_DETAIL, consumes = { MediaType.APPLICATION_JSON }, produces = {	MediaType.APPLICATION_JSON })
	public ConfigPaymentBreakdown getTravellerDetail(@RequestBody ConfigPaymentBreakdown dto, HttpServletRequest request) throws IOException {
		return JsonUtil.transferToObject(beConfigPaymentBreakdownSvc.searchBeTvlPaymentBreakdown(dto), ConfigPaymentBreakdown.class);
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.INFO_ADD, consumes = { MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<BeConfigPaymentBreakdown> addPaymentInfo(@RequestBody List<BeConfigPaymentBreakdown> dtoList, @RequestParam("pmtRefNo") String pmtRefNo,
			HttpServletRequest request) throws IOException {
		
		List<BeConfigPaymentBreakdown> payments = new ArrayList<BeConfigPaymentBreakdown>();
		if(!BaseUtil.isListNull(dtoList)) {
			payments = JsonUtil.transferToList(beConfigPaymentBreakdownSvc.addPaymentInfo(JsonUtil.transferToList(dtoList, BeConfigPaymentBreakdown.class), pmtRefNo), BeConfigPaymentBreakdown.class);
		}
		return payments;
	} 
	
	@PostMapping(value = BeUrlConstants.GET_LIST, consumes = { MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<ConfigPaymentBreakdown> getBeConfigPaymentBreakdown(@RequestBody ConfigPaymentBreakdown dto,
			HttpServletRequest request) throws IOException {
		return beConfigPaymentBreakdownSvc.searchBeTvlPaymentbrkdownPagination(dto, null);
	} 
}
