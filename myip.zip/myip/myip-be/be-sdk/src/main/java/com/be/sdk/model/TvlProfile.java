/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 * @author michelle.angela
 *
 */
public class TvlProfile implements Serializable, IQfCriteria<TvlProfile> {

	private static final long serialVersionUID = 6227378224788535869L;

	private Integer tvlProfId;

	private AcctTraveller acctTraveller;

	private String trxnRefNo;

	private Date trxnDt;

	private String fullName;

	private String email;

	private String contactNo;

	private String gender;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date dob;

	private Country birthPlace;

	private Country nationality;

	private AcctPassport acctPassport;

	private Integer faceId;

	private String photoId;

	private Integer passportFaceId;

	private String passportPhotoId;

	private String docRefNo;

	private List<McAttendance> tvlMcAttendances;

	private List<TvlTestResult> tvlTestResults;

	private McAttendance mcAttendance;

	private TvlTestResult tvlTestResult;

	private String passportNo;

	private Metadata relationMtdt;

	private String emrgncyCntctName;

	private String emrgncyCntctNo;

	private String ecEmail;

	private Metadata ecRelationMtdt;

	private String addr1;

	private String addr2;

	private String addr3;

	private String addr4;

	private String cityDesc;

	private String stateDesc;

	private Country country;

	private String zipcode;

	private Metadata typeMtdt;

	private Boolean isDisabled;


	public Integer getTvlProfId() {
		return tvlProfId;
	}


	public void setTvlProfId(Integer tvlProfId) {
		this.tvlProfId = tvlProfId;
	}


	public AcctTraveller getAcctTraveller() {
		return acctTraveller;
	}


	public void setAcctTraveller(AcctTraveller acctTraveller) {
		this.acctTraveller = acctTraveller;
	}


	public String getTrxnRefNo() {
		return trxnRefNo;
	}


	public void setTrxnRefNo(String trxnRefNo) {
		this.trxnRefNo = trxnRefNo;
	}


	public Date getTrxnDt() {
		return trxnDt;
	}


	public void setTrxnDt(Date trxnDt) {
		this.trxnDt = trxnDt;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public Country getBirthPlace() {
		return birthPlace;
	}


	public void setBirthPlace(Country birthPlace) {
		this.birthPlace = birthPlace;
	}


	public Country getNationality() {
		return nationality;
	}


	public void setNationality(Country nationality) {
		this.nationality = nationality;
	}


	public AcctPassport getAcctPassport() {
		return acctPassport;
	}


	public void setAcctPassport(AcctPassport acctPassport) {
		this.acctPassport = acctPassport;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public List<McAttendance> getTvlMcAttendances() {
		return tvlMcAttendances;
	}


	public void setTvlMcAttendances(List<McAttendance> tvlMcAttendances) {
		this.tvlMcAttendances = tvlMcAttendances;
	}


	public List<TvlTestResult> getTvlTestResults() {
		return tvlTestResults;
	}


	public void setTvlTestResults(List<TvlTestResult> tvlTestResults) {
		this.tvlTestResults = tvlTestResults;
	}


	public McAttendance getMcAttendance() {
		return mcAttendance;
	}


	public void setMcAttendance(McAttendance mcAttendance) {
		this.mcAttendance = mcAttendance;
	}


	public TvlTestResult getTvlTestResult() {
		return tvlTestResult;
	}


	public void setTvlTestResult(TvlTestResult tvlTestResult) {
		this.tvlTestResult = tvlTestResult;
	}


	public String getPassportNo() {
		return passportNo;
	}


	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}


	public Metadata getRelationMtdt() {
		return relationMtdt;
	}


	public void setRelationMtdt(Metadata relationMtdt) {
		this.relationMtdt = relationMtdt;
	}


	public String getEmrgncyCntctName() {
		return emrgncyCntctName;
	}


	public void setEmrgncyCntctName(String emrgncyCntctName) {
		this.emrgncyCntctName = emrgncyCntctName;
	}


	public String getEmrgncyCntctNo() {
		return emrgncyCntctNo;
	}


	public void setEmrgncyCntctNo(String emrgncyCntctNo) {
		this.emrgncyCntctNo = emrgncyCntctNo;
	}


	public String getEcEmail() {
		return ecEmail;
	}


	public void setEcEmail(String ecEmail) {
		this.ecEmail = ecEmail;
	}


	public Metadata getEcRelationMtdt() {
		return ecRelationMtdt;
	}


	public void setEcRelationMtdt(Metadata ecRelationMtdt) {
		this.ecRelationMtdt = ecRelationMtdt;
	}


	public String getAddr1() {
		return addr1;
	}


	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}


	public String getAddr2() {
		return addr2;
	}


	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}


	public String getAddr3() {
		return addr3;
	}


	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}


	public String getAddr4() {
		return addr4;
	}


	public void setAddr4(String addr4) {
		this.addr4 = addr4;
	}


	public String getCityDesc() {
		return cityDesc;
	}


	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc;
	}


	public String getStateDesc() {
		return stateDesc;
	}


	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc;
	}


	public Country getCountry() {
		return country;
	}


	public void setCountry(Country country) {
		this.country = country;
	}


	public String getZipcode() {
		return zipcode;
	}


	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public Integer getFaceId() {
		return faceId;
	}


	public void setFaceId(Integer faceId) {
		this.faceId = faceId;
	}


	public String getPhotoId() {
		return photoId;
	}


	public void setPhotoId(String photoId) {
		this.photoId = photoId;
	}


	public Integer getPassportFaceId() {
		return passportFaceId;
	}


	public void setPassportFaceId(Integer passportFaceId) {
		this.passportFaceId = passportFaceId;
	}


	public String getPassportPhotoId() {
		return passportPhotoId;
	}


	public void setPassportPhotoId(String passportPhotoId) {
		this.passportPhotoId = passportPhotoId;
	}


	public Metadata getTypeMtdt() {
		return typeMtdt;
	}


	public void setTypeMtdt(Metadata typeMtdt) {
		this.typeMtdt = typeMtdt;
	}


	public Boolean getDisabled() {
		return isDisabled;
	}


	public void setDisabled(Boolean isDisabled) {
		this.isDisabled = isDisabled;
	}

}
