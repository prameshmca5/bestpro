package com.be.sdk.model;

import java.util.Date;

public class UpdateInsuranceSearchPage {

	private Date paymentDateFrom;
	private Date paymentDateTo;
	private String passportNo;
	private String name;
	private String paymentRefNo;
	private String status;
	public Date getPaymentDateFrom() {
		return paymentDateFrom;
	}
	public void setPaymentDateFrom(Date paymentDateFrom) {
		this.paymentDateFrom = paymentDateFrom;
	}
	public Date getPaymentDateTo() {
		return paymentDateTo;
	}
	public void setPaymentDateTo(Date paymentDateTo) {
		this.paymentDateTo = paymentDateTo;
	}
	public String getPassportNo() {
		return passportNo;
	}
	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPaymentRefNo() {
		return paymentRefNo;
	}
	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
