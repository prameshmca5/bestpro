package com.be.sdk.builder;


import java.util.Arrays;
import java.util.List;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.TrxnDocuments;


public class TrxnDocumentService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public TrxnDocumentService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	public TrxnDocuments searchTrxnDocuments(String docRefNo, Integer docId) {
		TrxnDocuments dto = new TrxnDocuments();
		dto.setDocRefNo(docRefNo);
		dto.setDocId(docId);
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRXN_DOCUMENTS);
		sb.append(BeUrlConstants.SEARCH_TRXN_DOCUMENT);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, TrxnDocuments.class);
	}


	public List<TrxnDocuments> getTrxnDocuments(String docRefNo) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRXN_DOCUMENTS);
		sb.append(BeUrlConstants.GET_LIST);
		sb.append("?docRefNo=" + docRefNo);
		TrxnDocuments[] docArray = restTemplate().getForObject(getServiceURI(sb.toString()), TrxnDocuments[].class);
		return Arrays.asList(docArray);
	}


	public List<TrxnDocuments> addDocInfo(List<TrxnDocuments> dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRXN_DOCUMENTS);
		sb.append(BeUrlConstants.INFO_ADD_DOC);
		TrxnDocuments[] docArray = restTemplate().postForObject(getServiceURI(sb.toString()), dto,
				TrxnDocuments[].class);
		return Arrays.asList(docArray);
	}
}
