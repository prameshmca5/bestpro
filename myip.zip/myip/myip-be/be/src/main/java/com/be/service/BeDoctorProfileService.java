/**
 *
 */
package com.be.service;


import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeDoctorProfileQf;
import com.be.dao.BeDoctorProfileRepository;
import com.be.model.BeDoctorProfile;
import com.be.sdk.model.DoctorProfile;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.TrxnDocuments;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_DOCTOR_PROFILE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_DOCTOR_PROFILE_SVC)
public class BeDoctorProfileService extends AbstractService<BeDoctorProfile> {

	@Autowired
	BeDoctorProfileRepository beDoctorProfileDao;

	@Autowired
	BeDoctorProfileQf beDoctorProfileQf;

	@Autowired
	BeTrxnDocumentService beTrxnDocumentSvc;


	@Override
	public GenericRepository<BeDoctorProfile> primaryDao() {
		return beDoctorProfileDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return beDoctorProfileQf.generateCriteria(cb, from, criteria);
	}


	public List<BeDoctorProfile> findListByMcProfId(Integer mcProfId) {
		return beDoctorProfileDao.findByMcProfId(mcProfId);
	}


	public BeDoctorProfile searchBeDoctorProfile(DoctorProfile dto) {
		return beDoctorProfileQf.searchBeDoctorProfile(dto);
	}


	@SuppressWarnings("unchecked")
	public List<DoctorProfile> searchDoctorPagination(DoctorProfile dto, DataTableRequest<?> dataTableInRQ)
			throws IOException {
		return JsonUtil.transferToList(beDoctorProfileQf.searchBeDoctorProfilePagination(dto, dataTableInRQ),
				DoctorProfile.class);
	}


	public long getCount(DoctorProfile dto) {
		return beDoctorProfileQf.getCount(dto);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class })
	public BeDoctorProfile createUpdate(BeDoctorProfile beDoctorProfile, BeDoctorProfile beDoctorProfileOri,
			HttpServletRequest request, String reguser, List<TrxnDocuments> docs) {

		String userId = getCurrUserId(request);
		getIdmService(request).getUserProfileById(userId, false, false);

		if (BaseUtil.isObjNull(beDoctorProfile.getDocProfId())) {
			beDoctorProfile.setCreateId(userId);
			beDoctorProfile.setIsActive(true);
		} else {

			beDoctorProfile.setCreateId(beDoctorProfileOri.getCreateId());
			beDoctorProfile.setCreateDt(beDoctorProfileOri.getCreateDt());
		}
		if (!BaseUtil.isListNull(docs)) {
			beTrxnDocumentSvc.createUpdate(docs, userId, beDoctorProfile.getDocRefNo());
		}
		beDoctorProfile.setUpdateId(userId);
		beDoctorProfile = update(beDoctorProfile);

		return beDoctorProfile;
	}
}
