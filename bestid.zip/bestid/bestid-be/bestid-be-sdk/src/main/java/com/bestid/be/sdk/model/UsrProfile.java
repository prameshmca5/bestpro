/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 12, 2018
 */
@JsonInclude(Include.NON_NULL)
public class UsrProfile implements Serializable {

	private static final long serialVersionUID = 106316930304813799L;

	private Integer userId;

	private Integer secUserId;

	private String refNo;

	private Integer userType;

	private String fullName;

	private Date dob;

	private String pob;

	private String gender;

	private String race;

	private String religion;

	private String citizenship;

	private String addres;

	private String postcode;

	private String city;

	private String state;

	private String country;

	private Date issueDate;

	private String cntryIssue;

	private String photoDocId;

	private String status;

	private String remarks;

	private List<Device> deviceList;

	private List<SubscriberInfo> subscriberList;

	private List<DigitalIdInfo> digitalIdList;

	private String profileId;

	private String subscribeStatus;

	private String digitalStatus;

	private String deviceStatus;

	private Device deviceInfo;


	public Integer getUserId() {
		return userId;
	}


	public void setUserId(Integer userId) {
		this.userId = userId;
	}


	public String getRefNo() {
		return refNo;
	}


	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}


	public Integer getUserType() {
		return userType;
	}


	public void setUserType(Integer userType) {
		this.userType = userType;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public String getPob() {
		return pob;
	}


	public void setPob(String pob) {
		this.pob = pob;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getRace() {
		return race;
	}


	public void setRace(String race) {
		this.race = race;
	}


	public String getReligion() {
		return religion;
	}


	public void setReligion(String religion) {
		this.religion = religion;
	}


	public String getCitizenship() {
		return citizenship;
	}


	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}


	public String getAddres() {
		return addres;
	}


	public void setAddres(String addres) {
		this.addres = addres;
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public Date getIssueDate() {
		return issueDate;
	}


	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}


	public String getCntryIssue() {
		return cntryIssue;
	}


	public void setCntryIssue(String cntryIssue) {
		this.cntryIssue = cntryIssue;
	}


	public String getPhotoDocId() {
		return photoDocId;
	}


	public void setPhotoDocId(String photoDocId) {
		this.photoDocId = photoDocId;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public List<Device> getDeviceList() {
		return deviceList;
	}


	public void setDeviceList(List<Device> deviceList) {
		this.deviceList = deviceList;
	}


	public List<SubscriberInfo> getSubscriberList() {
		return subscriberList;
	}


	public void setSubscriberList(List<SubscriberInfo> subscriberList) {
		this.subscriberList = subscriberList;
	}


	public List<DigitalIdInfo> getDigitalIdList() {
		return digitalIdList;
	}


	public void setDigitalIdList(List<DigitalIdInfo> digitalIdList) {
		this.digitalIdList = digitalIdList;
	}


	public Integer getSecUserId() {
		return secUserId;
	}


	public void setSecUserId(Integer secUserId) {
		this.secUserId = secUserId;
	}


	public String getProfileId() {
		return profileId;
	}


	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}


	public String getSubscribeStatus() {
		return subscribeStatus;
	}


	public void setSubscribeStatus(String subscribeStatus) {
		this.subscribeStatus = subscribeStatus;
	}


	public String getDigitalStatus() {
		return digitalStatus;
	}


	public void setDigitalStatus(String digitalStatus) {
		this.digitalStatus = digitalStatus;
	}


	public String getDeviceStatus() {
		return deviceStatus;
	}


	public void setDeviceStatus(String deviceStatus) {
		this.deviceStatus = deviceStatus;
	}


	public Device getDeviceInfo() {
		return deviceInfo;
	}


	public void setDeviceInfo(Device deviceInfo) {
		this.deviceInfo = deviceInfo;
	}

}