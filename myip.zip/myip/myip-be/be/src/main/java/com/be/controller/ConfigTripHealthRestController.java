package com.be.controller;


import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.model.BeConfigTripHealth;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.ConfigTripHealth;
import com.be.service.BeConfigTripHealthService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;


/**
 * @author nurul.naimma
 *
 * @since Jul 14, 2020
 */

@Lazy
@RestController
@RequestMapping(BeUrlConstants.CONFIG_TRIP_HEALTH)

public class ConfigTripHealthRestController extends AbstractRestController {

	@Autowired
	private BeConfigTripHealthService beConfigTripHealthSvc;


	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.GET_CONFIG_TRIP_HEALTH, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<ConfigTripHealth> getConfigTripHealth(@RequestBody ConfigTripHealth tripHealth,
			HttpServletRequest request) throws IOException {
		if (BaseUtil.isObjNull(tripHealth)) {
			throw new BeException(BeErrorCodeEnum.E400C913);
		}

		BeConfigTripHealth configTripHelath = JsonUtil.transferToObject(tripHealth, BeConfigTripHealth.class);
		return JsonUtil.transferToList(beConfigTripHealthSvc.searchAllByProperty(configTripHelath),
				ConfigTripHealth.class);
	}

}
