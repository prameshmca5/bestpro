package com.bestpay.be.service;


import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.PgwMerchantPidCustomDao;
import com.bestpay.be.dao.PgwMerchantPidRepository;
import com.bestpay.be.model.PgwMerchantPid;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;


@Transactional
@Service(QualifierConstants.PGW_MERCHANT_PID_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_PID_SVC)
public class PgwMerchantPidService extends AbstractService<PgwMerchantPid> {

	@Autowired
	private PgwMerchantPidRepository pgwMerchantPidRepository;

	@Autowired
	private PgwMerchantPidCustomDao pidInfoDao;


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwMerchantPid> searchPaginationByMerchantId(String merchantId,
			DataTableRequest dataTableInRQ) {
		return pidInfoDao.searchPaginationByMerchantId(merchantId, dataTableInRQ);
	}


	@Override
	public GenericRepository<PgwMerchantPid> primaryDao() {
		return pgwMerchantPidRepository;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantPid findByMerchantId(String merchantId) {
		return pgwMerchantPidRepository.findByMerchantId(merchantId);
	}
	
	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantPid findByMerchantIdUsingMTO(String merchantId, String mtotype) {
		return pgwMerchantPidRepository.findByMerchantIdUsingMTO(merchantId, mtotype);
	}

 
}
