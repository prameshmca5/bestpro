/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;


/**
 * @author michelle.angela
 *
 */
public class McAddress implements Serializable, IQfCriteria<McAddress> {

	private static final long serialVersionUID = 1629227653329043770L;

	private Integer mcAddrId;

	private McProfile mcProfile;

	private String mcBranchName;

	private String addr1;

	private String addr2;

	private String addr3;

	private String addr4;

	private City city;

	private State state;

	private Country country;

	private String zipcode;

	private String addrType;

	private String cityDesc;

	private String stateDesc;

	private String orgTypeMtdtCd;

	private String mcTypeMtdtCd;

	private String cntryCd;

	private String mcName;

	private Double latitude;

	private Double longitude;

	private GmtTimeZone timezone;

	private String timeZoneId;


	public Integer getMcAddrId() {
		return mcAddrId;
	}


	public void setMcAddrId(Integer mcAddrId) {
		this.mcAddrId = mcAddrId;
	}


	public McProfile getMcProfile() {
		return mcProfile;
	}


	public String getMcBranchName() {
		return mcBranchName;
	}


	public void setMcBranchName(String mcBranchName) {
		this.mcBranchName = mcBranchName;
	}


	public void setMcProfile(McProfile mcProfile) {
		this.mcProfile = mcProfile;
	}


	public String getAddr1() {
		return addr1;
	}


	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}


	public String getAddr2() {
		return addr2;
	}


	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}


	public String getAddr3() {
		return addr3;
	}


	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}


	public String getAddr4() {
		return addr4;
	}


	public void setAddr4(String addr4) {
		this.addr4 = addr4;
	}


	public City getCity() {
		return city;
	}


	public void setCity(City city) {
		this.city = city;
	}


	public State getState() {
		return state;
	}


	public void setState(State state) {
		this.state = state;
	}


	public Country getCountry() {
		return country;
	}


	public void setCountry(Country country) {
		this.country = country;
	}


	public String getZipcode() {
		return zipcode;
	}


	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}


	public String getAddrType() {
		return addrType;
	}


	public void setAddrType(String addrType) {
		this.addrType = addrType;
	}


	public String getCityDesc() {
		return cityDesc;
	}


	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc;
	}


	public String getStateDesc() {
		return stateDesc;
	}


	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc;
	}


	public String getOrgTypeMtdtCd() {
		return orgTypeMtdtCd;
	}


	public void setOrgTypeMtdtCd(String orgTypeMtdtCd) {
		this.orgTypeMtdtCd = orgTypeMtdtCd;
	}


	public String getMcTypeMtdtCd() {
		return mcTypeMtdtCd;
	}


	public void setMcTypeMtdtCd(String mcTypeMtdtCd) {
		this.mcTypeMtdtCd = mcTypeMtdtCd;
	}


	public String getCntryCd() {
		return cntryCd;
	}


	public void setCntryCd(String cntryCd) {
		this.cntryCd = cntryCd;
	}


	public String getMcName() {
		return mcName;
	}


	public void setMcName(String mcName) {
		this.mcName = mcName;
	}


	public Double getLatitude() {
		return latitude;
	}


	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}


	public Double getLongitude() {
		return longitude;
	}


	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}


	public GmtTimeZone getTimezone() {
		return timezone;
	}


	public void setTimezone(GmtTimeZone timezone) {
		this.timezone = timezone;
	}


	public String getTimeZoneId() {
		return timeZoneId;
	}


	public void setTimeZoneId(String timeZoneId) {
		this.timeZoneId = timeZoneId;
	}

}
