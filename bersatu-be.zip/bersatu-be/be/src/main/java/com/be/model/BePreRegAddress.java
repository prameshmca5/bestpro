/**
 * Copyright 2019
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.be.core.AbstractEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the BE_PRE_REG_ADDRESS database table.
 *
 * @author Naem Othman
 * @since March 31, 2020
 */
@Entity
@Table(name = "BE_PRE_REG_ADDRESS")
public class BePreRegAddress extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = 6016032592885161865L;

	@Id
	@Column(name = "PRE_REG_ADD_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer preRegAddId;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "PRE_REG_ID")
	private BePreReg preReg;

	@Column(name = "ADDRESS_TYPE_MTDT_ID")
	private Integer addressTypeMtdtId;

	@Column(name = "ADDRESS_1")
	private String address1;

	@Column(name = "ADDRESS_2")
	private String address2;

	@Column(name = "ADDRESS_3")
	private String address3;

	@Column(name = "POSTCODE")
	private String postcode;

	@Column(name = "CITY_CD")
	private String cityCd;

	@Column(name = "STATE_CD")
	private String stateCd;

	@Column(name = "COUNTRY_CD")
	private String countryCd;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "STATUS")
	private Boolean status;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getPreRegAddId() {
		return preRegAddId;
	}


	public void setPreRegAddId(Integer preRegAddId) {
		this.preRegAddId = preRegAddId;
	}


	public Integer getAddressTypeMtdtId() {
		return addressTypeMtdtId;
	}


	public void setAddressTypeMtdtId(Integer addressTypeMtdtId) {
		this.addressTypeMtdtId = addressTypeMtdtId;
	}


	public String getAddress1() {
		return address1;
	}


	public void setAddress1(String address1) {
		this.address1 = address1.toUpperCase();
	}


	public String getAddress2() {
		return address2;
	}


	public void setAddress2(String address2) {
		this.address2 = address2.toUpperCase();
	}


	public String getAddress3() {
		return address3;
	}


	public void setAddress3(String address3) {
		this.address3 = address3.toUpperCase();
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getCityCd() {
		return cityCd;
	}


	public void setCityCd(String cityCd) {
		this.cityCd = cityCd;
	}


	public String getStateCd() {
		return stateCd;
	}


	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}


	public String getCountryCd() {
		return countryCd;
	}


	public void setCountryCd(String countryCd) {
		this.countryCd = countryCd;
	}


	public Boolean getStatus() {
		return status;
	}


	public void setStatus(Boolean status) {
		this.status = status;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public BePreReg getPreReg() {
		return preReg;
	}


	public void setPreReg(BePreReg preReg) {
		this.preReg = preReg;
	}

}