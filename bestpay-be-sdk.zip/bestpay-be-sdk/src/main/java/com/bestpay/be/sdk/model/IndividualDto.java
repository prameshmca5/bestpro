package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class IndividualDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String operationIndicator;

	private String isIndividual;

	private String nationalId;

	private String name;

	private String addr1;

	private String addr2;

	private String road;

	private String islandId;

	private String postcode;

	private String mobileNum;

	private String email;

	private String status;

	private String blckLstStatus;

	private String blckLstReason;

	private Timestamp createDt;

	private String createId;

	private Timestamp updateDt;

	private String updateId;

	private String activationKey;

	private String gender;

	private String isOnlineUser;

	private String docRefNo;

	private String position;


	public IndividualDto() {
		// individual dto model
	}


	public String getOperationIndicator() {
		return operationIndicator;
	}


	public void setOperationIndicator(String operationIndicator) {
		this.operationIndicator = operationIndicator;
	}


	public String getIsIndividual() {
		return isIndividual;
	}


	public void setIsIndividual(String isIndividual) {
		this.isIndividual = isIndividual;
	}


	public String getNationalId() {
		return nationalId;
	}


	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddr1() {
		return addr1;
	}


	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}


	public String getAddr2() {
		return addr2;
	}


	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}


	public String getRoad() {
		return road;
	}


	public void setRoad(String road) {
		this.road = road;
	}


	public String getIslandId() {
		return islandId;
	}


	public void setIslandId(String islandId) {
		this.islandId = islandId;
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getMobileNum() {
		return mobileNum;
	}


	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getBlckLstStatus() {
		return blckLstStatus;
	}


	public void setBlckLstStatus(String blckLstStatus) {
		this.blckLstStatus = blckLstStatus;
	}


	public String getBlckLstReason() {
		return blckLstReason;
	}


	public void setBlckLstReason(String blckLstReason) {
		this.blckLstReason = blckLstReason;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public String getActivationKey() {
		return activationKey;
	}


	public void setActivationKey(String activationKey) {
		this.activationKey = activationKey;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getIsOnlineUser() {
		return isOnlineUser;
	}


	public void setIsOnlineUser(String isOnlineUser) {
		this.isOnlineUser = isOnlineUser;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public String getPosition() {
		return position;
	}


	public void setPosition(String position) {
		this.position = position;
	}

}