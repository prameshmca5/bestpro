/**
 *
 */
package com.bestpay.pgw.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;


/**
 * @author Ravindra kumar
 *
 */
@Entity
@Table(name = "PGW_TRXN_DOCUMENTS")
public class PgwTrxnDocument extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = 7416236620129328729L;

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name = "DOC_ID")
	private Integer docId;

	@Column(name = "DOC_REF_NO")
	private String docRefNo;

	@Column(name = "DOC_MGT_ID")
	private String docMgtId;

	@Column(name = "REAPJ_TRXN_DOCUMENTSF_NO")
	private String reapjTrxnDocNo;

	@Column(name = "DOC_CONTENT_TYPE")
	private String docContentType;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DOC_ID", referencedColumnName = "DOC_ID", insertable = false, updatable = false)
	private RefDocument refDocument;


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public Integer getDocId() {
		return docId;
	}


	public void setDocId(Integer docId) {
		this.docId = docId;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public String getDocMgtId() {
		return docMgtId;
	}


	public void setDocMgtId(String docMgtId) {
		this.docMgtId = docMgtId;
	}


	public String getReapjTrxnDocNo() {
		return reapjTrxnDocNo;
	}


	public void setReapjTrxnDocNo(String reapjTrxnDocNo) {
		this.reapjTrxnDocNo = reapjTrxnDocNo;
	}


	public String getDocContentType() {
		return docContentType;
	}


	public void setDocContentType(String docContentType) {
		this.docContentType = docContentType;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public RefDocument getRefDocument() {
		return refDocument;
	}


	public void setRefDocument(RefDocument refDocument) {
		this.refDocument = refDocument;
	}

}
