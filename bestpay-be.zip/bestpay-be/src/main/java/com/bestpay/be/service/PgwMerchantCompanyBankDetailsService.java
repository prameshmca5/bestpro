/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.MerCompBankDetailsCustomDao;
import com.bestpay.be.dao.PgwMerchantCompanyBankDetailsRepository;
import com.bestpay.be.model.PgwMerchantCompanyBankDetails;
import com.bestpay.be.sdk.model.MerCompBankDetails;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;

@Transactional
@Service(QualifierConstants.PGW_MERCHANT_COMPANY_BANK_DETAILS_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_COMPANY_BANK_DETAILS_SVC)
public class PgwMerchantCompanyBankDetailsService extends AbstractService<PgwMerchantCompanyBankDetails> {

	@Autowired
	private PgwMerchantCompanyBankDetailsRepository pgwMerchantCompanyBankDetailsDao;
	
	@Autowired
	private MerCompBankDetailsCustomDao merCompBankDetailsCustomDao;

	@Override
	public PgwMerchantCompanyBankDetailsRepository primaryDao() {
		return pgwMerchantCompanyBankDetailsDao;
	}

	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantCompanyBankDetails findBeneficiaryByCompRefId(String compRefId) {
		return pgwMerchantCompanyBankDetailsDao.findBeneficiaryByCompRefId(compRefId);
	}
	
	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwMerchantCompanyBankDetails> searchMerCompBankDetails(MerCompBankDetails merCompBankDetails,
			DataTableRequest dataTableInRQ) {
		return merCompBankDetailsCustomDao.searchByPagination(merCompBankDetails, dataTableInRQ);
	}

	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantCompanyBankDetails findBeneficiaryByCompBankId(Integer compBankId) {
		return pgwMerchantCompanyBankDetailsDao.findBeneficiaryByCompBankId(compBankId);
	}

}
