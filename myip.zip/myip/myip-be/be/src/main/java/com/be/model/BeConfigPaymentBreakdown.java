/**
 * 
 */
package com.be.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;

/**
 * @author michelle.angela
 *
 */
 @Entity
 @Table(name = "BE_CONFIG_PAYMENT_BREAKDOWN")
public class BeConfigPaymentBreakdown extends AbstractEntity implements Serializable, IQfCriteria<BeConfigPaymentBreakdown> {

	private static final long serialVersionUID = -6144591053850044136L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="PMT_BREAKDOWN_ID")
	private Integer pmtBreakdownId;
	 
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="PMT_STAGE_ID")
	private BeConfigPaymentStage configPaymentStage;
	 
	@Column(name="LEVEL")
	private Integer level;
	
	@Column(name = "CHARGES")
	private double charges;
	
	@Column(name = "REFUND")
	private double refund;
	 
	@Column(name = "CURRENCY")
	private String currency;
	
	@Column(name = "DESCRIPTION")
	private String description;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "STATUS")
	private Boolean isActive;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNTRY_CD")
	private RefCountry country;
	
	@Column(name = "BATCH_ID")
	private Integer batchId;
	
	@Column(name = "STAKE_HOLDER")
	private String stakeholder;
	
	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	public Integer getPmtBreakdownId() {
		return pmtBreakdownId;
	}

	public void setPmtBreakdownId(Integer pmtBreakdownId) {
		this.pmtBreakdownId = pmtBreakdownId;
	}

	public BeConfigPaymentStage getConfigPaymentStage() {
		return configPaymentStage;
	}

	public void setConfigPaymentStage(BeConfigPaymentStage configPaymentStage) {
		this.configPaymentStage = configPaymentStage;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public double getCharges() {
		return charges;
	}

	public void setCharges(double charges) {
		this.charges = charges;
	}

	public double getRefund() {
		return refund;
	}

	public void setRefund(double refund) {
		this.refund = refund;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public RefCountry getCountry() {
		return country;
	}

	public void setCountry(RefCountry country) {
		this.country = country;
	}

	public Integer getBatchId() {
		return batchId;
	}

	public void setBatchId(Integer batchId) {
		this.batchId = batchId;
	}

	public String getStakeholder() {
		return stakeholder;
	}

	public void setStakeholder(String stakeholder) {
		this.stakeholder = stakeholder;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}	 
	
}
