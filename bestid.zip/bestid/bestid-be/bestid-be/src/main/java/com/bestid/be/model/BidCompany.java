/**
 *
 */
package com.bestid.be.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author suhada
 * @since Feb 22, 2019
 */
@Entity
@Table(name = "BID_COMPANY")
public class BidCompany implements java.io.Serializable {

	private static final long serialVersionUID = 7803285550647135313L;

	@Id
	@Column(name = "CMPNY_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cmpnyId;

	@Column(name = "CMPNY_NAME")
	private String cmpnyName;

	@Column(name = "CMPNY_REG_NO")
	private String cmpnyRegNo;

	@Column(name = "CMPNY_OWNER")
	private String cmpnyOwner;

	@Column(name = "CONTACT_NO")
	private String contactNo;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	public int getCmpnyId() {
		return cmpnyId;
	}

	public void setCmpnyId(int cmpnyId) {
		this.cmpnyId = cmpnyId;
	}

	public String getCmpnyName() {
		return cmpnyName;
	}

	public void setCmpnyName(String cmpnyName) {
		this.cmpnyName = cmpnyName;
	}

	public String getCmpnyRegNo() {
		return cmpnyRegNo;
	}

	public void setCmpnyRegNo(String cmpnyRegNo) {
		this.cmpnyRegNo = cmpnyRegNo;
	}

	public String getCmpnyOwner() {
		return cmpnyOwner;
	}

	public void setCmpnyOwner(String cmpnyOwner) {
		this.cmpnyOwner = cmpnyOwner;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}
