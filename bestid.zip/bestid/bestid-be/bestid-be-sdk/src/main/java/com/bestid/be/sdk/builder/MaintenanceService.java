/**
 * Copyright 2019. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.builder;


import java.util.HashMap;
import java.util.Map;

import com.bestid.be.sdk.client.BeRestTemplate;
import com.bestid.be.sdk.constants.BeUrlConstants;
import com.bestid.be.sdk.exception.BeException;
import com.bestid.be.sdk.model.RefBidConfig;
import com.bstsb.util.pagination.DataTableResults;


/**
 * @author rahmat.balli
 * @since Mar 11, 2019
 */
public class MaintenanceService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;

	}


	public MaintenanceService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	public RefBidConfig getConfigById(Integer configId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MAINTENANCE_BIDCONFIG_FIND_BY_ID);
		sb.append("?id={id}");
		Map<String, Object> params = new HashMap<>();
		params.put("id", configId);
		return restTemplate().getForObject(getServiceURI(sb.toString()), RefBidConfig.class, params);
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<RefBidConfig> listBidConfigPaginated(RefBidConfig config, Map<String, Object> pagination)
			throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MAINTENANCE_BIDCONFIG_PAGINATED);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), config, DataTableResults.class);
	}


	public RefBidConfig createBidConfig(RefBidConfig config) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MAINTENANCE_BIDCONFIG_CREATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), config, RefBidConfig.class);
	}


	public RefBidConfig updateBidConfig(RefBidConfig config) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MAINTENANCE_BIDCONFIG_UPDATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), config, RefBidConfig.class);
	}


	public Boolean deleteBidConfig(RefBidConfig config) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MAINTENANCE_BIDCONFIG_DELETED);
		sb.append("?id=" + config.getConfigId());

		return restTemplate().deleteForObject(getServiceURI(sb.toString()));

	}

}
