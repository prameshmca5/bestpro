/**
 *
 */
package com.be.service;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTvlTripHealthRepository;
import com.be.model.BeConfigRiskStatus;
import com.be.model.BeTvl;
import com.be.model.BeTvlTrip;
import com.be.model.BeTvlTripHealth;
import com.be.model.RefMetadata;
import com.be.model.RefStatus;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.TripHealth;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlProfile;
import com.util.BaseUtil;
import com.util.JsonUtil;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_TRIP_HEALTH_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_TRIP_HEALTH_SVC)
public class BeTvlTripHealthService extends AbstractService<BeTvlTripHealth> {

	@Autowired
	BeTvlTripHealthRepository beTripHealthDao;

	@Autowired
	BeConfigRiskStatusService beConfigRiskStatusSvc;

	@Autowired
	BeTvlService beTvlSvc;

	@Autowired
	RefMetadataService refMetadataSvc;


	@Override
	public GenericRepository<BeTvlTripHealth> primaryDao() {
		return beTripHealthDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}


	@SuppressWarnings("unchecked")
	public List<BeTvlTripHealth> createUpdate(List<TripHealth> dtoList, BeTvlTrip beTvlTrip, String userId)
			throws IOException {

		List<BeTvlTripHealth> dtoTripHealths = JsonUtil.transferToList(dtoList, BeTvlTripHealth.class);
		List<BeTvlTripHealth> beTvlTripHealths = new ArrayList<>();
		for (BeTvlTripHealth tripHealth : dtoTripHealths) {
			BeTvlTripHealth beTvlTripHealth = beTripHealthDao.findBeTvlTripHealth(beTvlTrip,
					tripHealth.getConfigTripHealth());
			if (BaseUtil.isObjNull(beTvlTripHealth)) {
				beTvlTripHealth = tripHealth;
				beTvlTripHealth.setTvlTrip(beTvlTrip);
				beTvlTripHealth.setCreateId(userId);
			} else {
				beTvlTripHealth.setResultMtdt(tripHealth.getResultMtdt());
			}
			beTvlTripHealth.setUpdateId(userId);
			beTvlTripHealths.add(beTvlTripHealth);
		}
		return beTripHealthDao.save(beTvlTripHealths);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { BeException.class,
			Exception.class })
	public List<BeTvlTripHealth> addTripHealth(List<TripHealth> dtoList, BeTvlTrip beTvlTrip, Integer statusId,
			String userId) throws IOException {
		List<BeTvlTripHealth> beTvlTripHealths = createUpdate(dtoList, beTvlTrip, userId);
		Tvl tvl = new Tvl();
		tvl.setTvlProfile(new TvlProfile());
		tvl.getTvlProfile().setTvlProfId(beTvlTrip.getTvlProfile().getTvlProfId());
		BeTvl beTvl = beTvlSvc.searchBeTravel(tvl);
		beTvl.setRiskStatus(getRiskStatus(beTvlTripHealths));
		if (!BaseUtil.isObjNull(statusId) && statusId != 0) {
			beTvl.setStatus(new RefStatus());
			beTvl.getStatus().setStatusId(statusId);
		}
		beTvl.setUpdateId(userId);
		beTvlSvc.update(beTvl);
		return beTvlTripHealths;
	}


	public BeConfigRiskStatus getRiskStatus(List<BeTvlTripHealth> dtoList) {

		BeConfigRiskStatus beConfigRiskStatus = null;
		List<BeConfigRiskStatus> riskStatuses = beConfigRiskStatusSvc.findAll();
		Comparator<BeTvlTripHealth> byConfig = (e1, e2) -> e2.getConfigTripHealth().getTripHealthId()
				.compareTo(e1.getConfigTripHealth().getTripHealthId());
		List<BeTvlTripHealth> sortedList = dtoList.stream().sorted(byConfig.reversed()).collect(Collectors.toList());
		StringBuilder sb = new StringBuilder();

		for (BeTvlTripHealth th : sortedList) {
			RefMetadata metadata = refMetadataSvc.find(th.getResultMtdt().getMtdtId());
			sb.append(metadata.getMtdtCd());
		}

		for (BeConfigRiskStatus riskStatus : riskStatuses) {
			if (BaseUtil.isEquals(riskStatus.getCondition(), sb.toString())) {
				beConfigRiskStatus = riskStatus;
				break;
			}
		}

		return beConfigRiskStatus;
	}
}
