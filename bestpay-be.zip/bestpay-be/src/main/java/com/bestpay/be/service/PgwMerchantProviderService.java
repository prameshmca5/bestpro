/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwMerchantProviderCustomDao;
import com.bestpay.be.dao.PgwMerchantProviderRepository;
import com.bestpay.be.model.PgwMerchantProvider;
import com.bestpay.be.sdk.model.Provider;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since March 28, 2019
 */
@Transactional
@Service(QualifierConstants.PGW_MER_PROVIDER_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MER_PROVIDER_SVC)
public class PgwMerchantProviderService extends AbstractService<PgwMerchantProvider> {

	@Autowired
	private PgwMerchantProviderRepository providerDao;

	@Autowired
	private PgwMerchantProviderCustomDao providerInfoDao;


	@Override
	public PgwMerchantProviderRepository primaryDao() {
		return providerDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwMerchantProvider> searchByPagination(Provider provider,
			DataTableRequest dataTableInRQ) {
		return providerInfoDao.searchByPagination(provider, dataTableInRQ);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantProvider findByProviderId(Integer providerId) {
		return providerDao.findByProviderId(providerId);
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public PgwMerchantProvider findProviderByChannel(String channel) {
		return providerDao.findProviderByChannel(channel);
	}


	public List<PgwMerchantProvider> findByProviderSsmId(String ssmid) {
		return providerDao.findByProviderSsmId(ssmid);
	}


	public List<PgwMerchantProvider> findByProviderPublicName(String providerPublicName) {
		return providerDao.findByProviderPublicName(providerPublicName);
	}

}