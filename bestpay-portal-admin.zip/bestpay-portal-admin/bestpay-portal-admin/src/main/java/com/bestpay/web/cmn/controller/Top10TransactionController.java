/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.sdk.model.Transaction;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.notify.sdk.util.BaseUtil;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.WebUtil;
import com.google.gson.Gson;

/**
 * @author N.N.Shuhada
 * @since June 10, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_TOP10_TRANSACTION)
public class Top10TransactionController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(Top10TransactionController.class);

	// for view transaction list
	@GetMapping
	public ModelAndView view(@ModelAttribute("transactionList") Transaction transactionList, BindingResult result)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TOP10_TRANSACTION, "top10trans", null,
				"top10-transaction-script");
		List<Status> status = staticData.status("TRANSTAT");
		List<Status> channel = staticData.status("CHANNEL");
		mav.addObject("statusList", status);
		mav.addObject("channelList", channel);
		return mav;

	}

	@PostMapping(params = "search")
	public ModelAndView search(@ModelAttribute("transactionList") Transaction transactionList, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TRANSACTION, "translist", null, "transaction-list-script");
		mav.addObject("transactionList", transactionList);
		List<Status> status = staticData.status("TRANSTAT");
		List<Status> channel = staticData.status("CHANNEL");
		mav.addObject("statusList", status);
		mav.addObject("channelList", channel);
		return mav;
	}

	@GetMapping(value = "/paginated")
	public @ResponseBody String getTop10List(@ModelAttribute("transactionList") Transaction transactionList,
			@RequestParam(value = "top10", required = false) String top10, HttpServletRequest request) {
		LOGGER.info("GET PAGINATED BILLING LIST....");
		DataTableResults<Transaction> tasks = new DataTableResults<>();
		if (BaseUtil.isEqualsCaseIgnore(top10, "amt")) {
			transactionList.setTop10("amt");
		}

		try {
			Transaction transaction = dozerMapper.map(transactionList, Transaction.class);
			tasks = getBeService().searchTop10List(transaction, getPaginationRequest(request, true));
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(e.getMessage());
			tasks.setError(e.getMessage());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			tasks.setError(e.getMessage());
		}

		return new Gson().toJson(tasks);
	}

}