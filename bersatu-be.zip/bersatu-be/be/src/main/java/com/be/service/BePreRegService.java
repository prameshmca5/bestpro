/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.be.service;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BePaymentRepository;
import com.be.dao.BePreRegQf;
import com.be.dao.BePreRegRepository;
import com.be.model.BePayment;
import com.be.model.BePaymentDtl;
import com.be.model.BePreReg;
import com.be.model.BeTrxnDocument;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.PaymentDtl;
import com.be.sdk.model.PreReg;
import com.be.sdk.model.PreRegAddress;
import com.be.sdk.model.TrxnDocuments;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;


/**
 * @author mohd.naem
 * @since March 31 , 2021
 */
@Service(QualifierConstants.BE_PRE_REG_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_PRE_REG_SVC)
@Transactional
public class BePreRegService extends AbstractService<BePreReg> {

	protected static Logger logger = LoggerFactory.getLogger(BePreRegService.class);

	@Autowired
	private BePreRegRepository bePreRegDao;

	@Autowired
	private BePreRegQf bePreRegQf;

	@Autowired
	private BeTrxnDocumentsService beTrxnDocumentsSvc;

	@Autowired
	private BePaymentRepository bePaymentDao;


	@Override
	public GenericRepository<BePreReg> primaryDao() {
		return bePreRegDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return null;
	}


	public long getCount(PreReg dto) {
		return bePreRegQf.getCount(dto);
	}


	@SuppressWarnings("unchecked")
	public List<PreReg> searchPagination(PreReg dto, DataTableRequest<?> dataTableInRQ) throws IOException {
		return JsonUtil.transferToList(bePreRegQf.searchAllByProperty(dto, dataTableInRQ), PreReg.class);
	}


	@SuppressWarnings("unchecked")
	public List<PreReg> searchList(PreReg dto) {
		List<BePreReg> bePreRegList = bePreRegQf.searchAllByProperty(dto, null);
		List<PreReg> preRegList = null;
		if (!BaseUtil.isListNull(bePreRegList)) {
			preRegList = bePreRegList.stream().map(bePreReg -> {
				PreReg preReg = null;
				try {
					preReg = JsonUtil.transferToObject(bePreReg, PreReg.class);
					preReg.setPreRegAddressList(
							JsonUtil.transferToList(bePreReg.getPreRegAddressList(), PreRegAddress.class));
				} catch (IOException e) {
					e.printStackTrace();
				}
				return preReg;
			}).collect(Collectors.toList());
		}
		return preRegList;
	}


	public List<BePreReg> searchBePreReg(PreReg dto) {
		return bePreRegQf.searchAllByProperty(dto, null);
	}


	@SuppressWarnings("unchecked")
	public PreReg search(PreReg dto) throws IOException {
		List<BePreReg> bePreRegList = bePreRegQf.searchAllByProperty(dto, null);
		PreReg preReg = null;
		if (!BaseUtil.isListNull(bePreRegList)) {
			BePreReg bePreReg = bePreRegList.stream()
					.sorted(Comparator.comparingInt(BePreReg::getPreRegId).reversed()).findFirst().orElse(null);
			if (!BaseUtil.isObjNull(bePreReg)) {
				preReg = JsonUtil.transferToObject(bePreReg, PreReg.class);
				preReg.setPreRegAddressList(
						JsonUtil.transferToList(bePreReg.getPreRegAddressList(), PreRegAddress.class));
				if (!BaseUtil.isListNull(bePreReg.getTrxnDocumentsList())) {
					preReg.setTrxnDocumentList(bePreReg.getTrxnDocumentsList().stream().map(doc -> {
						TrxnDocuments docTrxn = new TrxnDocuments();
						docTrxn.setDocRefNo(doc.getId().getDocRefNo());
						docTrxn.setDocId(doc.getId().getDocId());
						docTrxn.setDocMgtId(doc.getId().getDocMgtId());
						docTrxn.setAppRefNo(doc.getAppRefNo());
						docTrxn.setAppType(doc.getAppType());
						docTrxn.setDocContentType(doc.getDocContentType());
						return docTrxn;
					}).collect(Collectors.toList()));
				}
			}
		}
		return preReg;
	}


	@SuppressWarnings("unchecked")
	public List<PreReg> searchPreRegList(PreReg dto) throws IOException {
		List<BePreReg> bePreRegList = bePreRegQf.searchAllByProperty(dto, null);
		List<PreReg> preRegs = new ArrayList<>();

		if (!BaseUtil.isListNull(bePreRegList)) {
			for (BePreReg bePreReg : bePreRegList) {
				PreReg preReg = JsonUtil.transferToObject(bePreReg, PreReg.class);
				preReg.setPreRegAddressList(
						JsonUtil.transferToList(bePreReg.getPreRegAddressList(), PreRegAddress.class));
				if (!BaseUtil.isListNull(bePreReg.getTrxnDocumentsList())) {
					preReg.setTrxnDocumentList(bePreReg.getTrxnDocumentsList().stream().map(doc -> {
						TrxnDocuments docTrxn = new TrxnDocuments();
						docTrxn.setDocRefNo(doc.getId().getDocRefNo());
						docTrxn.setDocId(doc.getId().getDocId());
						docTrxn.setDocMgtId(doc.getId().getDocMgtId());
						docTrxn.setAppRefNo(doc.getAppRefNo());
						docTrxn.setAppType(doc.getAppType());
						docTrxn.setDocContentType(doc.getDocContentType());
						return docTrxn;
					}).collect(Collectors.toList()));
				}
				preRegs.add(preReg);
			}

		}

		return preRegs;
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public BePreReg create(BePreReg bePreReg, Collection<BeTrxnDocument> beTrxnDocumentList) {
		if (beTrxnDocumentList != null && !beTrxnDocumentList.isEmpty()) {
			beTrxnDocumentsSvc.updateAll(beTrxnDocumentList);
		}
		return bePreRegDao.save(bePreReg);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public BePreReg updatepreReg(PreReg dto) {
		PreReg searchdto = new PreReg();
		searchdto.setPreRegId(dto.getPreRegId());
		searchdto.setTxnId(dto.getTxnId());
		List<BePreReg> bePreRegList = bePreRegQf.searchAllByProperty(searchdto, null);
		if (!BaseUtil.isListNull(bePreRegList)) {
			BePreReg preReg = bePreRegList.get(0);
			preReg.setStatusId(dto.getStatusId());

			// if (!BaseUtil.isObjNull(dto.getHqInd())) {
			// Timestamp currDt = DateUtil.getSQLTimestamp();
			// preReg.setHqInd(dto.getHqInd());
			// preReg.setUpdateDt(currDt);
			// preReg.setUpdateId(dto.getUserId());
			// }
			return update(preReg);
		}
		return null;
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public BePreReg createPublic(BePreReg bePreReg, Collection<BeTrxnDocument> beTrxnDocumentList,
			BePayment crtPayment, List<PaymentDtl> paymentDtlList) {
		if (beTrxnDocumentList != null && !beTrxnDocumentList.isEmpty()) {
			beTrxnDocumentsSvc.updateAll(beTrxnDocumentList);
		}

		bePreReg = bePreRegDao.save(bePreReg);
		if (!BaseUtil.isListNull(paymentDtlList)) {
			int count = 0;
			List<BePaymentDtl> bePaymentDtlList = new ArrayList<>();
			for (PaymentDtl payment : paymentDtlList) {
				BePaymentDtl pmtDtl = dozerMapper.map(payment, BePaymentDtl.class);
				pmtDtl.setPmtDtlRefNo(crtPayment.getPmtRefNo() + "-" + (count + 1));
				pmtDtl.setItemId(BaseUtil.getStr(bePreReg.getPreRegId()));
				pmtDtl.setCreateId(crtPayment.getCreateId());
				pmtDtl.setCreateDt(crtPayment.getCreateDt());
				pmtDtl.setUpdateId(crtPayment.getCreateId());
				pmtDtl.setUpdateDt(crtPayment.getCreateDt());
				bePaymentDtlList.add(pmtDtl);
			}
			crtPayment.addBePaymentDtlList(bePaymentDtlList);
			BePayment payment = bePaymentDao.save(crtPayment);
			bePreReg.setPayment(payment);
		}
		return bePreReg;

	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public BePreReg updatepreRegRej(PreReg dto) {
		PreReg searchdto = new PreReg();
		searchdto.setPreRegId(dto.getPreRegId());
		searchdto.setTxnId(dto.getTxnId());
		List<BePreReg> bePreRegList = bePreRegQf.searchAllByProperty(searchdto, null);
		if (!BaseUtil.isListNull(bePreRegList)) {
			BePreReg preReg = bePreRegList.get(0);
			preReg.setStatusId(dto.getStatusId());
			preReg.setApproveRemarks(dto.getApproveRemarks());
			preReg.setPositionId(dto.getPositionId());
			if (!BaseUtil.isObjNull(dto.getStatusId()) && dto.getStatusId() == 12
					&& !BaseUtil.isObjNull(dto.getHqInd())) {
				preReg.setHqInd(dto.getHqInd());
			}
			return update(preReg);
		}
		return null;
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public List<BePreReg> updatePreRegList(List<BePreReg> dtoList) {

		List<BePreReg> bePreRegList = new ArrayList<>();
		for (BePreReg dto : dtoList) {
			bePreRegList.add(update(dto));
		}

		return bePreRegList;
	}

}