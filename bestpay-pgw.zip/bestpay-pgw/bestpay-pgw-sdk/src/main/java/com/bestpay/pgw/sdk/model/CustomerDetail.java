
package com.bestpay.pgw.sdk.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "beneficiaries",
    "comment",
    "companyName",
    "companyType",
    "complianceDoneBy",
    "complicateDoneAt",
    "contactPerson",
    "convertedAt",
    "convertedBy",
    "created",
    "createdBy",
    "customerType",
    "dob",
    "earthPortUserId",
    "email",
    "fullName",
    "gender",
    "guest",
    "idExpiry",
    "idNo",
    "idType",
    "images",
    "location",
    "loginAttempt",
    "maxMoneyId",
    "mobile",
    "name",
    "natureOfBusiness",
    "preferences",
    "riskCategory",
    "riskProfile",
    "riskScore",
    "riskScoreCard",
    "role",
    "securityField",
    "status",
    "title",
    "type",
    "unlockRequestDate",
    "updated",
    "updatedBy",
    "username",
    "validatedAt",
    "validatedBy",
    "wallets"
})
public class CustomerDetail {

    @JsonProperty("beneficiaries")
    private List<String> beneficiaries = null;
    @JsonProperty("comment")
    private String comment;
    @JsonProperty("customerName")
    private String customerName;
    @JsonProperty("companyName")
    private String companyName;
    @JsonProperty("companyType")
    private String companyType;
    @JsonProperty("complianceDoneBy")
    private String complianceDoneBy;
    @JsonProperty("complicateDoneAt")
    private String complicateDoneAt;
    @JsonProperty("contactPerson")
    private String contactPerson;
    @JsonProperty("convertedAt")
    private String convertedAt;
    @JsonProperty("convertedBy")
    private String convertedBy;
    @JsonProperty("created")
    private String created;
    @JsonProperty("createdBy")
    private String createdBy;
    @JsonProperty("customerType")
    private String customerType;
    @JsonProperty("dob")
    private String dob;
    @JsonProperty("earthPortUserId")
    private String earthPortUserId;
    @JsonProperty("email")
    private String email;
    @JsonProperty("fullName")
    private String fullName;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("guest")
    private String guest;
    @JsonProperty("idExpiry")
    private String idExpiry;
    @JsonProperty("idNo")
    private String idNo;
    @JsonProperty("idType")
    private String idType;
    @JsonProperty("images")
    private Images images;
    @JsonProperty("location")
    private String location;
    @JsonProperty("loginAttempt")
    private String loginAttempt;
    @JsonProperty("maxMoneyId")
    private String maxMoneyId;
    @JsonProperty("mobile")
    private String mobile;
    @JsonProperty("name")
    private String name;
    @JsonProperty("natureOfBusiness")
    private String natureOfBusiness;
    @JsonProperty("preferences")
    private String preferences;
    @JsonProperty("riskCategory")
    private String riskCategory;
    @JsonProperty("riskProfile")
    private RiskProfile riskProfile;
    @JsonProperty("riskScore")
    private String riskScore;
    @JsonProperty("riskScoreCard")
    private RiskScoreCard riskScoreCard;
    @JsonProperty("role")
    private String role;
    @JsonProperty("securityField")
    private String securityField;
    @JsonProperty("status")
    private String status;
    @JsonProperty("title")
    private String title;
    @JsonProperty("type")
    private String type;
    @JsonProperty("unlockRequestDate")
    private String unlockRequestDate;
    @JsonProperty("updated")
    private String updated;
    @JsonProperty("updatedBy")
    private String updatedBy;
    @JsonProperty("username")
    private String username;
    @JsonProperty("validatedAt")
    private String validatedAt;
    @JsonProperty("validatedBy")
    private String validatedBy;
    @JsonProperty("wallets")
    private String wallets;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();
    
    private String responseCode;
    private String descriptions;

    @JsonProperty("beneficiaries")
    public List<String> getBeneficiaries() {
        return beneficiaries;
    }

    @JsonProperty("beneficiaries")
    public void setBeneficiaries(List<String> beneficiaries) {
        this.beneficiaries = beneficiaries;
    }

    @JsonProperty("comment")
    public String getComment() {
        return comment;
    }

    @JsonProperty("comment")
    public void setComment(String comment) {
        this.comment = comment;
    }

    @JsonProperty("companyName")
    public String getCompanyName() {
        return companyName;
    }

    @JsonProperty("companyName")
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    @JsonProperty("companyType")
    public String getCompanyType() {
        return companyType;
    }

    @JsonProperty("companyType")
    public void setCompanyType(String companyType) {
        this.companyType = companyType;
    }

    @JsonProperty("complianceDoneBy")
    public Object getComplianceDoneBy() {
        return complianceDoneBy;
    }

    @JsonProperty("complianceDoneBy")
    public void setComplianceDoneBy(String complianceDoneBy) {
        this.complianceDoneBy = complianceDoneBy;
    }

    @JsonProperty("complicateDoneAt")
    public String getComplicateDoneAt() {
        return complicateDoneAt;
    }

    @JsonProperty("complicateDoneAt")
    public void setComplicateDoneAt(String complicateDoneAt) {
        this.complicateDoneAt = complicateDoneAt;
    }

    @JsonProperty("contactPerson")
    public String getContactPerson() {
        return contactPerson;
    }

    @JsonProperty("contactPerson")
    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    @JsonProperty("convertedAt")
    public String getConvertedAt() {
        return convertedAt;
    }

    @JsonProperty("convertedAt")
    public void setConvertedAt(String convertedAt) {
        this.convertedAt = convertedAt;
    }

    @JsonProperty("convertedBy")
    public String getConvertedBy() {
        return convertedBy;
    }

    @JsonProperty("convertedBy")
    public void setConvertedBy(String convertedBy) {
        this.convertedBy = convertedBy;
    }

    @JsonProperty("created")
    public String getCreated() {
        return created;
    }

    @JsonProperty("created")
    public void setCreated(String created) {
        this.created = created;
    }

    @JsonProperty("createdBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("createdBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("customerType")
    public String getCustomerType() {
        return customerType;
    }

    @JsonProperty("customerType")
    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    @JsonProperty("dob")
    public String getDob() {
        return dob;
    }

    @JsonProperty("dob")
    public void setDob(String dob) {
        this.dob = dob;
    }

    @JsonProperty("earthPortUserId")
    public String getEarthPortUserId() {
        return earthPortUserId;
    }

    @JsonProperty("earthPortUserId")
    public void setEarthPortUserId(String earthPortUserId) {
        this.earthPortUserId = earthPortUserId;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("fullName")
    public String getFullName() {
        return fullName;
    }

    @JsonProperty("fullName")
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    @JsonProperty("guest")
    public String getGuest() {
        return guest;
    }

    @JsonProperty("guest")
    public void setGuest(String guest) {
        this.guest = guest;
    }

    @JsonProperty("idExpiry")
    public String getIdExpiry() {
        return idExpiry;
    }

    @JsonProperty("idExpiry")
    public void setIdExpiry(String idExpiry) {
        this.idExpiry = idExpiry;
    }

    @JsonProperty("idNo")
    public String getIdNo() {
        return idNo;
    }

    @JsonProperty("idNo")
    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    @JsonProperty("idType")
    public String getIdType() {
        return idType;
    }

    @JsonProperty("idType")
    public void setIdType(String idType) {
        this.idType = idType;
    }

    @JsonProperty("images")
    public Images getImages() {
        return images;
    }

    @JsonProperty("images")
    public void setImages(Images images) {
        this.images = images;
    }

    @JsonProperty("location")
    public String getLocation() {
        return location;
    }

    @JsonProperty("location")
    public void setLocation(String location) {
        this.location = location;
    }

    @JsonProperty("loginAttempt")
    public String getLoginAttempt() {
        return loginAttempt;
    }

    @JsonProperty("loginAttempt")
    public void setLoginAttempt(String loginAttempt) {
        this.loginAttempt = loginAttempt;
    }

    @JsonProperty("maxMoneyId")
    public String getMaxMoneyId() {
        return maxMoneyId;
    }

    @JsonProperty("maxMoneyId")
    public void setMaxMoneyId(String maxMoneyId) {
        this.maxMoneyId = maxMoneyId;
    }

    @JsonProperty("mobile")
    public String getMobile() {
        return mobile;
    }

    @JsonProperty("mobile")
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("natureOfBusiness")
    public String getNatureOfBusiness() {
        return natureOfBusiness;
    }

    @JsonProperty("natureOfBusiness")
    public void setNatureOfBusiness(String natureOfBusiness) {
        this.natureOfBusiness = natureOfBusiness;
    }

    @JsonProperty("preferences")
    public String getPreferences() {
        return preferences;
    }

    @JsonProperty("preferences")
    public void setPreferences(String preferences) {
        this.preferences = preferences;
    }

    @JsonProperty("riskCategory")
    public String getRiskCategory() {
        return riskCategory;
    }

    @JsonProperty("riskCategory")
    public void setRiskCategory(String riskCategory) {
        this.riskCategory = riskCategory;
    }

    @JsonProperty("riskProfile")
    public RiskProfile getRiskProfile() {
        return riskProfile;
    }

    @JsonProperty("riskProfile")
    public void setRiskProfile(RiskProfile riskProfile) {
        this.riskProfile = riskProfile;
    }

    @JsonProperty("riskScore")
    public String getRiskScore() {
        return riskScore;
    }

    @JsonProperty("riskScore")
    public void setRiskScore(String riskScore) {
        this.riskScore = riskScore;
    }

    @JsonProperty("riskScoreCard")
    public RiskScoreCard getRiskScoreCard() {
        return riskScoreCard;
    }

    @JsonProperty("riskScoreCard")
    public void setRiskScoreCard(RiskScoreCard riskScoreCard) {
        this.riskScoreCard = riskScoreCard;
    }

    @JsonProperty("role")
    public String getRole() {
        return role;
    }

    @JsonProperty("role")
    public void setRole(String role) {
        this.role = role;
    }

    @JsonProperty("securityField")
    public String getSecurityField() {
        return securityField;
    }

    @JsonProperty("securityField")
    public void setSecurityField(String securityField) {
        this.securityField = securityField;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(String title) {
        this.title = title;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("unlockRequestDate")
    public String getUnlockRequestDate() {
        return unlockRequestDate;
    }

    @JsonProperty("unlockRequestDate")
    public void setUnlockRequestDate(String unlockRequestDate) {
        this.unlockRequestDate = unlockRequestDate;
    }

    @JsonProperty("updated")
    public String getUpdated() {
        return updated;
    }

    @JsonProperty("updated")
    public void setUpdated(String updated) {
        this.updated = updated;
    }

    @JsonProperty("updatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("updatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("username")
    public String getUsername() {
        return username;
    }

    @JsonProperty("username")
    public void setUsername(String username) {
        this.username = username;
    }

    @JsonProperty("validatedAt")
    public String getValidatedAt() {
        return validatedAt;
    }

    @JsonProperty("validatedAt")
    public void setValidatedAt(String validatedAt) {
        this.validatedAt = validatedAt;
    }

    @JsonProperty("validatedBy")
    public String getValidatedBy() {
        return validatedBy;
    }

    @JsonProperty("validatedBy")
    public void setValidatedBy(String validatedBy) {
        this.validatedBy = validatedBy;
    }

    @JsonProperty("wallets")
    public String getWallets() {
        return wallets;
    }

    @JsonProperty("wallets")
    public void setWallets(String wallets) {
        this.wallets = wallets;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getDescriptions() {
		return descriptions;
	}

	public void setDescriptions(String descriptions) {
		this.descriptions = descriptions;
	}

}
