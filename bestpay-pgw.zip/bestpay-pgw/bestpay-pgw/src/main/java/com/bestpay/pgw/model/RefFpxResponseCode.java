/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;

/**
 * @author Sridhar Kapidi
 * @since 29/11/2017
 */
@Entity
@Table(name="REF_FPX_RESPONSE_CODE")
public class RefFpxResponseCode extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -3186445980890420147L;

	@Id
	@Column(name="FPX_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "FPX_CODE")
	private String fpxCode;
	
	@Column(name = "FPX_DESCRIPTION")
	private String fpxDescription;
	
	@Column(name = "BESTPAY_CODE")
	private String bestpayCode;
	
	@Column(name = "CHANNEL")
	private String channel;
	
	@Column(name = "CREATE_ID")
	private String createId;
	
	@Column(name = "CREATE_DT")
	private Timestamp createDt;
	
	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;
	
	@Column(name = "UPDATE_ID")
	private String updateId;
	
	
	/*
	 * 00- success
	 * 01- pending
	 * 02- fail
	 */
	@Column(name = "RESP_CODE")
	private String respCode;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	
	/**
	 * @return the fpxCode
	 */
	public String getFpxCode() {
		return fpxCode;
	}

	/**
	 * @param fpxCode the fpxCode to set
	 */
	public void setFpxCode(String fpxCode) {
		this.fpxCode = fpxCode;
	}

	/**
	 * @return the fpxDescription
	 */
	public String getFpxDescription() {
		return fpxDescription;
	}

	/**
	 * @param fpxDescription the fpxDescription to set
	 */
	public void setFpxDescription(String fpxDescription) {
		this.fpxDescription = fpxDescription;
	}

	
	 
	public String getBestpayCode() {
		return bestpayCode;
	}

	public void setBestpayCode(String bestpayCode) {
		this.bestpayCode = bestpayCode;
	}

	/**
	 * @return the createId
	 */
	public String getCreateId() {
		return createId;
	}

	/**
	 * @param createId the createId to set
	 */
	public void setCreateId(String createId) {
		this.createId = createId;
	}

	/**
	 * @return the createDt
	 */
	public Timestamp getCreateDt() {
		return createDt;
	}

	/**
	 * @param createDt the createDt to set
	 */
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	/**
	 * @return the updateDt
	 */
	public Timestamp getUpdateDt() {
		return updateDt;
	}

	/**
	 * @param updateDt the updateDt to set
	 */
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	/**
	 * @return the updateId
	 */
	public String getUpdateId() {
		return updateId;
	}

	/**
	 * @param updateId the updateId to set
	 */
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}
	

}
