/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Ravindra kumar
 * @since 21/03/2018
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class RefEmbedResponse implements Serializable {

	private static final long serialVersionUID = -6255425222614429634L;

	private List<Nationality> refNationality;
	private List<Status> refStatus;
	private List<Country> refCountry;
	private List<State> refState;

	public List<Nationality> getRefNationality() {
		return refNationality;
	}

	public void setRefNationality(List<Nationality> refNationality) {
		this.refNationality = refNationality;
	}

	public List<Status> getRefStatus() {
		return refStatus;
	}

	public void setRefStatus(List<Status> refStatus) {
		this.refStatus = refStatus;
	}

	public List<Country> getRefCountry() {
		return refCountry;
	}

	public void setRefCountry(List<Country> refCountry) {
		this.refCountry = refCountry;
	}

	public List<State> getRefState() {
		return refState;
	}

	public void setRefState(List<State> refState) {
		this.refState = refState;
	}

}