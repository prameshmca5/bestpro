/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dto;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Bank;
import com.bestpay.be.sdk.model.Category;
import com.bestpay.be.sdk.model.Channel;
import com.bestpay.be.sdk.model.City;
import com.bestpay.be.sdk.model.Country;
import com.bestpay.be.sdk.model.Nationality;
import com.bestpay.be.sdk.model.RefDocuments;
import com.bestpay.be.sdk.model.ReferralMultiChannel;
import com.bestpay.be.sdk.model.RelationShip;
import com.bestpay.be.sdk.model.State;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.sdk.model.SubscriptionPlan;
import com.bestpay.idm.sdk.constants.BaseConstants;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.AuditAction;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.config.audit.AuditActionPolicy;
import com.bestpay.web.constants.CacheConstants;
import com.bestpay.web.core.AbstractService;
import com.bestpay.web.util.WebUtil;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
@Component
public class StaticData extends AbstractService {

	private static final Logger LOGGER = LoggerFactory.getLogger(StaticData.class);

	private static final String ERROR_MESSAGE = "Error message = {}";

	@Autowired
	CacheManager cacheManager;


	@SuppressWarnings("unchecked")
	private Object getCmnList(String entityType) throws BeException {
		String cacheKey = CacheConstants.CACHE_KEY_REF.concat(entityType);
		Cache cache = cacheManager.getCache(CacheConstants.CACHE_BUCKET);
		Cache.ValueWrapper cv = cache.get(cacheKey);

		if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_CONFIG)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return cv.get();
			}
			try {
				LOGGER.debug("STAT_LST_CONFIG");
				Map<String, String> objMap = getBeService().reference().findAllConfig();
				if (!BaseUtil.isObjNull(objMap)) {
					cache.put(cacheKey, objMap);
				}
				return objMap;
			} catch (IdmException | BeException e) {
				if (WebUtil.checkTokenError(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
			return null;

		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_STATUS)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return cv.get();
			}
			try {
				LOGGER.debug("STAT_LST_STATUS");
				List<Status> objLst = getBeService().reference().getAllStatus();
				if (!BaseUtil.isListNullZero(objLst)) {
					cache.put(cacheKey, objLst);
				}
				return objLst;
			} catch (IdmException | BeException e) {
				if (WebUtil.checkTokenError(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
			return null;

		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_STATE)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			} else {
				try {
					List<State> objLst = getBeService().reference().findAllState();
					if (!BaseUtil.isListNullZero(objLst)) {
						cache.put(cacheKey, objLst);
					}
					return objLst;
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
				return null;
			}
		} else if (BaseUtil.isEquals(entityType, ServiceConstants.COUNTRY_LST)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			} else {
				try {
					List<Country> objLst = getBeService().reference().allCountry();
					if (!BaseUtil.isListNullZero(objLst)) {
						cache.put(cacheKey, objLst);
					}
					return objLst;
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
				return null;
			}
		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_CITY)) {

			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			}

			try {
				List<City> objLst = getBeService().reference().findByAllCities();

				if (!BaseUtil.isListNullZero(objLst)) {
					cache.put(cacheKey, objLst);
				}
				return objLst;
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
				LOGGER.debug(ERROR_MESSAGE, e);
			}
			return null;

		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_DOCUMENT)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			}
			try {
				List<RefDocuments> objLst = getBeService().reference().getRefDocLst();
				if (!BaseUtil.isListNullZero(objLst)) {
					cache.put(cacheKey, objLst);
				}
				return objLst;
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
			return null;

		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_RELATIONSHIP)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			} else {
				try {
					List<RelationShip> objLst = getBeService().reference().findAllRelationShips();
					if (!BaseUtil.isListNullZero(objLst)) {
						cache.put(cacheKey, objLst);
					}
					return objLst;
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
				return null;
			}

		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_NATIONALITY)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			} else {
				try {
					List<Nationality> objLst = getBeService().reference().findAllNationality();
					if (!BaseUtil.isListNullZero(objLst)) {
						cache.put(cacheKey, objLst);
					}
					return objLst;
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
				return null;
			}
		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_CAT)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			} else {
				try {
					List<Category> objLst = getBeService().reference().getAllCategory();
					if (!BaseUtil.isListNullZero(objLst)) {
						cache.put(cacheKey, objLst);
					}
					return objLst;
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
				return null;
			}

		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_CHNNL)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			} else {
				try {
					List<Channel> objLst = getBeService().reference().getAllChannel();
					if (!BaseUtil.isListNullZero(objLst)) {
						cache.put(cacheKey, objLst);
					}
					return objLst;
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
				return null;
			}

		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_BANK)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			} else {
				try {
					List<Bank> objLst = getBeService().reference().getAllBank();
					if (!BaseUtil.isListNullZero(objLst)) {
						cache.put(cacheKey, objLst);
					}
					return objLst;
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
				return null;
			}
		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_SUB_PLAN)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			} else {
				try {
					List<SubscriptionPlan> objLst = getBeService().reference().getAllSubscriptionPlan();
					if (!BaseUtil.isListNullZero(objLst)) {
						cache.put(cacheKey, objLst);
					}
					return objLst;
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
				return null;
			}
		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_MULTI_CHNNL)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			} else {
				try {
					List<ReferralMultiChannel> objLst = getBeService().reference().getRefMultiChannelLst();
					if (!BaseUtil.isListNullZero(objLst)) {
						cache.put(cacheKey, objLst);
					}
					return objLst;
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
				return null;
			}

		} else {
			return null;
		}
	}


	public Map<String, String> defaultMaritalStatusList() {
		Map<String, String> map = new HashMap<>();
		map.put("M", "Married");
		map.put("S", "Single");
		map.put("D", "Divorced");
		return map;
	}


	public Map<String, String> defaultReligionStatusList() {
		Map<String, String> map = new HashMap<>();
		map.put("M", "Islam");
		map.put("C", "Cristianity");
		map.put("B", "Bhuddism");
		map.put("NM", "Other Religion");
		return map;
	}


	@SuppressWarnings("unchecked")
	public List<RelationShip> relationList() throws BeException {
		return (List<RelationShip>) getCmnList(ServiceConstants.STAT_LST_RELATIONSHIP);
	}


	@SuppressWarnings("unchecked")
	public List<Nationality> nationalityList() throws BeException {
		return (List<Nationality>) getCmnList(ServiceConstants.STAT_LST_NATIONALITY);
	}


	@SuppressWarnings("unchecked")
	public Nationality nationalityByCode(String code) throws BeException {

		List<Nationality> lst = (List<Nationality>) getCmnList(ServiceConstants.STAT_LST_NATIONALITY);

		for (Nationality obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getNtnltyCode())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public RelationShip relationByCode(String code) throws BeException {
		List<RelationShip> lst = (List<RelationShip>) getCmnList(ServiceConstants.STAT_LST_RELATIONSHIP);
		for (RelationShip obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getRelationCode())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public Map<String, String> sstConfig() throws BeException {
		return ((Map<String, String>) getCmnList(ServiceConstants.STAT_LST_CONFIG));
	}


	@SuppressWarnings("unchecked")
	public List<State> getAllStateList() {

		List<State> resState = null;

		try {
			resState = ((List<State>) getCmnList(ServiceConstants.STAT_LST_STATE));

			if (!BaseUtil.isListNull(resState)) {

				Collections.sort(resState, new Comparator<State>() {

					@Override
					public int compare(State o1, State o2) {
						return o1.getStateDesc().compareTo(o2.getStateDesc());
					}
				});
			}

		} catch (Exception e) {
			LOGGER.debug(ERROR_MESSAGE, e);
		}

		return resState;
	}


	public List<State> stateList() {
		return getAllStateList();
	}


	@SuppressWarnings("unchecked")
	public List<State> stateList(String country) throws BeException {
		List<State> lst = (List<State>) getCmnList(ServiceConstants.STAT_LST_STATE);
		List<State> newLst = new ArrayList<>();
		for (State obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(country, obj.getCountry())) {
				newLst.add(obj);
			}
		}

		Collections.sort(newLst, new Comparator<State>() {

			@Override
			public int compare(State o1, State o2) {
				return o1.getStateDesc().compareTo(o2.getStateDesc());
			}
		});
		return newLst;
	}


	@SuppressWarnings("unchecked")
	public State state(String stateCode) throws BeException {
		List<State> lst = (List<State>) getCmnList(ServiceConstants.STAT_LST_STATE);
		for (State obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(stateCode, obj.getStateCode())) {
				return obj;
			}
		}
		return null;
	}


	public String stateDesc(String stateCode) throws BeException {
		State state = state(stateCode);
		if (!BaseUtil.isObjNull(state)) {
			return state.getStateDesc();
		}
		return "";
	}


	@SuppressWarnings("unchecked")
	public List<State> getStateListByCountry(String country) {
		List<State> resStateIn = null;
		try {
			List<State> resState = ((List<State>) getCmnList(ServiceConstants.STAT_LST_STATE));
			if (!BaseUtil.isListNull(resState)) {
				resStateIn = new ArrayList<>();
				for (State st : resState) {
					if (BaseUtil.isEqualsCaseIgnore(st.getCountry(), country)) {
						resStateIn.add(st);
					}
				}
				Collections.sort(resStateIn, new Comparator<State>() {

					@Override
					public int compare(State o1, State o2) {
						return o1.getStateDesc().compareTo(o2.getStateDesc());
					}
				});
			}

		} catch (Exception e) {
			LOGGER.debug(ERROR_MESSAGE, e);
		}
		return resStateIn;
	}


	@SuppressWarnings("unchecked")
	public List<Country> getAllCountryList() throws BeException {
		return ((List<Country>) getCmnList(ServiceConstants.COUNTRY_LST));
	}


	@SuppressWarnings("unchecked")
	public List<Country> getCountryListByCountryCode(String cntryCode) throws BeException {

		List<Country> countryList = ((List<Country>) getCmnList(ServiceConstants.COUNTRY_LST));

		List<Country> countryList2 = new ArrayList<>();

		if (!BaseUtil.isListNull(countryList)) {

			try {
				for (Country country : countryList) {

					if (BaseUtil.isEqualsCaseIgnore(country.getCntryCode(), cntryCode)) {
						countryList2.add(country);
					}
				}
			} catch (Exception e) {
				LOGGER.debug(ERROR_MESSAGE, e);
			}
		}
		return countryList2;
	}


	public String sstConfig(String key) throws BeException {
		if (!BaseUtil.isObjNull(key)) {
			Map<String, String> conf = sstConfig();
			return conf.get(key);
		}
		return BaseConstants.EMPTY_STRING;
	}


	public Map<String, String> defaultStatusList() {
		Map<String, String> map = new HashMap<>();
		map.put("A", "ACTIVE");
		map.put("I", "INACTIVE");
		return map;
	}


	public Map<String, String> defaultUserStatusList() {
		Map<String, String> map = new HashMap<>();
		map.put("F", "PENDING ACTIVATION");
		map.put("A", "ACTIVE");
		map.put("I", "INACTIVE");
		return map;
	}


	public void addUserAction(AuditActionPolicy auditPolicy, String userId, String reqData) {
		try {
			AuditAction audit = new AuditAction();
			audit.setPortal(messageService.getMessage("app.portal.type"));
			audit.setPage(auditPolicy.page());
			audit.setAuditInfo(auditPolicy.action());
			audit.setUserId(userId);
			audit.setLookupInfo(reqData);
		} catch (Exception e) {
			LOGGER.error("IDM-AuditAction Response Error: {}", e.getMessage());
		}
	}


	@SuppressWarnings("unchecked")
	public List<RefDocuments> refDocList(String trxnNo) throws BeException {
		List<RefDocuments> lst = (List<RefDocuments>) getCmnList(ServiceConstants.STAT_LST_DOCUMENT);
		List<RefDocuments> newLst = new ArrayList<>();
		if (!BaseUtil.isObjNull(lst)) {
			for (RefDocuments obj : lst) {
				if (BaseUtil.isEqualsCaseIgnore(trxnNo, obj.getTrxnNo())) {
					newLst.add(obj);
				}
			}
		}
		return newLst;
	}


	@SuppressWarnings("unchecked")
	public List<City> cityList() throws BeException {
		return (List<City>) getCmnList(ServiceConstants.STAT_LST_CITY);
	}


	@SuppressWarnings("unchecked")
	public City city(String cityCode) throws BeException {

		List<City> cityLst = (List<City>) getCmnList(ServiceConstants.STAT_LST_CITY);

		for (City city : cityLst) {

			if (BaseUtil.isEqualsCaseIgnore(cityCode, city.getCityCode())) {
				return city;
			}
		}
		return null;
	}


	public String cityDesc(String cityCode) throws BeException {
		City city = city(cityCode);
		if (!BaseUtil.isObjNull(city)) {
			return city.getDescEn();
		}
		return "";
	}


	@SuppressWarnings("unchecked")
	public List<City> cityList(String state) throws BeException {

		List<City> lst = (List<City>) getCmnList(ServiceConstants.STAT_LST_CITY);

		List<City> newLst = new ArrayList<>();

		for (City obj : lst) {

			if (BaseUtil.isEqualsCaseIgnore(state, obj.getState())) {
				newLst.add(obj);
			}
		}

		Collections.sort(newLst, new Comparator<City>() {

			@Override
			public int compare(City o1, City o2) {
				return o1.getState().compareTo(o2.getState());
			}
		});

		return newLst;
	}


	@SuppressWarnings("unchecked")
	public List<Country> countryList() throws BeException {
		return (List<Country>) getCmnList(ServiceConstants.COUNTRY_LST);
	}


	@SuppressWarnings("unchecked")
	public List<Country> countrySourceList() throws BeException {
		List<Country> lst = (List<Country>) getCmnList(ServiceConstants.COUNTRY_LST);
		List<Country> newLst = new ArrayList<>();
		for (Country obj : lst) {
			if (!obj.getCntryInd().isEmpty()) {
				newLst.add(obj);
			}
		}

		Collections.sort(newLst, new Comparator<Country>() {

			@Override
			public int compare(Country o1, Country o2) {
				return o1.getCntryInd().compareTo(o2.getCntryInd());
			}
		});
		return newLst;
	}


	@SuppressWarnings("unchecked")
	public Country country(String code) throws BeException {
		List<Country> lst = (List<Country>) getCmnList(ServiceConstants.COUNTRY_LST);
		for (Country obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getCntryCode())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public String countryDesc(String code) throws BeException {
		List<Country> lst = (List<Country>) getCmnList(ServiceConstants.COUNTRY_LST);
		for (Country obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getCntryCode())) {
				return obj.getCntryDesc();
			}
		}
		return "";
	}


	@SuppressWarnings("unchecked")
	public List<Status> statusList() throws BeException {
		return (List<Status>) getCmnList(ServiceConstants.STAT_LST_STATUS);
	}


	@SuppressWarnings("unchecked")
	public List<Status> status(String statusType) throws BeException {
		List<Status> statusList = (List<Status>) getCmnList(ServiceConstants.STAT_LST_STATUS);
		List<Status> statLst = new ArrayList<>();
		if (statusType != null && !BaseUtil.isListNullZero(statusList)) {
			for (Status stat : statusList) {
				if (BaseUtil.isEqualsCaseIgnore(statusType, stat.getStatusType())) {
					statLst.add(stat);
				}
			}
		}
		return statLst;
	}


	public String statusDescByStatusType(String code, String statusType) throws BeException {
		LOGGER.info("statusDescByStatusType = {} - {}", code, statusType);
		List<Status> lst = status(statusType);// (List<Status>)
		for (Status obj : lst) {
			if (BaseUtil.isEqualsCaseIgnoreAny(statusType, obj.getStatusType())
					&& BaseUtil.isEqualsCaseIgnore(code, obj.getStatusCode())) {
				return obj.getStatusDescEn();
			}
		}
		return null;
	}


	public Status statusByStatusTypeStatusCode(String code, String statusType) throws BeException {
		LOGGER.info("statusDescByStatusType = {} - {}", code, statusType);
		List<Status> lst = status(statusType);
		for (Status obj : lst) {
			if (BaseUtil.isEqualsCaseIgnoreAny(statusType, obj.getStatusType())
					&& BaseUtil.isEqualsCaseIgnore(code, obj.getStatusCode())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public String statusDesc(String code) throws BeException {
		List<Status> lst = (List<Status>) getCmnList(ServiceConstants.STAT_LST_STATUS);
		for (Status obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getStatusCode())) {
				return obj.getStatusDescEn();
			}
		}
		return "";
	}


	@SuppressWarnings("unchecked")
	public List<Bank> bankList() throws BeException {
		return (List<Bank>) getCmnList(ServiceConstants.STAT_LST_BANK);
	}


	@SuppressWarnings("unchecked")
	public List<Bank> bank(String bankId) throws BeException {
		List<Bank> bankList = (List<Bank>) getCmnList(ServiceConstants.STAT_LST_BANK);
		List<Bank> bankLst = new ArrayList<>();
		if (bankId != null && !BaseUtil.isListNullZero(bankList)) {
			for (Bank bank : bankList) {
				if (BaseUtil.isEqualsCaseIgnore(bankId, bank.getBankId().toString())) {
					bankLst.add(bank);
				}
			}
		}
		return bankLst;
	}


	@SuppressWarnings("unchecked")
	public List<Category> catList() throws BeException {
		return (List<Category>) getCmnList(ServiceConstants.STAT_LST_CAT);
	}


	@SuppressWarnings("unchecked")
	public List<Category> cat(String catName) throws BeException {
		List<Category> lst = (List<Category>) getCmnList(ServiceConstants.STAT_LST_CAT);
		for (Category obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(catName, obj.getCategoryId())) {
				return (List<Category>) obj;
			}
		}
		return Collections.emptyList();
	}


	@SuppressWarnings("unchecked")
	public List<Channel> channelList() throws BeException {
		return (List<Channel>) getCmnList(ServiceConstants.STAT_LST_CHNNL);
	}


	@SuppressWarnings("unchecked")
	public List<SubscriptionPlan> subPlanList() throws BeException {
		return (List<SubscriptionPlan>) getCmnList(ServiceConstants.STAT_LST_SUB_PLAN);
	}


	@SuppressWarnings("unchecked")
	public List<SubscriptionPlan> subscriptionPlan(String subPlanId) throws BeException {
		List<SubscriptionPlan> subscriptionPlanList = (List<SubscriptionPlan>) getCmnList(
				ServiceConstants.STAT_LST_SUB_PLAN);
		List<SubscriptionPlan> subPlan = new ArrayList<>();
		if (subPlanId != null && !BaseUtil.isListNullZero(subscriptionPlanList)) {
			for (SubscriptionPlan subscriptionPlan : subscriptionPlanList) {
				if (BaseUtil.isEqualsCaseIgnore(subPlanId, subscriptionPlan.getSubPlanId().toString())) {
					subPlan.add(subscriptionPlan);
				}
			}
		}
		return subPlan;
	}


	@SuppressWarnings("unchecked")
	public List<ReferralMultiChannel> multiChannelList(String compRefId) throws BeException {
		List<ReferralMultiChannel> chnlList = new ArrayList<>();
		if (compRefId != null && !compRefId.isEmpty()) {
			chnlList = getBeService().getMultiChannelListByCompRefId(compRefId);
			/*
			 * List<ReferralMultiChannel> chnlList = new ArrayList<>(); if
			 * (compRefId != null &&
			 * !BaseUtil.isListNullZero(refChannelList)) { for
			 * (ReferralMultiChannel referralMultiChannel : refChannelList) {
			 * System.out.println("### " +
			 * referralMultiChannel.getCompRefId()); if
			 * (referralMultiChannel.getChannelName() != null &&
			 * BaseUtil.isEqualsCaseIgnore(compRefId,
			 * referralMultiChannel.getCompRefId())) {
			 * chnlList.add(referralMultiChannel); } } }
			 */
			List<Channel> channelList = getBeService().reference().getAllChannel();
			for (ReferralMultiChannel referralMultiChannel : chnlList) {
				for (Channel channel : channelList) {
					if (referralMultiChannel.getChannel().equals(channel.getPublicName())) {
						referralMultiChannel.setChannelName(channel.getName());
					}
				}
			}
		}
		return chnlList;
	}


	@SuppressWarnings("unchecked")
	public List<Channel> allMultiChannelList() throws BeException {
		return (List<Channel>) getCmnList(ServiceConstants.STAT_LST_MULTI_CHNNL);
	}

}
