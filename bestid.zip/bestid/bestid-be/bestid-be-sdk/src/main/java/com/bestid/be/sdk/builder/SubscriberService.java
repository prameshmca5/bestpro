/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.builder;

import java.util.Arrays;
import java.util.List;

import com.bestid.be.sdk.client.BeRestTemplate;
import com.bestid.be.sdk.constants.BeUrlConstants;
import com.bestid.be.sdk.model.MessageResponse;
import com.bestid.be.sdk.model.SubscriberInfo;

/**
 * @author Suhada
 */
public class SubscriberService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;

	public SubscriberService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}

	public MessageResponse addSubscriber(SubscriberInfo subscriberInfo) {
		StringBuilder restUrl = new StringBuilder();
		restUrl.append(BeUrlConstants.SUBSCRIBER_ADD);
		return restTemplate().postForObject(getServiceURI(restUrl.toString()), subscriberInfo, MessageResponse.class);
	}

	public MessageResponse searchCompany(String cmpnyRegNo) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.SUBSCRIBER_SEARCH_COMPANY);
		sb.append("?cmpnyRegNo=" + cmpnyRegNo);
		return restTemplate().getForObject(getServiceURI(sb.toString()), MessageResponse.class);
	}

	public List<SubscriberInfo> subscriberList(SubscriberInfo subscriberInfo) {
		StringBuilder restUrl = new StringBuilder();
		restUrl.append(BeUrlConstants.SUBSCRIBER_LIST);
		SubscriberInfo[] si = restTemplate().postForObject(getServiceURI(restUrl.toString()), subscriberInfo,
				SubscriberInfo[].class);
		return Arrays.asList(si);
	}

	public Boolean deactivateSubscriber(SubscriberInfo subscriberInfo) {
		return restTemplate().postForObject(getServiceURI(BeUrlConstants.SUBSCRIBER_DEACTIVATED), subscriberInfo,
				Boolean.class);
	}

	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}

	@Override
	public String url() {
		return url;
	}

}