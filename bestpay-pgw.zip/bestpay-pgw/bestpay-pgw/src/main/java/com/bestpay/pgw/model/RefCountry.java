package com.bestpay.pgw.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;


/**
 * The persistent class for the REF_COUNTRY database table.
 *
 * @author Mohana Vamsi
 * @since Feb 22, 2018
 */
@Entity
@Table(name = "REF_COUNTRY")
public class RefCountry extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -6510355585641387606L;

	@Id
	@Column(name = "CNTRY_CODE")
	private String cntryCode;

	@Column(name = "CNTRY_DESC")
	private String cntryDesc;

	@Column(name = "CNTRY_IND")
	private String cntryInd;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public String getCntryCode() {
		return toUpper(cntryCode);
	}


	public void setCntryCode(String cntryCode) {
		this.cntryCode = toUpper(cntryCode);
	}


	public String getCntryDesc() {
		return toUpper(cntryDesc);
	}


	public void setCntryDesc(String cntryDesc) {
		this.cntryDesc = toUpper(cntryDesc);
	}


	public String getCntryInd() {
		return cntryInd;
	}


	public void setCntryInd(String cntryInd) {
		this.cntryInd = cntryInd;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Integer getId() {
		return null;
	}


	public void setId(Integer id) {
		/*
		 * setter method
		 */

	}

}