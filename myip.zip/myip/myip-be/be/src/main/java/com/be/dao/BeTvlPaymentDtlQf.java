/**
 * 
 */
package com.be.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeAcctPassport;
import com.be.model.BeAcctTraveller;
import com.be.model.BeConfigPaymentStage;
import com.be.model.BeTvlMcAttendance;
import com.be.model.BeTvlPaymentDtl;
import com.be.model.BeTvlProfile;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.PaymentDtl;
import com.be.service.BeTvlProfileService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;

/**
 * @author Ramesh Pongiannan
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_PAYMENTDTL_QF)
public class BeTvlPaymentDtlQf extends QueryFactory<BeTvlPaymentDtl> {

	@Autowired
	BeTvlProfileService tvlProfileSvc;
	
	@Autowired
	BeConfigPaymentStageRepository configPaymentStageSvc;
		
 	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;

	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}
	
	@Override
	public Specification<BeTvlPaymentDtl> searchByProperty(BeTvlPaymentDtl t) {
		return (Root<BeTvlPaymentDtl> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}

	@Override
	public List<BeTvlPaymentDtl> searchAllByProperty(BeTvlPaymentDtl t) {
		CriteriaQuery<BeTvlPaymentDtl> cq = cb.createQuery(BeTvlPaymentDtl.class);
		Root<BeTvlPaymentDtl> from = cq.from(BeTvlPaymentDtl.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}

	public List<BeTvlPaymentDtl> searchBeTvlPaymentDetails(PaymentDtl dto, DataTableRequest<?> dataTableInRQ) {

		List<BeTvlPaymentDtl> result = new ArrayList<>();
		CriteriaQuery<BeTvlPaymentDtl> cq = cb.createQuery(BeTvlPaymentDtl.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlPaymentDtl> root = cq.from(BeTvlPaymentDtl.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					cq.orderBy(getOrderByClause(cb, root, pagination));
				}
			}

			TypedQuery<BeTvlPaymentDtl> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}
	
	
	public BeTvlPaymentDtl searchPayment(PaymentDtl dto) {

		BeTvlPaymentDtl result = null;
		CriteriaQuery<BeTvlPaymentDtl> cq = cb.createQuery(BeTvlPaymentDtl.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlPaymentDtl> root = cq.from(BeTvlPaymentDtl.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeTvlPaymentDtl> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}
	
	public Long getCount(PaymentDtl dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeTvlPaymentDtl> root = cq.from(BeTvlPaymentDtl.class);
		predicates.addAll(generateCriteria(cb, root, dto));
		
		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}
	
	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			BeTvlPaymentDtl dto = JsonUtil.transferToObject(criteria, BeTvlPaymentDtl.class);
			/* 
			if (!BaseUtil.isObjNull(dto.getTvlPayment().getTvlPmtId())) {
				predicates.add(cb.equal(from.get("tvlPmtId"), dto.getTvlPayment().getTvlPmtId()));
			}
			*/
			
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void joinFetch(From<?, ?> from, List<Predicate> predicates, PaymentDtl dto, CriteriaQuery<BeTvlPaymentDtl> cq) {
		
		from.fetch("tvlPayment", JoinType.LEFT);
		from.fetch("tvlPaymentInfos", JoinType.LEFT);
		Join<BeTvlPaymentDtl, BeTvlProfile> tvlProfile = (Join) from.fetch("tvlProfile", JoinType.LEFT);
		predicates.addAll(tvlProfileSvc.generateCriteria(cb, tvlProfile, dto.getTvlProfile())); 
		
		 
	}
 
}
