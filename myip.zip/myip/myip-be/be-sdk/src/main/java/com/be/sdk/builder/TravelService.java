/**
 *
 */
package com.be.sdk.builder;


import java.util.Map;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.Tvl;
import com.util.pagination.DataTableResults;


/**
 * @author michelle.angela
 *
 */
public class TravelService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public TravelService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<Tvl> searchTravelPagination(Tvl dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVEL).append(BeUrlConstants.TRAVEL);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}


	public Tvl getTravel(Tvl dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVEL).append(BeUrlConstants.TRAVEL);
		sb.append(BeUrlConstants.GET_DETAIL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Tvl.class);
	}


	public Tvl updateTravel(Tvl tvl) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVEL);
		sb.append(BeUrlConstants.UPDATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), tvl, Tvl.class);
	}
}
