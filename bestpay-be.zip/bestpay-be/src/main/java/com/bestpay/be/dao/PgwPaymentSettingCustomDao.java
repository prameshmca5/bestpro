package com.bestpay.be.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.bestpay.be.model.PgwPaymentSetting;
import com.bestpay.be.model.PgwSettlement;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;

@Repository
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_PYMT_SETTING_CUSTOM_DAO)
public class PgwPaymentSettingCustomDao {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PgwPaymentSettingCustomDao.class);

	
	@PersistenceContext
	private EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<PgwPaymentSetting> findMerchantpaymentListByCompRefId(String compRefId){
		StringBuilder sb = new StringBuilder("select r ");
		sb.append(" from PgwPaymentSetting r, PgwMerchantProfile t ");
		sb.append(" where 1=1 ");
		sb.append(" and r.merchantId = t.merchantId ");
		if(compRefId!=null) {
			sb.append(" and t.companyRefId = :compRefId ");
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.info(sb.toString());
		}
		TypedQuery<PgwPaymentSetting> query = entityManager.createQuery(sb.toString(), PgwPaymentSetting.class);
		
		query.setParameter("compRefId", compRefId);
		
		if (LOGGER.isDebugEnabled()) {
			LOGGER.info(query.toString());
		}
		
		return query.getResultList();
	}


}
