/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.core;


import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Locale;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.RandomStringUtils;
import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.StringUtils;

import com.bestpay.be.config.ConfigConstants;
import com.bestpay.be.config.StaticData;
import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.service.PgwBankDetailsService;
import com.bestpay.be.service.PgwBusinessCategoryService;
import com.bestpay.be.service.PgwConfigService;
import com.bestpay.be.service.PgwFraudSettingService;
import com.bestpay.be.service.PgwMerchantBlacklistService;
import com.bestpay.be.service.PgwMerchantCompanyBankDetailsService;
import com.bestpay.be.service.PgwMerchantCompanyService;
import com.bestpay.be.service.PgwMerchantContactService;
import com.bestpay.be.service.PgwMerchantPidService;
import com.bestpay.be.service.PgwMerchantProfileService;
import com.bestpay.be.service.PgwMerchantProviderService;
import com.bestpay.be.service.PgwMerchantSubscriptionService;
import com.bestpay.be.service.PgwMultiChannelService;
import com.bestpay.be.service.PgwOfflineRequestPaymentService;
import com.bestpay.be.service.PgwPaymentSettingService;
import com.bestpay.be.service.PgwReferralMultiChannelService;
import com.bestpay.be.service.PgwReportSubscribeService;
import com.bestpay.be.service.PgwRestrictionService;
import com.bestpay.be.service.PgwSettlementConfigService;
import com.bestpay.be.service.PgwSettlementService;
import com.bestpay.be.service.PgwTicketService;
import com.bestpay.be.service.PgwTransactionService;
import com.bestpay.be.service.PgwTrxnDocumentsService;
import com.bestpay.be.service.RefCategoryService;
import com.bestpay.be.service.RefChannelService;
import com.bestpay.be.service.RefCountryService;
import com.bestpay.be.service.RefStatusService;
import com.bestpay.be.service.RefSubscriptionPlanService;
import com.bestpay.idm.sdk.client.IdmServiceClient;
import com.bestpay.notify.sdk.client.NotServiceClient;
import com.bestpay.notify.sdk.util.BaseUtil;
import com.bstsb.util.UidGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public abstract class AbstractRestController extends GenericAbstract {

	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractRestController.class);

	public static final String HEADER_MESSAGE_ID = "X-Message-Id";

	public static final String HEADER_AUTHORIZATION = "Authorization";

	@Autowired
	protected Mapper dozerMapper;

	@Autowired
	protected ObjectMapper objectMapper;

	@Autowired
	protected StaticData staticData;

	@Autowired
	protected CacheManager cacheManager;

	@Autowired
	protected RedisTemplate<String, String> redisTemplate;

	@Autowired
	protected PgwMerchantBlacklistService pgwMerchantBlacklistService;

	@Autowired
	protected PgwMerchantProfileService pgwMerchantProfileService;

	@Autowired
	protected PgwPaymentSettingService pgwPaymentSettingService;

	@Autowired
	protected PgwMultiChannelService pgwMultiChannelService;

	@Autowired
	protected PgwMerchantContactService pgwMerchantContactService;

	@Autowired
	protected PgwFraudSettingService pgwFraudSettingService;

	@Autowired
	protected PgwBankDetailsService pgwBankDetailsService;

	@Autowired
	protected PgwBusinessCategoryService pgwBusinessCategoryService;

	@Autowired
	protected PgwTransactionService pgwTransactionService;

	@Autowired
	protected RefCategoryService refCategoryService;

	@Autowired
	protected PgwReportSubscribeService pgwReportSubscribeService;

	@Autowired
	protected PgwRestrictionService pgwRestrictionService;

	@Autowired
	protected PgwSettlementConfigService pgwSettlementConfigService;

	@Autowired
	protected PgwOfflineRequestPaymentService pgwOfflineRequestPaymentService;

	@Autowired
	protected PgwMerchantSubscriptionService pgwMerchantSubscriptionService;

	@Autowired
	protected RefChannelService refChannelSvc;

	private NotServiceClient notifyService;

	@Autowired
	protected PgwTicketService pgwTicketService;

	@Autowired
	protected PgwSettlementService pgwSettlementService;

	@Autowired
	protected RefSubscriptionPlanService refSubscriptionPlanService;

	@Autowired
	protected RefStatusService refStatusService;

	@Autowired
	private IdmServiceClient idmService;

	@Autowired
	protected PgwTrxnDocumentsService pgwTrxnDocumentsService;

	@Autowired
	protected PgwMerchantCompanyService pgwMerchantCompanyService;

	@Autowired
	protected PgwMerchantPidService pgwMerchantPidService;

	@Autowired
	protected PgwMerchantProviderService pgwMerchantProviderService;

	@Autowired
	protected RefCountryService refCountrySvc;

	@Autowired
	protected PgwMerchantCompanyBankDetailsService pgwMerchantCompanyBankDetailsService;

	@Autowired
	protected PgwReferralMultiChannelService pgwReferralMultiChannelService;

	@Autowired
	protected PgwConfigService pgwConfigSvc;


	protected Timestamp getSQLTimestamp() {
		Calendar calendar = Calendar.getInstance();
		java.util.Date now = calendar.getTime();
		return new java.sql.Timestamp(now.getTime());
	}


	protected String getCurrUserId(HttpServletRequest request) {
		return String.valueOf(request.getAttribute("currUserId"));
	}


	protected String getCurrUserFullname(HttpServletRequest request) {
		return String.valueOf(request.getAttribute("currUserFname"));
	}


	public NotServiceClient getNotifyService(HttpServletRequest request) {
		if (BaseUtil.isObjNull(notifyService)) {
			String url = messageSource.getMessage(ConfigConstants.SVC_NOT_URL, null, Locale.getDefault());
			notifyService = new NotServiceClient(url);
		}

		String messageId = request.getHeader(HEADER_MESSAGE_ID);
		if (messageId == null) {
			messageId = String.valueOf(UUID.randomUUID());
		}
		String auth = request.getHeader(HEADER_AUTHORIZATION);
		notifyService.setAuthToken(auth);
		notifyService.setMessageId(messageId);
		notifyService.setReadTimeout(Integer
				.valueOf(messageSource.getMessage(ConfigConstants.SVC_NOT_TIMEOUT, null, Locale.getDefault())));
		return notifyService;
	}


	protected String genUserName(String name) {
		String userName = "";
		name = name.replaceAll("[^\\w]", "");

		if (name.length() < 8) {
			name = name + RandomStringUtils.randomAlphabetic(8 - name.length());
		}

		if (name.length() >= 8) {

			int start = 4;
			int end = 4;
			userName = name.substring(0, start) + name.substring(name.length() - end);
			LOGGER.debug("Username '{}' Already Exists..", userName);
			boolean isExists = false;
			isExists = isUserNameExists(userName);
			if (isExists) {
				// case -2
				userName = name.substring(0, start - 1) + name.substring(name.length() - end - 1);
				isExists = isUserNameExists(userName);

				if (isExists) {
					// case-3
					userName = name.substring(0, start - 2) + name.substring(name.length() - end - 2);
					isExists = isUserNameExists(userName);
					if (isExists) {
						// case-4
						userName = name.substring(0, start - 3) + name.substring(name.length() - end - 3);
						isExists = isUserNameExists(userName);
						if (isExists) {
							// case-5
							userName = name.substring(0, start - 4) + name.substring(name.length() - end - 4);
							// randomly generate username
							isExists = isUserNameExists(userName);
							if (isExists) {
								for (int i = 0; i < 8; i++) {
									String username = shuffle(userName);
									isExists = isUserNameExists(username);
									if (!isExists) {
										userName = username;
										break;
									}
								}
							}
						}
					}
				}

			}

		} else {
			// error.. Name should be 8 chars.
			return null;
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Generated Username: {}", userName.toLowerCase());
		}
		return userName.toLowerCase();
	}


	protected String shuffle(String username) {
		if (username.length() <= 1) {
			return username;
		}

		int split = username.length() / 2;

		String temp1 = shuffle(username.substring(0, split));
		String temp2 = shuffle(username.substring(split));

		if (Math.random() > 0.5) {
			return temp1 + temp2;
		} else {
			return temp2 + temp1;
		}
	}


	protected boolean isUserNameExists(String userName) {
		PgwMerchantProfile pf = pgwMerchantProfileService.findMerProfileByMerchantId(userName);

		if (BaseUtil.isObjNull(pf)) {
			return false;
		}

		String dbName = StringUtils.hasText(pf.getMerchantId()) ? pf.getMerchantId() : null;
		return StringUtils.pathEquals(userName.toLowerCase(), dbName);
	}


	public IdmServiceClient getIdmService() {

		idmService.setToken(messageService.getMessage(ConfigConstants.SVC_IDM_SKEY));
		idmService.setClientId(messageService.getMessage(ConfigConstants.SVC_IDM_CLIENT));
		idmService.setMessageId(UidGenerator.getMessageId());
		return idmService;
	}

}