/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;


/**
 * @author nurul.naimma
 *
 * @since 9 Nov 2018
 */
public class CtrlGen implements Serializable {

	private static final long serialVersionUID = -1089090176875288666L;

	private String ctrlGenId;

	private String trxnCd;

	private Integer trxnId;


	/**
	 * @return the ctrlGenId
	 */
	public String getCtrlGenId() {
		return ctrlGenId;
	}


	/**
	 * @param ctrlGenId
	 *             the ctrlGenId to set
	 */
	public void setCtrlGenId(String ctrlGenId) {
		this.ctrlGenId = ctrlGenId;
	}


	/**
	 * @return the trxnCd
	 */
	public String getTrxnCd() {
		return trxnCd;
	}


	/**
	 * @param trxnCd
	 *             the trxnCd to set
	 */
	public void setTrxnCd(String trxnCd) {
		this.trxnCd = trxnCd;
	}


	/**
	 * @return the trxnId
	 */
	public Integer getTrxnId() {
		return trxnId;
	}


	/**
	 * @param trxnId
	 *             the trxnId to set
	 */
	public void setTrxnId(Integer trxnId) {
		this.trxnId = trxnId;
	}

}
