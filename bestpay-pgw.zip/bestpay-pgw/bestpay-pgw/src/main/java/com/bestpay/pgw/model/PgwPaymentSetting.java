package com.bestpay.pgw.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;

@Entity
@Table(name = "PGW_PAYMENT_SETTING")
public class PgwPaymentSetting extends AbstractEntity implements Serializable {

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8642114187292260403L;

	@Id
	@Column(name="PMT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(name="MERCHANT_ID")
	private String merchantId;
	
	@Column(name="SELLER_ID")
	private String sellerId;
	
	@Column(name="RETURN_URL")
	private String retUrl;

	@Column(name="RETURN_URL_WITH_IPN")
	private String retUrlPin;
	
	@Column(name="CALLBACK_URL")
	private String callUrl;
	
	@Column(name="CALLBACK_URL_WITH_IPN")
	private String callUrlPin;
	
	@Column(name="VERIFY_KEY")
	private String verifykey;
	
	@Column(name="ENABLE_VERIFY")
	private Integer enableVerify;
	
	@Column(name="EMAIL_NOTIFICATION")
	private String emailNot;
	
	@Column(name="RECEIPT")
	private String receipt;
	
	@Column(name="CAN_MODIFY_OID")
	private Integer modifyOid;
	
	@Column(name="CAN_MODIFY_AMT")
	private Integer modifyAmt;
	
	@Column(name="CANT_MODIFY_DESC")
	private String modifyDesc;
	
	@Column(name="EMAIL_LOCK")
	private String emailLock;
	
	@Column(name="NAME_LOCK")
	private String nameLock;
	
	@Column(name="PHONE_LOCK")
	private String phoneLock;
	
	@Column(name = "CREATE_ID")
	private String createId;
	
	@Column(name = "CREATE_DT")
	private Timestamp createDt;
	
	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;
	
	@Column(name = "DOC_MGT_ID")
	private String docMgtId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getRetUrl() {
		return retUrl;
	}

	public void setRetUrl(String retUrl) {
		this.retUrl = retUrl;
	}

	public String getRetUrlPin() {
		return retUrlPin;
	}

	public void setRetUrlPin(String retUrlPin) {
		this.retUrlPin = retUrlPin;
	}

	public String getCallUrl() {
		return callUrl;
	}

	public void setCallUrl(String callUrl) {
		this.callUrl = callUrl;
	}

	public String getCallUrlPin() {
		return callUrlPin;
	}

	public void setCallUrlPin(String callUrlPin) {
		this.callUrlPin = callUrlPin;
	}

	public String getVerifykey() {
		return verifykey;
	}

	public void setVerifykey(String verifykey) {
		this.verifykey = verifykey;
	}

	public Integer getEnableVerify() {
		return enableVerify;
	}

	public void setEnableVerify(Integer enableVerify) {
		this.enableVerify = enableVerify;
	}

	public String getEmailNot() {
		return emailNot;
	}

	public void setEmailNot(String emailNot) {
		this.emailNot = emailNot;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public Integer getModifyOid() {
		return modifyOid;
	}

	public void setModifyOid(Integer modifyOid) {
		this.modifyOid = modifyOid;
	}

	public Integer getModifyAmt() {
		return modifyAmt;
	}

	public void setModifyAmt(Integer modifyAmt) {
		this.modifyAmt = modifyAmt;
	}

	public String getModifyDesc() {
		return modifyDesc;
	}

	public void setModifyDesc(String modifyDesc) {
		this.modifyDesc = modifyDesc;
	}

	public String getEmailLock() {
		return emailLock;
	}

	public void setEmailLock(String emailLock) {
		this.emailLock = emailLock;
	}

	public String getNameLock() {
		return nameLock;
	}

	public void setNameLock(String nameLock) {
		this.nameLock = nameLock;
	}

	public String getPhoneLock() {
		return phoneLock;
	}

	public void setPhoneLock(String phoneLock) {
		this.phoneLock = phoneLock;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getDocMgtId() {
		return docMgtId;
	}

	public void setDocMgtId(String docMgtId) {
		this.docMgtId = docMgtId;
	}
	
	
}
