/**
 * Copyright 2019
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;


/**
 * The persistent class for the REF_STATUS database table.
 *
 * @author Mary Jane Buenaventura
 * @since Oct 5, 2019
 */
@Entity
@Table(name = "REF_POSITION")
public class RefPosition extends AbstractEntity implements Serializable, IQfCriteria<RefPosition> {

	private static final long serialVersionUID = 3362801765553782305L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "POSITION_ID")
	private Integer positionId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "STATUS")
	private Boolean status;

	@Column(name = "POSITION_CD")
	private String positionCd;

	@Lob
	@Column(name = "POSITION_DESC")
	private String positionDesc;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;


	public RefPosition() {
	}


	public Integer getPositionId() {
		return this.positionId;
	}


	public void setPositionId(Integer positionId) {
		this.positionId = positionId;
	}


	@Override
	public Timestamp getCreateDt() {
		return this.createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getCreateId() {
		return this.createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Boolean isActive() {
		return status;
	}


	public void setActive(Boolean status) {
		this.status = status;
	}


	public String getPositionCd() {
		return this.positionCd;
	}


	public void setPositionCd(String positionCd) {
		this.positionCd = positionCd;
	}


	public String getPositionDesc() {
		return this.positionDesc;
	}


	public void setPositionDesc(String positionDesc) {
		this.positionDesc = positionDesc;
	}


	@Override
	public Timestamp getUpdateDt() {
		return this.updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getUpdateId() {
		return this.updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}