/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.core;


import java.io.File;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Locale;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.core.RedisTemplate;

import com.bestpay.be.sdk.client.BeServiceClient;
import com.bestpay.notify.sdk.client.NotServiceClient;
import com.bestpay.notify.sdk.util.BaseUtil;
import com.bestpay.pgw.config.ConfigConstants;
import com.bestpay.pgw.config.StaticData;
import com.bestpay.pgw.service.PgwMerchantBeneficiaryService;
import com.bestpay.pgw.service.PgwMerchantCompanyBankDetailsService;
import com.bestpay.pgw.service.PgwMerchantCompanyService;
import com.bestpay.pgw.service.PgwMerchantProviderService;
import com.bestpay.pgw.service.RefFpxResponseCodeService;
import com.bstsb.util.UidGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public abstract class AbstractRestController extends GenericAbstract {

	public static final String HEADER_MESSAGE_ID = "X-Message-Id";

	public static final String HEADER_AUTHORIZATION = "Authorization";

	@Autowired
	protected Mapper dozerMapper;

	@Autowired
	protected ObjectMapper objectMapper;

	@Autowired
	protected StaticData staticData;

	@Autowired
	protected CacheManager cacheManager;

	@Autowired
	protected RedisTemplate<String, String> redisTemplate;

	private NotServiceClient notifyService;

	@Autowired
	private BeServiceClient beService;

	@Autowired
	protected PgwMerchantBeneficiaryService pgwMerchantBeneficiaryService;
	
	@Autowired
	protected PgwMerchantCompanyService pgwMerchantCompanyService;
	
	@Autowired
	protected PgwMerchantCompanyBankDetailsService pgwMerchantCompanyBankDetailsService;

	@Autowired
	protected PgwMerchantProviderService pgwMerchantProviderService;
	
	@Autowired
	protected RefFpxResponseCodeService refFpxResponseCodeService;


	protected Timestamp getSQLTimestamp() {
		Calendar calendar = Calendar.getInstance();
		java.util.Date now = calendar.getTime();
		return new java.sql.Timestamp(now.getTime());
	}


	protected String getCurrUserId(HttpServletRequest request) {
		return String.valueOf(request.getAttribute("currUserId"));
	}


	protected String getCurrUserFullname(HttpServletRequest request) {
		return String.valueOf(request.getAttribute("currUserFname"));
	}


	public NotServiceClient getNotifyService(HttpServletRequest request) {
		if (BaseUtil.isObjNull(notifyService)) {
			String url = messageSource.getMessage(ConfigConstants.SVC_NOT_URL, null, Locale.getDefault());
			notifyService = new NotServiceClient(url);
		}

		String messageId = request.getHeader(HEADER_MESSAGE_ID);
		if (messageId == null) {
			messageId = String.valueOf(UUID.randomUUID());
		}
		String auth = request.getHeader(HEADER_AUTHORIZATION);
		notifyService.setAuthToken(auth);
		notifyService.setMessageId(messageId);
		notifyService.setReadTimeout(Integer
				.valueOf(messageSource.getMessage(ConfigConstants.SVC_NOT_TIMEOUT, null, Locale.getDefault())));
		return notifyService;
	}


	// Read certificates from conf
	public String getCertPath() {
		String propertyHome = null;
		propertyHome = System.getProperty(ConfigConstants.PATH_CATALINA_HOME) != null
				? System.getProperty(ConfigConstants.PATH_CATALINA_HOME)
				: System.getProperty(ConfigConstants.PATH_CATALINA_BASE);
		if (!BaseUtil.isObjNull(propertyHome)) {
			propertyHome = propertyHome + File.separator + "conf/fpx/";
		}

		return propertyHome;
	}


	public BeServiceClient getBeService() {

		beService.setToken(messageService.getMessage(ConfigConstants.SVC_IDM_SKEY));
		beService.setClientId(messageService.getMessage(ConfigConstants.SVC_IDM_CLIENT));
		beService.setMessageId(UidGenerator.getMessageId());
		return beService;
	}

}