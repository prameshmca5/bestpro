/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.bestpay.be.model.PgwMerchantBlacklist;
import com.bestpay.be.sdk.model.BlacklistInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.pagination.PaginationCriteria;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;
import com.bstsb.util.DateUtil;

/**
 * @author Afif Saman
 * @since June 6, 2018
 */
@Repository
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.STTLMNTINFO_CUSTOM_DAO)
public class BlacklistCustomDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(BlacklistCustomDao.class);

	@Autowired
	private PgwMerchantBlacklistRepository blacklistDao;

	@PersistenceContext
	private EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public DataTableResults<PgwMerchantBlacklist> searchByPagination(BlacklistInfo blacklistInfo,
			DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append("from PgwMerchantBlacklist r ");
		sb.append(" where 1=1 ");

		if (!BaseUtil.isObjNull(blacklistInfo.getTag())) {
			sb.append(" and r.tag = :tag ");
		}

		if (!BaseUtil.isObjNull(blacklistInfo.getValue())) {
			sb.append(" and r.value like :value ");
		}

		if (!BaseUtil.isObjNull(blacklistInfo.getCreateDate())) {
			sb.append("and r.createDate between :createDate and :createDateAfter ");

		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause("r"));
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<PgwMerchantBlacklist> query = entityManager.createQuery(sb.toString(), PgwMerchantBlacklist.class);
		// Original Query
		TypedQuery<PgwMerchantBlacklist> query2 = entityManager.createQuery(sb.toString(), PgwMerchantBlacklist.class);

		if (!BaseUtil.isObjNull(blacklistInfo.getTag())) {
			query.setParameter("tag", blacklistInfo.getTag());
			query2.setParameter("tag", blacklistInfo.getTag());
		}

		if (!BaseUtil.isObjNull(blacklistInfo.getValue())) {
			query.setParameter("value", "%" + blacklistInfo.getValue() + "%");
			query2.setParameter("value", "%" + blacklistInfo.getValue() + "%");
		}

		if (!BaseUtil.isObjNull(blacklistInfo.getCreateDate())) {
			query.setParameter("createDate", blacklistInfo.getCreateDate(), TemporalType.DATE);
			query2.setParameter("createDate", blacklistInfo.getCreateDate(), TemporalType.DATE);
			query.setParameter("createDateAfter", DateUtil.addDayToTimestamp(blacklistInfo.getCreateDate(), 1),
					TemporalType.DATE);
			query2.setParameter("createDateAfter", DateUtil.addDayToTimestamp(blacklistInfo.getCreateDate(), 1),
					TemporalType.DATE);
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwMerchantBlacklist> dataTableResult = new DataTableResults<>();
		List<PgwMerchantBlacklist> svcResp = query.getResultList();
		List<PgwMerchantBlacklist> svcResp2 = query2.getResultList();
		LOGGER.debug("Filtered Size: {}", svcResp.size());
		LOGGER.debug("Original Size: {}", svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : blacklistDao.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		LOGGER.debug("isFilterByEmpty: {}", dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}
		return dataTableResult;
	}

}