/**
 *
 */
package com.be.controller;


import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.model.BeAcctProfile;
import com.be.model.BeAirlinesProfile;
import com.be.model.BeDoctorProfile;
import com.be.model.BeMcProfile;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.AcctProfile;
import com.be.sdk.model.AirlinesProfile;
import com.be.sdk.model.DoctorProfile;
import com.be.sdk.model.McAddress;
import com.be.sdk.model.McProfile;
import com.be.service.BeAcctProfileService;
import com.be.service.BeAirlinesProfileService;
import com.be.service.BeDoctorProfileService;
import com.be.service.BeMcAddressService;
import com.be.service.BeMcProfileService;
import com.notify.sdk.exception.NotificationException;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;
import com.util.pagination.DataTableRequest;
import com.util.pagination.DataTableResults;


/**
 * @author michelle.angela
 *
 */
@Lazy
@RestController
@RequestMapping(BeUrlConstants.PROFILES)
public class ProfileRestController extends AbstractRestController {

	@Autowired
	BeAcctProfileService acctProfileSvc;

	@Autowired
	BeAirlinesProfileService airlinesProfileSvc;

	@Autowired
	BeMcProfileService mcProfileSvc;

	@Autowired
	BeDoctorProfileService doctorProfileSvc;

	@Autowired
	BeMcAddressService mcAddressSvc;


	@PostMapping(value = BeUrlConstants.REGISTER, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public AcctProfile register(@RequestBody AcctProfile dto, HttpServletRequest request) throws IOException {

		if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getEmail())) {
			throw new BeException(BeErrorCodeEnum.E400C913);
		}

		BeAcctProfile beAcctProfile = acctProfileSvc.findByEmail(dto.getEmail());
		if (!BaseUtil.isObjNull(beAcctProfile)) {
			throw new BeException(BeErrorCodeEnum.I409C001);
		}
		try {

			if (BaseUtil.isObjNull(dto.getResidentPlace())) {
				dto.setResidentPlace(dto.getCountry());
			}

			beAcctProfile = acctProfileSvc.createUpdate(dto, beAcctProfile, request);

			return JsonUtil.transferToObject(beAcctProfile, AcctProfile.class);
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		} catch (NotificationException e) {
			throw new BeException(BeErrorCodeEnum.E500C009);
		}
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public AcctProfile update(@RequestBody AcctProfile dto, HttpServletRequest request) throws IOException {

		if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getEmail())) {
			throw new BeException(BeErrorCodeEnum.E400C913);
		}

		try {
			AcctProfile acctProf = new AcctProfile();
			acctProf.setEmail(dto.getEmail());
			BeAcctProfile beAcctProfile = acctProfileSvc.searchBeAcctProfile(acctProf);
			if (BaseUtil.isObjNull(beAcctProfile)) {
				throw new BeException(BeErrorCodeEnum.I404C001);
			}

			if (BaseUtil.isObjNull(dto.getResidentPlace())) {
				dto.setResidentPlace(dto.getCountry());
			}

			AcctProfile acctProfile = JsonUtil.transferToObject(beAcctProfile, AcctProfile.class);
			acctProfile.setContactNo(dto.getContactNo());
			acctProfile.setFullName(dto.getFullName());

			beAcctProfile = acctProfileSvc.createUpdate(acctProfile, beAcctProfile, request);

			return JsonUtil.transferToObject(beAcctProfile, AcctProfile.class);
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	@PostMapping(value = BeUrlConstants.GET_DETAIL, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public AcctProfile getProfileDetails(@RequestBody AcctProfile dto, HttpServletRequest request) throws IOException {
		return JsonUtil.transferToObject(acctProfileSvc.searchBeAcctProfile(dto), AcctProfile.class);
	}


	@PostMapping(value = BeUrlConstants.AIRLINES + BeUrlConstants.GET_DETAIL, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public AirlinesProfile getAAirlinesProfileDetails(@RequestBody AirlinesProfile dto, HttpServletRequest request)
			throws IOException {

		if (BaseUtil.isObjNull(dto)) {
			dto = new AirlinesProfile();
		}
		dto.setEmbedContacts(true);
		dto.setEmbedPICs(true);
		dto.setEmbedAddresses(true);
		return JsonUtil.transferToObject(airlinesProfileSvc.searchBeAirlinesProfile(dto), AirlinesProfile.class);
	}


	@PostMapping(value = BeUrlConstants.AIRLINES + BeUrlConstants.REGISTER, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public AirlinesProfile addAirlinesInfo(@RequestBody AirlinesProfile dto, HttpServletRequest request)
			throws IOException {
		if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getEmail())) {
			throw new BeException(BeErrorCodeEnum.E400C913);
		}

		try {
			AirlinesProfile dtoSearch = new AirlinesProfile();
			dtoSearch.setEmail(dto.getEmail());
			BeAirlinesProfile beAirlinesProfile = airlinesProfileSvc.searchBeAirlinesProfile(dtoSearch);
			if (!BaseUtil.isObjNull(beAirlinesProfile)) {
				throw new BeException(BeErrorCodeEnum.I409C004);
			}

			beAirlinesProfile = airlinesProfileSvc.createUpdate(
					JsonUtil.transferToObject(dto, BeAirlinesProfile.class), beAirlinesProfile,
					dto.getTrxnDocuments(), request, dto.getSystemType());

			return JsonUtil.transferToObject(beAirlinesProfile, AirlinesProfile.class);
		} catch (BeException e) {
			if (BaseUtil.isEquals(e.getInternalErrorCode(), "I409C004")) {
				throw new BeException(BeErrorCodeEnum.I409C004);
			} else {
				throw new BeException(BeErrorCodeEnum.E500C001);
			}
		} catch (Exception e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	@PostMapping(value = BeUrlConstants.MC_PROFILE + BeUrlConstants.GET_DETAIL, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public McProfile getMcProfileDetails(@RequestBody McProfile dto, HttpServletRequest request) throws IOException {

		if (BaseUtil.isObjNull(dto)) {
			dto = new McProfile();
		}
		dto.setEmbedOwners(true);
		dto.setEmbedPICs(true);
		dto.setEmbedAddresses(true);
		return JsonUtil.transferToObject(mcProfileSvc.searchBeMcProfile(dto), McProfile.class);
	}


	@PostMapping(value = BeUrlConstants.MC_PROFILE + BeUrlConstants.REGISTER, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public McProfile addMCInfo(@RequestBody McProfile dto, HttpServletRequest request) throws IOException {
		if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getEmail())) {
			throw new BeException(BeErrorCodeEnum.E400C913);
		}

		try {
			McProfile dtoSearch = new McProfile();
			dtoSearch.setMcRegNo(dto.getMcRegNo());
			BeMcProfile beMcProfile = mcProfileSvc.searchBeMcProfile(dtoSearch);
			if (!BaseUtil.isObjNull(beMcProfile)) {
				throw new BeException(BeErrorCodeEnum.I409C003);
			}

			beMcProfile = mcProfileSvc.createUpdate(JsonUtil.transferToObject(dto, BeMcProfile.class), beMcProfile,
					dto.getTrxnDocuments(), request, dto.getSystemType());

			return JsonUtil.transferToObject(beMcProfile, McProfile.class);
		} catch (BeException e) {
			if (BaseUtil.isEquals(e.getInternalErrorCode(), "I409C003")) {
				throw new BeException(BeErrorCodeEnum.I409C003);
			} else {
				throw new BeException(BeErrorCodeEnum.E500C001);
			}
		}
	}


	@PostMapping(value = BeUrlConstants.DOCTOR + BeUrlConstants.GET_DETAIL, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DoctorProfile getDoctorDetails(@RequestBody DoctorProfile dto, HttpServletRequest request)
			throws IOException {
		return JsonUtil.transferToObject(doctorProfileSvc.searchBeDoctorProfile(dto), DoctorProfile.class);
	}


	@PostMapping(value = BeUrlConstants.DOCTOR + BeUrlConstants.REGISTER, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DoctorProfile registerDoctor(@RequestBody DoctorProfile dto, HttpServletRequest request)
			throws IOException {
		if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getEmail())) {
			throw new BeException(BeErrorCodeEnum.E400C913);
		}
		String reguser = dto.getUserId();
		BeDoctorProfile beDoctorProfile = null;
		try {
			if (!BaseUtil.isObjNull(dto.getDocProfId())) {
				DoctorProfile dtoSearch = new DoctorProfile();
				dtoSearch.setDocProfId(dto.getDocProfId());
				beDoctorProfile = doctorProfileSvc.searchBeDoctorProfile(dtoSearch);
			}

			beDoctorProfile = doctorProfileSvc.createUpdate(JsonUtil.transferToObject(dto, BeDoctorProfile.class),
					beDoctorProfile, request, reguser, dto.getTrxnDocuments());

			return JsonUtil.transferToObject(beDoctorProfile, DoctorProfile.class);
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	@PostMapping(value = BeUrlConstants.DOCTOR + BeUrlConstants.UPDATE, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DoctorProfile updateDoctor(@RequestBody DoctorProfile dto, HttpServletRequest request) throws IOException {
		if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getDocProfId())) {
			throw new BeException(BeErrorCodeEnum.E400C913);
		}
		String reguser = dto.getUserId();
		try {

			DoctorProfile dtoSearch = new DoctorProfile();
			dtoSearch.setDocProfId(dto.getDocProfId());
			BeDoctorProfile beDoctorProfile = doctorProfileSvc.searchBeDoctorProfile(dtoSearch);
			if (BaseUtil.isObjNull(beDoctorProfile)) {
				throw new BeException(BeErrorCodeEnum.I409C001);
			}

			beDoctorProfile = doctorProfileSvc.createUpdate(JsonUtil.transferToObject(dto, BeDoctorProfile.class),
					beDoctorProfile, request, reguser, dto.getTrxnDocuments());

			return JsonUtil.transferToObject(beDoctorProfile, DoctorProfile.class);
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	@PostMapping(value = BeUrlConstants.DOCTOR + BeUrlConstants.SEARCH_PAGINATION, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DataTableResults<DoctorProfile> searchDoctorPaginated(@RequestBody DoctorProfile dto,
			HttpServletRequest request) throws IOException {

		DataTableRequest<DoctorProfile> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) doctorProfileSvc.getCount(dto);
		List<DoctorProfile> filtered = doctorProfileSvc.searchDoctorPagination(dto, dataTableInRQ);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("ALL DATA: {}", totalCount);
			LOGGER.debug("ALL filtered DATA : {}", filtered);
		}

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.DOCTOR + BeUrlConstants.GET_LIST, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<DoctorProfile> getDoctorList(@RequestBody DoctorProfile dto, HttpServletRequest request)
			throws IOException {
		return JsonUtil.transferToList(doctorProfileSvc.searchDoctorPagination(dto, null), DoctorProfile.class);
	}


	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.MC_PROFILE + BeUrlConstants.GET_LIST, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<McProfile> getMcList(@RequestBody McProfile dto, HttpServletRequest request) throws IOException {
		return JsonUtil.transferToList(
				mcProfileSvc.searchAllByProperty(JsonUtil.transferToObject(dto, BeMcProfile.class)),
				McProfile.class);
	}


	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.AIRLINES + BeUrlConstants.GET_LIST, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<AirlinesProfile> getMcList(@RequestBody AirlinesProfile dto, HttpServletRequest request)
			throws IOException {
		return JsonUtil.transferToList(
				airlinesProfileSvc.searchAllByProperty(JsonUtil.transferToObject(dto, BeAirlinesProfile.class)),
				AirlinesProfile.class);
	}

	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.AIRLINES + BeUrlConstants.AIRLINE_EXIST, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<AirlinesProfile> checkAirlineExistByCertainCriteria(@RequestBody AirlinesProfile dto, HttpServletRequest request)
			throws IOException {
		return JsonUtil.transferToList(
				airlinesProfileSvc.searchExistByProperty(JsonUtil.transferToObject(dto, BeAirlinesProfile.class)),
				AirlinesProfile.class);
	}


	@PostMapping(value = BeUrlConstants.AIRLINES + BeUrlConstants.SEARCH_PAGINATION, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DataTableResults<AirlinesProfile> searchAirlinesPaginated(@RequestBody AirlinesProfile dto,
			HttpServletRequest request) throws IOException {

		DataTableRequest<AirlinesProfile> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) airlinesProfileSvc.getCount(dto);
		List<AirlinesProfile> filtered = airlinesProfileSvc.searchAirlinesPagination(dto, dataTableInRQ);
		for (AirlinesProfile element : filtered) {
			if (element.getAirlinesTypeMtdt() != null) {
				element.setAirlinesType(element.getAirlinesTypeMtdt().getMtdtDesc());
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("ALL DATA: {}", totalCount);
			LOGGER.debug("ALL filtered DATA : {}", filtered);
		}

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.MC_PROFILE + BeUrlConstants.SEARCH_PAGINATION, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DataTableResults<McProfile> searchMcPaginated(@RequestBody McProfile dto, HttpServletRequest request)
			throws IOException {

		DataTableRequest<McProfile> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) mcProfileSvc.getCount(dto);
		List<McProfile> filtered = mcProfileSvc.searchDoctorPagination(dto, dataTableInRQ);
		for (McProfile profile : filtered) {
			if (!BaseUtil.isListNullZero(profile.getMcAddresses())) {
				McAddress add = profile.getMcAddresses().get(0);
				profile.setCntryDesc(add.getCountry().getCntryDesc());
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("ALL DATA: {}", totalCount);
			LOGGER.debug("ALL filtered DATA : {}", filtered);
		}

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.MC_ADDRESS + BeUrlConstants.SEARCH_PAGINATION, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DataTableResults<McAddress> searchMcAddressPaginated(@RequestBody McAddress dto, HttpServletRequest request)
			throws IOException {

		DataTableRequest<McAddress> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) mcAddressSvc.getCount(dto);
		List<McAddress> filtered = mcAddressSvc.searchMcAddressPagination(dto, dataTableInRQ);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("ALL DATA: {}", totalCount);
			LOGGER.debug("ALL filtered DATA : {}", filtered);
		}

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.MC_ADDRESS + BeUrlConstants.GET_DETAIL, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public McAddress getDoctorDetails(@RequestBody McAddress dto, HttpServletRequest request) throws IOException {
		return JsonUtil.transferToObject(mcAddressSvc.searchMcAddress(dto), McAddress.class);
	}


	@PostMapping(value = BeUrlConstants.MC_PROFILE + BeUrlConstants.UPDATE, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public McProfile updateMcInfo(@RequestBody McProfile dto, HttpServletRequest request) throws IOException {
		if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getMcProfId())) {
			throw new BeException(BeErrorCodeEnum.E400C913);
		}

		try {
			McProfile dtoSearch = new McProfile();
			dtoSearch.setMcProfId(dto.getMcProfId());
			BeMcProfile beMcProfile = mcProfileSvc.searchBeMcProfile(dtoSearch);
			if (BaseUtil.isObjNull(beMcProfile)) {
				throw new BeException(BeErrorCodeEnum.I404C001);
			}

			beMcProfile = mcProfileSvc.createUpdate(JsonUtil.transferToObject(dto, BeMcProfile.class), beMcProfile,
					dto.getTrxnDocuments(), request, dto.getSystemType());

			return JsonUtil.transferToObject(beMcProfile, McProfile.class);
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	@PostMapping(value = BeUrlConstants.AIRLINES + BeUrlConstants.UPDATE, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public AirlinesProfile updateAirlinesInfo(@RequestBody AirlinesProfile dto, HttpServletRequest request)
			throws IOException {
		if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getAirlinesProfId())) {
			throw new BeException(BeErrorCodeEnum.E400C913);
		}

		try {
			AirlinesProfile dtoSearch = new AirlinesProfile();
			dtoSearch.setAirlinesProfId(dto.getAirlinesProfId());
			BeAirlinesProfile beAirlinesProfile = airlinesProfileSvc.searchBeAirlinesProfile(dtoSearch);
			if (BaseUtil.isObjNull(beAirlinesProfile)) {
				throw new BeException(BeErrorCodeEnum.I404C001);
			}

			beAirlinesProfile = airlinesProfileSvc.createUpdate(
					JsonUtil.transferToObject(dto, BeAirlinesProfile.class), beAirlinesProfile,
					dto.getTrxnDocuments(), request, dto.getSystemType());

			return JsonUtil.transferToObject(beAirlinesProfile, AirlinesProfile.class);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}
}
