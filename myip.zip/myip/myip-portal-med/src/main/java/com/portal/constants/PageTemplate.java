/**
  * Copyright 2018. Bestinet Sdn Bhd
 */
package com.portal.constants;


/**
 * @author Mary Jane Buenaventura
 * @since May 17, 2018
 */
public class PageTemplate {

	private PageTemplate() {
		throw new IllegalStateException("Utility class");
	}


	public static final String TEMP_COMPONENTS = "pg_components";

	public static final String TEMP_ERROR = "pg_error";

	public static final String TEMP_ERROR_403 = "pg_error403";

	public static final String TEMP_LOGIN = "login";

	public static final String MAIN_PAGE = "main_page";

	public static final String FAQ = "faq";

	public static final String CONTACT = "contact";

	public static final String DISCLAIMER = "disclaimer";

	public static final String FIND_OUT_MORE = "findOutMore";

	public static final String MAIN_JOB_DTL = "main_job";

	public static final String IDM_FORGOT_PWORD = "forgot_password";

	public static final String TEMP_USERMGMT = "idm_usermgmt";

	public static final String TEMP_IDM_USR_CHNG_PWORD = "change-password";

	public static final String TEMP_IDM_USR_CRED = "user_profile";

	public static final String TEMP_IDM_USR_LST = "user_list";

	public static final String TEMP_DASHBOARD = "dashboard";

	public static final String TEMP_CMN_STTC_LST = "static_list";

	public static final String TEMP_HOME = "home";

	public static final String IDM_UPDATE_PROFILE = "updateProfile";

	public static final String TEMP_POLICY = "policy";

	public static final String TEMP_IDM_FACE = "pg_face";

	public static final String MEDICAL_CENTER = "medicalCenter";

	public static final String MEDICAL_VERIFY_ATT_LIST = "mc-verify-attndce";

	public static final String MEDICAL_VERIFY_PHOTO_ATT = "mc-verify-photo_attendance";

	public static final String TEMP_MEDICAL_RESULT = "mc-medical-result";

	public static final String TEMP_UPDATE_MEDICAL_RESULT = "update-mc-medical-result";

	public static final String TEMP_APPROVED_MEDICAL_RESULT = "approved-mc-medical-result";

	public static final String TEMP_MEDICAL_RESULT_SEARCH = "mc-medical-result-search";

	public static final String PAGE_DOC_SRCH = "doc-search";

	public static final String TEMP_TRAVELLER_INFO = "traveller-info";

	public static final String PAGE_DOC_ADD = "doc-add";

	public static final String TEMP_TRVELR_EDIT = "traveller-update";

	public static final String TEMP_CMN_FACE_UPD = "pg_face_upd";

	public static final String TEMP_CMN_PASS_UPD = "pg_pass_upd";

	public static final String TEMP_TRAVELLER_INFO_UPD = "traveller-info_edit";

	public static final String PAGE_DOC_OPT_SRCH = "doc-opt-search";

}
