/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.config.init;


import java.util.Locale;

import javax.servlet.Filter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.filter.DelegatingFilterProxy;
import org.springframework.web.filter.HiddenHttpMethodFilter;
import org.springframework.web.filter.ShallowEtagHeaderFilter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.config.ConfigConstants;
import com.bestpay.web.config.ExceptionConfig;
import com.bestpay.web.config.MDCFilter;
import com.bestpay.web.config.SecurityConfig;
import com.bestpay.web.config.ServiceConfig;
import com.bestpay.web.config.SessionListener;
import com.bestpay.web.config.WebMvcConfig;
import com.bestpay.web.config.gzip.GzipFilter;
import com.bestpay.web.exception.ErrorHandlerFilter;


/**
 * Application Initializer
 * 
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class ApplicationInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {

	private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationInitializer.class);


	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] { WebMvcConfig.class, SecurityConfig.class, ExceptionConfig.class, ServiceConfig.class };
	}


	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] {};
	}


	@Override
	protected String[] getServletMappings() {
		return new String[] { "/*" };
	}


	@Override
	protected Filter[] getServletFilters() {
		CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
		characterEncodingFilter.setEncoding("UTF-8");

		DelegatingFilterProxy securityFilterChain = new DelegatingFilterProxy("springSecurityFilterChain");

		return new Filter[] { characterEncodingFilter, securityFilterChain, new HiddenHttpMethodFilter(),
				new ShallowEtagHeaderFilter(), new ErrorHandlerFilter(), new GzipFilter(), new MDCFilter() };
	}


	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		LOGGER.info("Starting Admin Portal...");
		servletContext.addListener(new HttpSessionEventPublisher());
		servletContext.addListener(new SessionListener());
		servletContext.addListener(new RequestContextListener());
		String secure = messageSource().getMessage("session.secure.cookie", null, Locale.getDefault());
		if (!BaseUtil.isObjNull(secure)) {
			servletContext.getSessionCookieConfig().setSecure(Boolean.getBoolean(secure));
		}
		super.onStartup(servletContext);
	}


	@Bean
	@Qualifier("messageSource")
	public MessageSource messageSource() {
		ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
		messageSource.setBasenames("classpath:messages/portal/locale", "classpath:messages/portal/message",
				"classpath:messages/app_url", ConfigConstants.FILE_PFX + WebMvcConfig.getPropertyPath());
		messageSource.setUseCodeAsDefaultMessage(true);
		messageSource.setDefaultEncoding("UTF-8");
		messageSource.setCacheSeconds(1800);
		messageSource.setFallbackToSystemLocale(false);
		return messageSource;
	}


	@Override
	public void customizeRegistration(ServletRegistration.Dynamic registration) {
		registration.setInitParameter("throwExceptionIfNoHandlerFound", "true");
	}

}