/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Atiqah
 * @since June 20, 2018
 */
public class MerSettlementSet implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1864073233598003483L;
	private String settleDay;
	private Date recentSettleDt;
	private Date nextSettleDt;
	private String merchantId;
	private Integer reserveDay;
	private String userId;

	public String getSettleDay() {
		return settleDay;
	}

	public void setSettleDay(String settleDay) {
		this.settleDay = settleDay;
	}

	public Date getRecentSettleDt() {
		return recentSettleDt;
	}
	
	public void setRecentSettleDt(Date recentSettleDt) {
		this.recentSettleDt = recentSettleDt;
	}
	
	public Date getNextSettleDt() {
		return nextSettleDt;
	}
	
	public void setNextSettleDt(Date nextSettleDt) {
		this.nextSettleDt = nextSettleDt;
	}
	
	public String getMerchantId() {
		return merchantId;
	}
	
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public Integer getReserveDay() {
		return reserveDay;
	}

	public void setReserveDay(Integer reserveDay) {
		this.reserveDay = reserveDay;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}