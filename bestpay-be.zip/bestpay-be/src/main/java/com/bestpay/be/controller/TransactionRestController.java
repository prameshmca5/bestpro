/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwTransaction;
import com.bestpay.be.model.RefChannel;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.model.Transaction;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.service.PgwTransactionService;
import com.bstsb.util.MediaType;


/**
 * @author N.N. Shuhada
 * @since 08 June 2018
 */

@RestController
@RequestMapping(BeUrlConstants.TRANSACTION)
public class TransactionRestController extends AbstractRestController {

	@Autowired
	private PgwTransactionService pgwTransactionSvc;


	@PostMapping(value = BeUrlConstants.TRANSACTION_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<Transaction> searchBilling(@Valid @RequestBody Transaction transactionList,
			HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwTransaction> result = pgwTransactionSvc.searchTranLst(transactionList, dataTableInRQ);
		DataTableResults<Transaction> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			if (!BaseUtil.isListNullAndZero((result.getData()))) {
				List<Transaction> bpLst = new ArrayList<>();
				for (PgwTransaction bbp : result.getData()) {
					Transaction trustee = dozerMapper.map(bbp, Transaction.class);
					if (!BaseUtil.isObjNull(bbp.getChannel()) && !BaseUtil.isEquals(bbp.getChannel(), "FPX")) {
						RefChannel channel = refChannelSvc.findRefChannelByPublicName(bbp.getChannel());
						trustee.setPaymentType(channel.getType());
					} else if (BaseUtil.isEquals(bbp.getChannel(), "FPX")) {
						trustee.setPaymentType("FPX");
					} else {
						trustee.setPaymentType("-");
					}
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		return dataTableInResp;
	}


	@PostMapping(value = BeUrlConstants.TOP10_TRANSLIST, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<Transaction> searchTop10List(@Valid @RequestBody Transaction transactionList,
			HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwTransaction> result = pgwTransactionSvc.searchTop10TranLst(transactionList,
				dataTableInRQ);
		DataTableResults<Transaction> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			if (!BaseUtil.isListNullAndZero((result.getData()))) {
				List<Transaction> bpLst = new ArrayList<>();
				for (PgwTransaction bbp : result.getData()) {
					Transaction trustee = dozerMapper.map(bbp, Transaction.class);
					if (!BaseUtil.isObjNull(bbp.getChannel()) || BaseUtil.isEquals(bbp.getChannel(), "FPX")) {
						RefChannel channel = refChannelSvc.findRefChannelByPublicName(bbp.getChannel());
						trustee.setPaymentType(channel.getType());
						trustee.setChannel(channel.getName());
					} else {
						trustee.setPaymentType("-");
					}
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		return dataTableInResp;
	}


	@GetMapping(value = "/{transId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Transaction getTransDetailById(@PathVariable String transId) {

		PgwTransaction transDtl = super.pgwTransactionService.findDetailByTranId(transId);

		Transaction dtl = new Transaction();
		if (!BaseUtil.isObjNull(transDtl)) {
			dtl = dozerMapper.map(transDtl, Transaction.class);
			String stat = dtl.getStatus().toUpperCase();
			RefChannel refChannel = refChannelSvc.findRefChannelByPublicName(dtl.getChannel());
			if (!BaseUtil.isObjNull(refChannel)) {
				dtl.setChannel(refChannel.getName());
			} else {
				dtl.setChannel(dtl.getChannel());
			}
			dtl.setStatus(stat);
		}

		return dtl;
	}


	// @Add by Ramesh Pongiannan
	@PostMapping(value = BeUrlConstants.TRANS_SETTLELIST, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<Transaction> findAllStmtTransList(@RequestBody Transaction transaction, HttpServletRequest request) {
		List<Transaction> arTrans = new ArrayList<>();
		String merchantId = transaction.getMerchantId();
		Integer setTransId = transaction.getSetId();

		if (BaseUtil.isObjNull(merchantId)) {
			List<PgwTransaction> stmtList = pgwTransactionSvc.findDetailBySetIdTrans(setTransId);
			for (PgwTransaction info : stmtList) {
				transaction = dozerMapper.map(info, Transaction.class);
				RefChannel channel = refChannelSvc.findRefChannelByPublicName(info.getChannel());
				transaction.setChannel(channel.getName());
				arTrans.add(transaction);
			}
		} else {
			List<PgwTransaction> stmtList = pgwTransactionSvc.findDetailBySetId(merchantId, setTransId);
			for (PgwTransaction info : stmtList) {
				transaction = dozerMapper.map(info, Transaction.class);
				arTrans.add(transaction);
			}
		}

		return arTrans;
	}


	@GetMapping(value = BeUrlConstants.TRANS_MONTHLIST + "/{merchantId}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<String> getTransListByMonth(@PathVariable String merchantId, HttpServletRequest request) {
		return pgwTransactionSvc.getTransListByMonth(merchantId);
	}


	@PostMapping(value = BeUrlConstants.TRANS_SUCC_TODAY_LIST, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<Transaction> getTodaysSuccessfulTransactions(@RequestBody String merchantId,
			HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwTransaction> values = pgwTransactionSvc.getTodaysSuccessfulTransactions(merchantId,
				dataTableInRQ);
		DataTableResults<Transaction> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(values)) {
			dataTableInResp.setRecordsFiltered(values.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(values.getRecordsTotal());
			if (!BaseUtil.isListNullAndZero((values.getData()))) {
				List<Transaction> bpLst = new ArrayList<>();
				for (PgwTransaction bbp : values.getData()) {
					Transaction trustee = dozerMapper.map(bbp, Transaction.class);
					if (!BaseUtil.isObjNull(bbp.getChannel()) || BaseUtil.isEquals(bbp.getChannel(), "FPX")) {
						RefChannel channel = refChannelSvc.findRefChannelByPublicName(bbp.getChannel());
						trustee.setPaymentType(channel.getType());
					} else {
						trustee.setPaymentType("-");
					}
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		return dataTableInResp;
	}


	@PostMapping(value = BeUrlConstants.TRANS_SUCC_MNTHLY_LIST, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<Transaction> getMonthlySuccessfulTransactions(@RequestBody String merchantId,
			HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwTransaction> values = pgwTransactionSvc.getMonthlySuccessfulTransactions(merchantId,
				dataTableInRQ);
		DataTableResults<Transaction> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(values)) {
			dataTableInResp.setRecordsFiltered(values.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(values.getRecordsTotal());
			if (!BaseUtil.isListNullAndZero((values.getData()))) {
				List<Transaction> bpLst = new ArrayList<>();
				for (PgwTransaction bbp : values.getData()) {
					Transaction trustee = dozerMapper.map(bbp, Transaction.class);
					if (!BaseUtil.isObjNull(bbp.getChannel()) || BaseUtil.isEquals(bbp.getChannel(), "FPX")) {
						RefChannel channel = refChannelSvc.findRefChannelByPublicName(bbp.getChannel());
						trustee.setPaymentType(channel.getType());
					} else {
						trustee.setPaymentType("-");
					}
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		return dataTableInResp;
	}


	@GetMapping(value = BeUrlConstants.TRANS_SUCC_MNTHLY_SUM + "/{merchantId}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public String getSumAndCountOfMonth(@PathVariable String merchantId, HttpServletRequest request) {
		return pgwTransactionSvc.getSumAndCountOfMonth(merchantId);
	}


	@GetMapping(value = BeUrlConstants.TRANS_SUCC_TODAY_CNT + "/{merchantId}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public long getTodaysCountSuccessfulTransactions(@PathVariable String merchantId, HttpServletRequest request) {
		return pgwTransactionSvc.getTodaysCountSuccessfulTransactions(merchantId);
	}


	@GetMapping(value = BeUrlConstants.TRANS_SUM_BILLAMT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public double getSumOfBillAmt(HttpServletRequest request) {
		return pgwTransactionSvc.getSumOfBillAmt();
	}

}