/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;
import java.util.List;

/**
 * @author michelle.angela
 *
 */
public class Insurance implements Serializable, IQfCriteria<Insurance> {

	private static final long serialVersionUID = -1070269417964145574L;

	private Integer tvlInsId;
	
	private TvlProfile tvlProfile;
	 
	private PaymentDtl tvlPaymentDtl;

	private String coverageDtl;
	
	private String insuranceValidity;
	
	private String docRefNo;
	
	private Integer tvlProfId;
	
	private Integer statusId;
	
	private List<TrxnDocuments> trxnDocumentList;
	
	private Status status;
	
	private Payment tvlPayment;

	public Integer getTvlInsId() {
		return tvlInsId;
	}

	public void setTvlInsId(Integer tvlInsId) {
		this.tvlInsId = tvlInsId;
	}

	public TvlProfile getTvlProfile() {
		return tvlProfile;
	}

	public void setTvlProfile(TvlProfile tvlProfile) {
		this.tvlProfile = tvlProfile;
	}

	public PaymentDtl getTvlPaymentDtl() {
		return tvlPaymentDtl;
	}

	public void setTvlPaymentDtl(PaymentDtl tvlPaymentDtl) {
		this.tvlPaymentDtl = tvlPaymentDtl;
	}

	public String getCoverageDtl() {
		return coverageDtl;
	}

	public void setCoverageDtl(String coverageDtl) {
		this.coverageDtl = coverageDtl;
	}

	public String getInsuranceValidity() {
		return insuranceValidity;
	}

	public void setInsuranceValidity(String insuranceValidity) {
		this.insuranceValidity = insuranceValidity;
	}

	public String getDocRefNo() {
		return docRefNo;
	}

	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}

	public Integer getTvlProfId() {
		return tvlProfId;
	}

	public void setTvlProfId(Integer tvlProfId) {
		this.tvlProfId = tvlProfId;
	}

	public Integer getStatusId() {
		return statusId;
	}

	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	public List<TrxnDocuments> getTrxnDocumentList() {
		return trxnDocumentList;
	}

	public void setTrxnDocumentList(List<TrxnDocuments> trxnDocumentList) {
		this.trxnDocumentList = trxnDocumentList;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Payment getTvlPayment() {
		return tvlPayment;
	}

	public void setTvlPayment(Payment tvlPayment) {
		this.tvlPayment = tvlPayment;
	}
	
}
