/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;


/**
 * @author Atiqah
 * @since June 7, 2018
 */
public class MerGenInfo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1864073233598003483L;

	private Integer merProfId;

	private String merchantId;

	private String name;

	private String phone;

	private String mphone;

	private String fax;

	private String email;

	private String email2;

	private String emailMisc;

	private String ccEmail;

	private String ccEmailTo;

	private String state;

	private String stateName;

	private String postcode;

	private String city;

	private String address;

	private String country;

	private String userId;

	private String address2;

	private String address3;

	private String stateMy;

	private String stateNonMy;

	private String cityMy;

	private String cityNonMy;

	private Integer pdpa;

	private String rocNo;


	public String getCityMy() {
		return cityMy;
	}


	public void setCityMy(String cityMy) {
		this.cityMy = cityMy;
	}


	public String getCityNonMy() {
		return cityNonMy;
	}


	public void setCityNonMy(String cityNonMy) {
		this.cityNonMy = cityNonMy;
	}


	public String getStateMy() {
		return stateMy;
	}


	public void setStateMy(String stateMy) {
		this.stateMy = stateMy;
	}


	public String getStateNonMy() {
		return stateNonMy;
	}


	public void setStateNonMy(String stateNonMy) {
		this.stateNonMy = stateNonMy;
	}


	public String getAddress2() {
		return address2;
	}


	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	public String getAddress3() {
		return address3;
	}


	public void setAddress3(String address3) {
		this.address3 = address3;
	}


	public Integer getMerProfId() {
		return merProfId;
	}


	public void setMerProfId(Integer merProfId) {
		this.merProfId = merProfId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getMphone() {
		return mphone;
	}


	public void setMphone(String mphone) {
		this.mphone = mphone;
	}


	public String getFax() {
		return fax;
	}


	public void setFax(String fax) {
		this.fax = fax;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getEmail2() {
		return email2;
	}


	public void setEmail2(String email2) {
		this.email2 = email2;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getStateName() {
		return stateName;
	}


	public void setStateName(String stateName) {
		this.stateName = stateName;
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getEmailMisc() {
		return emailMisc;
	}


	public void setEmailMisc(String emailMisc) {
		this.emailMisc = emailMisc;
	}


	public String getCcEmail() {
		return ccEmail;
	}


	public void setCcEmail(String ccEmail) {
		this.ccEmail = ccEmail;
	}


	public String getCcEmailTo() {
		return ccEmailTo;
	}


	public void setCcEmailTo(String ccEmailTo) {
		this.ccEmailTo = ccEmailTo;
	}


	public Integer getPdpa() {
		return pdpa;
	}


	public void setPdpa(Integer pdpa) {
		this.pdpa = pdpa;
	}


	public String getRocNo() {
		return rocNo;
	}


	public void setRocNo(String rocNo) {
		this.rocNo = rocNo;
	}

}