/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author Suhada
 */
public class MaritalStatus implements Serializable {

	private static final long serialVersionUID = 2708543236371408998L;
	
	private String maritalStatusId;
	private String maritalStatusCode;
	private String maritalStatusDescEn;
	private String createId;
	private Timestamp createDt;
	private String updateId;
	private Timestamp updateDt;


	public String getMaritalStatusId() {
		return maritalStatusId;
	}

	public void setMaritalStatusId(String maritalStatusId) {
		this.maritalStatusId = maritalStatusId;
	}

	public String getMaritalStatusCode() {
		return maritalStatusCode;
	}

	public void setMaritalStatusCode(String maritalStatusCode) {
		this.maritalStatusCode = maritalStatusCode;
	}

	public String getMaritalStatusDescEn() {
		return maritalStatusDescEn;
	}

	public void setMaritalStatusDescEn(String maritalStatusDescEn) {
		this.maritalStatusDescEn = maritalStatusDescEn;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


}