/**
 *
 */
package com.be.service;


import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeConfigPaymentBreakdownRepository;
import com.be.dao.BeTvlPaymentDtlRepository;
import com.be.dao.BeTvlRefundQf;
import com.be.dao.BeTvlRefundRepository;
import com.be.dao.BeTvlRepository;
import com.be.model.BeConfigPaymentBreakdown;
import com.be.model.BeTvlPaymentDtl;
import com.be.model.BeTvlRefund;
import com.be.model.RefStatus;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.TvlRefund;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_REFUND_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_REFUND_SVC)
public class BeTvlRefundService extends AbstractService<BeTvlRefund> {

	@Autowired
	BeTvlRefundRepository beTvlRefundDao;

	@Autowired
	BeTvlRefundQf beTvlRefundQf;

	@Autowired
	BeConfigPaymentBreakdownRepository beConfigPaymentBreakdownDao;

	@Autowired
	RefStatusService refStatusSvc;
	
	@Autowired
	BeTvlPaymentDtlRepository beTvlPaymentDtlRepository;
	
	@Autowired
	BeTvlRepository beTvlRepository;
	
	@Autowired 
	BeTvlService beTvlService;

	@Override
	public GenericRepository<BeTvlRefund> primaryDao() {
		return beTvlRefundDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}


	public long getCount(TvlRefund dto) {
		return beTvlRefundQf.getCount(dto);
	}


	public BeTvlRefund searchBeTvlRefund(TvlRefund dto) {
		return beTvlRefundQf.searchbyRefund(dto);
	}


	@SuppressWarnings("unchecked")
	public List<TvlRefund> searchBeTvlPaymentRefundPagination(TvlRefund dto, DataTableRequest<?> dataTableInRQ)
			throws IOException {
		return JsonUtil.transferToList(beTvlRefundQf.searchPaymentRefundPagination(dto, dataTableInRQ),
				TvlRefund.class);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class })
	public BeTvlRefund addRefundInfo(TvlRefund dto, String userId) throws IOException {
		
		BeTvlRefund beTvlRefund = JsonUtil.transferToObject(dto, BeTvlRefund.class);
		if (!BaseUtil.isObjNull(dto.getPmtBreakdown()) && !BaseUtil.isObjNull(dto.getPmtBreakdown().getPmtBreakdownId())) {
			BeConfigPaymentBreakdown pmtBreakdown = beConfigPaymentBreakdownDao
					.findOne(dto.getPmtBreakdown().getPmtBreakdownId());
			if (!BaseUtil.isObjNull(pmtBreakdown)) {
				beTvlRefund.setPmtBreakdown(pmtBreakdown);
			}
		}
		
		RefStatus refStatus = new RefStatus();
		refStatus.setStatusType("REFUND");
		refStatus.setStatusCd("RFND_APR");
		refStatus = refStatusSvc.searchAllByProperty(refStatus).get(0);
		beTvlRefund.setStatus(refStatus);
		if(BaseUtil.isEquals(userId, null)) {
			userId = "SYSTEM";
		}
		beTvlRefund.setCreateId(userId);
		beTvlRefund.setUpdateId(userId);
		beTvlRefund = update(beTvlRefund);
		if(!BaseUtil.isObjNull(beTvlRefund)) {
			BeTvlPaymentDtl paymentDtl =  beTvlPaymentDtlRepository.findOne(dto.getTvlPaymentDtl().getTvlPmtDtlId());
			Integer profId = paymentDtl.getTvlProfile().getTvlProfId();
			if(profId !=null) {
				beTvlService.updateStatus(profId, refStatus.getStatusId());
			}
		}
		return beTvlRefund;
	}

	public BeTvlRefund createUpdate(TvlRefund dto, String userId) throws IOException {

		BeTvlRefund beTvlRefund = beTvlRefundDao.findByRefundId(dto.getTvlRefundId());
		if (!BaseUtil.isObjNull(dto.getPmtBreakdown())
				&& !BaseUtil.isObjNull(dto.getPmtBreakdown().getPmtBreakdownId())) {
			BeConfigPaymentBreakdown pmtBreakdown = beConfigPaymentBreakdownDao
					.findOne(dto.getPmtBreakdown().getPmtBreakdownId());
			if (!BaseUtil.isObjNull(pmtBreakdown)) {
				beTvlRefund.setPmtBreakdown(pmtBreakdown);
			}
		}
		beTvlRefund.setRemarks(dto.getRemarks());
		JsonUtil.transferToObject(dto, BeTvlRefund.class);
		return update(beTvlRefund);
	}

	public BeTvlRefund findProfileRefund(Integer tvlPmtInfoId) {
		return beTvlRefundDao.findByRefundId(tvlPmtInfoId);
	}
	
	

}
