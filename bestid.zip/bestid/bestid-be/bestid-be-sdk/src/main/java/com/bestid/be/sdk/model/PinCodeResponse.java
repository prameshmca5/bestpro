/**
 * Copyright 2019. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;

import com.bestid.be.sdk.model.Device;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author mohd.faisal
 *
 */
@JsonInclude(Include.NON_NULL)
public class PinCodeResponse implements Serializable {

	private static final long serialVersionUID = 1395412900677871139L;

	private String profileId;

	private String pinCode;

	private String verifyPinCode;

	private String oldPinCode;

	Device deviceInfo;


	public PinCodeResponse() {
		// Do nothing
	}


	public String getProfileId() {
		return profileId;
	}


	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}


	public String getPinCode() {
		return pinCode;
	}


	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}


	public String getVerifyPinCode() {
		return verifyPinCode;
	}


	public void setVerifyPinCode(String verifyPinCode) {
		this.verifyPinCode = verifyPinCode;
	}


	public String getOldPinCode() {
		return oldPinCode;
	}


	public void setOldPinCode(String oldPinCode) {
		this.oldPinCode = oldPinCode;
	}


	public Device getDeviceInfo() {
		return deviceInfo;
	}


	public void setDeviceInfo(Device deviceInfo) {
		this.deviceInfo = deviceInfo;
	}

}
