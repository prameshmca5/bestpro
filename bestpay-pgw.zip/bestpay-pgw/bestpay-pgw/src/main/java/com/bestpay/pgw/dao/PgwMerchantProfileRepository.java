package com.bestpay.pgw.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.PgwMerchantProfile;
import com.bestpay.pgw.util.QualifierConstants;

@Repository
@RepositoryDefinition(domainClass = PgwMerchantProfile.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_PROFILE_DAO)
public interface PgwMerchantProfileRepository extends GenericRepository<PgwMerchantProfile> {
	
	@Query("select u from PgwMerchantProfile u where u.merchantId = :merchantId ")
	public PgwMerchantProfile findbyMerchantId(@Param("merchantId") String merchantId);

}
