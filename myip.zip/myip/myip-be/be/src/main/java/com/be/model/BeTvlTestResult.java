/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.util.BaseUtil;


/**
 * @author Atiqah Khairuddin
 *
 */

@Entity
@Table(name = "BE_TVL_TEST_RESULT")
public class BeTvlTestResult extends AbstractEntity implements Serializable, IQfCriteria<BeTvlTestResult> {

	private static final long serialVersionUID = -6606855235977856401L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TVL_TEST_RESULT_ID")
	private Integer tvlTestResultId;

	@Column(name = "MC_REF_NO")
	private String mcRefNo;

	@Column(name = "MC_PROF_ID")
	private Integer mcProfId;

	@JsonIgnoreProperties("tvlTestResults")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TVL_PROF_ID")
	private BeTvlProfile tvlProfile;

	// @JsonSerialize(using = JsonDateSerializer.class)
	// @JsonDeserialize(using = JsonDateDeserializer.class)
	// @JsonFormat(shape = JsonFormat.Shape.STRING, pattern =
	// BaseConstants.DT_YYYY_MM_DD_SLASH)
	// @Temporal(TemporalType.DATE)
	@Column(name = "MED_TEST_DT")
	private Timestamp medTestDt;

	@Column(name = "DOCTOR_PROF_ID")
	private Integer doctorProfId;

	@Column(name = "CNTRY_CD")
	private String cntryCd;

	@Column(name = "MEDICAL_RESULT")
	private Integer medicalResult;

	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "DOCTOR_REMARKS")
	private String doctorRemarks;

	@Column(name = "STATUS_ID")
	private Integer statusId;

	@Column(name = "DOC_REF_NO")
	private String docRefNo;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@JsonIgnoreProperties("tvlTestResult")
	@OneToMany(mappedBy = "tvlTestResult", fetch = FetchType.LAZY)
	private Set<BeTvlMcCollate> tvlMcCollates;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "MC_PROF_ID", insertable = false, updatable = false)
	private BeMcProfile mcProfile;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "STATUS_ID", insertable = false, updatable = false)
	private RefStatus status;


	public Integer getTvlTestResultId() {
		return tvlTestResultId;
	}


	public void setTvlTestResultId(Integer tvlTestResultId) {
		this.tvlTestResultId = tvlTestResultId;
	}


	public String getMcRefNo() {
		return mcRefNo;
	}


	public void setMcRefNo(String mcRefNo) {
		this.mcRefNo = mcRefNo;
	}


	public Integer getMcProfId() {
		return mcProfId;
	}


	public void setMcProfId(Integer mcProfId) {
		this.mcProfId = mcProfId;
	}


	public BeTvlProfile getTvlProfile() {
		return tvlProfile;
	}


	public void setTvlProfile(BeTvlProfile tvlProfile) {
		this.tvlProfile = tvlProfile;
	}


	public Timestamp getMedTestDt() {
		return medTestDt;
	}


	public void setMedTestDt(Timestamp medTestDt) {
		this.medTestDt = medTestDt;
	}


	public Integer getDoctorProfId() {
		return doctorProfId;
	}


	public void setDoctorProfId(Integer doctorProfId) {
		this.doctorProfId = doctorProfId;
	}


	public String getCntryCd() {
		return cntryCd;
	}


	public void setCntryCd(String cntryCd) {
		this.cntryCd = cntryCd;
	}


	public Integer getMedicalResult() {
		return medicalResult;
	}


	public void setMedicalResult(Integer medicalResult) {
		this.medicalResult = medicalResult;
	}


	public String getRemarks() {
		return BaseUtil.getStrUpperWithNull(remarks);
	}


	public void setRemarks(String remarks) {
		this.remarks = BaseUtil.getStrUpperWithNull(remarks);
	}


	public String getDoctorRemarks() {
		return BaseUtil.getStrUpperWithNull(doctorRemarks);
	}


	public void setDoctorRemarks(String doctorRemarks) {
		this.doctorRemarks = BaseUtil.getStrUpperWithNull(doctorRemarks);
	}


	public Integer getStatusId() {
		return statusId;
	}


	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Set<BeTvlMcCollate> getTvlMcCollates() {
		return tvlMcCollates;
	}


	public void setTvlMcCollates(Set<BeTvlMcCollate> tvlMcCollates) {
		this.tvlMcCollates = tvlMcCollates;
	}


	public BeMcProfile getMcProfile() {
		return mcProfile;
	}


	public void setMcProfile(BeMcProfile mcProfile) {
		this.mcProfile = mcProfile;
	}


	public RefStatus getStatus() {
		return status;
	}


	public void setStatus(RefStatus status) {
		this.status = status;
	}

}
