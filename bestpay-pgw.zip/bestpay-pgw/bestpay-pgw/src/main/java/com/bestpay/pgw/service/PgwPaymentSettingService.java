/**
 * 
 */
package com.bestpay.pgw.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.PgwPaymentSettingRepository;
import com.bestpay.pgw.model.PgwPaymentSetting;
import com.bestpay.pgw.util.QualifierConstants;
/**
 * @author Chaithanya Kumar
 * @since 10/07/2018
 */
@Service(QualifierConstants.PGW_PAY_SETTING_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_PAY_SETTING_SVC)
@Transactional
public class PgwPaymentSettingService extends AbstractService<PgwPaymentSetting>{

	@Autowired
	private PgwPaymentSettingRepository pgwPaySettingDao;
	
	@Override
	public GenericRepository<PgwPaymentSetting> primaryDao() {
		return pgwPaySettingDao;
	}
	
	public PgwPaymentSetting findByMerchantId(String merchantId){
		return pgwPaySettingDao.findByMerchantId(merchantId);
	}
	

}