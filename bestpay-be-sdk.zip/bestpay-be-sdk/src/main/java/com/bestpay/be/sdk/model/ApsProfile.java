package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.util.List;
 
public class ApsProfile implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String registrationNo;

	private String apsName;

	private String ownerName;

	private String ownerNationalId;

	private String ownerNationalCountryId;

	private String ownerPhoneNo;

	private String ownerEmail;

	private String ownerAddress;

	private String ownerAddress2;

	private String ownerAddress3;

	private String ownerState;

	private String ownerCity;

	private String ownerPostCode;

	private String ownerCountry;

	private String ownerNationality;

	private String picName;

	private String picNationalId;

	private String picPhoneNo;

	private String picEmail;

	private String apsBankName;

	private String apsBankAccountNo;

	private String apsBankAddress;

	private String apsState;

	private String apsCity;

	private String apsPostCode;

	private String apsNatureOfBussiness;

	private String apsType;

	private String fileName;

	private String docMgtId;

	private String refNo;

	private String docRefNo;

	private List<FileUpload> fileUploads;

	private List<FileUpload> fileUploadsLor;

	private List<FileUpload> fileUploadsForm241;

	private List<FileUpload> fileUploadsDirectorFront;

	private List<FileUpload> fileUploadsForm492;

	private List<FileUpload> fileUploadsForm242;

	private List<FileUpload> fileUploadsForm491;

	private List<FileUpload> fileUploadsForm243;

	private List<FileUpload> fileUploadsDirectorBack;
	
	private List<FileUpload> fileUploadsIcFront;

	private List<FileUpload> fileUploadsIcBack;

	private String docMgtIdLor;

	private String docMgtIdForm241;

	private String docMgtIdDirectorFront;

	private String docMgtIdForm492;

	private String docMgtIdForm242;

	private String docMgtIdForm491;

	private String docMgtIdForm243;

	private String docMgtIdDirectorBack;

	private String beneficiaryId;

	private String natureOfBusiness;

	private String merchantId;

	private String companyReferenceId;

	private String apsCountry;


	public String getRegistrationNo() {
		return registrationNo;
	}


	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}


	public String getApsName() {
		return apsName;
	}


	public void setApsName(String apsName) {
		this.apsName = apsName;
	}


	public String getOwnerName() {
		return ownerName;
	}


	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}


	public String getOwnerNationalId() {
		return ownerNationalId;
	}


	public void setOwnerNationalId(String ownerNationalId) {
		this.ownerNationalId = ownerNationalId;
	}


	public String getOwnerNationalCountryId() {
		return ownerNationalCountryId;
	}


	public void setOwnerNationalCountryId(String ownerNationalCountryId) {
		this.ownerNationalCountryId = ownerNationalCountryId;
	}


	public String getOwnerPhoneNo() {
		return ownerPhoneNo;
	}


	public void setOwnerPhoneNo(String ownerPhoneNo) {
		this.ownerPhoneNo = ownerPhoneNo;
	}


	public String getOwnerEmail() {
		return ownerEmail;
	}


	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}


	public String getOwnerAddress() {
		return ownerAddress;
	}


	public void setOwnerAddress(String ownerAddress) {
		this.ownerAddress = ownerAddress;
	}


	public String getOwnerAddress2() {
		return ownerAddress2;
	}


	public void setOwnerAddress2(String ownerAddress2) {
		this.ownerAddress2 = ownerAddress2;
	}


	public String getOwnerAddress3() {
		return ownerAddress3;
	}


	public void setOwnerAddress3(String ownerAddress3) {
		this.ownerAddress3 = ownerAddress3;
	}


	public String getOwnerState() {
		return ownerState;
	}


	public void setOwnerState(String ownerState) {
		this.ownerState = ownerState;
	}


	public String getOwnerCity() {
		return ownerCity;
	}


	public void setOwnerCity(String ownerCity) {
		this.ownerCity = ownerCity;
	}


	public String getOwnerPostCode() {
		return ownerPostCode;
	}


	public void setOwnerPostCode(String ownerPostCode) {
		this.ownerPostCode = ownerPostCode;
	}


	public String getOwnerCountry() {
		return ownerCountry;
	}


	public void setOwnerCountry(String ownerCountry) {
		this.ownerCountry = ownerCountry;
	}


	public String getOwnerNationality() {
		return ownerNationality;
	}


	public void setOwnerNationality(String ownerNationality) {
		this.ownerNationality = ownerNationality;
	}


	public String getPicName() {
		return picName;
	}


	public void setPicName(String picName) {
		this.picName = picName;
	}


	public String getPicNationalId() {
		return picNationalId;
	}


	public void setPicNationalId(String picNationalId) {
		this.picNationalId = picNationalId;
	}


	public String getPicPhoneNo() {
		return picPhoneNo;
	}


	public void setPicPhoneNo(String picPhoneNo) {
		this.picPhoneNo = picPhoneNo;
	}


	public String getPicEmail() {
		return picEmail;
	}


	public void setPicEmail(String picEmail) {
		this.picEmail = picEmail;
	}


	public String getApsBankName() {
		return apsBankName;
	}


	public void setApsBankName(String apsBankName) {
		this.apsBankName = apsBankName;
	}


	public String getApsBankAccountNo() {
		return apsBankAccountNo;
	}


	public void setApsBankAccountNo(String apsBankAccountNo) {
		this.apsBankAccountNo = apsBankAccountNo;
	}


	public String getApsBankAddress() {
		return apsBankAddress;
	}


	public void setApsBankAddress(String apsBankAddress) {
		this.apsBankAddress = apsBankAddress;
	}


	public String getApsState() {
		return apsState;
	}


	public void setApsState(String apsState) {
		this.apsState = apsState;
	}


	public String getApsCity() {
		return apsCity;
	}


	public void setApsCity(String apsCity) {
		this.apsCity = apsCity;
	}


	public String getApsPostCode() {
		return apsPostCode;
	}


	public void setApsPostCode(String apsPostCode) {
		this.apsPostCode = apsPostCode;
	}


	public String getApsNatureOfBussiness() {
		return apsNatureOfBussiness;
	}


	public void setApsNatureOfBussiness(String apsNatureOfBussiness) {
		this.apsNatureOfBussiness = apsNatureOfBussiness;
	}


	public String getApsType() {
		return apsType;
	}


	public void setApsType(String apsType) {
		this.apsType = apsType;
	}


	public String getFileName() {
		return fileName;
	}


	public void setFileName(String fileName) {
		this.fileName = fileName;
	}


	public String getDocMgtId() {
		return docMgtId;
	}


	public void setDocMgtId(String docMgtId) {
		this.docMgtId = docMgtId;
	}


	public String getRefNo() {
		return refNo;
	}


	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public List<FileUpload> getFileUploads() {
		return fileUploads;
	}


	public void setFileUploads(List<FileUpload> fileUploads) {
		this.fileUploads = fileUploads;
	}


	public List<FileUpload> getFileUploadsLor() {
		return fileUploadsLor;
	}


	public void setFileUploadsLor(List<FileUpload> fileUploadsLor) {
		this.fileUploadsLor = fileUploadsLor;
	}


	public List<FileUpload> getFileUploadsForm241() {
		return fileUploadsForm241;
	}


	public void setFileUploadsForm241(List<FileUpload> fileUploadsForm241) {
		this.fileUploadsForm241 = fileUploadsForm241;
	}


	public List<FileUpload> getFileUploadsDirectorFront() {
		return fileUploadsDirectorFront;
	}


	public void setFileUploadsDirectorFront(List<FileUpload> fileUploadsDirectorFront) {
		this.fileUploadsDirectorFront = fileUploadsDirectorFront;
	}


	public List<FileUpload> getFileUploadsForm492() {
		return fileUploadsForm492;
	}


	public void setFileUploadsForm492(List<FileUpload> fileUploadsForm492) {
		this.fileUploadsForm492 = fileUploadsForm492;
	}


	public List<FileUpload> getFileUploadsForm242() {
		return fileUploadsForm242;
	}


	public void setFileUploadsForm242(List<FileUpload> fileUploadsForm242) {
		this.fileUploadsForm242 = fileUploadsForm242;
	}


	public List<FileUpload> getFileUploadsForm491() {
		return fileUploadsForm491;
	}


	public void setFileUploadsForm491(List<FileUpload> fileUploadsForm491) {
		this.fileUploadsForm491 = fileUploadsForm491;
	}


	public List<FileUpload> getFileUploadsForm243() {
		return fileUploadsForm243;
	}


	public void setFileUploadsForm243(List<FileUpload> fileUploadsForm243) {
		this.fileUploadsForm243 = fileUploadsForm243;
	}


	public List<FileUpload> getFileUploadsDirectorBack() {
		return fileUploadsDirectorBack;
	}


	public void setFileUploadsDirectorBack(List<FileUpload> fileUploadsDirectorBack) {
		this.fileUploadsDirectorBack = fileUploadsDirectorBack;
	}


	public String getDocMgtIdLor() {
		return docMgtIdLor;
	}


	public void setDocMgtIdLor(String docMgtIdLor) {
		this.docMgtIdLor = docMgtIdLor;
	}


	public String getDocMgtIdForm241() {
		return docMgtIdForm241;
	}


	public void setDocMgtIdForm241(String docMgtIdForm241) {
		this.docMgtIdForm241 = docMgtIdForm241;
	}


	public String getDocMgtIdDirectorFront() {
		return docMgtIdDirectorFront;
	}


	public void setDocMgtIdDirectorFront(String docMgtIdDirectorFront) {
		this.docMgtIdDirectorFront = docMgtIdDirectorFront;
	}


	public String getDocMgtIdForm492() {
		return docMgtIdForm492;
	}


	public void setDocMgtIdForm492(String docMgtIdForm492) {
		this.docMgtIdForm492 = docMgtIdForm492;
	}


	public String getDocMgtIdForm242() {
		return docMgtIdForm242;
	}


	public void setDocMgtIdForm242(String docMgtIdForm242) {
		this.docMgtIdForm242 = docMgtIdForm242;
	}


	public String getDocMgtIdForm491() {
		return docMgtIdForm491;
	}


	public void setDocMgtIdForm491(String docMgtIdForm491) {
		this.docMgtIdForm491 = docMgtIdForm491;
	}


	public String getDocMgtIdForm243() {
		return docMgtIdForm243;
	}


	public void setDocMgtIdForm243(String docMgtIdForm243) {
		this.docMgtIdForm243 = docMgtIdForm243;
	}


	public String getDocMgtIdDirectorBack() {
		return docMgtIdDirectorBack;
	}


	public void setDocMgtIdDirectorBack(String docMgtIdDirectorBack) {
		this.docMgtIdDirectorBack = docMgtIdDirectorBack;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public String getBeneficiaryId() {
		return beneficiaryId;
	}


	public void setBeneficiaryId(String beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}


	public String getNatureOfBusiness() {
		return natureOfBusiness;
	}


	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getCompanyReferenceId() {
		return companyReferenceId;
	}


	public void setCompanyReferenceId(String companyReferenceId) {
		this.companyReferenceId = companyReferenceId;
	}


	public String getApsCountry() {
		return apsCountry;
	}


	public void setApsCountry(String apsCountry) {
		this.apsCountry = apsCountry;
	}


	public List<FileUpload> getFileUploadsIcFront() {
		return fileUploadsIcFront;
	}


	public void setFileUploadsIcFront(List<FileUpload> fileUploadsIcFront) {
		this.fileUploadsIcFront = fileUploadsIcFront;
	}


	public List<FileUpload> getFileUploadsIcBack() {
		return fileUploadsIcBack;
	}


	public void setFileUploadsIcBack(List<FileUpload> fileUploadsIcBack) {
		this.fileUploadsIcBack = fileUploadsIcBack;
	}
	
	
}
