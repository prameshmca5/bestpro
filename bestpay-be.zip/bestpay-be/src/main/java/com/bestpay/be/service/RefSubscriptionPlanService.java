package com.bestpay.be.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.config.ConfigConstants;
import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.RefSubscriptionPlanCustomDao;
import com.bestpay.be.dao.RefSubscriptionPlanRepository;
import com.bestpay.be.model.RefSubscriptionPlan;
import com.bestpay.be.sdk.constants.BeCacheConstants;
import com.bestpay.be.sdk.model.SubscriptionPlan;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;


@Service(QualifierConstants.REF_SUB_PLAN_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_SUB_PLAN_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
@Transactional
public class RefSubscriptionPlanService extends AbstractService<RefSubscriptionPlan> {

	@Autowired
	private RefSubscriptionPlanRepository refSubscriptionPlanRepository;

	@Autowired
	private RefSubscriptionPlanCustomDao refSubscriptionPlanCustomDao;


	@Override
	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_SUB_PLAN_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<RefSubscriptionPlan> findAll() {
		return refSubscriptionPlanRepository.findAll();
	}


	@Override
	public GenericRepository<RefSubscriptionPlan> primaryDao() {
		return refSubscriptionPlanRepository;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<RefSubscriptionPlan> findByPlanType(String planType) {
		return refSubscriptionPlanRepository.findByPlanType(planType);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<RefSubscriptionPlan> searchSubscriptionByPagination(SubscriptionPlan subscriptionPlan,
			DataTableRequest dataTableInRQ) {
		return refSubscriptionPlanCustomDao.searchSubscriptionByPagination(subscriptionPlan, dataTableInRQ);
	}
}