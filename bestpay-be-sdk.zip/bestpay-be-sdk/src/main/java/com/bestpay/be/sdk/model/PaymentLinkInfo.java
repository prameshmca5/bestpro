/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author Ramesh Pongiannan
 * @since Jun 28, 2018
 */
public class PaymentLinkInfo implements Serializable {

	private static final long serialVersionUID = 6719857272007621024L;

	private Integer traceId;

	private String merchantId;

	private String currency;

	private String channel;

	private String orderId;

	private String amount;

	private String name;

	private String mobile;

	private String email;

	private String ccEmail;

	private String description;

	private String reqhash;

	private String createId;

	private String updateId;

	private Timestamp createDt;

	private Timestamp updateDt;

	private String payMethod;

	private String bankCode;

	private String bankName;

	private String merPayUrl;

	private String merBankUrl;


	public PaymentLinkInfo() {
		// payment link info dto model
	}


	public Integer getTraceId() {
		return traceId;
	}


	public void setTraceId(Integer traceId) {
		this.traceId = traceId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public String getAmount() {
		return amount;
	}


	public void setAmount(String amount) {
		this.amount = amount;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getCcEmail() {
		return ccEmail;
	}


	public void setCcEmail(String ccEmail) {
		this.ccEmail = ccEmail;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getReqhash() {
		return reqhash;
	}


	public void setReqhash(String reqhash) {
		this.reqhash = reqhash;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getPayMethod() {
		return payMethod;
	}


	public void setPayMethod(String payMethod) {
		this.payMethod = payMethod;
	}


	public String getBankCode() {
		return bankCode;
	}


	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getMerPayUrl() {
		return merPayUrl;
	}


	public void setMerPayUrl(String merPayUrl) {
		this.merPayUrl = merPayUrl;
	}


	public String getMerBankUrl() {
		return merBankUrl;
	}


	public void setMerBankUrl(String merBankUrl) {
		this.merBankUrl = merBankUrl;
	}

}