
package com.bestpay.pgw.sdk.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "address",
    "branch",
    "branchManager",
    "branchType",
    "code",
    "country",
    "created",
    "createdBy",
    "currentDate",
    "cutoffDate",
    "cutoffDays",
    "cutoffHour",
    "email",
    "fax",
    "name",
    "phone",
    "state",
    "status",
    "type",
    "updated",
    "updatedBy"
})
public class Location {

    @JsonProperty("address")
    private Object address;
    @JsonProperty("branch")
    private String branch;
    @JsonProperty("branchManager")
    private Object branchManager;
    @JsonProperty("branchType")
    private Object branchType;
    @JsonProperty("code")
    private String code;
    @JsonProperty("country")
    private String country;
    @JsonProperty("created")
    private Integer created;
    @JsonProperty("createdBy")
    private Object createdBy;
    @JsonProperty("currentDate")
    private String currentDate;
    @JsonProperty("cutoffDate")
    private Object cutoffDate;
    @JsonProperty("cutoffDays")
    private Object cutoffDays;
    @JsonProperty("cutoffHour")
    private Object cutoffHour;
    @JsonProperty("email")
    private Object email;
    @JsonProperty("fax")
    private Object fax;
    @JsonProperty("name")
    private String name;
    @JsonProperty("phone")
    private Object phone;
    @JsonProperty("state")
    private Object state;
    @JsonProperty("status")
    private String status;
    @JsonProperty("type")
    private String type;
    @JsonProperty("updated")
    private Integer updated;
    @JsonProperty("updatedBy")
    private String updatedBy;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("address")
    public Object getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Object address) {
        this.address = address;
    }

    @JsonProperty("branch")
    public String getBranch() {
        return branch;
    }

    @JsonProperty("branch")
    public void setBranch(String branch) {
        this.branch = branch;
    }

    @JsonProperty("branchManager")
    public Object getBranchManager() {
        return branchManager;
    }

    @JsonProperty("branchManager")
    public void setBranchManager(Object branchManager) {
        this.branchManager = branchManager;
    }

    @JsonProperty("branchType")
    public Object getBranchType() {
        return branchType;
    }

    @JsonProperty("branchType")
    public void setBranchType(Object branchType) {
        this.branchType = branchType;
    }

    @JsonProperty("code")
    public String getCode() {
        return code;
    }

    @JsonProperty("code")
    public void setCode(String code) {
        this.code = code;
    }

    @JsonProperty("country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(String country) {
        this.country = country;
    }

    @JsonProperty("created")
    public Integer getCreated() {
        return created;
    }

    @JsonProperty("created")
    public void setCreated(Integer created) {
        this.created = created;
    }

    @JsonProperty("createdBy")
    public Object getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("createdBy")
    public void setCreatedBy(Object createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("currentDate")
    public String getCurrentDate() {
        return currentDate;
    }

    @JsonProperty("currentDate")
    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }

    @JsonProperty("cutoffDate")
    public Object getCutoffDate() {
        return cutoffDate;
    }

    @JsonProperty("cutoffDate")
    public void setCutoffDate(Object cutoffDate) {
        this.cutoffDate = cutoffDate;
    }

    @JsonProperty("cutoffDays")
    public Object getCutoffDays() {
        return cutoffDays;
    }

    @JsonProperty("cutoffDays")
    public void setCutoffDays(Object cutoffDays) {
        this.cutoffDays = cutoffDays;
    }

    @JsonProperty("cutoffHour")
    public Object getCutoffHour() {
        return cutoffHour;
    }

    @JsonProperty("cutoffHour")
    public void setCutoffHour(Object cutoffHour) {
        this.cutoffHour = cutoffHour;
    }

    @JsonProperty("email")
    public Object getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(Object email) {
        this.email = email;
    }

    @JsonProperty("fax")
    public Object getFax() {
        return fax;
    }

    @JsonProperty("fax")
    public void setFax(Object fax) {
        this.fax = fax;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("phone")
    public Object getPhone() {
        return phone;
    }

    @JsonProperty("phone")
    public void setPhone(Object phone) {
        this.phone = phone;
    }

    @JsonProperty("state")
    public Object getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(Object state) {
        this.state = state;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("updated")
    public Integer getUpdated() {
        return updated;
    }

    @JsonProperty("updated")
    public void setUpdated(Integer updated) {
        this.updated = updated;
    }

    @JsonProperty("updatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("updatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
