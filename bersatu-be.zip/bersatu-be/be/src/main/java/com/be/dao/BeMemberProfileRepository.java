/**
 * Copyright 2019. Bestinet Sdn Bhd
 */
package com.be.dao;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.BeMemberProfile;


/**
 * @author mohd.naem
 *
 * @since 31 March 2021
 */

@Repository
@RepositoryDefinition(domainClass = BeMemberProfile.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_MEMBER_PROFILE_DAO)
public interface BeMemberProfileRepository extends GenericRepository<BeMemberProfile> {

	@Transactional
	@Modifying
	@Query("update BeMemberProfile u set u.orgStateCd = :orgStateCd, u.orgDivisionCd = :orgDivisionCd, u.orgBranchCd = :orgBranchCd, u.transferRemarks = :transferRemarks  where u.idNo=:idNo")
	void updateTransferByMemberId(@Param("orgStateCd") String orgStateCd,@Param("orgDivisionCd") String orgDivisionCd,@Param("orgBranchCd") String orgBranchCd, @Param("transferRemarks") String transferRemarks, @Param("idNo") String idNo);
	
	@Query("select count(u) from BeMemberProfile u where u.preRegId = :preRegId")
	int totalMemberProfRecords(@Param("preRegId") Integer preRegId);
	
	@Transactional
	@Modifying
	@Query("update BeMemberProfile u set u.statusId = :statusId where u.memberId in (:memberIdList)")
	void updateStatusIdByMemberId(@Param("statusId") Integer statusId,
			@Param("memberIdList") List<Integer> memberIdList);
	
	@Query("select count(u) from BeMemberProfile u where u.idNo = :idNo and u.regExistMtdtId = 494")
	int totalMemberProfByIdNo(@Param("idNo") String idNo);

}
