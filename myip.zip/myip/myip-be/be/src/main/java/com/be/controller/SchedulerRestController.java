/**
 *
 */
package com.be.controller;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.model.BeAcctTraveller;
import com.be.model.BeConfig;
import com.be.model.BeTvl;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.Tvl;
import com.be.service.BeConfigService;
import com.be.service.BeTvlService;
import com.be.service.BeTvlTestResultService;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.MediaType;
import com.util.constants.BaseConstants;


/**
 * @author michelle.angela
 *
 */
@Lazy
@RestController
@RequestMapping(BeUrlConstants.SCHEDULER)
public class SchedulerRestController extends AbstractRestController {

	@Autowired
	BeTvlService tvlSvc;

	@Autowired
	BeTvlTestResultService tvlTestResultSvc;

	@Autowired
	BeConfigService configSvc;


	@GetMapping(value = BeUrlConstants.EXPIRED, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public int searchPaymentPaginated(HttpServletRequest request) throws IOException {

		List<BeTvl> beTvlsUpd = new ArrayList<>();
		List<BeAcctTraveller> beAcctTravellers = new ArrayList<>();
		int listCount = 0;
		try {
			String dateNow = getSQLTimestamp().toString();
			String pattern = BaseConstants.DT_YYYY_MM_DD_DASH_TIME_S;

			Tvl dto = new Tvl();
			dto.setIsActive(true);
			dto.setEmbedTraveller(true);
			dto.setEmbedMedical(true);
			List<BeTvl> beTvls = tvlSvc.searchBeTravelPagination(dto);

			if (!BaseUtil.isListNull(beTvls)) {
				BeConfig hoursValidity = configSvc.findByConfigCode("MYIP_VLDTY");
				if (BaseUtil.isObjNull(hoursValidity)) {
					throw new BeException(BeErrorCodeEnum.E400C007);
				}

				for (BeTvl beTvl : beTvls) {
					if (!beTvl.getTvlProfile().getTvlTestResults().isEmpty() && !BaseUtil.isObjNull(
							beTvl.getTvlProfile().getTvlTestResults().iterator().next().getMedTestDt())) {

						int hours = DateUtil.getDateDiffJodaTimeInHours(beTvl.getTvlProfile().getTvlTestResults()
								.iterator().next().getMedTestDt().toString(), dateNow, pattern);

						if (hours >= Integer.parseInt(hoursValidity.getConfigVal())) {
							beTvl.setIsActive(false);
							beTvlsUpd.add(beTvl);
							if (!BaseUtil.isObjNull(beTvl.getTvlProfile())
									&& !BaseUtil.isObjNull(beTvl.getTvlProfile().getAcctTraveller())
									&& beTvl.getTvlProfile().getAcctTraveller().getIsPaid()) {
								beTvl.getTvlProfile().getAcctTraveller().setIsPaid(false);
								beAcctTravellers.add(beTvl.getTvlProfile().getAcctTraveller());
							}
						}
					}
				}
				listCount = tvlSvc.bulkUpdateExpired(beTvlsUpd, beAcctTravellers).size();
			}
		} catch (Exception e) {
			throw e;
		}

		return listCount;
	}
}
