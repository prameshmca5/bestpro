package com.bestpay.pgw.util;

/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public enum ProjectEnum {

	BESTPAY("bestpay", "PGW"),;

	private final String name;
	private final String prefix;

	ProjectEnum(String name, String prefix) {
		this.name = name;
		this.prefix = prefix;
	}

	public String getName() {
		return name;
	}

	public String getPrefix() {
		return prefix;
	}

}
