package com.bestpay.web.cmn.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Channel;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;


@Controller
@RequestMapping(value = PageConstants.PAGE_CMS_CHANNEL_LST)
public class CMSChannelController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CMSChannelController.class);

	private static final String CHANNEL = "channel";

	private static final String CHANNEL_LIST_SCRIPT = "channel-list-script";

	private static final String STATUS_CHANNEL = "CHANNEL";

	private static final String STATUS_CHANNEL_LIST = "statusChannelList";

	@Autowired
	@Qualifier("cmsChannelValidator")
	private Validator cmsChannelValidator;


	@Override
	protected void bindingPreparation(WebDataBinder binder) {
		binder.setValidator(cmsChannelValidator);
		super.bindingPreparation(binder);
	}


	@GetMapping
	public ModelAndView channel(Channel channel, BindingResult result, HttpServletRequest request, HttpSession session)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMS_CHANNEL, CHANNEL, null, CHANNEL_LIST_SCRIPT);
		mav.addObject(CHANNEL, channel);
		mav.addObject(STATUS_CHANNEL_LIST, staticData.status(STATUS_CHANNEL));
		return mav;
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String searchPaginated(@ModelAttribute(CHANNEL) Channel channel, HttpServletRequest request)
			throws BeException {
		getDefaultMav(PageTemplate.TEMP_CMS_CHANNEL, CHANNEL, null, CHANNEL_LIST_SCRIPT);
		DataTableResults<Channel> tasks = getBeService().searchChannel(channel, getPaginationRequest(request, true));
		return new Gson().toJson(tasks);
	}


	@PostMapping(params = "search")
	public ModelAndView search(Channel channel, HttpServletRequest request) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMS_CHANNEL, CHANNEL, null, CHANNEL_LIST_SCRIPT);
		mav.addObject(CHANNEL, channel);
		mav.addObject(STATUS_CHANNEL_LIST, staticData.status(STATUS_CHANNEL));
		return mav;
	}


	// Reset searching channel
	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute("channel") Channel channel, BindingResult result,
			HttpServletRequest request, HttpSession session) throws BeException {

		return channel(new Channel(), result, request, session);
	}


	@PostMapping(params = "resetFormChannel")
	public ModelAndView resetFormChannel(@ModelAttribute("channel") Channel channel, BindingResult result,
			HttpServletRequest request, HttpSession session) throws BeException {

		return updateChannel(channel.getChannelId(), request, session);
	}


	@GetMapping(value = "/new")
	public ModelAndView newChannel(Channel channel, BindingResult result, HttpServletRequest request,
			HttpSession session) throws BeException {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_CMS_CHANNEL_NEW);
		Channel cmsChannel = new Channel();
		mav.addObject(CHANNEL, cmsChannel);
		mav.addObject(STATUS_CHANNEL_LIST, staticData.status(STATUS_CHANNEL));
		return mav;
	}


	@PostMapping(value = "/addChannel")
	public ModelAndView addNewChannel(@Valid @ModelAttribute("channel") Channel channel, BindingResult result,
			HttpServletRequest request, HttpSession session) throws BeException {
		ModelAndView mav;
		List<Channel> channelCode = getBeService().getChannelPublicName(channel);
		List<Channel> channelName = getBeService().getChannelName(channel);
		int channelCodeSize = channelCode.size();
		int channelNameSize = channelName.size();
		mav = newChannel(channel, result, request, session);
		if (channelCodeSize > 0 || channelNameSize > 0) {

			mav.addAllObjects(com.bstsb.util.PopupBox.error("createdError", null,
					messageService.getMessage(MessageConstants.ERROR_FIELDS_CHANNEL_PUBLIC_NAME_EXISTS)));
		} else {
			if (!result.hasErrors()) {
				boolean isUpdated = getBeService().addChannel(channel);
				LOGGER.info("Update channel {}", isUpdated);
				String msg;
				if (channel.getChannelId() != null) {
					msg = messageService.getMessage(MessageConstants.SUCC_UPDATE_CHANNEL);
				} else {
					msg = messageService.getMessage(MessageConstants.SUCC_CREATE_CHANNEL);
				}
				mav = getDefaultMav(PageTemplate.TEMP_CMS_CHANNEL, "channellist", null, CHANNEL_LIST_SCRIPT);
				channel = new Channel();
				mav.addAllObjects(PopupBox.success(CHANNEL, null, msg));
				mav.addAllObjects(PopupBox.success(null, null, msg, PageConstants.PAGE_CMS_CHANNEL_LST));
			} else {
				mav = new ModelAndView(PageTemplate.TEMP_CMS_CHANNEL_NEW);
			}
			mav.addObject(CHANNEL, channel);
			mav.addObject(STATUS_CHANNEL_LIST, staticData.status(STATUS_CHANNEL));
		}
		return mav;
	}


	@GetMapping(value = "/update/{channelId}")
	public ModelAndView updateChannel(@PathVariable("channelId") Integer channelId, HttpServletRequest request,
			HttpSession session) throws BeException {
		Channel channel = getBeService().getChannelById(channelId);
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_CMS_CHANNEL_NEW);
		mav.addObject(CHANNEL, channel);
		mav.addObject(STATUS_CHANNEL_LIST, staticData.status(STATUS_CHANNEL));
		return mav;
	}


	@GetMapping(value = "/delete/{channelId}")
	public ModelAndView deleteChannel(@PathVariable("channelId") Integer channelId, HttpServletRequest request,
			HttpSession session) throws BeException {
		boolean isDeleted = getBeService().deleteChannel(channelId);
		LOGGER.info("Delete channel {}", isDeleted);
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMS_CHANNEL, "channellist", null, CHANNEL_LIST_SCRIPT);
		mav.addAllObjects(
				PopupBox.success(CHANNEL, null, messageService.getMessage(MessageConstants.SUCC_DELETE_CHANNEL)));
		mav.addAllObjects(
				PopupBox.success(null, null, messageService.getMessage(MessageConstants.SUCC_DELETE_CHANNEL),
						PageConstants.PAGE_CMS_CHANNEL_LST));
		Channel cmsChannel = new Channel();
		mav.addObject("cmsChannel", cmsChannel);
		return mav;
	}

}
