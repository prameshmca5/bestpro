/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.core;


import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.util.StringUtils;

import com.bestpay.be.config.ConfigConstants;
import com.bestpay.be.service.MessageService;
import com.bestpay.idm.sdk.client.IdmServiceClient;
import com.bestpay.report.sdk.client.ReportServiceClient;
import com.bstsb.util.UidGenerator;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public abstract class GenericAbstract {

	public static final String HEADER_MESSAGE_ID = "X-Message-Id";

	public static final String HEADER_AUTHORIZATION = "Authorization";

	@Autowired
	protected MessageSource messageSource;

	@Autowired
	private IdmServiceClient idmService;

	@Autowired
	private ReportServiceClient reportService;

	@Autowired
	protected MessageService messageService;


	protected IdmServiceClient getIdmService(HttpServletRequest request) {
		idmService.setAuthToken(request.getHeader(HEADER_AUTHORIZATION));
		idmService.setMessageId(
				StringUtils.hasText(request.getHeader(HEADER_MESSAGE_ID)) ? request.getHeader(HEADER_MESSAGE_ID)
						: String.valueOf(UUID.randomUUID()));
		return idmService;
	}


	public ReportServiceClient getReportService() {
		reportService.setToken(messageService.getMessage(ConfigConstants.SVC_IDM_SKEY));
		reportService.setClientId(messageService.getMessage(ConfigConstants.SVC_IDM_CLIENT));
		reportService.setMessageId(UidGenerator.getMessageId());
		return reportService;
	}

}