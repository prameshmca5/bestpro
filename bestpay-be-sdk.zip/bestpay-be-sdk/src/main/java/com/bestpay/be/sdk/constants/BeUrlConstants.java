/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BeUrlConstants {

	private BeUrlConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String SERVICE_CHECK = "/serviceCheck";

	public static final String REFERENCE = "/references";

	public static final String APJ_CONFIG = REFERENCE + "/config";

	public static final String SST_BLK_TRAN = REFERENCE + "/blktran";

	public static final String REF_REF_COUNTRY = REFERENCE + "/references/getRefCountry";

	public static final String COUNTRIES = REFERENCE + "/countries";

	public static final String STATES = REFERENCE + "/states";

	public static final String STATUS = REFERENCE + "/status";

	public static final String REF_PAYMENT_TYPES = "/refPaymentTypes";

	public static final String REF_PAYMENT_TYPES_CODE = "/refPaymentCode";

	public static final String REF_PAYMENT_STATUS_CODE = "/refStatusCode";

	public static final String CITY = "/cities";

	public static final String RELATIONSHIP = "/relationship";

	public static final String GET_ALL_RELATIONSHIP = "/getAllRelationship";

	public static final String INCENTIVEREMIT_SERVICE = "/incentiveremit";

	public static final String GET_ALL_STATE = "/getAllState";

	public static final String GET_ALL_COUNTRY = "/getAllCountry";

	public static final String GET_ALL_NATIONALITY = "/getAllNationality";

	public static final String GET_ALL_NATIONALITY_CODE = "/findByNationalityCode";

	public static final String GET_ALL_NATIONALITY_DESC = "/findNationalityByDesc";

	public static final String GET_ALL_STAUS = "/getAllStatus";

	public static final String GET_ALL_CAT = "/getAllCategory";

	public static final String PROFILE = "/profiles";

	public static final String SEARCH_PAGINATION = "/search/paginated";

	public static final String TRANSACTION = "/transaction";

	public static final String TRANSACTION_PAGINATION = "/paginated";

	public static final String TOP10_TRANSLIST = "/top10Translist";

	public static final String STTLMNT_REPORT = "/settlementReport";

	public static final String BLCKLST = "/blacklist";

	public static final String CREATE = "/create";

	public static final String GENERATE = "/generate";

	public static final String DELETE = "/delete";

	public static final String UPDATE = "/update";

	public static final String TRANSACTION_REPORT = "/transactionReport";

	public static final String SETTLEMENT = "/settlement";

	public static final String SETTLEMENT_WEEKLY = "/settlementWeekly";

	public static final String SETTLEMENT_MONTHLY = "/settlementMonthly";

	public static final String SETTLEMENT_PAGINATION = "/paginated";

	public static final String TRANS_RPT_INFO = "/findTransactionReportInfo";

	public static final String MER_ACC_INFO = "/account-info";

	public static final String MERCHANT = "/merchant-list";

	public static final String MERCHANT_PAGINATION = "/paginated";

	public static final String GET_ALL_CHANNEL = "/getAllChannel";

	public static final String CHAN_SET = "/channel-setting";

	public static final String TRANSACTION_DETAILS = "/transactionDetails";

	public static final String PAY_PAGE_SET = "/payment-page-setting";

	public static final String MER_GENG_INFO = "/general-info";

	public static final String MER_FRAUD_SET = "/fraud-setting";

	public static final String GET_ALL_BANK = "/getAllBank";

	public static final String MER_ACC_SET = "/account-setting";

	public static final String BUS_CAT = "/business-category";

	public static final String RPT_SET = "/report-setting";

	public static final String MER_RESTRICTION = "/restriction";

	public static final String STTLMNT_SET = "/settlement-setting";

	public static final String PAYMENT_LINK = "/paymentLink";

	public static final String PAYMENT_LINK_PAGINATION = "/paginated";

	public static final String MER_STMNS_DETAILS = "/findSettlementsByMerchantId";

	public static final String GET_ALL_SUB_PLAN = "/getAllSubscriptionPlan";

	public static final String MER_SUBSCRIPTION_PLAN = "/subscription-plan";

	public static final String GET_ALL_FPX_RESPOND_CODE = "/getAllFpxResCode";

	public static final String SETTLEMENT_RPT_INFO = "/findSettlementReportInfo";

	public static final String ALL_MER_LIST = "/merchantList";

	public static final String ALL_MER_PAYSET_LIST = "/merchantList";

	public static final String DEACTV_MER_EXPRD_SCHEDULER = "/deActivateExpiredMerchantsScheduler";

	public static final String TRANS_SETTLELIST = "/transbysettlement";

	public static final String CHAL_LIST = "/findByMerchantId";

	public static final String SETTLEMENT_REPORT = "/findSettlementReportInfo";

	public static final String OFFLINE_PAYMENT_LINK = "https://payment.bestpay4u.my";

	public static final String TICKET = "/ticket";

	public static final String CHANNEL_PAGINATION = "/paginated";

	public static final String ADD_CHANNEL = "/addChannel";

	public static final String DEL_CHANNEL = "/deleteChannel";

	public static final String GET_CHANNEL = "/getChannel";

	public static final String GET_COUNTRY_BY_CODE = "/getCountryDesc";

	public static final String GET_STATUS_BY_CODE = "/getStatusDesc";

	public static final String TRANS_MONTHLIST = "/transListbyMonth";

	public static final String TRANS_SUCC_TODAY_LIST = "/todaysSuccessfultransList";

	public static final String TRANS_SUCC_MNTHLY_LIST = "/monthlySuccessfultransList";

	public static final String TRANS_SUCC_MNTHLY_SUM = "/getSumAndCountMonthly";

	public static final String TRANS_SUCC_TODAY_CNT = "/getCountTransDaily";

	public static final String CNT_MER_STATUS = "/getCountByMerchantStatus";

	public static final String TRANS_SUM_BILLAMT = "/getSumOfBillAmount";

	public static final String TKT_CNT_ALLSTATUS = "/getCountOfAllStatus";

	public static final String GET_CHANNEL_BYNAME = "/getChannelByName";

	public static final String SUBSCRIPTION_PAGINATION = "/subscriptionPaginated";

	public static final String ADD_SUBSCRIPTION = "/addSubscriptionPlan";

	public static final String DEL_SUBSCRIPTION = "/deleteSubscriptionPlan";

	public static final String GET_SUBSCRIPTION = "/getSubscriptionPlan";

	public static final String STATUS_PAGINATION = "/statusPaginated";

	public static final String ADD_STATUS = "/addStatus";

	public static final String GET_STATUS = "/getStatus";

	public static final String DEL_STATUS = "/deleteStatus";

	public static final String SAVE_APS_PROFILE = "/saveApsProfile";

	public static final String REMITTENCE_SETTLEMENT = "/remittenceSettlement";

	public static final String SAVE_TRXN_DOCUMENT = "/saveDocuments";

	public static final String MERCHANT_COMPANY = "/merchant-company";

	public static final String MERCHANT_COMPANY_PAGINATION = "/paginated";

	public static final String UPD_MER_COMP = "/merchantCompanyUpdate";

	public static final String MER_PID = "/merchantPid";

	public static final String PROVIDER = "/provider";

	public static final String PROVIDER_PAGINATION = "/paginated";

	public static final String UPD_BEN_BY_MERID = "/updateBenefeciaryIdByMerchantId";

	public static final String REMIT_SETTLEMENT_MONTHLY = "/remitSettlementMonthly";

	public static final String PAGINATED = "/paginated";

	public static final String PAGINATED_BY_MERCHANT_ID = "/paginatedByMerchant";

	public static final String GET_COMP_REF_BANK_DETAILS = "/getCompRefBankDetails";

	public static final String MER_COMP_BANK_DETAILS = "/merCompBankDetails";

	public static final String GET_MER_COMP_LIST = "/getMerchantCompanyList";

	public static final String GET_ALL_REF_MULTI_CHANNEL = "/getAllRefMultiChannel";

	public static final String REFFERAL_MULTI_CHANNEL = "/referralMultiChannel";

	public static final String GET_PROVIDER_LIST = "/providerList";

	public static final String ADD_PROVIDER = "/addProvider";

	public static final String DEL_PROVIDER = "/deleteProvider";

	public static final String GET_BANK_DETAILS_BY_COMPBANKID = "/getBankDetailsByCompBankId";

	public static final String SAVE_IR_PROFILE = "/saveIRProfile";

	public static final String GET_OWNERID = "/findOwnerNatId";

	public static final String REMIT_REG = "/remit-register";

	public static final String SAVE_INTER_IR_PROFILE = "/saveIRInternalProfile";

	public static final String SET_RPT_PAGINATED_BY_REMIT = "/settlementReportByRemittance";

	public static final String REMIT_SETTLEMENT_RPT_INFO = "/findRemitSettlementReportInfo";

	public static final String MAXMONEY_SERVICE = "/maxmoney";

	public static final String UPLOAD_DOCS = "/uploadDocs";

	public static final String SAVE_INTER_MM_PROFILE = "/saveMMInternalProfile";

	public static final String PAYMENT_CONFIG = "/payment-configuration";

	public static final String GET_PAYMENT_CONFIG = "/getPaymentConfig";

	public static final String GET_SSM_ID = "/findSsmId";

	public static final String GET_CHANNEL_PUBLIC_NAME = "/findChannelPublicName";

	public static final String GET_CHANNEL_NAME = "/findChannelName";

	public static final String GET_PROVIDER_PUBLIC_NAME = "/findProvPublicName";

	public static final String SEND_ACTIVATION_EMAIL = "/sendActivationEmail";

	public static final String SEND_APPROVALN_EMAIL = "/sendApprovalEmail";

	public static final String GET_REF_MULTI_CHANNEL_BY_COMPREFID = "/getRefMultiChannelByCompRefId";

	public static final String EXISTS = "/exists";
	
	public static final String ALL_MER_PAYSET_LIST_BY_COMPREFID = "/merchantListByCompRefId";
}