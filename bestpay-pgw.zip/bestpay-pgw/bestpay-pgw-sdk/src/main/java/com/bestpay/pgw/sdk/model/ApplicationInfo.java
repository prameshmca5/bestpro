package com.bestpay.pgw.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class ApplicationInfo implements Serializable {

	private static final long serialVersionUID = 9021571971908298779L;

	private String appId;

	private String appDt;

	private String companyName;

	private String appliedBy;

	private String status;

	private String transType; // REG-Registration, QAP-Quota Application

	private String statusCd;

	private String phoneNo;

	private String faxNo;

	private String applcntMobile;

	private Integer quotaApplied;

	private Integer quotaApprove;

	private String approveDt;

	private String remark;

	private String cidbApproveDt;

	private Integer cidbQuotaApprove;

	private String jtkApproveDt;

	private Integer jtkQuotaApprove;

	private String statusDesc;

	private Integer statusInd;

	private Integer attemptApply;

	private String bpsTaskId;

	private String bpsTaskStatus;

	private Integer month;

	private Integer year;

	private String operationType;

	private String claimBy;

	private String applctnDtFrom;

	private String applctnDtTo;

	private String apprveDtFrm;

	private String apprveDtTo;

	private String cmpnyRegNo;

	private String recruitmentAgent;

	private String recruitmentAgencyID;

	private String tab;


	public String getTab() {
		return tab;
	}


	public void setTab(String tab) {
		this.tab = tab;
	}


	public String getAppId() {
		return appId;
	}


	public void setAppId(String appId) {
		this.appId = appId;
	}


	public String getAppDt() {
		return appDt;
	}


	public void setAppDt(String appDt) {
		this.appDt = appDt;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public String getAppliedBy() {
		return appliedBy;
	}


	public void setAppliedBy(String appliedBy) {
		this.appliedBy = appliedBy;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getTransType() {
		return transType;
	}


	public void setTransType(String transType) {
		this.transType = transType;
	}


	public Integer getQuotaApplied() {
		return quotaApplied;
	}


	public void setQuotaApplied(Integer quotaApplied) {
		this.quotaApplied = quotaApplied;
	}


	public Integer getQuotaApprove() {
		return quotaApprove;
	}


	public void setQuotaApprove(Integer quotaApprove) {
		this.quotaApprove = quotaApprove;
	}


	public String getApproveDt() {
		return approveDt;
	}


	public void setApproveDt(String approveDt) {
		this.approveDt = approveDt;
	}


	public String getRemark() {
		return remark;
	}


	public void setRemark(String remark) {
		this.remark = remark;
	}


	public String getCidbApproveDt() {
		return cidbApproveDt;
	}


	public void setCidbApproveDt(String cidbApproveDt) {
		this.cidbApproveDt = cidbApproveDt;
	}


	public Integer getCidbQuotaApprove() {
		return cidbQuotaApprove;
	}


	public void setCidbQuotaApprove(Integer cidbQuotaApprove) {
		this.cidbQuotaApprove = cidbQuotaApprove;
	}


	public String getJtkApproveDt() {
		return jtkApproveDt;
	}


	public void setJtkApproveDt(String jtkApproveDt) {
		this.jtkApproveDt = jtkApproveDt;
	}


	public Integer getJtkQuotaApprove() {
		return jtkQuotaApprove;
	}


	public void setJtkQuotaApprove(Integer jtkQuotaApprove) {
		this.jtkQuotaApprove = jtkQuotaApprove;
	}


	public String getStatusCd() {
		return statusCd;
	}


	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}


	public String getStatusDesc() {
		return statusDesc;
	}


	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}


	public Integer getStatusInd() {
		return statusInd;
	}


	public void setStatusInd(Integer statusInd) {
		this.statusInd = statusInd;
	}


	public Integer getAttemptApply() {
		return attemptApply;
	}


	public void setAttemptApply(Integer attemptApply) {
		this.attemptApply = attemptApply;
	}


	public String getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}


	public String getFaxNo() {
		return faxNo;
	}


	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}


	public String getApplcntMobile() {
		return applcntMobile;
	}


	public void setApplcntMobile(String applcntMobile) {
		this.applcntMobile = applcntMobile;
	}


	public String getBpsTaskId() {
		return bpsTaskId;
	}


	public void setBpsTaskId(String bpsTaskId) {
		this.bpsTaskId = bpsTaskId;
	}


	public String getBpsTaskStatus() {
		return bpsTaskStatus;
	}


	public void setBpsTaskStatus(String bpsTaskStatus) {
		this.bpsTaskStatus = bpsTaskStatus;
	}


	public Integer getMonth() {
		return month;
	}


	public void setMonth(Integer month) {
		this.month = month;
	}


	public Integer getYear() {
		return year;
	}


	public void setYear(Integer year) {
		this.year = year;
	}


	public String getOperationType() {
		return operationType;
	}


	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}


	public String getClaimBy() {
		return claimBy;
	}


	public void setClaimBy(String claimBy) {
		this.claimBy = claimBy;
	}


	public String getApplctnDtFrom() {
		return applctnDtFrom;
	}


	public void setApplctnDtFrom(String applctnDtFrom) {
		this.applctnDtFrom = applctnDtFrom;
	}


	public String getApplctnDtTo() {
		return applctnDtTo;
	}


	public void setApplctnDtTo(String applctnDtTo) {
		this.applctnDtTo = applctnDtTo;
	}


	public String getApprveDtFrm() {
		return apprveDtFrm;
	}


	public void setApprveDtFrm(String apprveDtFrm) {
		this.apprveDtFrm = apprveDtFrm;
	}


	public String getApprveDtTo() {
		return apprveDtTo;
	}


	public void setApprveDtTo(String apprveDtTo) {
		this.apprveDtTo = apprveDtTo;
	}


	public String getCmpnyRegNo() {
		return cmpnyRegNo;
	}


	public void setCmpnyRegNo(String cmpnyRegNo) {
		this.cmpnyRegNo = cmpnyRegNo;
	}


	public String getRecruitmentAgent() {
		return recruitmentAgent;
	}


	public void setRecruitmentAgent(String recruitmentAgent) {
		this.recruitmentAgent = recruitmentAgent;
	}


	public String getRecruitmentAgencyID() {
		return recruitmentAgencyID;
	}


	public void setRecruitmentAgencyID(String recruitmentAgencyID) {
		this.recruitmentAgencyID = recruitmentAgencyID;
	}

}
