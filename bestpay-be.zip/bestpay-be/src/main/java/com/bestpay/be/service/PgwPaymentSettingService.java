/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwPaymentSettingCustomDao;
import com.bestpay.be.dao.PgwPaymentSettingRepository;
import com.bestpay.be.model.PgwPaymentSetting;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Afif Saman
 * @since July 13, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_PAY_SET_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_PAY_SET_SVC)
public class PgwPaymentSettingService extends AbstractService<PgwPaymentSetting> {

	@Autowired
	private PgwPaymentSettingRepository paymentSettingDao;
	
	@Autowired
	private PgwPaymentSettingCustomDao paymentSettingCustomDao;


	@Override
	public PgwPaymentSettingRepository primaryDao() {
		return paymentSettingDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwPaymentSetting findPaymentSettingMerchantId(String merchantId) {
		return paymentSettingDao.findPaymentSettingMerchantId(merchantId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwPaymentSetting> findAllMerchantList() {
		return paymentSettingDao.findAllMerchantpaymentList();
	}
	
	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwPaymentSetting> findMerchantListByCompRefId(String compRefId) {
		return paymentSettingCustomDao.findMerchantpaymentListByCompRefId(compRefId);
	}

}