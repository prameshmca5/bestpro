package com.be.controller;


import java.io.IOException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.constants.ConfigConstants;
import com.be.core.AbstractRestController;
import com.be.model.BeConfig;
import com.be.model.RefBranch;
import com.be.model.RefCity;
import com.be.model.RefCountry;
import com.be.model.RefDivision;
import com.be.model.RefDun;
import com.be.model.RefMetadata;
import com.be.model.RefParliament;
import com.be.model.RefState;
import com.be.model.RefStatus;
import com.be.sdk.constants.BeCacheConstants;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.constants.MailTemplateConstants;
import com.be.sdk.constants.ReferenceConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.MemberAddress;
import com.be.sdk.model.MemberProfile;
import com.be.sdk.model.Otp;
import com.be.sdk.model.Payment;
import com.be.sdk.model.PaymentBreakdown;
import com.be.sdk.model.PreReg;
import com.be.service.BeConfigService;
import com.be.service.BeMemberProfileService;
import com.be.service.BePaymentBreakdownService;
import com.be.service.BePaymentService;
import com.be.service.BePreRegService;
import com.be.service.RefBranchService;
import com.be.service.RefCityService;
import com.be.service.RefCountryService;
import com.be.service.RefDivisionService;
import com.be.service.RefDunService;
import com.be.service.RefMetadataService;
import com.be.service.RefParliamentService;
import com.be.service.RefStateService;
import com.be.service.RefStatusService;
import com.notify.sdk.util.MailUtil;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.MediaType;
import com.util.UidGenerator;


@RestController
@RequestMapping(BeUrlConstants.MOBILE)
public class MobileRestController extends AbstractRestController {

	@Autowired
	BeConfigService beConfigSvc;

	@Autowired
	BePaymentBreakdownService bePaymentBreakdownSvc;

	@Autowired
	RefMetadataService refMetadataSvc;

	@Autowired
	BeMemberProfileService beMemberProfileSvc;

	@Autowired
	RefStateService refStateSvc;

	@Autowired
	RefDivisionService refDivisionSvc;

	@Autowired
	RefBranchService refBranchSvc;

	@Autowired
	RefParliamentService refParliamentSvc;

	@Autowired
	RefDunService refDunSvc;

	@Autowired
	RefCityService refCitySvc;

	@Autowired
	RefCountryService refCountrySvc;

	@Autowired
	BePaymentService bePaymentSvc;

	@Autowired
	RefStatusService refStatusSvc;

	@Autowired
	BePreRegService bePreRegSvc;


	@PostMapping(value = BeUrlConstants.GEN_REG_OTP, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Otp genComplainantRegOtp(@Valid @RequestBody Otp dto, HttpServletRequest request) throws IOException {

		if (BaseUtil.isObjNull(dto)) {
			throw new BeException(BeErrorCodeEnum.E400C003);
		}

		if (BaseUtil.isObjNull(dto.getContactNo()) || BaseUtil.isObjNull(dto.getTransDt())) {
			throw new BeException(BeErrorCodeEnum.E400C006);
		}

		String actvNo = UidGenerator.generateRandomNoInStr();
		String transId = UidGenerator.getMessageId();

		String cacheKey = BeCacheConstants.CACHE_KEY_REG_OTP.concat(transId);
		Cache cache = cacheManager.getCache(BeCacheConstants.CACHE_OTP_BUCKET);

		Map<String, Object> cacheMap = new HashMap<>();
		cacheMap.put("otp", actvNo);
		cacheMap.put("transDt", dto.getTransDt());
		cache.put(cacheKey, cacheMap);

		Map<String, Object> map = new HashMap<>();
		map.put("actvNo", actvNo);

		try {
			getNotifyService(request).sendSms(dto.getContactNo(), MailUtil.convertMapToJson(map),
					MailTemplateConstants.OTP_REG);
			dto.setTransId(transId);
		} catch (Exception e) {

		}
		return dto;
	}


	@PostMapping(value = BeUrlConstants.VER_REG_OTP, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Otp verifyComplainantRegOtp(@Valid @RequestBody Otp dto, HttpServletRequest request) throws IOException {

		if (BaseUtil.isObjNull(dto)) {
			throw new BeException(BeErrorCodeEnum.E400C003);
		}

		if (BaseUtil.isObjNull(dto.getTransId()) || BaseUtil.isObjNull(dto.getTransDt())
				|| BaseUtil.isObjNull(dto.getOtp())) {
			throw new BeException(BeErrorCodeEnum.E400C006);
		}

		String cacheKey = BeCacheConstants.CACHE_KEY_REG_OTP.concat(dto.getTransId());
		Cache cache = cacheManager.getCache(BeCacheConstants.CACHE_OTP_BUCKET);

		Cache.ValueWrapper cv = cache.get(cacheKey);
		if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
			Map<String, Object> map = (Map<String, Object>) cv.get();
			String otp = BaseUtil.getStr(map.get("otp"));
			Timestamp transDt = (Timestamp) map.get("transDt");

			Integer otpValid = 0;
			BeConfig beConfig = beConfigSvc.findByConfigCode(ConfigConstants.CONFIG_OTP_VALIDITY);
			if (!BaseUtil.isObjNull(beConfig)) {
				otpValid = BaseUtil.getInt(beConfig.getConfigVal());
			}

			if (BaseUtil.isEquals(otp, dto.getOtp())
					&& DateUtil.compareDates(DateUtil.addHourMinutesSecondToDate(transDt, 0, otpValid, 0),
							dto.getTransDt()) != -1) {
				// Evict existing cachekey
				Set<String> redisKeys = redisTemplate.keys("*" + cacheKey + "*");
				Iterator<String> it = redisKeys.iterator();
				while (it.hasNext()) {
					String data = it.next();
					cache.evict(data);
				}
			} else {
				throw new BeException(BeErrorCodeEnum.I404C001);
			}
		} else {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}
		return dto;
	}


	@PostMapping(value = BeUrlConstants.PAYMENT + BeUrlConstants.BREAKDOWN)
	public List<PaymentBreakdown> searchPaymentBreakdown(@RequestBody PaymentBreakdown dto, HttpServletRequest request)
			throws IOException {

		Integer batchId = null;
		BeConfig beConfig = beConfigSvc.findByConfigCode(ConfigConstants.PAYMENT_BATCH_ID);
		if (!BaseUtil.isObjNull(beConfig)) {
			batchId = BaseUtil.getInt(beConfig.getConfigVal());
		}

		Integer pmtBreakdownMtDtId = null;
		if (!BaseUtil.isObjNull(dto.getIsDetail())) {
			RefMetadata refMtdt = new RefMetadata();
			refMtdt.setMtdtType(ReferenceConstants.MTDT_PMT_BRKDWN);
			if (dto.getIsDetail()) {
				refMtdt.setMtdtCd(ReferenceConstants.MTDT_CD_BRKDWN_DTL);
			} else {
				refMtdt.setMtdtCd(ReferenceConstants.MTDT_CD_BRKDWN_TOT);
			}

			List<RefMetadata> refMtdtList = refMetadataSvc.findMetadataByCriteria(refMtdt);
			if (!BaseUtil.isListNull(refMtdtList)) {
				pmtBreakdownMtDtId = refMtdtList.get(0).getMtdtId();
			}
		}

		dto.setBatchId(batchId);
		dto.setPmtBreakdownMtDtId(pmtBreakdownMtDtId);
		return bePaymentBreakdownSvc.searchPagination(dto, null);
	}


	@PostMapping(value = BeUrlConstants.MEMBER + BeUrlConstants.SEARCH)
	public MemberProfile searchMemberProfile(@RequestBody MemberProfile dto, HttpServletRequest request)
			throws IOException {
		// MEMBER_ID, TXN_ID, MEMBER_REF_NO, ID_NO
		MemberProfile memberProfile = beMemberProfileSvc.search(dto);
		if (!BaseUtil.isObjNull(memberProfile)) {
			memberProfile.setGenderMtdtDesc(getRefMetadataDesc(memberProfile.getGenderMtdtId()));
			memberProfile.setReligionMtdtDesc(getRefMetadataDesc(memberProfile.getReligionMtdtId()));
			memberProfile.setEthnicMtdtDesc(getRefMetadataDesc(memberProfile.getEthnicMtdtId()));
			memberProfile.setEduMtdtDesc(getRefMetadataDesc(memberProfile.getEduMtdtId()));
			memberProfile.setOccupationMtdtDesc(getRefMetadataDesc(memberProfile.getOccupationMtdtId()));
			memberProfile.setVoterRegMtdtDesc(getRefMetadataDesc(memberProfile.getVoterRegMtdtId()));
			memberProfile.setMemberCtrgyMtdtDesc(getRefMetadataDesc(memberProfile.getMemberCtrgyMtdtId()));
			memberProfile.setMemberTypeMtdtDesc(getRefMetadataDesc(memberProfile.getMemberTypeMtdtId()));

			if (!BaseUtil.isObjNull(memberProfile.getOrgStateCd())) {
				RefState obj = refStateSvc.findByStateCode(memberProfile.getOrgStateCd());
				if (!BaseUtil.isObjNull(obj)) {
					memberProfile.setOrgStateDesc(obj.getStateDesc());
				}
			}

			if (!BaseUtil.isObjNull(memberProfile.getOrgDivisionCd())) {
				RefDivision obj = refDivisionSvc.findByDivisionCd(memberProfile.getOrgDivisionCd());
				if (!BaseUtil.isObjNull(obj)) {
					memberProfile.setOrgDivisionDesc(obj.getDivisionDesc());
				}
			}

			if (!BaseUtil.isObjNull(memberProfile.getOrgBranchCd())) {
				RefBranch obj = refBranchSvc.findByBranchCd(memberProfile.getOrgBranchCd());
				if (!BaseUtil.isObjNull(obj)) {
					memberProfile.setOrgBranchDesc(obj.getBranchDesc());
				}
			}
			
			if (!BaseUtil.isObjNull(memberProfile.getSprStateCd())) {
				RefState obj = refStateSvc.findByStateCode(memberProfile.getSprStateCd());
				if (!BaseUtil.isObjNull(obj)) {
					memberProfile.setSprStateDesc(obj.getStateDesc());
				}
			}

			if (!BaseUtil.isObjNull(memberProfile.getParliamentCode())) {
				RefParliament obj = refParliamentSvc.findByParliamentCd(memberProfile.getParliamentCode());
				if (!BaseUtil.isObjNull(obj)) {
					memberProfile.setParliamentDesc(obj.getParliamentDesc());
				}
			}

			if (!BaseUtil.isObjNull(memberProfile.getDunCode())) {
				RefDun obj = refDunSvc.findByDunCd(memberProfile.getDunCode());
				if (!BaseUtil.isObjNull(obj)) {
					memberProfile.setDunDesc(obj.getDunDesc());
				}
			}

			List<MemberAddress> memberAddressList = memberProfile.getMemberAddressList();
			if (!BaseUtil.isListNull(memberAddressList)) {
				for (MemberAddress memberAddress : memberAddressList) {
					if (!BaseUtil.isObjNull(memberAddress.getCityCd())) {
						RefCity obj = refCitySvc.findByCityCode(memberAddress.getCityCd());
						if (!BaseUtil.isObjNull(obj)) {
							memberAddress.setCityDesc(obj.getCityDesc());
						}
					}

					if (!BaseUtil.isObjNull(memberAddress.getStateCd())) {
						RefState obj = refStateSvc.findByStateCode(memberAddress.getStateCd());
						if (!BaseUtil.isObjNull(obj)) {
							memberAddress.setStateDesc(obj.getStateDesc());
						}
					}

					if (!BaseUtil.isObjNull(memberAddress.getCountryCd())) {
						RefCountry obj = refCountrySvc.findByCountryCode(memberAddress.getCountryCd());
						if (!BaseUtil.isObjNull(obj)) {
							memberAddress.setCountryDesc(obj.getCntryDesc());
						}
					}
				}
			}
		}
		return memberProfile;
	}


	@PostMapping(value = BeUrlConstants.PAYMENT + BeUrlConstants.SEARCH)
	public Payment searchPayment(@RequestBody Payment dto, HttpServletRequest request) throws IOException {
		// PMT_ID, TXN_ID, PMT_REF_NO
		Payment payment = bePaymentSvc.search(dto);
		if (!BaseUtil.isObjNull(payment)) {
			RefStatus refStatus = refStatusSvc.find(payment.getStatusId());
			if (!BaseUtil.isObjNull(refStatus)) {
				payment.setStatusCd(refStatus.getStatusCd());
				payment.setStatusDesc(refStatus.getStatusDesc());
			}
		}
		return payment;
	}


	private String getRefMetadataDesc(Integer mtdtId) {
		String mtdtDesc = null;
		if (!BaseUtil.isObjNull(mtdtId)) {
			RefMetadata metadata = refMetadataSvc.find(mtdtId);
			if (!BaseUtil.isObjNull(metadata)) {
				mtdtDesc = metadata.getMtdtDesc();
			}
		}
		return mtdtDesc;
	}


	@PostMapping(value = BeUrlConstants.REGISTER + BeUrlConstants.SEARCH)
	public PreReg searchPreReg(@RequestBody PreReg dto, HttpServletRequest request) throws IOException {
		// ID_NO, PASSCODE
//		PreReg preregResp = null;
		PreReg preReg = bePreRegSvc.search(dto);
		if (!BaseUtil.isObjNull(preReg)) {
//			preregResp = new PreReg();
//			preregResp.setIdNo(preReg.getIdNo());
//			preregResp.setPasscode(preReg.getPasscode());
//			preregResp.setFullName(preReg.getFullName());
			RefStatus refStatus = refStatusSvc.find(preReg.getStatusId());
			if (!BaseUtil.isObjNull(refStatus)) {
				preReg.setStatusCd(refStatus.getStatusCd());
				preReg.setStatusDesc(refStatus.getStatusDesc());
			}
		}
		return preReg;
	}
}
