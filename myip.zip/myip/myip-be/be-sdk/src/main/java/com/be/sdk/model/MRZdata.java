/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author michelle.angela
 *
 */
public class MRZdata implements Serializable {

	private static final long serialVersionUID = 8512334271113386596L;

	private String country_code;
	
	private String card_code;
	
	private byte[] scan_image_base64;
	
	@JsonProperty("MRZ")
	private String mrz;
	
	private String country;
	
	@JsonProperty("last_name")
	private String lastname;
	
	@JsonProperty("first_name")
	private String firstname;
	
	@JsonProperty("document_no")
	private String documentNo;
	
	private String nationality;
	
	@JsonProperty("date_of_birth")
	private String dob;
	
	@JsonProperty("date_of_expiry")
	private String expiryDate;	
	
	@JsonProperty("Base64ImageString")
	private byte[] base64ImageString;
	
	@JsonProperty("Format")
	private String format;
	
	@JsonProperty("LightIndex")
	private Integer lightIndex;
	
	@JsonProperty("PageIndex")
	private Integer pageIndex;
	
	private String gender;
	
	public String getCountry_code() {
		return country_code;
	}

	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}

	public String getCard_code() {
		return card_code;
	}

	public void setCard_code(String card_code) {
		this.card_code = card_code;
	}

	public byte[] getScan_image_base64() {
		return scan_image_base64;
	}

	public void setScan_image_base64(byte[] scan_image_base64) {
		this.scan_image_base64 = scan_image_base64;
	}

	public String getMrz() {
		return mrz;
	}

	public void setMrz(String mrz) {
		this.mrz = mrz;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getDocumentNo() {
		return documentNo;
	}

	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	
	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public byte[] getBase64ImageString() {
		return base64ImageString;
	}

	public void setBase64ImageString(byte[] base64ImageString) {
		this.base64ImageString = base64ImageString;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public Integer getLightIndex() {
		return lightIndex;
	}

	public void setLightIndex(Integer lightIndex) {
		this.lightIndex = lightIndex;
	}

	public Integer getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

}
