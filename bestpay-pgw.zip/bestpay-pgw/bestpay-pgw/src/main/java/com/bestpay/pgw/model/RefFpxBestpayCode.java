/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;

/**
 * @author Atiqah Khairuddin
 * @since 21/02/2019
 */
@Entity
@Table(name="REF_FPX_BESTPAY_CODE")
public class RefFpxBestpayCode extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -3186445980890420147L;

	@Id
	@Column(name="BESTPAYCODE_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bestpayCodeId;
	
	@Column(name = "BESTPAY_CODE")
	private String bestpayCode;
	
	@Column(name = "BESTPAY_DESCRIPTION")
	private String bestpayDescription;
	
	@Column(name = "CREATE_ID")
	private String createId;
	
	@Column(name = "CREATE_DT")
	private Timestamp createDt;
	
	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;
	
	@Column(name = "UPDATE_ID")
	private String updateId;

	public int getBestpayCodeId() {
		return bestpayCodeId;
	}

	public void setBestpayCodeId(int bestpayCodeId) {
		this.bestpayCodeId = bestpayCodeId;
	}

	public String getBestpayCode() {
		return bestpayCode;
	}

	public void setBestpayCode(String bestpayCode) {
		this.bestpayCode = bestpayCode;
	}

	public String getBestpayDescription() {
		return bestpayDescription;
	}

	public void setBestpayDescription(String bestpayDescription) {
		this.bestpayDescription = bestpayDescription;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
