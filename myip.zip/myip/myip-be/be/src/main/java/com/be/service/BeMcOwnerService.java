/**
 * 
 */
package com.be.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeMcOwnerRepository;
import com.be.model.BeMcOwner;
import com.be.model.BeMcProfile;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_MC_OWNER_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_MC_OWNER_SVC)
public class BeMcOwnerService extends AbstractService<BeMcOwner> {

	@Autowired
	BeMcOwnerRepository beMcOwnerDao;
	
	@Override
	public GenericRepository<BeMcOwner> primaryDao() {
		return beMcOwnerDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}

	public Set<BeMcOwner> createUpdate(Set<BeMcOwner> set, BeMcProfile mcProfile, String userId){
		
		List<BeMcOwner> beMcOwners = new ArrayList<>();
		set.stream().forEach(owner -> {
			if(BaseUtil.isObjNull(owner.getMcOwnerId())) {
				owner.setCreateId(userId);
				owner.setMcProfile(mcProfile);
			}else {
				BeMcOwner ownerOri = find(owner.getMcOwnerId());
				owner.setMcProfile(ownerOri.getMcProfile());
				owner.setCreateId(ownerOri.getCreateId());
				owner.setCreateDt(ownerOri.getCreateDt());
			}
			owner.setUpdateId(userId);
			beMcOwners.add(owner);
		});		
		beMcOwnerDao.save(beMcOwners);
		return set;
	}
}
