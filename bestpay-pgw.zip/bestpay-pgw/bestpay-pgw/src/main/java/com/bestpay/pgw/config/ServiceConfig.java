/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.config;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bestpay.be.sdk.client.BeServiceClient;
import com.bestpay.dm.sdk.client.DmServiceClient;
import com.bestpay.idm.sdk.client.IdmServiceClient;
import com.bestpay.pgw.service.MessageService;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
@Configuration
public class ServiceConfig implements InitializingBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceConfig.class);

	@Autowired
	MessageService messageService;

	private String idmUrl;

	private int idmTimeout;

	private String dmUrl;

	private int dmTimeout;

	private String beUrl;

	private int beTimeout;


	@Bean
	public IdmServiceClient idmService() {
		return new IdmServiceClient(idmUrl, idmTimeout);
	}


	@Bean
	public DmServiceClient dmService() {
		return new DmServiceClient(dmUrl, dmTimeout);
	}


	@Bean
	public BeServiceClient apjatiService() {
		return new BeServiceClient(beUrl, beTimeout);
	}


	@Override
	public void afterPropertiesSet() throws Exception {
		idmUrl = messageService.getMessage(ConfigConstants.SVC_IDM_URL);
		idmTimeout = Integer.valueOf(messageService.getMessage(ConfigConstants.SVC_IDM_TIMEOUT));
		dmUrl = messageService.getMessage(ConfigConstants.SVC_DM_URL);
		dmTimeout = Integer.valueOf(messageService.getMessage(ConfigConstants.SVC_DM_TIMEOUT));
		beUrl = messageService.getMessage(ConfigConstants.SVC_APJ_URL);
		beTimeout = Integer.valueOf(messageService.getMessage(ConfigConstants.SVC_APJ_TIMEOUT));

		LOGGER.info(
				"\n[Integration Service :: \n\tIDM Service :: {} \t- Timeout (seconds) :: {}\n]{} \t- Timeout (seconds) :: {}\n]",
				idmUrl, idmTimeout, dmUrl, dmTimeout);
	}

}