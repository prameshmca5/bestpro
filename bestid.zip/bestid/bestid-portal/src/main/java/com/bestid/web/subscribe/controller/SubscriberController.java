/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.web.subscribe.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bestid.be.sdk.constants.FileUploadConstants;
import com.bestid.be.sdk.exception.BeException;
import com.bestid.be.sdk.model.MessageResponse;
import com.bestid.be.sdk.model.RefDocuments;
import com.bestid.be.sdk.model.SubscriberInfo;
import com.bestid.core.AbstractController;
import com.bestid.web.cmn.form.CustomMultipartFile;
import com.bestid.web.cmn.form.FileUpload;
import com.bestid.web.subscribe.form.CompanyInfoForm;
import com.bestid.web.subscribe.form.SubscriberInfoForm;
import com.bestid.web.util.WebUtil;
import com.bestid.web.util.constants.MessageConstants;
import com.bestid.web.util.constants.PageConstants;
import com.bestid.web.util.constants.PageTemplate;
import com.bestid.web.util.constants.ProjectEnum;
import com.bstsb.dm.sdk.exception.DmException;
import com.bstsb.dm.sdk.model.Documents;
import com.bstsb.idm.sdk.exception.IdmException;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.PopupBox;

/**
 * @author Suhada
 * @since Feb 26, 2019
 */
@Controller
@RequestMapping(value = PageConstants.SUBSCRIBER)
public class SubscriberController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(SubscriberController.class);
	private static final String FILENAMEJS = "subscriber";
	private static final String SUBSCRIBERINFOFORM = "subscriberInfoForm";
	private static final String ERRORCODE_RESPONSE = "errorCode Response: {} - {}";
	private static final String IDM_RESPONSE_ERROR = "IDM Response Error: {}";
	private static final String ADD_SUB = "addSub";
	public static final String IDM_EXCEPTION = "IdmException: {}";
	public static final String ERROR = "Error";
	public static final String EXCEPTION = "Exception: {}";
	private static final String DEACTIVATED_SUB = "deactivatedSub";
	private static final String GENERAL = "GENERAL";
	private static final String FILE_UPLOAD = "FileUpload" ;

	@Autowired
	@Qualifier("subscriberInfoFormValidator")
	private Validator validator;

	@Override
	protected void bindingPreparation(WebDataBinder binder) {
		binder.setValidator(validator);
		super.bindingPreparation(binder);
	}

	@GetMapping()
	public ModelAndView view(@ModelAttribute("subscriberInfoForm") SubscriberInfoForm subscriberInfoForm,
			BindingResult result) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_SUBSCRIBER_LIST, null, null, null, FILENAMEJS);

		SubscriberInfo si = dozerMapper.map(subscriberInfoForm, SubscriberInfo.class);
		List<SubscriberInfo> sif = null;

		try {
			sif = getBeService().subscriberService().subscriberList(si);

		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			String errorCode = e.getInternalErrorCode();
			LOGGER.error(ERRORCODE_RESPONSE, errorCode, e.getMessage());
			mav.addAllObjects(PopupBox.error(errorCode, e.getMessage()));
			return mav;
		} catch (Exception e) {
			LOGGER.error(IDM_RESPONSE_ERROR, e.getMessage());
			mav.addAllObjects(PopupBox.error(GENERAL, e.getMessage()));
			return mav;
		}
		mav.addObject("resultList", sif);
		mav.addObject(SUBSCRIBERINFOFORM, subscriberInfoForm);
		return mav;
	}

	@PostMapping(params = "search")
	public ModelAndView search(SubscriberInfoForm subscriberInfoForm, BindingResult result) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_SUBSCRIBER_ADD, null, null, null, FILENAMEJS);
		mav.addObject(SUBSCRIBERINFOFORM, subscriberInfoForm);
		MessageResponse mp = null;
		CompanyInfoForm companyInfo = null;

		try {
			mp = getBeService().subscriberService().searchCompany(subscriberInfoForm.getCmpnyRegNoParam());

			if (!BaseUtil.isObjNull(mp.getResponse())) {
				companyInfo = dozerMapper.map(mp.getResponse(), CompanyInfoForm.class);
				subscriberInfoForm.setCmpnyRegNo(companyInfo.getCmpnyRegNo());
				subscriberInfoForm.setCompanyInfo(companyInfo);
			} else {
				mav.addAllObjects(PopupBox.error(null, "", "No Record found"));
			}

		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			String errorCode = e.getInternalErrorCode();
			LOGGER.error(ERRORCODE_RESPONSE, errorCode, e.getMessage());
			mav.addAllObjects(PopupBox.error(errorCode, e.getMessage()));
			return mav;
		} catch (Exception e) {
			LOGGER.error(IDM_RESPONSE_ERROR, e.getMessage());
			mav.addAllObjects(PopupBox.error(GENERAL, e.getMessage()));
			return mav;
		}
		subscriberInfoForm.setIndicator("Company");
		mav.addObject(SUBSCRIBERINFOFORM, subscriberInfoForm);
		return mav;
	}

	@GetMapping(value = "/addSubscriber")
	public ModelAndView addSub(SubscriberInfoForm subscriberInfoForm, BindingResult result) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_SUBSCRIBER_ADD, null, null, null, FILENAMEJS);
		mav.addObject(SUBSCRIBERINFOFORM, subscriberInfoForm);
		return mav;
	}

	@PostMapping(params = "addSub")
	public ModelAndView addSubPost(@Validated SubscriberInfoForm subscriberInfoForm, BindingResult result,
			HttpServletRequest request, HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_SUBSCRIBER_ADD, null, null, null, FILENAMEJS);
		mav.addObject(SUBSCRIBERINFOFORM, subscriberInfoForm);
		SubscriberInfo si = new SubscriberInfo();
		if(!BaseUtil.isObjNull(subscriberInfoForm)) {
			 si = dozerMapper.map(subscriberInfoForm, SubscriberInfo.class);
		}
		SubscriberInfo siSearch = new SubscriberInfo();
		SubscriberInfo siSearchAll = new SubscriberInfo();
		List<SubscriberInfo> sif = null;
		List<SubscriberInfo> sifAll = null;
		Boolean subscriberDuplicateSystemName = Boolean.FALSE;

		try {
			
			if (!BaseUtil.isListNullZero(subscriberInfoForm.getFileUploads())
					&& subscriberInfoForm.getFileUploads().size() == 1) {

				FileUpload fu = subscriberInfoForm.getFileUploads().get(0);
				CustomMultipartFile file = fu.getFile();
				List<RefDocuments> refDocs = staticData.refDocList(FileUploadConstants.SYSLOGO1);
				if (file != null) {
					Documents doc = new Documents();
					doc.setContentType(file.getContentType());
					doc.setFilename(file.getFilename());
					doc.setDocid(refDocs.get(0).getDocId());
					doc.setLength(file.getSize());
					doc.setContent(file.getContent());
					if (!BaseUtil.isObjNull(doc.getContent()) && (doc.getContent().length != 0)
							|| (BaseUtil.isObjNull(doc.getId()) && (doc.getContent().length != 0))) {
					
							Documents newDoc = getDmService(ProjectEnum.BESTID).upload(doc);
							LOGGER.info("Profile Picture DocMgtId: {}", newDoc.getId());
							if(!BaseUtil.isObjNull(newDoc.getId())) {
								si.setSysLogo(newDoc.getId());
							}
						
					}
				}

			}

			if (BaseUtil.isEqualsCaseIgnore(si.getIndicator(), "edit")) {
				siSearch.setSubscrCd(subscriberInfoForm.getSubscrCd());
				sif = getBeService().subscriberService().subscriberList(siSearch);
				sifAll = getBeService().subscriberService().subscriberList(siSearchAll);
				if (!BaseUtil.isListNull(sif)) {
					subscriberInfoForm.setCmpnyRegNo(sif.get(0).getCompanyInfo().getCmpnyRegNo());
					si.setCmpnyRegNo(sif.get(0).getCompanyInfo().getCmpnyRegNo());
				}
				if (!BaseUtil.isListNull(sifAll)) {
					for (SubscriberInfo data : sifAll) {
						if (BaseUtil.isEqualsCaseIgnore(data.getSysName().trim(),
								subscriberInfoForm.getSysName().trim()) && !BaseUtil.isEqualsCaseIgnore(data.getSubscrCd().trim(),
										subscriberInfoForm.getSubscrCd().trim())) {
							subscriberDuplicateSystemName = Boolean.TRUE;
							mav.addAllObjects(PopupBox.error(null, "", "System Name Already Exist"));
						}
					}

				}
			}

			if (!BaseUtil.isObjNull(subscriberInfoForm) && !result.hasErrors()
					&& subscriberDuplicateSystemName.equals(Boolean.FALSE)) {
				
				
				getBeService().subscriberService().addSubscriber(si);
				if (BaseUtil.isEqualsCaseIgnore(si.getIndicator(), "edit")) {
					mav.addAllObjects(PopupBox.success(ADD_SUB, null,
							messageService.getMessage(MessageConstants.SUCC_UPDATE_SUBSCRIBER),
							PageConstants.SUBSCRIBER));
				} else {
					mav.addAllObjects(PopupBox.success(ADD_SUB, null,
							messageService.getMessage(MessageConstants.SUCC_ADD_SUBSCRIBER), PageConstants.SUBSCRIBER));
				}

			}else {
					if (!BaseUtil.isObjNull(si.getSysLogo())) {
						List<FileUpload> fileUpload = new ArrayList<>();
						List<RefDocuments> refDocLst = getRefSyslogoLst();
						for (RefDocuments refDoc : refDocLst) {
							FileUpload file = null;
							Documents docs = null;
									docs = getDmService(ProjectEnum.BESTID).getMetadata(si.getSysLogo());
									if (!BaseUtil.isObjNull(docs) && (docs.getDocid().equals(refDoc.getDocId()))) {
										file = dozerMapper.map(docs, FileUpload.class);
										CustomMultipartFile fl = new CustomMultipartFile();
										fl.setFilename(docs.getFilename());
										file.setFile(fl);
										file.setDocId(refDoc.getDocId());
										file.setDocMgtId(si.getSysLogo());
										fileUpload.add(file);
									}
								
							
						}
						subscriberInfoForm.setFileUploads(fileUpload);
					} 
				
			}
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			String errorCode = e.getInternalErrorCode();
			LOGGER.error(ERRORCODE_RESPONSE, errorCode, e.getMessage());
			mav.addAllObjects(PopupBox.error(errorCode, e.getMessage()));
			return mav;
		} catch (DmException e) {
			LOGGER.error("DmException: {}", e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
			String errorCode = e.getInternalErrorCode();
			LOGGER.error("DOM Response Error: {} - {}", errorCode, e.getMessage());
			result.rejectValue(FILE_UPLOAD, "",
					"Unable to process your request [" + errorCode + "]");
		} catch (Exception e) {
			String errorCode = null;
			result.rejectValue(FILE_UPLOAD, "",
					"Unable to process your request [" + errorCode + "]");
		}

		mav.addObject(SUBSCRIBERINFOFORM, subscriberInfoForm);
		return mav;

	}

	@PostMapping(params = "searchList")
	public ModelAndView searchList(SubscriberInfoForm subscriberInfoForm) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_SUBSCRIBER_LIST, null, null, null, FILENAMEJS);
		mav.addObject(SUBSCRIBERINFOFORM, subscriberInfoForm);
		List<SubscriberInfo> sif = null;
		SubscriberInfo si = dozerMapper.map(subscriberInfoForm, SubscriberInfo.class);

		try {
			sif = getBeService().subscriberService().subscriberList(si);

		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			String errorCode = e.getInternalErrorCode();
			LOGGER.error(ERRORCODE_RESPONSE, errorCode, e.getMessage());
			mav.addAllObjects(PopupBox.error(errorCode, e.getMessage()));
			return mav;
		} catch (Exception e) {
			LOGGER.error(IDM_RESPONSE_ERROR, e.getMessage());
			mav.addAllObjects(PopupBox.error(GENERAL, e.getMessage()));
			return mav;
		}

		mav.addObject("resultList", sif);
		mav.addObject(SUBSCRIBERINFOFORM, subscriberInfoForm);
		return mav;
	}

	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute("subscriberInfoForm") SubscriberInfoForm subscriberInfoForm,
			BindingResult result) {
		return view(new SubscriberInfoForm(), result);
	}

	@GetMapping(value = "editSub/{subscrCd}")
	public ModelAndView editSub(@PathVariable("subscrCd") String subscrCd,
			@ModelAttribute("subscriberInfoForm") SubscriberInfoForm subscriberInfoForm, BindingResult result,
			HttpServletRequest request, HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_SUBSCRIBER_ADD, null, null, null, FILENAMEJS);

		SubscriberInfo si = dozerMapper.map(subscriberInfoForm, SubscriberInfo.class);
		subscriberInfoForm.setIndicator("edit");
		List<SubscriberInfo> sif = null;
		CompanyInfoForm companyInfo = new CompanyInfoForm();

		try {

			sif = getBeService().subscriberService().subscriberList(si);
			if (!BaseUtil.isListNull(sif)) {
				companyInfo.setCmpnyName(sif.get(0).getCompanyInfo().getCmpnyName());
				companyInfo.setCmpnyOwner(sif.get(0).getCompanyInfo().getCmpnyOwner());
				companyInfo.setEmail(sif.get(0).getCompanyInfo().getEmail());
				companyInfo.setContactNo(sif.get(0).getCompanyInfo().getContactNo());
				subscriberInfoForm.setCompanyInfo(companyInfo);
				subscriberInfoForm.setSysName(sif.get(0).getSysName());
				subscriberInfoForm.setSubscrCd(sif.get(0).getSubscrCd());
				subscriberInfoForm.setSubscrType(sif.get(0).getSubscrType());
				subscriberInfoForm.setCmpnyRegNo(sif.get(0).getCompanyInfo().getCmpnyRegNo());
				
				if (!BaseUtil.isObjNull(sif.get(0).getSysLogo())) {
					List<FileUpload> fileUpload = new ArrayList<>();
					List<RefDocuments> refDocLst = getRefSyslogoLst();
					for (RefDocuments refDoc : refDocLst) {
						FileUpload file = null;
						Documents docs = null;
								docs = getDmService(ProjectEnum.BESTID).getMetadata(sif.get(0).getSysLogo());
								if (!BaseUtil.isObjNull(docs) && (docs.getDocid().equals(refDoc.getDocId()))) {
									file = dozerMapper.map(docs, FileUpload.class);
									CustomMultipartFile fl = new CustomMultipartFile();
									fl.setFilename(docs.getFilename());
									file.setFile(fl);
									file.setDocId(refDoc.getDocId());
									file.setDocMgtId(sif.get(0).getSysLogo());
									fileUpload.add(file);
								}
							
						
					}
					subscriberInfoForm.setFileUploads(fileUpload);
				} 
			}

		} catch (IdmException e) {
			LOGGER.error(IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
		} catch (BeException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			mav.addAllObjects(PopupBox.error(ADD_SUB, ERROR,
					messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
		}
		mav.addObject(SUBSCRIBERINFOFORM, subscriberInfoForm);
		return mav;
	}

	@PostMapping(params = "deactivated")
	public ModelAndView deactivated(SubscriberInfoForm subscriberInfoForm) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_SUBSCRIBER_ADD, null, null, null, FILENAMEJS);
		mav.addObject(SUBSCRIBERINFOFORM, subscriberInfoForm);
		SubscriberInfo si = dozerMapper.map(subscriberInfoForm, SubscriberInfo.class);
		Boolean subscriberDeactivated = Boolean.FALSE;

		try {
			subscriberDeactivated = getBeService().subscriberService().deactivateSubscriber(si);

			if (subscriberDeactivated.equals(Boolean.TRUE)) {
				mav.addAllObjects(PopupBox.success(DEACTIVATED_SUB, null,
						messageService.getMessage(MessageConstants.SUCC_DEACTIVATED_SUBSCRIBER),
						PageConstants.SUBSCRIBER));
			}

		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			String errorCode = e.getInternalErrorCode();
			LOGGER.error(ERRORCODE_RESPONSE, errorCode, e.getMessage());
			mav.addAllObjects(PopupBox.error(errorCode, e.getMessage()));
			return mav;
		} catch (Exception e) {
			LOGGER.error(IDM_RESPONSE_ERROR, e.getMessage());
			mav.addAllObjects(PopupBox.error(GENERAL, e.getMessage()));
			return mav;
		}

		mav.addObject(SUBSCRIBERINFOFORM, subscriberInfoForm);
		return mav;

	}
	
	@ModelAttribute("refSyslogoLst")
	public List<RefDocuments> getRefSyslogoLst() {
		List<RefDocuments> refDocs = new ArrayList<>();
		refDocs.addAll(staticData.refDocList(FileUploadConstants.SYSLOGO1));
		return refDocs;
	}

}
