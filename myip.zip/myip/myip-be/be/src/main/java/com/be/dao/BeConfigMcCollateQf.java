package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeConfigMcCollate;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;
import com.util.JsonUtil;


/**
 * @author Atiqah
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_CONFIG_MC_COLLATE_QF)
public class BeConfigMcCollateQf extends QueryFactory<BeConfigMcCollate> {

	@PersistenceContext
	private EntityManager em;


	@Override
	public Specification<BeConfigMcCollate> searchByProperty(BeConfigMcCollate t) {
		return (Root<BeConfigMcCollate> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}


	@Override
	public List<BeConfigMcCollate> searchAllByProperty(BeConfigMcCollate t) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<BeConfigMcCollate> cq = cb.createQuery(BeConfigMcCollate.class);
		Root<BeConfigMcCollate> statusRoot = cq.from(BeConfigMcCollate.class);
		List<Predicate> predicates = generateCriteria(cb, statusRoot, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			BeConfigMcCollate dto = JsonUtil.transferToObject(criteria, BeConfigMcCollate.class);

			if (!BaseUtil.isObjNull(dto.getMcCollateId())) {
				predicates.add(cb.equal(from.get("mcCollateId"), dto.getMcCollateId()));
			}
			if (!BaseUtil.isObjNull(dto.getMcCollateCd())) {
				predicates.add(cb.equal(from.get("mcCollateCd"), dto.getMcCollateCd()));
			}

			if (!BaseUtil.isObjNull(dto.getMcCollateDesc())) {
				predicates.add(cb.like(from.<String> get("mcCollateDesc"), "%" + dto.getMcCollateDesc() + "%"));
			}

			if (!BaseUtil.isObjNull(dto.getIsActive())) {
				predicates.add(cb.equal(from.get("isActive"), dto.getIsActive()));
			}

		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

}