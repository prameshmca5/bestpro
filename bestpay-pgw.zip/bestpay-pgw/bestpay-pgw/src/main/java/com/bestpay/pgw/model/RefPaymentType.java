package com.bestpay.pgw.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;

/**
 * The persistent class for the REF_PAYMENT_TYPE database table.
 * 
 * @author Zia Ur Rahman Baig
 * @since Feb 22, 2018
 */
@Entity
@Table(name = "REF_PAYMENT_TYPE")
public class RefPaymentType extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -6510355585641387606L;

	@Id
	@Column(name = "PYMT_TYPE_ID")
	private Integer id;

	@Column(name = "PYMT_CODE")
	private String paymentTypeCode;

	@Column(name = "PAYMENT_AMOUNT")
	private Double paymentAmount;

	@Column(name = "PYMT_DESC_EN")
	private Double paymentDescEn;

	@Column(name = "PYMT_TYPE")
	private String paymentType;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;

	}

	public String getPaymentTypeCode() {
		return paymentTypeCode;
	}

	public void setPaymentTypeCode(String paymentTypeCode) {
		this.paymentTypeCode = paymentTypeCode;
	}

	public Double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public Double getPaymentDescEn() {
		return paymentDescEn;
	}

	public void setPaymentDescEn(Double paymentDescEn) {
		this.paymentDescEn = paymentDescEn;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

}