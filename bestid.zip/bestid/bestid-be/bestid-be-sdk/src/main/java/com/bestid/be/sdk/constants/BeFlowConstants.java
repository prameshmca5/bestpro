/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BeFlowConstants {

	public static final String PREV_FLOW = "prevFlow";

	public static final String CURR_FLOW = "currFlow";

	public static final String NEXT_FLOW = "nextFlow";


	private BeFlowConstants() {
		throw new IllegalStateException("BeFlowConstants class");
	}
}