/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 * @author michelle.angela
 *
 */

@Entity
@Table(name = "BE_ACCT_PROFILE")
public class BeAcctProfile extends AbstractEntity implements Serializable, IQfCriteria<BeAcctProfile> {

	private static final long serialVersionUID = -6606855235977856401L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ACCT_PROF_ID")
	private Integer acctProfId;

	@Column(name = "FULL_NAME")
	private String fullName;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "CONTACT_NO")
	private String contactNo;

	@Column(name = "GENDER")
	private String gender;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH)
	@Temporal(TemporalType.DATE)
	@Column(name = "DOB")
	private Date dob;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "NATIONALITY")
	private RefCountry nationality;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PASSPORT_ID")
	private BeAcctPassport acctPassport;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BIRTH_PLACE")
	private RefCountry birthPlace;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "RESIDENT_PLACE")
	private RefCountry residentPlace;

	@Column(name = "ADDR_1")
	private String addr1;

	@Column(name = "ADDR_2")
	private String addr2;

	@Column(name = "ADDR_3")
	private String addr3;

	@Column(name = "ADDR_4")
	private String addr4;

	@Column(name = "CITY_DESC")
	private String cityDesc;

	@Column(name = "STATE_DESC")
	private String stateDesc;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNTRY_CD")
	private RefCountry country;

	@Column(name = "ZIPCODE")
	private String zipcode;

	@Column(name = "EC_NAME")
	private String emrgncyCntctName;

	@Column(name = "EC_CONTACT_NO")
	private String emrgncyCntctNo;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EC_RELATION_MTDT_ID")
	private RefMetadata ecRelationMtdt;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ACCT_TYPE_MTDT_ID")
	private RefMetadata acctTypeMtdt;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "APPS_MTDT_ID")
	private RefMetadata appsMtdt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getAcctProfId() {
		return acctProfId;
	}


	public void setAcctProfId(Integer acctProfId) {
		this.acctProfId = acctProfId;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public RefCountry getNationality() {
		return nationality;
	}


	public void setNationality(RefCountry nationality) {
		this.nationality = nationality;
	}


	public BeAcctPassport getAcctPassport() {
		return acctPassport;
	}


	public void setAcctPassport(BeAcctPassport acctPassport) {
		this.acctPassport = acctPassport;
	}


	public RefCountry getBirthPlace() {
		return birthPlace;
	}


	public void setBirthPlace(RefCountry birthPlace) {
		this.birthPlace = birthPlace;
	}


	public RefCountry getResidentPlace() {
		return residentPlace;
	}


	public void setResidentPlace(RefCountry residentPlace) {
		this.residentPlace = residentPlace;
	}


	public String getAddr1() {
		return addr1;
	}


	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}


	public String getAddr2() {
		return addr2;
	}


	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}


	public String getAddr3() {
		return addr3;
	}


	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}


	public String getAddr4() {
		return addr4;
	}


	public void setAddr4(String addr4) {
		this.addr4 = addr4;
	}


	public String getCityDesc() {
		return cityDesc;
	}


	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc;
	}


	public String getStateDesc() {
		return stateDesc;
	}


	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc;
	}


	public RefCountry getCountry() {
		return country;
	}


	public void setCountry(RefCountry country) {
		this.country = country;
	}


	public String getZipcode() {
		return zipcode;
	}


	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}


	public String getEmrgncyCntctName() {
		return emrgncyCntctName;
	}


	public void setEmrgncyCntctName(String emrgncyCntctName) {
		this.emrgncyCntctName = emrgncyCntctName;
	}


	public String getEmrgncyCntctNo() {
		return emrgncyCntctNo;
	}


	public void setEmrgncyCntctNo(String emrgncyCntctNo) {
		this.emrgncyCntctNo = emrgncyCntctNo;
	}


	public RefMetadata getEcRelationMtdt() {
		return ecRelationMtdt;
	}


	public void setEcRelationMtdt(RefMetadata ecRelationMtdt) {
		this.ecRelationMtdt = ecRelationMtdt;
	}


	public RefMetadata getAcctTypeMtdt() {
		return acctTypeMtdt;
	}


	public void setAcctTypeMtdt(RefMetadata acctTypeMtdt) {
		this.acctTypeMtdt = acctTypeMtdt;
	}


	public RefMetadata getAppsMtdt() {
		return appsMtdt;
	}


	public void setAppsMtdt(RefMetadata appsMtdt) {
		this.appsMtdt = appsMtdt;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}
}
