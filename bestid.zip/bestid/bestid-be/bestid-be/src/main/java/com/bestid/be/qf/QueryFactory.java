package com.bestid.be.qf;


import org.springframework.data.jpa.domain.Specification;


/**
 * @author Naem Othman
 * @since March 04, 2019
 */
public abstract class QueryFactory<T> {

	public abstract Specification<T> searchByProperty(T t);

}
