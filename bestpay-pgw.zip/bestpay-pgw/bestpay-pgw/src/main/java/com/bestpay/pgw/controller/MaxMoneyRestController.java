package com.bestpay.pgw.controller;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.ApsProfile;
import com.bestpay.be.sdk.model.MerchantPid;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.pgw.config.ConfigConstants;
import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwMerchantPid;
import com.bestpay.pgw.model.PgwTransaction;
import com.bestpay.pgw.model.PgwTransactionHistory;
import com.bestpay.pgw.model.RefFpxResponseCode;
import com.bestpay.pgw.sdk.constants.BestpayErrorCodeEnum;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.exception.PgwException;
import com.bestpay.pgw.sdk.model.BankList;
import com.bestpay.pgw.sdk.model.BeneficiaryAccount;
import com.bestpay.pgw.sdk.model.BeneficiaryDetail;
import com.bestpay.pgw.sdk.model.CustomerDetail;
import com.bestpay.pgw.sdk.model.KYCStatusResponse;
import com.bestpay.pgw.sdk.model.Location;
import com.bestpay.pgw.sdk.model.MMResponse;
import com.bestpay.pgw.sdk.model.OrderDetails;
import com.bestpay.pgw.sdk.model.PidDetail;
import com.bestpay.pgw.sdk.model.RemittanceStatusDto;
import com.bestpay.pgw.sdk.model.SourceOfIncome;
import com.bestpay.pgw.sdk.model.TransferRate;
import com.bestpay.pgw.service.PgwMerchantPidService;
import com.bestpay.pgw.service.PgwTransactionHistoryService;
import com.bestpay.pgw.service.PgwTransactionService;
import com.bestpay.pgw.service.RefFpxResponseCodeService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@RestController
@RequestMapping(PgwUrlConstants.MAXMONEY_SERVICE)
public class MaxMoneyRestController extends AbstractRestController {

	private static final Logger logger = LoggerFactory.getLogger(MaxMoneyRestController.class);

	@Autowired
	protected RefFpxResponseCodeService refFpxResponseCodeService;

	@Autowired
	protected PgwTransactionService pgwTransactionService;

	@Autowired
	protected PgwMerchantPidService pgwMerchantPidService;

	@Autowired
	public PgwTransactionHistoryService transHistoryService;


	@PostMapping(value = "/getSessionWithPID")
	public String getSessionWithPID(String pid) {
		String sessionId = null;
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_CREATE_PID_SESSIONS);

			HttpPost request = new HttpPost(sbUrl.toString());

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("maxMoneyId", pid));

			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);

			if (response.getStatusLine().getStatusCode() == 200 || response.getStatusLine().getStatusCode() == 201) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					BufferedReader rd = new BufferedReader(
							new InputStreamReader(response.getEntity().getContent()));
					StringBuilder jsonString = new StringBuilder();
					String line = "";
					while ((line = rd.readLine()) != null) {
						jsonString.append(line);
					}
					JSONObject jsonObject = new JSONObject(jsonString.toString());
					sessionId = (String) jsonObject.get("session");
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("getSessionWithPID Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
				}
			}

		} catch (UnsupportedEncodingException e) {
			logger.info("getSessionWithPID UnsupportedEncodingException: {}", e.getMessage());
			throw new PgwException(BestpayErrorCodeEnum.BP00011, new String[] {});
		} catch (ClientProtocolException e) {
			logger.info("getSessionWithPID ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("getSessionWithPID JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("getSessionWithPIDJsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("getSessionWithPID IOException: {}", e.getMessage());
		}

		return sessionId;
	}


	/** CUSTOMER REGISTRATION **/
	@PostMapping(value = "/customerRegistration")
	public CustomerDetail customerRegistration(ApsProfile apsProfile) {
		CustomerDetail customerDetail = null;
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_CUSTOMER);

			HttpPost request = new HttpPost(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					messageService.getMessage(ConfigConstants.MAX_MONEY_DEFAULT_API_KEY));

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_IDTYPE, "NRIC"));
			params.add(
					new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_IDNO, apsProfile.getOwnerNationalId()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_CUSTOMERNAME,
					apsProfile.getOwnerName()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_EMAIL, apsProfile.getOwnerEmail()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_MOBILE, apsProfile.getOwnerPhoneNo()));
			params.add(
					new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_ADDRESS, apsProfile.getOwnerAddress()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_CITY, apsProfile.getOwnerCity()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_STATE, apsProfile.getOwnerState()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_POSTALCODE,
					apsProfile.getOwnerPostCode()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_COUNTRY, "Malaysia"));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_NATIONALITY, "Malaysian"));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_COMPANYNAME, apsProfile.getApsName()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_NATUREOFBUSINESS,
					apsProfile.getNatureOfBusiness()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_COMPANYTYPE, apsProfile.getApsType()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_CONTACTPERSON,
					apsProfile.getPicName()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_BENEFICIARYID,
					apsProfile.getBeneficiaryId()));
			params.add(new BasicNameValuePair("type", "SME"));
			params.add(new BasicNameValuePair("registeredThrough", "Agent"));

			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					customerDetail = objectMapper.readValue(instream, CustomerDetail.class);
					instream.close();
				}
			} else {
				customerDetail = new CustomerDetail();
				customerDetail.setIdNo(apsProfile.getOwnerNationalId());

				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("customerRegistration Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
					customerDetail.setResponseCode(mmResponse.getCode());
					customerDetail
							.setDescriptions(mmResponse.getMessage() + "(" + mmResponse.getDescription() + ")");
				} else {
					customerDetail.setResponseCode(String.valueOf(response.getStatusLine().getStatusCode()));
					customerDetail.setDescriptions(response.getStatusLine().getReasonPhrase());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("customerRegistration UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("customerRegistration ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("customerRegistration JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("customerRegistration JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("customerRegistration IOException: {}", e.getMessage());
		}

		return customerDetail;
	}


	@PostMapping(value = "/createBeneficiary")
	public BeneficiaryDetail createBeneficiary(String name, String address, String country, String relationship,
			String mobile, String email, String customerName) {
		BeneficiaryDetail beneficiaryDetail = null;
		MMResponse mmResponse = null;

		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_CREATE_BENEFICIARY);

			HttpPost request = new HttpPost(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					messageService.getMessage(ConfigConstants.MAX_MONEY_DEFAULT_API_KEY));

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("name", name));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_ADDRESS, address));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_COUNTRY, country));
			params.add(new BasicNameValuePair("relationship", relationship));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_MOBILE, mobile));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_EMAIL, email));
			params.add(new BasicNameValuePair("orderPurpose", "Business"));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_CUSTOMERNAME, customerName));

			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					beneficiaryDetail = objectMapper.readValue(instream, BeneficiaryDetail.class);
					instream.close();
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("createBeneficiary Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("createBeneficiary UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("createBeneficiary ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("createBeneficiary JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("createBeneficiary JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("createBeneficiary IOException: {}", e.getMessage());
		}
		return beneficiaryDetail;
	}


	@GetMapping(value = "/getBankList")
	public List<Location> getBankList() {
		List<Location> listLocation = null;
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append("/locations?status=active&country=Indonesia&type=BANK");

			HttpGet request = new HttpGet(sbUrl.toString());

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					BankList bankList = objectMapper.readValue(instream, BankList.class);
					listLocation = bankList.getLocations();
					instream.close();
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("getBankList Response {}", mmResponse.getCode() + " : " + mmResponse.getMessage()
							+ " : " + mmResponse.getDescription());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("getBankList UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("getBankList ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("getBankList JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("getBankList JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("getBankList IOException: {}", e.getMessage());
		}
		return listLocation;
	}


	@PostMapping(value = "/createBeneficiaryAccount")
	public BeneficiaryAccount createBeneficiaryAccount(String beneficiaryId, String acctNo, String acctName,
			String name, String branch, String location, String country, String bankName) {
		BeneficiaryAccount beneficiaryAcc = null;
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append("/beneficiaries/" + beneficiaryId + "/accounts");

			HttpPost request = new HttpPost(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					messageService.getMessage(ConfigConstants.MAX_MONEY_DEFAULT_API_KEY));

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("acctNo", acctNo));
			params.add(new BasicNameValuePair("acctName", acctName));
			params.add(new BasicNameValuePair("name", name));
			params.add(new BasicNameValuePair("branch", branch));
			params.add(new BasicNameValuePair("location", location));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_COUNTRY, country));
			params.add(new BasicNameValuePair("bankName", bankName));
			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					beneficiaryAcc = objectMapper.readValue(instream, BeneficiaryAccount.class);
					instream.close();
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("createBeneficiaryAccount Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("createBeneficiaryAccount UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("createBeneficiaryAccount ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("createBeneficiaryAccount JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("createBeneficiaryAccount JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("createBeneficiaryAccount IOException: {}", e.getMessage());
		}
		return beneficiaryAcc;
	}


	@PostMapping(value = "/updateCustomer")
	public CustomerDetail updateCustomer(com.bestpay.pgw.sdk.model.ApsProfile apsProfile) {
		CustomerDetail customerDetail = null;
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_CUSTOMER + "/" + apsProfile.getOwnerNationalId());

			HttpPut request = new HttpPut(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					messageService.getMessage(ConfigConstants.MAX_MONEY_DEFAULT_API_KEY));

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_CUSTOMERNAME,
					apsProfile.getOwnerName()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_EMAIL, apsProfile.getOwnerEmail()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_MOBILE, apsProfile.getOwnerPhoneNo()));
			params.add(
					new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_ADDRESS, apsProfile.getOwnerAddress()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_CITY, apsProfile.getOwnerCity()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_STATE, apsProfile.getOwnerState()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_POSTALCODE,
					apsProfile.getOwnerPostCode()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_COMPANYNAME, apsProfile.getApsName()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_NATUREOFBUSINESS,
					apsProfile.getNatureOfBusiness()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_COMPANYTYPE, apsProfile.getApsType()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_CONTACTPERSON,
					apsProfile.getPicName()));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_BENEFICIARYID,
					apsProfile.getBeneficiaryId()));

			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					customerDetail = objectMapper.readValue(instream, CustomerDetail.class);
					instream.close();
				}
			} else {
				customerDetail = new CustomerDetail();
				customerDetail.setIdNo(apsProfile.getOwnerNationalId());

				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("updateCustomer Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
					customerDetail.setResponseCode(mmResponse.getCode());
					customerDetail
							.setDescriptions(mmResponse.getMessage() + "(" + mmResponse.getDescription() + ")");
				} else {
					customerDetail.setResponseCode(String.valueOf(response.getStatusLine().getStatusCode()));
					customerDetail.setDescriptions(response.getStatusLine().getReasonPhrase());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("updateCustomer UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("updateCustomer ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("updateCustomer JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("updateCustomer JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("updateCustomer IOException: {}", e.getMessage());
		}
		return customerDetail;
	}


	@PostMapping(value = PgwUrlConstants.UPLOAD_DOCS, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public CustomerDetail uploadDocs(@RequestBody com.bestpay.pgw.sdk.model.ApsProfile apsProfile,
			HttpServletRequest req, HttpServletResponse res) {
		CustomerDetail customerDetail = null;
		MMResponse mmResponse = null;
		try {

			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_CUSTOMER + "/" + apsProfile.getOwnerNationalId());

			HttpPut request = new HttpPut(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					messageService.getMessage(ConfigConstants.MAX_MONEY_DEFAULT_API_KEY));

			MultipartEntityBuilder builder = MultipartEntityBuilder.create();
			builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
			addOwnerSupportingDocs(builder, apsProfile);
			addCompSupportingDocs(builder, apsProfile);

			HttpEntity entityBuilder = builder.build();
			request.setEntity(entityBuilder);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					customerDetail = objectMapper.readValue(instream, CustomerDetail.class);
					instream.close();
				}
			} else {
				customerDetail = new CustomerDetail();
				customerDetail.setIdNo(apsProfile.getOwnerNationalId());

				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("uploadDocs Response {}", mmResponse.getCode() + " : " + mmResponse.getMessage()
							+ " : " + mmResponse.getDescription());
					customerDetail.setResponseCode(mmResponse.getCode());
					customerDetail
							.setDescriptions(mmResponse.getMessage() + "(" + mmResponse.getDescription() + ")");
				} else {
					customerDetail.setResponseCode(String.valueOf(response.getStatusLine().getStatusCode()));
					customerDetail.setDescriptions(response.getStatusLine().getReasonPhrase());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("uploadDocs UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("uploadDocs ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("uploadDocs JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("uploadDocs JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("uploadDocs IOException: {}", e.getMessage());
		}
		return customerDetail;
	}


	private void addOwnerSupportingDocs(MultipartEntityBuilder builder,
			com.bestpay.pgw.sdk.model.ApsProfile apsProfile) throws IOException {
		String serverPath = messageService.getMessage(ConfigConstants.MAX_MONEY_TEMP_UPLOAD_PATH);
		if (apsProfile.getFileUploadsIcFront().get(0) != null
				&& apsProfile.getFileUploadsIcFront().get(0).getFile() != null
				&& apsProfile.getFileUploadsIcFront().get(0).getFile().getContent() != null) {
			File icFront = getFile(apsProfile.getFileUploadsIcFront().get(0).getFile().getContent(),
					serverPath + "icFront.png");
			builder.addBinaryBody("front", icFront);
		}

		if (apsProfile.getFileUploadsIcBack().get(0) != null
				&& apsProfile.getFileUploadsIcBack().get(0).getFile() != null
				&& apsProfile.getFileUploadsIcBack().get(0).getFile().getContent() != null) {
			File icBack = getFile(apsProfile.getFileUploadsIcBack().get(0).getFile().getContent(),
					serverPath + "icBack.png");
			builder.addBinaryBody("back", icBack);
		}
		if (apsProfile.getFileUploadsDirectorFront().get(0) != null
				&& apsProfile.getFileUploadsDirectorFront().get(0).getFile() != null
				&& apsProfile.getFileUploadsDirectorFront().get(0).getFile().getContent() != null) {
			File directorIDFront = getFile(apsProfile.getFileUploadsDirectorFront().get(0).getFile().getContent(),
					serverPath + "directorIDFront.png");
			builder.addBinaryBody("directorIDFront", directorIDFront);
		}
		if (apsProfile.getFileUploadsDirectorBack().get(0) != null
				&& apsProfile.getFileUploadsDirectorBack().get(0).getFile() != null
				&& apsProfile.getFileUploadsDirectorBack().get(0).getFile().getContent() != null) {
			File directorIDBack = getFile(apsProfile.getFileUploadsDirectorBack().get(0).getFile().getContent(),
					serverPath + "directorIDBack.png");
			builder.addBinaryBody("directorIDBack", directorIDBack);
		}
	}


	private void addCompSupportingDocs(MultipartEntityBuilder builder, com.bestpay.pgw.sdk.model.ApsProfile apsProfile)
			throws IOException {
		String serverPath = messageService.getMessage(ConfigConstants.MAX_MONEY_TEMP_UPLOAD_PATH);

		if (apsProfile.getFileUploadsLor().get(0) != null && apsProfile.getFileUploadsLor().get(0).getFile() != null
				&& apsProfile.getFileUploadsLor().get(0).getFile().getContent() != null) {
			File lor = getFile(apsProfile.getFileUploadsLor().get(0).getFile().getContent(), serverPath + "lor.png");
			builder.addBinaryBody("lor", lor);
		}
		if (apsProfile.getFileUploadsForm241().get(0) != null
				&& apsProfile.getFileUploadsForm241().get(0).getFile() != null
				&& apsProfile.getFileUploadsForm241().get(0).getFile().getContent() != null) {
			File form241 = getFile(apsProfile.getFileUploadsForm241().get(0).getFile().getContent(),
					serverPath + "form24_1.png");
			builder.addBinaryBody("form24_1", form241);
		}
		if (apsProfile.getFileUploadsForm242().get(0) != null
				&& apsProfile.getFileUploadsForm242().get(0).getFile() != null
				&& apsProfile.getFileUploadsForm242().get(0).getFile().getContent() != null) {
			File form242 = getFile(apsProfile.getFileUploadsForm242().get(0).getFile().getContent(),
					serverPath + "form24_2.png");
			builder.addBinaryBody("form24_2", form242);
		}
		if (apsProfile.getFileUploadsForm243().get(0) != null
				&& apsProfile.getFileUploadsForm243().get(0).getFile() != null
				&& apsProfile.getFileUploadsForm243().get(0).getFile().getContent() != null) {
			File form243 = getFile(apsProfile.getFileUploadsForm243().get(0).getFile().getContent(),
					serverPath + "form24_3.png");
			builder.addBinaryBody("form24_3", form243);
		}
		if (apsProfile.getFileUploadsForm491().get(0) != null
				&& apsProfile.getFileUploadsForm491().get(0).getFile() != null
				&& apsProfile.getFileUploadsForm491().get(0).getFile().getContent() != null) {
			File form491 = getFile(apsProfile.getFileUploadsForm491().get(0).getFile().getContent(),
					serverPath + "form49_1.png");
			builder.addBinaryBody("form49_1", form491);
		}
		if (apsProfile.getFileUploadsForm492().get(0) != null
				&& apsProfile.getFileUploadsForm492().get(0).getFile() != null
				&& apsProfile.getFileUploadsForm492().get(0).getFile().getContent() != null) {
			File form492 = getFile(apsProfile.getFileUploadsForm492().get(0).getFile().getContent(),
					serverPath + "form49_2.png");
			builder.addBinaryBody("form49_2", form492);
		}
	}


	@PostMapping(value = PgwUrlConstants.APPROVE_CUSTOMER, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MMResponse approveCustomer(@RequestBody String idNo, HttpServletRequest req, HttpServletResponse res) {
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_CUSTOMER + "/" + idNo + "/approve");

			HttpPost request = new HttpPost(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					messageService.getMessage(ConfigConstants.MAX_MONEY_DEFAULT_API_KEY));

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() != 204) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("approveCustomer Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
				}
			} else {
				mmResponse = new MMResponse();
				mmResponse.setCode("204");
				mmResponse.setMessage("Customer Approved");
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("approveCustomer UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("approveCustomer ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("approveCustomer JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("approveCustomer JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("approveCustomer IOException: {}", e.getMessage());
		}
		return mmResponse;
	}


	@GetMapping(value = PgwUrlConstants.VALIDATE_CUSTOMER, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MMResponse validateCustomer(@RequestParam String idNo, HttpServletRequest req, HttpServletResponse res) {
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_CUSTOMER + "/" + idNo + "/validate");

			HttpPost request = new HttpPost(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					messageService.getMessage(ConfigConstants.MAX_MONEY_DEFAULT_API_KEY));

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("url", "https://maxmoney.com"));
			params.add(new BasicNameValuePair("status", "Validated"));

			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() != 204) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("validateCustomer Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
				}
			} else {
				mmResponse = new MMResponse();
				mmResponse.setCode("204");
				mmResponse.setMessage("Customer Validated");
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("validateCustomer UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("validateCustomer ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("validateCustomer JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("validateCustomer JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("validateCustomer IOException: {}", e.getMessage());
		}
		return mmResponse;
	}


	@GetMapping(value = PgwUrlConstants.CREATE_USER, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public CustomerDetail createUser(@RequestParam String idNo, HttpServletRequest req, HttpServletResponse res) {
		CustomerDetail customerDetail = null;
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_CUSTOMER + "/" + idNo + "/convert-by-agent");

			HttpPost request = new HttpPost(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					messageService.getMessage(ConfigConstants.MAX_MONEY_DEFAULT_API_KEY));

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200 || response.getStatusLine().getStatusCode() == 201) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					customerDetail = objectMapper.readValue(instream, CustomerDetail.class);
					instream.close();
				}
			} else {
				customerDetail = new CustomerDetail();
				customerDetail.setIdNo(idNo);

				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("createUser Response {}", mmResponse.getCode() + " : " + mmResponse.getMessage()
							+ " : " + mmResponse.getDescription());
					customerDetail.setResponseCode(mmResponse.getCode());
					customerDetail
							.setDescriptions(mmResponse.getMessage() + "(" + mmResponse.getDescription() + ")");
				} else {
					customerDetail.setResponseCode(String.valueOf(response.getStatusLine().getStatusCode()));
					customerDetail.setDescriptions(response.getStatusLine().getReasonPhrase());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("createUser UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("createUser ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("createUser JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("createUser JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("createUser IOException: {}", e.getMessage());
		}
		return customerDetail;
	}


	/** TRANSACTION ORDER **/
	@GetMapping(value = "/getPidByIdNo")
	public PidDetail getPidByIdNo(String idNo) {
		PidDetail pidDetail = null;
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append("users/" + idNo + "/get-pid");

			HttpPost request = new HttpPost(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					messageService.getMessage(ConfigConstants.MAX_MONEY_DEFAULT_API_KEY));

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					pidDetail = objectMapper.readValue(instream, PidDetail.class);
					instream.close();
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("getPidByIdNo Response {}", mmResponse.getCode() + " : " + mmResponse.getMessage()
							+ " : " + mmResponse.getDescription());
				} else {
					throw new PgwException(BestpayErrorCodeEnum.BP00032, new String[] {});
				}
				throw new PgwException(BestpayErrorCodeEnum.BP00011, new String[] {});
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("getPidByIdNo UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("getPidByIdNo ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("getPidByIdNo JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("getPidByIdNo JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("getPidByIdNo IOException: {}", e.getMessage());
		}
		return pidDetail;
	}


	@PostMapping(value = PgwUrlConstants.CHKORDER_STATUS_CHK, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public RemittanceStatusDto getOrderStatus(@RequestBody @Valid RemittanceStatusDto remitdto) {
		String status = null;
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_ORDER + "/" + remitdto.getOrderId());

			HttpGet request = new HttpGet(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY, getSessionWithPID(remitdto.getpId()));

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					BufferedReader rd = new BufferedReader(
							new InputStreamReader(response.getEntity().getContent()));
					StringBuilder jsonString = new StringBuilder();
					String line = "";
					while ((line = rd.readLine()) != null) {
						jsonString.append(line);
					}
					JSONObject jsonObject = new JSONObject(jsonString.toString());
					status = (String) jsonObject.get("status");
					RefFpxResponseCode refFpxResponseCode = refFpxResponseCodeService.findByMaxmoneyDesc(status);
					remitdto.setStatusCode(refFpxResponseCode.getRespCode());
					remitdto.setErrorCode(refFpxResponseCode.getFpxCode());
					remitdto.setOrderDetails(status);
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("getOrderStatus Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("getOrderStatus UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("getOrderStatus ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("getOrderStatus JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("getOrderStatus JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("getOrderStatus IOException: {}", e.getMessage());
		}
		return remitdto;
	}


	@GetMapping(value = PgwUrlConstants.GET_MAXMONEY_RATE, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public TransferRate getTransferRate(@RequestParam(value = "currencyCode", required = true) String currencyCode) {
		TransferRate transferRate = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_TRANSFER_RATE + "/" + currencyCode);

			HttpGet request = new HttpGet(sbUrl.toString());
			HttpClient httpClient = HttpClientBuilder.create().build();

			HttpResponse response = httpClient.execute(request);
			HttpEntity entity = response.getEntity();
			if (entity != null) {
				InputStream instream = entity.getContent();
				transferRate = objectMapper.readValue(instream, TransferRate.class);
				instream.close();
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("getTransferRate UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("getTransferRate ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("getTransferRate JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("getTransferRate JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("getTransferRate IOException: {}", e.getMessage());
		}

		return transferRate;
	}


	@GetMapping(value = "/getSourceOfIncome")
	public List<SourceOfIncome> getSourceOfIncome(String pid) {
		List<SourceOfIncome> listSourceOfIncome = null;
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_SOURCE_INCOME);

			HttpGet request = new HttpGet(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY,
					messageService.getMessage(ConfigConstants.MAX_MONEY_DEFAULT_API_KEY));
			HttpClient httpClient = HttpClientBuilder.create().build();

			HttpResponse response = httpClient.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					listSourceOfIncome = getListSourceOfIncome(response);
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("getSourceOfIncome Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("getSourceOfIncome UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("getSourceOfIncome ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("getSourceOfIncome JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("getSourceOfIncome JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("getSourceOfIncome IOException: {}", e.getMessage());
		}
		return listSourceOfIncome;
	}


	private List<SourceOfIncome> getListSourceOfIncome(HttpResponse response) throws IOException {
		List<SourceOfIncome> listSourceOfIncome = new ArrayList<>();
		BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

		StringBuilder jsonString = new StringBuilder();
		String line = "";
		while ((line = rd.readLine()) != null) {
			jsonString.append(line);
		}
		String[] parts = jsonString.toString().split(",");
		for (String r : parts) {
			String id = StringUtils.substringAfter(r, ":").trim().replace("{", "").replace("}", "").replace("\"",
					"");
			String detail = StringUtils.substringBefore(r, ":").trim().replace("{", "").replace("}", "")
					.replace("\"", "");

			SourceOfIncome income = new SourceOfIncome();
			income.setId(id);
			income.setDetail(detail);
			listSourceOfIncome.add(income);
		}
		return listSourceOfIncome;
	}


	@PostMapping(value = PgwUrlConstants.GET_MAXMONEY_PAYLOAD, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public OrderDetails requestPayload(@RequestBody OrderDetails orderDetails) {
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_ORDER);

			HttpPost httpPost = new HttpPost(sbUrl.toString());
			httpPost.addHeader(ConfigConstants.MAX_MONEY_API_KEY, getSessionWithPID(orderDetails.getPid()));

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("ccy", orderDetails.getCurrencyCode()));
			params.add(new BasicNameValuePair("fee", String.valueOf(orderDetails.getFee())));
			params.add(new BasicNameValuePair("from", String.valueOf(orderDetails.getAmount())));
			params.add(new BasicNameValuePair("product", "omor"));
			params.add(new BasicNameValuePair("channelType", "Bestinet"));

			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			httpPost.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(httpPost);
			if (response.getStatusLine().getStatusCode() == 201) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					orderDetails = objectMapper.readValue(instream, OrderDetails.class);
					instream.close();
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("requestPayload Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
					throw new PgwException(BestpayErrorCodeEnum.BP00001, new String[] {});
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("requestPayload UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("requestPayload ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("requestPayload JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("requestPayload JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("requestPayload IOException: {}", e.getMessage());
		}
		return orderDetails;
	}


	@PostMapping(value = PgwUrlConstants.GET_BENFI_DETAILS, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public OrderDetails addBeneficiaryToOrder(@RequestBody OrderDetails orderDetails) {
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_ORDER + "/" + orderDetails.getId());

			HttpPut request = new HttpPut(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY, getSessionWithPID(orderDetails.getPid()));

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("beneficiary", orderDetails.getBeneficiaryId()));
			params.add(new BasicNameValuePair("beneficiaryBankAccount", "1"));
			params.add(new BasicNameValuePair("beneficiaryRealTime", "true"));
			// TO REVISE BY RAMESH. NEED TO GET THE BANK LOCATION FROM THE DATABASE
			params.add(new BasicNameValuePair("location", messageService.getMessage(ConfigConstants.MAX_MONEY_BANK_LOCATION)));

			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					orderDetails = objectMapper.readValue(instream, OrderDetails.class);
					instream.close();
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("addBeneficiaryToOrder Response {}", mmResponse.getCode() + " : "
							+ mmResponse.getMessage() + " : " + mmResponse.getDescription());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("addBeneficiaryToOrder UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("addBeneficiaryToOrder ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("addBeneficiaryToOrder JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("addBeneficiaryToOrder JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("addBeneficiaryToOrder IOException: {}", e.getMessage());
		}
		return orderDetails;
	}


	@PostMapping(value = "/submitOrder")
	public OrderDetails submitOrder(String pid, String beneficiaryId, String orderId) {
		OrderDetails orderDetails = null;
		MMResponse mmResponse = null;
		String sessionId = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_ORDER + "/" + orderId + "/submit");
			sessionId = getSessionWithPID(pid);

			HttpPost request = new HttpPost(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY, sessionId);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					orderDetails = objectMapper.readValue(instream, OrderDetails.class);
					instream.close();
				}
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("submitOrder Response {}", mmResponse.getCode() + " : " + mmResponse.getMessage()
							+ " : " + mmResponse.getDescription());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("submitOrder UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("submitOrder ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("submitOrder JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("submitOrder JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("submitOrder IOException: {}", e.getMessage());
		}

		if (orderDetails != null) {
			StringBuilder webLinkUrl = new StringBuilder();
			webLinkUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_WEBLINK_URL));
			webLinkUrl.append("?oid=");
			webLinkUrl.append(orderDetails.getId());
			webLinkUrl.append("&token=");
			webLinkUrl.append(sessionId);
			orderDetails.setWebLink(webLinkUrl.toString());
		}
		return orderDetails;
	}


	@PutMapping(value = "/updateUser")
	public void updateUser(String pid, String customerEmail, String sourceOfIncome, String natureOfBusiness) {
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append("/users/" + customerEmail + "/profile");

			HttpPut request = new HttpPut(sbUrl.toString());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY, getSessionWithPID(pid));

			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("incomeSource", sourceOfIncome));
			params.add(new BasicNameValuePair(ConfigConstants.MAX_MONEY_PARAM_NATUREOFBUSINESS, natureOfBusiness));

			UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
					ConfigConstants.MAX_MONEY_CHAR_ENCODING);
			request.setEntity(reqEntity);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 201) {
				// SUCCESS
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("updateUser Response {}", mmResponse.getCode() + " : " + mmResponse.getMessage()
							+ " : " + mmResponse.getDescription());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("updateUser UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("updateUser ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("updateUser JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("updateUser JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("updateUser IOException: {}", e.getMessage());
		}
	}


	@PostMapping(value = PgwUrlConstants.SUBMIT_MAXMONEY_ORDER, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public OrderDetails checkCDD(@RequestBody OrderDetails orderDetails) {
		MMResponse mmResponse = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_BASE_URL));
			sbUrl.append(ConfigConstants.MAX_MONEY_ORDER + "/" + orderDetails.getId() + "/cdd");

			HttpPost request = new HttpPost(sbUrl.toString());
			String sessionId = getSessionWithPID(orderDetails.getPid());
			request.addHeader(ConfigConstants.MAX_MONEY_API_KEY, sessionId);

			HttpClient client = HttpClientBuilder.create().build();
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 204 || response.getStatusLine().getStatusCode() == 200) {
				StringBuilder webLinkUrl = new StringBuilder();
				webLinkUrl.append(messageService.getMessage(ConfigConstants.MAX_MONEY_WEBLINK_URL));
				webLinkUrl.append("?oid=");
				webLinkUrl.append(orderDetails.getId());
				webLinkUrl.append("&token=");
				webLinkUrl.append(sessionId);
				orderDetails.setWebLink(webLinkUrl.toString());
			} else {
				HttpEntity entity = response.getEntity();
				if (entity != null) {
					InputStream instream = entity.getContent();
					mmResponse = objectMapper.readValue(instream, MMResponse.class);
					instream.close();
					logger.info("checkCDD Response {}", mmResponse.getCode() + " : " + mmResponse.getMessage()
							+ " : " + mmResponse.getDescription());
					logger.info("WEB LINK ISSUE AND STATUS FOR {}", response.getStatusLine().getStatusCode());
				}
			}
		} catch (UnsupportedEncodingException e) {
			logger.info("checkCDD UnsupportedEncodingException: {}", e.getMessage());
		} catch (ClientProtocolException e) {
			logger.info("checkCDD ClientProtocolException: {}", e.getMessage());
		} catch (JsonParseException e) {
			logger.info("checkCDD JsonParseException: {}", e.getMessage());
		} catch (JsonMappingException e) {
			logger.info("checkCDD JsonMappingException: {}", e.getMessage());
		} catch (IOException e) {
			logger.info("checkCDD IOException: {}", e.getMessage());
		}
		return orderDetails;
	}


	private File getFile(byte[] content, String name) throws IOException {
		File f = new File(name);
		try (OutputStream pdfout = new FileOutputStream(name)) {

			pdfout.write(content);
		} catch (IOException e) {
			logger.info("Exception: {}", e.getMessage());
		}
		return f;
	}


	@GetMapping(value = PgwUrlConstants.MMORDERSTATUS, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public RemittanceStatusDto getMMOrderStatus(@RequestParam String orderId) {
		String merpid = null;
		String maxid = null;
		RemittanceStatusDto remitdto = new RemittanceStatusDto();
		if (orderId != null) {
			PgwTransaction transaction = pgwTransactionService.findByMerOrderDetails(orderId);
			if (transaction != null && transaction.getRefId() != null) {
				maxid = transaction.getRefId();
				PgwMerchantPid pid = pgwMerchantPidService.findByMerchantMaxmoneyPid(transaction.getMerchantId());
				merpid = pid.getPid();
				remitdto.setOrderId(maxid);
				remitdto.setpId(merpid);
				try {
					remitdto = getOrderStatus(remitdto);
					String errorcode = remitdto.getStatusCode();
					switch (errorcode) {
					case "06":
						remitdto.setTransStatus("success");
						break;

					case "07":
						remitdto.setTransStatus("fail");
						break;

					case "04":
						remitdto.setTransStatus("fail");
						break;

					default:
						remitdto.setTransStatus("pending");
						break;
					}

					if (!BaseUtil.isEquals(transaction.getResMsg(), remitdto.getOrderDetails())) {
						transaction.setResCode(remitdto.getStatusCode());
						transaction.setResMsg(remitdto.getOrderDetails());
						transaction.setStatus(remitdto.getTransStatus());
						pgwTransactionService.update(transaction);
						saveTransHistory(transaction);
					}

				} catch (Exception e) {
					remitdto.setStatusCode("04");
					remitdto.setErrorCode("76");
					remitdto.setDescription("Transaction Not Found");
					logger.info("MAXMONEY ORDER STATUS ISSUE {}", e.getMessage());
				}
			} else {
				remitdto.setStatusCode("04");
				remitdto.setErrorCode("76");
				remitdto.setDescription("Transaction Not Found");
			}
		}
		return remitdto;
	}


	@GetMapping(value = "/getKYCStatus", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public KYCStatusResponse getKYCStatus(@RequestParam String merchantId, HttpServletRequest request,
			HttpServletResponse response) throws BeException {
		KYCStatusResponse statusResponse = new KYCStatusResponse();

		if (merchantId != null && !"".equalsIgnoreCase(merchantId)) {
			MerchantPid merchantPid = getBeService().findMerchantPidByMerchantId(merchantId);
			if (merchantPid != null && merchantPid.getPid() != null) {
				String sessionId = getSessionWithPID(merchantPid.getPid());
				if (sessionId != null && !"".equalsIgnoreCase(sessionId)) {
					statusResponse.setStatus("A");
					statusResponse.setDate(merchantPid.getCreateDt());
				} else {
					statusResponse.setStatus("P");
					statusResponse.setDate(merchantPid.getCreateDt());
				}
			} else {
				statusResponse.setStatus("I");
				statusResponse.setDate(new Date());
			}
		} else {
			statusResponse.setStatus("I");
			statusResponse.setDate(new Date());
		}

		return statusResponse;
	}


	private void saveTransHistory(PgwTransaction p) {
		try {
			PgwTransactionHistory h = dozerMapper.map(p, PgwTransactionHistory.class);
			h.setId(null);
			transHistoryService.create(h);
		} catch (Exception e1) {
			logger.info("Error in creating transaction history {}", e1.getMessage());
		}
	}
}
