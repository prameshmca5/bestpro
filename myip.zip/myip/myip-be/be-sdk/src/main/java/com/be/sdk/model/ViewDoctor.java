package com.be.sdk.model;

import java.util.List;

public class ViewDoctor {

	private String id;
	private String name;
	private String identityNo;
	private String gender;
	private String designation;
	private String department;
	private String division;
	private String email;
	private String telCountryCode;
	private String telNo;
	private String faxCountryCode;
	private String faxNo;
	private String ext;
	private String mcNo;
	private List<FileUpload> fileUploadsMc;	
	private String docMgtIdMc;
	private List<FileUpload> fileUploadsStamp;	
	private String docMgtIdStamp;
	private List<FileUpload> fileUploadsSignature;	
	private String docMgtIdSignature;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIdentityNo() {
		return identityNo;
	}
	public void setIdentityNo(String identityNo) {
		this.identityNo = identityNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelCountryCode() {
		return telCountryCode;
	}
	public void setTelCountryCode(String telCountryCode) {
		this.telCountryCode = telCountryCode;
	}
	public String getTelNo() {
		return telNo;
	}
	public void setTelNo(String telNo) {
		this.telNo = telNo;
	}
	public String getFaxCountryCode() {
		return faxCountryCode;
	}
	public void setFaxCountryCode(String faxCountryCode) {
		this.faxCountryCode = faxCountryCode;
	}
	public String getFaxNo() {
		return faxNo;
	}
	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}
	public String getExt() {
		return ext;
	}
	public void setExt(String ext) {
		this.ext = ext;
	}
	public String getMcNo() {
		return mcNo;
	}
	public void setMcNo(String mcNo) {
		this.mcNo = mcNo;
	}
	public List<FileUpload> getFileUploadsMc() {
		return fileUploadsMc;
	}
	public void setFileUploadsMc(List<FileUpload> fileUploadsMc) {
		this.fileUploadsMc = fileUploadsMc;
	}
	public String getDocMgtIdMc() {
		return docMgtIdMc;
	}
	public void setDocMgtIdMc(String docMgtIdMc) {
		this.docMgtIdMc = docMgtIdMc;
	}
	public List<FileUpload> getFileUploadsStamp() {
		return fileUploadsStamp;
	}
	public void setFileUploadsStamp(List<FileUpload> fileUploadsStamp) {
		this.fileUploadsStamp = fileUploadsStamp;
	}
	public String getDocMgtIdStamp() {
		return docMgtIdStamp;
	}
	public void setDocMgtIdStamp(String docMgtIdStamp) {
		this.docMgtIdStamp = docMgtIdStamp;
	}
	public List<FileUpload> getFileUploadsSignature() {
		return fileUploadsSignature;
	}
	public void setFileUploadsSignature(List<FileUpload> fileUploadsSignature) {
		this.fileUploadsSignature = fileUploadsSignature;
	}
	public String getDocMgtIdSignature() {
		return docMgtIdSignature;
	}
	public void setDocMgtIdSignature(String docMgtIdSignature) {
		this.docMgtIdSignature = docMgtIdSignature;
	}
	
	

}
