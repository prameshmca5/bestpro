/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since 03/03/2018
 */
public class FileUploadConstants {

	public static final String PROFILE_PIC = "PROFPIC";

	public static final String PREFIX_DOC = "DOC";
	
	public static final String TXN_TVL_TICKET_SUPP_DOCS = "TVLTICKET01";
	
	public static final String TXN_TVL_TICKET_RTN_SUPP_DOCS = "TVLTICKET02";
	
	public static final String TXN_TVL_PROOF_SUPP_DOCS = "PROOFOFSTY01";
	
	public static final String DOC_TRXN_TAX_INVOICE = "TAX_INVOICE";
	
	public static final String DOC_TRXN_OFFICIAL_RECEIPT = "OFFICIAL_RECEIPT";
	
	public static final String DOC_TRXN_MEDICAL_REPORT = "MEDICAL_REPORT";
	
	public static final String DOC_TRXN_MYIP_SLIP = "MYIP_SLIP";
	
	public static final String REPORT_FOLDER = "Reports/MyIP/"; 
	
	public static final String DOC_INS_POLICY_DOC = "INSURANCE";



	private FileUploadConstants() {
		throw new IllegalStateException("FileUploadConstants class");
	}

}