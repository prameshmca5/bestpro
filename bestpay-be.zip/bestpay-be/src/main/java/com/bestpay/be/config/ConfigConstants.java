/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.config;


import java.io.File;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public class ConfigConstants {

	private ConfigConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String BASE_PACKAGE = "com.bestpay.be";

	public static final String BASE_PACKAGE_REPO = "com.bestpay.be.dao";

	public static final String BASE_PACKAGE_MODEL = "com.bestpay.be.model";

	public static final String BASE_PACKAGE_SERVICE = "com.bestpay.be.service";

	public static final String BASE_PACKAGE_CONTROLLER = "com.bestpay.be.controller";

	public static final String CACHE_JAVA_FILE = "T(com.bestpay.be.sdk.constants.BeCacheConstants)";

	public static final String PATH_PROJ_CONFIG = "bestpay.config.path";

	public static final String PATH_CATALINA_HOME = "catalina.home";

	public static final String PATH_CATALINA_BASE = "catalina.base";

	public static final String PROJ_JBOSS_HOME = "jboss.server.config.dir";

	public static final String PROPERTY_FILENAME = "bestpay-be";

	public static final String PROPERTIES_EXT = ".properties";

	public static final String FILE_SYS_RESOURCE = File.separator + PROPERTY_FILENAME + PROPERTIES_EXT;

	public static final String PROPERTY_CLASSPATH = "classpath:" + PROPERTY_FILENAME;

	public static final String FILE_PFX = "file:";

	public static final String DB_CONF_DRIVER = "mysql.db.driver";

	public static final String DB_CONF_URL = "mysql.db.url";

	public static final String DB_CONF_UNAME = "mysql.db.uname";

	public static final String DB_CONF_PWORD = "mysql.db.pword";

	public static final String DB_CONF_POOL = "mysql.db.pool";

	public static final String DB_CONF_ABANDONED = "mysql.db.pool.removeAbandoned";

	public static final String DB_CONF_ABANDONED_TIMEOUT = "mysql.db.pool.removeAbandonedTimeout";

	public static final String DB_CONF_ABANDONED_LOG = "mysql.db.pool.logAbandoned";

	public static final String DB_CONF_MIN_IDLE = "mysql.db.pool.minIdle";

	public static final String DB_CONF_TEST_IDLE = "mysql.db.pool.testWhileIdle";

	public static final String DB_CONF_TEST_ONBORROW = "mysql.db.pool.testOnBorrow";

	public static final String DB_CONF_TEST_ONRETURN = "mysql.db.pool.testOnReturn";

	public static final String DB_CONF_VALIDATION_QRY = "mysql.db.pool.validationQuery";

	public static final String DB_CONF_VALIDATION_TIMEOUT = "mysql.db.pool.validationQueryTimeout";

	public static final String DB_CONF_MIN_IDLE_EVICT = "mysql.db.pool.minEvictableIdleTimeMillis";

	public static final String DB_CONF_TIME_BW_EVICT = "mysql.db.pool.timeBetweenEvictionRunsMillis";

	public static final String DB_CONF_MAX_ACTIVE = "mysql.db.pool.maxActive";

	public static final String DB_CONF_INIT_SIZE = "mysql.db.pool.initialSize";

	public static final String DB_CONF_MAX_WAIT = "mysql.db.pool.maxWait";

	public static final String DB_CONF_HIKARI_CONN_TIMEOUT = "mysql.db.pool.hikaricp.connectionTimeout";

	public static final String DB_CONF_HIKARI_IDLE_TIMEOUT = "mysql.db.pool.hikaricp.idleTimeout";

	public static final String DB_CONF_HIKARI_MAX_LIFETIME = "mysql.db.pool.hikaricp.maxLifetime";

	public static final String DB_CONF_HIKARI_CONN_QUERY = "mysql.db.pool.hikaricp.connectionTestQuery";

	public static final String DB_CONF_HIKARI_MIN_IDLE = "mysql.db.pool.hikaricp.minimumIdle";

	public static final String DB_CONF_HIKARI_MAX_POOL_SIZE = "mysql.db.pool.hikaricp.maximumPoolSize";

	public static final String DB_CONF_HIKARI_INIT_SQL = "mysql.db.pool.hikaricp.connectionInitSql";

	public static final String DB_CONF_HIKARI_VALID_TIMEOUT = "mysql.db.pool.hikaricp.validationTimeout";

	public static final String DB_CONF_HIKARI_LEAK_DETECT = "mysql.db.pool.hikaricp.leakDetectionThreshold";

	public static final String LDAP_CONF_DRIVER = "idm.ldap.driver";

	public static final String LDAP_CONF_URL = "idm.ldap.url";

	public static final String LDAP_CONF_UNAME = "idm.ldap.uname";

	public static final String LDAP_CONF_PWORD = "idm.ldap.pword";

	public static final String LDAP_CONF_PWORD_SALT = "idm.ldap.pword.salt";

	public static final String LDAP_CONF_BASEDN = "idm.ldap.basedn";

	public static final String LDAP_CONF_BASEDN_GROUP = "idm.ldap.basedn.group";

	public static final String REDIS_CONF_DEFAULT = "redis.cache.default";

	public static final String REDIS_CONF_UNAME = "redis.cache.uname";

	public static final String REDIS_CONF_PWORD = "redis.cache.pword";

	public static final String REDIS_CONF_HOST = "redis.cache.host";

	public static final String REDIS_CONF_PORT = "redis.cache.port";

	public static final String REDIS_CONF_SENTINEL_MASTER = "redis.cache.sentinel.master";

	public static final String REDIS_CONF_SENTINEL_HOST = "redis.cache.sentinel.host";

	public static final String REDIS_CONF_SENTINEL_PORT = "redis.cache.sentinel.port";

	public static final String SVC_CACHE_URL = "svc.cache.url";

	public static final String SVC_IDM_URL = "idm.service.url";

	public static final String SVC_IDM_TIMEOUT = "idm.service.timeout";

	public static final String SVC_IDM_SKEY = "idm.service.skey";

	public static final String SVC_IDM_CLIENT = "idm.service.client";

	public static final String SVC_NOT_URL = "not.service.url";

	public static final String SVC_NOT_TIMEOUT = "not.service.timeout";

	public static final String AUDI_SYSTEM_LOG = "audit.system.log";

	public static final String SVC_RPT_URL = "rpt.service.url";

	public static final String SVC_RPT_TIMEOUT = "rpt.service.timeout";

	public static final String MM_CALLBACK_URL = "mm.callback.url";

	public static final String MM_RETURN_URL = "mm.return.url";

	// MAX-MONEY
		public static final String MAX_MONEY_BASE_URL 					= "maxmoney.intergration.baseurl";
		public static final String MAX_MONEY_WEBLINK_URL 				= "maxmoney.intergration.weblinkurl";
		public static final String MAX_MONEY_DEFAULT_API_KEY 			= "maxmoney.intergration.default.api.key";
		public static final String MAX_MONEY_TEMP_UPLOAD_PATH 			= "maxmoney.intergration.temp.upload.path";	
		public static final String MAX_MONEY_BANK_LOCATION	 			= "maxmoney.intergration.bank.location";	
		public static final String MAX_MONEY_API_KEY					= "api-key";
		public static final String MAX_MONEY_CHAR_ENCODING	 			= "UTF-8";	
		public static final String MAX_MONEY_CREATE_SESSIONS 			= "/sessions/current";
		public static final String MAX_MONEY_CREATE_PID_SESSIONS 		= "/sessions/current/terminal";
		public static final String MAX_MONEY_CUSTOMER 					= "/customers";
		public static final String MAX_MONEY_CREATE_BENEFICIARY 		= "/beneficiaries";
		
		public static final String MAX_MONEY_ORDER 						= "/orders/current";
		
		public static final String MAX_MONEY_TRANSFER_RATE 				= "/transfer-rate";
		public static final String MAX_MONEY_SOURCE_INCOME 				= "/risks/sources";
		public static final String MAX_MONEY_PURPOSE_PAYMENT 			= "/risks/purposes";
		public static final String MAX_MONEY_NATURE_BUSINESS 			= "/risks//businesses";
		
		public static final String MAX_MONEY_PARAM_IDTYPE 				= "idType";
		public static final String MAX_MONEY_PARAM_IDNO 				= "idNo";
		public static final String MAX_MONEY_PARAM_CUSTOMERNAME			= "customerName";
		public static final String MAX_MONEY_PARAM_EMAIL 				= "email";
		public static final String MAX_MONEY_PARAM_MOBILE 				= "mobile";
		public static final String MAX_MONEY_PARAM_ADDRESS 				= "address";
		public static final String MAX_MONEY_PARAM_CITY 				= "city";
		public static final String MAX_MONEY_PARAM_STATE 				= "state";
		public static final String MAX_MONEY_PARAM_POSTALCODE			= "postalCode";
		public static final String MAX_MONEY_PARAM_COUNTRY 				= "country";	
		public static final String MAX_MONEY_PARAM_NATIONALITY			= "nationality";
		public static final String MAX_MONEY_PARAM_COMPANYNAME			= "companyName";
		public static final String MAX_MONEY_PARAM_NATUREOFBUSINESS		= "natureOfBusiness";
		public static final String MAX_MONEY_PARAM_COMPANYTYPE			= "companyType";
		public static final String MAX_MONEY_PARAM_CONTACTPERSON		= "contactPerson";
		public static final String MAX_MONEY_PARAM_BENEFICIARYID		= "beneficiaryId";
		public static final String MAX_MONEY_PARAM_TYPE 				= "type";
		public static final String MAX_MONEY_PARAM_REGISTEREDTHROUGHT	= "registeredThrough";

}
