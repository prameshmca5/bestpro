/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dialect;


import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.thymeleaf.dom.Element;
import org.thymeleaf.processor.element.AbstractElementProcessor;
import org.thymeleaf.util.StringUtils;

import com.bestpay.idm.sdk.model.Token;
import com.bestpay.web.config.iam.CustomUserDetails;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public abstract class AbstractBstElement extends AbstractElementProcessor {

	protected AbstractBstElement(String elementName) {
		super(elementName);
	}


	protected String getElementName(Element element) {
		return StringUtils.substringAfter(element.getOriginalName(), "bst:");
	}


	protected String getAuthToken() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null && auth.isAuthenticated() && auth.getPrincipal() instanceof CustomUserDetails) {
			CustomUserDetails cud = (CustomUserDetails) auth.getPrincipal();
			Token token = cud.getAuthToken();
			if (token != null) {
				return token.getAccessToken();
			}
		}
		return null;
	}

}
