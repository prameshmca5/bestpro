/**
  * Copyright 2019
 */
package com.be.sdk.model;


import java.io.Serializable;


/**
 * The persistent class for the BE_ELECTION_NOT_DTL database table.
 *
 * @author Naem Othman
 * @since March 31, 2020
 */
public class ElectionNotDtl implements Serializable, IQfCriteria<ElectionNotDtl> {

	/**
	 *
	 */
	private static final long serialVersionUID = 2158358517208494516L;

	private Integer electionNotDtlId;

	private Integer electionNotId;

	private Integer memberId;

	private String orgDivisionCd;

	private MemberProfile memberProfile;

	private String createId;


	public Integer getElectionNotDtlId() {
		return electionNotDtlId;
	}


	public void setElectionNotDtlId(Integer electionNotDtlId) {
		this.electionNotDtlId = electionNotDtlId;
	}


	public Integer getMemberId() {
		return memberId;
	}


	public void setMemberId(Integer memberId) {
		this.memberId = memberId;
	}


	public MemberProfile getMemberProfile() {
		return memberProfile;
	}


	public void setMemberProfile(MemberProfile memberProfile) {
		this.memberProfile = memberProfile;
	}


	public Integer getElectionNotId() {
		return electionNotId;
	}


	public void setElectionNotId(Integer electionNotId) {
		this.electionNotId = electionNotId;
	}


	public String getOrgDivisionCd() {
		return orgDivisionCd;
	}


	public void setOrgDivisionCd(String orgDivisionCd) {
		this.orgDivisionCd = orgDivisionCd;
	}


	/**
	 * @return the createId
	 */
	public String getCreateId() {
		return createId;
	}


	/**
	 * @param createId
	 *             the createId to set
	 */
	public void setCreateId(String createId) {
		this.createId = createId;
	}

}