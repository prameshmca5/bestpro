/**
  * Copyright 2019
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;


/**
 * The persistent class for the BE_ELECTION_NOT database table.
 *
 * @author Naem Othman
 * @since March 31, 2020
 */
@Entity
@Table(name = "BE_ELECTION_NOT")
public class BeElectionNot extends AbstractEntity implements Serializable, IQfCriteria<BeElectionNot> {

	/**
	 *
	 */
	private static final long serialVersionUID = 475104004414536703L;

	@Id
	@Column(name = "ELECTION_NOT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer electionNotId;

	@Column(name = "TXN_ID")
	private String txnId;

	@Column(name = "ORG_STATE_CD")
	private String orgStateCd;

	@Column(name = "ORG_DIVISION_CD")
	private String orgDivisionCd;

	@Column(name = "PARLIAMENT_CODE")
	private String parliamentCode;

	@Column(name = "DUN_CODE")
	private String dunCode;

	@Column(name = "MEMBER_CTGRY_MTDT_ID")
	private Integer memberCtrgyMtdtId;

	@Column(name = "TOTAL_MEMBER")
	private Integer totalMember;

	@Column(name = "APPLY_BY")
	private String applyBy;

	@Column(name = "APPLY_DT")
	private Timestamp applyDt;

	@Column(name = "APPLY_LEVEL")
	private String applyLevel;

	@Column(name = "APPLY_ORG_STATE_CD")
	private String applyOrgStateCd;

	@Column(name = "APPLY_ORG_DIVISION_CD")
	private String applyOrgDivisionCd;

	@Column(name = "NOTIFY_IND")
	private Integer notifyInd;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@OneToMany(mappedBy = "electionNot", cascade = CascadeType.ALL)
	private List<BeElectionNotDtl> electionNotDtlList;


	public Integer getElectionNotId() {
		return electionNotId;
	}


	public void setElectionNotId(Integer electionNotId) {
		this.electionNotId = electionNotId;
	}


	public String getTxnId() {
		return txnId;
	}


	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}


	public String getOrgStateCd() {
		return orgStateCd;
	}


	public void setOrgStateCd(String orgStateCd) {
		this.orgStateCd = orgStateCd;
	}


	public String getOrgDivisionCd() {
		return orgDivisionCd;
	}


	public void setOrgDivisionCd(String orgDivisionCd) {
		this.orgDivisionCd = orgDivisionCd;
	}


	public String getParliamentCode() {
		return parliamentCode;
	}


	public void setParliamentCode(String parliamentCode) {
		this.parliamentCode = parliamentCode;
	}


	public String getDunCode() {
		return dunCode;
	}


	public void setDunCode(String dunCode) {
		this.dunCode = dunCode;
	}


	public Integer getMemberCtrgyMtdtId() {
		return memberCtrgyMtdtId;
	}


	public void setMemberCtrgyMtdtId(Integer memberCtrgyMtdtId) {
		this.memberCtrgyMtdtId = memberCtrgyMtdtId;
	}


	public String getApplyBy() {
		return applyBy;
	}


	public void setApplyBy(String applyBy) {
		this.applyBy = applyBy.toUpperCase();
	}


	public Timestamp getApplyDt() {
		return applyDt;
	}


	public void setApplyDt(Timestamp applyDt) {
		this.applyDt = applyDt;
	}


	public Integer getTotalMember() {
		return totalMember;
	}


	public void setTotalMember(Integer totalMember) {
		this.totalMember = totalMember;
	}


	public String getApplyLevel() {
		return applyLevel;
	}


	public void setApplyLevel(String applyLevel) {
		this.applyLevel = applyLevel.toUpperCase();
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public List<BeElectionNotDtl> getElectionNotDtlList() {
		return electionNotDtlList;
	}


	public void setElectionNotDtlList(List<BeElectionNotDtl> electionNotDtlList) {
		this.electionNotDtlList = electionNotDtlList;
	}


	public void addBeElectionDtlNotList(List<BeElectionNotDtl> beElectionDtlNotList) {
		beElectionDtlNotList.forEach(electionDtl -> {
			electionDtl.setElectionNot(this);
		});

		setElectionNotDtlList(beElectionDtlNotList);
	}


	public Integer getNotifyInd() {
		return notifyInd;
	}


	public void setNotifyInd(Integer notifyInd) {
		this.notifyInd = notifyInd;
	}


	public String getApplyOrgStateCd() {
		return applyOrgStateCd;
	}


	public void setApplyOrgStateCd(String applyOrgStateCd) {
		this.applyOrgStateCd = applyOrgStateCd;
	}


	public String getApplyOrgDivisionCd() {
		return applyOrgDivisionCd;
	}


	public void setApplyOrgDivisionCd(String applyOrgDivisionCd) {
		this.applyOrgDivisionCd = applyOrgDivisionCd;
	}

}