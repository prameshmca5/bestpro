/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.RefBranch;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.Branch;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;
import com.util.JsonUtil;


/**
 * @author Ramesh Pongiannan
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_BRANCH_QF)
public class RefBranchQf extends QueryFactory<RefBranch> {

	@PersistenceContext
	private EntityManager em;


	@Override
	public Specification<RefBranch> searchByProperty(RefBranch t) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<RefBranch> searchAllByProperty(RefBranch t) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<RefBranch> cq = cb.createQuery(RefBranch.class);
		Root<RefBranch> parliamentRoot = cq.from(RefBranch.class);
		List<Predicate> predicates = generateCriteria(cb, parliamentRoot, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			Branch dto = JsonUtil.transferToObject(criteria, Branch.class);

			if (!BaseUtil.isObjNull(dto)) {

				if (!BaseUtil.isObjNull(dto.getBranchCd())) {
					predicates.add(cb.equal(from.get("branchCd"), dto.getBranchCd()));
				}

				if (!BaseUtil.isObjNull(dto.getBranchDesc())) {
					predicates.add(cb.like(from.get("branchDesc"), "%" + dto.getBranchDesc() + "%"));
				}

			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

}
