/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author michelle.angela
 *
 */

@Entity
@Table(name = "BE_TVL")
public class BeTvl extends AbstractEntity implements Serializable, IQfCriteria<BeTvl> {

	private static final long serialVersionUID = 7856540544780852659L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TVL_ID")
	private Integer tvlId;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TVL_PROF_ID")
	private BeTvlProfile tvlProfile;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ACCT_PROF_ID")
	private BeAcctProfile acctProfile;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TVL_PMT_ID")
	private BeTvlPayment tvlPayment;

	@JsonIgnoreProperties("tvls") 
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TVL_TRIP_ID")
	private BeTvlTrip tvlTrip;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TVL_INS_ID")
	private BeTvlInsurance tvlInsurance;

	@Column(name = "TVL_SLIP_NO")
	private String tvlSlipId;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATUS_ID")
	private RefStatus status;

	@Column(name = "REMARKS")
	private String addr;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "STATUS")
	private Boolean isActive;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@JsonIgnoreProperties("tvl")
	@OneToMany(mappedBy = "tvl", fetch = FetchType.LAZY)
	private Set<BeTvlStat> tvlStats;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "RISK_STATUS_ID")
	private BeConfigRiskStatus riskStatus;

	public Integer getTvlId() {
		return tvlId;
	}


	public void setTvlId(Integer tvlId) {
		this.tvlId = tvlId;
	}


	public BeTvlProfile getTvlProfile() {
		return tvlProfile;
	}


	public void setTvlProfile(BeTvlProfile tvlProfile) {
		this.tvlProfile = tvlProfile;
	}


	public BeAcctProfile getAcctProfile() {
		return acctProfile;
	}


	public void setAcctProfile(BeAcctProfile acctProfile) {
		this.acctProfile = acctProfile;
	}


	public BeTvlPayment getTvlPayment() {
		return tvlPayment;
	}


	public void setTvlPayment(BeTvlPayment tvlPayment) {
		this.tvlPayment = tvlPayment;
	}


	public BeTvlTrip getTvlTrip() {
		return tvlTrip;
	}


	public void setTvlTrip(BeTvlTrip tvlTrip) {
		this.tvlTrip = tvlTrip;
	}


	public BeTvlInsurance getTvlInsurance() {
		return tvlInsurance;
	}


	public void setTvlInsurance(BeTvlInsurance tvlInsurance) {
		this.tvlInsurance = tvlInsurance;
	}


	public String getTvlSlipId() {
		return tvlSlipId;
	}


	public void setTvlSlipId(String tvlSlipId) {
		this.tvlSlipId = tvlSlipId;
	}


	public RefStatus getStatus() {
		return status;
	}


	public void setStatus(RefStatus status) {
		this.status = status;
	}


	public String getAddr() {
		return addr;
	}


	public void setAddr(String addr) {
		this.addr = addr;
	}


	public Boolean getIsActive() {
		return isActive;
	}


	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Set<BeTvlStat> getTvlStats() {
		return tvlStats;
	}


	public void setTvlStats(Set<BeTvlStat> tvlStats) {
		this.tvlStats = tvlStats;
	}


	public BeConfigRiskStatus getRiskStatus() {
		return riskStatus;
	}


	public void setRiskStatus(BeConfigRiskStatus riskStatus) {
		this.riskStatus = riskStatus;
	}

}
