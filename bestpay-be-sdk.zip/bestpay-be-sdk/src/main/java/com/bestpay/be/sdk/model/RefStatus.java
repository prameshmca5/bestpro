package com.bestpay.be.sdk.model;

import java.io.Serializable;
import java.sql.Timestamp;


public class RefStatus implements Serializable {
	
	private static final long serialVersionUID = 607657392585361232L;
	private Integer id;
	private String statusCode;
	private String statusDescEn;
	private String statusType;
	private String createId;
	private Timestamp createDt;
	private Timestamp updateDt;
	private String updateId;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescEn() {
		return statusDescEn;
	}
	public void setStatusDescEn(String statusDescEn) {
		this.statusDescEn = statusDescEn;
	}
	public String getStatusType() {
		return statusType;
	}
	public void setStatusType(String statusType) {
		this.statusType = statusType;
	}
	public String getCreateId() {
		return createId;
	}
	public void setCreateId(String createId) {
		this.createId = createId;
	}
	public Timestamp getCreateDt() {
		return createDt;
	}
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}
	public Timestamp getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}
	public String getUpdateId() {
		return updateId;
	}
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


}
