/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BeConstants {

	public static final String SUCCESS_RESPONSE = "SUCCESS";

	public static final String FAIL_RESPONSE = "FAIL";

	public static final String TRXN_NO_CMPNY_LOGO = "CMPNYLOGO";

	// USER TYPE CODE
	public static final String USER_TYPE_EXTERNAL = "EXT";

	// USER GROUP ROLE CODE
	public static final String USER_ROLE_GROUP_VA = "VA_USER";

	public static final String DVM_PREFIX = "DVM";

	// Operation
	public static final String OPERATION_CREATE = "C";

	public static final String OPERATION_UPDATE = "U";

	public static final Integer MISIGNET_AUTHORISE_TRANS = 1;

	public static final Integer MISIGNET_EXECUTE_TRANS = 2;

	public static final Integer USR_TYPE_MALAYSIAN = 1;

	public static final Integer USR_TYPE_FOREIGNER = 2;


	private BeConstants() {
		throw new IllegalStateException("BeConstants class");
	}
}