package com.bestpay.be.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwTrxnDocumentRepository;
import com.bestpay.be.model.PgwTrxnDocument;
import com.bestpay.be.util.QualifierConstants;


@Transactional
@Service(QualifierConstants.PGW_TRXN_DOCUMENT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_TRXN_DOCUMENT_SVC)
public class PgwTrxnDocumentsService extends AbstractService<PgwTrxnDocument> {

	@Autowired
	private PgwTrxnDocumentRepository trxnDocumentDao;


	@Override
	public PgwTrxnDocumentRepository primaryDao() {
		return trxnDocumentDao;
	}

}
