package com.bestpay.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwMerchantBeneficiary;
import com.bestpay.be.util.QualifierConstants;

 
@Repository
@RepositoryDefinition(domainClass = PgwMerchantBeneficiary.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_BENEFICIARY_DAO)
public interface PgwMerchantBeneficiaryRepository extends GenericRepository<PgwMerchantBeneficiary> {

	@Query("select u from PgwMerchantBeneficiary u where u.merchantId = :merchantId ")
	public PgwMerchantBeneficiary findByMerchantBenefId(@Param("merchantId") String merchantId);
 	
 	@Query("select u from PgwMerchantBeneficiary u where u.merchantId = :merchantId  and u.mtoId = :mtoId")
	public PgwMerchantBeneficiary findByMerchantBenefIdMtoid(@Param("merchantId") String merchantId,@Param("mtoId")String mtoId);

}
