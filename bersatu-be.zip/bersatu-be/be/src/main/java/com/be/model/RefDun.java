/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;


/**
 * @author Ramesh Pongiannan
 *
 */
@Entity
@Table(name = "REF_DUN")
public class RefDun extends AbstractEntity implements Serializable, IQfCriteria<RefDun> {

	private static final long serialVersionUID = 5466589728737397061L;

	@Id
	@Column(name = "DUN_CD")
	private String dunCd;

	@Column(name = "DUN_DESC")
	private String dunDesc;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "STATE_CD", insertable = false, updatable = false)
	private RefState state;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PARLIAMENT_CD", referencedColumnName = "PARLIAMENT_CD", insertable = false, updatable = false)
	private RefParliament parliament;

	@Column(name = "PARLIAMENT_CD")
	private String parliamentCd;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;


	public String getDunCd() {
		return dunCd;
	}


	public void setDunCd(String dunCd) {
		this.dunCd = dunCd;
	}


	public String getDunDesc() {
		return dunDesc;
	}


	public void setDunDesc(String dunDesc) {
		this.dunDesc = dunDesc;
	}


	public RefState getState() {
		return state;
	}


	public void setState(RefState state) {
		this.state = state;
	}


	public String getStatus() {
		return status;
	}


	public RefParliament getParliament() {
		return parliament;
	}


	public void setParliament(RefParliament parliament) {
		this.parliament = parliament;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public String getParliamentCd() {
		return parliamentCd;
	}


	public void setParliamentCd(String parliamentCd) {
		this.parliamentCd = parliamentCd;
	}

}
