package com.portal.web.idm.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.be.sdk.model.DoctorProfile;
import com.portal.core.AbstractController;
import com.portal.web.util.ValidationUtil;

@Component("doctorProfileValidator")
public class DoctorProfileValidator extends AbstractController implements Validator {
	
	@Override
	public boolean supports(Class<?> clazz) {
		return DoctorProfile.class.equals(clazz);
	}

	@Override
	public void validate(Object object, Errors errors) {
			
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "doctorId", "", "ID is required");
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "fullName", "", "Name is required");
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "identityNo", "", "Identity No is required");
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "gender", "", "Gender is required");
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "designation", "", "Designation is required");
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "department", "", "Department is required");
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "division", "", "Division Code is required");
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "email", "", "Email is required");
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "contactNo", "", "Contact No is required");
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "faxNo", "", "Fax No Code is required");
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "ext", "", "Ext is required");
			//ValidationUtil.rejectIfEmptyOrWhitespace(errors, "beMcProfile.mcRegNo", "", "Medical Certificate No. is required");			
			
		}
}
