package com.bestpay.be.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.RefSubscriptionPlan;
import com.bestpay.be.util.QualifierConstants;


@Repository
@RepositoryDefinition(domainClass = RefSubscriptionPlan.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_SUB_PLAN_DAO)
public interface RefSubscriptionPlanRepository extends GenericRepository<RefSubscriptionPlan> {

	@Override
	@Query("select u from RefSubscriptionPlan u ")
	public List<RefSubscriptionPlan> findAll();


	@Query("select u from RefSubscriptionPlan u where u.planType = :planType ")
	public List<RefSubscriptionPlan> findByPlanType(@Param("planType") String planType);


	@Query("select count(u) from RefSubscriptionPlan u ")
	public int totalRecords();

}