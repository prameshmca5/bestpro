package com.bestpay.pgw.sdk.incentiveremit.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "Return_TRANSREPORT")
@XmlAccessorType(XmlAccessType.FIELD)
public class TransactionReport {

	@XmlElement(name = "CODE")
	private String code;

	@XmlElement(name = "TRANNO")
	private String tranNo;

	@XmlElement(name = "PINNO")
	private String pinNo;

	@XmlElement(name = "SENDER_NAME")
	private String senderName;

	@XmlElement(name = "RECEIVER_NAME")
	private String receiverName;

	@XmlElement(name = "RECEIVER_COUNTRY")
	private String receiverCountry;

	@XmlElement(name = "REMIT_AMT")
	private String remitAmt;

	@XmlElement(name = "REMIT_CCY")
	private String remitCcy;

	@XmlElement(name = "REMIT_CHARGE")
	private String remitCharge;

	@XmlElement(name = "REMIT_EXRATE")
	private String remitExrate;

	@XmlElement(name = "PAYOUT_AMT")
	private String payoutAmt;

	@XmlElement(name = "PAYOUT_CCY")
	private String payoutCcy;

	@XmlElement(name = "TRANSACTION_TYPE")
	private String transactionType;

	@XmlElement(name = "TRANSACTION_DATE")
	private String transactionDate;

	@XmlElement(name = "APPROVE_DATE")
	private String approveDate;

	@XmlElement(name = "BANK_NAME")
	private String bankName;

	@XmlElement(name = "BANK_BRANCH_NAME")
	private String bankBranchName;

	@XmlElement(name = "BANK_ACCOUNT_NUMBER")
	private String bankAccountNumber;

	@XmlElement(name = "STATUS")
	private String status;

	@XmlElement(name = "MESSAGE")
	private String message;


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getTranNo() {
		return tranNo;
	}


	public void setTranNo(String tranNo) {
		this.tranNo = tranNo;
	}


	public String getPinNo() {
		return pinNo;
	}


	public void setPinNo(String pinNo) {
		this.pinNo = pinNo;
	}


	public String getSenderName() {
		return senderName;
	}


	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}


	public String getReceiverName() {
		return receiverName;
	}


	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}


	public String getReceiverCountry() {
		return receiverCountry;
	}


	public void setReceiverCountry(String receiverCountry) {
		this.receiverCountry = receiverCountry;
	}


	public String getRemitAmt() {
		return remitAmt;
	}


	public void setRemitAmt(String remitAmt) {
		this.remitAmt = remitAmt;
	}


	public String getRemitCcy() {
		return remitCcy;
	}


	public void setRemitCcy(String remitCcy) {
		this.remitCcy = remitCcy;
	}


	public String getRemitCharge() {
		return remitCharge;
	}


	public void setRemitCharge(String remitCharge) {
		this.remitCharge = remitCharge;
	}


	public String getRemitExrate() {
		return remitExrate;
	}


	public void setRemitExrate(String remitExrate) {
		this.remitExrate = remitExrate;
	}


	public String getPayoutAmt() {
		return payoutAmt;
	}


	public void setPayoutAmt(String payoutAmt) {
		this.payoutAmt = payoutAmt;
	}


	public String getPayoutCcy() {
		return payoutCcy;
	}


	public void setPayoutCcy(String payoutCcy) {
		this.payoutCcy = payoutCcy;
	}


	public String getTransactionType() {
		return transactionType;
	}


	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	public String getTransactionDate() {
		return transactionDate;
	}


	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}


	public String getApproveDate() {
		return approveDate;
	}


	public void setApproveDate(String approveDate) {
		this.approveDate = approveDate;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getBankBranchName() {
		return bankBranchName;
	}


	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}


	public String getBankAccountNumber() {
		return bankAccountNumber;
	}


	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}

}
