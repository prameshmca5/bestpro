/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.util.List;


/**
 * @author michelle.angela
 *
 */
public class AirlinesProfile implements Serializable, IQfCriteria<AirlinesProfile> {

	private static final long serialVersionUID = 7317920368549261318L;

	private Integer airlinesProfId;

	private Metadata airlinesTypeMtdt;

	private Metadata flightCoverageMtdt;

	private String iataRegNo;

	private String icaoRegNo;

	private String airlinesName;

	private String callSign;

	private String contactNo;

	private String contactNo2;

	private String faxNo;

	private String email;

	private String website;

	private String yearCommencedOps;

	private String docRefNo;

	private List<AirlinesContact> airlinesContacts;

	private List<AirlinesPic> airlinesPics;

	private List<AirlinesAddress> airlinesAddresses;

	private List<TrxnDocuments> trxnDocuments;

	private boolean embedContacts;

	private boolean embedPICs;

	private boolean embedAddresses;

	private String airlinesType;

	private String systemType;


	public Integer getAirlinesProfId() {
		return airlinesProfId;
	}


	public void setAirlinesProfId(Integer airlinesProfId) {
		this.airlinesProfId = airlinesProfId;
	}


	public Metadata getAirlinesTypeMtdt() {
		return airlinesTypeMtdt;
	}


	public void setAirlinesTypeMtdt(Metadata airlinesTypeMtdt) {
		this.airlinesTypeMtdt = airlinesTypeMtdt;
	}


	public Metadata getFlightCoverageMtdt() {
		return flightCoverageMtdt;
	}


	public void setFlightCoverageMtdt(Metadata flightCoverageMtdt) {
		this.flightCoverageMtdt = flightCoverageMtdt;
	}


	public String getIataRegNo() {
		return iataRegNo;
	}


	public void setIataRegNo(String iataRegNo) {
		this.iataRegNo = iataRegNo;
	}


	public String getIcaoRegNo() {
		return icaoRegNo;
	}


	public void setIcaoRegNo(String icaoRegNo) {
		this.icaoRegNo = icaoRegNo;
	}


	public String getAirlinesName() {
		return airlinesName;
	}


	public void setAirlinesName(String airlinesName) {
		this.airlinesName = airlinesName;
	}


	public String getCallSign() {
		return callSign;
	}


	public void setCallSign(String callSign) {
		this.callSign = callSign;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public String getContactNo2() {
		return contactNo2;
	}


	public void setContactNo2(String contactNo2) {
		this.contactNo2 = contactNo2;
	}


	public String getFaxNo() {
		return faxNo;
	}


	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getWebsite() {
		return website;
	}


	public void setWebsite(String website) {
		this.website = website;
	}


	public String getYearCommencedOps() {
		return yearCommencedOps;
	}


	public void setYearCommencedOps(String yearCommencedOps) {
		this.yearCommencedOps = yearCommencedOps;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public List<AirlinesContact> getAirlinesContacts() {
		return airlinesContacts;
	}


	public void setAirlinesContacts(List<AirlinesContact> airlinesContacts) {
		this.airlinesContacts = airlinesContacts;
	}


	public List<AirlinesPic> getAirlinesPics() {
		return airlinesPics;
	}


	public void setAirlinesPics(List<AirlinesPic> airlinesPics) {
		this.airlinesPics = airlinesPics;
	}


	public List<AirlinesAddress> getAirlinesAddresses() {
		return airlinesAddresses;
	}


	public void setAirlinesAddresses(List<AirlinesAddress> airlinesAddresses) {
		this.airlinesAddresses = airlinesAddresses;
	}


	public boolean isEmbedContacts() {
		return embedContacts;
	}


	public void setEmbedContacts(boolean embedContacts) {
		this.embedContacts = embedContacts;
	}


	public boolean isEmbedPICs() {
		return embedPICs;
	}


	public void setEmbedPICs(boolean embedPICs) {
		this.embedPICs = embedPICs;
	}


	public boolean isEmbedAddresses() {
		return embedAddresses;
	}


	public void setEmbedAddresses(boolean embedAddresses) {
		this.embedAddresses = embedAddresses;
	}


	public List<TrxnDocuments> getTrxnDocuments() {
		return trxnDocuments;
	}


	public void setTrxnDocuments(List<TrxnDocuments> trxnDocuments) {
		this.trxnDocuments = trxnDocuments;
	}


	public String getAirlinesType() {
		return airlinesType;
	}


	public void setAirlinesType(String airlinesType) {
		this.airlinesType = airlinesType;
	}


	public String getSystemType() {
		return systemType;
	}


	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}

}
