/**
 * Copyright 2020. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;


/**
 * @author nurul.naimma
 *
 * @since Jul 17, 2020
 */
public class DashsyncCred implements Serializable {

	private static final long serialVersionUID = -1349809217048715271L;

	private String validationkey;

	private String decryptionKey;

	private String userid;

	private String password;

	private String url;

	private String syncClientId;

	private String tokenUrl;


	public DashsyncCred(String url, String validationkey, String decryptionKey, String userid, String password,
			String syncClientId, String tokenUrl) {
		this.url = url;
		this.validationkey = validationkey;
		this.decryptionKey = decryptionKey;
		this.userid = userid;
		this.password = password;
		this.syncClientId = syncClientId;
		this.tokenUrl = tokenUrl;
	}


	public String getValidationkey() {
		return validationkey;
	}


	public void setValidationkey(String validationkey) {
		this.validationkey = validationkey;
	}


	public String getDecryptionKey() {
		return decryptionKey;
	}


	public void setDecryptionKey(String decryptionKey) {
		this.decryptionKey = decryptionKey;
	}


	public String getUserid() {
		return userid;
	}


	public void setUserid(String userid) {
		this.userid = userid;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public String getSyncClientId() {
		return syncClientId;
	}


	public void setSyncClientId(String syncClientId) {
		this.syncClientId = syncClientId;
	}


	public String getTokenUrl() {
		return tokenUrl;
	}


	public void setTokenUrl(String tokenUrl) {
		this.tokenUrl = tokenUrl;
	}

}
