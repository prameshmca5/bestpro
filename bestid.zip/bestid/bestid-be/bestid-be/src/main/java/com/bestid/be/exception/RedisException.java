/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.exception;


import java.text.MessageFormat;

import com.bestid.be.sdk.constants.BeErrorCodeEnum;


/**
 * @author mary.jane
 * @since Nov 12, 2018
 */
public class RedisException extends RuntimeException {

	private String internalErrorCode;


	public RedisException() {
		super();
	}


	public RedisException(String s) {
		super(s);
	}


	public RedisException(String internalCode, String reason) {
		super(reason);
		internalErrorCode = internalCode;
	}


	public RedisException(BeErrorCodeEnum rce) {
		super(rce.getMessage());
		internalErrorCode = rce.name();
	}


	public RedisException(BeErrorCodeEnum rce, Object[] args) {
		super((args != null ? MessageFormat.format(rce.getMessage(), args) : rce.getMessage()));
		internalErrorCode = rce.name();
	}


	public String getInternalErrorCode() {
		return internalErrorCode;
	}

}
