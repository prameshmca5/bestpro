/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.util;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bestpay.idm.sdk.constants.IdmErrorCodeEnum;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bstsb.util.DateUtil;
import com.bstsb.util.constants.BaseConstants;
import com.bstsb.util.constants.ChkSumDayEnum;
import com.bstsb.util.constants.ChkSumMonthEnum;
import com.bstsb.util.constants.ChkSumYearEnum;
 


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public class WebUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(WebUtil.class);

	private static final String SUMDIGIT = "m10....: {}";

	private static final String CHKSUM = "chksum...: {}";

	private static final String SUM = "sum....: {}";


	public static String getStackTrace(final Throwable throwable) {
		StringWriter writer = new StringWriter();
		throwable.printStackTrace(new PrintWriter(writer));
		String[] lines = writer.toString().split("\n");
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < Math.min(lines.length, 10); i++) {
			sb.append(lines[i]).append("\n");
		}
		return sb.toString();
	}

	public static String getRequestBody(final InputStream is) throws IOException {
		StringBuilder stringBuilder = new StringBuilder();
		InputStream inputStream = is;
		if (inputStream != null) {
			try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));) {
				char[] charBuffer = new char[128];
				int bytesRead = -1;
				while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
					stringBuilder.append(charBuffer, 0, bytesRead);
				}
			} catch (IOException ex) {
				LOGGER.error("IOException: {} ", ex);
				throw ex;
			} finally {
				stringBuilder.append("");

			}

		}
		return stringBuilder.toString();
	}

	 

	public static void main(String[] args) {
		// EQMA2015G187
		/**
		 * Checksum checksum = new CRC32(); String input = "201509180000015";
		 * byte bytes[] = input.getBytes(); checksum.update(bytes, 0,
		 * bytes.length); long checksumValue = checksum.getValue();
		 */

		String refNo = genChksumNoDate("KDN-SPPA", "20151010", 1);
		LOGGER.debug("GENERATED REF NO: {} ", refNo);

		LOGGER.debug(SUM, checkDigitNoDate(refNo));

		// [START] SHUFFLE STRING
		String chck = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		List<Character> characters = new ArrayList<>();
		for (char c : chck.toCharArray()) {
			characters.add(c);
		}
		Collections.shuffle(characters);
		StringBuilder sb = new StringBuilder();
		for (char c : characters) {
			sb.append(c);
		}
		String str = sb.toString();
		LOGGER.debug(str);
		// [END] SHUFFLE STRING
	}


	public static int checkDigitNoDate(String refNo) {
		if (refNo.length() != 20) {
			return -1;
		}

		final String ERR_TEXT = "{} -- {}";

		String newRefNo = refNo.substring(9, 20);
		LOGGER.debug(newRefNo);
		String dtPrfx = newRefNo.substring(0, 3);
		LOGGER.debug(dtPrfx);
		char[] dtArray = dtPrfx.toCharArray();
		if (dtArray.length == 3) {
			dtPrfx = ChkSumYearEnum.getEnumBySeq(String.valueOf(dtArray[0]));
			LOGGER.debug(ERR_TEXT, dtArray[0], dtPrfx);
			dtPrfx = dtPrfx + ChkSumMonthEnum.getEnumBySeq(String.valueOf(dtArray[1]));
			LOGGER.debug(ERR_TEXT, dtArray[1], dtPrfx);
			dtPrfx = dtPrfx + ChkSumDayEnum.getEnumBySeq(String.valueOf(dtArray[2]));
			LOGGER.debug(ERR_TEXT, dtArray[2], dtPrfx);
		}
		String sufx = newRefNo.substring(4, newRefNo.length());
		LOGGER.debug(sufx);
		int chksum = Integer.parseInt(newRefNo.substring(9, 10));
		LOGGER.info("Chksum: {}", chksum);

		String calcSum = dtPrfx + sufx;
		LOGGER.debug(calcSum);

		char[] a = calcSum.toCharArray();

		int i;
		int len = a.length;
		int mul;
		int sum;
		int m10;

		mul = 2;
		sum = 0;
		for (i = len - 2; i >= 0; i--) {
			if ((Integer.valueOf(a[i]) * mul) >= 10) {
				sum += ((Integer.valueOf(a[i]) * mul) / 10) + ((Integer.valueOf(a[i]) * mul) % 10);
			} else {
				sum += Integer.valueOf(a[i]) * mul;
			}

			if (mul == 2) {
				mul = 1;
			} else {
				mul = 2;
			}
			LOGGER.debug("{}  - {} - {}", a[i], sum, mul);
		}

		LOGGER.info(SUM, sum);
		m10 = sum % 10;
		LOGGER.info(SUMDIGIT, m10);
		LOGGER.info(CHKSUM, chksum);

		if (m10 > 10) {
			m10 = 10 - m10;
		}
		LOGGER.info(SUMDIGIT, m10);
		if (m10 == chksum) {
			return 1;
		} else {
			return 0;
		}
	}


	public static int checkDigit(String refNo) {
		if (refNo.length() != 20) {
			return -1;
		}

		String newRefNo = refNo.substring(4, 20);
		LOGGER.debug(newRefNo);
		String prfx = newRefNo.substring(0, 8);
		LOGGER.debug(prfx);
		String sufx = newRefNo.substring(10, 16);
		LOGGER.debug(sufx);
		int chksum = Integer.parseInt(newRefNo.substring(9, 10));
		LOGGER.info(CHKSUM, chksum);

		String calcSum = prfx + sufx;
		LOGGER.info(CHKSUM, chksum);

		char[] a = calcSum.toCharArray();

		int i;
		int len = a.length;
		int mul;
		int sum;
		int m10;

		if (len != 14) {
			return -1;
		}

		mul = 2;
		sum = 0;
		for (i = len - 2; i >= 0; i--) {
			if ((Integer.valueOf(a[i]) * mul) >= 10) {
				sum += ((Integer.valueOf(a[i]) * mul) / 10) + ((Integer.valueOf(a[i]) * mul) % 10);
			} else {
				sum += Integer.valueOf(a[i]) * mul;
			}

			if (mul == 2) {
				mul = 1;
			} else {
				mul = 2;
			}

			LOGGER.debug("{}  - {} - {}", a[i], sum, mul);
		}

		LOGGER.info("sum....: {} ", sum);
		m10 = sum % 10;
		LOGGER.info(SUMDIGIT, m10);
		LOGGER.info(CHKSUM, chksum);

		if (m10 > 10) {
			m10 = 10 - m10;
		}
		LOGGER.info(SUMDIGIT, m10);
		if (m10 == chksum) {
			return 1;
		} else {
			return 0;
		}

	}


	public static String genChksumNoDate(String trxnCd, String ctrlGenDt, Integer trxnId) {
		StringBuilder sb = new StringBuilder();
		sb.append(trxnCd);
		sb.append("/");

		Date date = DateUtil.convertStrDateToDate(ctrlGenDt, BaseConstants.SIMPLE_DATE_FORMAT);
		DateTime dt = new DateTime(date);
		LOGGER.debug("Year: {} - Month: {} - Day: {}", dt.getYear(), dt.getMonthOfYear(), dt.getDayOfMonth());

		sb.append(ChkSumYearEnum.valueOf("YEAR_" + dt.getYear()).getSeq());
		sb.append(ChkSumMonthEnum.valueOf("MONTH_" + dt.getMonthOfYear()).getSeq());
		sb.append(ChkSumDayEnum.valueOf("DAY_" + dt.getDayOfMonth()).getSeq());

		String str = String.valueOf(trxnId);
		String newTrxnId = ("0000000" + str).substring(str.length());
		String calcSum = ctrlGenDt + str;
		LOGGER.info("Length: {}", calcSum.length());

		char[] a = calcSum.toCharArray();
		int i;
		int len = a.length;
		int mul;
		int sum;
		int m10;

		mul = 2;
		sum = 0;
		for (i = len - 2; i >= 0; i--) {
			if ((Integer.valueOf(a[i]) * mul) >= 10) {
				sum += ((Integer.valueOf(a[i]) * mul) / 10) + ((Integer.valueOf(a[i]) * mul) % 10);
			} else {
				sum += Integer.valueOf(a[i]) * mul;
			}

			if (mul == 2) {
				mul = 1;
			} else {
				mul = 2;
			}
		}

		m10 = sum % 10;
		if (m10 > 10) {
			m10 = 10 - m10;
		}
		LOGGER.info("Chcksum Val: {} ", m10);
		sb.append(m10);
		sb.append(newTrxnId);
		return sb.toString();
	}


	public static String genChksumDigit(String trxnCd, String ctrlGenDt, Integer trxnId) {
		StringBuilder sb = new StringBuilder();
		sb.append(trxnCd);
		sb.append(ctrlGenDt);
		sb.append("-");

		Date date = DateUtil.convertStrDateToDate(ctrlGenDt, BaseConstants.SIMPLE_DATE_FORMAT);
		DateTime dt = new DateTime(date);
		LOGGER.debug("Year: {} - Month: {} - Day: {}", dt.getYear(), dt.getMonthOfYear(), dt.getDayOfMonth());
		String str = String.valueOf(trxnId);
		String newTrxnId = ("000000" + str).substring(str.length());
		String calcSum = ctrlGenDt + newTrxnId;
		if (calcSum.length() != 14) {
			return null;
		}

		char[] a = calcSum.toCharArray();
		int i;
		int len = a.length;
		int mul;
		int sum;
		int m10;

		if (len != 14) {
			return null;
		}

		mul = 2;
		sum = 0;
		for (i = len - 2; i >= 0; i--) {
			if ((Integer.valueOf(a[i]) * mul) >= 10) {
				sum += ((Integer.valueOf(a[i]) * mul) / 10) + ((Integer.valueOf(a[i]) * mul) % 10);
			} else {
				sum += Integer.valueOf(a[i]) * mul;
			}

			if (mul == 2) {
				mul = 1;
			} else {
				mul = 2;
			}
		}

		LOGGER.info(SUM, sum);
		m10 = sum % 10;
		LOGGER.info(SUMDIGIT, sum);
		if (m10 > 10) {
			m10 = 10 - m10;
		}
		LOGGER.info(SUMDIGIT, m10);
		sb.append(m10);

		sb.append(newTrxnId);
		return sb.toString();
	}


	public static boolean checkTokenError(Exception e) {
		if (e instanceof IdmException) {
			IdmException ex = (IdmException) e;
			if (BaseUtil.isEqualsCaseIgnore(IdmErrorCodeEnum.I404IDM113.name(), ex.getInternalErrorCode())
					|| BaseUtil.isEqualsCaseIgnore(IdmErrorCodeEnum.I404IDM115.name(),
							ex.getInternalErrorCode())) {
				LOGGER.info("checkTokenError: IdmException: {} - {} ", ex.getInternalErrorCode(), ex.getMessage());
				return true;
			}
		}
		return false;
	}


	public static String genChksumNoDate(String ctrlGenDt, Integer trxnId) {

		StringBuilder sb = new StringBuilder();
		Date date = DateUtil.convertStrDateToDate(ctrlGenDt, BaseConstants.SIMPLE_DATE_FORMAT);
		DateTime dt = new DateTime(date);
		sb.append(ChkSumYearEnum.valueOf("YEAR_" + dt.getYear()).getSeq());
		sb.append(ChkSumMonthEnum.valueOf("MONTH_" + dt.getMonthOfYear()).getSeq());
		sb.append(ChkSumDayEnum.valueOf("DAY_" + dt.getDayOfMonth()).getSeq());

		String str = String.valueOf(trxnId);
		String newTrxnId = ("0000000" + str).substring(str.length());
		String calcSum = ctrlGenDt + str;

		char[] a = calcSum.toCharArray();
		int i;
		int len = a.length;
		int mul;
		int sum;
		int m10;

		mul = 2;
		sum = 0;
		for (i = len - 2; i >= 0; i--) {
			if ((Integer.valueOf(a[i]) * mul) >= 10) {
				sum += ((Integer.valueOf(a[i]) * mul) / 10) + ((Integer.valueOf(a[i]) * mul) % 10);
			} else {
				sum += Integer.valueOf(a[i]) * mul;
			}

			if (mul == 2) {
				mul = 1;
			} else {
				mul = 2;
			}
		}

		m10 = sum % 10;
		if (m10 > 10) {
			m10 = 10 - m10;
		}
		sb.append(m10);
		sb.append(newTrxnId);
		return sb.toString();
	}
}