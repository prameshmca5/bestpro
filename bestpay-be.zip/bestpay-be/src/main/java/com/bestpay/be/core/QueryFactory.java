/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.core;

import org.springframework.data.jpa.domain.Specification;

/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public abstract class QueryFactory<T> {

	public abstract Specification<T> searchByProperty(T t);

}
