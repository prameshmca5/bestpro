package com.bestpay.pgw.sdk.model;


import java.io.Serializable;


public class IRProfileResponse implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String merchantId;

	private String verifyKey;

	private String message;


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getVerifyKey() {
		return verifyKey;
	}


	public void setVerifyKey(String verifyKey) {
		this.verifyKey = verifyKey;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}

}
