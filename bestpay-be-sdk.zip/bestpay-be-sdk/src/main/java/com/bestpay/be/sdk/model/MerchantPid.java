package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


public class MerchantPid implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private Integer pidId;

	private String merchantId;

	private String mtoId;

	private String pid;

	private String createId;

	private Timestamp createDt;

	private Timestamp updateDt;

	private String updateId;


	public Integer getPidId() {
		return pidId;
	}


	public void setPidId(Integer pidId) {
		this.pidId = pidId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getMtoId() {
		return mtoId;
	}


	public void setMtoId(String mtoId) {
		this.mtoId = mtoId;
	}


	public String getPid() {
		return pid;
	}


	public void setPid(String pid) {
		this.pid = pid;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
