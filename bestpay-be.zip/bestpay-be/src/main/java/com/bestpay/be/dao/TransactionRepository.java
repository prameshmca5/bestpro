/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwConfig;
import com.bestpay.be.model.PgwTransaction;
import com.bestpay.be.model.PgwTransactionAmount;
import com.bestpay.be.util.QualifierConstants;


/**
 * N.N. Shuhada 05 June 2018
 */
@Repository
@RepositoryDefinition(domainClass = PgwTransaction.class, idClass = Integer.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_TRANSACTION_DAO)
public interface TransactionRepository extends GenericRepository<PgwTransaction> {

	@Query("select count(u) from PgwTransaction u")
	int totalRecords();


	@Query("select u from PgwConfig u where u.configCode= :configCode ")
	PgwConfig findByConfigCode(@Param("configCode") String configCode);


	@Query("select t from PgwTransaction t where t.transId = :transId ")
	PgwTransaction findUserByTranId(@Param("transId") String transId);


	@Query("select t from PgwTransaction t where t.merchantId = :merchantId and t.status='success' and t.setId=:setId and t.paymentDt >= :startDate and t.paymentDt <= :endDate")
	List<PgwTransaction> findTransactionByMerchantAndSetId(@Param("merchantId") String merchantId,
			@Param("setId") int setId, @Param("startDate") Date startDate, @Param("endDate") Date endDate);


	@Query("select new com.bestpay.be.model.PgwTransactionAmount(merchantId,sum(billAmt) as billAmount, sum(transRate) as transactionRate,sum(actAmt) as actAmt) from PgwTransaction t where t.merchantId = :merchantId and t.status='success'"
			+ " and t.setId='0' and paymentDt >= :startDate and paymentDt <= :endDate group by merchantId")
	PgwTransactionAmount findSumTransactionByMerchantId(@Param("merchantId") String merchantId,
			@Param("startDate") Date startDate, @Param("endDate") Date endDate);


	@Modifying
	@Query("update PgwTransaction t set t.setId=:setId where t.merchantId= :merchantId and t.status='success' and t.setId='0'and t.paymentDt >= :startDate and t.paymentDt <= :endDate ")
	int updateTransactionByMerchant(@Param("merchantId") String merchantId, @Param("setId") Integer setId,
			@Param("startDate") Date startDate, @Param("endDate") Date endDate);


	@Query("select t from PgwTransaction t where t.merchantId = :merchantId and t.setId= :setId ")
	List<PgwTransaction> findDetailBySetIdByAllTransaction(@Param("merchantId") String merchantId,
			@Param("setId") Integer setId);


	@Query("select t from PgwTransaction t where  t.setId= :setId ")
	List<PgwTransaction> findDetailBySetIdByAllTrans(@Param("setId") Integer setId);


	@Query("select round(sum(t.billAmt),2) from PgwTransaction t where t.setId=0 and t.status='success' ")
	double getSumOfBillAmt();


	@Query("select t from PgwTransaction t where t.channel = :channel and t.status='success' and t.setId=:setId and t.paymentDt >= :startDate and t.paymentDt <= :endDate")
	List<PgwTransaction> findTransactionByChannelAndSetID(@Param("channel") String channel, @Param("setId") int setId,
			@Param("startDate") Date startDate, @Param("endDate") Date endDate);


	@Query("select new com.bestpay.be.model.PgwTransactionAmount(channel,sum(billAmt) as billAmount, sum(transRate) as transactionRate,sum(actAmt) as actAmt) from PgwTransaction t where t.channel = :channel and t.status='success'"
			+ " and t.setId='0' and paymentDt >= :startDate and paymentDt <= :endDate group by channel")
	PgwTransactionAmount findSumTransactionByChannel(@Param("channel") String channel,
			@Param("startDate") Date startDate, @Param("endDate") Date endDate);


	@Modifying
	@Query("update PgwTransaction t set t.setId=:setId where t.channel= :channel and t.status='success' and t.setId='0'and t.paymentDt >= :startDate and t.paymentDt <= :endDate ")
	int updateTransactionByChannel(@Param("channel") String channel, @Param("setId") Integer setId,
			@Param("startDate") Date startDate, @Param("endDate") Date endDate);


	@Query("select count(u) from PgwTransaction u where u.channel = :channel and u.status='success' and u.setId='0' and u.paymentDt >= :startDate and u.paymentDt <= :endDate group by u.channel")
	int findTotalTransactionByChannel(@Param("channel") String channel, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate);

}