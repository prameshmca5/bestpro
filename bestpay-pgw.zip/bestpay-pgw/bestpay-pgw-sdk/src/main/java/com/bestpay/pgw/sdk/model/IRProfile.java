package com.bestpay.pgw.sdk.model;


public class IRProfile {

	private static final long serialVersionUID = 1L;

	private String registrationNo;

	private String apsName;

	private String ownerName;

	private String ownerNationalId;

	private String ownerPhoneNo;

	private String ownerEmail;

	private String ownerAddress;

	private String ownerAddress2;

	private String ownerAddress3;

	private String ownerState;

	private String ownerCity;

	private String ownerPostCode;

	private String ownerCountry;

	private String ownerNationality;

	private String picName;

	private String picNationalId;

	private String picPhoneNo;

	private String picEmail;

	private String apsBankName;

	private String apsBankAccountNo;

	private String apsBankAddress;

	private String apsState;

	private String apsCity;

	private String apsPostCode;

	private String natureOfBusiness;

	private String apsType;

	private String apsCountry;

	private String companyReferenceId;

	private String beneficiaryId;

	private String senderPhoto;

	private String senderPhoto1;


	public String getRegistrationNo() {
		return registrationNo;
	}


	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}


	public String getApsName() {
		return apsName;
	}


	public void setApsName(String apsName) {
		this.apsName = apsName;
	}


	public String getOwnerName() {
		return ownerName;
	}


	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}


	public String getOwnerNationalId() {
		return ownerNationalId;
	}


	public void setOwnerNationalId(String ownerNationalId) {
		this.ownerNationalId = ownerNationalId;
	}


	public String getOwnerPhoneNo() {
		return ownerPhoneNo;
	}


	public void setOwnerPhoneNo(String ownerPhoneNo) {
		this.ownerPhoneNo = ownerPhoneNo;
	}


	public String getOwnerEmail() {
		return ownerEmail;
	}


	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}


	public String getOwnerAddress() {
		return ownerAddress;
	}


	public void setOwnerAddress(String ownerAddress) {
		this.ownerAddress = ownerAddress;
	}


	public String getOwnerAddress2() {
		return ownerAddress2;
	}


	public void setOwnerAddress2(String ownerAddress2) {
		this.ownerAddress2 = ownerAddress2;
	}


	public String getOwnerAddress3() {
		return ownerAddress3;
	}


	public void setOwnerAddress3(String ownerAddress3) {
		this.ownerAddress3 = ownerAddress3;
	}


	public String getOwnerState() {
		return ownerState;
	}


	public void setOwnerState(String ownerState) {
		this.ownerState = ownerState;
	}


	public String getOwnerCity() {
		return ownerCity;
	}


	public void setOwnerCity(String ownerCity) {
		this.ownerCity = ownerCity;
	}


	public String getOwnerPostCode() {
		return ownerPostCode;
	}


	public void setOwnerPostCode(String ownerPostCode) {
		this.ownerPostCode = ownerPostCode;
	}


	public String getOwnerCountry() {
		return ownerCountry;
	}


	public void setOwnerCountry(String ownerCountry) {
		this.ownerCountry = ownerCountry;
	}


	public String getOwnerNationality() {
		return ownerNationality;
	}


	public void setOwnerNationality(String ownerNationality) {
		this.ownerNationality = ownerNationality;
	}


	public String getPicName() {
		return picName;
	}


	public void setPicName(String picName) {
		this.picName = picName;
	}


	public String getPicNationalId() {
		return picNationalId;
	}


	public void setPicNationalId(String picNationalId) {
		this.picNationalId = picNationalId;
	}


	public String getPicPhoneNo() {
		return picPhoneNo;
	}


	public void setPicPhoneNo(String picPhoneNo) {
		this.picPhoneNo = picPhoneNo;
	}


	public String getPicEmail() {
		return picEmail;
	}


	public void setPicEmail(String picEmail) {
		this.picEmail = picEmail;
	}


	public String getApsBankName() {
		return apsBankName;
	}


	public void setApsBankName(String apsBankName) {
		this.apsBankName = apsBankName;
	}


	public String getApsBankAccountNo() {
		return apsBankAccountNo;
	}


	public void setApsBankAccountNo(String apsBankAccountNo) {
		this.apsBankAccountNo = apsBankAccountNo;
	}


	public String getApsBankAddress() {
		return apsBankAddress;
	}


	public void setApsBankAddress(String apsBankAddress) {
		this.apsBankAddress = apsBankAddress;
	}


	public String getApsState() {
		return apsState;
	}


	public void setApsState(String apsState) {
		this.apsState = apsState;
	}


	public String getApsCity() {
		return apsCity;
	}


	public void setApsCity(String apsCity) {
		this.apsCity = apsCity;
	}


	public String getApsPostCode() {
		return apsPostCode;
	}


	public void setApsPostCode(String apsPostCode) {
		this.apsPostCode = apsPostCode;
	}


	public String getNatureOfBusiness() {
		return natureOfBusiness;
	}


	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}


	public String getApsType() {
		return apsType;
	}


	public void setApsType(String apsType) {
		this.apsType = apsType;
	}


	public String getApsCountry() {
		return apsCountry;
	}


	public void setApsCountry(String apsCountry) {
		this.apsCountry = apsCountry;
	}


	public String getCompanyReferenceId() {
		return companyReferenceId;
	}


	public void setCompanyReferenceId(String companyReferenceId) {
		this.companyReferenceId = companyReferenceId;
	}


	public String getBeneficiaryId() {
		return beneficiaryId;
	}


	public void setBeneficiaryId(String beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}


	public String getSenderPhoto() {
		return senderPhoto;
	}


	public void setSenderPhoto(String senderPhoto) {
		this.senderPhoto = senderPhoto;
	}


	public String getSenderPhoto1() {
		return senderPhoto1;
	}


	public void setSenderPhoto1(String senderPhoto1) {
		this.senderPhoto1 = senderPhoto1;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
