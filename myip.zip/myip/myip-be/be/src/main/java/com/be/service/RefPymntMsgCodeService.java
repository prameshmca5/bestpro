/**
 * 
 */
package com.be.service;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.ConfigConstants;
import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.RefPymntMsgCodeQf;
import com.be.dao.RefPymntMsgCodeRepository;
import com.be.model.RefPymntMsgCode;
import com.be.sdk.constants.BeCacheConstants;
import com.be.sdk.model.IQfCriteria;

/**
 * @author michelle.angela
 *
 */
@Lazy
@Transactional
@Service(QualifierConstants.REF_PYMNT_MSG_CODE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_PYMNT_MSG_CODE_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
public class RefPymntMsgCodeService extends AbstractService<RefPymntMsgCode> {

	@Autowired
	private RefPymntMsgCodeRepository refPymntMsgCodeDao;
	
	@Autowired
	private RefPymntMsgCodeQf refPymntMsgCodeQf;
	
	@Override
	public GenericRepository<RefPymntMsgCode> primaryDao() {
		return refPymntMsgCodeDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return refPymntMsgCodeQf.generateCriteria(cb, from, criteria);
	}
	
	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_MSGCODE_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<RefPymntMsgCode> getAllMsgCode() {
		return refPymntMsgCodeDao.findAll();
	}

}
