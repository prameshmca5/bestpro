/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.builder;


import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.bestpay.pgw.sdk.client.PgwRestTemplate;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.model.City;
import com.bestpay.pgw.sdk.model.Config;
import com.bestpay.pgw.sdk.model.Country;
import com.bestpay.pgw.sdk.model.Nationality;
import com.bestpay.pgw.sdk.model.RefDocuments;
import com.bestpay.pgw.sdk.model.RefEmbedRequest;
import com.bestpay.pgw.sdk.model.RefEmbedResponse;
import com.bestpay.pgw.sdk.model.RelationShip;
import com.bestpay.pgw.sdk.model.State;
import com.bestpay.pgw.sdk.model.StaticList;
import com.bestpay.pgw.sdk.model.Status;
import com.bestpay.pgw.sdk.util.BaseUtil;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
public class ReferenceService extends AbstractService {

	private PgwRestTemplate restTemplate;

	private Properties prop;

	private String url;


	public ReferenceService(PgwRestTemplate restTemplate, Properties prop, String url) {
		this.restTemplate = restTemplate;
		this.prop = prop;
		this.url = url;
	}


	@Override
	public PgwRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public Properties prop() {
		return prop;
	}


	@Override
	public String url() {
		return url;
	}


	public boolean evict() {
		return evict(null);
	}


	public boolean evict(String prefixKey) {
		StringBuilder sbUrl = new StringBuilder();
		sbUrl.append(PgwUrlConstants.REFERENCE).append("/evict");
		if (!BaseUtil.isObjNull(prefixKey)) {
			sbUrl.append("?prefixKey=" + prefixKey);
		}
		return restTemplate().getForObject(getServiceURI(sbUrl.toString()), boolean.class);

	}

 
	@SuppressWarnings("unchecked")
	public Map<String, String> findAllConfig() {
		return restTemplate().getForObject(getServiceURI(PgwUrlConstants.REFERENCE + PgwUrlConstants.APJ_CONFIG),
				HashMap.class);
	}


	public List<Config> findEqmConfig() {
		Config[] svcResp = restTemplate().getForObject(PgwUrlConstants.APJ_CONFIG, Config[].class);
		return Arrays.asList(svcResp);
	}


	public List<Config> findEqmConfig(String configAgency) {
		StringBuilder sbUrl = new StringBuilder();
		sbUrl.append(PgwUrlConstants.APJ_CONFIG).append("/{configAgency}");

		Map<String, Object> params = new HashMap<>();
		params.put("configAgency", configAgency);

		Config[] svcResp = restTemplate().getForObject(sbUrl.toString(), Config[].class, params);
		return Arrays.asList(svcResp);
	}


	public List<Country> getRefCountryLst() {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.REF_REF_COUNTRY);
		Country[] refStats = restTemplate().getForObject(getServiceURI(sb.toString()), Country[].class);
		return Arrays.asList(refStats);
	}

 
	public List<City> findByAllCities() {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.CITY);
		City[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), City[].class);

		return Arrays.asList(svcResp);
	}


	// find city
	public City findByCityCode(String cityCode) {
		return restTemplate().getForObject(getServiceURI(PgwUrlConstants.CITY + "/" + cityCode), City.class);

	}


	// find city by city and state code
	public City fidCityByCityStateCode(String cityCode, String stateCode) {
		return restTemplate().getForObject(getServiceURI(PgwUrlConstants.CITY + "/" + cityCode + "/" + stateCode),
				City.class);

	}


	public List<RefDocuments> getRefDocLst() {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.REFERENCE + "/refDocList");
		RefDocuments[] refStats = restTemplate().getForObject(getServiceURI(sb.toString()), RefDocuments[].class);
		return Arrays.asList(refStats);
	}


	// list status
	public List<Status> findByAllStatus() {
		Status[] svcResp = restTemplate().getForObject(getServiceURI(PgwUrlConstants.STATUS), Status[].class);
		return Arrays.asList(svcResp);
	}


	// find status
 	public Status findByStatusCodeAndType(String statusCode) {
		Status svcResp = null;
		Map<String, Object> params = new HashMap<>();
		params.put("statusCode", statusCode);
		svcResp = restTemplate().getForObject(getServiceURI(PgwUrlConstants.STATUS + "/{statusCode}"), Status.class,
				params);
		return svcResp;
	}


	// add status
	public Status addStatus(Status status) {
		return restTemplate().postForObject(getServiceURI(PgwUrlConstants.STATUS), status, Status.class);
	}


	// update status
	public boolean updatStatus(Status status) {
		return restTemplate().putForObject(getServiceURI(PgwUrlConstants.STATUS), status, boolean.class, null);
	}


	public StaticList all() {
		StaticList svcResp = null;
		StringBuilder sbUrl = new StringBuilder();
		sbUrl.append(PgwUrlConstants.REFERENCE);
		svcResp = restTemplate().getForObject(getServiceURI(sbUrl.toString()), StaticList.class);
		return svcResp;
	}


	// list relation
	public List<RelationShip> findAllRelationShips() {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.REFERENCE);
		sb.append(PgwUrlConstants.GET_ALL_RELATIONSHIP);
		RelationShip[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), RelationShip[].class);
		return Arrays.asList(svcResp);
	}


	// list of state
	public List<State> findAllState() {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.REFERENCE);
		sb.append(PgwUrlConstants.GET_ALL_STATE);
		State[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), State[].class);
		return Arrays.asList(svcResp);
	}


	// list of state with countries
	public List<Country> allCountry() {
		List<Country> countryList = null;
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.REFERENCE);
		sb.append(PgwUrlConstants.GET_ALL_COUNTRY);

		Country[] countryArray = restTemplate().getForObject(getServiceURI(sb.toString()), Country[].class);

		countryList = Arrays.asList(countryArray);
		return countryList;
	}


	// list of nationality
	public List<Nationality> findAllNationality() {
		List<Nationality> nationalityList = null;
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.REFERENCE);
		sb.append(PgwUrlConstants.GET_ALL_NATIONALITY);

		Nationality[] nationalityArray = restTemplate().getForObject(getServiceURI(sb.toString()),
				Nationality[].class);

		nationalityList = Arrays.asList(nationalityArray);
		return nationalityList;
	}


	// nationality by code
	public Nationality findByNationalityCode(String ntnltyCode) {
		Nationality nationality = null;
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.REFERENCE);
		sb.append(PgwUrlConstants.GET_ALL_NATIONALITY_CODE);
		sb.append("/" + ntnltyCode);

		nationality = restTemplate().getForObject(getServiceURI(sb.toString()), Nationality.class);

		return nationality;
	}


	// nationality by description
	public Nationality findNationalityByDesc(String ntnltyDescEn) {
		Nationality nationality = null;
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.REFERENCE);
		sb.append(PgwUrlConstants.GET_ALL_NATIONALITY_DESC);
		sb.append("/" + ntnltyDescEn);
		nationality = restTemplate().getForObject(getServiceURI(sb.toString()), Nationality.class);
		return nationality;
	}


	public List<Status> getAllStatus() {
		List<Status> statusList = null;
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.REFERENCE);
		sb.append(PgwUrlConstants.GET_ALL_STAUS);
		Status[] statusArray = restTemplate().getForObject(getServiceURI(sb.toString()), Status[].class);
		statusList = Arrays.asList(statusArray);
		return statusList;
	}


	public RefEmbedResponse getRrefData(RefEmbedRequest refEmbedRequest) {
		return restTemplate().postForObject(getServiceURI(PgwUrlConstants.REFERENCE + "/refData"), refEmbedRequest,
				RefEmbedResponse.class);
	}
}