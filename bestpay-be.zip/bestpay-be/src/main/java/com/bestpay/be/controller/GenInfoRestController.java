/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwBankDetails;
import com.bestpay.be.model.PgwMerchantContact;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerGenInfo;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.MER_GENG_INFO)
public class GenInfoRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(GenInfoRestController.class);


	@GetMapping(consumes = { MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MerGenInfo findMerContact(@RequestParam(value = "tag", required = false) String tag,
			@RequestParam(value = "value", required = false) String value) {
		if (BaseUtil.isEqualsCaseIgnore(tag, "email")) {
			super.pgwMerchantContactService.findMerchantForBlacklistByEmail(value);
		} else {
			super.pgwMerchantContactService.findMerchantForBlacklistByMobile(value);
		}

		MerGenInfo merGenInfo = new MerGenInfo();
		PgwMerchantContact pgwMerchantContact = new PgwMerchantContact();
		if (!BaseUtil.isObjNull(pgwMerchantContact)) {
			merGenInfo = dozerMapper.map(pgwMerchantContact, MerGenInfo.class);
		}
		return merGenInfo;
	}


	@GetMapping(value = "/{merchantId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerGenInfo findMerContactByMerchantId(@PathVariable String merchantId) {

		PgwMerchantContact genInfo = super.pgwMerchantContactService.findMerContactByMerchantId(merchantId);

		MerGenInfo merCtct = new MerGenInfo();
		if (!BaseUtil.isObjNull(genInfo)) {
			merCtct = dozerMapper.map(genInfo, MerGenInfo.class);
		}

		if (BaseUtil.isEqualsCaseIgnore(merCtct.getCountry(), "MYS")) {
			merCtct.setStateMy(merCtct.getState());
			merCtct.setCityMy(merCtct.getCity());
		} else {
			merCtct.setStateNonMy(merCtct.getState());
			merCtct.setCityNonMy(merCtct.getCity());
		}

		return merCtct;
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerGenInfo updateMerchantContact(@Valid @RequestBody MerGenInfo merGenInfo, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		LOGGER.info("Create new merchant profile ... ");
		if (merGenInfo == null) {// generalInfo null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		if (StringUtils.isBlank(merGenInfo.getMerchantId())) {// no merchant
			// name
			throw new BeException(BeErrorCodeEnum.I400IDM137, new String[] { "Merchant Name", "Merchant Profile" });
		}

		PgwMerchantContact merProfile = new PgwMerchantContact();
		PgwBankDetails accountSetting = new PgwBankDetails();

		PgwMerchantContact genInfo = super.pgwMerchantContactService
				.findMerContactByMerchantId(merGenInfo.getMerchantId());
		PgwBankDetails accSet = super.pgwBankDetailsService.findBankDetailsByMerchantId(merGenInfo.getMerchantId());

		if (BaseUtil.isObjNull(merGenInfo.getCcEmail())) {
			merGenInfo.setCcEmail("0");
		}

		if (BaseUtil.isObjNull(genInfo)) {
			merProfile.setMerchantId(merGenInfo.getMerchantId());
			merProfile.setName(merGenInfo.getName());
			merProfile.setPhone(merGenInfo.getPhone());
			merProfile.setMphone(merGenInfo.getMphone());
			merProfile.setFax(merGenInfo.getFax());
			merProfile.setEmail(merGenInfo.getEmail());
			merProfile.setEmail2(merGenInfo.getEmail2());
			merProfile.setState(merGenInfo.getState());
			merProfile.setPostcode(merGenInfo.getPostcode());
			merProfile.setCity(merGenInfo.getCity());
			merProfile.setAddress(merGenInfo.getAddress());
			merProfile.setAddress2(merGenInfo.getAddress2());
			merProfile.setAddress3(merGenInfo.getAddress3());
			merProfile.setCountry(merGenInfo.getCountry());
			merProfile.setCreateId(merGenInfo.getUserId());
			super.pgwMerchantContactService.create(merProfile);

			accountSetting.setMerchantId(merGenInfo.getMerchantId());
			accountSetting.setAccType("COM");
			accountSetting.setIcType("ROBROC");
			accountSetting.setIcNumber(merGenInfo.getRocNo());
			super.pgwBankDetailsService.create(accountSetting);
		} else {
			genInfo.setMerchantId(merGenInfo.getMerchantId());
			genInfo.setName(merGenInfo.getName());
			genInfo.setPhone(merGenInfo.getPhone());
			genInfo.setMphone(merGenInfo.getMphone());
			genInfo.setFax(merGenInfo.getFax());
			genInfo.setEmail(merGenInfo.getEmail());
			genInfo.setEmail2(merGenInfo.getEmail2());
			genInfo.setState(merGenInfo.getState());
			genInfo.setPostcode(merGenInfo.getPostcode());
			genInfo.setCity(merGenInfo.getCity());
			genInfo.setAddress(merGenInfo.getAddress());
			genInfo.setAddress2(merGenInfo.getAddress2());
			genInfo.setAddress3(merGenInfo.getAddress3());
			genInfo.setCountry(merGenInfo.getCountry());
			genInfo.setUpdateId(merGenInfo.getUserId());
			super.pgwMerchantContactService.update(genInfo);

			accSet.setIcNumber(merGenInfo.getRocNo());
			super.pgwBankDetailsService.update(accSet);
		}

		MerGenInfo merContact = new MerGenInfo();
		PgwMerchantContact updatGenInfo = super.pgwMerchantContactService
				.findMerContactByMerchantId(merGenInfo.getMerchantId());

		PgwBankDetails updatAccSet = super.pgwBankDetailsService
				.findBankDetailsByMerchantId(merGenInfo.getMerchantId());

		if (!BaseUtil.isObjNull(updatGenInfo)) {
			merContact = dozerMapper.map(updatGenInfo, MerGenInfo.class);
			merContact.setRocNo(updatAccSet.getIcNumber());
		}

		return merContact;
	}

}
