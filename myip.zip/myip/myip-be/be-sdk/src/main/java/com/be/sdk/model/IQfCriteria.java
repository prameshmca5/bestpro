/**
 * Copyright 2019.
 */
package com.be.sdk.model;


/**
 * @author mary.jane
 *
 */
public interface IQfCriteria<T> {

}
