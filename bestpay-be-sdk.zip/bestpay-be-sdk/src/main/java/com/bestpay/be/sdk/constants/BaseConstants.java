/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BaseConstants {

	private BaseConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String EMPTY_STRING = "";

	public static final String SPACE = " ";

	public static final String COMMA = ",";

	public static final String SLASH = "/";

	public static final String DASH = "-";

	public static final Integer ZERO = 0;

	public static final String DAY = "DAY";

	public static final String MONTH = "MONTH";

	public static final String YEAR = "YEAR";

	public static final String FIRST_TIME_PWRD = "F";

	/* Date & Time Constants */
	public static final String SIMPLE_TIMESTAMP_FORMAT = "yyyyMMddHHmmss";

	public static final String DT_FORMAT = "yyyyMMdd";

	public static final String DT_TIME_A = "HH:mm a";

	public static final String DT_TIME_S = "HH:mm:ss";

	public static final String DT_TIME_MS = "HH:mm:ss.s";

	public static final String DT_YYYY_MM_DD_DASH = "yyyy-MM-dd";

	public static final String DT_YYYY_MM_DD_DASH_TIME_A = "yyyy-MM-dd HH:mm a";

	public static final String DT_YYYY_MM_DD_DASH_TIME_S = "yyyy-MM-dd HH:mm:ss";

	public static final String DT_YYYY_MM_DD_DASH_TIME_MS = "yyyy-MM-dd HH:mm:ss.s";

	public static final String DT_YYYY_MM_DD_SLASH = "yyyy/MM/dd";

	public static final String DT_YYYY_MM_DD_SLASH_TIME_A = "yyyy/MM/dd HH:mm a";

	public static final String DT_YYYY_MM_DD_SLASH_TIME_S = "yyyy/MM/dd HH:mm:ss";

	public static final String DT_YYYY_MM_DD_SLASH_TIME_MS = "yyyy/MM/dd HH:mm:ss.s";

	public static final String DT_DD_MM_YYYY_DASH = "dd-MM-yyyy";

	public static final String DT_DD_MM_YYYY_DASH_TIME_A = "dd-MM-yyyy hh:mm a";

	public static final String DT_DD_MM_YYYY_DASH_TIME_S = "dd-MM-yyyy HH:mm:ss";

	public static final String DT_DD_MM_YYYY_DASH_TIME_MS = "dd-MM-yyyy HH:mm:ss.s";

	public static final String DT_DD_MM_YYYY_SLASH = "dd/MM/yyyy";

	public static final String DT_DD_MM_YYYY_SLASH_TIME_A = "dd/MM/yyyy hh:mm a";

	public static final String DT_DD_MM_YYYY_SLASH_TIME_S = "dd/MM/yyyy HH:mm:ss";

	public static final String DT_DD_MM_YYYY_SLASH_TIME_MS = "dd/MM/yyyy HH:mm:ss.s" + "";

	public static final String DT_DD_MMMM_YYYY = "dd MMMM yyyy";

	public static final String DT_DD_MMMM_YYYY_TIME_A = "dd MMMM yyyy hh:mm a";

	protected static final String HEADER_MESSAGE_ID = "X-Message-Id";

	protected static final String HEADER_AUTHORIZATION = "Authorization";

	protected static final String PERMISSION_CODE = "txnNo";

	public static final String WRKR_STAT_APR = "APR";

	public static final String WRKR_STAT_REJ = "REJ";

	public static final String INTERVIEW_VENUE = "One Stop Centre, Bahagian Pengurusan Pekerja Asing, Kementerian Dalam Negeri, Putrajaya.";

	public static final String INTERVIEW_TIME = "9 am – 5 pm (First come, first serve basis)";

	public static final String BRANCH_OLD = "0";

	public static final String BRANCH_NEW = "1";

	public static final String SITE_ID = "siteId";

	public static final String STATUS_ACTIVE = "A";

	public static final String STATUS_INACTIVE = "I";

	public static final String YES = "Y";

	public static final String NO = "N";

	public static final String INDICATOR_Y = "Y";

	public static final String INDICATOR_N = "N";

}
