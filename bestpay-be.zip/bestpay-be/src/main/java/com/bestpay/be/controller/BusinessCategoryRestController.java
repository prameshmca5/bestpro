/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwBusinessCategory;
import com.bestpay.be.model.RefCategory;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerBusCat;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;

/**
 * @author Afif Saman
 * @since July 19, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.BUS_CAT)
public class BusinessCategoryRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BusinessCategoryRestController.class);

	@GetMapping(value = "/{merchantId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerBusCat getMerBusCatById(@PathVariable String merchantId) {

		PgwBusinessCategory pgwbusinessCategory = pgwBusinessCategoryService
				.findBusinessCategoryByMerchantId(merchantId);
		MerBusCat merBusCat = new MerBusCat();
		if (!BaseUtil.isObjNull(pgwbusinessCategory)) {
			merBusCat = dozerMapper.map(pgwbusinessCategory, MerBusCat.class);
		}
		if (!BaseUtil.isObjNull(merBusCat) && !BaseUtil.isObjNull(merBusCat.getCategory())) {
			merBusCat.setCatList(Arrays.asList(merBusCat.getCategory().split(",")));
		}
		return merBusCat;
	}

	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public boolean updateBusinessCategory(@Valid @RequestBody MerBusCat merBusCat, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		LOGGER.info("Create new Business Category ... ");
		if (merBusCat == null) {// Business Category null
			throw new BeException(BeErrorCodeEnum.E404BCC001);
		}

		PgwBusinessCategory pgwbusinessCategory = pgwBusinessCategoryService
				.findBusinessCategoryByMerchantId(merBusCat.getMerchantId());
		String newCategory = "";
		if (!BaseUtil.isObjNull(merBusCat.getAddNewCat()) && merBusCat.getAddNewCat() == 1) {
			if (!BaseUtil.isObjNull(merBusCat.getCategory())) {
				newCategory = merBusCat.getCategory() + "," + merBusCat.getNewMerCat();
			} else {
				newCategory = merBusCat.getNewMerCat();
			}
			RefCategory refCategory = new RefCategory();
			refCategory.setCategoryName(merBusCat.getNewMerCat());
			refCategory.setCreateId(merBusCat.getUserId());
			refCategory.setUpdateId(merBusCat.getUserId());
			super.refCategoryService.create(refCategory);
		}

		if (BaseUtil.isObjNull(pgwbusinessCategory)) {
			PgwBusinessCategory newBusinessCategory = dozerMapper.map(merBusCat, PgwBusinessCategory.class);
			newBusinessCategory.setCreateId(merBusCat.getUserId());
			newBusinessCategory.setUpdateId(merBusCat.getUserId());
			if (!BaseUtil.isObjNull(merBusCat.getAddNewCat()) && merBusCat.getAddNewCat() == 1) {
				newBusinessCategory.setCategory(newCategory);
			}
			super.pgwBusinessCategoryService.create(newBusinessCategory);
		} else {
			if (!BaseUtil.isObjNull(merBusCat.getAddNewCat()) && merBusCat.getAddNewCat() == 1) {
				pgwbusinessCategory.setCategory(newCategory);
			} else {
				pgwbusinessCategory.setCategory(merBusCat.getCategory());
			}
			pgwbusinessCategory.setUpdateId(merBusCat.getUserId());
			super.pgwBusinessCategoryService.update(pgwbusinessCategory);
		}

		return true;
	}

}
