/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwFraudSetting;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerFraudSet;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;

/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.MER_FRAUD_SET)
public class FraudSetRestController extends AbstractRestController {

	@GetMapping(value = "/{merchantId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerFraudSet findFraudSettingByMerchantId(@PathVariable String merchantId) {

		PgwFraudSetting fraudSet = super.pgwFraudSettingService.findFraudSettingByMerchantId(merchantId);

		MerFraudSet merFraudSet = new MerFraudSet();
		if (!BaseUtil.isObjNull(fraudSet)) {
			merFraudSet = dozerMapper.map(fraudSet, MerFraudSet.class);
		}
		return merFraudSet;
	}

	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerFraudSet updateFraudSetting(@Valid @RequestBody MerFraudSet merFraudSet, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		if (merFraudSet == null) {// fraudSetting null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		if (StringUtils.isBlank(merFraudSet.getMerchantId())) {// no merchant
			// name
			throw new BeException(BeErrorCodeEnum.I400IDM137, new String[] { "Merchant Name", "Merchant Profile" });
		}

		PgwFraudSetting merFrdSet = new PgwFraudSetting();
		PgwFraudSetting frdSet = super.pgwFraudSettingService.findFraudSettingByMerchantId(merFraudSet.getMerchantId());

		if (BaseUtil.isObjNull(frdSet)) {
			merFrdSet.setMerchantId(merFraudSet.getMerchantId());
			merFrdSet.setMaxallowFraudscore(merFraudSet.getMaxallowFraudscore());
			merFrdSet.setAllowMyIp(merFraudSet.getAllowMyIp());
			merFrdSet.setAllowMyCc(merFraudSet.getAllowMyCc());
			merFrdSet.setAllowIpccMatch(merFraudSet.getAllowIpccMatch());
			merFrdSet.setCreateId(merFraudSet.getUserId());
			super.pgwFraudSettingService.create(merFrdSet);
		} else {
			frdSet.setMerchantId(merFraudSet.getMerchantId());
			frdSet.setMaxallowFraudscore(merFraudSet.getMaxallowFraudscore());
			frdSet.setAllowMyIp(merFraudSet.getAllowMyIp());
			frdSet.setAllowMyCc(merFraudSet.getAllowMyCc());
			frdSet.setAllowIpccMatch(merFraudSet.getAllowIpccMatch());
			frdSet.setUpdateId(merFraudSet.getUserId());
			super.pgwFraudSettingService.update(frdSet);
		}

		MerFraudSet fraudSet = new MerFraudSet();
		PgwFraudSetting updatFrdSet = super.pgwFraudSettingService
				.findFraudSettingByMerchantId(merFraudSet.getMerchantId());
		if (!BaseUtil.isObjNull(updatFrdSet)) {
			fraudSet = dozerMapper.map(updatFrdSet, MerFraudSet.class);
		}
		return fraudSet;
	}

}
