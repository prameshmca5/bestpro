/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dialect.processor;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.thymeleaf.Arguments;
import org.thymeleaf.dom.Element;
import org.thymeleaf.processor.ProcessorResult;
import org.thymeleaf.util.StringUtils;

import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.dialect.AbstractBstElement;
import com.bestpay.web.dialect.constants.AttributeConstants;
import com.bestpay.web.dialect.constants.ElementConstants;
import com.bestpay.web.dialect.constants.ElementEnum;
import com.bestpay.web.dialect.constants.ElementHelper;
import com.bestpay.web.dialect.constants.StyleConstants;


/**
 * Convert the <bst:input-*> node to a normal <input> node
 * 
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class InputElementProcessor extends AbstractBstElement {

	private static final Logger LOGGER = LoggerFactory.getLogger(InputElementProcessor.class);


	public InputElementProcessor(String elementName) {
		super(elementName);
	}


	@Override
	protected ProcessorResult processElement(Arguments arguments, Element element) {
		LOGGER.debug("Processing Input Element...");
		String elementNm = getElementName(element);

		Element newElement = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_INPUT,
				false);
		newElement.setRecomputeProcessorsImmediately(true);

		// Set TYPE Attribute
		if (StringUtils.equals(elementNm, ElementEnum.RADIO.getName())) {
			newElement.setAttribute(AttributeConstants.ATTR_TYPE, AttributeConstants.ATTR_TYPE_RADIO);

		} else if (StringUtils.equals(elementNm, ElementEnum.CHECKBOX.getName())) {
			newElement.setAttribute(AttributeConstants.ATTR_TYPE, AttributeConstants.ATTR_TYPE_CHECKBOX);

		} else if (StringUtils.equals(elementNm, ElementEnum.INPUT_HIDDEN.getName())) {
			newElement.setAttribute(AttributeConstants.ATTR_TYPE, AttributeConstants.ATTR_TYPE_HIDDEN);

		} else if (StringUtils.equals(elementNm, ElementEnum.INPUT_PASSWORD.getName())) {
			newElement.setAttribute(AttributeConstants.ATTR_TYPE, AttributeConstants.ATTR_TYPE_PWORD);

		} else {
			if (element.getAttributeValue("type") != null) {
				newElement.setAttribute(AttributeConstants.ATTR_TYPE, element.getAttributeValue("type"));
			} else {
				newElement.setAttribute(AttributeConstants.ATTR_TYPE, AttributeConstants.ATTR_TYPE_TEXT);
			}
		}

		// Set CLASS Attribute
		String classVal = ElementEnum.findStyleByName(elementNm);

		if (element.getAttributeValue(AttributeConstants.ATTR_CLASS) != null) {
			classVal = classVal + StyleConstants.SPACE + element.getAttributeValue(AttributeConstants.ATTR_CLASS);
		}

		if (StringUtils.equals(elementNm, ElementEnum.INPUT_AMOUNT.getName())) {
			classVal = classVal + StyleConstants.SPACE + "input-amount";
		}

		if (StringUtils.equals(elementNm, ElementEnum.INPUT_NUMBER.getName())) {
			classVal = classVal + StyleConstants.SPACE + "limit-number";
		}

		if (classVal != null)
			newElement.setAttribute(AttributeConstants.ATTR_CLASS, classVal);

		// Process Time Picker
		if (StringUtils.equals(elementNm, ElementEnum.INPUT_TIME.getName())) {
			newElement = ElementHelper.processTimePicker(newElement);
		} else if (StringUtils.equals(elementNm, ElementEnum.INPUT_DATE.getName())) {
			newElement = ElementHelper.processDatePicker(newElement);
		} else if (StringUtils.equals(elementNm, ElementEnum.RADIO.getName())) {
			newElement = ElementHelper.processRadioButton(newElement);
		} else if (StringUtils.equals(elementNm, ElementEnum.CHECKBOX.getName())) {
			newElement = ElementHelper.processCheckboxButton(newElement);
		}

		if (element.getAttributeValue("lbl") != null) {
			String forVal = element.getAttributeValue(AttributeConstants.ATTR_NAME);
			if (BaseUtil.isObjNull(forVal)) {
				forVal = element.getAttributeValue("th:field");
				if (!BaseUtil.isObjNull(forVal)) {
					forVal = forVal.replace("*{", "").replace("}", "");
				}
			}

			Element bindElement = new Element(ElementConstants.HTML_LABEL);
			String lblClass = ElementEnum.LABEL.getStyle();
			if (element.getAttributeValue("data-constraints") != null) {
				String data = element.getAttributeValue("data-constraints");
				if (StringUtils.contains(data, "@Required")) {
					bindElement.setAttribute(AttributeConstants.ATTR_TH_CLASSAPPEND, "required");
				}
			}
			bindElement.setAttribute(AttributeConstants.ATTR_CLASS, lblClass);
			bindElement.setAttribute("for", forVal);
			bindElement.setAttribute("th:text", element.getAttributeValue("lbl"));
			element.getParent().insertBefore(element, bindElement);
			newElement.removeAttribute("lbl");
		}

		element.getParent().insertAfter(element, newElement);
		element.getParent().removeChild(element);
		return ProcessorResult.OK;
	}


	@Override
	public int getPrecedence() {
		return 100000;
	}

}