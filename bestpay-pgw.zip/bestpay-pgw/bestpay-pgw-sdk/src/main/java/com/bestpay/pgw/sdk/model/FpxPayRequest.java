package com.bestpay.pgw.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

 
@JsonInclude(Include.NON_NULL)
public class FpxPayRequest implements Serializable {

	private static final long serialVersionUID = -503202399644239358L;

	private String fpx_msgType; // Indicate Message Type AC

	private String fpx_msgToken; // indicate business model 01-B2C

	private String fpx_sellerExId;

	private String fpx_sellerExOrderNo;

	private String fpx_sellerTxnTime;

	private String fpx_sellerOrderNo;

	private String fpx_sellerId;

	private String fpx_sellerBankCode;

	private String fpx_txnCurrency;

	private String fpx_txnAmount;

	private String fpx_checkSum;

	private String fpx_buyerName;

	private String fpx_buyerBankId;

	private String fpx_buyerBankBranch;

	private String fpx_buyerId;

	private String fpx_makerName;

	private String fpx_buyerIban;

	private String fpxUrl;

	private String fpx_buyerAccNo;

	private String fpx_buyerEmail;

	private String fpx_productDesc;

	private String fpx_version;


	/**
	 * @return the fpx_msgType
	 */
	public String getFpx_msgType() {
		return fpx_msgType;
	}


	/**
	 * @param fpx_msgType
	 *             the fpx_msgType to set
	 */
	public void setFpx_msgType(String fpx_msgType) {
		this.fpx_msgType = fpx_msgType;
	}


	/**
	 * @return the fpx_msgToken
	 */
	public String getFpx_msgToken() {
		return fpx_msgToken;
	}


	/**
	 * @param fpx_msgToken
	 *             the fpx_msgToken to set
	 */
	public void setFpx_msgToken(String fpx_msgToken) {
		this.fpx_msgToken = fpx_msgToken;
	}


	/**
	 * @return the fpx_sellerExId
	 */
	public String getFpx_sellerExId() {
		return fpx_sellerExId;
	}


	/**
	 * @param fpx_sellerExId
	 *             the fpx_sellerExId to set
	 */
	public void setFpx_sellerExId(String fpx_sellerExId) {
		this.fpx_sellerExId = fpx_sellerExId;
	}


	/**
	 * @return the fpx_sellerExOrderNo
	 */
	public String getFpx_sellerExOrderNo() {
		return fpx_sellerExOrderNo;
	}


	/**
	 * @param fpx_sellerExOrderNo
	 *             the fpx_sellerExOrderNo to set
	 */
	public void setFpx_sellerExOrderNo(String fpx_sellerExOrderNo) {
		this.fpx_sellerExOrderNo = fpx_sellerExOrderNo;
	}


	/**
	 * @return the fpx_sellerTxnTime
	 */
	public String getFpx_sellerTxnTime() {
		return fpx_sellerTxnTime;
	}


	/**
	 * @param fpx_sellerTxnTime
	 *             the fpx_sellerTxnTime to set
	 */
	public void setFpx_sellerTxnTime(String fpx_sellerTxnTime) {
		this.fpx_sellerTxnTime = fpx_sellerTxnTime;
	}


	/**
	 * @return the fpx_sellerOrderNo
	 */
	public String getFpx_sellerOrderNo() {
		return fpx_sellerOrderNo;
	}


	/**
	 * @param fpx_sellerOrderNo
	 *             the fpx_sellerOrderNo to set
	 */
	public void setFpx_sellerOrderNo(String fpx_sellerOrderNo) {
		this.fpx_sellerOrderNo = fpx_sellerOrderNo;
	}


	/**
	 * @return the fpx_sellerId
	 */
	public String getFpx_sellerId() {
		return fpx_sellerId;
	}


	/**
	 * @param fpx_sellerId
	 *             the fpx_sellerId to set
	 */
	public void setFpx_sellerId(String fpx_sellerId) {
		this.fpx_sellerId = fpx_sellerId;
	}


	/**
	 * @return the fpx_sellerBankCode
	 */
	public String getFpx_sellerBankCode() {
		return fpx_sellerBankCode;
	}


	/**
	 * @param fpx_sellerBankCode
	 *             the fpx_sellerBankCode to set
	 */
	public void setFpx_sellerBankCode(String fpx_sellerBankCode) {
		this.fpx_sellerBankCode = fpx_sellerBankCode;
	}


	/**
	 * @return the fpx_txnCurrency
	 */
	public String getFpx_txnCurrency() {
		return fpx_txnCurrency;
	}


	/**
	 * @param fpx_txnCurrency
	 *             the fpx_txnCurrency to set
	 */
	public void setFpx_txnCurrency(String fpx_txnCurrency) {
		this.fpx_txnCurrency = fpx_txnCurrency;
	}


	/**
	 * @return the fpx_txnAmount
	 */
	public String getFpx_txnAmount() {
		return fpx_txnAmount;
	}


	/**
	 * @param fpx_txnAmount
	 *             the fpx_txnAmount to set
	 */
	public void setFpx_txnAmount(String fpx_txnAmount) {
		this.fpx_txnAmount = fpx_txnAmount;
	}


	/**
	 * @return the fpx_checkSum
	 */
	public String getFpx_checkSum() {
		return fpx_checkSum;
	}


	/**
	 * @param fpx_checkSum
	 *             the fpx_checkSum to set
	 */
	public void setFpx_checkSum(String fpx_checkSum) {
		this.fpx_checkSum = fpx_checkSum;
	}


	/**
	 * @return the fpx_buyerName
	 */
	public String getFpx_buyerName() {
		return fpx_buyerName;
	}


	/**
	 * @param fpx_buyerName
	 *             the fpx_buyerName to set
	 */
	public void setFpx_buyerName(String fpx_buyerName) {
		this.fpx_buyerName = fpx_buyerName;
	}


	/**
	 * @return the fpx_buyerBankId
	 */
	public String getFpx_buyerBankId() {
		return fpx_buyerBankId;
	}


	/**
	 * @param fpx_buyerBankId
	 *             the fpx_buyerBankId to set
	 */
	public void setFpx_buyerBankId(String fpx_buyerBankId) {
		this.fpx_buyerBankId = fpx_buyerBankId;
	}


	/**
	 * @return the fpx_buyerBankBranch
	 */
	public String getFpx_buyerBankBranch() {
		return fpx_buyerBankBranch;
	}


	/**
	 * @param fpx_buyerBankBranch
	 *             the fpx_buyerBankBranch to set
	 */
	public void setFpx_buyerBankBranch(String fpx_buyerBankBranch) {
		this.fpx_buyerBankBranch = fpx_buyerBankBranch;
	}


	/**
	 * @return the fpx_buyerId
	 */
	public String getFpx_buyerId() {
		return fpx_buyerId;
	}


	/**
	 * @param fpx_buyerId
	 *             the fpx_buyerId to set
	 */
	public void setFpx_buyerId(String fpx_buyerId) {
		this.fpx_buyerId = fpx_buyerId;
	}


	/**
	 * @return the fpx_makerName
	 */
	public String getFpx_makerName() {
		return fpx_makerName;
	}


	/**
	 * @param fpx_makerName
	 *             the fpx_makerName to set
	 */
	public void setFpx_makerName(String fpx_makerName) {
		this.fpx_makerName = fpx_makerName;
	}


	/**
	 * @return the fpx_buyerIban
	 */
	public String getFpx_buyerIban() {
		return fpx_buyerIban;
	}


	/**
	 * @param fpx_buyerIban
	 *             the fpx_buyerIban to set
	 */
	public void setFpx_buyerIban(String fpx_buyerIban) {
		this.fpx_buyerIban = fpx_buyerIban;
	}


	/**
	 * @return the fpxUrl
	 */
	public String getFpxUrl() {
		return fpxUrl;
	}


	/**
	 * @param fpxUrl
	 *             the fpxUrl to set
	 */
	public void setFpxUrl(String fpxUrl) {
		this.fpxUrl = fpxUrl;
	}


	/**
	 * @return the fpx_buyerAccNo
	 */
	public String getFpx_buyerAccNo() {
		return fpx_buyerAccNo;
	}


	/**
	 * @param fpx_buyerAccNo
	 *             the fpx_buyerAccNo to set
	 */
	public void setFpx_buyerAccNo(String fpx_buyerAccNo) {
		this.fpx_buyerAccNo = fpx_buyerAccNo;
	}


	/**
	 * @return the fpx_buyerEmail
	 */
	public String getFpx_buyerEmail() {
		return fpx_buyerEmail;
	}


	/**
	 * @param fpx_buyerEmail
	 *             the fpx_buyerEmail to set
	 */
	public void setFpx_buyerEmail(String fpx_buyerEmail) {
		this.fpx_buyerEmail = fpx_buyerEmail;
	}


	/**
	 * @return the fpx_productDesc
	 */
	public String getFpx_productDesc() {
		return fpx_productDesc;
	}


	/**
	 * @param fpx_productDesc
	 *             the fpx_productDesc to set
	 */
	public void setFpx_productDesc(String fpx_productDesc) {
		this.fpx_productDesc = fpx_productDesc;
	}


	/**
	 * @return the fpx_version
	 */
	public String getFpx_version() {
		return fpx_version;
	}


	/**
	 * @param fpx_version
	 *             the fpx_version to set
	 */
	public void setFpx_version(String fpx_version) {
		this.fpx_version = fpx_version;
	}

}