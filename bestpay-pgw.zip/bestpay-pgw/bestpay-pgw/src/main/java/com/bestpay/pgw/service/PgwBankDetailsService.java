/**
 * 
 */
package com.bestpay.pgw.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.PgwBankDetailsRepository;
import com.bestpay.pgw.model.PgwBankDetails;
import com.bestpay.pgw.util.QualifierConstants;
/**
 * @author Chaithanya Kumar
 * @since 19/07/2018
 */
@Service(QualifierConstants.PGW_BANKDETIALS_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_BANKDETIALS_SVC)
@Transactional
public class PgwBankDetailsService extends AbstractService<PgwBankDetails>{

	@Autowired
	private PgwBankDetailsRepository pgwBankDetailsDao;
	
	@Override
	public GenericRepository<PgwBankDetails> primaryDao() {
		return pgwBankDetailsDao;
	}
	
	public PgwBankDetails findByMerchantId(String merchantId){
		return pgwBankDetailsDao.findByMerchantId(merchantId);
	}
	

}