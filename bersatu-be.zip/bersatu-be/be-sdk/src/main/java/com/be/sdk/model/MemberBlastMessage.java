/**
  * Copyright 2019
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 *
 * @author Naem Othman
 * @since March 31, 2020
 */
public class MemberBlastMessage implements Serializable, IQfCriteria<MemberBlastMessage> {

	private static final long serialVersionUID = 6016032592885161865L;

	private String orgStateCd;
	
	private String stateCd;

	private String orgDivisionCd;

	private String parliamentCode;

	private String dunCode;

	private Integer memberCtrgyMtdtId;
	
	private String memberCtrgyMtdtDesc;

	private Integer totalMember;

	private String applyBy;

	private Timestamp applyDt;

	private String applyLevel;

//	private Timestamp applyDtFrom;
//
//	private Timestamp applyDtTo;
	private String branchCd;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date applyDtFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date applyDtTo;
	
	private int notifyTypeMail;

	private int notifyTypeSms;
	
	private int notifyTypeFcm;
	
	private String notifyMessage;
	
	private String areaCd;

	public String getOrgStateCd() {
		return orgStateCd;
	}


	public void setOrgStateCd(String orgStateCd) {
		this.orgStateCd = orgStateCd;
	}

	
	public String getStateCd() {
		return stateCd;
	}


	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}


	public String getOrgDivisionCd() {
		return orgDivisionCd;
	}


	public void setOrgDivisionCd(String orgDivisionCd) {
		this.orgDivisionCd = orgDivisionCd;
	}


	public String getParliamentCode() {
		return parliamentCode;
	}


	public void setParliamentCode(String parliamentCode) {
		this.parliamentCode = parliamentCode;
	}


	public String getDunCode() {
		return dunCode;
	}


	public void setDunCode(String dunCode) {
		this.dunCode = dunCode;
	}


	public Integer getMemberCtrgyMtdtId() {
		return memberCtrgyMtdtId;
	}


	public void setMemberCtrgyMtdtId(Integer memberCtrgyMtdtId) {
		this.memberCtrgyMtdtId = memberCtrgyMtdtId;
	}


	public String getApplyBy() {
		return applyBy;
	}


	public void setApplyBy(String applyBy) {
		this.applyBy = applyBy;
	}


	public Timestamp getApplyDt() {
		return applyDt;
	}


	public void setApplyDt(Timestamp applyDt) {
		this.applyDt = applyDt;
	}


	public Date getApplyDtFrom() {
		return applyDtFrom;
	}


	public void setApplyDtFrom(Date applyDtFrom) {
		this.applyDtFrom = applyDtFrom;
	}


	public Date getApplyDtTo() {
		return applyDtTo;
	}


	public void setApplyDtTo(Date applyDtTo) {
		this.applyDtTo = applyDtTo;
	}


	public Integer getTotalMember() {
		return totalMember;
	}


	public void setTotalMember(Integer totalMember) {
		this.totalMember = totalMember;
	}


	public String getMemberCtrgyMtdtDesc() {
		return memberCtrgyMtdtDesc;
	}


	public void setMemberCtrgyMtdtDesc(String memberCtrgyMtdtDesc) {
		this.memberCtrgyMtdtDesc = memberCtrgyMtdtDesc;
	}


	public String getApplyLevel() {
		return applyLevel;
	}


	public void setApplyLevel(String applyLevel) {
		this.applyLevel = applyLevel;
	}


	public String getBranchCd() {
		return branchCd;
	}


	public void setBranchCd(String branchCd) {
		this.branchCd = branchCd;
	}
	
	public int getNotifyTypeMail() {
		return notifyTypeMail;
	}


	public void setNotifyTypeMail(int notifyTypeMail) {
		this.notifyTypeMail = notifyTypeMail;
	}


	public int getNotifyTypeSms() {
		return notifyTypeSms;
	}


	public void setNotifyTypeSms(int notifyTypeSms) {
		this.notifyTypeSms = notifyTypeSms;
	}


	public int getNotifyTypeFcm() {
		return notifyTypeFcm;
	}


	public void setNotifyTypeFcm(int notifyTypeFcm) {
		this.notifyTypeFcm = notifyTypeFcm;
	}
	
	
	public String getNotifyMessage() {
		return notifyMessage;
	}


	public void setNotifyMessage(String notifyMessage) {
		this.notifyMessage = notifyMessage;
	}


	public String getAreaCd() {
		return areaCd;
	}


	public void setAreaCd(String areaCd) {
		this.areaCd = areaCd;
	}

}