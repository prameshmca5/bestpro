/**
 * 
 */
package com.bestpay.pgw.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.PgwTransactionHistoryRepository;
import com.bestpay.pgw.model.PgwTransactionHistory;
import com.bestpay.pgw.util.QualifierConstants;
/**
 * @author Chaithanya Kumar
 * @since 17/07/2018
 */
@Service(QualifierConstants.PGW_TRANSACTION_HIS_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_TRANSACTION_HIS_SVC)
@Transactional
public class PgwTransactionHistoryService extends AbstractService<PgwTransactionHistory>{

	@Autowired
	private PgwTransactionHistoryRepository pgwTransHistoryDao;
	
	@Override
	public GenericRepository<PgwTransactionHistory> primaryDao() {
		return pgwTransHistoryDao;
	}
	
	public List<PgwTransactionHistory> findByOrderIDGetDetails(String orderId) {
		return pgwTransHistoryDao.findByOrderIDGetDetails(orderId);
	}

}