/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.controller;


import java.security.GeneralSecurityException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestid.be.constants.ApplicationConstants;
import com.bestid.be.constants.CacheConstants;
import com.bestid.be.constants.ConfigConstants;
import com.bestid.be.constants.TxnCodeConstants;
import com.bestid.be.constants.UriConstants;
import com.bestid.be.dto.MobileLoginResponse;
import com.bestid.be.model.BidCertInfo;
import com.bestid.be.model.BidConfig;
import com.bestid.be.model.BidEnrollAppl;
import com.bestid.be.model.BidIcaoConfig;
import com.bestid.be.model.BidSubscriber;
import com.bestid.be.model.BidSubscriberUser;
import com.bestid.be.model.BidUserProfile;
import com.bestid.be.model.SecUser;
import com.bestid.be.model.SecUserDevice;
import com.bestid.be.sdk.constants.BeConstants;
import com.bestid.be.sdk.constants.BeErrorCodeEnum;
import com.bestid.be.sdk.constants.MailTemplateConstants;
import com.bestid.be.sdk.model.Device;
import com.bestid.be.sdk.model.DigitalIdInfo;
import com.bestid.be.sdk.model.MessageResponse;
import com.bestid.be.sdk.model.MobileUser;
import com.bestid.be.sdk.model.PinCodeResponse;
import com.bestid.be.sdk.model.QrDetail;
import com.bestid.be.sdk.model.SubscriberInfo;
import com.bestid.be.sdk.model.TransSign;
import com.bestid.be.sdk.model.UsrProfile;
import com.bestid.be.service.BidCertInfoService;
import com.bestid.be.service.BidConfigService;
import com.bestid.be.service.BidEnrollApplService;
import com.bestid.be.service.BidIcaoConfigService;
import com.bestid.be.service.BidSubscriberService;
import com.bestid.be.service.BidSubscriberUserService;
import com.bestid.be.service.BidUserProfileService;
import com.bestid.be.service.SecUserDeviceService;
import com.bestid.be.service.SecUserService;
import com.bestid.be.util.CryptoHelper;
import com.bstsb.camvi.sdk.client.CamviServiceClient;
import com.bstsb.camvi.sdk.exception.CamviException;
import com.bstsb.camvi.sdk.model.PersonDto;
import com.bstsb.cert.sdk.client.Cs2ServiceClient;
import com.bstsb.cert.sdk.client.MsctgServiceClient;
import com.bstsb.cert.sdk.exception.CertException;
import com.bstsb.cert.sdk.model.EnrollRequest;
import com.bstsb.cert.sdk.model.EnrollResponse;
import com.bstsb.cert.sdk.model.enums.UniqueIDType;
import com.bstsb.icao.sdk.client.IcaoServiceClient;
import com.bstsb.icao.sdk.exception.IcaoException;
import com.bstsb.icao.sdk.model.IcaoInfo;
import com.bstsb.icao.sdk.model.IcaoResponse;
import com.bstsb.idm.sdk.exception.IdmException;
import com.bstsb.idm.sdk.model.LoginDto;
import com.bstsb.idm.sdk.model.UserProfile;
import com.bstsb.notify.sdk.model.Notification;
import com.bstsb.notify.sdk.util.MailUtil;
import com.bstsb.signet.sdk.client.SignetServiceClient;
import com.bstsb.signet.sdk.exception.SignetException;
import com.bstsb.signet.sdk.model.SignetResp;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.DateUtil;
import com.bstsb.util.MediaType;
import com.bstsb.util.SSHA;
import com.bstsb.util.UidGenerator;
import com.bstsb.util.constants.BaseConstants;


/**
 * This Rest Controller is specific for BestID Mobile Integration Service
 *
 * @author Mary Jane Buenaventura
 * @since Nov 12, 2018
 */
@Lazy
@RestController
public class MobileRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MobileRestController.class);

	@Autowired
	private SecUserService secUserSvc;

	@Autowired
	private SecUserDeviceService secUserDeviceSvc;

	@Autowired
	private BidEnrollApplService bidEnrollApplSvc;

	@Autowired
	private BidUserProfileService bidUserProfileService;

	@Autowired
	private BidCertInfoService bidCertInfoService;

	@Autowired
	private CacheManager cacheManager;

	@Autowired
	CamviServiceClient camviService;

	@Autowired
	Cs2ServiceClient cs2ServiceClient;

	@Autowired
	MsctgServiceClient msctgServiceClient;

	@Autowired
	SignetServiceClient signetServiceClient;

	@Autowired
	BidConfigService bidConfigSvc;

	@Autowired
	BidIcaoConfigService bidIcaoConfigSvc;

	@Autowired
	private IcaoServiceClient icaoService;

	@Autowired
	private BidSubscriberService bidSubscriberSvc;

	@Autowired
	private BidSubscriberUserService bidSubscriberUserSvc;

	private static final String LOG_PLACEMENT = "[{0}]";


	/**
	 * @param trxnNo
	 * @param request
	 * @param mobileUser
	 * @return
	 * @throws GeneralSecurityException
	 */
	@PostMapping(value = UriConstants.MOBILE_LOGIN, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse login(@RequestParam(defaultValue = TxnCodeConstants.SEC_LOGIN) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) throws GeneralSecurityException {

		SecUser secUser = null;
		SecUserDevice secUserDevice = null;
		UserProfile up = null;
		LoginDto loginDto = null;
		UserProfile userProfile = null;
		MobileLoginResponse mobileLoginResponse = null;

		if (BaseUtil.isObjNull(mobileUser)) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		if (BaseUtil.isObjNull(mobileUser.getUsername()) || BaseUtil.isObjNull(mobileUser.getPassword())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		try {
			String passStr = mobileUser.getPassword();
			String passDecrypt = CryptoHelper.decrypt(passStr);
			LOGGER.info("CryptoHelper.decrypt :: {}", passStr);
			LOGGER.info("passDecrypt :: {}", passDecrypt);
			LOGGER.info("username :: {}", mobileUser.getUsername());

			up = getIdmService(request).getUserProfileById(mobileUser.getUsername(), false, false);

			LOGGER.debug("UP is null ? ==> {}", BaseUtil.isObjNull(up));
			if (!BaseUtil.isObjNull(up)) {
				LOGGER.debug("UP userId is null ? ==> {}", up.getUserId());
				loginDto = new LoginDto();
				loginDto.setUserId(up.getUserId());
				loginDto.setClientId("bestid-be");
				loginDto.setClientSecret("Basic YmVzdGlkLWJlOnNlY3JldA==");
				String pwd = SSHA.getLDAPSSHAHash(passDecrypt, getPwordEkey());
				loginDto.setPassword(pwd);
				loginDto.setUserType("INT");

				LOGGER.debug("PASSWORD >> {}", loginDto.getPassword());
				loginDto = getIdmService(request).login(loginDto);

			}

		} catch (Exception e) {
			LOGGER.error("IdmException: {}", e.getMessage());
			String msg = BeErrorCodeEnum.E404BST004.getMessage().replace("{0}",
					"[" + mobileUser.getUsername() + "]");
			return new MessageResponse(new Timestamp(new Date().getTime()), BeErrorCodeEnum.E404BST004.getCode(),
					BeErrorCodeEnum.E404BST004.getMessage(), msg, request.getRequestURI());

		}

		if (BaseUtil.isObjNull(loginDto)) {
			String msg = BeErrorCodeEnum.E500BST005.getMessage().replace("{0}",
					"[" + mobileUser.getUsername() + "]");
			return new MessageResponse(new Timestamp(new Date().getTime()), BeErrorCodeEnum.E500BST005.getCode(),
					BeErrorCodeEnum.E500BST005.getMessage(), msg, request.getRequestURI());
		}

		try {
			secUser = secUserSvc.findByUserName(mobileUser.getUsername());

			if (BaseUtil.isObjNull(secUser)) {
				secUser = new SecUser();
				secUser.setUserName(mobileUser.getUsername());
				if (!BaseUtil.isObjNull(up.getFullName())) {
					secUser.setName(up.getFullName());
				}
				secUser.setStatus(up.getStatus());
				secUser.setCreateId(mobileUser.getUsername());
				secUser.setUpdateId(mobileUser.getUsername());
				// secUser = secUserSvc.create(secUser);
			} else {
				secUser.setStatus(up.getStatus());
				secUser.setUpdateId(mobileUser.getUsername());
				secUser.setUpdateDt(DateUtil.getSQLTimestamp());
				// secUser = secUserSvc.update(secUser);
			}

			userProfile = dozerMapper.map(secUser, UserProfile.class);
			userProfile.setUserId(up.getUserId());
			userProfile.setFullName(up.getFullName());
			userProfile.setEmail(up.getEmail());
			userProfile.setMobPhoneNo(up.getMobPhoneNo());
			userProfile.setNationalId(up.getNationalId());
			userProfile.setStatus(up.getStatus());

			secUserDevice = secUserDeviceSvc.findDeviceByUserMachine(mobileUser.getUsername(),
					mobileUser.getDeviceInfo().getMachineId());

			if (BaseUtil.isObjNull(secUserDevice)) {
				secUserDevice = new SecUserDevice();
				secUserDevice.setUserName(mobileUser.getUsername());
				secUserDevice.setMachineId(mobileUser.getDeviceInfo().getMachineId());
				secUserDevice.setSdkVersion(mobileUser.getDeviceInfo().getSdkVersion());
				secUserDevice.setModel(mobileUser.getDeviceInfo().getModel());
				secUserDevice.setBrand(mobileUser.getDeviceInfo().getBrand());
				secUserDevice.setManufacturer(mobileUser.getDeviceInfo().getManufacturer());
				secUserDevice.setGeoLocation(mobileUser.getDeviceInfo().getGeoLocation());
				secUserDevice.setStatus("A");
				secUserDevice.setCreateId(mobileUser.getUsername());
				secUserDevice.setUpdateId(mobileUser.getUsername());
				// secUserDeviceSvc.create(secUserDevice);
			} else {
				secUserDevice.setStatus("A");
				secUserDevice.setUpdateId(mobileUser.getUsername());
				secUserDevice.setUpdateDt(DateUtil.getSQLTimestamp());
				// secUserDeviceSvc.update(secUserDevice);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			LOGGER.debug("secUser :: {}", secUser);
			return new MessageResponse(BeErrorCodeEnum.E500BST001, request.getRequestURI(), null);
		}

		mobileLoginResponse = new MobileLoginResponse(userProfile);
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), mobileLoginResponse);

	}


	@PostMapping(value = UriConstants.MOBILE_LOGOUT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse logout(@RequestParam(defaultValue = TxnCodeConstants.SEC_LOGOUT) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {
		if (BaseUtil.isObjNull(mobileUser)) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		UserProfile userProfile = getIdmService(request).getUserProfileById(mobileUser.getUsername(), false, false);
		new MobileLoginResponse(userProfile);

		try {
			LoginDto loginDto = new LoginDto();
			loginDto.setUserId(mobileUser.getUsername());
			loginDto.setPassword(SSHA.getLDAPSSHAHash(mobileUser.getPassword(), getPwordEkey()));
			loginDto.setUserType("INT");
			getIdmService(request).login(loginDto);

		} catch (IdmException e) {
			LOGGER.error(e.getMessage());
		}

		SecUserDevice userDevice = secUserDeviceSvc.findDeviceByUserMachine(mobileUser.getUsername(),
				mobileUser.getDeviceInfo().getMachineId());

		if (!BaseUtil.isObjNull(userDevice)) {
			userDevice.setStatus("I");
			userDevice.setUpdateId(mobileUser.getUsername());
			secUserDeviceSvc.update(userDevice);
			return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), null);
		}

		return new MessageResponse(BeErrorCodeEnum.E500BST001, request.getRequestURI(), null);
	}


	@PostMapping(value = UriConstants.MOBILE_REGISTRATION_PROFILE, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MessageResponse registerProfile(
			@RequestParam(defaultValue = TxnCodeConstants.SEC_REGISTER_PROFILE) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {

		if (BaseUtil.isObjNull(mobileUser)) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		BidConfig configCamvi = bidConfigSvc.findConfigCd(ConfigConstants.BID_CAMVI_GRP_ID);
		if (BaseUtil.isObjNull(configCamvi)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}

		try {
			String uuid = UUID.randomUUID().toString();
			PersonDto person = camviService.createPerson(uuid, configCamvi.getConfigVal(),
					mobileUser.getFaceImage());

			if (BaseUtil.isObjNull(person)) {
				return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
			}

			SecUser secUser = secUserSvc.findByProfileId(person.getPersonId());
			SecUserDevice secUserDevice = secUserDeviceSvc
					.findDeviceByMachineId(mobileUser.getDeviceInfo().getMachineId());
			if (BaseUtil.isObjNull(secUser) && BaseUtil.isObjNull(secUserDevice)) {
				secUser = new SecUser();
				secUser.setUserName(uuid);
				secUser.setPinCd(mobileUser.getPin());
				secUser.setProfileId(person.getPersonId());
				secUser.setFaceId(person.getFaceId());
				secUser.setStatus(BaseConstants.USER_ACTIVE);

				secUserDevice = new SecUserDevice();
				secUserDevice.setUserName(uuid);
				secUserDevice.setMachineId(mobileUser.getDeviceInfo().getMachineId());
				secUserDevice.setStatus(BaseConstants.USER_ACTIVE);

				secUser = secUserSvc.createSecUserInfo(secUser, secUserDevice);
				return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), mobileUser);
			}

		} catch (CamviException e) {
			LOGGER.error(e.getMessage());
			return new MessageResponse(BeErrorCodeEnum.E500BST004, request.getRequestURI(), null);
		}
		return new MessageResponse(BeErrorCodeEnum.E500BST001, request.getRequestURI(), null);
	}


	@PostMapping(value = UriConstants.MOBILE_REGISTRATION_PIN, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse pinRegistration(
			@RequestParam(defaultValue = TxnCodeConstants.SEC_REGISTER_PIN) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {

		if (BaseUtil.isObjNull(mobileUser)) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		SecUser secUser = null;
		secUser = secUserSvc.findByUserName(mobileUser.getUsername());
		if (!BaseUtil.isObjNull(secUser)) {
			secUser.setPinCd(mobileUser.getPin());
			secUser.setUpdateId(mobileUser.getUsername());
			secUserSvc.update(secUser);
			return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), mobileUser);
		}

		return new MessageResponse(BeErrorCodeEnum.E500BST001, request.getRequestURI(), null);
	}


	@PostMapping(value = UriConstants.MOBILE_VERIFICATION_PIN, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse pinVerification(@RequestParam(defaultValue = TxnCodeConstants.SEC_VERIFY_PIN) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {
		if (BaseUtil.isObjNull(mobileUser)) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		SecUser secUser = secUserSvc.findByUserName(mobileUser.getUsername());

		if (BaseUtil.isObjNull(secUser)) {
			String msg = BeErrorCodeEnum.E404BST003.getMessage().replace(LOG_PLACEMENT,
					"[" + mobileUser.getUsername() + "]");
			return new MessageResponse(new Timestamp(new Date().getTime()), 1,
					BeErrorCodeEnum.E404BST003.getMessage(), msg, request.getRequestURI());
		}

		if (BaseUtil.isEqualsCaseIgnore(mobileUser.getPin(), secUser.getPinCd())) {
			return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), mobileUser);
		}

		return new MessageResponse(BeErrorCodeEnum.E500BST002, request.getRequestURI(), mobileUser);
	}


	@PostMapping(value = UriConstants.MOBILE_REGISTRATION_FACE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse faceIdRegistration(
			@RequestParam(defaultValue = TxnCodeConstants.SEC_REGISTER_FACE) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {

		if (BaseUtil.isObjNull(mobileUser)) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		SecUser secUser = secUserSvc.findByUserName(mobileUser.getUsername());

		if (BaseUtil.isObjNull(secUser)) {
			String msg = BeErrorCodeEnum.E404BST003.getMessage().replace(LOG_PLACEMENT,
					"[" + mobileUser.getUsername() + "]");
			return new MessageResponse(new Timestamp(new Date().getTime()), BeErrorCodeEnum.E404BST003.getCode(),
					BeErrorCodeEnum.E404BST003.getMessage(), msg, request.getRequestURI());
		}

		// camvi start
		PersonDto person = camviService.createPerson(secUser.getUserName(), "2", mobileUser.getFaceImage());
		// camvi end

		if (!BaseUtil.isObjNull(secUser)) {
			secUser.setFaceId(person.getFaceId());
			secUser.setUpdateId(mobileUser.getUsername());
			secUserSvc.update(secUser);
			return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), mobileUser);
		}

		return new MessageResponse(BeErrorCodeEnum.E500BST001, request.getRequestURI(), null);
	}


	@PostMapping(value = UriConstants.MOBILE_VERIFICATION_FACE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse faceVerification(
			@RequestParam(defaultValue = TxnCodeConstants.SEC_VERIFY_FACE) String trxnNo, HttpServletRequest request,
			@Valid @RequestBody MobileUser mobileUser) {

		if (BaseUtil.isObjNull(mobileUser)) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		SecUser secUser = secUserSvc.findByUserName(mobileUser.getUsername());

		if (BaseUtil.isObjNull(secUser)) {
			String msg = BeErrorCodeEnum.E404BST003.getMessage().replace(LOG_PLACEMENT,
					"[" + mobileUser.getUsername() + "]");
			return new MessageResponse(new Timestamp(new Date().getTime()), 1,
					BeErrorCodeEnum.E404BST003.getMessage(), msg, request.getRequestURI());
		}

		// camvi start
		PersonDto person = camviService.createPerson(secUser.getUserName(), "2", mobileUser.getFaceImage());
		// camvi end
		if (BaseUtil.isEqualsCaseIgnore(mobileUser.getFaceId(), person.getFaceId())) {
			return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), null);
		}

		return new MessageResponse(BeErrorCodeEnum.E500BST003, request.getRequestURI(), null);
	}


	@PostMapping(value = UriConstants.MOBILE_VERIFICATION_QR, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse qrVerification(@RequestParam(defaultValue = TxnCodeConstants.SEC_VERIFY_QR) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {

		if (BaseUtil.isObjNull(mobileUser)) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		String qrString = mobileUser.getQr();
		LOGGER.info("qrString ::{}", qrString);

		String cacheKey = CacheConstants.CACHE_PREFIX
				+ CacheConstants.CACHE_KEY_API_QR.concat("12345678~df6f3093-2603-4cde-9eee-7cdbf1733022");
		Cache cache = cacheManager.getCache(CacheConstants.CACHE_BUCKET);
		Cache.ValueWrapper cv = cache.get(cacheKey);
		QrDetail qrDetail = new QrDetail();
		if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
			qrDetail = (QrDetail) cv.get();
			if (!BaseUtil.isObjNull(qrDetail)) {

			}
		}
		LOGGER.debug("QrDetail isObjNull = {}", BaseUtil.isObjNull(qrDetail));
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), mobileUser);
	}


	@GetMapping(value = UriConstants.MOBILE_FIND_ACTIVE_DEVICE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse fetchActiveDevice(
			@RequestParam(defaultValue = TxnCodeConstants.SEC_FETCH_ACTIVE_DEVICE) String trxnNo,
			HttpServletRequest request) {

		List<Device> device = new ArrayList<>();
		List<SecUserDevice> secUserDeviceLst = null;
		secUserDeviceLst = secUserDeviceSvc.findStatus(ApplicationConstants.ACTIVE);
		if (!BaseUtil.isListNull(secUserDeviceLst)) {
			LOGGER.info("secUserDeviceLst size ::{}", secUserDeviceLst.size());
			for (SecUserDevice userDevice : secUserDeviceLst) {
				Device dvc = new Device();
				dvc.setMachineId(userDevice.getMachineId());
				dvc.setSdkVersion(userDevice.getSdkVersion());
				dvc.setModel(userDevice.getModel());
				dvc.setBrand(userDevice.getBrand());
				dvc.setManufacturer(userDevice.getManufacturer());
				dvc.setGeoLocation(userDevice.getGeoLocation());
				device.add(dvc);
			}
		} else {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}

		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), device);
	}


	@PostMapping(value = UriConstants.MOBILE_REGISTRATION_CERT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse registerCert(@RequestParam(defaultValue = TxnCodeConstants.SEC_REGISTER_CERT) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody TransSign transSign) {

		if (BaseUtil.isObjNull(transSign.getTransRef()) || BaseUtil.isObjNull(transSign.getTransType())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		if (!(transSign.getTransType() == BeConstants.MISIGNET_EXECUTE_TRANS
				|| transSign.getTransType() == BeConstants.MISIGNET_AUTHORISE_TRANS)) {
			return new MessageResponse(BeErrorCodeEnum.E400BST003, request.getRequestURI(), null);
		}

		if (transSign.getTransType() == BeConstants.MISIGNET_EXECUTE_TRANS
				&& BaseUtil.isObjNull(transSign.getApplId())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		// send to mi-signet server
		SignetResp resp = null;
		try {
			resp = signetServiceClient.sendReqSocket(transSign.getTransRef());
			if (BaseUtil.isObjNull(resp) || (!BaseUtil.isObjNull(resp)
					&& !BaseUtil.isEquals(resp.getStatusCode(), ApplicationConstants.MISIGNET_STATUS_SUCCESS))) {
				return new MessageResponse(BeErrorCodeEnum.E500BST004, request.getRequestURI(), null);
			}
		} catch (SignetException e) {
			return new MessageResponse(BeErrorCodeEnum.E500BST004, request.getRequestURI(), null);
		}

		// submit to Certificate Authority (CR)
		if (transSign.getTransType() == BeConstants.MISIGNET_EXECUTE_TRANS) {
			MessageResponse msgResp = submitCA(transSign.getApplId(), transSign.getDeviceInfo().getMachineId(),
					request.getRequestURI(), resp);
			if (!BaseUtil.isObjNull(msgResp)) {
				return msgResp;
			}
		}
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), resp);
	}


	private MessageResponse submitCA(Integer applId, String machineId, String reqURI, SignetResp resp) {
		BidEnrollAppl bidEnrollAppl = bidEnrollApplSvc.find(applId);
		if (BaseUtil.isObjNull(bidEnrollAppl)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, reqURI, null);
		}

		SecUserDevice secUserDevice = secUserDeviceSvc.findDeviceByMachineId(machineId);
		if (BaseUtil.isObjNull(secUserDevice)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, reqURI, null);
		}

		if (bidEnrollAppl.getDeviceId() != secUserDevice.getDeviceId()) {
			return new MessageResponse(BeErrorCodeEnum.E401BST001, reqURI, null);
		}

		BidUserProfile bidUserProfile = bidUserProfileService.find(bidEnrollAppl.getUserId());
		if (BaseUtil.isObjNull(bidUserProfile)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, reqURI, null);
		}

		BidCertInfo bidCertInfo = bidCertInfoService.findByApplId(applId);
		if (!BaseUtil.isObjNull(bidCertInfo)) {
			return new MessageResponse(BeErrorCodeEnum.E409BST001, reqURI, null);
		}

		EnrollRequest reqCert = new EnrollRequest();
		reqCert.setUniqueID(bidUserProfile.getRefNo());

		reqCert.setCsr(BaseUtil.getStr(resp.getData()));
		reqCert.setUserMail(secUserDevice.getEmail());
		reqCert.setUserPhoneNumber(secUserDevice.getMobileNo());
		reqCert.setUserFirstName(bidUserProfile.getFullName());
		reqCert.setUserPostalAddress(bidUserProfile.getAddres());
		reqCert.setUserPostalCode(bidUserProfile.getPostcode());

		EnrollResponse cs2Resp = null;
		String pemCertificate = null;
		bidCertInfo = new BidCertInfo();
		try {
			if (bidUserProfile.getUserType() == BeConstants.USR_TYPE_MALAYSIAN) {
				reqCert.setUniqueIDType(UniqueIDType.IC);
				bidCertInfo.setCertSrc(ApplicationConstants.CERT_SRC_MSCTG);
				cs2Resp = msctgServiceClient.enroll(reqCert);
			} else if (bidUserProfile.getUserType() == BeConstants.USR_TYPE_FOREIGNER) {
				reqCert.setUniqueIDType(UniqueIDType.PASSPORT_NUMBER);
				bidCertInfo.setCertSrc(ApplicationConstants.CERT_SRC_CS2);
				cs2Resp = cs2ServiceClient.enroll(reqCert);
			}

			if (cs2Resp == null) {
				return new MessageResponse(BeErrorCodeEnum.E500BST004, reqURI, null);
			}

			pemCertificate = cs2Resp.getPemCertificate();
			String content = BaseUtil.subString(pemCertificate, ApplicationConstants.CERT_BEGIN_STR.length(),
					pemCertificate.length() - ApplicationConstants.CERT_END_STR.length());
			pemCertificate = pemCertificate.replace(content, content.replaceAll("\\s+", "")).trim();
		} catch (CertException e1) {
			return new MessageResponse(BeErrorCodeEnum.E500BST004, reqURI, null);
		}

		try {
			String userId = secUserDevice.getMachineId();
			Timestamp currDt = DateUtil.getSQLTimestamp();

			// store in BID_CERT_INFO

			bidCertInfo.setCertRefNo(cs2Resp.getId());
			bidCertInfo.setApplId(applId);
			bidCertInfo.setRefno(bidUserProfile.getRefNo());
			bidCertInfo.setUserType(bidUserProfile.getUserType());
			bidCertInfo.setEmail(secUserDevice.getEmail());
			bidCertInfo.setPhoneNo(secUserDevice.getMobileNo());
			bidCertInfo.setFirstName(bidUserProfile.getFullName());
			bidCertInfo.setAddress(bidUserProfile.getAddres());
			bidCertInfo.setPostcode(bidUserProfile.getPostcode());
			bidCertInfo.setCert(pemCertificate);
			bidCertInfo.setGenerateDt(cs2Resp.getStartDate());
			bidCertInfo.setExpiredDt(cs2Resp.getEndDate());
			bidCertInfo.setApproveDt(cs2Resp.getApproveDate());
			bidCertInfo.setStatus(ApplicationConstants.ACTIVE);
			bidCertInfo.setCreateId(userId);
			bidCertInfo.setCreateDt(currDt);
			bidCertInfo.setUpdateId(userId);
			bidCertInfo.setUpdateDt(currDt);

			secUserDevice.setCertStatus(ApplicationConstants.ACTIVE);
			secUserDevice.setUpdateId(userId);
			secUserDevice.setUpdateDt(currDt);

			BidCertInfo bidCertCrt = bidCertInfoService.createCert(bidCertInfo, secUserDevice);
			if (BaseUtil.isObjNull(bidCertCrt)) {
				return new MessageResponse(BeErrorCodeEnum.E500BST001, reqURI, null);
			}

			resp.setData(bidCertInfo.getCert().replace(ApplicationConstants.CERT_BEGIN_STR, "")
					.replace(ApplicationConstants.CERT_END_STR, ""));

		} catch (Exception e) {
			return new MessageResponse(BeErrorCodeEnum.E500BST001, reqURI, null);

		}

		return null;
	}


	@PostMapping(value = UriConstants.MOBILE_STORE_CERT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse storeCert(@RequestParam(defaultValue = TxnCodeConstants.SEC_STORE_CERT) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody TransSign transSign) {

		if (BaseUtil.isObjNull(transSign.getTransRef()) || BaseUtil.isObjNull(transSign.getTransType())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		if (!(transSign.getTransType() == BeConstants.MISIGNET_EXECUTE_TRANS
				|| transSign.getTransType() == BeConstants.MISIGNET_AUTHORISE_TRANS)) {
			return new MessageResponse(BeErrorCodeEnum.E400BST003, request.getRequestURI(), null);
		}

		if (transSign.getTransType() == BeConstants.MISIGNET_AUTHORISE_TRANS
				&& BaseUtil.isObjNull(transSign.getApplId())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		SecUserDevice secUserDevice = secUserDeviceSvc
				.findDeviceByMachineId(transSign.getDeviceInfo().getMachineId());
		if (BaseUtil.isObjNull(secUserDevice)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}

		String authReq = transSign.getTransRef();

		if (transSign.getTransType() == BeConstants.MISIGNET_AUTHORISE_TRANS) {
			BidCertInfo bidCertInfo = bidCertInfoService.findByApplId(transSign.getApplId());
			if (BaseUtil.isObjNull(bidCertInfo)) {
				return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
			}

			BidEnrollAppl bidEnrollAppl = bidEnrollApplSvc.findByApplIdDvcId(bidCertInfo.getApplId(),
					secUserDevice.getDeviceId());
			if (BaseUtil.isObjNull(bidEnrollAppl)) {
				return new MessageResponse(BeErrorCodeEnum.E409BST001, request.getRequestURI(), null);
			}

			authReq += "@" + bidCertInfo.getCert().replace(ApplicationConstants.CERT_BEGIN_STR, "")
					.replace(ApplicationConstants.CERT_END_STR, "");
		}

		// send to mi-signet server
		SignetResp resp = null;
		try {
			resp = signetServiceClient.sendReqSocket(authReq);
			if (BaseUtil.isObjNull(resp) || (!BaseUtil.isObjNull(resp)
					&& !BaseUtil.isEquals(resp.getStatusCode(), ApplicationConstants.MISIGNET_STATUS_SUCCESS))) {
				return new MessageResponse(BeErrorCodeEnum.E500BST004, request.getRequestURI(), null);
			}
		} catch (SignetException e) {
			return new MessageResponse(BeErrorCodeEnum.E500BST004, request.getRequestURI(), null);
		}

		if (transSign.getTransType() == BeConstants.MISIGNET_EXECUTE_TRANS) {
			secUserDevice.setIsCertInstall(BaseConstants.Y);
			secUserDevice.setUpdateId(secUserDevice.getMachineId());
			secUserDevice.setUpdateDt(DateUtil.getSQLTimestamp());
			secUserDevice = secUserDeviceSvc.update(secUserDevice);
			if (BaseUtil.isObjNull(secUserDevice)) {
				return new MessageResponse(BeErrorCodeEnum.E500BST001, request.getRequestURI(), null);
			}
		}

		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), resp);
	}


	@PostMapping(value = UriConstants.MOBILE_SUBMIT_CERT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse submitCert(@RequestParam(defaultValue = TxnCodeConstants.SEC_SUBMIT_CERT) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody TransSign transSign) {

		if (BaseUtil.isObjNull(transSign.getTransRef()) || BaseUtil.isObjNull(transSign.getTransType())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		if (!(transSign.getTransType() == BeConstants.MISIGNET_EXECUTE_TRANS
				|| transSign.getTransType() == BeConstants.MISIGNET_AUTHORISE_TRANS)) {
			return new MessageResponse(BeErrorCodeEnum.E400BST003, request.getRequestURI(), null);
		}

		// send to mi-signet server
		SignetResp resp = null;
		try {
			resp = signetServiceClient.sendReqSocket(transSign.getTransRef());
			if (BaseUtil.isObjNull(resp) || (!BaseUtil.isObjNull(resp)
					&& !BaseUtil.isEquals(resp.getStatusCode(), ApplicationConstants.MISIGNET_STATUS_SUCCESS))) {
				return new MessageResponse(BeErrorCodeEnum.E500BST004, request.getRequestURI(), null);
			}
		} catch (SignetException e) {
			return new MessageResponse(BeErrorCodeEnum.E500BST004, request.getRequestURI(), null);
		}

		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), resp);
	}


	@PostMapping(value = UriConstants.MOBILE_REVOKE_CERT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse revokeCert(@RequestParam(defaultValue = TxnCodeConstants.SEC_REVOKE_CERT) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody TransSign transSign) {

		if (BaseUtil.isObjNull(transSign.getCertRef())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		BidCertInfo bidCertInfo = bidCertInfoService.findByCertRefNo(transSign.getCertRef());
		if (BaseUtil.isObjNull(bidCertInfo)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}

		BidEnrollAppl bidEnrollAppl = bidEnrollApplSvc.find(bidCertInfo.getApplId());
		if (BaseUtil.isObjNull(bidEnrollAppl)) {
			return new MessageResponse(BeErrorCodeEnum.E409BST001, request.getRequestURI(), null);
		}

		SecUserDevice secUserDevice = secUserDeviceSvc.find(bidEnrollAppl.getDeviceId());
		if (BaseUtil.isObjNull(secUserDevice)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}

		boolean revokeStatus = false;
		try {
			if (BaseUtil.isEquals(bidCertInfo.getCertSrc(), ApplicationConstants.CERT_SRC_MSCTG)) {
				revokeStatus = msctgServiceClient.revoke(bidCertInfo.getCertRefNo());
			} else if (BaseUtil.isEquals(bidCertInfo.getCertSrc(), ApplicationConstants.CERT_SRC_CS2)) {
				revokeStatus = cs2ServiceClient.revoke(bidCertInfo.getCertRefNo());
			}

			if (!revokeStatus) {
				return new MessageResponse(BeErrorCodeEnum.E500BST001, request.getRequestURI(), null);
			}

			String userId = secUserDevice.getMachineId();
			Timestamp currDt = DateUtil.getSQLTimestamp();

			bidCertInfo.setRevokeDt(DateUtil.getSQLTimestamp());
			bidCertInfo.setStatus(ApplicationConstants.INACTIVE);
			bidCertInfo.setCreateId(transSign.getDeviceInfo().getMachineId());
			bidCertInfo.setCreateDt(DateUtil.getSQLTimestamp());
			bidCertInfo.setUpdateId(transSign.getDeviceInfo().getMachineId());
			bidCertInfo.setUpdateDt(DateUtil.getSQLTimestamp());

			secUserDevice.setCertStatus(ApplicationConstants.INACTIVE);
			secUserDevice.setUpdateId(userId);
			secUserDevice.setUpdateDt(currDt);

			BidCertInfo bidCertUpd = bidCertInfoService.updateCert(bidCertInfo, secUserDevice);
			if (BaseUtil.isObjNull(bidCertUpd)) {
				return new MessageResponse(BeErrorCodeEnum.E500BST001, request.getRequestURI(), null);
			}

		} catch (CertException e) {
			return new MessageResponse(BeErrorCodeEnum.E500BST004, request.getRequestURI(), null);
		}
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), null);
	}


	@PostMapping(value = UriConstants.MOBILE_SEARCH_FACE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse searchFace(@RequestParam(defaultValue = TxnCodeConstants.SEC_FACE_SEARCH) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {

		if (BaseUtil.isObjNull(mobileUser.getFaceImage())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		UsrProfile usrProfileDto = null;
		try {

			BidConfig configIcao = bidConfigSvc.findConfigCd(ConfigConstants.BID_ICAO_SWITCH);
			if (BaseUtil.isObjNull(configIcao)) {
				return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
			}

			// startIcao
			if (BaseUtil.isEquals(configIcao.getConfigVal(), BaseConstants.Y)) {
				MessageResponse msgResp = checkICAO(mobileUser.getFaceImage(), request.getRequestURI());
				if (!BaseUtil.isObjNull(msgResp)) {
					return msgResp;
				}
			}

			BidConfig configCamvi = bidConfigSvc.findConfigCd(ConfigConstants.BID_CAMVI_GRP_ID);
			if (BaseUtil.isObjNull(configCamvi)) {
				return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
			}

			// camvi start
			List<PersonDto> personList = camviService.searchFaceImage(BaseUtil.getInt(configCamvi.getConfigVal()),
					mobileUser.getFaceImage());
			if (BaseUtil.isListNull(personList)) {
				return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
			}

			usrProfileDto = new UsrProfile();
			for (PersonDto person : personList) {
				Double confdn = person.getConfidence();
				Double highestConfdn = 0.00;
				if (confdn > highestConfdn) {
					usrProfileDto.setProfileId(person.getPerson());
				}
			}

			SecUser secUser = secUserSvc.findByProfileId(usrProfileDto.getProfileId());
			if (BaseUtil.isObjNull(secUser)) {
				return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
			}

		} catch (CamviException e) {
			return new MessageResponse(BeErrorCodeEnum.E500BST004, request.getRequestURI(), null);
		}

		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), usrProfileDto);
	}


	private MessageResponse checkICAO(String faceImage, String reqURI) {
		try {
			List<BidIcaoConfig> icaoCfg = bidIcaoConfigSvc.findConfigVal(BaseConstants.Y);
			if (BaseUtil.isListNull(icaoCfg)) {
				return new MessageResponse(BeErrorCodeEnum.E404BST001, reqURI, null);
			}

			List<String> icaoCriteria = new ArrayList<>();
			for (BidIcaoConfig cfg : icaoCfg) {
				icaoCriteria.add(cfg.getConfigCd());
			}

			List<IcaoInfo> icaoInfo = IcaoInfo.findListByCriteria(icaoCriteria);
			IcaoResponse icaoResponse = icaoService.verifyPhoto(faceImage, icaoInfo);
			if (BaseUtil.isObjNull(icaoResponse)) {
				return new MessageResponse(BeErrorCodeEnum.E500BST004, reqURI, null);
			}

			if (BaseUtil.isEqualsCaseIgnore(icaoResponse.getResult(), ApplicationConstants.ICAO_RESULT_FAIL)) {
				return new MessageResponse(BeErrorCodeEnum.E500BST006, reqURI, icaoResponse);
			}
		} catch (IcaoException e) {
			return new MessageResponse(BeErrorCodeEnum.E500BST004, reqURI, null);
		}

		return null;
	}


	@PostMapping(value = UriConstants.MOBILE_PINCODE_VERIFY, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse verifyPin(@RequestParam(defaultValue = TxnCodeConstants.SEC_PINCODE_VERIFY) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser pinCodeRequest) {
		String profileId = pinCodeRequest.getProfileId();
		String pincode = pinCodeRequest.getPin();

		SecUser secUser = secUserSvc.findByProfileId(profileId);
		PinCodeResponse pinCodeResponse = new PinCodeResponse();
		SecUserDevice secUserDevice = secUserDeviceSvc
				.findDeviceByMachineId(pinCodeRequest.getDeviceInfo().getMachineId());
		Device device = dozerMapper.map(secUserDevice, Device.class);
		pinCodeResponse.setDeviceInfo(device);

		// Verify
		if (!BaseUtil.isObjNull(secUser)) {
			if (!BaseUtil.isEqualsCaseIgnoreAny(secUser.getPinCd(), pincode)) {
				return new MessageResponse(BeErrorCodeEnum.E500BST002, request.getRequestURI(), pinCodeResponse);
			}
		} else {
			return new MessageResponse(BeErrorCodeEnum.E500BST002, request.getRequestURI(), pinCodeResponse);
		}

		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), pinCodeResponse);
	}


	@PostMapping(value = UriConstants.MOBILE_PINCODE_UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse updatePin(@RequestParam(defaultValue = TxnCodeConstants.SEC_PINCODE_UPDATE) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser pinCodeRequest) {
		String profileId = pinCodeRequest.getProfileId();
		String newpincode = pinCodeRequest.getPin();
		String oldpincode = pinCodeRequest.getOldPin();

		SecUser secUser = secUserSvc.findByProfileId(profileId);
		PinCodeResponse pinCodeResponse = new PinCodeResponse();
		SecUserDevice secUserDevice = secUserDeviceSvc
				.findDeviceByMachineId(pinCodeRequest.getDeviceInfo().getMachineId());
		Device device = dozerMapper.map(secUserDevice, Device.class);
		pinCodeResponse.setDeviceInfo(device);

		// Verify & Update
		if (!BaseUtil.isObjNull(secUser)) {
			try {

				if (BaseUtil.isEquals(secUser.getPinCd(), oldpincode) && !BaseUtil.isStringNull(newpincode)) {
					secUser.setPinCd(newpincode);
					secUser.setUpdateId(getCurrUserId(request));
					secUserSvc.update(secUser);
					return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(),
							pinCodeResponse);
				} else {
					return new MessageResponse(BeErrorCodeEnum.E500BST001, request.getRequestURI(),
							pinCodeResponse);
				}
			} catch (Exception e) {
				return new MessageResponse(BeErrorCodeEnum.E500BST002, request.getRequestURI(), pinCodeResponse);
			}
		}

		return new MessageResponse(BeErrorCodeEnum.E404BST002, request.getRequestURI(), pinCodeResponse);
	}


	@PostMapping(value = UriConstants.MOBILE_INVITATION_CODE_GENERATE, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MessageResponse genInvCd(
			@RequestParam(defaultValue = TxnCodeConstants.SEC_INVITATION_CODE_GENERATE) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {

		if (BaseUtil.isObjNull(mobileUser.getSystemCode()) || BaseUtil.isObjNull(mobileUser.getMobileNo())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}
		BidSubscriber bidSubs = bidSubscriberSvc.findSysCd(mobileUser.getSystemCode());
		if (BaseUtil.isObjNull(bidSubs)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}
		BidSubscriberUser bidSubUsr = bidSubscriberUserSvc.findBySubIdNPhoneNo(bidSubs.getSubscrId(),
				mobileUser.getMobileNo());
		if (BaseUtil.isObjNull(bidSubUsr)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}
		SecUserDevice secUserDevice = secUserDeviceSvc
				.findDeviceByMachineId(mobileUser.getDeviceInfo().getMachineId());
		if (BaseUtil.isObjNull(secUserDevice)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}
		String invtNo = UidGenerator.generateRandomNoInStr();
		bidSubUsr.setInvitationCd(invtNo);
		bidSubUsr.setStatus("A");
		mobileUser.setUsername(secUserDevice.getUserName());
		bidSubscriberUserSvc.update(bidSubUsr);
		if (!BaseUtil.isObjNull(mobileUser.getMobileNo())) {
			String newmobile = mobileUser.getMobileNo();
			Map<String, Object> map = new HashMap<>();
			map.put("invtNo", invtNo);
			Notification notification = new Notification();
			notification.setNotifyTo(newmobile);
			notification.setMetaData(MailUtil.convertMapToJson(map));
			try {
				getNotifyService().addNotification(notification, MailTemplateConstants.GEN_INVITATION_CODE_SMS);
			} catch (IdmException e) {
				LOGGER.error("IdmException: {}", e.getMessage());
			} catch (Exception e) {
				LOGGER.error("Exception: {}", e.getMessage());
			}
		}
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), mobileUser);
	}


	@PostMapping(value = UriConstants.MOBILE_INVITATION_CODE_VERIFY, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MessageResponse verifyInvCd(
			@RequestParam(defaultValue = TxnCodeConstants.SEC_INVITATION_CODE_VERIFY) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {

		if (BaseUtil.isObjNull(mobileUser.getProfileId()) && BaseUtil.isObjNull(mobileUser.getMobileNo())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}
		SecUser secUser = secUserSvc.findByProfileId(mobileUser.getProfileId());
		if (BaseUtil.isObjNull(secUser)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}
		BidSubscriberUser bidSubUsr = bidSubscriberUserSvc.findByProfIdNPhoneNo(secUser.getUserId(),
				mobileUser.getMobileNo());
		if (BaseUtil.isObjNull(bidSubUsr)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}
		Device dvcInfo = mobileUser.getDeviceInfo();
		dvcInfo.setDeviceId(bidSubUsr.getDeviceId());
		mobileUser.setDeviceInfo(dvcInfo);
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), mobileUser);
	}


	@PostMapping(value = UriConstants.MOBILE_AUTH_VALIDATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse authVerify(@RequestParam(defaultValue = TxnCodeConstants.API_AUTH_VERIFY) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {

		if (BaseUtil.isObjNull(mobileUser.getProfileId()) && BaseUtil.isObjNull(mobileUser.getUuid())
				&& BaseUtil.isObjNull(mobileUser.getSubscrId())
				&& BaseUtil.isObjNull(mobileUser.getDigitalIdInd())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}
		BidSubscriber bidSubscriber = bidSubscriberSvc
				.findBySubscribIdType(Integer.parseInt(mobileUser.getSubscrId()), mobileUser.getDigitalIdInd());
		if (BaseUtil.isObjNull(bidSubscriber)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}

		SecUserDevice secUserDevice = secUserDeviceSvc.findByUuid(mobileUser.getUuid());
		if (BaseUtil.isObjNull(secUserDevice)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}

		List<BidSubscriberUser> subsriberUser = bidSubscriberUserSvc.findBySubscId(
				Integer.parseInt(mobileUser.getSubscrId()), secUserDevice.getDeviceId(), secUserDevice.getUserId());
		if (BaseUtil.isListNull(subsriberUser)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		} else {
			for (BidSubscriberUser subscribUser : subsriberUser) {
				SecUser secUser = secUserSvc.findByUserIdProfileId(subscribUser.getSecUserId(),
						mobileUser.getProfileId());
				if (BaseUtil.isObjNull(secUser)) {
					return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
				}
			}
		}
		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), mobileUser);
	}


	@PostMapping(value = UriConstants.MOBILE_SEARCH_PROFILE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse searchProfile(
			@RequestParam(defaultValue = TxnCodeConstants.SEC_PROFILE_SEARCH) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody UsrProfile profile) {

		if (BaseUtil.isObjNull(profile.getProfileId())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		SecUser secUser = secUserSvc.findByProfileId(profile.getProfileId());
		if (BaseUtil.isObjNull(secUser)) {
			return new MessageResponse(BeErrorCodeEnum.E404BST001, request.getRequestURI(), null);
		}

		UsrProfile usrProfile = new UsrProfile();

		BidUserProfile bidUserProfile = bidUserProfileService.findBySecUserId(secUser.getUserId());
		if (!BaseUtil.isObjNull(bidUserProfile)) {
			usrProfile = dozerMapper.map(bidUserProfile, UsrProfile.class);

			// certificate info
			BidEnrollAppl bidEnrollAppl = new BidEnrollAppl();
			bidEnrollAppl.setUserId(bidUserProfile.getUserId());
			bidEnrollAppl.setStatus(profile.getDigitalStatus());
			usrProfile.setDigitalIdList(getDigitalIdInfo(bidEnrollAppl));

		}

		// device info
		SecUserDevice secUserDevice = new SecUserDevice();
		secUserDevice.setStatus(profile.getDeviceStatus());
		secUserDevice.setUserId(secUser.getUserId());
		usrProfile.setDeviceList(getDeviceInfo(secUserDevice));

		// system info
		BidSubscriberUser bidSubscriberUser = new BidSubscriberUser();
		bidSubscriberUser.setSecUserId(secUser.getUserId());
		bidSubscriberUser.setStatus(profile.getSubscribeStatus());
		usrProfile.setSubscriberList(getSubscriberInfo(bidSubscriberUser));

		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), usrProfile);
	}


	private List<DigitalIdInfo> getDigitalIdInfo(BidEnrollAppl bidEnrollAppl) {
		List<DigitalIdInfo> digitalIdList = null;
		List<BidEnrollAppl> bidEnrollApplLst = bidEnrollApplSvc.searchByProperty(bidEnrollAppl);
		if (!BaseUtil.isObjNull(bidEnrollApplLst)) {
			List<Integer> applIdLst = new ArrayList<>();
			for (BidEnrollAppl enrollAppl : bidEnrollApplLst) {
				if (!applIdLst.contains(enrollAppl.getApplId())) {
					applIdLst.add(enrollAppl.getApplId());
				}
			}

			if (!BaseUtil.isListNull(applIdLst)) {
				List<BidCertInfo> bidCertInfoLst = bidCertInfoService.findByApplIdList(applIdLst);
				if (!BaseUtil.isListNull(bidCertInfoLst)) {
					digitalIdList = new ArrayList<>();
					for (BidCertInfo certInfo : bidCertInfoLst) {
						digitalIdList.add(dozerMapper.map(certInfo, DigitalIdInfo.class));
					}
				}
			}

		}
		return digitalIdList;
	}


	private List<Device> getDeviceInfo(SecUserDevice secUserDevice) {
		List<Device> deviceList = null;
		List<SecUserDevice> secUserDeviceLst = secUserDeviceSvc.searchByProperty(secUserDevice);
		if (!BaseUtil.isListNull(secUserDeviceLst)) {
			deviceList = new ArrayList<>();
			for (SecUserDevice userDevice : secUserDeviceLst) {
				deviceList.add(dozerMapper.map(userDevice, Device.class));
			}
		}
		return deviceList;
	}


	private List<SubscriberInfo> getSubscriberInfo(BidSubscriberUser bidSubscriberUser) {
		List<SubscriberInfo> subscriberList = null;
		List<BidSubscriberUser> bidSubscriberUserLst = bidSubscriberUserSvc.searchByProperty(bidSubscriberUser);
		if (!BaseUtil.isListNull(bidSubscriberUserLst)) {
			List<Integer> subscrIdLst = new ArrayList<>();
			for (BidSubscriberUser subscriberUser : bidSubscriberUserLst) {
				if (!subscrIdLst.contains(subscriberUser.getSubscrId())) {
					subscrIdLst.add(subscriberUser.getSubscrId());
				}
			}

			BidSubscriber bidSubscriber = new BidSubscriber();
			bidSubscriber.setSubscrIdList(subscrIdLst);
			List<BidSubscriber> bidSubscriberLst = bidSubscriberSvc.searchByProperty(bidSubscriber);
			if (!BaseUtil.isListNull(bidSubscriberLst)) {
				subscriberList = new ArrayList<>();
				for (BidSubscriber subscriber : bidSubscriberLst) {
					subscriberList.add(dozerMapper.map(subscriber, SubscriberInfo.class));
				}

			}
		}
		return subscriberList;
	}


	@PostMapping(value = UriConstants.MOBILE_DIGITALID_VALIDATION, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MessageResponse digitalIdRegister(
			@RequestParam(defaultValue = TxnCodeConstants.API_DIGITALID_VERIFY) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {

		if (BaseUtil.isObjNull(mobileUser.getProfileId()) && BaseUtil.isObjNull(mobileUser.getUuid())) {
			return new MessageResponse(BeErrorCodeEnum.E400BST005, request.getRequestURI(), null);
		}

		SecUser secUser = secUserSvc.findByProfileId(mobileUser.getProfileId());
		if (BaseUtil.isObjNull(secUser)) {
			return new MessageResponse(BeErrorCodeEnum.E409BST001, request.getRequestURI(), null);
		}

		SecUserDevice secUserDevice = secUserDeviceSvc.findDeviceByUserIdUuid(secUser.getUserId(),
				mobileUser.getUuid());
		if (BaseUtil.isObjNull(secUserDevice)) {
			return new MessageResponse(BeErrorCodeEnum.E409BST001, request.getRequestURI(), null);
		}

		BidEnrollAppl bidEnrAppl = bidEnrollApplSvc.findByUsrNDeviceIdSts(secUserDevice.getDeviceId(),
				secUser.getUserId(), "A");
		if (BaseUtil.isObjNull(bidEnrAppl)) {
			return new MessageResponse(BeErrorCodeEnum.E409BST001, request.getRequestURI(), null);
		}

		BidCertInfo bidCertInfo = bidCertInfoService.findByApplId(bidEnrAppl.getApplId());
		if (BaseUtil.isObjNull(bidCertInfo)) {
			return new MessageResponse(BeErrorCodeEnum.E409BST001, request.getRequestURI(), null);
		}

		return new MessageResponse(BeErrorCodeEnum.E200BST000, request.getRequestURI(), mobileUser);
	}

}