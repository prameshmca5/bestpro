/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.MerchantCompanyCustomDao;
import com.bestpay.be.dao.PgwMerchantCompanyRepository;
import com.bestpay.be.model.PgwMerchantCompany;
import com.bestpay.be.sdk.model.MerCompany;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;


@Transactional
@Service(QualifierConstants.PGW_MERCHANT_COMPANY_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_COMPANY_SVC)
public class PgwMerchantCompanyService extends AbstractService<PgwMerchantCompany> {

	@Autowired
	private PgwMerchantCompanyRepository pgwMerchantCompanyDao;

	@Autowired
	private MerchantCompanyCustomDao merchantCompanyCustomDao;


	@Override
	public PgwMerchantCompanyRepository primaryDao() {
		return pgwMerchantCompanyDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantCompany findCompanyByCompanyId(Integer companyId) {
		return pgwMerchantCompanyDao.findCompanyByCompanyId(companyId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwMerchantCompany> searchMerchantCompany(MerCompany merchantCompany,
			DataTableRequest dataTableInRQ) {
		return merchantCompanyCustomDao.searchByPagination(merchantCompany, dataTableInRQ);
	}
	
	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantCompany findCompanyByCompRefId(String compRefId) {
		return pgwMerchantCompanyDao.findCompanyByCompRefId(compRefId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwMerchantCompany> getMerchantCompanyList() {
		return pgwMerchantCompanyDao.findAllMerchantCompany();
	}

}
