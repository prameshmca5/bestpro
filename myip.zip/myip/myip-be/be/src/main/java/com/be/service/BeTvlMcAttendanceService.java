/**
 *
 */
package com.be.service;


import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTvlMcAttendanceQf;
import com.be.dao.BeTvlMcAttendanceRepository;
import com.be.model.BeTvlMcAttendance;
import com.be.model.BeTvlProfile;
import com.be.model.RefStatus;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.McAttendance;
import com.util.BaseUtil;


/**
 * @author Atiqah Khairuddin
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_MC_ATTENDANCE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_MC_ATTENDANCE_SVC)
public class BeTvlMcAttendanceService extends AbstractService<BeTvlMcAttendance> {

	@Autowired
	private BeTvlMcAttendanceRepository beTvlMcAttendanceDao;

	@Autowired
	BeTvlMcAttendanceQf beTvlMcAttendanceQf;

	@Autowired
	BeTvlService beTvlSvc;


	@Override
	public GenericRepository<BeTvlMcAttendance> primaryDao() {
		return beTvlMcAttendanceDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beTvlMcAttendanceQf.generateCriteria(cb, from, criteria);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class })
	public BeTvlMcAttendance addAttendanceInfo(McAttendance dto, BeTvlProfile beTvlProfile, String userId)
			throws IOException {

		/*
		 * BeTvlMcAttendance beTvlMcAttendance =
		 * beTvlMcAttendanceDao.findByTvlProfile(dto.getTvlProfile()); if
		 * (BaseUtil.isObjNull(beTvlMcAttendance)) {
		 */
		BeTvlMcAttendance beTvlMcAttendance = beTvlMcAttendanceDao.findByTvlProfile(dto.getTvlProfId());
		if (BaseUtil.isObjNull(beTvlMcAttendance)) {
			beTvlMcAttendance = new BeTvlMcAttendance();

			RefStatus refStatus = new RefStatus();
			refStatus.setStatusId(dto.getStatusId());

			beTvlMcAttendance.setStatus(refStatus);
			beTvlMcAttendance.setMcProfId(dto.getMcProfId());
			beTvlMcAttendance.setTvlProfile(beTvlProfile);
			beTvlMcAttendance.setCreateId(userId);
		}

		beTvlMcAttendance.setUpdateId(userId);
		/* } */
		beTvlMcAttendance = create(beTvlMcAttendance);
		beTvlSvc.updateStatus(beTvlMcAttendance.getTvlProfile().getTvlProfId(), dto.getStatusId());

		/*
		 * BeTvlMcAttendance beTvlMcAttendance = new BeTvlMcAttendance();
		 * RefStatus refStatus = new RefStatus();
		 * refStatus.setStatusId(dto.getStatusId());
		 * beTvlMcAttendance.setStatus(refStatus);
		 * beTvlMcAttendance.setCreateId(userId); beTvlMcAttendance =
		 * create(beTvlMcAttendance);
		 */

		return beTvlMcAttendance;
	}

}
