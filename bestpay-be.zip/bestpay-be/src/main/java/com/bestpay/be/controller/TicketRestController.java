/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.model.PgwTicket;
import com.bestpay.be.model.RefStatus;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Ticket;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.service.RefStatusService;
import com.bestpay.idm.sdk.model.MenuDto;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.notify.sdk.constants.MailTemplate;
import com.bestpay.notify.sdk.constants.MailTypeEnum;
import com.bestpay.notify.sdk.model.MailAttachment;
import com.bestpay.notify.sdk.model.Notification;
import com.bestpay.notify.sdk.util.MailUtil;
import com.bstsb.util.MediaType;


/**
 * @author Atiqah Khairuddin
 * @since November 13, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.TICKET)
public class TicketRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(TicketRestController.class);

	private static final String ADM_ADMIN = "ADM_ADMIN";

	private static final String ADM_SUPPORT = "ADM_SUPPORT";

	private static final String MER_ADMIN = "MER_ADMIN";

	@Autowired
	protected RefStatusService refStatusSvc;


	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<Ticket> searchTicketPaginated(@Valid @RequestBody Ticket ticket,
			HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwTicket> result = pgwTicketService.searchTicket(ticket, dataTableInRQ);
		DataTableResults<Ticket> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			dataTableInResp.setDraw(result.getDraw());
			dataTableInResp.setError(result.getError());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<Ticket> ticketLst = new ArrayList<>();
				for (PgwTicket tck : result.getData()) {
					if (!BaseUtil.isObjNull(tck.getStatus())) {
						RefStatus refStatus = refStatusSvc.findByStatusTypeAndCode("TECHSTAT", tck.getStatus());
						tck.setStatus(refStatus.getStatusDescEn());
					}
					if (!BaseUtil.isObjNull(tck.getCategory())) {
						RefStatus refStatus = refStatusSvc.findByStatusTypeAndCode("TECHCAT", tck.getCategory());
						tck.setCategory(refStatus.getStatusDescEn());
					}
					if (!BaseUtil.isObjNull(tck.getSupportId())) {
						UserProfile userProfile = getIdmService(request).getUserProfileById(tck.getSupportId(),
								false, false);
						tck.setSupportId(userProfile.getFullName());
					}
					Ticket trustee = dozerMapper.map(tck, Ticket.class);
					ticketLst.add(trustee);
				}
				dataTableInResp.setData(ticketLst);
			}
		}
		return dataTableInResp;
	}


	@GetMapping(value = "/{ticketId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Ticket getTicketById(@PathVariable Integer ticketId) {

		PgwTicket pgwTicket = super.pgwTicketService.findByTicketId(ticketId);

		Ticket ticket = new Ticket();
		if (!BaseUtil.isObjNull(pgwTicket)) {
			ticket = dozerMapper.map(pgwTicket, Ticket.class);
		}
		return ticket;
	}


	@PostMapping(value = BeUrlConstants.CREATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Ticket create(@Valid @RequestBody Ticket ticket, HttpServletRequest request, HttpServletResponse response)
			throws BeException {

		if (ticket == null) {// restriction null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		if (StringUtils.isBlank(ticket.getMerchantId())) {// no
			// merchant
			// name
			throw new BeException(BeErrorCodeEnum.I400IDM137, new String[] { "Ticket", "Ticket" });
		}

		PgwTicket pgwTicket = new PgwTicket();

		pgwTicket.setMerchantId(ticket.getMerchantId());
		pgwTicket.setIssuerDate(new Timestamp(new Date().getTime()));
		pgwTicket.setName(ticket.getName());
		pgwTicket.setContact(ticket.getContact());
		pgwTicket.setEmail(ticket.getEmail());
		pgwTicket.setSubject(ticket.getSubject());
		pgwTicket.setDescription(ticket.getDescription());
		pgwTicket.setStatus("OPEN");
		pgwTicket.setCategory(ticket.getCategory());
		pgwTicket.setModule(ticket.getModule());
		if (!BaseUtil.isObjNull(ticket.getDocMgtId())) {
			pgwTicket.setDocMgtId(ticket.getDocMgtId());
		}
		pgwTicket.setCreateId(ticket.getUserId());
		super.pgwTicketService.create(pgwTicket);
		Integer tcktid = pgwTicketService.findTicketId(ticket.getMerchantId());
		LOGGER.info("ticket id = {}", tcktid);
		sendMailTicket(ticket.getMerchantId(), tcktid, "", ticket.getUserRoleGroupCode(), "", request);

		Ticket restr = new Ticket();
		PgwTicket pgwTckt = super.pgwTicketService.findByTicketId(ticket.getTicketId());
		if (!BaseUtil.isObjNull(pgwTckt)) {
			restr = dozerMapper.map(pgwTckt, Ticket.class);
		}
		return restr;
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Ticket updateTicket(@Valid @RequestBody Ticket ticket, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		if (ticket == null) {// ticket null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}

		PgwTicket pgwTicket = super.pgwTicketService.findByTicketId(ticket.getTicketId());

		if (!BaseUtil.isObjNull(pgwTicket)) {

			if (BaseUtil.isEqualsCaseIgnore(ticket.getUserRoleGroupCode(), ADM_ADMIN)) {
				pgwTicket.setStatus("INP");
				pgwTicket.setSupportId(ticket.getSupportId());
			}

			if (BaseUtil.isEqualsCaseIgnore(ticket.getUserRoleGroupCode(), ADM_SUPPORT)) {
				pgwTicket.setStatus(ticket.getStatus());
			}

			if (BaseUtil.isEqualsCaseIgnore(ticket.getUserRoleGroupCode(), MER_ADMIN)) {
				pgwTicket.setFeedback(ticket.getFeedback());
			}

			pgwTicket.setUpdateId(ticket.getUserId());
			super.pgwTicketService.update(pgwTicket);
			Integer tcktid = pgwTicketService.findByTicket(pgwTicket.getTicketId());
			String feedback = pgwTicketService.findFeedback(tcktid);
			sendMailTicket(pgwTicket.getMerchantId(), tcktid, ticket.getSupportId(), ticket.getUserRoleGroupCode(),
					feedback, request);
		}

		Ticket ticketInfo = new Ticket();
		PgwTicket updateTicket = super.pgwTicketService.findByTicketId(ticket.getTicketId());
		if (!BaseUtil.isObjNull(updateTicket)) {
			ticketInfo = dozerMapper.map(updateTicket, Ticket.class);
		}
		return ticketInfo;
	}


	private void sendMailTicket(String merchantId, int ticketId, String supportid, String userRoleGroupCode,
			String feedback, HttpServletRequest request) {
		List<MailAttachment> attachments = null;
		PgwTicket pgwTicket = super.pgwTicketService.findByMerchantIdTicketId(merchantId, ticketId);
		UserProfile userProfile = new UserProfile();

		// admin send an email to support
		if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, ADM_ADMIN)) {
			userProfile = getIdmService(request).getUserProfileById(supportid, false, false);
		}

		PgwMerchantProfile pgwMerchantProfile = super.pgwMerchantProfileService
				.findMerProfileByMerchantId(merchantId);

		RefStatus refStatusCategory = refStatusSvc.findByStatusCode(pgwTicket.getCategory());
		RefStatus refStatusStatus = refStatusSvc.findByStatusCode(pgwTicket.getStatus());
		MenuDto idmMenu = getIdmService(request).findMenuByMenuCode(pgwTicket.getModule());

		Map<String, Object> map = new HashMap<>();
		Map<String, String> notConfig = getNotifyService(request).findAllConfig();
		String feedbacks = "";
		if (!BaseUtil.isObjNull(feedback)) {
			feedbacks = feedback.substring(0, 1).toUpperCase() + feedback.substring(1);
		}
		String subject = pgwTicket.getSubject();
		String subjects = subject.substring(0, 1).toUpperCase() + subject.substring(1);
		String ctnt = "";
		if (BaseUtil.isEqualsCaseIgnore(pgwTicket.getStatus(), "SOLVED")) {
			ctnt = "Please check and re-test. Below is ticket details :";
		} else if (BaseUtil.isEqualsCaseIgnore(pgwTicket.getStatus(), "INP")
				|| BaseUtil.isEqualsCaseIgnore(pgwTicket.getStatus(), "OPEN")) {
			ctnt = "Your ticket is in progress and is being worked on by our team. We're prioritizing your request, and we will make sure this issue is resolved as soon as possible. Thanks for your patience.";
		}
		LOGGER.info("status = {} and content = {}", pgwTicket.getStatus(), ctnt);
		map.put("merchantId", pgwMerchantProfile.getMerchantId().toUpperCase());
		map.put("ticketId", ticketId);
		map.put("subject", subjects);
		map.put("module", idmMenu.getMenuDesc());
		map.put("category", refStatusCategory.getStatusDescEn());
		map.put("feedback", feedbacks);
		map.put("status", refStatusStatus.getStatusDescEn());
		map.put("ctnt", ctnt);

		// admin send an email to support
		if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, ADM_ADMIN)
				|| BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, MER_ADMIN)) {
			map.put("supportName", userProfile.getFullName());
		}

		// support send an email to merchant
		if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, ADM_SUPPORT) || !BaseUtil.isObjNull(feedback)) {
			map.put("companyName", pgwMerchantProfile.getCompany());
		}

		String fwcmsUrl = "";

		// merchant send an email to admin
		if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, MER_ADMIN)) {
			fwcmsUrl = notConfig.get("PORTAL_URL_ADM");
		}

		// admin send an email to support
		if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, ADM_ADMIN)) {
			fwcmsUrl = notConfig.get("PORTAL_URL_ADM");
		}

		// support send an email to merchant
		if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, ADM_SUPPORT)) {
			fwcmsUrl = notConfig.get("PORTAL_URL_MER");
		}

		map.put("fwcmsUrl", fwcmsUrl);

		Notification notification = new Notification();
		// merchant send an email to admin
		if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, MER_ADMIN)) {
			notification.setNotifyTo("support@bestpay.com.my");
		}
		// admin send an email to support
		else if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, ADM_ADMIN)) {
			notification.setNotifyTo(userProfile.getEmail());
		}
		// support send an email to merchant
		else if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, ADM_SUPPORT)) {
			notification.setNotifyTo(pgwMerchantProfile.getEmail());
		}

		// merchant send an email to admin
		if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, MER_ADMIN)) {
			if (BaseUtil.isObjNull(feedback)) {
				notification.setSubject(
						MessageFormat.format(MailTemplate.TICKET_NOTIFICATION.getSubject(), merchantId));
			} else {
				notification.setSubject(
						MessageFormat.format(MailTemplate.TICKET_FEEDBACK_NOTIFICATION.getSubject(), merchantId));
			}
		}
		// admin send an email to support
		else if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, ADM_ADMIN)) {
			notification.setSubject(
					MessageFormat.format(MailTemplate.TICKET_SUPPORT_NOTIFICATION.getSubject(), merchantId));
		}
		// support send an email to merchant
		else if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, ADM_SUPPORT)) {
			notification.setSubject(MessageFormat.format(MailTemplate.TICKET_STATUS_NOTIFICATION.getSubject(),
					pgwMerchantProfile.getCompany()));
		}

		notification.setMetaData(MailUtil.convertMapToJson(map));
		notification.setAttachments(attachments);

		// merchant send an email to admin
		if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, MER_ADMIN)) {
			if (BaseUtil.isObjNull(feedback)) {
				getNotifyService(request).addNotification(notification, MailTypeEnum.MAIL,
						MailTemplate.TICKET_NOTIFICATION);
			} else {
				getNotifyService(request).addNotification(notification, MailTypeEnum.MAIL,
						MailTemplate.TICKET_FEEDBACK_NOTIFICATION);
			}
		}
		// admin send an email to support
		else if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, ADM_ADMIN)) {
			getNotifyService(request).addNotification(notification, MailTypeEnum.MAIL,
					MailTemplate.TICKET_SUPPORT_NOTIFICATION);
		}
		// support send an email to merchant
		else if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, ADM_SUPPORT)) {
			getNotifyService(request).addNotification(notification, MailTypeEnum.MAIL,
					MailTemplate.TICKET_STATUS_NOTIFICATION);
		}

	}


	@GetMapping(value = BeUrlConstants.TKT_CNT_ALLSTATUS + "/{merchantId}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<String> getCountOfAllStatus(@PathVariable String merchantId, HttpServletRequest request) {
		return super.pgwTicketService.getCountOfAllStatus(merchantId);
	}

}
