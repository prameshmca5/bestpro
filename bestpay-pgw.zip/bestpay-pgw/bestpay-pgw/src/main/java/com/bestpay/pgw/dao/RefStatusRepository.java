/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.RefStatus;
import com.bestpay.pgw.util.QualifierConstants;

/**
 * @author Mary Jane Buenaventura
 * @since Nov 3, 2016
 */
@Repository
@RepositoryDefinition(domainClass = RefStatus.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_STATUS_DAO)
public interface RefStatusRepository extends GenericRepository<RefStatus> {

	@Query("select u from RefStatus u where u.statusCode = :statusCode ")
	public RefStatus findByStatusCode(@Param("statusCode") String statusCode);

	@Query("select u from RefStatus u where u.statusType = :statusType ")
	public List<RefStatus> findByStatusType(
			@Param("statusType") String statusType);

	@Query("select u from RefStatus u where u.statusDescEn = TRIM(:statusDescEn)")
	public RefStatus findByStatusDescEn(
			@Param("statusDescEn") String statusDescEn);

}