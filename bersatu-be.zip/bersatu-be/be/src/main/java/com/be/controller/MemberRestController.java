package com.be.controller;


import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.be.constants.ConfigConstants;
import com.be.core.AbstractRestController;
import com.be.dao.BeMemberProfileRepository;
import com.be.model.BeConfig;
import com.be.model.BeMemberAddress;
import com.be.model.BeMemberProfile;
import com.be.model.BePreReg;
import com.be.model.BeTrxnDocument;
import com.be.model.BeTrxnDocumentPK;
import com.be.model.RefBranch;
import com.be.model.RefDivision;
import com.be.model.RefDocument;
import com.be.model.RefMetadata;
import com.be.model.RefState;
import com.be.model.RefStatus;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.constants.FileUploadConstants;
import com.be.sdk.constants.MailTemplateConstants;
import com.be.sdk.constants.ReferenceConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.AckSlip;
import com.be.sdk.model.MemberAddress;
import com.be.sdk.model.MemberBlastMessage;
import com.be.sdk.model.MemberProfile;
import com.be.sdk.model.Metadata;
import com.be.sdk.model.PaymentDtl;
import com.be.sdk.model.PreReg;
import com.be.sdk.model.TrxnDocuments;
import com.be.sdk.model.Watchlist;
import com.be.service.BeConfigService;
import com.be.service.BeCtrlGenService;
import com.be.service.BeMemberAddressService;
import com.be.service.BeMemberProfileService;
import com.be.service.BePaymentDtlService;
import com.be.service.BePreRegService;
import com.be.service.BeTrxnDocumentsService;
import com.be.service.BeWatchlistService;
import com.be.service.RefBranchService;
import com.be.service.RefDivisionService;
import com.be.service.RefDocumentService;
import com.be.service.RefMetadataService;
import com.be.service.RefStateService;
import com.be.service.RefStatusService;
import com.dm.sdk.model.Documents;
import com.notify.sdk.constants.MailTypeEnum;
import com.notify.sdk.model.Notification;
import com.notify.sdk.util.MailUtil;
import com.report.sdk.constants.ReportTypeEnum;
import com.report.sdk.model.Report;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.MediaType;
import com.util.UidGenerator;
import com.util.pagination.DataTableRequest;
import com.util.pagination.DataTableResults;


@RestController
@RequestMapping(BeUrlConstants.MEMBER)
public class MemberRestController extends AbstractRestController {

	@Autowired
	BeMemberProfileService beMemberProfileSvc;

	@Autowired
	RefStatusService refStatusSvc;

	@Autowired
	BeTrxnDocumentsService beTrxnDocumentsSvc;

	@Autowired
	BeMemberAddressService beMemberAddressSvc;

	@Autowired
	BePreRegService bePreRegSvc;

	@Autowired
	RefMetadataService refMetadataSvc;

	@Autowired
	BeWatchlistService beWatchlistSvc;

	@Autowired
	BeConfigService beConfigSvc;

	@Autowired
	RefDivisionService refDivisionSvc;

	@Autowired
	RefMetadataService refMetaSvc;

	@Autowired
	RefBranchService refBranchSvc;

	@Autowired
	RefStateService RefStateSvc;

	@Autowired
	RefDocumentService documentSvc;

	@Autowired
	BeTrxnDocumentsService trxnDocumentSvc;

	@Autowired
	private BePaymentDtlService bePaymentDtlSvc;

	@Autowired
	private BeCtrlGenService beCtrlGenSvc;
	
	@Autowired
	private BeMemberProfileRepository beMemberProfileDao;


	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<MemberProfile> searchPaginated(@Valid @RequestBody MemberProfile dto,
			HttpServletRequest request) throws IOException {
		DataTableRequest<MemberProfile> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) beMemberProfileSvc.getCount(dto);
		List<MemberProfile> filtered = beMemberProfileSvc.searchPagination(dto, dataTableInRQ);
		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATIONS, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<MemberProfile> searchPaginatedList(@Valid @RequestBody MemberProfile dto,
			HttpServletRequest request) throws IOException {
		DataTableRequest<MemberProfile> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) beMemberProfileSvc.getCount(dto);
		List<MemberProfile> filtered = beMemberProfileSvc.searchPagination(dto, dataTableInRQ);

		for (MemberProfile task : filtered) {
			String currData = "-";

			if (!BaseUtil.isObjNull(task.getOrgStateCd())) {
				RefState refState = RefStateSvc.findByStateCode(task.getOrgStateCd());
				if (!BaseUtil.isObjNull(refState)) {
					task.setOrgStateDesc(refState.getStateDesc());
				} else {
					task.setOrgStateDesc(currData);
				}

			} else {

				task.setOrgStateDesc(currData);
			}

			if (!BaseUtil.isObjNull(task.getOrgDivisionCd())) {
				RefDivision refDiv = refDivisionSvc.findByDivisionCd(task.getOrgDivisionCd());
				if (!BaseUtil.isObjNull(refDiv)) {
					task.setOrgDivisionDesc(refDiv.getDivisionDesc());
				} else {
					task.setOrgDivisionDesc(currData);
				}
			} else {
				task.setOrgDivisionDesc(currData);

			}

			if (!BaseUtil.isObjNull(task.getOrgBranchCd())) {
				RefBranch refDiv = refBranchSvc.findByBranchCd(task.getOrgBranchCd());
				if (!BaseUtil.isObjNull(refDiv)) {
					task.setOrgBranchDesc(refDiv.getBranchDesc());
				} else {
					task.setOrgBranchDesc(currData);
				}
			} else {
				task.setOrgBranchDesc(currData);

			}

			if (!BaseUtil.isObjNull(task.getMemberCtrgyMtdtId())) {
				RefMetadata refMetaSearch = new RefMetadata();
				refMetaSearch.setMtdtId(task.getMemberCtrgyMtdtId());

				List<RefMetadata> refMetaResult = refMetaSvc.findMetadataByCriteria(refMetaSearch);
				if (BaseUtil.isObjNull(refMetaResult)) {
					task.setMemberCtrgyMtdtDesc(currData);
				} else {
					task.setMemberCtrgyMtdtDesc(refMetaResult.get(0).getMtdtDesc());

				}

			} else {
				task.setMemberCtrgyMtdtDesc(currData);
			}

		}
		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.SEARCH)
	public MemberProfile searchMemberProfile(@RequestBody MemberProfile dto, HttpServletRequest request)
			throws IOException {
		// MEMBER_ID, TXN_ID, MEMBER_REF_NO, ID_NO
		return beMemberProfileSvc.search(dto);
	}


	@PostMapping(value = BeUrlConstants.SEARCH_LIST)
	public List<MemberProfile> searchMemberProfileList(@RequestBody MemberProfile dto, HttpServletRequest request)
			throws IOException {
		// TXN_ID LIST
		return beMemberProfileSvc.searchMemberProfileList(dto);
	}


	@PostMapping(value = BeUrlConstants.CREATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MemberProfile createMemberProfile(@RequestBody MemberProfile dto, HttpServletRequest request) {

		boolean isExistReg = false;
		if (!BaseUtil.isObjNull(dto.getRegExistMtdtId())) {
			RefMetadata mtdtExistReg = refMetadataSvc.find(dto.getRegExistMtdtId());
			if (!BaseUtil.isObjNull(mtdtExistReg)) {
				if (BaseUtil.isEquals(mtdtExistReg.getMtdtCd(), ReferenceConstants.MTDT_CD_EXIST_Y)) {
					isExistReg = true;
				}
			}
		}

		if (!isExistReg && BaseUtil.isObjNull(dto.getPreRegId())) {
			throw new BeException(BeErrorCodeEnum.E400C006);
		}

		if (isExistReg) {
			// check if id no valid for registration process, will throw
			// exception if not valid
			checkValidRegIdNo(dto.getIdNo());

			// check if contact no is exist or not
			BeConfig beConf = beConfigSvc.findByConfigCode(ConfigConstants.CONFIG_CONTACT_NO);
			if (BaseUtil.isEquals(beConf.getConfigVal(), "1")) {
				checkContactNo(dto.getContactNo());
			}
		}

		RefStatus refStatus = refStatusSvc.find(dto.getStatusId());
		if (BaseUtil.isObjNull(refStatus)) {
			throw new BeException(BeErrorCodeEnum.E500C002);
		}

		String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();
		BeMemberProfile crtMemberProfile = null;
		Set<BeTrxnDocument> beTrxnDocumentsList = null;
		if (BaseUtil.isEqualsCaseIgnore("VER", refStatus.getStatusCd())) {
			crtMemberProfile = dozerMapper.map(dto, BeMemberProfile.class);
			// String appRefNo = UidGenerator.generateUidYear("MBR");
			String appRefNo = null;
			crtMemberProfile.setTxnId(UidGenerator.getMessageId());

			if (BaseUtil.isObjNull(dto.getMemberNo())) {
				appRefNo = beCtrlGenSvc.generateSeqNo("MEMBERNO", "MBR");
				crtMemberProfile.setMemberNo(appRefNo);
				crtMemberProfile.setMemberRefNo(appRefNo);
			} else {
				appRefNo = dto.getMemberNo();
				crtMemberProfile.setMemberNo(dto.getMemberNo());
				crtMemberProfile.setMemberRefNo(dto.getMemberNo());
				
				if (BaseUtil.isObjNull(dto.getApplyDt())) {//Approve date
					crtMemberProfile.setApproveDt(currDt);
					crtMemberProfile.setApproveBy(userId);
				} else {
					crtMemberProfile.setApproveDt(dto.getApplyDt());
					crtMemberProfile.setApproveBy(userId);
				}

			}

			if (!BaseUtil.isListNull(dto.getMemberAddressList())) {
				List<BeMemberAddress> memberAddList = dto.getMemberAddressList().stream().map(address -> {
					BeMemberAddress memberAdd = dozerMapper.map(address, BeMemberAddress.class);
					memberAdd.setStatus(true);
					memberAdd.setCreateId(userId);
					memberAdd.setCreateDt(currDt);
					memberAdd.setUpdateId(userId);
					memberAdd.setUpdateDt(currDt);

					return memberAdd;
				}).collect(Collectors.toList());

				crtMemberProfile.addBeMemberAddressList(memberAddList);
			}

			if (!BaseUtil.isListNull(dto.getTrxnDocumentList())) {
				String docRefNo = UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC);
				crtMemberProfile.setDocRefNo(docRefNo);
				String memberNo = crtMemberProfile.getMemberNo();
				beTrxnDocumentsList = dto.getTrxnDocumentList().stream().map(doc -> {
					BeTrxnDocumentPK docPk = new BeTrxnDocumentPK();
					docPk.setDocRefNo(docRefNo);
					docPk.setDocId(doc.getDocId());
					docPk.setDocMgtId(doc.getDocMgtId());
					BeTrxnDocument trxnDoc = new BeTrxnDocument(docPk, memberNo, doc.getDocContentType());
					trxnDoc.setCreateId(userId);
					trxnDoc.setCreateDt(currDt);
					trxnDoc.setUpdateId(userId);
					trxnDoc.setUpdateDt(currDt);
					return trxnDoc;
				}).collect(Collectors.toSet());
			}

			if (BaseUtil.isObjNull(dto.getApplyDt())) {
				crtMemberProfile.setApplyDt(currDt);
			} else {
				crtMemberProfile.setApplyDt(dto.getApplyDt());
			}
			crtMemberProfile.setPositionId(dto.getPositionId());
			crtMemberProfile.setMemberCtrgyMtdtId(dto.getMemberCtrgyMtdtId());
			crtMemberProfile.setCredentialInd(0);
			crtMemberProfile.setApplyBy(userId);
			crtMemberProfile.setCreateId(userId);
			crtMemberProfile.setCreateDt(currDt);
			crtMemberProfile.setUpdateId(userId);
			crtMemberProfile.setUpdateDt(currDt);

		}

		BePreReg bePreReg = null;
		if (!BaseUtil.isObjNull(dto.getPreRegId())) {
			bePreReg = bePreRegSvc.find(dto.getPreRegId());
			if (BaseUtil.isObjNull(bePreReg)) {
				throw new BeException(BeErrorCodeEnum.E500C001);
			}

			if (!BaseUtil.isObjNull(dto.getPositionId())) {
				bePreReg.setPositionId(dto.getPositionId());
			}

			bePreReg.setApproveBy(userId);
			bePreReg.setApproveDt(currDt);
			String remarks = dto.getApproveRemarks();
			if (BaseUtil.isEquals("", remarks)) {
				remarks = "LULUS";
			}
			bePreReg.setApproveRemarks(remarks);
			bePreReg.setStatusId(dto.getStatusId());
			bePreReg.setUpdateId(userId);
			bePreReg.setUpdateDt(currDt);
		}

		if (!isExistReg) {
			RefMetadata existRegMtdt = refMetadataSvc.findByMtdtTypeMtdtCd("REG_EXIST", "EXIST_N");

			if (!BaseUtil.isObjNull(existRegMtdt)) {
				crtMemberProfile.setRegExistMtdtId(existRegMtdt.getMtdtId());
			}
		}

		crtMemberProfile = beMemberProfileSvc.create(crtMemberProfile, beTrxnDocumentsList, bePreReg);

//		try {
//			// generate genAppFormReport and genApprovalLetter form
//			if (!BaseUtil.isObjNull(crtMemberProfile)) {
//				LOGGER.info("try save application form and approval letter");
//				List<RefDocument> docs = new ArrayList<>();
//				List<RefDocument> bpDoc = documentSvc
//						.findTrxnDocumentsByDocTrxnNo(FileUploadConstants.DOC_TRXN_BORANG_PERMOHONAN);
//				docs.addAll(bpDoc);
//				List<RefDocument> skDoc = documentSvc
//						.findTrxnDocumentsByDocTrxnNo(FileUploadConstants.DOC_TRXN_SURAT_KELULUSAN);
//				docs.addAll(skDoc);
//
//				if (!BaseUtil.isListNull(docs)) {
//					for (RefDocument oneDoc : docs) {
//						Report report = null;
//						Documents documents = null;
//						MemberProfile memberProfile = new MemberProfile();
//						memberProfile.setTxnId(crtMemberProfile.getTxnId());
//
//						if (oneDoc.getDocTrxnNo().equals(FileUploadConstants.DOC_TRXN_BORANG_PERMOHONAN)) {
//							LOGGER.info("try generate application form");
//							report = getReportService(request).report().genAppFormReport(memberProfile,
//									ReportTypeEnum.PDF);
//						} else if (oneDoc.getDocTrxnNo().equals(FileUploadConstants.DOC_TRXN_SURAT_KELULUSAN)) {
//							LOGGER.info("try generate approval letter");
//							report = getReportService(request).report().genApprovalLetter(memberProfile,
//									ReportTypeEnum.PDF);
//						}
//
//						if (!BaseUtil.isObjNull(report.getReportBytes())) {
//							documents = trxnDocumentSvc.upload(oneDoc, report, crtMemberProfile.getDocRefNo(),
//									request);
//							if (!BaseUtil.isObjNull(documents)) {
//								BeTrxnDocument trxnDocument = new BeTrxnDocument();
//								trxnDocument.setId(new BeTrxnDocumentPK(crtMemberProfile.getDocRefNo(),
//										documents.getDocid(), documents.getId()));
//								trxnDocument.setDocContentType(documents.getContentType());
//								trxnDocumentSvc.create(trxnDocument);
//							}
//						}
//
//					}
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		return dozerMapper.map(crtMemberProfile, MemberProfile.class);
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MemberProfile updateMemberProfile(@RequestBody MemberProfile dto, HttpServletRequest request) {

		BeMemberProfile beMemberProfile = beMemberProfileSvc.find(dto.getMemberId());
		if (BaseUtil.isObjNull(beMemberProfile)) {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}

		beMemberProfile.setFullName(dto.getFullName());
		beMemberProfile.setGenderMtdtId(dto.getGenderMtdtId());
		beMemberProfile.setReligionMtdtId(dto.getReligionMtdtId());
		beMemberProfile.setDob(dto.getDob());
		beMemberProfile.setEthnicMtdtId(dto.getEthnicMtdtId());
		beMemberProfile.setContactNo(dto.getContactNo());
		beMemberProfile.setEmail(dto.getEmail());
		beMemberProfile.setEduMtdtId(dto.getEduMtdtId());
		beMemberProfile.setEduDesc(dto.getEduDesc());
		beMemberProfile.setOccupationMtdtId(dto.getOccupationMtdtId());
		beMemberProfile.setOrgStateCd(dto.getOrgStateCd());
		beMemberProfile.setOrgDivisionCd(dto.getOrgDivisionCd());
		beMemberProfile.setOrgBranchCd(dto.getOrgBranchCd());
		beMemberProfile.setSprStateCd(dto.getSprStateCd());
		beMemberProfile.setParliamentCode(dto.getParliamentCode());
		beMemberProfile.setDunCode(dto.getDunCode());
		beMemberProfile.setVoterRegMtdtId(dto.getVoterRegMtdtId());
		beMemberProfile.setMemberCtrgyMtdtId(dto.getMemberCtrgyMtdtId());
		beMemberProfile.setMemberTypeMtdtId(dto.getMemberTypeMtdtId());
		beMemberProfile.setPositionId(dto.getPositionId());
		if (!BaseUtil.isObjNull(dto.getRegExistMtdtId())) {
			beMemberProfile.setRegExistMtdtId(dto.getRegExistMtdtId());
			RefMetadata existRegMtdt = refMetadataSvc.findByMtdtTypeMtdtCd("REG_EXIST", "EXIST_Y");
			if(!BaseUtil.isObjNull(existRegMtdt) && dto.getRegExistMtdtId().intValue() == existRegMtdt.getMtdtId().intValue()) {
				beMemberProfile.setApproveDt(dto.getApplyDt());
			}
		}
		beMemberProfile.setMemberNo(dto.getMemberNo());
		beMemberProfile.setApplyDt(dto.getApplyDt());
		if (!BaseUtil.isObjNull(dto.getCredentialInd())) {
			beMemberProfile.setCredentialInd(dto.getCredentialInd());
		}
		String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();

		if (!BaseUtil.isListNull(dto.getMemberAddressList())) {
			List<BeMemberAddress> memberAddList = dto.getMemberAddressList().stream().map(address -> {

				BeMemberAddress memberAdd = null;
				if (!BaseUtil.isObjNull(address.getMemberAddressId())) {
					memberAdd = beMemberAddressSvc.find(address.getMemberAddressId());
				}

				if (BaseUtil.isObjNull(memberAdd)) {
					memberAdd.setStatus(true);
					memberAdd.setCreateId(userId);
					memberAdd.setCreateDt(currDt);
				}
				memberAdd.setAddressTypeMtdtId(address.getAddressTypeMtdtId());
				memberAdd.setAddress1(address.getAddress1());
				memberAdd.setAddress2(address.getAddress2());
				memberAdd.setAddress3(address.getAddress3());
				memberAdd.setPostcode(address.getPostcode());
				memberAdd.setStateCd(address.getStateCd());
				memberAdd.setCityCd(address.getCityCd());
				memberAdd.setCountryCd(address.getCountryCd());
				memberAdd.setUpdateId(userId);
				memberAdd.setUpdateDt(currDt);
				return memberAdd;
			}).collect(Collectors.toList());

			beMemberProfile.addBeMemberAddressList(memberAddList);
		}

		List<BeTrxnDocument> beTrxnDocumentsList = null;
		List<BeTrxnDocument> beTrxnDocumentDelList = null;
		if (!BaseUtil.isListNull(dto.getTrxnDocumentList())) {
			beTrxnDocumentsList = new ArrayList<>();
			beTrxnDocumentDelList = new ArrayList<>();
			String docRefNo = beMemberProfile.getDocRefNo();
			if (BaseUtil.isObjNull(docRefNo)) {
				docRefNo = UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC);
				beMemberProfile.setDocRefNo(docRefNo);
			}
			for (TrxnDocuments doc : dto.getTrxnDocumentList()) {
				BeTrxnDocument trxnDoc = null;
				List<BeTrxnDocument> trxnDocList = null;
				if (!BaseUtil.isObjNull(doc.getDocRefNo()) && !BaseUtil.isObjNull(doc.getDocId())) {
					trxnDocList = beTrxnDocumentsSvc.getTrxnDocumentsByRefNoAndDocId(doc.getDocRefNo(),
							doc.getDocId());
				}

				if (BaseUtil.isListNull(trxnDocList)) {
					BeTrxnDocumentPK docPk = new BeTrxnDocumentPK();
					docPk.setDocRefNo(docRefNo);
					docPk.setDocId(doc.getDocId());
					trxnDoc = new BeTrxnDocument(docPk, beMemberProfile.getMemberRefNo(), doc.getDocContentType());
					trxnDoc.setCreateId(userId);
					trxnDoc.setCreateDt(currDt);
				} else {
					trxnDoc = trxnDocList.get(0);
					BeTrxnDocument delDoc = dozerMapper.map(trxnDoc, BeTrxnDocument.class);
					beTrxnDocumentDelList.add(delDoc);
				}

				trxnDoc.getId().setDocMgtId(doc.getDocMgtId());
				trxnDoc.setDocContentType(doc.getDocContentType());
				trxnDoc.setUpdateId(userId);
				trxnDoc.setUpdateDt(currDt);
				beTrxnDocumentsList.add(trxnDoc);
			}
		}

		beMemberProfile.setUpdateId(userId);
		beMemberProfile.setUpdateDt(currDt);
		beMemberProfile = beMemberProfileSvc.update(beMemberProfile, beTrxnDocumentsList, beTrxnDocumentDelList);
		return dozerMapper.map(beMemberProfile, MemberProfile.class);
	}


	@PostMapping(value = BeUrlConstants.TRANSFER, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MemberProfile updateMemberTransfer(@RequestBody MemberProfile dto, HttpServletRequest request) {

		BeMemberProfile beMemberProfile = beMemberProfileSvc.find(dto.getMemberId());
		if (BaseUtil.isObjNull(beMemberProfile)) {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}

		if (!BaseUtil.isObjNull(beMemberProfile)) {
			// State update
			String usertypeCode = "";
			String userRole = "";
			String oldState = beMemberProfile.getOrgStateCd();
			String newState = dto.getOrgStateCd();
			if (!BaseUtil.isEquals(oldState, newState)) {
				usertypeCode = "STATE";
				userRole = "STATE_USER";
			} else {
				// Div Update
				String oldDiv = beMemberProfile.getOrgDivisionCd();
				String newDiv = dto.getOrgDivisionCd();
				if (!BaseUtil.isEquals(oldDiv, newDiv)) {
					usertypeCode = "DIV";
					userRole = "DIV_ADMIN";
				} else {
					// Branch Update
					usertypeCode = "BRANCH";
					userRole = "NORMAL_USER";
				}
			}
			beMemberProfile.setOrgStateCd(dto.getOrgStateCd());
			beMemberProfile.setOrgDivisionCd(dto.getOrgDivisionCd());
			beMemberProfile.setOrgBranchCd(dto.getOrgBranchCd());
			beMemberProfile.setTransferRemarks(dto.getTransferRemarks());
			beMemberProfile.setTxnId(dto.getTxnId());

			beMemberProfile = beMemberProfileSvc.updateTransfer(beMemberProfile, usertypeCode, userRole, request);
		}

		return dozerMapper.map(beMemberProfile, MemberProfile.class);
	}


	@PostMapping(value = BeUrlConstants.COUNT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Integer countMemberProfile(@Valid @RequestBody MemberProfile dto, HttpServletRequest request)
			throws IOException {
		return (int) beMemberProfileSvc.getCount(dto);
	}


	@GetMapping(value = BeUrlConstants.CHECK_VALID_REG_IDNO, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Integer checkValidityRegIdNo(@RequestParam(value = "idNo", required = true) String idNo) {
		if (!BaseUtil.isObjNull(idNo)) {
			RefStatus statusPend = refStatusSvc.findByStatusCodeStatusType(ReferenceConstants.REG_STATUS_PEND,
					ReferenceConstants.STATUS_TYPE_REG_STATUS);
			RefStatus statusFailed = refStatusSvc.findByStatusCodeStatusType(ReferenceConstants.REG_STATUS_FAILED,
					ReferenceConstants.STATUS_TYPE_REG_STATUS);
//			RefStatus statusRej = refStatusSvc.findByStatusCodeStatusType(ReferenceConstants.REG_STATUS_REJ,
//					ReferenceConstants.STATUS_TYPE_REG_STATUS);
			RefMetadata mtdtSelfReg = refMetaSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_REG_CHANNEL,
					"WEB_SELF");
			RefMetadata mtdtMobile = refMetaSvc.findByMtdtTypeMtdtCd(ReferenceConstants.MTDT_REG_CHANNEL,
					"MOB_SELF");
			List<Integer> statusList = new ArrayList<>();
			statusList.add(statusPend.getStatusId());
			statusList.add(statusFailed.getStatusId());
//			statusList.add(statusRej.getStatusId());
			List<Integer> channelMtdtList = new ArrayList<>();
			channelMtdtList.add(mtdtSelfReg.getMtdtId());
			channelMtdtList.add(mtdtMobile.getMtdtId());
			PreReg tempPreReg = new PreReg();
			tempPreReg.setIdNo(idNo);
			tempPreReg.setStatusIdList(statusList);
			tempPreReg.setChannelMtdtIdList(channelMtdtList);
			int tempPreRegCount = (int) bePreRegSvc.getCount(tempPreReg);
			if (tempPreRegCount != 0) {
				return 4;
			}
			
			RefStatus status = refStatusSvc.findByStatusCodeStatusType(ReferenceConstants.REG_STATUS_REJ,
					ReferenceConstants.STATUS_TYPE_REG_STATUS);
			PreReg preReg = new PreReg();
			preReg.setIdNo(idNo);
			preReg.setStatusId(status.getStatusId());
			preReg.setNotIn(true);
			int preRegCount = (int) bePreRegSvc.getCount(preReg);
			if (preRegCount != 0) {
				return 1;
			}

			MemberProfile memberProf = new MemberProfile();
			memberProf.setIdNo(idNo);
			memberProf.setStatusId(status.getStatusId());
			memberProf.setNotIn(true);
			int memberProfCount = (int) beMemberProfileSvc.getCount(memberProf);
			if (memberProfCount != 0) {
				return 1;
			}

			Watchlist watchlist = new Watchlist();
			watchlist.setIdNo(idNo);
			watchlist.setStatus(true);
			int watchlistCount = (int) beWatchlistSvc.getCount(watchlist);
			if (watchlistCount != 0) {
				return 2;
			}
		} else {
			return 1;
		}
		return 0;
	}


	@PostMapping(value = BeUrlConstants.BLOCK, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MemberProfile updateBlock(@RequestBody MemberProfile dto, HttpServletRequest request) throws IOException {

		try {
			if (BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getTxnId())) {
				throw new BeException(BeErrorCodeEnum.E400C913);
			}
			RefStatus refStatus = refStatusSvc.findByStatusCodeStatusType("BLK", "REG_STATUS");
			dto.setStatusId(refStatus.getStatusId());
			beMemberProfileSvc.blockMemberProfile(dto);
			return dto; // dozerMapper.map(crtPreReg, PreReg.class);

		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	@PostMapping(value = BeUrlConstants.UPDATE_ENDORSEMENT_STATUS, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<MemberProfile> updateEndorsement(@RequestBody List<MemberProfile> dtoList, HttpServletRequest request)
			throws IOException {
		List<MemberProfile> memberProfileList = new ArrayList<>();
		BeMemberProfile beMemberProfile = null;
		MemberProfile membProfile = null;
		try {
			if (!BaseUtil.isListNull(dtoList)) {
				for (MemberProfile memberProfile : dtoList) {
					MemberProfile memberProf = new MemberProfile();
					RefStatus status = refStatusSvc.findByStatusCodeStatusType("ENDT", "ENDT_STATUS");

					memberProf.setMemberId(memberProfile.getMemberId());
					memberProf = beMemberProfileSvc.search(memberProf);
					memberProf.setEndtStatusId(status.getStatusId());
					beMemberProfile = beMemberProfileSvc.updateEndorsement(memberProf);
				}

				membProfile = dozerMapper.map(beMemberProfile, MemberProfile.class);
				memberProfileList.add(membProfile);
			}
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
		return memberProfileList;

	}


	@PostMapping(value = BeUrlConstants.ACK_SLIP)
	public AckSlip searchAcknowledgementSlip(@RequestBody MemberProfile dto, HttpServletRequest request)
			throws IOException {

		AckSlip ackSlip = new AckSlip();
		// MEMBER_ID, TXN_ID, MEMBER_REF_NO, ID_NO
		MemberProfile memberProfile = beMemberProfileSvc.search(dto);

		if (BaseUtil.isObjNull(memberProfile)) {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}

		ackSlip.setFullName(memberProfile.getFullName());
		ackSlip.setIdNo(memberProfile.getIdNo());
		ackSlip.setOrgDivisionCd(memberProfile.getOrgDivisionCd());
		RefDivision refDivision = refDivisionSvc.findByDivisionCd(memberProfile.getOrgDivisionCd());
		if (!BaseUtil.isObjNull(refDivision)) {
			ackSlip.setOrgDivisionDesc(refDivision.getDivisionDesc());
		}

		ackSlip.setOrgBranchCd(memberProfile.getOrgBranchCd());
		RefBranch refBranch = refBranchSvc.findByBranchCd(memberProfile.getOrgBranchCd());
		if (!BaseUtil.isObjNull(refBranch)) {
			ackSlip.setOrgBranchDesc(refBranch.getBranchDesc());
		}

		if (!BaseUtil.isObjNull(memberProfile.getMemberAddressList())) {
			MemberAddress memberAddress = memberProfile.getMemberAddressList().get(0);
			ackSlip.setAddress1(memberAddress.getAddress1());
			ackSlip.setAddress2(memberAddress.getAddress2());
			ackSlip.setAddress3(memberAddress.getAddress3());
			ackSlip.setPostcode(memberAddress.getPostcode());
			ackSlip.setCityCd(memberAddress.getCityCd());
			ackSlip.setStateCd(memberAddress.getStateCd());
			ackSlip.setCountryCd(memberAddress.getCountryCd());
			// add total amount

		}

		PaymentDtl paymentDtl = bePaymentDtlSvc.searchDtl(String.valueOf(memberProfile.getPreRegId()));

		if (!BaseUtil.isObjNull(paymentDtl)) {
			ackSlip.setTotalAmount(paymentDtl.getItemAmount());
		}

		return ackSlip;
	}


	@PostMapping(value = BeUrlConstants.BLAST_MESSAGE)
	public Integer blastMessage(@RequestBody MemberBlastMessage dto, HttpServletRequest request) throws IOException {
		if (BaseUtil.isObjNull(dto)) {
			throw new BeException(BeErrorCodeEnum.E400C003);
		}

		if (BaseUtil.isObjNull(dto.getNotifyMessage())) {
			throw new BeException(BeErrorCodeEnum.E400C003);
		}

		int notifyTypeMail = !BaseUtil.isObjNull(dto.getNotifyTypeMail()) ? dto.getNotifyTypeMail() : 0;
		int notifyTypeSms = !BaseUtil.isObjNull(dto.getNotifyTypeSms()) ? dto.getNotifyTypeSms() : 0;
		int notifyTypeFcm = !BaseUtil.isObjNull(dto.getNotifyTypeFcm()) ? dto.getNotifyTypeFcm() : 0;

		Integer SMS_MAX_TEXT_LENGTH = 146;

		if (notifyTypeSms == 1) {
			BeConfig beConfig = beConfigSvc.findByConfigCode(ConfigConstants.SMS_MAX_TEXT_LENGTH);
			if (!BaseUtil.isObjNull(beConfig)) {
				SMS_MAX_TEXT_LENGTH = BaseUtil.getInt(beConfig.getConfigVal());
			}
		}

		MemberProfile profileDto = new MemberProfile();

		if (!BaseUtil.isObjNull(dto.getOrgStateCd())) {
			profileDto.setOrgStateCd(dto.getOrgStateCd());
		}

		if (!BaseUtil.isObjNull(dto.getBranchCd())) {
			profileDto.setOrgBranchCd(dto.getBranchCd());
		}

		if (!BaseUtil.isObjNull(dto.getOrgDivisionCd())) {
			profileDto.setOrgDivisionCd(dto.getOrgDivisionCd());
		}
		
		if(!BaseUtil.isObjNull(dto.getStateCd())) {
			profileDto.setSprStateCd(dto.getStateCd());
		}

		if (!BaseUtil.isObjNull(dto.getParliamentCode())) {
			profileDto.setParliamentCode(dto.getParliamentCode());
		}

		if (!BaseUtil.isObjNull(dto.getDunCode())) {
			profileDto.setDunCode(dto.getDunCode());
		}

		int sentCount = 0;
		List<BeMemberProfile> filtered = beMemberProfileSvc.searchList(profileDto);

		for (BeMemberProfile memberPro : filtered) {
			String notifyMessage = dto.getNotifyMessage();
			Map<String, Object> map = new HashMap<>();
			
			if (!BaseUtil.isObjNull(memberPro.getIdNo())) {
				LOGGER.info("Member Id No {}", memberPro.getIdNo());
			}

			// sms
			if (notifyTypeSms == 1 && !BaseUtil.isObjNull(memberPro.getContactNo())) {
				if (notifyMessage.length() > SMS_MAX_TEXT_LENGTH) {
					map.put("msg", notifyMessage.substring(0, SMS_MAX_TEXT_LENGTH));
				} else {
					map.put("msg", notifyMessage);
				}
				LOGGER.info("Member Sms {}", memberPro.getContactNo());
				
				Notification notification = new Notification();
				notification.setNotifyTo(memberPro.getContactNo());
				notification.setMetaData(MailUtil.convertMapToJson(map));
				notification.setNotifyType(MailTypeEnum.SMS.getType());
				notification.setContent(memberPro.getCreateId());
				getNotifyService(request).addNotification(notification,
						MailTemplateConstants.MEMBER_BLAST_MESSAGE_SMS);
				sentCount++;
			}

			// email
			if (notifyTypeMail == 1 && !BaseUtil.isObjNull(memberPro.getEmail())) {
				
				LOGGER.info("Member Email {}", memberPro.getEmail());
				
				map.put("msg", notifyMessage);
				Notification notification = new Notification();
				notification.setNotifyTo(memberPro.getEmail());
				notification.setMetaData(MailUtil.convertMapToJson(map));
				notification.setNotifyType(MailTypeEnum.MAIL.getType());
				notification.setContent(memberPro.getCreateId());

				getNotifyService(request).addNotification(notification,
						MailTemplateConstants.MEMBER_BLAST_MESSAGE_EMAIL);
				sentCount++;
			}

			// fcm
			if (notifyTypeFcm == 1) {
				
				LOGGER.info("Member fcm {}", memberPro.getContactNo());
				map.put("msg", notifyMessage);
				sendFcmNotification(memberPro.getIdNo(), memberPro.getCreateId(), map,
						MailTemplateConstants.MEMBER_BLAST_MESSAGE_FCM, request);
				sentCount++;
			}

		}

		return sentCount;
	}
	
	@GetMapping(value = BeUrlConstants.CHECK_VALID_MIGRATION_IDNO, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Integer checkValidityMigrationIdNo(@RequestParam(value = "idNo", required = true) String idNo) {
		if (!BaseUtil.isObjNull(idNo)) {
		
			MemberProfile memberProf = new MemberProfile();
			memberProf.setIdNo(idNo);
			int memberProfCountImgrasi = (int) beMemberProfileDao.totalMemberProfByIdNo(idNo);
			if (memberProfCountImgrasi == 1) {
				return 0;
			} 
			
			Watchlist watchlist = new Watchlist();
			watchlist.setIdNo(idNo);
			watchlist.setStatus(true);
			int watchlistCount = (int) beWatchlistSvc.getCount(watchlist);
			if (watchlistCount != 0) {
				return 2;
			}
		} else {
			return 1;
		}
		return 0;
	}
	
	@PostMapping(value = BeUrlConstants.UPDATE_PROFILE_PHOTO, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MemberProfile updateProfilePhoto(@RequestBody MemberProfile dto, HttpServletRequest request) {

		BeMemberProfile beMemberProfile = beMemberProfileSvc.find(dto.getMemberId());
		if (BaseUtil.isObjNull(beMemberProfile)) {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}

		String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();

		List<BeTrxnDocument> beTrxnDocumentsList = null;
		List<BeTrxnDocument> beTrxnDocumentDelList = null;
		if (!BaseUtil.isListNull(dto.getTrxnDocumentList())) {
			beTrxnDocumentsList = new ArrayList<>();
			beTrxnDocumentDelList = new ArrayList<>();
			String docRefNo = beMemberProfile.getDocRefNo();
			if (BaseUtil.isObjNull(docRefNo)) {
				docRefNo = UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC);
				beMemberProfile.setDocRefNo(docRefNo);
			}
			for (TrxnDocuments doc : dto.getTrxnDocumentList()) {
				BeTrxnDocument trxnDoc = null;
				List<BeTrxnDocument> trxnDocList = null;
				if (!BaseUtil.isObjNull(doc.getDocRefNo()) && !BaseUtil.isObjNull(doc.getDocId())) {
					trxnDocList = beTrxnDocumentsSvc.getTrxnDocumentsByRefNoAndDocId(doc.getDocRefNo(),
							doc.getDocId());
				}

				if (BaseUtil.isListNull(trxnDocList)) {
					BeTrxnDocumentPK docPk = new BeTrxnDocumentPK();
					docPk.setDocRefNo(docRefNo);
					docPk.setDocId(doc.getDocId());
					trxnDoc = new BeTrxnDocument(docPk, beMemberProfile.getMemberRefNo(), doc.getDocContentType());
					trxnDoc.setCreateId(userId);
					trxnDoc.setCreateDt(currDt);
				} else {
					trxnDoc = trxnDocList.get(0);
					BeTrxnDocument delDoc = dozerMapper.map(trxnDoc, BeTrxnDocument.class);
					beTrxnDocumentDelList.add(delDoc);
				}

				trxnDoc.getId().setDocMgtId(doc.getDocMgtId());
				trxnDoc.setDocContentType(doc.getDocContentType());
				trxnDoc.setUpdateId(userId);
				trxnDoc.setUpdateDt(currDt);
				beTrxnDocumentsList.add(trxnDoc);
			}
		}

		beMemberProfile.setUpdateId(userId);
		beMemberProfile.setUpdateDt(currDt);
		beMemberProfile = beMemberProfileSvc.update(beMemberProfile, beTrxnDocumentsList, beTrxnDocumentDelList);
		return dozerMapper.map(beMemberProfile, MemberProfile.class);
	}

}
