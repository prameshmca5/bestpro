package com.bestpay.be.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.bestpay.be.core.AbstractEntity;

@Entity
@Table(name = "REF_DOCUMENTS")
public class RefDocument extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -8113415903134966574L;

	@Id
	@Column(name = "DOC_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String docId;

	@Column(name = "TRXN_NO")
	private String trxnNo;

	@Column(name = "TITLE")
	private String title;

	@Column(name = "TYPE")
	private String type;

	@Column(name = "SIZE")
	private int size;

	@Column(name = "IS_COMPULSARY")
	@Type(type = "yes_no")
	private boolean compulsary;

	@Column(name = "IS_DIMENSION_COMPULSARY")
	private String dimensionCompulsary;

	@Column(name = "MIN_WIDTH")
	private int minWidth;

	@Column(name = "MAX_WIDTH")
	private int maxWith;

	@Column(name = "MIN_HEIGHT")
	private int minHeight;

	@Column(name = "MAX_HEIGHT")
	private int maxHeight;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "DOC_DESC_EN")
	private String docDescEn;

	@Column(name = "DOC_DESC_MY")
	private String docDescMy;

	@Column(name = "SORT_ORDER")
	private int sortOrder;

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getTrxnNo() {
		return toUpper(trxnNo);
	}

	public void setTrxnNo(String trxnNo) {
		this.trxnNo = toUpper(trxnNo);
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = toUpper(title);
	}

	public String getType() {
		return toUpper(type);
	}

	public void setType(String type) {
		this.type = toUpper(type);
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public boolean isCompulsary() {
		return compulsary;
	}

	public void setCompulsary(boolean compulsary) {
		this.compulsary = compulsary;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getDocDescEn() {
		return docDescEn;
	}

	public void setDocDescEn(String docDescEn) {
		this.docDescEn = docDescEn;
	}

	public String getDocDescMy() {
		return docDescMy;
	}

	public void setDocDescMy(String docDescMy) {
		this.docDescMy = docDescMy;
	}

	public int getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getDimensionCompulsary() {
		return dimensionCompulsary;
	}

	public void setDimensionCompulsary(String dimensionCompulsary) {
		this.dimensionCompulsary = dimensionCompulsary;
	}

	public int getMinWidth() {
		return minWidth;
	}

	public void setMinWidth(int minWidth) {
		this.minWidth = minWidth;
	}

	public int getMaxWith() {
		return maxWith;
	}

	public void setMaxWith(int maxWith) {
		this.maxWith = maxWith;
	}

	public int getMinHeight() {
		return minHeight;
	}

	public void setMinHeight(int minHeight) {
		this.minHeight = minHeight;
	}

	public int getMaxHeight() {
		return maxHeight;
	}

	public void setMaxHeight(int maxHeight) {
		this.maxHeight = maxHeight;
	}

}
