/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwMerchantSubscription;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerSubscriptionPlan;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;

/**
 * @author Atiqah Khairuddin
 * @since Sept 14, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.MER_SUBSCRIPTION_PLAN)
public class SubscriptionPlanRestController extends AbstractRestController {

	@GetMapping(value = "/{merchantId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerSubscriptionPlan getMerSubPlanById(@PathVariable String merchantId) {

		PgwMerchantSubscription merSub = super.pgwMerchantSubscriptionService
				.findSubscriptionPlanByMerchantId(merchantId);

		MerSubscriptionPlan merSubPlan = new MerSubscriptionPlan();
		if (!BaseUtil.isObjNull(merSub)) {
			merSubPlan = dozerMapper.map(merSub, MerSubscriptionPlan.class);
		}
		return merSubPlan;
	}

	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerSubscriptionPlan createMerSubPlan(@Valid @RequestBody MerSubscriptionPlan merSubscriptionPlan,
			HttpServletRequest request, HttpServletResponse response) throws BeException {

		if (merSubscriptionPlan == null) {// restriction null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		if (StringUtils.isBlank(merSubscriptionPlan.getMerchantId())) {// no
			// merchant
			// name
			throw new BeException(BeErrorCodeEnum.I400IDM137, new String[] { "Merchant Name", "Merchant Profile" });
		}

		PgwMerchantSubscription newSubPlan = new PgwMerchantSubscription();
		newSubPlan.setMerchantId(merSubscriptionPlan.getMerchantId());
		newSubPlan.setSubPlanId(merSubscriptionPlan.getSubPlanId());
		newSubPlan.setExpiryDate(merSubscriptionPlan.getExpiryDate());
		newSubPlan.setStatus("A");
		newSubPlan.setCreateId(merSubscriptionPlan.getUserId());
		newSubPlan.setUpdateId(merSubscriptionPlan.getUserId());

		PgwMerchantSubscription merchantSubscriptionPlan = super.pgwMerchantSubscriptionService
				.findSubscriptionPlanByMerchantId(merSubscriptionPlan.getMerchantId());

		if (!BaseUtil.isObjNull(merchantSubscriptionPlan)) {
			merchantSubscriptionPlan.setStatus("I");
			super.pgwMerchantSubscriptionService.update(merchantSubscriptionPlan);
			super.pgwMerchantSubscriptionService.create(newSubPlan);
		} else {
			super.pgwMerchantSubscriptionService.create(newSubPlan);
		}

		MerSubscriptionPlan subPlan = new MerSubscriptionPlan();
		PgwMerchantSubscription updateMerSubPlan = super.pgwMerchantSubscriptionService
				.findSubscriptionPlanByMerchantId(merSubscriptionPlan.getMerchantId());
		if (!BaseUtil.isObjNull(updateMerSubPlan)) {
			subPlan = dozerMapper.map(updateMerSubPlan, MerSubscriptionPlan.class);
		}
		return subPlan;
	}

}
