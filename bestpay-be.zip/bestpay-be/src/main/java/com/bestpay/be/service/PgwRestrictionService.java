/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwRestrictionRepository;
import com.bestpay.be.model.PgwRestriction;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since June 25, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_RESTRICTION_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_RESTRICTION_SVC)
public class PgwRestrictionService extends AbstractService<PgwRestriction> {

	@Autowired
	private PgwRestrictionRepository restrictionDao;


	@Override
	public PgwRestrictionRepository primaryDao() {
		return restrictionDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwRestriction findRestrictionByMerchantId(String merchantId) {
		return restrictionDao.findRestrictionByMerchantId(merchantId);
	}
}