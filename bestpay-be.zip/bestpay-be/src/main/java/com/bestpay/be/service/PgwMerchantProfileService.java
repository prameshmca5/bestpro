/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.MerchantProfileCustomDao;
import com.bestpay.be.dao.PgwMerchantProfileRepository;
import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since June 25, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_MER_PROFILE)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MER_PROFILE)
public class PgwMerchantProfileService extends AbstractService<PgwMerchantProfile> {

	@Autowired
	private PgwMerchantProfileRepository merchantProfileDao;

	@Autowired
	private MerchantProfileCustomDao merchantProfileInfoDao;


	@Override
	public PgwMerchantProfileRepository primaryDao() {
		return merchantProfileDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwMerchantProfile> searchMerchantProfile(MerAccInfo merAccInfo,
			DataTableRequest dataTableInRQ) {
		return merchantProfileInfoDao.searchByPagination(merAccInfo, dataTableInRQ);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantProfile findMerProfileByMerchantId(String merchantId) {
		return merchantProfileDao.findMerProfileByMerchantId(merchantId);
	}


	// @Cacheable(key =
	// "T(com.bestinet.commons.sdk.constants.CmnCacheConstants).CACHE_KEY_CMPNY_ACTVTY_ID.concat(#activityId)",
	// condition = "#activityId != null and #result != null")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public PgwMerchantProfile findByMerchantProfileId(Integer merProfId) {
		return merchantProfileDao.findByMerchantProfileId(merProfId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwMerchantProfile> findAllMerchantList() {
		return merchantProfileDao.findAllMerchantProfileList();
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwMerchantProfile> findExpiredMerchantList() {
		return merchantProfileDao.findExpiredMerchantList();
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<String> getCountByStatus() {
		return merchantProfileDao.getCountByStatus();
	}


	public List<PgwMerchantProfile> findByOwnerNationalId(String ownerDirectorNationalId) {
		return merchantProfileDao.findByOwnerNationalId(ownerDirectorNationalId);
	}

}