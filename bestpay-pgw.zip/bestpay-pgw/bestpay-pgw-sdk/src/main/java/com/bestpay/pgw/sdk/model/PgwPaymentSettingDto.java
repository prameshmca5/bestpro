package com.bestpay.pgw.sdk.model;

import java.sql.Timestamp;
 
 
public class PgwPaymentSettingDto {

	
	 
	private Integer id;
	private String merchantId;
	private String sellerId;
	private String retUrl;
	private String retUrlPin;
	private String callUrl;
	private String callUrlPin;
	private String verifykey;
	private Integer enableVerify;
	private String emailNot;
	private String receipt;
	private Integer modifyOid;
	private Integer modifyAmt;
	private String modifyDesc;
	private String emailLock;
	private String nameLock;
	private String phoneLock;
	private String createId;
	private Timestamp createDt;
	private Timestamp updateDt;
	private String updateId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getRetUrl() {
		return retUrl;
	}

	public void setRetUrl(String retUrl) {
		this.retUrl = retUrl;
	}

	public String getRetUrlPin() {
		return retUrlPin;
	}

	public void setRetUrlPin(String retUrlPin) {
		this.retUrlPin = retUrlPin;
	}

	public String getCallUrl() {
		return callUrl;
	}

	public void setCallUrl(String callUrl) {
		this.callUrl = callUrl;
	}

	public String getCallUrlPin() {
		return callUrlPin;
	}

	public void setCallUrlPin(String callUrlPin) {
		this.callUrlPin = callUrlPin;
	}

	public String getVerifykey() {
		return verifykey;
	}

	public void setVerifykey(String verifykey) {
		this.verifykey = verifykey;
	}

	public Integer getEnableVerify() {
		return enableVerify;
	}

	public void setEnableVerify(Integer enableVerify) {
		this.enableVerify = enableVerify;
	}

	public String getEmailNot() {
		return emailNot;
	}

	public void setEmailNot(String emailNot) {
		this.emailNot = emailNot;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public Integer getModifyOid() {
		return modifyOid;
	}

	public void setModifyOid(Integer modifyOid) {
		this.modifyOid = modifyOid;
	}

	public Integer getModifyAmt() {
		return modifyAmt;
	}

	public void setModifyAmt(Integer modifyAmt) {
		this.modifyAmt = modifyAmt;
	}

	public String getModifyDesc() {
		return modifyDesc;
	}

	public void setModifyDesc(String modifyDesc) {
		this.modifyDesc = modifyDesc;
	}

	public String getEmailLock() {
		return emailLock;
	}

	public void setEmailLock(String emailLock) {
		this.emailLock = emailLock;
	}

	public String getNameLock() {
		return nameLock;
	}

	public void setNameLock(String nameLock) {
		this.nameLock = nameLock;
	}

	public String getPhoneLock() {
		return phoneLock;
	}

	public void setPhoneLock(String phoneLock) {
		this.phoneLock = phoneLock;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	
	
}


