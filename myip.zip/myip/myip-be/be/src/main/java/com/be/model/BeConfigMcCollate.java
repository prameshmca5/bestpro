/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.be.core.AbstractEntity;
import com.be.sdk.model.ConfigMcCollate;
import com.be.sdk.model.IQfCriteria;


/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_CONFIG_MC_COLLATE")
public class BeConfigMcCollate extends AbstractEntity implements Serializable, IQfCriteria<ConfigMcCollate> {

	private static final long serialVersionUID = -3715925704898888877L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "MC_COLLATE_ID")
	private Integer mcCollateId;

	@Column(name = "MC_COLLATE_CD")
	private String mcCollateCd;

	@Column(name = "MC_COLLATE_DESC")
	private String mcCollateDesc;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "STATUS")
	private Boolean isActive;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;


	public Integer getMcCollateId() {
		return mcCollateId;
	}


	public void setMcCollateId(Integer mcCollateId) {
		this.mcCollateId = mcCollateId;
	}


	public String getMcCollateCd() {
		return mcCollateCd;
	}


	public void setMcCollateCd(String mcCollateCd) {
		this.mcCollateCd = mcCollateCd;
	}


	public String getMcCollateDesc() {
		return mcCollateDesc;
	}


	public void setMcCollateDesc(String mcCollateDesc) {
		this.mcCollateDesc = mcCollateDesc;
	}


	public Boolean getIsActive() {
		return isActive;
	}


	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
