/**
 * Copyright 2020. Bestinet Sdn Bhd
 */
package com.portal.web.mc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.be.sdk.model.ConfigMcCollate;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlTestResult;
import com.portal.constants.PageConstants;
import com.portal.constants.PageTemplate;
import com.portal.core.AbstractController;
import com.portal.web.mc.form.MedicalResultForm;
import com.util.BaseUtil;

/**
 * @author muhammad.hafidz
 * @since 12/7/2020
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_MC_MEDICAL_RESULT)
public class MedicalResultController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MedicalResultController.class);
	
	private static final String MODULE = "mcMedResult";
	
	private static final String JS_FILENAME = "mcMedResult";
	
	@GetMapping()
	public ModelAndView showMedicalResultForm (@RequestParam (value = "id", required=false)  Integer id, 
			@RequestParam (value = "action", required=false)  String action,
			@ModelAttribute("medResultForm") MedicalResultForm medResultForm, BindingResult result) {

		if (id != null) {
			// initialise tvl if id is not null
			Tvl tvl = new Tvl();
			tvl.setTvlProfId(id); 
			tvl.setEmbedMedical(true);
			tvl = getBeService().medicalService().getTravelDetail(tvl);
			medResultForm.setTvl(tvl);
			medResultForm.setTvlProfId(id);
		}
		
		// get List from BE_CONFIG_MC_COLLATE
		List<ConfigMcCollate> configMcCollateLst = getBeService().reference().findCollateByCriteria(new ConfigMcCollate());
		
		// initialised model view
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_MEDICAL_RESULT, null, null, null, JS_FILENAME);
		mav.addObject("configMcCollateLst", configMcCollateLst);
		mav.addObject("medResultForm", medResultForm);
		mav.addObject("tvlProfId", id);
		return mav;
	}
	
	@PostMapping () 
	public ModelAndView updateAndApprove (@RequestParam (value = "id", required=false)  Integer id,
			@RequestParam (value = "action", required=false)  String action,
			@ModelAttribute("medResultForm") MedicalResultForm medResultForm, BindingResult result,
			HttpServletRequest request,HttpSession session) {
		
		if (BaseUtil.isEquals(action, "update")) {
			// initialise tvltestresult
			TvlTestResult ttr = new TvlTestResult();
			
			ttr.setTvlProfId(medResultForm.getTvl().getTvlProfile().getTvlProfId());
			ttr.setMcProfId(1); // hardcode for now
			ttr.setCntryCd("MYS");
			ttr.setStatusId(106);
			ttr.setDocRefNo("DOC123");
			ttr.setMedicalResult(medResultForm.getTvl().getTvlProfile().getTvlTestResult().getMedicalResult());
			ttr.setRemarks(medResultForm.getTvl().getTvlProfile().getTvlTestResult().getRemarks());
			
	        getBeService().medicalService().updateApprovedMedicalInfo(ttr);
		} else if (BaseUtil.isEquals(action, "approve")) {
			// initialise tvltestresult
			TvlTestResult ttr = new TvlTestResult();
			ttr.setStatusId(107); // approve
			// ttr.setStatusId(108); // reject
			ttr.setRemarks(medResultForm.getTvl().getTvlProfile().getTvlTestResult().getRemarks());
	        getBeService().medicalService().updateApprovedMedicalInfo(ttr);
			
		}
        		
        return showMedicalResultForm(medResultForm.getTvl().getTvlProfile().getTvlProfId(), null, medResultForm, result);
	}
	
	
	@GetMapping(value = PageConstants.PAGE_SEARCH ) 
	public ModelAndView searchForm (@ModelAttribute("medResultForm") MedicalResultForm medResultForm, BindingResult result,
			HttpServletRequest request,HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_MEDICAL_RESULT_SEARCH, null, null, null, JS_FILENAME);
		mav.addObject("medResultSearchForm", medResultForm);
		return mav;	}
	
}
