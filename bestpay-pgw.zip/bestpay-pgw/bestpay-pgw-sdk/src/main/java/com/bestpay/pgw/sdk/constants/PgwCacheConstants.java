/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class PgwCacheConstants {

	private PgwCacheConstants() {
		throw new IllegalStateException("Utility class");
	}


	// CACHE BUCKET
	public static final String CACHE_PREFIX = "BE_SVC";

	public static final String CACHE_BUCKET = CACHE_PREFIX + "_BUCKET";

	// CACHE DURATION in seconds
	public static final int CACHE_DURATION_MINUTE = 900;

	public static final int CACHE_DURATION_HOURLY = 3600;

	public static final int CACHE_DURATION_DAILY = 86400;

	// CACHE KEY
	public static final String CACHE_STATIC_SVC = CACHE_PREFIX + "_REF_";

	public static final String CACHE_STATIC_EQM = CACHE_PREFIX + "_REF_";

	public static final String CACHE_STATIC_EQM_SUB_SEC = CACHE_PREFIX + "_REF_SUB_SECTOR_";

	public static final String CACHE_KEY_CITY_ALL = "CMN_REF_CITY_ALL";

	public static final String CACHE_KEY_CITY = "CMN_REF_CITY_";

	public static final String CACHE_KEY_NATIONALITY_ALL = "CMN_REF_NATIONALITY_ALL";

	public static final String CACHE_KEY_NATIONALITY = "CMN_REF_NATIONALITY_";

	public static final String CACHE_KEY_CITY_STATE = "CMN_REF_CITY_STATE_";

	public static final String CACHE_KEY_STATE = "CMN_REF_STATE_";

	public static final String CACHE_KEY_STATE_ALL = "CMN_REF_STATE_ALL";

	public static final String CACHE_KEY_STATE_BLK = "CMN_REF_STATE_BLK";

	public static final String CACHE_KEY_STATE_PLCTKI = "CMN_REF_STATE_PLCTKI";

	public static final String CACHE_KEY_STATUS_ALL = "CACHE_KEY_STATUS_ALL";

	public static final String REF_TYP_CITY = "cities";

	public static final String REF_TYP_STATUS = "status";

	public static final String CACHE_KEY_RELATIONSHIP_ALL = "CMN_REF_RELATIONSHIP_ALL";

	public static final String CACHE_KEY_RELATIONSHIP = "CMN_REF_RELATIONSHIP_";

	public static final String REF_TYP_COUNTRY = "countries";

	public static final String REF_TYP_RELATION = "relations";

	public static final String REF_TYP_STATE = "states";

	public static final String REF_TYP_FPX_RES_CODE = "fpxResponseCode";
	
	public static final String REF_TYP_FPX_RES_DESC = "fpxResponseDesc";

}