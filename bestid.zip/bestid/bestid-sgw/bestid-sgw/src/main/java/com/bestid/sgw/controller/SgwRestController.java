/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.sgw.controller;


import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestid.be.sdk.model.KioskCounter;
import com.bestid.be.sdk.model.MessageResponse;
import com.bestid.be.sdk.model.MobileUser;
import com.bestid.be.sdk.model.QrDigitalId;
import com.bestid.be.sdk.model.TransSign;
import com.bestid.be.sdk.model.UsrProfile;
import com.bestid.sgw.constants.SgwTxnCodeConstants;
import com.bestid.sgw.sdk.client.constants.SgwUriConstants;
import com.bstsb.util.MediaType;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
@RestController
public class SgwRestController extends AbstractRestController {

	/**
	 * QR Code specifically for Mobile & Thick Users
	 *
	 * @param machineId
	 * @return QrDigitalId
	 * @throws Exception
	 */
	@PostMapping(value = SgwUriConstants.GENERATE_QR_CODE_DIGITALID, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MessageResponse generateQrCode(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_GENERATE_QR_CODE) String trxnNo,
			@Valid @RequestBody QrDigitalId qrDto, HttpServletRequest request) {
		return getBeService(request).apiService().generateQrCodeDigitalIdInfo(qrDto);
	}


	@PostMapping(value = SgwUriConstants.MOBILE_REGISTRATION_CERT, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MessageResponse registerCert(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SEC_REGISTER_CERT) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody TransSign transSign) {
		return getBeService(request).mobileService().registerCert(transSign);
	}


	@PostMapping(value = SgwUriConstants.MOBILE_STORE_CERT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse storeCert(@RequestParam(defaultValue = SgwTxnCodeConstants.SEC_STORE_CERT) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody TransSign transSign) {
		return getBeService(request).mobileService().storeCert(transSign);
	}


	@PostMapping(value = SgwUriConstants.MOBILE_SUBMIT_CERT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse submitCert(@RequestParam(defaultValue = SgwTxnCodeConstants.SEC_SUBMIT_CERT) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody TransSign transSign) {
		return getBeService(request).mobileService().submitCert(transSign);
	}


	@PostMapping(value = SgwUriConstants.MOBILE_REVOKE_CERT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse revokeCert(@RequestParam(defaultValue = SgwTxnCodeConstants.SEC_STORE_CERT) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody TransSign transSign) {
		return getBeService(request).mobileService().revokeCert(transSign);
	}


	@PostMapping(value = SgwUriConstants.MOBILE_LOGIN, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse login(@RequestParam(defaultValue = SgwTxnCodeConstants.MOBILE_LOGIN) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {
		return getBeService(request).mobileService().login(mobileUser);
	}


	@PostMapping(value = SgwUriConstants.MOBILE_LOGOUT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse logout(@RequestParam(defaultValue = SgwTxnCodeConstants.MOBILE_LOGOUT) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {
		return getBeService(request).mobileService().logout(mobileUser);
	}


	/**
	 * Search device
	 */
	@PostMapping(value = SgwUriConstants.SEARCH_DEVICE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse searchDevice(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_SEARCH_DEVICE) String trxnNo,
			@Valid @RequestBody KioskCounter kioskCounter, HttpServletRequest request) {
		return getBeService(request).apiService().searchDevice(kioskCounter);
	}


	/**
	 * Search user
	 */
	@PostMapping(value = SgwUriConstants.SEARCH_USER, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse searchUser(@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_SEARCH_USER) String trxnNo,
			@Valid @RequestBody KioskCounter kioskCounter, HttpServletRequest request) {
		return getBeService(request).apiService().searchUser(kioskCounter);
	}


	/**
	 * Register user
	 */
	@PostMapping(value = SgwUriConstants.REGISTER_USER, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse registerUser(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_REGISTER_USER) String trxnNo,
			@Valid @RequestBody KioskCounter kioskCounter, HttpServletRequest request) {
		return getBeService(request).apiService().registerUser(kioskCounter);
	}


	/**
	 * Update contact
	 */
	@PostMapping(value = SgwUriConstants.UPDATE_CONTACT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse updateContact(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_UPDATE_CONTACT) String trxnNo,
			@Valid @RequestBody KioskCounter kioskCounter, HttpServletRequest request) {
		return getBeService(request).apiService().updateContact(kioskCounter);
	}


	/**
	 * Generate activation code
	 */
	@PostMapping(value = SgwUriConstants.GEN_ACTIVATION_CODE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse genActCode(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_GEN_ACTIVATION_CODE) String trxnNo,
			@Valid @RequestBody KioskCounter kioskCounter, HttpServletRequest request) {
		return getBeService(request).apiService().genActCode(kioskCounter);
	}


	/**
	 * Verify activation code
	 */
	@PostMapping(value = SgwUriConstants.VERIFY_ACTIVATION_CODE, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MessageResponse verifyActCode(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_VERIFY_ACTIVATION_CODE) String trxnNo,
			@Valid @RequestBody KioskCounter kioskCounter, HttpServletRequest request) {
		return getBeService(request).apiService().verifyActCode(kioskCounter);
	}


	@PostMapping(value = SgwUriConstants.VERIFY_QR_CODE_DIGITALID, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MessageResponse verifyQrCode(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_VERIFY_QR_CODE) String trxnNo,
			@Valid @RequestBody QrDigitalId qrDto, HttpServletRequest request) {
		return getBeService(request).apiService().verifyQrCode(qrDto);
	}


	@PostMapping(value = SgwUriConstants.VERIFY_PHOTO, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse verifyPhoto(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_VERIFY_PHOTO) String trxnNo,
			@Valid @RequestBody KioskCounter counter, HttpServletRequest request) {
		return getBeService(request).apiService().verifyPhoto(counter);
	}


	@PostMapping(value = SgwUriConstants.MOBILE_SEARCH_FACE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse searchFace(@RequestParam(defaultValue = SgwTxnCodeConstants.SEC_FACE_SEARCH) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {
		return getBeService(request).mobileService().searchFace(mobileUser);
	}


	@PostMapping(value = SgwUriConstants.MOBILE_PINCODE_VERIFY, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse verifyPinCode(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SEC_PINCODE_VERIFY) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {
		return getBeService(request).mobileService().verifyPinCode(mobileUser);
	}


	@PostMapping(value = SgwUriConstants.MOBILE_PINCODE_UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse updatePinCode(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SEC_PINCODE_UPDATE) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {
		return getBeService(request).mobileService().updatePinCode(mobileUser);
	}


	@PostMapping(value = SgwUriConstants.MOBILE_GEN_INVITATION_CODE, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MessageResponse genInvCd(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SEC_INVITATION_CODE_GENERATE) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {
		return getBeService(request).mobileService().genInvCd(mobileUser);
	}


	@PostMapping(value = SgwUriConstants.MOBILE_VERIFY_INVITATION_CODE, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MessageResponse verifyInvCd(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SEC_INVITATION_CODE_VERIFY) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {
		return getBeService(request).mobileService().verifyInvCd(mobileUser);
	}


	@PostMapping(value = SgwUriConstants.MOBILE_SEARCH_PROFILE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse searchProfile(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SEC_PROFILE_SEARCH) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody UsrProfile profile) {
		return getBeService(request).mobileService().searchProfile(profile);
	}
	

	@PostMapping(value = SgwUriConstants.MOBILE_VERIFY_DIGITALID, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse verifyDigitalid(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_VERIFY_DIGITALID) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {
		return getBeService(request).mobileService().verifyDigitalid(mobileUser);
	}
	
	@PostMapping(value = SgwUriConstants.MOBILE_VERIFY_AUTH, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse verifyAuth(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_VERIFY_AUTH) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {
		return getBeService(request).mobileService().verifyAuth(mobileUser);
	}
	
	@PostMapping(value = SgwUriConstants.MOBILE_REGISTER_PROFILE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse registerProfile(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_REGISTER_PROFILE) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody MobileUser mobileUser) {
		return getBeService(request).mobileService().registerProfile(mobileUser);
	}
	
	@PostMapping(value = SgwUriConstants.DIGITALID_STATUS_CHECK, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MessageResponse digitalIdStatusCheck(
			@RequestParam(defaultValue = SgwTxnCodeConstants.SGW_DIGITALID_STATUS_CHECK) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody KioskCounter kioskCounter) {
		return getBeService(request).apiService().digitalIdStatusCheck(kioskCounter);
	}

}