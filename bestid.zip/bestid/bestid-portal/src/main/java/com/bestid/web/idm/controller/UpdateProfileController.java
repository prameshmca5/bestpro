package com.bestid.web.idm.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bestid.core.AbstractController;
import com.bestid.web.idm.form.UpdateProfileForm;
import com.bestid.web.util.constants.AppConstants;
import com.bestid.web.util.constants.MessageConstants;
import com.bestid.web.util.constants.PageConstants;
import com.bestid.web.util.constants.PageTemplate;
import com.bstsb.idm.sdk.exception.IdmException;
import com.bstsb.idm.sdk.model.UserProfile;
import com.bstsb.util.PopupBox;


@Controller
@RequestMapping(value = PageConstants.PAGE_UPDATE_PROFILE)
public class UpdateProfileController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateProfileController.class);

	@Autowired

	@Qualifier("UpdateProfileValidator")
	private Validator validator;


	@Override
	protected void bindingPreparation(WebDataBinder binder) {
		binder.setValidator(validator);
		binder.setBindEmptyMultipartFiles(false);
		super.bindingPreparation(binder);
	}


	@GetMapping()
	public ModelAndView view(@ModelAttribute("updateProfileForm") UpdateProfileForm updateProfile,
			BindingResult result) {

		String profileType = "upd_profile";

		ModelAndView mav = new ModelAndView(PageTemplate.IDM_UPDATE_PROFILE);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.usr.prof.upd "));
		try {
			UserProfile userProfileObj = getIdmService().getUserProfileById(getCurrentUserId(), false, false);
			updateProfile.setFullName(userProfileObj.getFullName());
			updateProfile.setEmail(userProfileObj.getUserId());
			updateProfile.setNationality(userProfileObj.getNationalId());
			updateProfile.setGender(userProfileObj.getGender());
			updateProfile.setContactNo(userProfileObj.getMobPhoneNo());

		} catch (Exception e) {
			LOGGER.error(e.getMessage());

		}

		mav.addObject(AppConstants.PORTAL_MODULE, profileType);
		mav.addObject("updateProfile", updateProfile);
		return mav;
	}


	@PostMapping
	public ModelAndView updateProfile(@Validated @ModelAttribute("updateProfileForm") UpdateProfileForm updateProfile,
			BindingResult result, Errors errors) {

		ModelAndView mav = new ModelAndView(PageTemplate.IDM_UPDATE_PROFILE);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.usr.prof.upd "));
		String profileType = "upd_profile";
		if (!result.hasErrors()) {

			try {
				UserProfile up = new UserProfile();
				up.setFullName(updateProfile.getFullName());
				up.setEmail(updateProfile.getEmail());
				up.setUserId(updateProfile.getEmail());
				up.setNationalId(updateProfile.getNationality());
				up.setGender(updateProfile.getGender());
				up.setMobPhoneNo(updateProfile.getContactNo());
				getIdmService().updateProfile(up);
			} catch (IdmException e) {

				LOGGER.error("Exception: {}", e.getMessage());
				mav.addObject("errorMsg", e.getMessage());
			}

			mav.addAllObjects(PopupBox.success(null, null,
					messageService.getMessage(MessageConstants.SUCC_UPD_JS_CONTACT), null));
		}
		mav.addObject("updateProfile", updateProfile);
		mav.addObject(AppConstants.PORTAL_MODULE, profileType);
		return mav;

	}
}
