/**
 * Copyright 2020. Bestinet Sdn Bhd
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeConfigRiskStatus;
import com.be.model.RefMetadata;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.ConfigRiskStatus;
import com.be.sdk.model.IQfCriteria;
import com.be.service.RefMetadataService;
import com.util.BaseUtil;
import com.util.JsonUtil;


/**
 * @author nurul.naimma
 *
 * @since Aug 21, 2020
 */

@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_CONFIG_RISK_STATUS_QF)
public class BeConfigRiskStatusQf extends QueryFactory<BeConfigRiskStatus> {

	@Autowired
	RefMetadataService refMetadataSvc;

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BeConfigRiskStatus> searchByProperty(BeConfigRiskStatus t) {
		return (Root<BeConfigRiskStatus> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}


	@Override
	public List<BeConfigRiskStatus> searchAllByProperty(BeConfigRiskStatus t) {
		CriteriaQuery<BeConfigRiskStatus> cq = cb.createQuery(BeConfigRiskStatus.class);
		Root<BeConfigRiskStatus> from = cq.from(BeConfigRiskStatus.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public BeConfigRiskStatus searchBeConfigRiskStatus(ConfigRiskStatus dto) {

		BeConfigRiskStatus result = null;
		CriteriaQuery<BeConfigRiskStatus> cq = cb.createQuery(BeConfigRiskStatus.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeConfigRiskStatus> root = cq.from(BeConfigRiskStatus.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeConfigRiskStatus> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			ConfigRiskStatus dto = JsonUtil.transferToObject(criteria, ConfigRiskStatus.class);
			if (!BaseUtil.isObjNull(dto.getId())) {
				predicates.add(cb.equal(from.get("id"), dto.getId()));
			}

		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void joinFetch(From<?, ?> from, List<Predicate> predicates, ConfigRiskStatus dto,
			CriteriaQuery<BeConfigRiskStatus> cq) {

		Join<BeConfigRiskStatus, RefMetadata> riskStatusMtdt = (Join) from.fetch("riskStatusMtdt", JoinType.LEFT);
		predicates.addAll(refMetadataSvc.generateCriteria(cb, riskStatusMtdt, dto));

	}

}
