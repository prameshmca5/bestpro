/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.util.model.FileUpload;


/**
 * @author michelle.angela
 *
 */
public class DoctorProfile implements Serializable, IQfCriteria<DoctorProfile> {

	private static final long serialVersionUID = 5586321345376966177L;

	private Integer docProfId;

	private McProfile beMcProfile;

	private String doctorId;

	private String fullName;

	private String identityNo;

	private String medCertNo;

	private String gender;

	private String designation;

	private String department;

	private String division;

	private String email;

	private String contactNo;

	private String faxNo;

	private String ext;

	private String docRefNo;

	private Boolean isActive;

	private String nationalId;

	private String userId;

	private String password;

	private String role;

	private String firstName;

	private String lastName;

	private String status;

	private Date dob;

	private String cntry;

	private String userGroupRoleBranchCd;

	private String userTypeCode;

	private String userGroupCode;

	private String userRoleGroupCode;

	private String userRoleGroupDesc;

	private String parentRoleGroup;

	private String createId;

	private String branchCode;

	private Timestamp createDt;

	private String updateId;

	private Timestamp updateDt;

	private List<String> selectedRoles;

	private boolean isFWCMSLogin;

	private String isFwcms;

	private List<String> cmpanyRegNoList;

	private String transactionType; // user create =C, update= U, profile
								// update = UP

	private List<FileUpload> fileUploads;

	private String docMgtId;

	private String myKadId;

	private String searchId;

	private String isMyimms;

	private String position;

	private String refNo;

	private String recordCardNo;

	private String staffId;

	private String stateCd;

	private Integer branchId;

	private String action;
	
	private List<FileUpload> fileUploadsSupportingDoc1;
	
	private List<FileUpload> fileUploadsSupportingDoc2;
	
	private List<FileUpload> fileUploadsSupportingDoc3;
	
	private List<TrxnDocuments> trxnDocuments;
	
	private String supportingDoc1;
	
	private String supportingDoc2;
	
	private String supportingDoc3;

	private String id;

	private Integer profId;

	public Integer getDocProfId() {
		return docProfId;
	}


	public void setDocProfId(Integer docProfId) {
		this.docProfId = docProfId;
	}


	public McProfile getBeMcProfile() {
		return beMcProfile;
	}


	public void setBeMcProfile(McProfile beMcProfile) {
		this.beMcProfile = beMcProfile;
	}


	public String getDoctorId() {
		return doctorId;
	}


	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId.toUpperCase();
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName.toUpperCase();
	}


	public String getIdentityNo() {
		return identityNo;
	}


	public void setIdentityNo(String identityNo) {
		this.identityNo = identityNo.toUpperCase();
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getDesignation() {
		return designation;
	}


	public void setDesignation(String designation) {
		this.designation = designation.toUpperCase();
	}


	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department.toUpperCase();
	}


	public String getDivision() {
		return division;
	}


	public void setDivision(String division) {
		this.division = division.toUpperCase();
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public String getFaxNo() {
		return faxNo;
	}


	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}


	public String getExt() {
		return ext;
	}


	public void setExt(String ext) {
		this.ext = ext;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public Boolean getIsActive() {
		return isActive;
	}


	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}


	public String getNationalId() {
		return nationalId;
	}


	public void setNationalId(String nationalId) {
		this.nationalId = nationalId;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public String getCntry() {
		return cntry;
	}


	public void setCntry(String cntry) {
		this.cntry = cntry;
	}


	public String getUserGroupRoleBranchCd() {
		return userGroupRoleBranchCd;
	}


	public void setUserGroupRoleBranchCd(String userGroupRoleBranchCd) {
		this.userGroupRoleBranchCd = userGroupRoleBranchCd;
	}


	public String getUserTypeCode() {
		return userTypeCode;
	}


	public void setUserTypeCode(String userTypeCode) {
		this.userTypeCode = userTypeCode;
	}


	public String getUserGroupCode() {
		return userGroupCode;
	}


	public void setUserGroupCode(String userGroupCode) {
		this.userGroupCode = userGroupCode;
	}


	public String getUserRoleGroupCode() {
		return userRoleGroupCode;
	}


	public void setUserRoleGroupCode(String userRoleGroupCode) {
		this.userRoleGroupCode = userRoleGroupCode;
	}


	public String getUserRoleGroupDesc() {
		return userRoleGroupDesc;
	}


	public void setUserRoleGroupDesc(String userRoleGroupDesc) {
		this.userRoleGroupDesc = userRoleGroupDesc;
	}


	public String getParentRoleGroup() {
		return parentRoleGroup;
	}


	public void setParentRoleGroup(String parentRoleGroup) {
		this.parentRoleGroup = parentRoleGroup;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public String getBranchCode() {
		return branchCode;
	}


	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public List<String> getSelectedRoles() {
		return selectedRoles;
	}


	public void setSelectedRoles(List<String> selectedRoles) {
		this.selectedRoles = selectedRoles;
	}


	public boolean isFWCMSLogin() {
		return isFWCMSLogin;
	}


	public void setFWCMSLogin(boolean isFWCMSLogin) {
		this.isFWCMSLogin = isFWCMSLogin;
	}


	public String getIsFwcms() {
		return isFwcms;
	}


	public void setIsFwcms(String isFwcms) {
		this.isFwcms = isFwcms;
	}


	public List<String> getCmpanyRegNoList() {
		return cmpanyRegNoList;
	}


	public void setCmpanyRegNoList(List<String> cmpanyRegNoList) {
		this.cmpanyRegNoList = cmpanyRegNoList;
	}


	public String getTransactionType() {
		return transactionType;
	}


	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	public List<FileUpload> getFileUploads() {
		return fileUploads;
	}


	public void setFileUploads(List<FileUpload> fileUploads) {
		this.fileUploads = fileUploads;
	}


	public String getDocMgtId() {
		return docMgtId;
	}


	public void setDocMgtId(String docMgtId) {
		this.docMgtId = docMgtId;
	}


	public String getMyKadId() {
		return myKadId;
	}


	public void setMyKadId(String myKadId) {
		this.myKadId = myKadId;
	}


	public String getSearchId() {
		return searchId;
	}


	public void setSearchId(String searchId) {
		this.searchId = searchId;
	}


	public String getIsMyimms() {
		return isMyimms;
	}


	public void setIsMyimms(String isMyimms) {
		this.isMyimms = isMyimms;
	}


	public String getPosition() {
		return position;
	}


	public void setPosition(String position) {
		this.position = position;
	}


	public String getRefNo() {
		return refNo;
	}


	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}


	public String getRecordCardNo() {
		return recordCardNo;
	}


	public void setRecordCardNo(String recordCardNo) {
		this.recordCardNo = recordCardNo;
	}


	public String getStaffId() {
		return staffId;
	}


	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}


	public String getStateCd() {
		return stateCd;
	}


	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}


	public Integer getBranchId() {
		return branchId;
	}


	public void setBranchId(Integer branchId) {
		this.branchId = branchId;
	}


	public String getAction() {
		return action;
	}


	public void setAction(String action) {
		this.action = action;
	}


	public String getMedCertNo() {
		return medCertNo;
	}


	public void setMedCertNo(String medCertNo) {
		this.medCertNo = medCertNo.toUpperCase();
	}


	public List<FileUpload> getFileUploadsSupportingDoc1() {
		return fileUploadsSupportingDoc1;
	}


	public void setFileUploadsSupportingDoc1(List<FileUpload> fileUploadsSupportingDoc1) {
		this.fileUploadsSupportingDoc1 = fileUploadsSupportingDoc1;
	}


	public List<FileUpload> getFileUploadsSupportingDoc2() {
		return fileUploadsSupportingDoc2;
	}


	public void setFileUploadsSupportingDoc2(List<FileUpload> fileUploadsSupportingDoc2) {
		this.fileUploadsSupportingDoc2 = fileUploadsSupportingDoc2;
	}


	public List<FileUpload> getFileUploadsSupportingDoc3() {
		return fileUploadsSupportingDoc3;
	}


	public void setFileUploadsSupportingDoc3(List<FileUpload> fileUploadsSupportingDoc3) {
		this.fileUploadsSupportingDoc3 = fileUploadsSupportingDoc3;
	}


	public List<TrxnDocuments> getTrxnDocuments() {
		return trxnDocuments;
	}


	public void setTrxnDocuments(List<TrxnDocuments> trxnDocuments) {
		this.trxnDocuments = trxnDocuments;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public Integer getProfId() {
		return profId;
	}


	public void setProfId(Integer profId) {
		this.profId = profId;
	}


	public String getSupportingDoc1() {
		return supportingDoc1;
	}


	public void setSupportingDoc1(String supportingDoc1) {
		this.supportingDoc1 = supportingDoc1;
	}


	public String getSupportingDoc2() {
		return supportingDoc2;
	}


	public void setSupportingDoc2(String supportingDoc2) {
		this.supportingDoc2 = supportingDoc2;
	}


	public String getSupportingDoc3() {
		return supportingDoc3;
	}


	public void setSupportingDoc3(String supportingDoc3) {
		this.supportingDoc3 = supportingDoc3;
	}
	
}
