/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;


/**
 * @author michelle.angela
 *
 */
public class ConfigTripHealth implements Serializable, IQfCriteria<Trip> {

	private static final long serialVersionUID = 1855414410982890449L;

	private Integer tripHealthId;

	private String tripHealthDesc;

	private Boolean isActive;


	public Integer getTripHealthId() {
		return tripHealthId;
	}


	public void setTripHealthId(Integer tripHealthId) {
		this.tripHealthId = tripHealthId;
	}


	public String getTripHealthDesc() {
		return tripHealthDesc;
	}


	public void setTripHealthDesc(String tripHealthDesc) {
		this.tripHealthDesc = tripHealthDesc;
	}


	public Boolean getIsActive() {
		return isActive;
	}


	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

}
