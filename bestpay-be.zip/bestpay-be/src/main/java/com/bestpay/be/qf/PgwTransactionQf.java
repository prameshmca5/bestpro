/**
 *
 */
package com.bestpay.be.qf;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.bestpay.be.dao.TransactionRepository;
import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.model.PgwTransaction;
import com.bestpay.be.sdk.model.Transaction;
import com.bestpay.be.sdk.model.TransactionRptInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.pagination.PaginationCriteria;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;
import com.bstsb.util.DateUtil;


/**
 * @author N.N. Shuhada
 * @since 08 June 2018
 */
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Component(QualifierConstants.PGW_TRANSACTION_QF)
@Qualifier(QualifierConstants.PGW_TRANSACTION_QF)
public class PgwTransactionQf {

	private Logger logger = LoggerFactory.getLogger(PgwTransactionQf.class);

	private static final String IS_FILTER_BY_EMPTY = "isFilterByEmpty: {}";

	private static final String ACTUAL_AMOUNT = "actAmt";

	private static final String TRANS_ID = "transId";

	private static final String QUERY = "Query : {}";

	private static final String CREATE_DT = "createDt";

	private static final String CREATE_DT_AFTER = "createDtAfter";

	private static final String STATUS_LIKE_STATUS = " and r.status like :status ";

	private static final String FROM_PGWTRANSACTION_R = " from PgwTransaction r ";

	private static final String WHERE_1_EQUALS_TO_1 = " where 1=1 ";

	private static final String FILTERED_SIZE = "Filtered Size: {}";

	private static final String ORIGINAL_SIZE = "Original Size: {}";

	private static final String BILL_AMT = "billAmt";

	private static final String BILLING_EMAIL = "billingEmail";

	private static final String BILLING_NAME = "billingName";

	private static final String CHANNEL = "channel";

	private static final String CONVERT_CUR = "convertCur";

	private static final String FROM_DATE = "fromDate";

	private static final String MERCHANTID = "merchantId";

	private static final String ORDERID = "orderId";

	private static final String SELECT_R = "select r ";

	private static final String STATUS = "status";

	private static final String TODATE = "toDate";

	private static final String AND_MERCHANTID_EQUALS_MERCHANTID = " and r.merchantId = :merchantId ";

	private static final String AND_STATUS_EQUALS_SUCCESS = " and r.status = 'success' ";

	@Autowired
	private TransactionRepository transListDao;

	@PersistenceContext
	private EntityManager em;


	public EntityManager getEntityManager() {
		return em;
	}


	public void setEntityManager(EntityManager entityManager) {
		em = entityManager;
	}


	public List<PgwTransaction> searchTransList(PgwTransaction transLst) {
		StringBuilder sb = new StringBuilder(SELECT_R);
		sb.append(FROM_PGWTRANSACTION_R);
		sb.append(WHERE_1_EQUALS_TO_1);

		if (!BaseUtil.isObjNull(transLst.getCreateDt())) {
			sb.append(" and r.createDt like :createDt ");
		}

		if (!BaseUtil.isObjNull(transLst.getTransId())) {
			sb.append(" and r.transId like :transId ");
		}

		if (!BaseUtil.isObjNull(transLst.getOrderId())) {
			sb.append(" and r.orderId like :orderId ");
		}

		if (!StringUtils.hasText(transLst.getChannel())) {
			sb.append(" and r.channel like :channel ");
		}

		if (!StringUtils.hasText(transLst.getBillingName())) {
			sb.append(" and r.billingName like :billingName ");
		}

		if (!StringUtils.hasText(transLst.getBillingEmail())) {
			sb.append(" and r.billingEmail like :billingEmail ");
		}

		if (!StringUtils.hasText(transLst.getStatus())) {
			sb.append(STATUS_LIKE_STATUS);
		}

		if (!StringUtils.hasText(transLst.getConvertCur())) {
			sb.append(" and r.convertCur like :convertCur ");
		}

		if (!BaseUtil.isObjNull(transLst.getBillAmt())) {
			sb.append(" and r.billAmt = billAmt ");
		}

		if (!BaseUtil.isObjNull(transLst.getActAmt())) {
			sb.append(" and r.actAmt like :actAmt ");
		}

		if (logger.isDebugEnabled()) {
			logger.info(QUERY, sb);
		}

		TypedQuery<PgwTransaction> query = em.createQuery(sb.toString(), PgwTransaction.class);

		if (!BaseUtil.isObjNull(transLst.getCreateDt())) {
			query.setParameter(CREATE_DT, transLst.getCreateDt());
		}

		if (!BaseUtil.isObjNull(transLst.getTransId())) {
			query.setParameter(TRANS_ID, transLst.getTransId());
		}

		if (!BaseUtil.isObjNull(transLst.getOrderId())) {
			query.setParameter(ORDERID, transLst.getOrderId());
		}

		if (!StringUtils.hasText(transLst.getChannel())) {
			query.setParameter(CHANNEL, transLst.getChannel());
		}

		if (!StringUtils.hasText(transLst.getBillingName())) {
			query.setParameter(BILLING_NAME, transLst.getBillingName());
		}

		if (!StringUtils.hasText(transLst.getBillingEmail())) {
			query.setParameter(BILLING_EMAIL, transLst.getBillingEmail());
		}

		if (!StringUtils.hasText(transLst.getConvertCur())) {
			query.setParameter(CONVERT_CUR, transLst.getConvertCur());
		}

		if (!BaseUtil.isObjNull(transLst.getActAmt())) {
			query.setParameter(ACTUAL_AMOUNT, transLst.getActAmt());
		}

		if (!BaseUtil.isObjNull(transLst.getBillAmt())) {
			query.setParameter(BILL_AMT, transLst.getBillAmt());
		}

		if (!StringUtils.hasText(transLst.getStatus())) {
			query.setParameter(STATUS, transLst.getStatus());
		}

		return query.getResultList();
	}


	public DataTableResults<PgwTransaction> searchTranLst(Transaction transactionList,
			DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder(SELECT_R);
		sb.append(FROM_PGWTRANSACTION_R);
		sb.append(WHERE_1_EQUALS_TO_1);

		if (!BaseUtil.isObjNull(transactionList.getCreateDt())) {
			sb.append(" and r.createDt like :createDt ");
		}

		if (!BaseUtil.isObjNull(transactionList.getTransId())) {
			sb.append(" and r.transId like :transId ");

		}

		if (!BaseUtil.isObjNull(transactionList.getOrderId())) {
			sb.append(" and r.orderId like :orderId ");
		}

		if (StringUtils.hasText(transactionList.getChannel())) {
			sb.append(" and r.channel like :channel ");
		}

		if (StringUtils.hasText(transactionList.getBillingName())) {
			sb.append(" and r.billingName like :billingName ");
		}

		if (StringUtils.hasText(transactionList.getBillingEmail())) {
			sb.append(" and r.billingEmail like :billingEmail ");
		}

		if (StringUtils.hasText(transactionList.getBillingMobile())) {
			sb.append(" and r.billingMobile like :billingMobile ");
		}

		if (StringUtils.hasText(transactionList.getStatus())) {
			sb.append(STATUS_LIKE_STATUS);
		}

		if (StringUtils.hasText(transactionList.getConvertCur())) {
			sb.append(" and r.convertCur like :convertCur ");
		}

		if (!BaseUtil.isObjNull(transactionList.getBillAmt())) {
			sb.append(" and r.billAmt = :billAmt ");
		}

		if (!BaseUtil.isObjNull(transactionList.getActAmt())) {
			sb.append(" and r.actAmt like :actAmt ");
		}

		if (!BaseUtil.isObjNull(transactionList.getMerchantId())) {
			sb.append(" and r.merchantId like :merchantId ");
		}

		if (!BaseUtil.isObjNull(transactionList.getSetId())) {
			sb.append(" and r.setId = :setId ");
		}

		sb.append(" order by r.createDt desc ");

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause());
			}
		}

		if (logger.isDebugEnabled()) {
			logger.info(QUERY, sb);
		}

		// Filtered Query by pagination
		TypedQuery<PgwTransaction> query = em.createQuery(sb.toString(), PgwTransaction.class);
		// Original Query
		TypedQuery<PgwTransaction> query2 = em.createQuery(sb.toString(), PgwTransaction.class);

		if (!BaseUtil.isObjNull(transactionList.getCreateDt())) {
			query.setParameter(CREATE_DT, transactionList.getCreateDt());
			query2.setParameter(CREATE_DT, transactionList.getCreateDt());
		}

		if (!BaseUtil.isObjNull(transactionList.getTransId())) {
			query.setParameter(TRANS_ID, transactionList.getTransId());
			query2.setParameter(TRANS_ID, transactionList.getTransId());
		}

		if (!BaseUtil.isObjNull(transactionList.getOrderId())) {
			query.setParameter(ORDERID, transactionList.getOrderId());
			query2.setParameter(ORDERID, transactionList.getOrderId());
		}

		if (StringUtils.hasText(transactionList.getChannel())) {
			query.setParameter(CHANNEL, transactionList.getChannel());
			query2.setParameter(CHANNEL, transactionList.getChannel());
		}

		if (StringUtils.hasText(transactionList.getBillingName())) {
			query.setParameter(BILLING_NAME, "%" + transactionList.getBillingName() + "%");
			query2.setParameter(BILLING_NAME, "%" + transactionList.getBillingName() + "%");
		}

		if (StringUtils.hasText(transactionList.getBillingEmail())) {
			query.setParameter(BILLING_EMAIL, "%" + transactionList.getBillingEmail() + "%");
			query2.setParameter(BILLING_EMAIL, "%" + transactionList.getBillingEmail() + "%");
		}

		if (StringUtils.hasText(transactionList.getBillingMobile())) {
			query.setParameter("billingMobile", transactionList.getBillingMobile());
			query2.setParameter("billingMobile", transactionList.getBillingMobile());
		}

		if (StringUtils.hasText(transactionList.getConvertCur())) {
			query.setParameter(CONVERT_CUR, transactionList.getConvertCur());
			query2.setParameter(CONVERT_CUR, transactionList.getConvertCur());
		}

		if (!BaseUtil.isObjNull(transactionList.getActAmt())) {
			query.setParameter(ACTUAL_AMOUNT, transactionList.getActAmt());
			query2.setParameter(ACTUAL_AMOUNT, transactionList.getActAmt());
		}

		if (!BaseUtil.isObjNull(transactionList.getBillAmt())) {
			query.setParameter(BILL_AMT, transactionList.getBillAmt());
			query2.setParameter(BILL_AMT, transactionList.getBillAmt());
		}

		if (StringUtils.hasText(transactionList.getStatus())) {
			query.setParameter(STATUS, transactionList.getStatus());
			query2.setParameter(STATUS, transactionList.getStatus());
		}

		if (!BaseUtil.isObjNull(transactionList.getMerchantId())) {
			query.setParameter(MERCHANTID, transactionList.getMerchantId());
			query2.setParameter(MERCHANTID, transactionList.getMerchantId());
		}

		if (!BaseUtil.isObjNull(transactionList.getSetId())) {
			query.setParameter("setId", transactionList.getSetId());
			query2.setParameter("setId", transactionList.getSetId());
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwTransaction> dataTableResult = new DataTableResults<>();
		List<PgwTransaction> svcResp = query.getResultList();
		List<PgwTransaction> svcResp2 = query2.getResultList();

		logger.debug(FILTERED_SIZE, svcResp.size());
		logger.debug(ORIGINAL_SIZE, svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : transListDao.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}

		return dataTableResult;
	}


	public DataTableResults<PgwTransaction> searchTransactionRpt(TransactionRptInfo transactionRptInfo,
			DataTableRequest dataTableInRQ, PgwMerchantProfile pgwMerchantProfile) {
		StringBuilder sb = new StringBuilder(SELECT_R);
		sb.append(FROM_PGWTRANSACTION_R);
		sb.append(WHERE_1_EQUALS_TO_1);

		if (!BaseUtil.isObjNull(pgwMerchantProfile.getMerchantId())) {
			sb.append(AND_MERCHANTID_EQUALS_MERCHANTID);
		}

		if (!BaseUtil.isObjNull(transactionRptInfo.getCreateDt())) {
			sb.append("and r.createDt between :createDt and :createDtAfter ");
		}

		if (!BaseUtil.isObjNull(transactionRptInfo.getFromDate())
				&& BaseUtil.isObjNull(transactionRptInfo.getToDate())) {
			sb.append("and r.createDt>=:fromDate ");
		} else if (BaseUtil.isObjNull(transactionRptInfo.getFromDate())
				&& !BaseUtil.isObjNull(transactionRptInfo.getToDate())) {
			sb.append("and r.createDt<=:toDate ");
		} else if (!BaseUtil.isObjNull(transactionRptInfo.getFromDate())
				&& !BaseUtil.isObjNull(transactionRptInfo.getToDate())) {
			sb.append("and r.createDt between :fromDate and :toDate ");
		}

		if (StringUtils.hasText(transactionRptInfo.getStatus())) {
			sb.append(STATUS_LIKE_STATUS);
		}

		sb.append(" order by r.createDt desc ");

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause());
			}
		}

		if (logger.isDebugEnabled()) {
			logger.info(QUERY, sb);
		}

		// Filtered Query by pagination
		TypedQuery<PgwTransaction> query = em.createQuery(sb.toString(), PgwTransaction.class);
		// Original Query
		TypedQuery<PgwTransaction> query2 = em.createQuery(sb.toString(), PgwTransaction.class);

		if (!BaseUtil.isObjNull(pgwMerchantProfile.getMerchantId())) {
			query.setParameter(MERCHANTID, pgwMerchantProfile.getMerchantId());
			query2.setParameter(MERCHANTID, pgwMerchantProfile.getMerchantId());
		}

		if (!BaseUtil.isObjNull(transactionRptInfo.getCreateDt())) {
			query.setParameter(CREATE_DT, transactionRptInfo.getCreateDt(), TemporalType.DATE);
			query2.setParameter(CREATE_DT, transactionRptInfo.getCreateDt(), TemporalType.DATE);
			query.setParameter(CREATE_DT_AFTER, DateUtil.addDayToTimestamp(transactionRptInfo.getCreateDt(), 1),
					TemporalType.DATE);
			query2.setParameter(CREATE_DT_AFTER, DateUtil.addDayToTimestamp(transactionRptInfo.getCreateDt(), 1),
					TemporalType.DATE);
		}

		if (!BaseUtil.isObjNull(transactionRptInfo.getFromDate())
				&& BaseUtil.isObjNull(transactionRptInfo.getToDate())) {
			query.setParameter(FROM_DATE, transactionRptInfo.getFromDate(), TemporalType.DATE);
			query2.setParameter(FROM_DATE, transactionRptInfo.getFromDate(), TemporalType.DATE);
		} else if (BaseUtil.isObjNull(transactionRptInfo.getFromDate())
				&& !BaseUtil.isObjNull(transactionRptInfo.getToDate())) {
			query.setParameter(TODATE, DateUtil.addDayToTimestamp(transactionRptInfo.getToDate(), 1),
					TemporalType.DATE);
			query2.setParameter(TODATE, transactionRptInfo.getToDate(), TemporalType.DATE);
		} else if (!BaseUtil.isObjNull(transactionRptInfo.getFromDate())
				&& !BaseUtil.isObjNull(transactionRptInfo.getToDate())) {
			query.setParameter(FROM_DATE, transactionRptInfo.getFromDate(), TemporalType.DATE);
			query.setParameter(TODATE, DateUtil.addDayToTimestamp(transactionRptInfo.getToDate(), 1),
					TemporalType.DATE);
			query2.setParameter(FROM_DATE, transactionRptInfo.getFromDate(), TemporalType.DATE);
			query2.setParameter(TODATE, DateUtil.addDayToTimestamp(transactionRptInfo.getToDate(), 1),
					TemporalType.DATE);
		}

		if (StringUtils.hasText(transactionRptInfo.getStatus())) {
			query.setParameter(STATUS, transactionRptInfo.getStatus());
			query2.setParameter(STATUS, transactionRptInfo.getStatus());
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwTransaction> dataTableResult = new DataTableResults<>();
		List<PgwTransaction> svcResp = query.getResultList();
		List<PgwTransaction> svcResp2 = query2.getResultList();

		logger.debug(FILTERED_SIZE, svcResp.size());
		logger.debug(ORIGINAL_SIZE, svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : transListDao.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		logger.debug(IS_FILTER_BY_EMPTY, dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}

		return dataTableResult;
	}


	public DataTableResults<PgwTransaction> getMonthlySuccessfulTransactions(String merchantId,
			DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder(SELECT_R);
		sb.append(FROM_PGWTRANSACTION_R);
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(" and r.paymentDt between date_format(now() , '%y-%m-01') and now() ");
		sb.append(AND_STATUS_EQUALS_SUCCESS);

		if (!BaseUtil.isObjNull(merchantId) && !BaseUtil.isEquals(merchantId, "null")) {
			sb.append(AND_MERCHANTID_EQUALS_MERCHANTID);
		}

		sb.append(" order by r.createDt desc ");
		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause());
			}
		}

		if (logger.isDebugEnabled()) {
			logger.info(QUERY, sb);
		}

		// Filtered Query by pagination
		TypedQuery<PgwTransaction> query = em.createQuery(sb.toString(), PgwTransaction.class);
		// Original Query
		TypedQuery<PgwTransaction> query2 = em.createQuery(sb.toString(), PgwTransaction.class);

		if (!BaseUtil.isObjNull(merchantId) && !BaseUtil.isEquals(merchantId, "null")) {
			query.setParameter(MERCHANTID, merchantId);
			query2.setParameter(MERCHANTID, merchantId);
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwTransaction> dataTableResult = new DataTableResults<>();
		List<PgwTransaction> svcResp = query.getResultList();
		List<PgwTransaction> svcResp2 = query2.getResultList();

		logger.debug(FILTERED_SIZE, svcResp.size());
		logger.debug(ORIGINAL_SIZE, svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : transListDao.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		logger.debug(IS_FILTER_BY_EMPTY, dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}

		return dataTableResult;
	}


	public DataTableResults<PgwTransaction> getTodaysSuccessfulTransactions(String merchantId,
			DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder(SELECT_R);
		sb.append(FROM_PGWTRANSACTION_R);
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(" and date(r.paymentDt)=date(now()) and r.status='success' ");

		if (!BaseUtil.isObjNull(merchantId) && !BaseUtil.isEquals(merchantId, "null")) {
			sb.append(AND_MERCHANTID_EQUALS_MERCHANTID);
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause());
			}
		}

		if (logger.isDebugEnabled()) {
			logger.info(QUERY, sb);
		}

		// Filtered Query by pagination
		TypedQuery<PgwTransaction> query = em.createQuery(sb.toString(), PgwTransaction.class);
		// Original Query
		TypedQuery<PgwTransaction> query2 = em.createQuery(sb.toString(), PgwTransaction.class);

		if (!BaseUtil.isObjNull(merchantId) && !BaseUtil.isEquals(merchantId, "null")) {
			query.setParameter(MERCHANTID, merchantId);
			query2.setParameter(MERCHANTID, merchantId);
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwTransaction> dataTableResult = new DataTableResults<>();
		List<PgwTransaction> svcResp = query.getResultList();
		List<PgwTransaction> svcResp2 = query2.getResultList();

		logger.debug(FILTERED_SIZE, svcResp.size());
		logger.debug(ORIGINAL_SIZE, svcResp2.size());

		// Get max total recors in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : transListDao.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		logger.debug(IS_FILTER_BY_EMPTY, dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}

		return dataTableResult;
	}


	public List<PgwTransaction> loadTransRptInfo(TransactionRptInfo transactionRptInfo,
			PgwMerchantProfile pgwMerchantProfile) {
		StringBuilder sb = new StringBuilder(SELECT_R);
		sb.append(FROM_PGWTRANSACTION_R);
		sb.append(WHERE_1_EQUALS_TO_1);

		if (!BaseUtil.isObjNull(pgwMerchantProfile.getMerchantId())) {
			sb.append(AND_MERCHANTID_EQUALS_MERCHANTID);
		}

		if (!BaseUtil.isObjNull(transactionRptInfo.getCreateDt())) {
			sb.append("and r.createDt between :createDt and :createDtAfter ");
		}

		if (!BaseUtil.isObjNull(transactionRptInfo.getFromDate())) {
			sb.append(" and r.createDt>=:fromDate ");
		}
		if (!BaseUtil.isObjNull(transactionRptInfo.getToDate())) {
			sb.append(" and r.createDt<=:toDate ");
		}
		if (!BaseUtil.isObjNull(transactionRptInfo.getStatus())) {
			sb.append(STATUS_LIKE_STATUS);
		}

		TypedQuery<PgwTransaction> query = em.createQuery(sb.toString(), PgwTransaction.class);

		if (!BaseUtil.isObjNull(pgwMerchantProfile.getMerchantId())) {
			query.setParameter(MERCHANTID, pgwMerchantProfile.getMerchantId());
		}

		if (!BaseUtil.isObjNull(transactionRptInfo.getCreateDt())) {
			query.setParameter(CREATE_DT, transactionRptInfo.getCreateDt(), TemporalType.DATE);
			query.setParameter(CREATE_DT_AFTER, DateUtil.addDayToTimestamp(transactionRptInfo.getCreateDt(), 1),
					TemporalType.DATE);
		}

		if (!BaseUtil.isObjNull(transactionRptInfo.getFromDate())
				&& BaseUtil.isObjNull(transactionRptInfo.getToDate())) {
			query.setParameter(FROM_DATE, transactionRptInfo.getFromDate(), TemporalType.DATE);
		} else if (BaseUtil.isObjNull(transactionRptInfo.getFromDate())
				&& !BaseUtil.isObjNull(transactionRptInfo.getToDate())) {
			query.setParameter(TODATE, DateUtil.addDayToTimestamp(transactionRptInfo.getToDate(), 1),
					TemporalType.DATE);
		} else if (!BaseUtil.isObjNull(transactionRptInfo.getFromDate())
				&& !BaseUtil.isObjNull(transactionRptInfo.getToDate())) {
			query.setParameter(FROM_DATE, transactionRptInfo.getFromDate(), TemporalType.DATE);
			query.setParameter(TODATE, DateUtil.addDayToTimestamp(transactionRptInfo.getToDate(), 1),
					TemporalType.DATE);
		}

		if (!BaseUtil.isObjNull(transactionRptInfo.getStatus())) {
			query.setParameter(STATUS, transactionRptInfo.getStatus());
		}

		return query.getResultList();
	}


	public DataTableResults<PgwTransaction> searchTop10TranLst(Transaction transactionList,
			DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder(SELECT_R);
		sb.append(FROM_PGWTRANSACTION_R);
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(" AND r.status = 'success' ");
		if (!BaseUtil.isObjNull(transactionList.getTop10())) {
			sb.append(" ORDER BY r.billAmt DESC");
		} else {
			sb.append(" ORDER BY r.fraudScore DESC");
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause());
			}
		}

		if (logger.isDebugEnabled()) {
			logger.info(QUERY, sb);
		}

		// Filtered Query by pagination
		TypedQuery<PgwTransaction> query = em.createQuery(sb.toString(), PgwTransaction.class);
		// Original Query
		TypedQuery<PgwTransaction> query2 = em.createQuery(sb.toString(), PgwTransaction.class);

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(10);
			}
		}

		DataTableResults<PgwTransaction> dataTableResult = new DataTableResults<>();
		List<PgwTransaction> svcResp = query.getResultList();
		List<PgwTransaction> svcResp2 = query2.getResultList();

		logger.debug(FILTERED_SIZE, svcResp.size());
		logger.debug(ORIGINAL_SIZE, svcResp2.size());

		int totalRecords = 10; // Get max total records in table
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}

		return dataTableResult;
	}


	public List<String> getTransListByMonth(String merchantId) {
		StringBuilder sb = new StringBuilder(" select concat(month(r.paymentDt), '-',cast(count(*) as int)) ");
		sb.append(FROM_PGWTRANSACTION_R);
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(AND_STATUS_EQUALS_SUCCESS);
		if (!BaseUtil.isObjNull(merchantId) && !BaseUtil.isEquals(merchantId, "null")) {
			sb.append(AND_MERCHANTID_EQUALS_MERCHANTID);
		}
		sb.append(" and year(r.paymentDt) = year(now()) ");
		sb.append(" group by month(paymentDt) ");
		logger.info(QUERY, sb);

		TypedQuery<String> query = em.createQuery(sb.toString(), String.class);
		if (!BaseUtil.isObjNull(merchantId) && !BaseUtil.isEquals(merchantId, "null")) {
			query.setParameter(MERCHANTID, merchantId);
		}
		return query.getResultList();
	}


	public long getTodaysCountSuccessfulTransactions(String merchantId) {
		StringBuilder sb = new StringBuilder(" select count(r) ");
		sb.append(FROM_PGWTRANSACTION_R);
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(" and date(r.paymentDt)=date(now()) and r.status='success' ");
		if (!BaseUtil.isObjNull(merchantId) && !BaseUtil.isEquals(merchantId, "null")) {
			sb.append(AND_MERCHANTID_EQUALS_MERCHANTID);
		}
		logger.info(QUERY, sb);

		TypedQuery<Long> query = em.createQuery(sb.toString(), Long.class);
		if (!BaseUtil.isObjNull(merchantId) && !BaseUtil.isEquals(merchantId, "null")) {
			query.setParameter(MERCHANTID, merchantId);
		}
		return query.getSingleResult();
	}


	public String getSumAndCountOfMonth(String merchantId) {
		StringBuilder sb = new StringBuilder(" select concat(sum(r.billAmt), '-',cast(count(*) as int)) ");
		sb.append(FROM_PGWTRANSACTION_R);
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(" and r.paymentDt between date_format(now() , '%y-%m-01') and now() ");
		sb.append(AND_STATUS_EQUALS_SUCCESS);
		if (!BaseUtil.isObjNull(merchantId) && !BaseUtil.isEquals(merchantId, "null")) {
			sb.append(AND_MERCHANTID_EQUALS_MERCHANTID);
		}
		logger.info(QUERY, sb);

		TypedQuery<String> query = em.createQuery(sb.toString(), String.class);
		if (!BaseUtil.isObjNull(merchantId) && !BaseUtil.isEquals(merchantId, "null")) {
			query.setParameter(MERCHANTID, merchantId);
		}
		return query.getSingleResult();
	}

}