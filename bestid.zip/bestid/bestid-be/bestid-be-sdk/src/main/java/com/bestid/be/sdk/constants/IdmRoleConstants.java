/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.constants;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * @author nurul.naimma
 *
 * @since 19 Nov 2018
 */
public class IdmRoleConstants {

	private IdmRoleConstants() {
		throw new IllegalStateException("IdmRoleConstants class");
	}


	public static final String SYSTEM_ADMIN = "SYSTEM";

	public static final String DQ_ADMIN = "DQ_ADMIN";

	public static final String JIM_ADMIN = "JIM_ADMIN";

	public static final String DQ_USER = "DQ_USER";

	public static final String JIM_BPA_ADMIN = "JIM_BPA_ADMIN";

	public static final String JIM_BPA_USER = "JIM_BPA_USER";

	public static final String JIM_VPP_ADMIN = "JIM_VPP_ADMIN";

	public static final String JIM_VPP_USER = "JIM_VPP_USER";

	public static final String JIM_ESD_ADMIN = "JIM_ESD_ADMIN";

	public static final String JIM_ESD_USER = "JIM_ESD_USER";

	public static final String JIM_EMGS_ADMIN = "JIM_EMGS_ADMIN";

	public static final String JIM_EMGS_USER = "JIM_EMGS_USER";

	public static final String VA_USER = "VA_USER";

	public static final String OSC_USER = "OSC_USER";

	public static final String OSC_ADMIN = "OSC_ADMIN";

	@SuppressWarnings("serial")
	public static final List<String> ADMIN_ROLES;
	static {
		final List<String> list = new ArrayList<>();
		list.add(SYSTEM_ADMIN);
		list.add(DQ_ADMIN);
		list.add(JIM_ADMIN);
		list.add(OSC_ADMIN);
		ADMIN_ROLES = Collections.unmodifiableList(list);
	}

}
