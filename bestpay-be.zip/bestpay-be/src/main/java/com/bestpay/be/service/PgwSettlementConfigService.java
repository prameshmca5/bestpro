/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwSettlementConfigRepository;
import com.bestpay.be.model.PgwSettlementConfig;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Afif Saman
 * @since July 24, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_STTLMNT_CFG_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_STTLMNT_CFG_SVC)
public class PgwSettlementConfigService extends AbstractService<PgwSettlementConfig> {

	@Autowired
	private PgwSettlementConfigRepository settlementCategoryDao;


	@Override
	public PgwSettlementConfigRepository primaryDao() {
		return settlementCategoryDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwSettlementConfig findSettlementConfigByMerchantId(String merchantId) {
		return settlementCategoryDao.findSettlementConfigByMerchantId(merchantId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwSettlementConfig> findSettlementConfig() {
		return settlementCategoryDao.findSettlementConfig();
	}
}