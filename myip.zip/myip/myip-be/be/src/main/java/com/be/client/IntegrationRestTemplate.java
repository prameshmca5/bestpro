/**
 * 
 */
package com.be.client;

import java.io.IOException;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.Asserts;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;
import com.util.UriUtil;
import com.util.model.ErrorResponse;
import com.util.model.MessageResponse;

/**
 * @author michelle.angela
 *
 */
public class IntegrationRestTemplate {

	
	private static final Logger LOGGER = LoggerFactory.getLogger(IntegrationRestTemplate.class);
	
	CloseableHttpClient httpClient;
	
	public CloseableHttpClient getHttpClient() {
		return httpClient;
	}
	
	public void setHttpClient(CloseableHttpClient httpClient) {
		this.httpClient = httpClient;
	}
	
    public IntegrationRestTemplate() {
    	httpClient = HttpClients.createDefault();
    }

    public IntegrationRestTemplate(CloseableHttpClient httpClient) {
    	this.httpClient = httpClient;
    }

//    public Object getForObject(String url) throws Exception {
//    	return getForObject(url, null);
//    }
//    
//    public Object getForObject(String url, Map<String, Object> urlVariables) throws Exception {
//    	Asserts.notEmpty(url, "'url' must not be null");
//    	url = UriUtil.expandUriComponent(url, urlVariables);
//    	StringBuffer sbLog = new StringBuffer();
//    	sbLog.append("ESB GET Request:: " + url);
//    	try {
//	        HttpGet httpGet = new HttpGet(url);
//	        CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
//	        sbLog.append("\nESB GET Response Status:: " + httpResponse.getStatusLine().getStatusCode());
//	 
//	        if (httpResponse.getStatusLine().getStatusCode() != 200) {
//	        	String result = EntityUtils.toString(httpResponse.getEntity());
//	        	ErrorResponse er = new ObjectMapper().readValue(result, ErrorResponse.class);
//	        	sbLog.append("\nERROR: ESB GET Exception:: " + er.getErrorMessage() + " [" + er.getErrorCode() + "]");
//	    		throw new BeException(er.getErrorCode(), er.getErrorMessage());
//			}
//	        
//	        String result = EntityUtils.toString(httpResponse.getEntity(), "utf-8");
//	        JsonNode jnode = new ObjectMapper().readTree(result);
//	        if(jnode.isArray()) {
//	        	List<String> str = new ArrayList<String>();
//	        	for(JsonNode node : jnode) {
//	        		str.add(new ObjectMapper().writeValueAsString(node));
//	        	}
//	        	return str;
//	        } 
//	        return new ObjectMapper().writeValueAsString(jnode);
//    	} catch (IOException ex) {
//    		sbLog.append("\nERROR: ESB GET IOException:: " + ex.getMessage());
//    		throw new BeException(BeErrorCodeEnum.E503C000, new Object[]{url});        
//	    } finally {
//			httpClient.close();
//			LOGGER.info(sbLog.toString());
//		}
//	}
    
    public <T> T postForObject(String url, Object requestBody, Class<T> responseType) throws Exception {
    	return postForObject(url, requestBody, responseType, null);
    }
    
    public <T> T postForObject(String url, Object requestBody, Class<T> responseType, Map<String, Object> uriVariables) throws Exception {
    	Asserts.notEmpty(url, "'url' must not be null");
    	url = UriUtil.expandUriComponent(url, uriVariables);
    	T p = null;
    	StringBuffer sbLog = new StringBuffer();
    	sbLog.append("ESB POST Request:: " + url);
    	try {
    		HttpPost httpPost = new HttpPost(url);
    		    		
    		if(!BaseUtil.isObjNull(requestBody)) {
    			LOGGER.info("requestBody====={}", JsonUtil.objectMapper().valueToTree(requestBody));
    			JsonNode node = JsonUtil.objectMapper().convertValue(requestBody, JsonNode.class); //mapper.convertValue(requestBody, JsonNode.class);
    			sbLog.append("\nESB POST Request Body:: " +node.toString());
    			StringEntity input = new StringEntity(node.toString());
    			input.setContentType(MediaType.APPLICATION_JSON);
    			httpPost.setEntity(input);
    			httpPost.addHeader("Api-Key","159591093871XF6gGe2vjGWu38GQJjDaTH3upMgfH4wrsSS2PQ");
    		}
    		httpClient = getHttpClient2(); 
    		CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
    		sbLog.append("\nESB POST Response Status:: " + httpResponse.getStatusLine().getStatusCode());
    		
    		if (httpResponse.getStatusLine().getStatusCode() != 200) {
    			String result = EntityUtils.toString(httpResponse.getEntity());
    			MessageResponse er = JsonUtil.objectMapper().readValue(result, MessageResponse.class);
				sbLog.append("\nERROR: ESB GET Exception:: " + er.getMessage() + " [" + er.getCode() + "]");
				throw new BeException(er.getCode(), er.getMessage());
    		}
    		
    		String result = EntityUtils.toString(httpResponse.getEntity());
    		if (!BaseUtil.isObjNull(result)) {
				p = JsonUtil.objectMapper().readValue(result, responseType);
			}
    	} catch (SocketException e) {
    		sbLog.append("\nERROR: ESB POST SocketException:: " + e.getMessage());
    		throw e;	
    	} catch (IOException ex) {
    		ex.printStackTrace();
    		sbLog.append("\nERROR: ESB POST IOException:: " + ex.getMessage());
    		throw new BeException(BeErrorCodeEnum.E503C000, new Object[]{url});
    	} catch (Exception ex) {
    		ex.printStackTrace();
    	}finally {
    		httpClient.close();
    		LOGGER.info(sbLog.toString());
    		return p;
    	}
	}
    
    public boolean deleteForObject(String url) throws Exception {
    	return deleteForObject(url, null);
    }
    
    public boolean deleteForObject(String url, Map<String, Object> uriVariables) throws Exception {
    	Asserts.notEmpty(url, "'url' must not be null");
    	StringBuffer sbLog = new StringBuffer();
    	sbLog.append("ESB DELETE Request:: " + url);
    	boolean isDel = false;
    	try {
    		HttpDelete httpDel = new HttpDelete(url);
    		CloseableHttpResponse httpResponse = httpClient.execute(httpDel);
    		sbLog.append("\nESB DELETE Response Status:: " + httpResponse.getStatusLine().getStatusCode());
    	} catch (IOException ex) {
    		sbLog.append("\nERROR: ESB DELETE IOException:: " + ex.getMessage());
    		throw new BeException(BeErrorCodeEnum.E503C000, new Object[]{url});
    	} finally {
    		httpClient.close();
    		LOGGER.info(sbLog.toString());
    	}
    	return isDel;
    }
    
    public Object putForObject(String url, Map<String, Object> uriVariables) throws Exception {
    	return postForObject(url, null, null, uriVariables);
    }

    public Object putForObject(String url, Object requestBody, Map<String, Object> uriVariables) throws Exception {
    	Asserts.notEmpty(url, "'url' must not be null");
    	url = UriUtil.expandUriComponent(url, uriVariables);
    	StringBuffer sbLog = new StringBuffer();
    	sbLog.append("ESB PUT Request:: " + url);
    	try {
    		HttpPut httpPut = new HttpPut(url);
    		if(!BaseUtil.isObjNull(requestBody)) {
    			ObjectMapper mapper = new ObjectMapper();
    			JsonNode node = mapper.convertValue(requestBody, JsonNode.class);
    			sbLog.append("\nESB PUT Request Body:: " + node.toString());
    			StringEntity input = new StringEntity(node.toString());
    			input.setContentType(MediaType.APPLICATION_JSON);
    			httpPut.setEntity(input);
    		}
    		
    		CloseableHttpResponse httpResponse = httpClient.execute(httpPut);
    		sbLog.append("\nESB PUT Response Status:: " + httpResponse.getStatusLine().getStatusCode());
    		
    		if (httpResponse.getStatusLine().getStatusCode() != 200) {
				String result = EntityUtils.toString(httpResponse.getEntity());
				ErrorResponse er = new ObjectMapper().readValue(result, ErrorResponse.class);
				sbLog.append("\nERROR: ESB GET Exception:: " + er.getErrorMessage() + " [" + er.getErrorCode() + "]");
				throw new BeException(er.getErrorCode(), er.getErrorMessage());
    		}
    		
    		String result = EntityUtils.toString(httpResponse.getEntity());
    		JsonNode jnode = new ObjectMapper().readTree(result);
	        if(jnode.isArray()) {
	        	List<String> str = new ArrayList<String>();
	        	for(JsonNode node : jnode) {
	        		str.add(new ObjectMapper().writeValueAsString(node));
	        	}
	        	return str;
	        } 
	        return new ObjectMapper().writeValueAsString(jnode);
    	} catch (IOException ex) {
    		sbLog.append("\nERROR: ESB PUT IOException:: " + ex.getMessage());
    		throw new BeException(BeErrorCodeEnum.E503C000, new Object[]{url});
    	} finally {
    		httpClient.close();
    		LOGGER.info(sbLog.toString());
    	}
	}	
    
    public <T> T postForObjectResp(String url, Object requestBody, Class<T> responseType, String apiKey) throws Exception {
    	return postForObjectResp(url, requestBody, responseType, null, apiKey, null);
    }
    
    public <T> T postForObjectResp(String url, Object requestBody, Class<T> responseType, Map<String, String> headers) throws Exception {
    	return postForObjectResp(url, requestBody, responseType, null, null, headers);
    }

    @SuppressWarnings("unchecked")
	public <T> T postForObjectResp(String url, Object requestBody, Class<T> responseType, 
    		Map<String, Object> uriVariables, String apiKey, Map<String, String> headers) throws Exception {
    	Asserts.notEmpty(url, "'url' must not be null");
    	url = UriUtil.expandUriComponent(url, uriVariables);
    	T p = null;
    	StringBuffer sbLog = new StringBuffer();
    	sbLog.append("ESB POST Request:: " + url);
    	try {
    		HttpPost httpPost = new HttpPost(url);
    		    		
    		if(!BaseUtil.isObjNull(requestBody)) {
    			LOGGER.info("requestBody====={}", JsonUtil.objectMapper().valueToTree(requestBody));
    			JsonNode node = JsonUtil.objectMapper().convertValue(requestBody, JsonNode.class); //mapper.convertValue(requestBody, JsonNode.class);
    			sbLog.append("\nESB POST Request Body:: " +node.toString());
    			StringEntity input = new StringEntity(node.toString());
    			input.setContentType(MediaType.APPLICATION_JSON);
    			httpPost.setEntity(input);
    			
    			if(!BaseUtil.isObjNull(apiKey)) {
	    			LOGGER.info("requestBody====={}", apiKey);
	    			httpPost.addHeader("Api-Key",apiKey);
    			}else if (headers.size() > 0) {
    				for(Entry<String, String> entry : headers.entrySet()) {
    					httpPost.addHeader(entry.getKey(), entry.getValue());
    				}
    			}
    		}
    		
    		httpClient = getHttpClient2(); 
    		CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
    		sbLog.append("\nESB POST Response Status:: " + httpResponse.getStatusLine().getStatusCode());
    		System.out.println(httpResponse.getEntity().getContentType().getValue());
    		if (httpResponse.getStatusLine().getStatusCode() != 200) {
    			String result = EntityUtils.toString(httpResponse.getEntity());
    			p = JsonUtil.objectMapper().readValue(result, responseType);
				return p;
    		}
    		
    		String result = EntityUtils.toString(httpResponse.getEntity());
    		if (!BaseUtil.isObjNull(result)) {
    			if(httpResponse.getEntity().getContentType().getValue().contains("text/plain"))
    				p = (T) result;
    			else
    				p = JsonUtil.objectMapper().readValue(result, responseType);
			}
    		
    		
    	} catch (SocketException e) {
    		sbLog.append("\nERROR: ESB POST SocketException:: " + e.getMessage());
    		throw e;	
    	} catch (IOException ex) {
    		ex.printStackTrace();
    		sbLog.append("\nERROR: ESB POST IOException:: " + ex.getMessage());
    		throw new BeException(BeErrorCodeEnum.E503C000, new Object[]{url});
    	} catch (Exception ex) {
    		ex.printStackTrace();
    	}finally {
    		httpClient.close();
    		LOGGER.info(sbLog.toString());
    		return p;
    	}
	}

    public CloseableHttpClient getHttpClient2() {
    	PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
    	int timeout = 20;
		RequestConfig config = RequestConfig.custom()
				 .setConnectTimeout (timeout * 1000) // set the connection timeout, in milliseconds
				 //.setConnectionRequestTimeout(timeout * 1000) // set the acquisition Connection timeout in milliseconds from the connect Manager
				 .setSocketTimeout (timeout * 1000) .build (); // timeout request for acquiring data milliseconds
		httpClient = HttpClients.custom()
				.setConnectionManager(cm).setDefaultRequestConfig(config)
				.build();
		if (!BaseUtil.isObjNull(cm) && !BaseUtil.isObjNull(cm.getTotalStats())) {// print the status of the connection pool		
			LOGGER.info("now client pool {}",cm.getTotalStats().toString());
		}
		return httpClient;
	}
  

    public <T> T getForObject(String url, Class<T> responseType) {
		return getForObject(url, responseType, null, null);
	}
    
    public <T> T getForObject(String url, Class<T> responseType, Map<String, String> headers) {
		return getForObject(url, responseType, null, headers);
	}
    
    public <T> T getForObject(String url, Class<T> responseType, Map<String, Object> urlVariables, Map<String, String> headers) {
    	Asserts.notEmpty(url, "'url' must not be null");
		url = UriUtil.expandUriComponent(url, urlVariables);
		LOGGER.info("{} GET Request: {}", url);
		T p = null;
		try {
			HttpGet httpGet = new HttpGet(url);
			
			if (headers.size() > 0) {
				for(Entry<String, String> entry : headers.entrySet()) {
					httpGet.addHeader(entry.getKey(), entry.getValue());
				}
			}
			
			httpClient = getHttpClient2(); 
			CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
			LOGGER.info("{} GET Response Status: {}", httpResponse.getStatusLine().getStatusCode());

			if (httpResponse.getStatusLine().getStatusCode() != 200) {
				String result = EntityUtils.toString(httpResponse.getEntity());
				System.out.println("ERR RESULT " + httpResponse.getEntity().getContentType().getValue());
				MessageResponse er = JsonUtil.objectMapper().readValue(result, MessageResponse.class);
				throw new BeException(er.getCode(), er.getMessage());
			}

			String result = EntityUtils.toString(httpResponse.getEntity(), "utf-8");
			if (!BaseUtil.isObjNull(result)) {
				p = JsonUtil.objectMapper().readValue(result, responseType);
			}
		} catch (Exception ex) {
			LOGGER.error("{}", ex);
			throw new BeException(BeErrorCodeEnum.E503C000, new Object[] { url });
		} 
		return p;
	}

}
