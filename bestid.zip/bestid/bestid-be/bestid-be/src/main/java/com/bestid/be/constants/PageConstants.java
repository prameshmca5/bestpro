/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.constants;


import com.bstsb.util.BaseUtil;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class PageConstants {

	private PageConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String PAGE_SRC = "/";

	public static final String PAGE_LOGIN = "/login";

	public static final String PAGE_LOGIN_QR = "/qr/login";

	public static final String PAGE_MAIN = "/main";

	public static final String PAGE_LOGIN_SUC = "/login-success";

	public static final String PAGE_LOGIN_ERR = "/login-error";

	public static final String PAGE_LOGOUT = "/logout-process";

	public static final String PAGE_ERROR = "/error";

	public static final String PAGE_ERROR_403 = "/403";

	public static final String PAGE_HOME = "/home";

	public static final String PAGE_WELCOME = "/welcome";

	public static final String PAGE_DISCLAIMER = "/disclaimer";

	public static final String PAGE_FIND_OUT_MORE = PAGE_MAIN + "/findOutMore";

	public static final String SERVICE_CHECK = "/serviceCheck";

	public static final String PAGE_FAQ = "/faq";

	public static final String PAGE_CONTACT = "/contact";

	public static final String PAGE_COMPONENTS = "/components";

	public static final String PAGE_TEST_VIEW = "/testView";

	public static final String PAGE_SETTINGS = "/settings";

	public static final String PAGE_SRC_IDM = "/idm";

	// Maintenance Screens
	public static final String GET_USERGROUP_CODE = "/getMenu";

	public static final String PAGE_IDM_CREATE_USERGROUP = "createUserGroup";

	public static final String PAGE_IDM_UPDATE_USERGROUP = "updateUserGroup";

	public static final String PAGE_IDM_USR_ROLE = PAGE_SRC_IDM + "/user-role-assignment";

	public static final String PAGE_USR_ROLE_GROUP = PAGE_SRC_IDM + "/user-role-group";

	public static final String PAGE_USR_GROUP = PAGE_SRC_IDM + "/usergroup-maintenance";

	public static final String GET_USERGROUP = "/getUserGroup";

	public static final String PAGE_APP = "/application";

	public static final String PAGE_APP_LIST = PAGE_APP + "/list";

	public static final String PAGE_APP_INBOX = PAGE_APP + "/inbox";

	public static final String PAGE_IDM_USER_TYPE_MAINTENANCE = PAGE_SRC_IDM + "/userType-maintenance";

	public static final String PAGE_IDM_CREATE_USER_TYPE = "/createUserType";

	public static final String PAGE_IDM_UPDATE_USER_TYPE = "updateUserType";

	public static final String PAGE_IDM_ROLE_CREATE_NEW_USER_TYPE = "createUserType";

	public static final String GET_MAINTENANCE_USER_TYPE_CODE = "/getUserType/{userTypeCode}/{userTypeDesc}/{userTypeId}";

	public static final String PAGE_CMN_STATIC = "/static-list";

	public static final String PAGE_CMN_OTP = "/otp";

	public static final String PAGE_CMN_CAPTCHA = "/captcha";

	public static final String PAGE_CMN_REPORT = "/reports";

	public static final String MAIL_TEMPLATE = "/mail-template";

	public static final String PAGE_DASHBOARD = "/dashboard";

	public static final String RESET = "reset";

	public static final String CANCEL = "cancel";

	public static final String DOCUMENTS = "/documents";

	public static final String REPORT = "/reports";

	public static final String NAME_BLOCK = "<th:block th:text=\"${name}\"/>";

	public static final String LOGIN_BLOCK = "<td th:text=\"${loginName}\" />";

	public static final String PASSWORD_BLOCK = "<td th:text=\"${password}\" />";

	public static final String FWCMS_URL_BLOCK = "<a th:href=\"${fwcmsUrl}\" th:text=\"${fwcmsUrl}\"/>";

	public static final String OTP_BLOCK = "<td th:text=\"${otp}\"/>";

	public static final String OTP_VARIABLE = "__otp__";

	public static final String NAME_VARIABLE = "__name__";

	public static final String LOGIN_NAME_VARIABLE = "__loginName__";

	public static final String PASSWORD_VARIABLE = "__password__";

	public static final String FWCMS_URL_VARIABLE = "__fwcmsUrl__";

	// User Management
	public static final String PAGE_IDM_USR_LST = "/user-list";

	public static final String PAGE_IDM_USR_UPD_LOGIN = "/user-list/id";

	public static final String PAGE_IDM_FRGT_PWORD = "/forgotPassword";

	public static final String PAGE_IDM_USR_CHNG_PWORD = "/user/change/password";


	public static String getRedirectUrl(String url) {
		return getRedirectUrl(url, null);
	}


	public static String getRedirectUrl(String url, String pathVar) {
		String newURL = "redirect:" + url;
		if (!BaseUtil.isObjNull(pathVar)) {
			newURL = newURL + "/" + pathVar;
		}
		return newURL;
	}

}
