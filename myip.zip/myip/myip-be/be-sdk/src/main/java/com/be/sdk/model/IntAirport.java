/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;


/**
 * @author nurul.naimma
 *
 * @since 11 Jul 2020
 */
public class IntAirport implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer intAirportId;

	private String iataCd;

	private String airportName;

	private String location;

	private String cntryCd;

	private boolean active;


	/**
	 * @return the intAirportId
	 */
	public Integer getIntAirportId() {
		return intAirportId;
	}


	/**
	 * @param intAirportId
	 *             the intAirportId to set
	 */
	public void setIntAirportId(Integer intAirportId) {
		this.intAirportId = intAirportId;
	}


	/**
	 * @return the iataCd
	 */
	public String getIataCd() {
		return iataCd;
	}


	/**
	 * @param iataCd
	 *             the iataCd to set
	 */
	public void setIataCd(String iataCd) {
		this.iataCd = iataCd;
	}


	/**
	 * @return the airportName
	 */
	public String getAirportName() {
		return airportName;
	}


	/**
	 * @param airportName
	 *             the airportName to set
	 */
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}


	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}


	/**
	 * @param location
	 *             the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}


	public String getCntryCd() {
		return cntryCd;
	}


	public void setCntryCd(String cntryCd) {
		this.cntryCd = cntryCd;
	}


	/**
	 * @return the active
	 */
	public boolean isActive() {
		return active;
	}


	/**
	 * @param active
	 *             the active to set
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

}
