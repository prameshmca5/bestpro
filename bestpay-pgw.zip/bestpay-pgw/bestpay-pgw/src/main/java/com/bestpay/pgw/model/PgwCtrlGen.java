/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;

/**
 * @author Chaithanya
 * @since 12/07/2018
 */
@Entity
@Table(name = "PGW_CTRL_GEN")
public class PgwCtrlGen extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = 6016032592885161865L;

	@Id
	@Column(name = "CTRL_GEN_DT")
	private String ctrlGenDt;

	@Column(name = "TRXN_ID")
	private Integer  trxnId;
 
	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	public String getCtrlGenDt() {
		return ctrlGenDt;
	}

	public void setCtrlGenDt(String ctrlGenDt) {
		this.ctrlGenDt = ctrlGenDt;
	}

	public Integer getTrxnId() {
		return trxnId;
	}

	public void setTrxnId(Integer trxnId) {
		this.trxnId = trxnId;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}
 
 
	
}