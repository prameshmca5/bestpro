/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.config;


import java.util.Locale;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
@Component
public class StaticData implements InitializingBean {

	@Autowired
	CacheManager cacheManager;

	@Autowired
	MessageSource messageSource;


	@Override
	public void afterPropertiesSet() throws Exception {
		messageSource.getMessage(ConfigConstants.SVC_IDM_SKEY, null, Locale.getDefault());
		messageSource.getMessage(ConfigConstants.SVC_IDM_CLIENT, null, Locale.getDefault());
	}

}