package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


public class IpayEnquireOrderStatus implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String b4u_merchantId;
	
	private Float b4u_amount;
	
	private String b4u_currency;
	
	private String b4u_channel;
	
	private String b4u_orderId;
	
	private String b4u_tranId;
	
	private String b4u_status;
	
	private String b4u_bank;
	
	private String b4u_paymentcode;
	
	private String b4u_appcode;
	
	private String b4u_errorcode;
	
	private String b4u_errordesc;
	
	private String b4u_txndate;
	
	private String b4u_ccName;
	
	private String b4u_ccNo;

	public String getB4u_merchantId() {
		return b4u_merchantId;
	}

	public void setB4u_merchantId(String b4u_merchantId) {
		this.b4u_merchantId = b4u_merchantId;
	}

	public Float getB4u_amount() {
		return b4u_amount;
	}

	public void setB4u_amount(Float b4u_amount) {
		this.b4u_amount = b4u_amount;
	}

	public String getB4u_currency() {
		return b4u_currency;
	}

	public void setB4u_currency(String b4u_currency) {
		this.b4u_currency = b4u_currency;
	}

	public String getB4u_channel() {
		return b4u_channel;
	}

	public void setB4u_channel(String b4u_channel) {
		this.b4u_channel = b4u_channel;
	}

	public String getB4u_orderId() {
		return b4u_orderId;
	}

	public void setB4u_orderId(String b4u_orderId) {
		this.b4u_orderId = b4u_orderId;
	}

	public String getB4u_tranId() {
		return b4u_tranId;
	}

	public void setB4u_tranId(String b4u_tranId) {
		this.b4u_tranId = b4u_tranId;
	}

	public String getB4u_status() {
		return b4u_status;
	}

	public void setB4u_status(String b4u_status) {
		this.b4u_status = b4u_status;
	}

	public String getB4u_bank() {
		return b4u_bank;
	}

	public void setB4u_bank(String b4u_bank) {
		this.b4u_bank = b4u_bank;
	}

	public String getB4u_paymentcode() {
		return b4u_paymentcode;
	}

	public void setB4u_paymentcode(String b4u_paymentcode) {
		this.b4u_paymentcode = b4u_paymentcode;
	}

	public String getB4u_appcode() {
		return b4u_appcode;
	}

	public void setB4u_appcode(String b4u_appcode) {
		this.b4u_appcode = b4u_appcode;
	}

	public String getB4u_errorcode() {
		return b4u_errorcode;
	}

	public void setB4u_errorcode(String b4u_errorcode) {
		this.b4u_errorcode = b4u_errorcode;
	}

	public String getB4u_errordesc() {
		return b4u_errordesc;
	}

	public void setB4u_errordesc(String b4u_errordesc) {
		this.b4u_errordesc = b4u_errordesc;
	}
	
 	public String getB4u_txndate() {
		return b4u_txndate;
	}

	public void setB4u_txndate(String b4u_txndate) {
		this.b4u_txndate = b4u_txndate;
	}

	public String getB4u_ccName() {
		return b4u_ccName;
	}

	public void setB4u_ccName(String b4u_ccName) {
		this.b4u_ccName = b4u_ccName;
	}

	public String getB4u_ccNo() {
		return b4u_ccNo;
	}

	public void setB4u_ccNo(String b4u_ccNo) {
		this.b4u_ccNo = b4u_ccNo;
	}
		
}
