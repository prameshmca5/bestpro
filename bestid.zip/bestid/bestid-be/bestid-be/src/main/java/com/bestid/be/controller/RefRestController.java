/**
 * Copyright 2019. Bestinet Sdn Bhd
 */
package com.bestid.be.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestid.be.constants.TxnCodeConstants;
import com.bestid.be.model.BidConfig;
import com.bestid.be.sdk.constants.BeErrorCodeEnum;
import com.bestid.be.sdk.constants.BeUrlConstants;
import com.bestid.be.sdk.exception.BeException;
import com.bestid.be.sdk.model.RefBidConfig;
import com.bestid.be.service.BidConfigService;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.MediaType;
import com.bstsb.util.pagination.DataTableRequest;
import com.bstsb.util.pagination.DataTableResults;


/**
 * @author mohd.faisal
 * @since Mar 5, 2019
 */

@Lazy
@RestController
public class RefRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(RefRestController.class);

	@Autowired
	private BidConfigService bidConfigService;


	// list
	@GetMapping(value = BeUrlConstants.MAINTENANCE_BIDCONFIG, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<RefBidConfig> listBidConfig(HttpServletRequest request) {

		List<BidConfig> confLst = bidConfigService.primaryDao().findAll();
		List<RefBidConfig> config = new ArrayList<>();
		if (!confLst.isEmpty()) {
			for (BidConfig conf : confLst) {
				config.add(dozerMapper.map(conf, RefBidConfig.class));
			}
		}
		return config;
	}


	// pagination
	@PostMapping(value = BeUrlConstants.MAINTENANCE_BIDCONFIG_PAGINATED, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DataTableResults<RefBidConfig> listBidConfigPaginated(
			@RequestParam(defaultValue = TxnCodeConstants.MAINTENANCE_BIDCONFIG) String trxnNo,
			HttpServletRequest request, @Valid @RequestBody RefBidConfig config) {

		DataTableRequest<BidConfig> dataTableRequest = new DataTableRequest<>(request.getParameterMap());
		DataTableResults<RefBidConfig> refbidconfigdataTableResponse = new DataTableResults<>();
		DataTableResults<BidConfig> bidconfigdataTableResponse = new DataTableResults<>();

		try {

			bidconfigdataTableResponse = bidConfigService.bidConfigPaginated(dataTableRequest, config);

			if (!BaseUtil.isObjNull(bidconfigdataTableResponse)) {
				refbidconfigdataTableResponse.setRecordsFiltered(bidconfigdataTableResponse.getRecordsFiltered());
				refbidconfigdataTableResponse.setRecordsTotal(bidconfigdataTableResponse.getRecordsTotal());
				if (!BaseUtil.isListNullZero(bidconfigdataTableResponse.getData())) {

					List<BidConfig> listbidconfig = bidconfigdataTableResponse.getData();
					List<RefBidConfig> listconfig = new ArrayList<>();
					if (!listbidconfig.isEmpty()) {
						for (BidConfig bidconf : listbidconfig) {
							listconfig.add(dozerMapper.map(bidconf, RefBidConfig.class));
						}
					}

					refbidconfigdataTableResponse.setData(listconfig);
				}
			}
		} catch (Exception e) {

			LOGGER.error(e.getMessage());
		}

		return refbidconfigdataTableResponse;
	}


	// search by Code
	@GetMapping(value = BeUrlConstants.MAINTENANCE_BIDCONFIG + "/{configCd}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public BidConfig findConfigCd(@PathVariable String configCd, HttpServletRequest request) {

		return bidConfigService.findByConfigCd(configCd);
	}


	// search by Id
	@GetMapping(value = BeUrlConstants.MAINTENANCE_BIDCONFIG_FIND_BY_ID, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public BidConfig findByConfigId(@RequestParam(value = "id", required = true) Integer configId,
			HttpServletRequest request) {

		return bidConfigService.findByConfigId(configId);
	}


	// create
	@PostMapping(value = BeUrlConstants.MAINTENANCE_BIDCONFIG_CREATE, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public BidConfig createBidConfig(@RequestBody RefBidConfig config, HttpServletRequest request) {
		BidConfig bidConfig1 = bidConfigService.findByConfigCd(config.getConfigCd());

		if (!BaseUtil.isObjNull(bidConfig1)) {
			throw new BeException(BeErrorCodeEnum.E409BST001);

		}

		BidConfig bidConfig = new BidConfig();
		bidConfig.setConfigCd(config.getConfigCd());
		bidConfig.setConfigVal(config.getConfigVal());
		bidConfig.setConfigDesc(config.getConfigDesc());
		bidConfig.setCreateId(getCurrUserId(request));
		bidConfig.setUpdateId(getCurrUserId(request));
		bidConfigService.create(bidConfig);

		return bidConfig;

	}


	// update
	@PostMapping(value = BeUrlConstants.MAINTENANCE_BIDCONFIG_UPDATE, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public BidConfig updateBidConfig(@RequestBody RefBidConfig config, HttpServletRequest request) {
		BidConfig bidConfig = bidConfigService.findByConfigId(config.getConfigId());

		if (!BaseUtil.isObjNull(bidConfig)) {
			bidConfig.setConfigCd(config.getConfigCd());
			bidConfig.setConfigVal(config.getConfigVal());
			bidConfig.setConfigDesc(config.getConfigDesc());
			bidConfigService.update(bidConfig);
		}
		return bidConfig;

	}


	// delete
	@DeleteMapping(value = BeUrlConstants.MAINTENANCE_BIDCONFIG_DELETED, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public boolean deleteBidConfig(@RequestParam(value = "id", required = true) Integer configId,
			HttpServletRequest request) {

		return bidConfigService.delete(configId);
	}

}
