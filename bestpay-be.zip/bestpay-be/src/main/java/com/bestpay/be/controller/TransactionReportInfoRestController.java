/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.model.PgwTransaction;
import com.bestpay.be.model.RefChannel;
import com.bestpay.be.model.RefStatus;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.model.TransactionRptInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.service.PgwTransactionService;
import com.bestpay.be.service.RefStatusService;
import com.bstsb.util.MediaType;


/**
 * @author Afif Saman
 * @since June 22, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.TRANSACTION_REPORT)
public class TransactionReportInfoRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionReportInfoRestController.class);

	@Autowired
	protected PgwTransactionService pgwTransactionSvc;

	@Autowired
	protected RefStatusService refStatusSvc;


	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<TransactionRptInfo> searchTransactionReportPaginated(
			@Valid @RequestBody TransactionRptInfo transactionRptInfo, HttpServletRequest request) {
		PgwMerchantProfile pgwMerchantProfile = new PgwMerchantProfile();
		if (!BaseUtil.isObjNull(transactionRptInfo.getMerProfId())) {
			pgwMerchantProfile = pgwMerchantProfileService
					.findByMerchantProfileId(transactionRptInfo.getMerProfId());
		}
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwTransaction> result = pgwTransactionSvc.searchTransactionRpt(transactionRptInfo,
				dataTableInRQ, pgwMerchantProfile);
		DataTableResults<TransactionRptInfo> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<TransactionRptInfo> bpLst = new ArrayList<>();
				for (PgwTransaction bbp : result.getData()) {
					TransactionRptInfo trustee = dozerMapper.map(bbp, TransactionRptInfo.class);
					RefChannel refChannel = refChannelSvc.findRefChannelByPublicName(trustee.getChannel());
					if (!BaseUtil.isObjNull(refChannel)) {
						trustee.setChannel(refChannel.getName());
					}
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		return dataTableInResp;
	}


	@PostMapping(value = BeUrlConstants.TRANS_RPT_INFO, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<TransactionRptInfo> findTransRptInfo(@Valid @RequestBody TransactionRptInfo transactionRptInfo,
			HttpServletRequest request) {
		PgwMerchantProfile pgwMerchantProfile = new PgwMerchantProfile();
		if (!BaseUtil.isObjNull(transactionRptInfo.getMerProfId())) {
			pgwMerchantProfile = pgwMerchantProfileService
					.findByMerchantProfileId(transactionRptInfo.getMerProfId());
		}
		List<TransactionRptInfo> transaction = new ArrayList<>();
		List<PgwTransaction> pgwTransaction = pgwTransactionSvc.loadTransRptInfo(transactionRptInfo,
				pgwMerchantProfile);
		if (!CollectionUtils.isEmpty(pgwTransaction)) {
			transaction = new ArrayList<>();
			for (PgwTransaction info : pgwTransaction) {
				LOGGER.info("Is Admin = {}", transactionRptInfo.getIsAdmin());
				TransactionRptInfo infoData = new TransactionRptInfo();
				infoData.setCreateDateReport(info.getCreateDt());
				infoData.setTransId(info.getTransId());
				infoData.setOrderId(info.getOrderId());
				if (transactionRptInfo.getIsAdmin()) {
					infoData.setActCur(info.getActCur());
				}

				if (BaseUtil.isEquals(info.getChannel(), "FPX")) {
					infoData.setChannel("FPX");
				} else if (BaseUtil.isObjNull(info.getChannel())) {
					infoData.setChannel("");
				} else {
					RefChannel refChannel = refChannelSvc.findRefChannelByPublicName(info.getChannel());
					infoData.setChannel(refChannel.getName());
				}

				infoData.setBillingName(info.getBillingName());
				infoData.setBillAmt(info.getBillAmt());
				infoData.setActAmt(info.getActAmt());
				RefStatus status = refStatusSvc.findByStatusTypeAndCode("TRANSTAT", info.getStatus());
				if (!BaseUtil.isObjNull(status)) {
					infoData.setStatus(status.getStatusDescEn());
				} else {
					infoData.setStatus(info.getStatus());
				}
				infoData.setMerchantId(info.getMerchantId());
				infoData.setAddField(transactionRptInfo.getAddField());
				if (!BaseUtil.isObjNull(transactionRptInfo.getAddField())) {
					if (BaseUtil.isEqualsCaseIgnore(transactionRptInfo.getAddField(), "currency")) {
						infoData.setActCur(info.getActCur());
					} else if (BaseUtil.isEqualsCaseIgnore(transactionRptInfo.getAddField(), "billEmail")) {
						infoData.setBillingEmail(info.getBillingEmail());
					} else if (BaseUtil.isEqualsCaseIgnore(transactionRptInfo.getAddField(), "transRate")) {
						infoData.setTransRate(info.getTransRate());
					} else if (BaseUtil.isEqualsCaseIgnore(transactionRptInfo.getAddField(), "billInfo")) {
						infoData.setBillingInfo(info.getBillingInfo());
					}
				}

				transaction.add(infoData);
			}
		}

		return transaction;
	}
}