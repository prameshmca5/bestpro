/**
 *
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author roziana
 * @since Feb 15, 2019
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class QrDigitalId implements Serializable {

	private static final long serialVersionUID = -1125957977724508212L;

	private DigitalIdInfo digitalIdInfo;

	private Device deviceInfo;

	private String machineId;

	private String status;

	private String applId;

	private String qrKey;

	private String uuid;

	private String ind;

	private Boolean respFlag;

	private String qrCodeImage;

	private String refNo;

	private String fullName;

	private String uuidExpDt;


	public String getMachineId() {
		return machineId;
	}


	public void setMachineId(String machineId) {
		this.machineId = machineId;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getQrCodeImage() {
		return qrCodeImage;
	}


	public void setQrCodeImage(String qrCodeImage) {
		this.qrCodeImage = qrCodeImage;
	}


	public DigitalIdInfo getDigitalIdInfo() {
		return digitalIdInfo;
	}


	public void setDigitalIdInfo(DigitalIdInfo digitalIdInfo) {
		this.digitalIdInfo = digitalIdInfo;
	}


	public Device getDeviceInfo() {
		return deviceInfo;
	}


	public void setDeviceInfo(Device deviceInfo) {
		this.deviceInfo = deviceInfo;
	}


	public String getApplId() {
		return applId;
	}


	public void setApplId(String applId) {
		this.applId = applId;
	}


	public String getQrKey() {
		return qrKey;
	}


	public void setQrKey(String qrKey) {
		this.qrKey = qrKey;
	}


	public String getInd() {
		return ind;
	}


	public void setInd(String ind) {
		this.ind = ind;
	}


	public String getUuid() {
		return uuid;
	}


	public void setUuid(String uuid) {
		this.uuid = uuid;
	}


	public Boolean getRespFlag() {
		return respFlag;
	}


	public void setRespFlag(Boolean respFlag) {
		this.respFlag = respFlag;
	}


	public String getRefNo() {
		return refNo;
	}


	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getUuidExpDt() {
		return uuidExpDt;
	}


	public void setUuidExpDt(String uuidExpDt) {
		this.uuidExpDt = uuidExpDt;
	}

}
