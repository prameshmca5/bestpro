/**
 * Copyright 2018 Bestinet Sdn Bhd
 */
package com.bestpay.web.idm.validator;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.be.sdk.model.BlacklistInfo;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ValidationUtil;

/**
 * @author Afif Saman
 *
 */
@Component("blacklistValidator")
public class BlacklistValidator extends AbstractController implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return BlacklistInfo.class.equals(clazz);
	}

	@Override
	public void validate(Object object, Errors errors) {
		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "tag", MessageConstants.ERROR_FIELDS_TAG);
		Object tagValue = errors.getFieldValue("tag");

		if (tagValue != null && StringUtils.hasText(tagValue.toString())) {
			if (BaseUtil.isEqualsCaseIgnore(tagValue.toString(), "email")) {
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "emailValue", MessageConstants.ERROR_EMAIL_REQUIRED);
				// Validate email if format is valid
				ValidationUtil.rejectIfInvalidEmailFormat(errors, "emailValue", MessageConstants.ERROR_EMAIL_FORMAT);
			} else if (BaseUtil.isEqualsCaseIgnore(tagValue.toString(), "mobile")) {
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "mobileValue", MessageConstants.ERROR_PHONE_REQUIRED);
			}
		}

	}

}
