/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.RefPaymentType;
import com.bestpay.pgw.util.QualifierConstants;

/**
 * @author Zia Ur Rahman Baig
 * @since Feb 17, 2018
 */
@Repository
@RepositoryDefinition(domainClass = RefPaymentType.class, idClass = Integer.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_PAYMENT_TYPE_DAO)
public interface RefPaymentTypeRepository extends
		GenericRepository<RefPaymentType> {

}