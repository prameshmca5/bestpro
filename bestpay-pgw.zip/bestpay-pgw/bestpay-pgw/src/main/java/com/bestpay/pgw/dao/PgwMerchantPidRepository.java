package com.bestpay.pgw.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.PgwMerchantPid;
import com.bestpay.pgw.util.QualifierConstants;


/**
 * @author Mohammad Rashid
 * @since Mar 25, 2019
 */
@Repository
@RepositoryDefinition(domainClass = PgwMerchantPid.class, idClass = Integer.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_PID_DAO)
public interface PgwMerchantPidRepository extends GenericRepository<PgwMerchantPid> {

	@Query("select u from PgwMerchantPid u where u.merchantId = :merchantId ")
	public List<PgwMerchantPid> findPgwMerchantPidBymerchantId(@Param("merchantId") String merchantId);


	@Query("select u from PgwMerchantPid u where u.merchantId = :merchantId ")
	public PgwMerchantPid findPgwMerchantMaxmoeyPidBymerchantId(@Param("merchantId") String merchantId);


	@Query("select u from PgwMerchantPid u where u.pid = :pid ")
	public PgwMerchantPid findPgwMerchantMaxmoeyPidByPid(@Param("pid") String pid);

}