/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidCertInfo;
import com.bestid.be.model.SecUserDevice;
import com.bestid.be.repo.BidCertInfoRepository;
import com.bestid.be.repo.GenericRepository;
import com.bestid.be.repo.SecUserDeviceRepository;


/**
 * @author mukhlis.hamzah
 * @since Feb 14, 2019
 */
@Transactional
@Service(QualifierConstants.BID_CERT_INFO_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_CERT_INFO_SVC)
public class BidCertInfoService extends AbstractService<BidCertInfo> {

	@Autowired
	@Qualifier(QualifierConstants.BID_CERT_INFO_REPOSITORY)
	BidCertInfoRepository bidCertInfoDao;

	@Autowired
	@Qualifier(QualifierConstants.SEC_USER_DEVICE_REPOSITORY)
	SecUserDeviceRepository secUserDeviceDao;


	@Override
	public GenericRepository<BidCertInfo> primaryDao() {
		return bidCertInfoDao;
	}


	public BidCertInfo findByApplId(Integer applId) {
		return bidCertInfoDao.findByApplId(applId);
	}


	public BidCertInfo findByRefNo(String refno) {
		return bidCertInfoDao.findByRefNo(refno);
	}


	public BidCertInfo findByCertRefNo(String certRefNo) {
		return bidCertInfoDao.findByCertRefNo(certRefNo);
	}


	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public BidCertInfo createCert(BidCertInfo bidCertInfo, SecUserDevice secUserDevice) {
		secUserDeviceDao.save(secUserDevice);
		return this.create(bidCertInfo);
	}


	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public BidCertInfo updateCert(BidCertInfo bidCertInfo, SecUserDevice secUserDevice) {
		secUserDeviceDao.save(secUserDevice);
		return this.update(bidCertInfo);
	}


	public List<BidCertInfo> findByApplIdList(List<Integer> applId) {
		return bidCertInfoDao.findByApplIdList(applId);
	}

}
