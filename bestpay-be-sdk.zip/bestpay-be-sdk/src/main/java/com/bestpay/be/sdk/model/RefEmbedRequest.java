/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author ravindra kumar
 * @since 21/03/2018
 */
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RefEmbedRequest implements Serializable {

	private static final long serialVersionUID = 2529325861681813793L;

	private boolean embedNationality;

	private boolean embedStatus;

	private boolean embedCountry;

	private boolean embedState;


	public RefEmbedRequest() {
		// refEmbedRequest dto model
	}


	public boolean isEmbedNationality() {
		return embedNationality;
	}


	public void setEmbedNationality(boolean embedNationality) {
		this.embedNationality = embedNationality;
	}


	public boolean isEmbedStatus() {
		return embedStatus;
	}


	public void setEmbedStatus(boolean embedStatus) {
		this.embedStatus = embedStatus;
	}


	public boolean isEmbedCountry() {
		return embedCountry;
	}


	public void setEmbedCountry(boolean embedCountry) {
		this.embedCountry = embedCountry;
	}


	public boolean isEmbedState() {
		return embedState;
	}


	public void setEmbedState(boolean embedState) {
		this.embedState = embedState;
	}

}