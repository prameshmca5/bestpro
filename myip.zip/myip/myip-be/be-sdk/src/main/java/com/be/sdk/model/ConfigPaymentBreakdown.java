/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;

/**
 * @author michelle.angela
 *
 */
public class ConfigPaymentBreakdown implements Serializable, IQfCriteria<ConfigPaymentBreakdown>  {

	private static final long serialVersionUID = 7360078277939266495L;

	private Integer pmtBreakdownId;
	 
	private ConfigPaymentStage configPaymentStage;
	 
	private Integer level;
	
	private double charges;
	
	private double refund;
	 
	private String currency;
	
	private String description;

	private Boolean isActive;
	
	private Country country;
	
	private Integer batchId;
	
	private String stakeholder;
	
	private boolean isCntryNull;

	public Integer getPmtBreakdownId() {
		return pmtBreakdownId;
	}

	public void setPmtBreakdownId(Integer pmtBreakdownId) {
		this.pmtBreakdownId = pmtBreakdownId;
	}

	public ConfigPaymentStage getConfigPaymentStage() {
		return configPaymentStage;
	}

	public void setConfigPaymentStage(ConfigPaymentStage configPaymentStage) {
		this.configPaymentStage = configPaymentStage;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public double getCharges() {
		return charges;
	}

	public void setCharges(double charges) {
		this.charges = charges;
	}

	public double getRefund() {
		return refund;
	}

	public void setRefund(double refund) {
		this.refund = refund;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Integer getBatchId() {
		return batchId;
	}

	public void setBatchId(Integer batchId) {
		this.batchId = batchId;
	}

	public String getStakeholder() {
		return stakeholder;
	}

	public void setStakeholder(String stakeholder) {
		this.stakeholder = stakeholder;
	}

	public boolean isCntryNull() {
		return isCntryNull;
	}

	public void setCntryNull(boolean isCntryNull) {
		this.isCntryNull = isCntryNull;
	}
	
}
