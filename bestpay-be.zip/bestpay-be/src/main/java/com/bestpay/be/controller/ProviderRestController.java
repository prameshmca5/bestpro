package com.bestpay.be.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwMerchantProvider;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Provider;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;


/**
 * @author Atiqah Khairuddin
 * @since March 28, 2019
 */
@RestController
@RequestMapping(BeUrlConstants.PROVIDER)
public class ProviderRestController extends AbstractRestController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());


	@PostMapping(value = BeUrlConstants.PROVIDER_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<PgwMerchantProvider> providerListPaginated(@Valid @RequestBody Provider provider,
			HttpServletRequest request) {

		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwMerchantProvider> result = pgwMerchantProviderService.searchByPagination(provider,
				dataTableInRQ);

		DataTableResults<PgwMerchantProvider> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<PgwMerchantProvider> bpLst = new ArrayList<>();
				for (PgwMerchantProvider bbp : result.getData()) {
					PgwMerchantProvider trustee = dozerMapper.map(bbp, PgwMerchantProvider.class);
					logger.info("getUpdateDt - {}", bbp.getUpdateDt());
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		return dataTableInResp;
	}


	@GetMapping(value = "/providerId/{providerId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Provider findByProviderId(@PathVariable Integer providerId) {

		PgwMerchantProvider pgwMerchantProvider = super.pgwMerchantProviderService.findByProviderId(providerId);
		Provider provider = new Provider();
		if (!BaseUtil.isObjNull(pgwMerchantProvider)) {
			provider = dozerMapper.map(pgwMerchantProvider, Provider.class);
		}
		if (BaseUtil.isEqualsCaseIgnore(pgwMerchantProvider.getCountry(), "MYS")) {
			provider.setStateMy(pgwMerchantProvider.getState());
			provider.setCityMy(pgwMerchantProvider.getCity());
		} else {
			provider.setStateNonMy(pgwMerchantProvider.getState());
			provider.setCityNonMy(pgwMerchantProvider.getCity());
		}
		return provider;
	}


	@GetMapping(value = "/channel/{channel}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Provider findProviderByChannel(@PathVariable String channel) {

		PgwMerchantProvider pgwMerchantProvider = super.pgwMerchantProviderService.findProviderByChannel(channel);

		Provider provider = new Provider();
		if (!BaseUtil.isObjNull(pgwMerchantProvider)) {
			provider = dozerMapper.map(pgwMerchantProvider, Provider.class);
		}

		return provider;
	}


	@PostMapping(value = BeUrlConstants.ADD_PROVIDER, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Provider addProvider(@Valid @RequestBody Provider provider, HttpServletRequest request) throws BeException {
		if (provider == null) {
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		PgwMerchantProvider newChannel = dozerMapper.map(provider, PgwMerchantProvider.class);
		super.pgwMerchantProviderService.update(newChannel);

		Provider prov = new Provider();
		PgwMerchantProvider pgwMerProv = super.pgwMerchantProviderService.findByProviderId(provider.getProviderId());
		if (!BaseUtil.isObjNull(pgwMerProv)) {
			prov = dozerMapper.map(pgwMerProv, Provider.class);
		}
		return prov;
	}


	@GetMapping(value = BeUrlConstants.DEL_PROVIDER + "/{provId}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public boolean deleteProvider(@PathVariable Integer provId, HttpServletRequest request) {
		try {
			if (provId == null) {
				throw new BeException(BeErrorCodeEnum.E404BLC002);
			}
			super.pgwMerchantProviderService.primaryDao().delete(super.pgwMerchantProviderService.find(provId));
			return true;
		} catch (BeException ex) {
			logger.info("{}", ex.getMessage());
		}
		return false;
	}


	// get provider ssm id
	@PostMapping(value = BeUrlConstants.GET_SSM_ID, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<Provider> getProviderSsmId(@Valid @RequestBody Provider provider, HttpServletRequest request,
			HttpServletResponse response) {
		List<Provider> providerList = new ArrayList<>();
		String ssmId = provider.getSsmId();
		List<PgwMerchantProvider> merProvider = super.pgwMerchantProviderService.findByProviderSsmId(ssmId);
		if (!BaseUtil.isListNullAndZero(merProvider)) {
			for (PgwMerchantProvider c : merProvider) {
				providerList.add(dozerMapper.map(c, Provider.class));
			}
		}
		return providerList;
	}


	// get provider public name
	@PostMapping(value = BeUrlConstants.GET_PROVIDER_PUBLIC_NAME, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public List<Provider> getProviderPublicName(@Valid @RequestBody Provider provider, HttpServletRequest request,
			HttpServletResponse response) {
		List<Provider> providerList = new ArrayList<>();
		String providerPublicName = provider.getProviderPublicName();
		List<PgwMerchantProvider> merProvider = super.pgwMerchantProviderService
				.findByProviderPublicName(providerPublicName);
		if (!BaseUtil.isListNullAndZero(merProvider)) {
			for (PgwMerchantProvider c : merProvider) {
				providerList.add(dozerMapper.map(c, Provider.class));
			}
		}
		return providerList;
	}

}
