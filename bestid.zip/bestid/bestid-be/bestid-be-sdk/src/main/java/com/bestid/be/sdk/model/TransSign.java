package com.bestid.be.sdk.model;


import java.io.Serializable;


/**
 * @author Naem Othman
 * @since 14th Feb 2019
 */

public class TransSign implements Serializable {

	private static final long serialVersionUID = 607657392585361232L;

	private String transRef;

	private Integer transType;

	private Integer applId;

	private String certRef;

	private Device deviceInfo;


	public Integer getApplId() {
		return applId;
	}


	public void setApplId(Integer applId) {
		this.applId = applId;
	}


	public String getTransRef() {
		return transRef;
	}


	public void setTransRef(String transRef) {
		this.transRef = transRef;
	}


	public Integer getTransType() {
		return transType;
	}


	public void setTransType(Integer transType) {
		this.transType = transType;
	}


	public Device getDeviceInfo() {
		return deviceInfo;
	}


	public void setDeviceInfo(Device deviceInfo) {
		this.deviceInfo = deviceInfo;
	}


	public String getCertRef() {
		return certRef;
	}


	public void setCertRef(String certRef) {
		this.certRef = certRef;
	}

}
