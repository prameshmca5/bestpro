/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.util;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public class QualifierConstants {

	private QualifierConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String SCOPE_PROTOTYPE = "prototype";

	public static final String TRANS_MANAGER = "transactionManager";

	public static final String ENTITY_MANAGER = "entityManagerFactory";

	public static final String ENTITY_MANAGER_UNIT = "emf";

	public static final String MESSAGE_SVC = "messageService";

	public static final String CONFIG_PGW_CONFIG_DAO = "pgwPayConfigDao";

	public static final String CONFIG_PGW_CONFIG_SVC = "pgwPayConfigSvc";

	public static final String REF_STATUS_DAO = "refStatusDao";

	public static final String REF_STATUS_SVC = "refStatusService";

	public static final String REF_COUNTRY_DAO = "refCountryDao";

	public static final String REF_COUNTRY_SVC = "refCountryService";

	public static final String REF_BANK_DAO = "refBankDao";

	public static final String REF_BANK_SVC = "refBankService";

	public static final String REF_DOCUMENT_DAO = "refDocumentDao";

	public static final String REF_DOCUMENT_SVC = "refDocumentSvc";

	public static final String REF_CHANNEL_SVC = "refChannelService";

	public static final String REF_CHANNEL_DAO = "refChannelDao";

	public static final String APJ_COMMON_SVC = "apjCmnSvc";

	public static final String APJ_COMMON_DAO = "apjCmnDao";

	public static final String REF_PAYMENT_TYPE_SVC = "paymentTypeSvc";

	public static final String REF_PAYMENT_TYPE_DAO = "paymentTypeDao";

	public static final String REF_STATE_SVC = "refStateSvc";

	public static final String REF_STATE_DAO = "refStateDao";

	public static final String APJ_CITY_DAO = "apjCityDao";

	public static final String APJ_CITY_SVC = "apjCitySvc";

	public static final String REF_NATIONALITY_DAO = "refNationalityDao";

	public static final String REF_NATIONALITY_SVC = "refNationalitySvc";

	public static final String REF_RELATIONSHIP_DAO = "refRelationshipDao";

	public static final String APJ_RELATIONSHIP_SVC = "apjRelationshipSvc";

	public static final String PGW_TRANSACTION_DAO = "pgwTransactionDao";

	public static final String PGW_TRANSACTION_SVC = "pgwTransactionSvc";

	public static final String PGW_TRANSACTION_QF = "pgwTransactionQf";

	public static final String PGW_SETTLEMENT_SVC = "pgwSettlementService";

	public static final String STTLMNTINFO_CUSTOM_DAO = "SettlementRptInfoCustomDao";

	public static final String PGW_SETTLEMENT_DAO = "pgwSettlementDao";

	public static final String PGW_MERBLCKLST_SVC = "pgwMerchantBlacklistService";

	public static final String PGW_MERBLCKLST_DAO = "pgwMerchantBlacklistDao";

	public static final String PGW_MER_PROFILE = "pgwMerchantProfileService";

	public static final String PGW_MER_PROFILE_DAO = "pgwMerchantProfileDao";

	public static final String PGW_MUL_CHAN_SVC = "pgwMultiChannelService";

	public static final String PGW_MUL_CHAN_DAO = "pgwMultiChannelDao";

	public static final String PGW_MER_CONTACT_SVC = "pgwMerchantContactService";

	public static final String PGW_MER_CONTACT_DAO = "pgwMerchantContactDao";

	public static final String PGW_FRAUD_SET_SVC = "pgwFraudSettingService";

	public static final String PGW_FRAUD_SET_DAO = "pgwFraudSettingDao";

	public static final String PGW_ACC_SET_SVC = "pgwAccSettingService";

	public static final String PGW_ACC_SET_DAO = "pgwAccSettingDao";

	public static final String PGW_PAY_SET_SVC = "pgwPaymentSettingService";

	public static final String PGW_PAY_SET_DAO = "pgwPaymentSettingDao";

	public static final String PGW_RESTRICTION_SVC = "pgwRestrictionService";

	public static final String PGW_RESTRICTION_DAO = "pgwRestrictionDao";

	public static final String REF_CATEGORY_SVC = "refCategoryService";

	public static final String REF_CATEGORY_DAO = "refCategoryDao";

	public static final String PGW_BUS_CAT_SVC = "pgwBusinessCategoryService";

	public static final String PGW_BUS_CAT_DAO = "pgwBusinessCategoryDao";

	public static final String PGW_RPT_SUB_SVC = "pgwReportSubscribeService";

	public static final String PGW_RPT_SUB_DAO = "pgwReportSubscribeDao";

	public static final String PGW_STTLMNT_CFG_SVC = "pgwSettlementConfigService";

	public static final String PGW_STTLMNT_CFG_DAO = "pgwSettlementConfigDao";

	public static final String PGW_PAYLK_SVC = "pgwTraceRequestPaymentService";

	public static final String PGW_PAYLK_DAO = "pgwTraceRequestPaymentCustomDao";

	public static final String REF_SUB_PLAN_DAO = "refSubscriptionPlanDao";

	public static final String REF_SUB_PLAN_SVC = "refSubscriptionPlanService";

	public static final String PGW_MERCHANT_SUBSCRIPTION_PLAN_SVC = "pgwMerchantSubscriptionService";

	public static final String PGW_MERCHANT_SUBSCRIPTION_PLAN_DAO = "pgwMerchantSubscriptionDao";

	public static final String FPX_RESPONSE_CODE_DAO = "refFpxResponseCodeDao";

	public static final String FPX_RESPONSE_CODE_SVC = "refFpxResponseCodeSvc";

	public static final String CMS_MGMT_CUSTOM_DAO = "cmsManagementCustomDao";

	public static final String PGW_TICKET_SVC = "pgwTicketService";

	public static final String PGW_TICKET_DAO = "pgwTicketDao";

	public static final String REF_SUB_PLAN_CUSTOM_DAO = "refSubscriptionPlanCustomDao";

	public static final String REF_STAT_CUSTOM_DAO = "refStatusCustomDao";

	public static final String PGW_TRXN_DOCUMENT_DAO = "pgwTrxnDocumentDao";

	public static final String PGW_TRXN_DOCUMENT_SVC = "pgwTrxnDocumentService";

	public static final String PGW_MERCHANT_COMPANY_DAO = "pgwMerchantCompanyDao";

	public static final String PGW_MERCHANT_COMPANY_SVC = "pgwMerchantCompanyService";

	public static final String PGW_MERCHANT_PID_DAO = "pgwMerchantPidDao";

	public static final String PGW_MERCHANT_PID_SVC = "pgwMerchantPidService";

	public static final String PGW_MER_PROVIDER_SVC = "pgwMerchantProviderService";

	public static final String PGW_MER_PROVIDER_DAO = "pgwMerchantProviderDao";

	public static final String PGW_MERCHANT_COMPANY_BANK_DETAILS_SVC = "pgwMerchantCompanyBankDetailsService";

	public static final String PGW_MERCHANT_COMPANY_BANK_DETAILS_DAO = "pgwMerchantCompanyBankDetailsDao";

	public static final String PGW_REFERRAL_MULTI_CHANNEL_DAO = "pgwReferralMultiChannelDao";

	public static final String PGW_REFERRAL_MULTI_CHANNEL_SVC = "pgwReferralMultiChannelService";

	public static final String PGW_MERCHANT_BENEFICIARY_SVC = "pgwMerchantBeneficiarySvc";

	public static final String PGW_MERCHANT_BENEFICIARY_DAO = "pgwMerchantBeneficiaryDao";

	public static final String PGW_CONFIG_SVC = "pgwConfigService";

	public static final String PGW_CONFIG_DAO = "pgwConfigDao";

	public static final String PGW_PYMT_SETTING_CUSTOM_DAO = "pgwPaymentSettingCustomDao";
}