/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
public enum BeAppStatusEnum {

	VERIFY("VER", 0, null, null, null),
	RETURN("RTN", 0, null, null, null),
	REJECT("REJ", 0, null, null, null),
	COMPLETE("CMP", 0, null, null, null),
	OPEN("OPN", 0, null, null, null);

	private final String status;

	private final Integer indicator;

	private final String prevFlow;

	private final String currFlow;

	private final String nextFlow;


	BeAppStatusEnum(String status, Integer indicator, String prevFlow, String currFlow, String nextFlow) {
		this.status = status;
		this.indicator = indicator;
		this.prevFlow = prevFlow;
		this.currFlow = currFlow;
		this.nextFlow = nextFlow;
	}


	public static BeAppStatusEnum findByIndicator(Integer indicator) {
		for (BeAppStatusEnum v : BeAppStatusEnum.values()) {
			if (v.getIndicator().equals(indicator)) {
				return v;
			}
		}

		return null;
	}


	public static BeAppStatusEnum findByStatus(String status) {
		for (BeAppStatusEnum v : BeAppStatusEnum.values()) {
			if (v.getStatus().equals(status)) {
				return v;
			}
		}

		return null;
	}


	public static String getStatus(String status) {
		StringBuilder sb = new StringBuilder();
		for (BeAppStatusEnum v : BeAppStatusEnum.values()) {
			if (v.getStatus().equals(status)) {
				sb.append(v.getStatus());
				break;
			}
			sb.append(v.getStatus()).append(",");
		}
		return sb.toString();
	}


	public String getStatus() {
		return status;
	}


	public Integer getIndicator() {
		return indicator;
	}


	public String getCurrFlow() {
		return currFlow;
	}


	public String getNextFlow() {
		return nextFlow;
	}


	public String getPrevFlow() {
		return prevFlow;
	}

}
