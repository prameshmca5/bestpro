/**
 * 
 */
package com.be.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeAirlinesPicRepository;
import com.be.model.BeAirlinesPic;
import com.be.model.BeAirlinesProfile;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_AIRLINES_PIC_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_AIRLINES_PIC_SVC)
public class BeAirlinesPicService extends AbstractService<BeAirlinesPic> {

	@Autowired
	BeAirlinesPicRepository beAirlinesPicDao;
	
	@Override
	public GenericRepository<BeAirlinesPic> primaryDao() {
		return beAirlinesPicDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public List<BeAirlinesPic> createUpdate(Set<BeAirlinesPic> set, BeAirlinesProfile airlinesProfile, String userId){
		
		List<BeAirlinesPic> beAirlinesPics = new ArrayList<>();
		set.stream().forEach(beAirlinesPic -> {
			if(BaseUtil.isObjNull(beAirlinesPic.getAirlinesPicId())) {
				beAirlinesPic.setCreateId(userId);
				beAirlinesPic.setAirlinesProfile(airlinesProfile);
			}else {
				BeAirlinesPic beAirlinesPicOri = find(beAirlinesPic.getAirlinesPicId());
				beAirlinesPic.setAirlinesProfile(beAirlinesPicOri.getAirlinesProfile());
				beAirlinesPic.setCreateId(beAirlinesPicOri.getCreateId());
				beAirlinesPic.setCreateDt(beAirlinesPicOri.getCreateDt());
			}
			beAirlinesPic.setUpdateId(userId);
			beAirlinesPics.add(beAirlinesPic);
		});	
		return beAirlinesPicDao.save(beAirlinesPics);
	}

}
