package com.be.sdk.model;


import java.io.Serializable;


public class PaymentBreakdown implements Serializable, IQfCriteria<PaymentBreakdown> {

	/**
	 *
	 */
	private static final long serialVersionUID = 4963273744808727847L;

	private Integer pmtBreakdownId;

	private Integer batchId;

	private Integer pmtBreakdownMtDtId;

	private String currency;

	private Double amount;

	private String breakdownDesc;

	private Boolean status;

	private Boolean isDetail;


	public Integer getPmtBreakdownId() {
		return pmtBreakdownId;
	}


	public void setPmtBreakdownId(Integer pmtBreakdownId) {
		this.pmtBreakdownId = pmtBreakdownId;
	}


	public Integer getBatchId() {
		return batchId;
	}


	public void setBatchId(Integer batchId) {
		this.batchId = batchId;
	}


	public Integer getPmtBreakdownMtDtId() {
		return pmtBreakdownMtDtId;
	}


	public void setPmtBreakdownMtDtId(Integer pmtBreakdownMtDtId) {
		this.pmtBreakdownMtDtId = pmtBreakdownMtDtId;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public String getBreakdownDesc() {
		return breakdownDesc;
	}


	public void setBreakdownDesc(String breakdownDesc) {
		this.breakdownDesc = breakdownDesc;
	}


	public Boolean getStatus() {
		return status;
	}


	public void setStatus(Boolean status) {
		this.status = status;
	}


	public Boolean getIsDetail() {
		return isDetail;
	}


	public void setIsDetail(Boolean isDetail) {
		this.isDetail = isDetail;
	}

}
