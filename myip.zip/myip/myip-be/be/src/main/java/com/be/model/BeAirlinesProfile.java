/**
 * 
 */
package com.be.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_AIRLINES_PROFILE")
public class BeAirlinesProfile extends AbstractEntity implements Serializable, IQfCriteria<BeAirlinesProfile> {

	private static final long serialVersionUID = -8772288413629786320L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="AIRLINES_PROF_ID")
	private Integer airlinesProfId;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "AIRLINES_TYPE_MTDT_ID")
	private RefMetadata airlinesTypeMtdt;
	 
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FLIGHT_COVERAGE_MTDT_ID")
	private RefMetadata flightCoverageMtdt;
		
	@Column(name = "IATA_REG_NO")
	private String iataRegNo;
	
	@Column(name = "ICAO_REG_NO")
	private String icaoRegNo;
	
	@Column(name = "AIRLINES_NAME")
	private String airlinesName;
	
	@Column(name = "CALLSIGN")
	private String callSign;
	
	@Column(name = "CONTACT_NO")
	private String contactNo;
	
	@Column(name = "CONTACT_NO_2")
	private String contactNo2;
	
	@Column(name = "FAX_NO")
	private String faxNo;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "WEBSITE")
	private String website;
	
	@Column(name = "YEAR_COMMENCED_OPS")
	private String yearCommencedOps;
	
	@Column(name = "DOC_REF_NO")
	private String docRefNo;
	
	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;
	
	@JsonIgnoreProperties("airlinesProfile")
	@OneToMany(mappedBy = "airlinesProfile", fetch = FetchType.LAZY)
	private Set<BeAirlinesContact> airlinesContacts;
	
	@JsonIgnoreProperties("airlinesProfile")
	@OneToMany(mappedBy = "airlinesProfile", fetch = FetchType.LAZY)
	private Set<BeAirlinesPic> airlinesPics;
	
	@JsonIgnoreProperties("airlinesProfile")
	@OneToMany(mappedBy = "airlinesProfile", fetch = FetchType.LAZY)
	private Set<BeAirlinesAddress> airlinesAddresses;

	public Integer getAirlinesProfId() {
		return airlinesProfId;
	}

	public void setAirlinesProfId(Integer airlinesProfId) {
		this.airlinesProfId = airlinesProfId;
	}

	public RefMetadata getAirlinesTypeMtdt() {
		return airlinesTypeMtdt;
	}

	public void setAirlinesTypeMtdt(RefMetadata airlinesTypeMtdt) {
		this.airlinesTypeMtdt = airlinesTypeMtdt;
	}

	public RefMetadata getFlightCoverageMtdt() {
		return flightCoverageMtdt;
	}

	public void setFlightCoverageMtdt(RefMetadata flightCoverageMtdt) {
		this.flightCoverageMtdt = flightCoverageMtdt;
	}

	public String getIataRegNo() {
		return iataRegNo;
	}

	public void setIataRegNo(String iataRegNo) {
		this.iataRegNo = iataRegNo;
	}

	public String getIcaoRegNo() {
		return icaoRegNo;
	}

	public void setIcaoRegNo(String icaoRegNo) {
		this.icaoRegNo = icaoRegNo;
	}

	public String getAirlinesName() {
		return airlinesName;
	}

	public void setAirlinesName(String airlinesName) {
		this.airlinesName = airlinesName;
	}

	public String getCallSign() {
		return callSign;
	}

	public void setCallSign(String callSign) {
		this.callSign = callSign;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getContactNo2() {
		return contactNo2;
	}

	public void setContactNo2(String contactNo2) {
		this.contactNo2 = contactNo2;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getYearCommencedOps() {
		return yearCommencedOps;
	}

	public void setYearCommencedOps(String yearCommencedOps) {
		this.yearCommencedOps = yearCommencedOps;
	}

	public String getDocRefNo() {
		return docRefNo;
	}

	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public Set<BeAirlinesContact> getAirlinesContacts() {
		return airlinesContacts;
	}

	public void setAirlinesContacts(Set<BeAirlinesContact> airlinesContacts) {
		this.airlinesContacts = airlinesContacts;
	}

	public Set<BeAirlinesPic> getAirlinesPics() {
		return airlinesPics;
	}

	public void setAirlinesPics(Set<BeAirlinesPic> airlinesPics) {
		this.airlinesPics = airlinesPics;
	}

	public Set<BeAirlinesAddress> getAirlinesAddresses() {
		return airlinesAddresses;
	}

	public void setAirlinesAddresses(Set<BeAirlinesAddress> airlinesAddresses) {
		this.airlinesAddresses = airlinesAddresses;
	}
	
}
