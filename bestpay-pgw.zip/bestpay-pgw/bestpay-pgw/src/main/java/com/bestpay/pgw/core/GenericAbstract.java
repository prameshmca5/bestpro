/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.core;


import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.util.StringUtils;

import com.bestpay.dm.sdk.client.DmServiceClient;
import com.bestpay.idm.sdk.client.IdmServiceClient;
import com.bestpay.pgw.config.ConfigConstants;
import com.bestpay.pgw.service.MessageService;
import com.bestpay.pgw.util.ProjectEnum;
import com.bestpay.pgw.util.QualifierConstants;
import com.bstsb.util.UidGenerator;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public abstract class GenericAbstract {

	public static final String HEADER_MESSAGE_ID = "X-Message-Id";

	public static final String HEADER_AUTHORIZATION = "Authorization";

	@Autowired
	@Qualifier(QualifierConstants.MESSAGE_SVC)
	protected MessageService messageService;

	@Autowired
	protected MessageSource messageSource;

	@Autowired
	private IdmServiceClient idmService;

	@Autowired
	private DmServiceClient dmService;


	protected IdmServiceClient getIdmService(HttpServletRequest request) {
		idmService.setAuthToken(request.getHeader(HEADER_AUTHORIZATION));
		idmService.setMessageId(
				StringUtils.hasText(request.getHeader(HEADER_MESSAGE_ID)) ? request.getHeader(HEADER_MESSAGE_ID)
						: String.valueOf(UUID.randomUUID()));
		return idmService;
	}


	public DmServiceClient getDmService(ProjectEnum project) {
		if (project != null) {
			dmService.setProjId(project.getName());
		}
		dmService.setToken(messageService.getMessage(ConfigConstants.SVC_IDM_SKEY));
		dmService.setClientId(messageService.getMessage(ConfigConstants.SVC_IDM_CLIENT));
		dmService.setMessageId(UidGenerator.getMessageId());
		return dmService;
	}

}