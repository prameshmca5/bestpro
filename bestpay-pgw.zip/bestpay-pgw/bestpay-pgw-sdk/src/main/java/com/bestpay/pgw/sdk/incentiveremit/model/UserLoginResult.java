package com.bestpay.pgw.sdk.incentiveremit.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "userLoginResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserLoginResult {

	@XmlElement(name = "CODE")
	private String code;

	@XmlElement(name = "STATUS")
	private String status;

	@XmlElement(name = "MESSAGE")
	private String message;

	@XmlElement(name = "USER_CCY")
	private String userCcy;

	@XmlElement(name = "USER_COUNTRY")
	private String userCountry;


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public String getUserCcy() {
		return userCcy;
	}


	public void setUserCcy(String userCcy) {
		this.userCcy = userCcy;
	}


	public String getUserCountry() {
		return userCountry;
	}


	public void setUserCountry(String userCountry) {
		this.userCountry = userCountry;
	}

}
