/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * @author nurul.naimma
 *
 * @since Jul 13, 2021
 */
public class FacesDto implements Serializable {

	private static final long serialVersionUID = 2199566622833074848L;

	private int x;

	private int y;

	private int w;

	private int h;

	@JsonProperty("image-id")
	private int imageId;


	/**
	 * @return the x
	 */
	public int getX() {
		return x;
	}


	/**
	 * @param x
	 *             the x to set
	 */
	public void setX(int x) {
		this.x = x;
	}


	/**
	 * @return the y
	 */
	public int getY() {
		return y;
	}


	/**
	 * @param y
	 *             the y to set
	 */
	public void setY(int y) {
		this.y = y;
	}


	/**
	 * @return the w
	 */
	public int getW() {
		return w;
	}


	/**
	 * @param w
	 *             the w to set
	 */
	public void setW(int w) {
		this.w = w;
	}


	/**
	 * @return the h
	 */
	public int getH() {
		return h;
	}


	/**
	 * @param h
	 *             the h to set
	 */
	public void setH(int h) {
		this.h = h;
	}


	/**
	 * @return the imageId
	 */
	public int getImageId() {
		return imageId;
	}


	/**
	 * @param imageId
	 *             the imageId to set
	 */
	public void setImageId(int imageId) {
		this.imageId = imageId;
	}

}
