/**
 * 
 */
package com.be.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.RefDun;

/**
 * @author Ramesh Pongiannan
 *
 */
@Lazy
@Repository
@RepositoryDefinition(domainClass = RefDun.class, idClass = Integer.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_DUN_DAO)
public interface RefDunRepository extends GenericRepository<RefDun> {

	@Query("select u from RefDun u ")
	public List<RefDun> findAll();

	@Query("select u from RefDun u where u.dunCd = :dunCd ")
	public RefDun findByDunCd(@Param("dunCd") String dunCd);
}
