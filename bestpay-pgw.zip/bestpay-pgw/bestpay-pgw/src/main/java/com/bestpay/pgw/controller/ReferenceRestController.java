/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwConfig;
import com.bestpay.pgw.model.RefBank;
import com.bestpay.pgw.model.RefFpxResponseCode;
import com.bestpay.pgw.sdk.constants.PgwCacheConstants;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.model.RefBankFpx;
import com.bestpay.pgw.sdk.model.StaticList;
import com.bestpay.pgw.sdk.model.Status;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.pgw.service.RefChannelService;
import com.bestpay.pgw.service.RefConfigService;
import com.bestpay.pgw.service.RefFpxBestpayCodeService;
import com.bestpay.pgw.service.RefFpxResponseCodeService;

/**
 * @author Mary Jane Buenaventura
 * @since Nov 3, 2016
 */
@RestController
@RequestMapping(PgwUrlConstants.REFERENCE)
public class ReferenceRestController extends AbstractRestController {

	@Autowired
	private RefConfigService apjConfigSvc;

	@Autowired
	private RefFpxResponseCodeService fpxResponseCodeSvc;

	@Autowired
	private RefChannelService refChannelSvc;

	@Autowired
	private RefFpxBestpayCodeService fpxBestpayCodeSvc;

	@SuppressWarnings("unchecked")
	@GetMapping(consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public StaticList staticList(HttpServletRequest request) {

		StaticList cmnStatList = new StaticList();
		cmnStatList.setStatusList(((List<Status>) findAll(PgwCacheConstants.REF_TYP_STATUS, request, null)));

		return cmnStatList;
	}

	@GetMapping(value = PgwUrlConstants.APJ_CONFIG, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public Map<String, String> sstConfig(HttpServletRequest request) {
		List<PgwConfig> confLst = apjConfigSvc.primaryDao().findAll();
		Map<String, String> config = new HashMap<>();
		if (!confLst.isEmpty()) {
			for (PgwConfig conf : confLst) {
				config.put(conf.getConfigCode(), conf.getConfigVal());
			}
		}
		return config;
	}

	@GetMapping(value = PgwUrlConstants.APJ_CONFIG + "/{configCode}", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwConfig findConfig(@PathVariable String configCode, HttpServletRequest request) {
		return apjConfigSvc.findByConfigCode(configCode);
	}

	@GetMapping(value = "/{refType}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<?> findAll(@PathVariable("refType") String refType, HttpServletRequest request,
			@RequestParam Map<String, String> requestParams) {
		if (BaseUtil.isEqualsCaseIgnore(PgwCacheConstants.REF_TYP_FPX_RES_CODE, refType)) {
			return fpxResponseCodeSvc.findAll();
		}
		return Collections.emptyList();
	}
	
	@GetMapping(value = PgwUrlConstants.REF_TYPE_FPX_RES_DESC, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<RefFpxResponseCode> findRespdsDesc(@RequestParam(value = "fpxDesc") String fpxDesc, HttpServletRequest request) {
		List<RefFpxResponseCode> resList = new ArrayList<>();
		List<RefFpxResponseCode> fpxDescription = fpxResponseCodeSvc.findByFpxDesc(fpxDesc);
		for (RefFpxResponseCode cnt : fpxDescription) {
			resList.add(dozerMapper.map(cnt, RefFpxResponseCode.class));
		}
		return resList;
	}
	
 	@GetMapping(value = "/{refType}/{refCode}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public Object find(@PathVariable("refType") String refType, @PathVariable("refCode") String refCode,
			HttpServletRequest request) {

		if (BaseUtil.isEqualsCaseIgnore(PgwUrlConstants.REF_TYPE_FPX_RES_CODE, refType)) {
			return fpxResponseCodeSvc.findByFpxCode(refCode);
		}
		 
		if (BaseUtil.isEqualsCaseIgnore(PgwUrlConstants.REF_TYPE_CHANNEL_LIST, refType)) {
			return refChannelSvc.findRefChannelByPublicName(refCode);
		}
		if (BaseUtil.isEqualsCaseIgnore(PgwUrlConstants.REF_TYPE_FPX_BESTPAY_CODE, refType)) {
			return fpxBestpayCodeSvc.findBestpayCodeDescr(refCode);

		}
		return null;
	}

}