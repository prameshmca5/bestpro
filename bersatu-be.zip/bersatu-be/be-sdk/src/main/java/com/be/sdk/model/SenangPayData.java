/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author Ramesh Pongiannan
 *
 * @since Dec 15, 2021
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class SenangPayData implements Serializable {
 
	private static final long serialVersionUID = -455233434333049024L;
	
	private SenangPayPaymentInfo payment_info;

	public SenangPayPaymentInfo getPayment_info() {
		return payment_info;
	}

	public void setPayment_info(SenangPayPaymentInfo payment_info) {
		this.payment_info = payment_info;
	}
	 
}
