/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.constants;


/**
 * @author mukhlis.hamzah
 * @since Feb 25, 2019
 */
public enum ProjectEnum {

	BESTID("bestid", "RA"),

	;

	private final String name;

	private final String prefix;


	ProjectEnum(String name, String prefix) {
		this.name = name;
		this.prefix = prefix;
	}


	public String getName() {
		return name;
	}


	public String getPrefix() {
		return prefix;
	}


	public static ProjectEnum findByName(String name) {
		for (ProjectEnum v : ProjectEnum.values()) {
			if (v.getName().equals(name)) {
				return v;
			}
		}
		return null;
	}

}
