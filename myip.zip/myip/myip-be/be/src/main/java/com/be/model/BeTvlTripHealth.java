/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_TVL_TRIP_HEALTH")
public class BeTvlTripHealth extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = 7312582942402181842L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TVL_TRIP_HEALTH_ID")
	private Integer tvlTripHealthId;

	@JsonIgnoreProperties("tripHealths")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TVL_TRIP_ID")
	private BeTvlTrip tvlTrip;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "TRIP_HEALTH_ID")
	private BeConfigTripHealth configTripHealth;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "RESULT_MTDT_ID")
	private RefMetadata resultMtdt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;


	public Integer getTvlTripHealthId() {
		return tvlTripHealthId;
	}


	public void setTvlTripHealthId(Integer tvlTripHealthId) {
		this.tvlTripHealthId = tvlTripHealthId;
	}


	public BeTvlTrip getTvlTrip() {
		return tvlTrip;
	}


	public void setTvlTrip(BeTvlTrip tvlTrip) {
		this.tvlTrip = tvlTrip;
	}


	public BeConfigTripHealth getConfigTripHealth() {
		return configTripHealth;
	}


	public void setConfigTripHealth(BeConfigTripHealth configTripHealth) {
		this.configTripHealth = configTripHealth;
	}


	public RefMetadata getResultMtdt() {
		return resultMtdt;
	}


	public void setResultMtdt(RefMetadata resultMtdt) {
		this.resultMtdt = resultMtdt;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
