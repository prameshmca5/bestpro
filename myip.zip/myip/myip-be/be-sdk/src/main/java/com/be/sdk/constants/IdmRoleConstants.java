/**
 * Copyright 2019
 */
package com.be.sdk.constants;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * @author nurul.naimma
 *
 * @since 19 Nov 2018
 */
public class IdmRoleConstants {

	private IdmRoleConstants() {
		throw new IllegalStateException("IdmRoleConstants class");
	}


	public static final String SYSTEM_ADMIN = "SYSTEM";

	public static final String JIM_ADMIN = "JIM_ADMIN";
	
	public static final String DQ_ADMIN = "DQ_ADMIN";

	public static final String DQ_USER = "DQ_USER";
	
	public static final String AIRLINE_ADMIN = "AIRLINE_ADMIN";
	
	public static final String CORP_COMM_ADMIN = "CORP_COMM_ADMIN";
	
	public static final String FINANCE_ADMIN = "FINANCE_ADMIN";
	
	public static final String INSURANCE_ADMIN = "INSURANCE_ADMIN";
	
	public static final String MC_ADMIN = "MC_ADMIN";
	
	public static final String MOH_ADMIN = "MOH_ADMIN";


	public static final List<String> ADMIN_ROLES;
	
	static {
		final List<String> list = new ArrayList<>();
		list.add(SYSTEM_ADMIN);
		list.add(JIM_ADMIN);
		list.add(DQ_ADMIN);		
		list.add(AIRLINE_ADMIN);
		list.add(CORP_COMM_ADMIN);
		list.add(FINANCE_ADMIN);
		list.add(INSURANCE_ADMIN);
		list.add(MC_ADMIN);
		list.add(MOH_ADMIN);
		list.add(CORP_COMM_ADMIN);
		ADMIN_ROLES = Collections.unmodifiableList(list);
	}

}
