/**
 *
 */
package com.be.sdk.builder;


import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.Config;
import com.be.sdk.model.ConfigPaymentStage;
import com.be.sdk.model.Payment;
import com.be.sdk.model.PaymentBreakdown;
import com.be.sdk.model.PaymentDtl;
import com.be.sdk.model.PreReg;
import com.be.sdk.model.SenangPayResponds;
import com.util.pagination.DataTableResults;


/**
 * @author mohd.naem
 *
 */
public class PaymentService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public PaymentService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<Payment> searchPaginated(Payment dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}


	// use to search for unique column only, or else return latest data in db
	public Payment searchPayment(Payment dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.SEARCH);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Payment.class);
	}


	public Payment prePayment(Payment dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.CREATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Payment.class);
	}


	public Payment createPaymentPublic(Payment dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.CREATE);
		sb.append(BeUrlConstants.PUBLIC);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Payment.class);
	}


	public List<PaymentBreakdown> searchPaymentBreakdown(PaymentBreakdown dto) {
		List<PaymentBreakdown> paymentBreakdownList = null;
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.BREAKDOWN);
		PaymentBreakdown[] array = restTemplate().postForObject(getServiceURI(sb.toString()), dto,
				PaymentBreakdown[].class);
		if (array != null && array.length > 0) {
			paymentBreakdownList = Arrays.asList(array);
		}
		return paymentBreakdownList;
	}


	public Payment postPayment(Payment dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.POST_PAYMENT);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Payment.class);
	}


	public ConfigPaymentStage updatePayment(Payment dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.UPDATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, ConfigPaymentStage.class);
	}


	public List<PaymentDtl> getPaymentDtlReceipt(Payment dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.GET_DETAIL);
		sb.append(BeUrlConstants.RECEIPT);
		PaymentDtl[] paymentDtlArray = restTemplate().postForObject(getServiceURI(sb.toString()), dto,
				PaymentDtl[].class);
		return Arrays.asList(paymentDtlArray);
	}


	public Config getBeConfigvalue(Config dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append("/getbeConfValue");
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Config.class);
	}


	public PaymentDtl getPaymentDetail(PaymentDtl dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.GET_DETAIL);
		sb.append(BeUrlConstants.PMT_DTL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, PaymentDtl.class);
	}


	public Payment findPaymentDetailByPreRegId(PreReg dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.FIND_BE_PAYMENT_DTL_BY_PRE_REG_ID);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Payment.class);
	}
	
	public SenangPayResponds findSenengpayEnquiryStatus(Payment dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.GET_SENENGPAY_ENQUIRY_STATUS);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, SenangPayResponds.class);
	}
	
	

}