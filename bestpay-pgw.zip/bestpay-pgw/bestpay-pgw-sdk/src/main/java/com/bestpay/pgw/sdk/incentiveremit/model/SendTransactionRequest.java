package com.bestpay.pgw.sdk.incentiveremit.model;


public class SendTransactionRequest {

	private String agentTxnId;

	private String payoutPartnerId;

	private String locationId;

	private String senderId;

	private String senderFirstName;

	private String senderMiddleName;

	private String senderLastName;

	private String senderGender;

	private String senderAddress;

	private String senderCity;

	private String senderStates;

	private String senderZipCode;

	private String senderCountry;

	private String senderMobile;

	private String senderNationality;

	private String senderIdType;

	private String senderIdNumber;

	private String senderIdIssueCountry;

	private String senderIdIssueDate;

	private String senderIdExpireDate;

	private String senderDateOfBirth;

	private String senderOccupation;

	private String senderSourceOfFund;

	private String senderSecondaryIdType;

	private String senderSecondaryIdNumber;

	private String senderBeneficiaryRelationship;

	private String purposeOfRemittance;

	private String receiverSno;

	private String receiverFirstName;

	private String receiverMiddleName;

	private String receiverLastName;

	private String receiverAddress;

	private String receiverContactNumber;

	private String receiverCity;

	private String receiverCountry;

	private String receiverIdType;

	private String receiverIdNumber;

	private String calcBy;

	private String transferAmount;

	private String transferCurrency;

	private String paymentMode;

	private String bankId;

	private String bankName;

	private String bankBranchId;

	private String bankBranchName;

	private String bankAccountNumber;

	private String promotionCode;


	public String getAgentTxnId() {
		return agentTxnId;
	}


	public void setAgentTxnId(String agentTxnId) {
		this.agentTxnId = agentTxnId;
	}


	public String getPayoutPartnerId() {
		return payoutPartnerId;
	}


	public void setPayoutPartnerId(String payoutPartnerId) {
		this.payoutPartnerId = payoutPartnerId;
	}


	public String getLocationId() {
		return locationId;
	}


	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}


	public String getSenderId() {
		return senderId;
	}


	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}


	public String getSenderFirstName() {
		return senderFirstName;
	}


	public void setSenderFirstName(String senderFirstName) {
		this.senderFirstName = senderFirstName;
	}


	public String getSenderMiddleName() {
		return senderMiddleName;
	}


	public void setSenderMiddleName(String senderMiddleName) {
		this.senderMiddleName = senderMiddleName;
	}


	public String getSenderLastName() {
		return senderLastName;
	}


	public void setSenderLastName(String senderLastName) {
		this.senderLastName = senderLastName;
	}


	public String getSenderGender() {
		return senderGender;
	}


	public void setSenderGender(String senderGender) {
		this.senderGender = senderGender;
	}


	public String getSenderAddress() {
		return senderAddress;
	}


	public void setSenderAddress(String senderAddress) {
		this.senderAddress = senderAddress;
	}


	public String getSenderCity() {
		return senderCity;
	}


	public void setSenderCity(String senderCity) {
		this.senderCity = senderCity;
	}


	public String getSenderStates() {
		return senderStates;
	}


	public void setSenderStates(String senderStates) {
		this.senderStates = senderStates;
	}


	public String getSenderZipCode() {
		return senderZipCode;
	}


	public void setSenderZipCode(String senderZipCode) {
		this.senderZipCode = senderZipCode;
	}


	public String getSenderCountry() {
		return senderCountry;
	}


	public void setSenderCountry(String senderCountry) {
		this.senderCountry = senderCountry;
	}


	public String getSenderMobile() {
		return senderMobile;
	}


	public void setSenderMobile(String senderMobile) {
		this.senderMobile = senderMobile;
	}


	public String getSenderNationality() {
		return senderNationality;
	}


	public void setSenderNationality(String senderNationality) {
		this.senderNationality = senderNationality;
	}


	public String getSenderIdType() {
		return senderIdType;
	}


	public void setSenderIdType(String senderIdType) {
		this.senderIdType = senderIdType;
	}


	public String getSenderIdNumber() {
		return senderIdNumber;
	}


	public void setSenderIdNumber(String senderIdNumber) {
		this.senderIdNumber = senderIdNumber;
	}


	public String getSenderIdIssueCountry() {
		return senderIdIssueCountry;
	}


	public void setSenderIdIssueCountry(String senderIdIssueCountry) {
		this.senderIdIssueCountry = senderIdIssueCountry;
	}


	public String getSenderIdIssueDate() {
		return senderIdIssueDate;
	}


	public void setSenderIdIssueDate(String senderIdIssueDate) {
		this.senderIdIssueDate = senderIdIssueDate;
	}


	public String getSenderIdExpireDate() {
		return senderIdExpireDate;
	}


	public void setSenderIdExpireDate(String senderIdExpireDate) {
		this.senderIdExpireDate = senderIdExpireDate;
	}


	public String getSenderDateOfBirth() {
		return senderDateOfBirth;
	}


	public void setSenderDateOfBirth(String senderDateOfBirth) {
		this.senderDateOfBirth = senderDateOfBirth;
	}


	public String getSenderOccupation() {
		return senderOccupation;
	}


	public void setSenderOccupation(String senderOccupation) {
		this.senderOccupation = senderOccupation;
	}


	public String getSenderSourceOfFund() {
		return senderSourceOfFund;
	}


	public void setSenderSourceOfFund(String senderSourceOfFund) {
		this.senderSourceOfFund = senderSourceOfFund;
	}


	public String getSenderSecondaryIdType() {
		return senderSecondaryIdType;
	}


	public void setSenderSecondaryIdType(String senderSecondaryIdType) {
		this.senderSecondaryIdType = senderSecondaryIdType;
	}


	public String getSenderSecondaryIdNumber() {
		return senderSecondaryIdNumber;
	}


	public void setSenderSecondaryIdNumber(String senderSecondaryIdNumber) {
		this.senderSecondaryIdNumber = senderSecondaryIdNumber;
	}


	public String getSenderBeneficiaryRelationship() {
		return senderBeneficiaryRelationship;
	}


	public void setSenderBeneficiaryRelationship(String senderBeneficiaryRelationship) {
		this.senderBeneficiaryRelationship = senderBeneficiaryRelationship;
	}


	public String getPurposeOfRemittance() {
		return purposeOfRemittance;
	}


	public void setPurposeOfRemittance(String purposeOfRemittance) {
		this.purposeOfRemittance = purposeOfRemittance;
	}


	public String getReceiverSno() {
		return receiverSno;
	}


	public void setReceiverSno(String receiverSno) {
		this.receiverSno = receiverSno;
	}


	public String getReceiverFirstName() {
		return receiverFirstName;
	}


	public void setReceiverFirstName(String receiverFirstName) {
		this.receiverFirstName = receiverFirstName;
	}


	public String getReceiverMiddleName() {
		return receiverMiddleName;
	}


	public void setReceiverMiddleName(String receiverMiddleName) {
		this.receiverMiddleName = receiverMiddleName;
	}


	public String getReceiverLastName() {
		return receiverLastName;
	}


	public void setReceiverLastName(String receiverLastName) {
		this.receiverLastName = receiverLastName;
	}


	public String getReceiverAddress() {
		return receiverAddress;
	}


	public void setReceiverAddress(String receiverAddress) {
		this.receiverAddress = receiverAddress;
	}


	public String getReceiverContactNumber() {
		return receiverContactNumber;
	}


	public void setReceiverContactNumber(String receiverContactNumber) {
		this.receiverContactNumber = receiverContactNumber;
	}


	public String getReceiverCity() {
		return receiverCity;
	}


	public void setReceiverCity(String receiverCity) {
		this.receiverCity = receiverCity;
	}


	public String getReceiverCountry() {
		return receiverCountry;
	}


	public void setReceiverCountry(String receiverCountry) {
		this.receiverCountry = receiverCountry;
	}


	public String getReceiverIdType() {
		return receiverIdType;
	}


	public void setReceiverIdType(String receiverIdType) {
		this.receiverIdType = receiverIdType;
	}


	public String getReceiverIdNumber() {
		return receiverIdNumber;
	}


	public void setReceiverIdNumber(String receiverIdNumber) {
		this.receiverIdNumber = receiverIdNumber;
	}


	public String getCalcBy() {
		return calcBy;
	}


	public void setCalcBy(String calcBy) {
		this.calcBy = calcBy;
	}


	public String getTransferAmount() {
		return transferAmount;
	}


	public void setTransferAmount(String transferAmount) {
		this.transferAmount = transferAmount;
	}


	public String getTransferCurrency() {
		return transferCurrency;
	}


	public void setTransferCurrency(String transferCurrency) {
		this.transferCurrency = transferCurrency;
	}


	public String getPaymentMode() {
		return paymentMode;
	}


	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}


	public String getBankId() {
		return bankId;
	}


	public void setBankId(String bankId) {
		this.bankId = bankId;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getBankBranchId() {
		return bankBranchId;
	}


	public void setBankBranchId(String bankBranchId) {
		this.bankBranchId = bankBranchId;
	}


	public String getBankBranchName() {
		return bankBranchName;
	}


	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}


	public String getBankAccountNumber() {
		return bankAccountNumber;
	}


	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}


	public String getPromotionCode() {
		return promotionCode;
	}


	public void setPromotionCode(String promotionCode) {
		this.promotionCode = promotionCode;
	}

}
