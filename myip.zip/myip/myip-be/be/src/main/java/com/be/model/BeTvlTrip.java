/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_TVL_TRIP")
public class BeTvlTrip extends AbstractEntity implements Serializable, IQfCriteria<BeTvlTrip> {

	private static final long serialVersionUID = -1467770470939044493L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TVL_TRIP_ID")
	private Integer tvlTripId;

	@Column(name = "TVL_TRIP_CODE_NO")
	private String tvlTripCodeNo;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TVL_PROF_ID")
	private BeTvlProfile tvlProfile;

	@Column(name = "TVL_MODE")
	private String tvlMode;

	@Column(name = "FLIGHT_NO")
	private String flightNo;

	@Column(name = "AIRLINES")
	private String airlines;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DEPARTURE_FROM")
	private RefIntAirport departureAirport;

	@Temporal(TemporalType.DATE)
	@Column(name = "DEPARTURE_DT")
	private Date departureDt;

	@Column(name = "DEPARTURE_TIME")
	private String departureTime;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ARRIVAL_TO")
	private RefIntAirport arrivalAirport;

	@Temporal(TemporalType.DATE)
	@Column(name = "ARRIVAL_DT")
	private Date arrivalDt;

	@Column(name = "ARRIVAL_TIME")
	private String arrivalTime;

	@Column(name = "TVL_PURPOSE")
	private String tvlPurpose;

	@Column(name = "STAY_DURATION")
	private String stayDuration;

	@Column(name = "STAY_ADDRESS")
	private String stayAddress;

	@Column(name = "DOC_REF_NO")
	private String docRefNo;

	@Temporal(TemporalType.DATE)
	@Column(name = "SUBMIT_DT")
	private Date submitDt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@JsonIgnoreProperties("tvlTrip")
	@OneToMany(mappedBy = "tvlTrip", fetch = FetchType.LAZY)
	private Set<BeTvlTripHealth> tripHealths;

	@JsonIgnoreProperties("tvlTrip")
	@OneToMany(mappedBy = "tvlTrip", fetch = FetchType.LAZY)
	private Set<BeTripAccommodation> tripAccommodations;

	@JsonIgnoreProperties({ "tvlTrip", "tvlProfile" })
	@OneToMany(mappedBy = "tvlTrip", fetch = FetchType.LAZY)
	private Set<BeTvl> tvls;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "TRIP_PLAN_MTDT_ID")
	private RefMetadata tripPlanMtdt;

	@Column(name = "TVL_MODE_RTN")
	private String tvlModeRtn;

	@Column(name = "FLIGHT_NO_RTN")
	private String flightNoRtn;

	@Column(name = "AIRLINES_RTN")
	private String airlinesRtn;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DEPARTURE_FROM_RTN")
	private RefIntAirport departureAirportRtn;

	@Temporal(TemporalType.DATE)
	@Column(name = "DEPARTURE_DT_RTN")
	private Date departureDtRtn;

	@Column(name = "DEPARTURE_TIME_RTN")
	private String departureTimeRtn;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ARRIVAL_TO_RTN")
	private RefIntAirport arrivalAirportRtn;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "APPS_MTDT_ID")
	private RefMetadata appsMtdt;


	public Integer getTvlTripId() {
		return tvlTripId;
	}


	public void setTvlTripId(Integer tvlTripId) {
		this.tvlTripId = tvlTripId;
	}


	public String getTvlTripCodeNo() {
		return tvlTripCodeNo;
	}


	public void setTvlTripCodeNo(String tvlTripCodeNo) {
		this.tvlTripCodeNo = tvlTripCodeNo;
	}


	public BeTvlProfile getTvlProfile() {
		return tvlProfile;
	}


	public void setTvlProfile(BeTvlProfile tvlProfile) {
		this.tvlProfile = tvlProfile;
	}


	public String getTvlMode() {
		return tvlMode;
	}


	public void setTvlMode(String tvlMode) {
		this.tvlMode = tvlMode;
	}


	public String getFlightNo() {
		return flightNo;
	}


	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}


	public String getAirlines() {
		return airlines;
	}


	public void setAirlines(String airlines) {
		this.airlines = airlines;
	}


	public Date getDepartureDt() {
		return departureDt;
	}


	public void setDepartureDt(Date departureDt) {
		this.departureDt = departureDt;
	}


	public String getDepartureTime() {
		return departureTime;
	}


	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}


	public Date getArrivalDt() {
		return arrivalDt;
	}


	public void setArrivalDt(Date arrivalDt) {
		this.arrivalDt = arrivalDt;
	}


	public String getArrivalTime() {
		return arrivalTime;
	}


	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}


	public String getTvlPurpose() {
		return tvlPurpose;
	}


	public void setTvlPurpose(String tvlPurpose) {
		this.tvlPurpose = tvlPurpose;
	}


	public String getStayDuration() {
		return stayDuration;
	}


	public void setStayDuration(String stayDuration) {
		this.stayDuration = stayDuration;
	}


	public String getStayAddress() {
		return stayAddress;
	}


	public void setStayAddress(String stayAddress) {
		this.stayAddress = stayAddress;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Set<BeTvlTripHealth> getTripHealths() {
		return tripHealths;
	}


	public void setTripHealths(Set<BeTvlTripHealth> tripHealths) {
		this.tripHealths = tripHealths;
	}


	public Set<BeTripAccommodation> getTripAccommodations() {
		return tripAccommodations;
	}


	public void setTripAccommodations(Set<BeTripAccommodation> tripAccommodations) {
		this.tripAccommodations = tripAccommodations;
	}


	public RefIntAirport getDepartureAirport() {
		return departureAirport;
	}


	public void setDepartureAirport(RefIntAirport departureAirport) {
		this.departureAirport = departureAirport;
	}


	public RefIntAirport getArrivalAirport() {
		return arrivalAirport;
	}


	public void setArrivalAirport(RefIntAirport arrivalAirport) {
		this.arrivalAirport = arrivalAirport;
	}


	public Date getSubmitDt() {
		return submitDt;
	}


	public void setSubmitDt(Date submitDt) {
		this.submitDt = submitDt;
	}


	public Set<BeTvl> getTvls() {
		return tvls;
	}


	public void setTvls(Set<BeTvl> tvls) {
		this.tvls = tvls;
	}


	public RefMetadata getTripPlanMtdt() {
		return tripPlanMtdt;
	}


	public void setTripPlanMtdt(RefMetadata tripPlanMtdt) {
		this.tripPlanMtdt = tripPlanMtdt;
	}


	public String getTvlModeRtn() {
		return tvlModeRtn;
	}


	public void setTvlModeRtn(String tvlModeRtn) {
		this.tvlModeRtn = tvlModeRtn;
	}


	public String getFlightNoRtn() {
		return flightNoRtn;
	}


	public void setFlightNoRtn(String flightNoRtn) {
		this.flightNoRtn = flightNoRtn;
	}


	public String getAirlinesRtn() {
		return airlinesRtn;
	}


	public void setAirlinesRtn(String airlinesRtn) {
		this.airlinesRtn = airlinesRtn;
	}


	public RefIntAirport getDepartureAirportRtn() {
		return departureAirportRtn;
	}


	public void setDepartureAirportRtn(RefIntAirport departureAirportRtn) {
		this.departureAirportRtn = departureAirportRtn;
	}


	public Date getDepartureDtRtn() {
		return departureDtRtn;
	}


	public void setDepartureDtRtn(Date departureDtRtn) {
		this.departureDtRtn = departureDtRtn;
	}


	public String getDepartureTimeRtn() {
		return departureTimeRtn;
	}


	public void setDepartureTimeRtn(String departureTimeRtn) {
		this.departureTimeRtn = departureTimeRtn;
	}


	public RefIntAirport getArrivalAirportRtn() {
		return arrivalAirportRtn;
	}


	public void setArrivalAirportRtn(RefIntAirport arrivalAirportRtn) {
		this.arrivalAirportRtn = arrivalAirportRtn;
	}


	public RefMetadata getAppsMtdt() {
		return appsMtdt;
	}


	public void setAppsMtdt(RefMetadata appsMtdt) {
		this.appsMtdt = appsMtdt;
	}

}
