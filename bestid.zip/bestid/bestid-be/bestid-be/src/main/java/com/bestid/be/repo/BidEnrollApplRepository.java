/**
 *
 */
package com.bestid.be.repo;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidEnrollAppl;


/**
 * @author mukhlis.hamzah
 * @since Feb 14, 2019
 */
@Repository
@RepositoryDefinition(domainClass = BidEnrollAppl.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_ENROLL_APPL_REPOSITORY)
public interface BidEnrollApplRepository extends GenericRepository<BidEnrollAppl> {

	@Query("select u from BidEnrollAppl u where u.deviceId= :deviceId and u.status= :status")
	BidEnrollAppl findByDeviceId(@Param("deviceId") int deviceId, @Param("status") String status);


	@Query("select u from BidEnrollAppl u where u.applId= :applId")
	BidEnrollAppl findByApplId(@Param("applId") Integer applId);


	@Query("select u from BidEnrollAppl u where u.deviceId= :deviceId and u.activationCode= :activationCode")
	BidEnrollAppl findByActvCdDvcId(@Param("deviceId") int deviceId, @Param("activationCode") String activationCode);


	@Query("select u from BidEnrollAppl u where u.deviceId= :deviceId and u.userId= :userId")
	BidEnrollAppl findByUsrNDeviceId(@Param("deviceId") int deviceId, @Param("userId") int userId);


	@Query("select u from BidEnrollAppl u where u.deviceId= :deviceId and u.userId= :userId  and u.status= :status")
	BidEnrollAppl findByUsrNDeviceIdSts(@Param("deviceId") int deviceId, @Param("userId") int userId,
			@Param("status") String status);


	@Query("select u from BidEnrollAppl u where u.applId= :applId and u.deviceId= :deviceId")
	BidEnrollAppl findByApplIdDvcId(@Param("applId") Integer applId, @Param("deviceId") int deviceId);


	@Query("select u from BidEnrollAppl u where u.activationCode= :activationCode")
	BidEnrollAppl findByActvCd(@Param("activationCode") String activationCode);

}
