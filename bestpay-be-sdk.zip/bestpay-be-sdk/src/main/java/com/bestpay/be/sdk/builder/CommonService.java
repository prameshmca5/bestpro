/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.builder;


import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.bestpay.be.sdk.client.BeRestTemplate;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Country;
import com.bestpay.be.sdk.model.PaymentType;
import com.bestpay.be.sdk.model.Status;


/**
 * @author Ilhomjon
 * @since Feb 22, 2018
 */
public class CommonService extends AbstractService {

	private BeRestTemplate restTemplate;

	private Properties prop;

	private String url;


	public CommonService(BeRestTemplate restTemplate, Properties prop, String url) {
		this.restTemplate = restTemplate;
		this.prop = prop;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public Properties prop() {
		return prop;
	}


	@Override
	public String url() {
		return url;
	}


	public List<Country> allCountry() throws BeException {
		Country[] countryArray = restTemplate().getForObject(getServiceURI(BeUrlConstants.COUNTRIES),
				Country[].class);
		return Arrays.asList(countryArray);
	}


	public List<PaymentType> getPaymentTypes() throws BeException {
		PaymentType[] paymentTypes = restTemplate().getForObject(getServiceURI(BeUrlConstants.REF_PAYMENT_TYPES),
				PaymentType[].class);
		return Arrays.asList(paymentTypes);
	}


	public List<Status> getPaymentTypesCode() throws BeException {
		Status[] paymentTypes = restTemplate().getForObject(getServiceURI(BeUrlConstants.REF_PAYMENT_TYPES_CODE),
				Status[].class);
		return Arrays.asList(paymentTypes);
	}


	public List<Status> getRefStatus() throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REF_PAYMENT_STATUS_CODE);
		Status[] refStats = restTemplate().getForObject(getServiceURI(sb.toString()), Status[].class);
		return Arrays.asList(refStats);
	}


	public Status getRefStatusNextItem(String statusCode) throws BeException {
		StringBuilder sb = new StringBuilder();
		Map<String, Object> requestLst = new HashMap<>();
		requestLst.put("status_code", statusCode);
		sb.append(BeUrlConstants.REF_PAYMENT_STATUS_CODE);
		return restTemplate().getForObject(getServiceURI(sb.toString() + "/nextItem?status_code={status_code}"),
				Status.class, requestLst);
	}
}