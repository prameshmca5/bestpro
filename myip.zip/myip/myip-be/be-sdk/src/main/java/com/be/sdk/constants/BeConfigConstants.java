/**
 * Copyright 2019
 */
package com.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BeConfigConstants {

	private BeConfigConstants() {
		throw new IllegalStateException("BeConfigConstants class");
	}


	public static final String SMS_SWITCH = "SMS_SWITCH";

	public static final String DIGITAL_SIGNING = "digital.sign.url";

	public static final String MRZ = "mrz.url";

	public static final String MRZ_API_KEY = "mrz.api.key";

	public static final String ACCURA_API_KEY = "accura.api.key";

	public static final String REGULA_X_TOKEN = "regula.x.token";
}