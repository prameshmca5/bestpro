/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since 03/03/2018
 */
public class FileUploadConstants {

	public static final String PROFILE_PIC = "PROFPIC";

	public static final String PREFIX_DOC = "DOC";

	public static final String DOC_TRXN_SLIP_PENDAFTARAN = "SLIP_PENDAFTARAN";

	public static final String DOC_TRXN_RESIT_PEMBAYARAN = "RESIT_PEMBAYARAN";

	public static final String DOC_TRXN_SLIP_PENGAKUAN = "SLIP_PENGAKUAN";

	public static final String DOC_TRXN_SURAT_KELULUSAN = "SURAT_KELULUSAN";

	public static final String DOC_TRXN_BORANG_PERMOHONAN = "BORANG_PERMOHONAN";


	private FileUploadConstants() {
		throw new IllegalStateException("FileUploadConstants class");
	}

}