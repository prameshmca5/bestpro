package com.bestpay.pgw.sdk.incentiveremit.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "Authorized_ConfirmedResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class AuthorizedConfirmedResponse {

	@XmlElement(name = "CODE")
	private String code;

	@XmlElement(name = "AGENT_SESSION_ID")
	private String agentSessionId;

	@XmlElement(name = "MESSAGE")
	private String message;


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getAgentSessionId() {
		return agentSessionId;
	}


	public void setAgentSessionId(String agentSessionId) {
		this.agentSessionId = agentSessionId;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}

}
