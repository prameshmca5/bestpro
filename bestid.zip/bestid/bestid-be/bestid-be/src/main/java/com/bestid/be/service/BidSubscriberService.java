/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidCompany;
import com.bestid.be.model.BidSubscriber;
import com.bestid.be.qf.BidSubscriberQf;
import com.bestid.be.repo.BidCompanyRepository;
import com.bestid.be.repo.BidSubscriberRepository;
import com.bestid.be.repo.GenericRepository;
import com.bestid.be.sdk.model.SubscriberInfo;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.DateUtil;

/**
 * @author mukhlis.hamzah
 * @since 1 Mar 2019
 */
@Transactional
@Service(QualifierConstants.BID_SUBSCRIBER_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_SUBSCRIBER_SVC)
public class BidSubscriberService extends AbstractService<BidSubscriber> {

	@Autowired
	@Qualifier(QualifierConstants.BID_SUBSCRIBER_REPOSITORY)
	BidSubscriberRepository bidSubscriberDao;

	@Autowired
	@Qualifier(QualifierConstants.BID_SUBSCRIBER_QF)
	BidSubscriberQf bidSubscriberQf;

	@Autowired
	private BidCompanyRepository bidCompanyDao;

	@Override
	public GenericRepository<BidSubscriber> primaryDao() {
		return bidSubscriberDao;
	}

	public BidSubscriber findSysCd(String subscrCd) {
		return bidSubscriberDao.findSysCd(subscrCd);
	}

	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public SubscriberInfo createSubscriberInfo(SubscriberInfo si, String userId, HttpServletRequest request) {

		List<SubscriberInfo> subscriberInfoList = null;
		BidSubscriber bsData = null;
		BidCompany bcData = null;
		SubscriberInfo searchFilter = new SubscriberInfo();
		if (!BaseUtil.isObjNull(si.getSubscrCd()) && !BaseUtil.isObjNull(si.getCmpnyRegNo())) {
			searchFilter.setSubscrCd(si.getSubscrCd());
			subscriberInfoList = bidSubscriberQf.findBySearchCriteria(searchFilter);
		}

		if (BaseUtil.isListNull(subscriberInfoList)) {
			BidCompany bc = dozerMapper.map(si.getCompanyInfo(), BidCompany.class);
			BidCompany cmpnyInfo = bidCompanyDao.findByCmpnyRegNo(si.getCmpnyRegNo());

			if (BaseUtil.isObjNull(cmpnyInfo)) {
				bc.setCmpnyName(bc.getCmpnyName().toUpperCase());
				bc.setCmpnyOwner(bc.getCmpnyOwner().toUpperCase());
				bc.setCmpnyRegNo(si.getCmpnyRegNo().toUpperCase());
				bc.setCreateId(userId);
				bc.setCreateDt(DateUtil.getSQLTimestamp());
				bc.setUpdateId(userId);
				bc.setUpdateDt(DateUtil.getSQLTimestamp());
				bc = bidCompanyDao.saveAndFlush(bc);
			}

			BidSubscriber bs = dozerMapper.map(si, BidSubscriber.class);
			if (!BaseUtil.isObjNull(bc.getCmpnyId()) && !BaseUtil.isObjNull(bs)) {
				if (BaseUtil.isObjNull(cmpnyInfo)) {
					bs.setCmpnyId(bc.getCmpnyId());

				} else {
					bs.setCmpnyId(cmpnyInfo.getCmpnyId());
				}
				bs.setStatus("A");
				bs.setSysName(bs.getSysName().toUpperCase());
				bs.setCreateId(userId);
				bs.setCreateDt(DateUtil.getSQLTimestamp());
				bs.setUpdateId(userId);
				bs.setUpdateDt(DateUtil.getSQLTimestamp());
				bidSubscriberDao.saveAndFlush(bs);
			}
		} else {

			bcData = bidCompanyDao.findByCmpnyRegNo(si.getCmpnyRegNo().toUpperCase());
			if (!BaseUtil.isObjNull(bcData)) {
				bcData.setCmpnyName(si.getCompanyInfo().getCmpnyName().toUpperCase());
				bcData.setCmpnyOwner(si.getCompanyInfo().getCmpnyOwner().toUpperCase());
				bcData.setContactNo(si.getCompanyInfo().getContactNo());
				bcData.setEmail(si.getCompanyInfo().getEmail());
				bcData.setUpdateId(userId);
				bcData.setUpdateDt(DateUtil.getSQLTimestamp());
				bidCompanyDao.saveAndFlush(bcData);
			}

			bsData = bidSubscriberDao.findSysCd(si.getSubscrCd());
			if (!BaseUtil.isObjNull(bsData)) {
				bsData.setSysName(si.getSysName().toUpperCase());
				bsData.setSubscrType(si.getSubscrType());
				bsData.setSysLogo(si.getSysLogo());
				bsData.setUpdateId(userId);
				bsData.setUpdateDt(DateUtil.getSQLTimestamp());
				bidSubscriberDao.saveAndFlush(bsData);
			}

		}

		return si;
	}

	public BidSubscriber findByCmpnyRegNoAndSysName(String cmpnyRegNo, String sysName) {
		return bidSubscriberDao.findByCmpnyRegNoAndSysName(cmpnyRegNo, sysName);
	}

	public List<SubscriberInfo> findBySearchCriteria(SubscriberInfo subscriberInfo) {
		return bidSubscriberQf.findBySearchCriteria(subscriberInfo);
	}

	public BidSubscriber findBySubscribIdType(int subscrId, String subscrType) {
		return bidSubscriberDao.findBySubscribIdType(subscrId, subscrType);
	}

	public List<BidSubscriber> searchByProperty(BidSubscriber bidSubscriber) {
		return bidSubscriberDao.findAll(bidSubscriberQf.searchByProperty(bidSubscriber));
	}

	public Boolean deactivatedSubscriber(SubscriberInfo subscriberInfo, String userId) {
		BidSubscriber bs = bidSubscriberDao.findSysCd(subscriberInfo.getSubscrCd());
		if (!BaseUtil.isObjNull(bs)) {
			bs.setStatus("I");
			bs.setUpdateId(userId);
			bs.setUpdateDt(DateUtil.getSQLTimestamp());
			bidSubscriberDao.saveAndFlush(bs);
		}
		return true;

	}

}
