/**
  * Copyright 2019
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 *
 * @author Naem Othman
 * @since March 31, 2020
 */
public class ElectionNot implements Serializable, IQfCriteria<ElectionNot> {

	/**
	 *
	 */
	private static final long serialVersionUID = 5093756330501797975L;

	private Integer electionNotId;

	private String txnId;

	private String orgStateCd;

	private String orgDivisionCd;

	private String parliamentCode;

	private String dunCode;

	private Integer memberCtrgyMtdtId;

	private Integer totalMember;

	private String applyBy;

	private Timestamp applyDt;

	private String applyLevel;

	private String applyOrgStateCd;

	private String applyOrgDivisionCd;

	private Timestamp applyDtFrom;

	private Timestamp applyDtTo;

	private Integer notifyInd;

	private String createId;

	private Timestamp createDt;

	private String updateId;

	private Timestamp updateDt;


	public Integer getElectionNotId() {
		return electionNotId;
	}


	public void setElectionNotId(Integer electionNotId) {
		this.electionNotId = electionNotId;
	}


	public String getTxnId() {
		return txnId;
	}


	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}


	public String getOrgStateCd() {
		return orgStateCd;
	}


	public void setOrgStateCd(String orgStateCd) {
		this.orgStateCd = orgStateCd;
	}


	public String getOrgDivisionCd() {
		return orgDivisionCd;
	}


	public void setOrgDivisionCd(String orgDivisionCd) {
		this.orgDivisionCd = orgDivisionCd;
	}


	public String getParliamentCode() {
		return parliamentCode;
	}


	public void setParliamentCode(String parliamentCode) {
		this.parliamentCode = parliamentCode;
	}


	public String getDunCode() {
		return dunCode;
	}


	public void setDunCode(String dunCode) {
		this.dunCode = dunCode;
	}


	public Integer getMemberCtrgyMtdtId() {
		return memberCtrgyMtdtId;
	}


	public void setMemberCtrgyMtdtId(Integer memberCtrgyMtdtId) {
		this.memberCtrgyMtdtId = memberCtrgyMtdtId;
	}


	public String getApplyBy() {
		return applyBy;
	}


	public void setApplyBy(String applyBy) {
		this.applyBy = applyBy;
	}


	public Timestamp getApplyDt() {
		return applyDt;
	}


	public void setApplyDt(Timestamp applyDt) {
		this.applyDt = applyDt;
	}


	public Timestamp getApplyDtFrom() {
		return applyDtFrom;
	}


	public void setApplyDtFrom(Timestamp applyDtFrom) {
		this.applyDtFrom = applyDtFrom;
	}


	public Timestamp getApplyDtTo() {
		return applyDtTo;
	}


	public void setApplyDtTo(Timestamp applyDtTo) {
		this.applyDtTo = applyDtTo;
	}


	public Integer getTotalMember() {
		return totalMember;
	}


	public void setTotalMember(Integer totalMember) {
		this.totalMember = totalMember;
	}


	public String getApplyLevel() {
		return applyLevel;
	}


	public void setApplyLevel(String applyLevel) {
		this.applyLevel = applyLevel;
	}


	public String getApplyOrgStateCd() {
		return applyOrgStateCd;
	}


	public void setApplyOrgStateCd(String applyOrgStateCd) {
		this.applyOrgStateCd = applyOrgStateCd;
	}


	public String getApplyOrgDivisionCd() {
		return applyOrgDivisionCd;
	}


	public void setApplyOrgDivisionCd(String applyOrgDivisionCd) {
		this.applyOrgDivisionCd = applyOrgDivisionCd;
	}


	/**
	 * @return the notifyInd
	 */
	public Integer getNotifyInd() {
		return notifyInd;
	}


	/**
	 * @param notifyInd
	 *             the notifyInd to set
	 */
	public void setNotifyInd(Integer notifyInd) {
		this.notifyInd = notifyInd;
	}


	/**
	 * @return the createId
	 */
	public String getCreateId() {
		return createId;
	}


	/**
	 * @param createId
	 *             the createId to set
	 */
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	/**
	 * @return the createDt
	 */
	public Timestamp getCreateDt() {
		return createDt;
	}


	/**
	 * @param createDt
	 *             the createDt to set
	 */
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	/**
	 * @return the updateId
	 */
	public String getUpdateId() {
		return updateId;
	}


	/**
	 * @param updateId
	 *             the updateId to set
	 */
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	/**
	 * @return the updateDt
	 */
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	/**
	 * @param updateDt
	 *             the updateDt to set
	 */
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}