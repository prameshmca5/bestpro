/**
 *
 */
package com.be.sdk.builder;


import java.util.Map;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.constants.ReferenceConstants;
import com.be.sdk.model.ConfigMcCollate;
import com.be.sdk.model.McAttendance;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlTestResult;
import com.util.pagination.DataTableResults;


/**
 * @author Atiqah Khairuddin
 *
 */
public class MedicalService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public MedicalService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<Tvl> searchTravelPaginated(Tvl dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVEL);
		sb.append(BeUrlConstants.TRAVEL + BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}


	public Tvl getTravelDetail(Tvl dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVEL);
		sb.append(BeUrlConstants.TRAVEL + BeUrlConstants.GET_DETAIL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Tvl.class);
	}


	public McAttendance addAttendanceInfo(McAttendance dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MC_ATTENDANCE);
		sb.append(BeUrlConstants.INFO_ADD);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, McAttendance.class);
	}


	public ConfigMcCollate searchConfigMcCollate(ConfigMcCollate dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(ReferenceConstants.SEARCH_CONFIG_MC_COLLATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, ConfigMcCollate.class);
	}


	public TvlTestResult updateApprovedMedicalInfo(TvlTestResult dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEDICAL);
		sb.append(BeUrlConstants.MEDICAL + BeUrlConstants.INFO_ADD);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, TvlTestResult.class);
	}
}
