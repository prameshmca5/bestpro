/**
 * 
 */
package com.be.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author michelle.angela
 *
 */
 @Entity
 @Table(name = "BE_CONFIG_PAYMENT_STAGE")
public class BeConfigPaymentStage extends AbstractEntity implements Serializable, IQfCriteria<BeConfigPaymentStage>  {

	private static final long serialVersionUID = 233229693306815L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="PMT_STAGE_ID")
	private Integer pmtStageId;
	 
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="PMT_IND_MTDT_ID")
	private RefMetadata pmtIndMtdt;
	 
	@Column(name = "PMT_TYPE")
	private String pmtType;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "STATUS")
	private Boolean isActive;

	@Column(name="SEQUENCE")
	private Integer sequence;
	
	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;
	
	@JsonIgnoreProperties("configPaymentStage")
	@OneToMany(mappedBy = "configPaymentStage", fetch = FetchType.LAZY)
	private Set<BeConfigPaymentBreakdown> configPaymentBreakdowns;

	public Integer getPmtStageId() {
		return pmtStageId;
	}

	public void setPmtStageId(Integer pmtStageId) {
		this.pmtStageId = pmtStageId;
	}

	public RefMetadata getPmtIndMtdt() {
		return pmtIndMtdt;
	}

	public void setPmtIndMtdt(RefMetadata pmtIndMtdt) {
		this.pmtIndMtdt = pmtIndMtdt;
	}

	public String getPmtType() {
		return pmtType;
	}

	public void setPmtType(String pmtType) {
		this.pmtType = pmtType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public Set<BeConfigPaymentBreakdown> getConfigPaymentBreakdowns() {
		return configPaymentBreakdowns;
	}

	public void setConfigPaymentBreakdowns(Set<BeConfigPaymentBreakdown> configPaymentBreakdowns) {
		this.configPaymentBreakdowns = configPaymentBreakdowns;
	} 
	 
}
