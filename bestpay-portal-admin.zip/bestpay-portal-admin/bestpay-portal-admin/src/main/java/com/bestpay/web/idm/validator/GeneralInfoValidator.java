/**
 * Copyright 2018 Bestinet Sdn Bhd
 */
package com.bestpay.web.idm.validator;


import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.be.sdk.model.MerGenInfo;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ValidationUtil;


/**
 * @author Afif Saman
 * @since July 17, 2018
 */
@Component("generalInfoValidator")
public class GeneralInfoValidator extends AbstractController implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return MerGenInfo.class.equals(clazz);
	}


	@Override
	public void validate(Object object, Errors errors) {
		// Validate if fields are empty or a whitespace

		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "postcode", MessageConstants.ERROR_FIELDS_POST_CODE);
		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "address", MessageConstants.ERROR_FIELDS_ADDRESS);
		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "country", MessageConstants.ERROR_FIELDS_COUNTRY);
		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "rocNo", MessageConstants.ERROR_ROC_NO);
		Object countryValue = errors.getFieldValue("country");
		if ((!BaseUtil.isObjNull(countryValue) && BaseUtil.isEqualsCaseIgnore(countryValue.toString(), "MYS"))) {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "stateMy", MessageConstants.ERROR_FIELDS_STATE);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "cityMy", MessageConstants.ERROR_FIELDS_CITY);
		} else {
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "stateNonMy", MessageConstants.ERROR_FIELDS_STATE);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "cityNonMy", MessageConstants.ERROR_FIELDS_CITY);
		}

		// Validate email if format is valid
		ValidationUtil.rejectIfInvalidEmailFormat(errors, "email", MessageConstants.ERROR_EMAIL_FORMAT);

	}
}
