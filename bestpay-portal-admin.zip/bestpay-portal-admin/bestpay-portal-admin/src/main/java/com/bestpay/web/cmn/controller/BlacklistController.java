/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.BlacklistInfo;
import com.bestpay.be.sdk.model.MerGenInfo;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.idm.sdk.util.MediaType;
import com.bestpay.notify.sdk.util.BaseUtil;
import com.bestpay.web.constants.AppConstants;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.WebUtil;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;

/**
 * @author Afif Saman
 * @since June 06, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_BLACKLIST)
public class BlacklistController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BlacklistController.class);

	private static final String BLACKLIST_INFO = "blacklistInfo";

	@Autowired
	@Qualifier("blacklistValidator")
	private Validator validator;

	@Override
	protected void bindingPreparation(WebDataBinder binder) {
		binder.setValidator(validator);
		super.bindingPreparation(binder);
	}

	// View blacklist
	@GetMapping
	public ModelAndView view(BlacklistInfo blacklistInfo, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_BLACKLIST, "blacklist", null, "blacklist-script");
		mav.addObject(BLACKLIST_INFO, blacklistInfo);
		return mav;
	}

	// Search blacklist
	@PostMapping(params = "search")
	public ModelAndView search(BlacklistInfo blacklistInfo, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_BLACKLIST, "blacklist", null, "blacklist-script");
		mav.addObject(BLACKLIST_INFO, blacklistInfo);
		LOGGER.info("Search blacklist {}", blacklistInfo);
		return mav;
	}

	// Get paginated blacklist
	@GetMapping(value = "/paginated")
	public @ResponseBody String getBlacklistPaginated(@ModelAttribute(BLACKLIST_INFO) BlacklistInfo blacklistInfo,
			BindingResult result, HttpServletRequest request) {
		LOGGER.info("GET PAGINATED BLACKLIST LIST....");
		UserProfile authUser = getCurrentUser();
		if (LOGGER.isDebugEnabled()) {
			LOGGER.info("User ID = {}", authUser);
		}
		DataTableResults<BlacklistInfo> blckList = null;
		try {
			blckList = getBeService().searchBlacklist(blacklistInfo, getPaginationRequest(request, true));
		} catch (Exception e) {
			if (WebUtil.checkSystemDown(e)) {
				LOGGER.info("Check system down = {}", e);
			}
			LOGGER.error(e.getMessage());
		}

		return new Gson().toJson(blckList);
	}

	// Delete blacklist
	@DeleteMapping(value = "delete/{id}", produces = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_JSON })
	public @ResponseBody String delete(@PathVariable String id) {
		BlacklistInfo blcklsttInfo = new BlacklistInfo();
		try {
			boolean del = getBeService().deleteBlacklist(id);
			// deleteForObject return false in BeRestTemplate
			if (!del) {
				LOGGER.info("Delete success");
				blcklsttInfo.setIsDeleted(true);
			}
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return new Gson().toJson(blcklsttInfo);
	}

	// Reset view blacklist
	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute(BLACKLIST_INFO) @Validated BlacklistInfo blacklistInfo,
			BindingResult result, HttpServletRequest request, HttpSession session) {
		BlacklistInfo blcklsttInfo = new BlacklistInfo();
		LOGGER.info("--reset--");
		return view(blcklsttInfo, result, request, session);
	}

	// View create blacklist
	@GetMapping(value = "/new")
	public ModelAndView viewCreate(@ModelAttribute(BLACKLIST_INFO) BlacklistInfo blacklistInfo, BindingResult result,
			HttpServletRequest request, HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_BLACKLIST_CRT, "create_blacklist", null);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.blcklst.crt"));
		mav.addObject(BLACKLIST_INFO, blacklistInfo);
		return mav;
	}

	// Reset create blacklist
	@PostMapping(value = "/new", params = "reset")
	public ModelAndView resetCreate(@ModelAttribute(BLACKLIST_INFO) @Validated BlacklistInfo blacklistInfo,
			BindingResult result, HttpServletRequest request, HttpSession session) {
		BlacklistInfo blcklsttInfo = new BlacklistInfo();
		LOGGER.info("--reset--");
		return viewCreate(blcklsttInfo, result, request, session);
	}

	// Add new blacklist entry
	@PostMapping(value = "/new", params = "create")
	public ModelAndView create(@Valid @ModelAttribute(BLACKLIST_INFO) BlacklistInfo blacklistInfo, BindingResult result)
			throws BeException {
		LOGGER.info("--Create blacklist entry--");
		UserProfile authUser = getCurrentUser();
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_BLACKLIST_CRT, "create_blacklist", null);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.blcklst.crt"));
		String value = "";
		if (BaseUtil.isEqualsCaseIgnore(blacklistInfo.getTag(), "email")) {
			value = blacklistInfo.getEmailValue();
		} else {
			value = blacklistInfo.getMobileValue();
		}

		if (!result.hasErrors()) {
			BlacklistInfo blckList = new BlacklistInfo();
			MerGenInfo merchInfo = getBeService().getMerchantForBlacklist(blacklistInfo.getTag(), value);
			String listName = "";
			if (!BaseUtil.isObjNull(merchInfo.getMerchantId())) {
				try {
					blacklistInfo.setMerchantId(merchInfo.getMerchantId());
					blacklistInfo.setUserId(authUser.getUserId());
					blckList = getBeService().createBlacklist(blacklistInfo);
					mav.addAllObjects(PopupBox.success(null, null,
							listName + messageService.getMessage(MessageConstants.SUCC_ADD),
							PageConstants.PAGE_BLACKLIST));
				} catch (IdmException e) {
					if (WebUtil.checkSystemDown(e)) {
						throw e;
					}
					mav.addAllObjects(WebUtil.checkServiceDown(e));
				} catch (Exception e) {
					mav.addAllObjects(WebUtil.checkServiceDown(e));
					if (BaseUtil.isEqualsCaseIgnore(e.getMessage(), "The record already exists")) {
						mav.addAllObjects(PopupBox.error("blcklstCreate", "Error",
								messageService.getMessage(MessageConstants.ERROR_DUP_ENTRY)));
					} else {
						mav.addAllObjects(PopupBox
								.error(listName + messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
					}
					LOGGER.error(e.getMessage());
				}
			} else {
				mav.addAllObjects(PopupBox
						.error(listName + messageService.getMessage(MessageConstants.ERROR_BLCKLST_MERCH_NOT_EXST)));
			}

			mav.addObject(BLACKLIST_INFO, blckList);
		}
		return mav;
	}

}