/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.PgwOfflineRequestPaymentCustomDao;
import com.bestpay.be.dao.PgwOfflineRequestPaymentRepository;
import com.bestpay.be.model.PgwOfflineRequestPayment;
import com.bestpay.be.sdk.model.PgwOfflineRequestPaymentDto;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;

/**
 * @author Ramesh Pongiannan
 * @since July 15, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_PAYLK_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_PAYLK_SVC)
public class PgwOfflineRequestPaymentService extends AbstractService<PgwOfflineRequestPayment> {

	@Autowired
	private PgwOfflineRequestPaymentCustomDao pgwTraceRequestPaymentCustomDao;

	@Autowired
	private PgwOfflineRequestPaymentRepository pgwtracepay;

	@Override
	public GenericRepository<PgwOfflineRequestPayment> primaryDao() {
		return pgwtracepay;
	}

	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwOfflineRequestPayment> searchPaymentLink(
			PgwOfflineRequestPaymentDto pgwTraceRequestPayment, DataTableRequest dataTableInRQ) {
		return pgwTraceRequestPaymentCustomDao.searchByPagination(pgwTraceRequestPayment, dataTableInRQ);
	}

	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwOfflineRequestPayment findOrderIdByValue(String value) {
		return pgwtracepay.findOrderIdByValue(value);
	}

	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwOfflineRequestPayment findPayLinkByTraceId(String orderId) {
		return pgwtracepay.findPayLinkByTraceId(orderId);
	}

}