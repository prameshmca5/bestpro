/**
 * 
 */
package com.be.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;

/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_ACCT_PASSPORT")
public class BeAcctPassport extends AbstractEntity implements Serializable, IQfCriteria<BeAcctPassport> {

	private static final long serialVersionUID = 4887966066806177277L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="PASSPORT_ID")
	private Integer passportId;

	@Column(name = "PASSPORT_NO")
	private String passportNo;
	
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH)	
	@Temporal(TemporalType.DATE)
	@Column(name = "PASSPORT_EXPIRY_DT")
	private Date passportExpiryDt;
	
	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "STATUS")
	private Boolean isActive;
	
	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name="ACCT_TVLR_ID")
	private Integer acctTvlrId;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "NATIONALITY")
	private RefCountry nationality;
	
	public Integer getPassportId() {
		return passportId;
	}

	public void setPassportId(Integer passportId) {
		this.passportId = passportId;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public Date getPassportExpiryDt() {
		return passportExpiryDt;
	}

	public void setPassportExpiryDt(Date passportExpiryDt) {
		this.passportExpiryDt = passportExpiryDt;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public Integer getAcctTvlrId() {
		return acctTvlrId;
	}

	public void setAcctTvlrId(Integer acctTvlrId) {
		this.acctTvlrId = acctTvlrId;
	}

	public RefCountry getNationality() {
		return nationality;
	}

	public void setNationality(RefCountry nationality) {
		this.nationality = nationality;
	}
	
}
