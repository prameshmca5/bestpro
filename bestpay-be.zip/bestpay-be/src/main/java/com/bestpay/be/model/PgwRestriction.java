/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@Entity
@Table(name = "PGW_RESTRICTION")
public class PgwRestriction extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "RESTRICT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer restrictId;

	@Column(name = "MERCHANT_ID")
	private String merchantId;

	@Column(name = "ALLOW_COUNTRY_CC")
	private String allowCountryCc;

	@Column(name = "ACCEPTED_COUNTRY_CC")
	private String acceptedCountryCc;

	@Column(name = "ALLOW_COUNTRY_IP")
	private String allowCountryIp;

	@Column(name = "ACCEPTED_COUNTRY_IP")
	private String acceptedCountryIp;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public PgwRestriction() {
		// pgwRestriction backend model
	}


	public Integer getRestrictId() {
		return restrictId;
	}


	public void setRestrictId(Integer restrictId) {
		this.restrictId = restrictId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getAllowCountryCc() {
		return allowCountryCc;
	}


	public void setAllowCountryCc(String allowCountryCc) {
		this.allowCountryCc = allowCountryCc;
	}


	public String getAcceptedCountryCc() {
		return acceptedCountryCc;
	}


	public void setAcceptedCountryCc(String acceptedCountryCc) {
		this.acceptedCountryCc = acceptedCountryCc;
	}


	public String getAllowCountryIp() {
		return allowCountryIp;
	}


	public void setAllowCountryIp(String allowCountryIp) {
		this.allowCountryIp = allowCountryIp;
	}


	public String getAcceptedCountryIp() {
		return acceptedCountryIp;
	}


	public void setAcceptedCountryIp(String acceptedCountryIp) {
		this.acceptedCountryIp = acceptedCountryIp;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}