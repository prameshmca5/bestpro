/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@Entity
@Table(name = "PGW_MERCHANT_CATEGORY")
public class PgwMerchantCategory extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "MER_CAT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer merCatId;

	@Column(name = "MERCHANT_ID")
	private String merchantId;

	@Column(name = "ROC")
	private String roc;

	@Column(name = "DBA")
	private String dba;

	@Column(name = "RESELLER")
	private String reseller;

	@Column(name = "CATEGORY")
	private String category;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public PgwMerchantCategory() {
		// pgwMerchantCategory backend model
	}


	public Integer getMerCatId() {
		return merCatId;
	}


	public void setMerCatId(Integer merCatId) {
		this.merCatId = merCatId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getRoc() {
		return roc;
	}


	public void setRoc(String roc) {
		this.roc = roc;
	}


	public String getDba() {
		return dba;
	}


	public void setDba(String dba) {
		this.dba = dba;
	}


	public String getReseller() {
		return reseller;
	}


	public void setReseller(String reseller) {
		this.reseller = reseller;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}