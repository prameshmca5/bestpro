/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.dao.PgwMultiChannelRepository;
import com.bestpay.pgw.model.PgwMultiChannel;
import com.bestpay.pgw.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since June 25, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_MULTI_CHANNEL_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MULTI_CHANNEL_SVC)
public class PgwMultiChannelService extends AbstractService<PgwMultiChannel> {

	@Autowired
	private PgwMultiChannelRepository multiChannelDao;


	@Override
	public PgwMultiChannelRepository primaryDao() {
		return multiChannelDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwMultiChannel> findMultiChannelByMerchantId(String merchantId) {
		return multiChannelDao.findMultiChannelByMerchantId(merchantId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMultiChannel findActiveMultiChannelByMerIdAndChannel(String merchantId, String channel) {
		return multiChannelDao.findActiveMultiChannelByMerIdAndChannel(merchantId, channel, "A");
	}
}