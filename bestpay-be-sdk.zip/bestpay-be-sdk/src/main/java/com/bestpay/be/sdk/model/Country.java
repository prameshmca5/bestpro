/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Ilhomjon
 * @since Feb 22, 2018
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Country implements Serializable {

	private static final long serialVersionUID = -6255425222614429634L;

	private String cntryCode;
	private String cntryDesc;
	private String cntryInd;
	private Integer cntryId;
	private String cntry3Code;
	private String simInd;
	private String mobileCode;

	public String getCntry3Code() {
		return cntry3Code;
	}

	public String getSimInd() {
		return simInd;
	}

	public void setCntry3Code(String cntry3Code) {
		this.cntry3Code = cntry3Code;
	}

	public void setSimInd(String simInd) {
		this.simInd = simInd;
	}

	public String getCntryCode() {
		return cntryCode;
	}

	public void setCntryCode(String cntryCode) {
		this.cntryCode = cntryCode;
	}

	public String getCntryDesc() {
		return cntryDesc;
	}

	public void setCntryDesc(String cntryDesc) {
		this.cntryDesc = cntryDesc;
	}

	public String getCntryInd() {
		return cntryInd;
	}

	public void setCntryInd(String cntryInd) {
		this.cntryInd = cntryInd;
	}

	public Integer getCntryId() {
		return cntryId;
	}

	public void setCntryId(Integer cntryId) {
		this.cntryId = cntryId;
	}

	public String getMobileCode() {
		return mobileCode;
	}

	public void setMobileCode(String mobileCode) {
		this.mobileCode = mobileCode;
	}

}