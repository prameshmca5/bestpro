package com.bestpay.web.cmn.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerChanSetWrapper;
import com.bestpay.be.sdk.model.MerCompBankDetails;
import com.bestpay.be.sdk.model.MerCompany;
import com.bestpay.be.sdk.model.MerSendAccInfo;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.WebUtil;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;


/**
 * @author Atiqah Khairuddin
 * @since March 25, 2019
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_COMPANY_REFERRAL)
public class MerchantCompanyController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MerchantCompanyController.class);

	private static final String MERCHANT_COMPANY_SCRIPT = "merchant-company-script";

	private static final String MERCHANT_COMPANY = "merchantCompany";

	private static final String COUNTRY_LIST = "countryList";

	private static final String STATE_LIST = "stateList";

	private static final String CITY_LIST = "cityList";

	private static final String REFERRAL_INFO = "referralInfo";

	private static final String REFERRAL_MGMT = "referral_mgmt";

	private static final String MER_COMP_BANK_DETAILS = "merCompBankDetails";

	private static final String BENEFICIARY_SETTING = "beneficiarySetting";

	private static final String COMP_REF_ID = "compRefId";

	private static final String ADD_BEN = "addBen";

	private static final String MERCHANT_SET_WRAPPER = "merChanSetWrapper";

	private static final String CHANNEL_LIST = "channelList";

	private static final String REFERRAL_CREATE = "referralCreate";

	@Autowired
	@Qualifier("merchantCompanyValidator")
	private Validator merchantCompanyValidator;


	@Override
	protected void bindingPreparation(WebDataBinder binder) {
		binder.setValidator(merchantCompanyValidator);
		super.bindingPreparation(binder);
	}


	/**
	 * View Merchant Company
	 *
	 * @param merchantCompany
	 */
	@GetMapping
	public ModelAndView view(MerCompany merchantCompany, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_MERCHANT_COMPANY, "merchant-company", null,
				MERCHANT_COMPANY_SCRIPT);
		mav.addObject(MERCHANT_COMPANY, merchantCompany);
		return mav;
	}


	/**
	 * Get Merchant Company paginated
	 *
	 * @param merchantCompany
	 */
	@GetMapping(value = "/paginated")
	public @ResponseBody String getCompRefPaginated(@ModelAttribute(MERCHANT_COMPANY) MerCompany merchantCompany,
			BindingResult result, HttpServletRequest request) {
		LOGGER.info("GET PAGINATED COMPANY REFERRAL LIST....");
		UserProfile authUser = getCurrentUser();
		if (LOGGER.isDebugEnabled()) {
			LOGGER.info("User ID = {}", authUser);
		}
		DataTableResults<MerCompany> compRefList = null;
		try {
			compRefList = getBeService().searchMerchantCompany(merchantCompany, getPaginationRequest(request, true));
		} catch (Exception e) {
			if (WebUtil.checkSystemDown(e)) {
				LOGGER.info("Check system down = {}", e);
			}
			LOGGER.error(e.getMessage());
		}

		return new Gson().toJson(compRefList);
	}


	/**
	 * Search Merchant Company
	 *
	 * @param merchantCompany
	 */
	@PostMapping(params = "search")
	public ModelAndView search(MerCompany merchantCompany, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_MERCHANT_COMPANY, null, null, MERCHANT_COMPANY_SCRIPT);
		mav.addObject(MERCHANT_COMPANY, merchantCompany);
		return mav;
	}


	/**
	 * Reset search Merchant Company
	 *
	 * @param merchantCompany
	 */
	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute(MERCHANT_COMPANY) @Validated MerCompany merchantCompany,
			BindingResult result, HttpServletRequest request, HttpSession session) {
		MerCompany merCompany = new MerCompany();
		LOGGER.info("--reset--");
		return view(merCompany, result, request, session);
	}


	/**
	 * View Merchant Company create form
	 *
	 * @param merchantCompany
	 * @param merCompBankDetails
	 */
	@GetMapping(value = "/new")
	public ModelAndView viewCreate(MerCompany merchantCompany, MerCompBankDetails merCompBankDetails,
			MerChanSetWrapper merChanSetWrapper, HttpSession session) throws BeException {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_REFERRAL_PROFILE);
		boolean updateMerchantCompany = !BaseUtil.isObjNull(merchantCompany.getCompRefId());
		String compRefId = "new";
		mav.addObject("tab", REFERRAL_INFO);
		mav.addObject(COUNTRY_LIST, staticData.countryList());
		mav.addObject(STATE_LIST, staticData.stateList("MYS"));
		mav.addObject(CITY_LIST, staticData.cityList());
		mav.addObject(MER_COMP_BANK_DETAILS, merCompBankDetails);
		mav.addObject(MERCHANT_COMPANY, merchantCompany);
		mav.addObject("updateMerchantCompany", updateMerchantCompany);
		mav.addObject(COMP_REF_ID, compRefId);
		mav.addObject(CHANNEL_LIST, staticData.channelList());
		return mav;
	}


	/**
	 * Save new Merchant Company
	 *
	 * @param compRefId
	 * @param merchantCompany
	 * @param merCompBankDetails
	 */
	@PostMapping(value = "/{compRefId}", params = "createReferralInfo")
	public ModelAndView create(@PathVariable String compRefId,
			@Valid @ModelAttribute(MERCHANT_COMPANY) MerCompany merchantCompany, BindingResult result,
			MerCompBankDetails merCompBankDetails, MerChanSetWrapper merChanSetWrapper, HttpServletRequest request,
			HttpSession session) throws BeException {
		ModelAndView mav = new ModelAndView();
		UserProfile authUser = getCurrentUser();
		MerCompany merComp = new MerCompany();
		boolean isCreated = false;
		if (result.hasErrors()) {
			return viewCreate(merchantCompany, merCompBankDetails, merChanSetWrapper, session);
		}
		merchantCompany.setCreateId(authUser.getUserId());
		try {
			merComp = getBeService().createCompRef(merchantCompany);
			mav.addAllObjects(PopupBox.success(MERCHANT_COMPANY, null,
					messageService.getMessage(MessageConstants.SUCC_CREATE_COMPANY),
					PageConstants.PAGE_COMPANY_REFERRAL));
			isCreated = true;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		if (isCreated) {
			mav = updatedInfo(merComp.getCompRefId(), PageTemplate.TEMP_REFERRAL_PROFILE, REFERRAL_MGMT,
					REFERRAL_INFO);
			mav.addObject(COMP_REF_ID, merComp.getCompRefId());
			mav.addAllObjects(com.bstsb.util.PopupBox.success(REFERRAL_CREATE, null,
					messageService.getMessage(MessageConstants.SUCC_CREATE_COMPANY)));
		} else {
			mav = updatedInfo(compRefId, PageTemplate.TEMP_REFERRAL_PROFILE, REFERRAL_MGMT, REFERRAL_INFO);
			mav.addObject(MERCHANT_COMPANY, merchantCompany);
			mav.addObject(MER_COMP_BANK_DETAILS, merCompBankDetails);
			mav.addObject(COMP_REF_ID, compRefId);
			mav.addObject(COUNTRY_LIST, staticData.countryList());
			mav.addObject(STATE_LIST, staticData.stateList("MYS"));
			mav.addObject(CITY_LIST, staticData.cityList());
		}

		return mav;
	}


	/**
	 * View merchant company update form
	 *
	 * @param compRefId
	 * @param merchantCompany
	 * @param merCompBankDetails
	 */
	@GetMapping(value = "/referral/{compRefId}")
	public ModelAndView viewReferral(@PathVariable String compRefId,
			@ModelAttribute(MERCHANT_COMPANY) MerCompany merchantCompany, MerCompBankDetails merCompBankDetails,
			MerChanSetWrapper merChanSetWrapper, BindingResult result) throws BeException {

		return updatedInfo(compRefId, PageTemplate.TEMP_REFERRAL_PROFILE, REFERRAL_MGMT, REFERRAL_INFO);
	}


	/**
	 * View merchant company bank details listing
	 *
	 * @param compRefId
	 * @param merchantCompany
	 * @param merCompBankDetails
	 */
	@GetMapping(value = "/referral/{compRefId}", params = "cancel=backToBenList")
	public ModelAndView cancelAndViewReferral(@PathVariable String compRefId,
			@ModelAttribute(MERCHANT_COMPANY) MerCompany merchantCompany, MerCompBankDetails merCompBankDetails,
			MerChanSetWrapper merChanSetWrapper, BindingResult result) throws BeException {

		ModelAndView mav = updatedInfo(compRefId, PageTemplate.TEMP_REFERRAL_PROFILE, REFERRAL_MGMT,
				BENEFICIARY_SETTING);
		mav.addObject(MER_COMP_BANK_DETAILS, merCompBankDetails);
		mav.addObject(MERCHANT_COMPANY, merchantCompany);
		mav.addObject(COMP_REF_ID, merCompBankDetails.getCompRefId());
		mav.addObject(MERCHANT_SET_WRAPPER, merChanSetWrapper);
		return mav;
	}


	/**
	 * update existing Merchant Company
	 *
	 * @param compRefId
	 * @param merchantCompany
	 * @throws BeException
	 */
	@PostMapping(value = "/referral/{compRefId}", params = "updateReferralInfo")
	public ModelAndView updateCompany(@PathVariable String compRefId,
			@Valid @ModelAttribute(MERCHANT_COMPANY) MerCompany merchantCompany, BindingResult result,
			MerCompBankDetails merCompBankDetails) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_REFERRAL_INFO, "referral-info", null);
		UserProfile authUser = getCurrentUser();
		merchantCompany.setUpdateId(authUser.getUserId());
		merchantCompany.setCompanyId(merchantCompany.getCompanyId());
		boolean isUpdated = false;

		LOGGER.info("Result = {}", merchantCompany.getCompanyId());
		if (!result.hasErrors()) {
			try {
				getBeService().updateCompany(merchantCompany);
				mav.addObject(COUNTRY_LIST, staticData.countryList());
				mav.addObject(STATE_LIST, staticData.stateList("MYS"));
				mav.addObject(CITY_LIST, staticData.cityList());

				mav.addAllObjects(PopupBox.success(null, null,
						messageService.getMessage(MessageConstants.SUCC_UPDATE_COMPANY),
						PageConstants.PAGE_COMPANY_REFERRAL));
				isUpdated = true;
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
		if (isUpdated) {
			mav = updatedInfo(merchantCompany.getCompRefId(), PageTemplate.TEMP_REFERRAL_PROFILE, REFERRAL_MGMT,
					REFERRAL_INFO);
			mav.addObject(COMP_REF_ID, merchantCompany.getCompRefId());
			mav.addAllObjects(com.bstsb.util.PopupBox.success(REFERRAL_CREATE, null,
					messageService.getMessage(MessageConstants.SUCC_UPDATE_COMPANY)));
		} else {
			mav = updatedInfo(merchantCompany.getCompRefId(), PageTemplate.TEMP_REFERRAL_PROFILE, REFERRAL_MGMT,
					REFERRAL_INFO);
			mav.addObject(MERCHANT_COMPANY, merchantCompany);
			mav.addObject(MER_COMP_BANK_DETAILS, merCompBankDetails);
			mav.addObject(COMP_REF_ID, merchantCompany.getCompRefId());
			mav.addObject(COUNTRY_LIST, staticData.countryList());
			mav.addObject(STATE_LIST, staticData.stateList("MYS"));
			mav.addObject(CITY_LIST, staticData.cityList());
		}
		return mav;
	}


	/**
	 * get merchant company bank details paginated
	 *
	 * @param compRefId
	 * @param merCompBankDetails
	 */
	@GetMapping(value = "/beneficiary-list/paginated")
	public @ResponseBody String getReferralBeneficiaryPaginated(
			@ModelAttribute(MER_COMP_BANK_DETAILS) MerCompBankDetails merCompBankDetails, BindingResult result,
			HttpServletRequest request) throws BeException {
		LOGGER.info("GET PAGINATED REFERRAL BENEFICIARY LIST....");
		LOGGER.info("company ref id = {}", merCompBankDetails.getCompRefId());
		DataTableResults<MerCompBankDetails> tasks = null;
		try {
			tasks = getBeService().searchReferralBeneficiary(merCompBankDetails,
					getPaginationRequest(request, true));
		} catch (BeException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(e.getMessage());
		}

		return new Gson().toJson(tasks);
	}


	/**
	 * view merchant company bank details create form
	 *
	 * @param compRefId
	 * @param merCompBankDetails
	 * @param merchantCompany
	 * @throws BeException
	 */
	@GetMapping(value = "/beneficiary/new/{compRefId}")
	public ModelAndView viewCreateBeneficiary(@PathVariable String compRefId, MerCompBankDetails merCompBankDetails,
			MerCompany merchantCompany, HttpSession session) throws BeException {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_REFERRAL_PROFILE);
		MerChanSetWrapper merChanSetWrapper = getBeService().getRefChannelByCompRefId(compRefId);
		MerCompany merCompany = getBeService().getCompanyByCompRefId(compRefId);
		mav.addObject("tab", BENEFICIARY_SETTING);
		mav.addObject(MER_COMP_BANK_DETAILS, merCompBankDetails);
		mav.addObject(MERCHANT_COMPANY, merchantCompany);
		mav.addObject(COMP_REF_ID, compRefId);
		mav.addObject(ADD_BEN, ADD_BEN);
		mav.addObject(CHANNEL_LIST, staticData.channelList());
		mav.addObject(MERCHANT_SET_WRAPPER, merChanSetWrapper);
		mav.addObject(MERCHANT_COMPANY, merCompany);
		return mav;
	}


	/**
	 * save new merchant company bank details
	 *
	 * @param compRefId
	 * @param merCompBankDetails
	 * @param merchantCompany
	 */
	@PostMapping(value = "/beneficiary/create/{compRefId}", params = "update=saveBenDetails")
	public ModelAndView createBeneficiary(@PathVariable String compRefId,
			@Valid @ModelAttribute("merCompBankDetails") MerCompBankDetails merCompBankDetails, BindingResult result,
			MerCompany merchantCompany, HttpServletRequest request, HttpSession session) throws BeException {
		ModelAndView mav = new ModelAndView();
		UserProfile authUser = getCurrentUser();
		MerCompBankDetails compBankDetails = new MerCompBankDetails();
		boolean isCreated = false;
		if (result.hasErrors()) {
			return viewCreateBeneficiary(compRefId, merCompBankDetails, merchantCompany, session);
		}
		merCompBankDetails.setCreateId(authUser.getUserId());
		merCompBankDetails.setCompBankId(merCompBankDetails.getCompBankId());
		try {
			compBankDetails = getBeService().createBeneficiary(merCompBankDetails);
			mav.addAllObjects(PopupBox.success(BENEFICIARY_SETTING, null,
					messageService.getMessage(MessageConstants.SUCC_CREATE_COMPANY_BENEFICIARY),
					PageConstants.PAGE_COMPANY_REFERRAL));
			isCreated = true;
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		if (isCreated) {
			mav = updatedInfo(compRefId, PageTemplate.TEMP_REFERRAL_PROFILE, REFERRAL_MGMT, BENEFICIARY_SETTING);
			mav.addObject(COMP_REF_ID, compBankDetails.getCompRefId());
			mav.addAllObjects(com.bstsb.util.PopupBox.success(REFERRAL_CREATE, null,
					messageService.getMessage(MessageConstants.SUCC_CREATE_COMPANY_BENEFICIARY)));
		} else {
			mav = updatedInfo(compRefId, PageTemplate.TEMP_REFERRAL_PROFILE, REFERRAL_MGMT, BENEFICIARY_SETTING);
			mav.addObject(MERCHANT_COMPANY, merchantCompany);
			mav.addObject(MER_COMP_BANK_DETAILS, merCompBankDetails);
			mav.addObject(COMP_REF_ID, compRefId);
		}

		return mav;
	}


	/**
	 * View merchant company bank details update form
	 *
	 * @param compRefId
	 * @param merchantCompany
	 * @param merCompBankDetails
	 */
	@GetMapping(value = "/beneficiary/{compBankId}")
	public ModelAndView viewRefBeneficiary(@PathVariable String compBankId,
			@ModelAttribute("merCompBankDetails") MerCompBankDetails merCompBankDetails, MerCompany merchantCompany,
			BindingResult result) throws BeException {

		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_REFERRAL_PROFILE);
		MerCompBankDetails compBankDetails = getBeService()
				.getCompRefBankDetailsByCompBankId(merCompBankDetails.getCompBankId());
		MerChanSetWrapper merChanSetWrapper = getBeService().getRefChannelByCompRefId(compBankDetails.getCompRefId());
		MerCompany merCompany = getBeService().getCompanyByCompRefId(compBankDetails.getCompRefId());
		LOGGER.info("view beneficiary company bank id = {}", compBankId);
		LOGGER.info("view beneficiary company ref id = {}", compBankDetails.getCompRefId());
		mav.addObject("tab", BENEFICIARY_SETTING);
		mav.addObject(COMP_REF_ID, compBankDetails.getCompRefId());
		mav.addObject(ADD_BEN, ADD_BEN);
		mav.addObject(MERCHANT_COMPANY, merchantCompany);
		mav.addObject(COUNTRY_LIST, staticData.countryList());
		mav.addObject(STATE_LIST, staticData.stateList("MYS"));
		mav.addObject(CITY_LIST, staticData.cityList());
		mav.addObject(MER_COMP_BANK_DETAILS, compBankDetails);
		mav.addObject(COMP_REF_ID, compBankDetails.getCompRefId());
		mav.addObject(CHANNEL_LIST, staticData.channelList());
		mav.addObject(MERCHANT_SET_WRAPPER, merChanSetWrapper);
		mav.addObject(MERCHANT_COMPANY, merCompany);
		return mav;
	}


	/**
	 * to view and update channel setting
	 *
	 * @param compRefId
	 * @param merChanSetWrapper
	 */
	@PostMapping(value = "/{compRefId}", params = "update=saveChnnlSetting")
	public ModelAndView updateChannelSetting(@PathVariable String compRefId,
			@Valid @ModelAttribute(MERCHANT_SET_WRAPPER) MerChanSetWrapper merChanSetWrapper, BindingResult result)
			throws BeException {
		ModelAndView mav = new ModelAndView();
		merChanSetWrapper.setCompRefId(compRefId);
		UserProfile authUser = getCurrentUser();
		merChanSetWrapper.setUserId(authUser.getUserId());
		boolean isUpdated = false;
		if (!result.hasErrors()) {
			try {
				isUpdated = getBeService().updateRefChannelSetting(merChanSetWrapper);
				mav = updatedInfo(compRefId, PageTemplate.TEMP_REFERRAL_PROFILE, "channel_mgmt", "channel-setting");
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		} else {
			mav = updatedInfo(compRefId, PageTemplate.TEMP_MER_CRED, "channel_mgmt", "channel-setting");
			mav.addObject(MERCHANT_SET_WRAPPER, merChanSetWrapper);
		}

		if (isUpdated) {
			mav = updatedInfo(compRefId, PageTemplate.TEMP_REFERRAL_PROFILE, REFERRAL_MGMT, "channelSetting");
			mav.addObject(COMP_REF_ID, compRefId);
			mav.addAllObjects(com.bstsb.util.PopupBox.success("chnlSetting", null,
					messageService.getMessage(MessageConstants.SUCC_UPD_CHNL_SET)));
			LOGGER.info("Successfully create/update multi channel");
		}

		return mav;
	}


	/**
	 * view merchant company all tab
	 *
	 * @param compRefId
	 * @param merCompBankDetails
	 * @param merchantCompany
	 */
	private ModelAndView updatedInfo(String compRefId, String template, String title, String tab) throws BeException {
		ModelAndView mav = getDefaultMav(template, title, null, "beneficiary-setting-script");
		MerCompany merCompany = getBeService().getCompanyByCompRefId(compRefId);
		MerCompBankDetails merCompBankDetails = new MerCompBankDetails();
		merCompBankDetails.setCompRefId(compRefId);
		MerChanSetWrapper merChanSetWrapper = getBeService().getRefChannelByCompRefId(compRefId);
		boolean updateMerchantCompany = !BaseUtil.isObjNull(merCompany.getCompRefId());
		mav.addObject("updateMerchantCompany", updateMerchantCompany);
		mav.addObject(MERCHANT_COMPANY, merCompany);
		mav.addObject(MER_COMP_BANK_DETAILS, merCompBankDetails);
		mav.addObject("tab", tab);
		mav.addObject(COUNTRY_LIST, staticData.countryList());
		mav.addObject(STATE_LIST, staticData.stateList("MYS"));
		mav.addObject(CITY_LIST, staticData.cityList());
		mav.addObject(COMP_REF_ID, compRefId);
		mav.addObject(MERCHANT_SET_WRAPPER, merChanSetWrapper);
		mav.addObject(CHANNEL_LIST, staticData.channelList());
		return mav;
	}


	@PostMapping(value = "/{compRefId}", params = "update=sendCompInfo")
	public ModelAndView sendAccInfo(@PathVariable String compRefId,
			@ModelAttribute("merSendAccInfo") MerSendAccInfo merSendAccInfo, BindingResult result)
			throws BeException {
		getBeService().getMerchantCompanyByCompanyId(compRefId);
		boolean isSent = false;
		if (!result.hasErrors()) {
			try {
				isSent = true;
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
		if (isSent) {
			LOGGER.info("Successfully send account info to merchant");
		}

		return null;
	}

}
