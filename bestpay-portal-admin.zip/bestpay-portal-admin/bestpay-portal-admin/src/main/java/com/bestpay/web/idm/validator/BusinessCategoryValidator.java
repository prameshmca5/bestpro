/**
 * Copyright 2018 Bestinet Sdn Bhd
 */
package com.bestpay.web.idm.validator;


import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.be.sdk.model.MerBusCat;
import com.bestpay.web.core.AbstractController;


/**
 * @author Afif Saman
 * @since July 17, 2018
 */
@Component("businessCategoryValidator")
public class BusinessCategoryValidator extends AbstractController implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return MerBusCat.class.equals(clazz);
	}


	@Override
	public void validate(Object object, Errors errors) {
		// Validate if fields are empty or a whitespace

	}
}
