package com.bestpay.pgw.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwPaymentSetting;
import com.bestpay.pgw.sdk.constants.PgwErrorCodeEnum;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.exception.PgwException;
import com.bestpay.pgw.sdk.model.PgwPaymentSettingDto;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.pgw.service.PgwPaymentSettingService;


/**
 * @author Chaithanya Kumar
 * @since 17/07/2018
 */
@RestController
@RequestMapping(PgwUrlConstants.PAYMENT_SETTING)
public class PgwPaymentSettingRestController extends AbstractRestController {

	@Autowired
	public PgwPaymentSettingService paymentSettingService;


	@GetMapping(value = PgwUrlConstants.FIND_BY_MERCHANT_ID, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwPaymentSettingDto findByMerchantId(@RequestParam(value = "merchantId") String merchantId,
			HttpServletRequest request) {
		PgwPaymentSetting paymentSetting = paymentSettingService.findByMerchantId(merchantId);
		if (!BaseUtil.isObjNull(paymentSetting)) {
			return dozerMapper.map(paymentSetting, PgwPaymentSettingDto.class);
		} else {
			throw new PgwException(PgwErrorCodeEnum.E400PGW012, new String[] { merchantId });
		}
	}

}
