/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author mukhlis.hamzah
 * @since Feb 15, 2019
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class CounterResponse implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -8098897830654742551L;

	private String id;
	
	private String icNo;

	private Date createDate;

	private String certStatus;

	private String status;

	private String activationCode;
	
	private Boolean imageResult;
	
	private String applId;

	

	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public Date getCreateDate() {
		return createDate;
	}


	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}


	public String getCertStatus() {
		return certStatus;
	}


	public void setCertStatus(String certStatus) {
		this.certStatus = certStatus;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getActivationCode() {
		return activationCode;
	}


	public void setActivationCode(String activationCode) {
		this.activationCode = activationCode;
	}


	public String getIcNo() {
		return icNo;
	}


	public void setIcNo(String icNo) {
		this.icNo = icNo;
	}


	public Boolean getImageResult() {
		return imageResult;
	}


	public void setImageResult(Boolean imageResult) {
		this.imageResult = imageResult;
	}


	public String getApplId() {
		return applId;
	}


	public void setApplId(String applId) {
		this.applId = applId;
	}
	
	

}