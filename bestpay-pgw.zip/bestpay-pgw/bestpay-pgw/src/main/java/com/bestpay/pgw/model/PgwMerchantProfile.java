package com.bestpay.pgw.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;

@Entity
@Table(name = "PGW_MERCHANT_PROFILE")
public class PgwMerchantProfile extends AbstractEntity implements Serializable {
	
	private static final long serialVersionUID = -9209662119492823348L;
	
	@Id
	@Column(name="MER_PROF_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer merProfId;
	
	@Column(name="MERCHANT_ID")
	private String merchantId;
	
	@Column(name="COMPANY")
	private String company;
	
	@Column(name="EMAIL")
	private String email;
	
	@Column(name="DOMAIN")
	private String domain;
	
	@Column(name="SALES_PIC")
	private String salesPic;
	
	@Column(name="AC_STATUS")
	private String acStatus;
	
	@Column(name="SUBSCRIPTION_PLAN")
	private String subsPlan;
	
	@Column(name="MONTHLY_CANCEL")
	private Integer monthlyCncl;
	
	@Column(name="MONTHLY_CHARGEBACK")
	private Integer monthlyChrgeback;
	
	@Column(name="TOTAL_CHARGEBACK")
	private Integer totalChrgeback;
	
	@Column(name="HIGHRISK")
	private Integer highrisk;
	
	@Column(name="START_CONTRACT_DATE")
	private Timestamp startCntrcDt;
	
	@Column(name="EXPIRE_DATE")
	private Date expiryDt;
	
	@Column(name="MEMO")
	private String memo;
	
	@Column(name = "CREATE_ID")
	private String createId;
	
	@Column(name = "CREATE_DT")
	private Timestamp createDt;
	
	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "DOC_MGT_ID")
	private String docMgtId;
	
	@Column(name = "OWNER_DIRECTOR_NATIONAL_ID")
	private String ownerDirNationalId;
	
	@Column(name = "OWNER_DIRECTOR_NAME")
	private String ownerDirName;
	
	@Column(name = "COMP_REF_ID")
	private String compRefId;
	
	@Column(name = "BENEFICIARY_ID")
	private String beneficiaryId;
	
	public Integer getMerProfId() {
		return merProfId;
	}

	public void setMerProfId(Integer merProfId) {
		this.merProfId = merProfId;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getSalesPic() {
		return salesPic;
	}

	public void setSalesPic(String salesPic) {
		this.salesPic = salesPic;
	}

	public String getAcStatus() {
		return acStatus;
	}

	public void setAcStatus(String acStatus) {
		this.acStatus = acStatus;
	}

	public String getSubsPlan() {
		return subsPlan;
	}

	public void setSubsPlan(String subsPlan) {
		this.subsPlan = subsPlan;
	}

	public Integer getMonthlyCncl() {
		return monthlyCncl;
	}

	public void setMonthlyCncl(Integer monthlyCncl) {
		this.monthlyCncl = monthlyCncl;
	}

	public Integer getMonthlyChrgeback() {
		return monthlyChrgeback;
	}

	public void setMonthlyChrgeback(Integer monthlyChrgeback) {
		this.monthlyChrgeback = monthlyChrgeback;
	}

	public Integer getTotalChrgeback() {
		return totalChrgeback;
	}

	public void setTotalChrgeback(Integer totalChrgeback) {
		this.totalChrgeback = totalChrgeback;
	}

	public Integer getHighrisk() {
		return highrisk;
	}

	public void setHighrisk(Integer highrisk) {
		this.highrisk = highrisk;
	}

	public Timestamp getStartCntrcDt() {
		return startCntrcDt;
	}

	public void setStartCntrcDt(Timestamp startCntrcDt) {
		this.startCntrcDt = startCntrcDt;
	}

	public Date getExpiryDt() {
		return expiryDt;
	}

	public void setExpiryDt(Date expiryDt) {
		this.expiryDt = expiryDt;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getDocMgtId() {
		return docMgtId;
	}

	public void setDocMgtId(String docMgtId) {
		this.docMgtId = docMgtId;
	}

	public String getOwnerDirNationalId() {
		return ownerDirNationalId;
	}

	public void setOwnerDirNationalId(String ownerDirNationalId) {
		this.ownerDirNationalId = ownerDirNationalId;
	}

	public String getOwnerDirName() {
		return ownerDirName;
	}

	public void setOwnerDirName(String ownerDirName) {
		this.ownerDirName = ownerDirName;
	}

	public String getCompRefId() {
		return compRefId;
	}

	public void setCompRefId(String compRefId) {
		this.compRefId = compRefId;
	}

	public String getBeneficiaryId() {
		return beneficiaryId;
	}

	public void setBeneficiaryId(String beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}


}
