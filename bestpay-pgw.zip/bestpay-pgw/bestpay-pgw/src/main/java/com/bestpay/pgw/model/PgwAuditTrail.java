/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bestpay.pgw.core.AbstractEntity;


/**
 * @author Chaithanya
 * @since 06/07/2018
 */
@Entity
@Table(name = "PGW_AUDIT_TRAIL")
public class PgwAuditTrail extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -3186445980890420147L;

	@Id
	@Column(name = "AUDIT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@Column(name = "MESSAGE_ID")
	private String messageId;

	@Column(name = "REF_NO")
	private String refNo;

	@Column(name = "ORDER_ID")
	private String orderId;

	@Column(name = "REQ_DATA")
	private String reqData;

	@Column(name = "TXN_NO")
	private String txnNo;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Transient
	private Timestamp updateDt;

	@Transient
	private String updateId;


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getMessageId() {
		return messageId;
	}


	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}


	public String getRefNo() {
		return refNo;
	}


	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public String getReqData() {
		return reqData;
	}


	public void setReqData(String reqData) {
		this.reqData = reqData;
	}


	public String getTxnNo() {
		return txnNo;
	}


	public void setTxnNo(String txnNo) {
		this.txnNo = txnNo;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public void setId(int id) {
		this.id = id;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
