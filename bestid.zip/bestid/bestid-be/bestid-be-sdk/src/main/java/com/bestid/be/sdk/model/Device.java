/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author mary.jane
 * @since Nov 12, 2018
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Device implements Serializable {

	private static final long serialVersionUID = -4910741561295224472L;

	private Integer deviceId;

	private Integer userId;

	private String machineId;

	private String sdkVersion;

	private String model;

	private String brand;

	private String manufacturer;

	private String geoLocation;

	private String status;

	private String certStatus;

	private String isCertInstall;

	private String mobileNo;

	private String email;

	private String uuid;

	private Timestamp uuidExpDt;


	public Device() {
		// DO NOTHING
	}


	public String getMachineId() {
		return machineId;
	}


	public void setMachineId(String machineId) {
		this.machineId = machineId;
	}


	public String getSdkVersion() {
		return sdkVersion;
	}


	public void setSdkVersion(String sdkVersion) {
		this.sdkVersion = sdkVersion;
	}


	public String getModel() {
		return model;
	}


	public void setModel(String model) {
		this.model = model;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getManufacturer() {
		return manufacturer;
	}


	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}


	public String getGeoLocation() {
		return geoLocation;
	}


	public void setGeoLocation(String geoLocation) {
		this.geoLocation = geoLocation;
	}


	public Integer getDeviceId() {
		return deviceId;
	}


	public void setDeviceId(Integer deviceId) {
		this.deviceId = deviceId;
	}


	public Integer getUserId() {
		return userId;
	}


	public void setUserId(Integer userId) {
		this.userId = userId;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getCertStatus() {
		return certStatus;
	}


	public void setCertStatus(String certStatus) {
		this.certStatus = certStatus;
	}


	public String getIsCertInstall() {
		return isCertInstall;
	}


	public void setIsCertInstall(String isCertInstall) {
		this.isCertInstall = isCertInstall;
	}


	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getUuid() {
		return uuid;
	}


	public void setUuid(String uuid) {
		this.uuid = uuid;
	}


	public Timestamp getUuidExpDt() {
		return uuidExpDt;
	}


	public void setUuidExpDt(Timestamp uuidExpDt) {
		this.uuidExpDt = uuidExpDt;
	}

}
