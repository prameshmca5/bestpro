/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.be.service;


import java.io.IOException;
import java.util.Comparator;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BePaymentBreakdownQf;
import com.be.dao.BePaymentBreakdownRepository;
import com.be.model.BePaymentBreakdown;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.PaymentBreakdown;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;


/**
 * @author mohd.naem
 * @since March 31 , 2021
 */
@Service(QualifierConstants.BE_PAYMENT_BREAKDOWN_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_PAYMENT_BREAKDOWN_SVC)
@Transactional
public class BePaymentBreakdownService extends AbstractService<BePaymentBreakdown> {

	protected static Logger logger = LoggerFactory.getLogger(BePaymentBreakdownService.class);

	@Autowired
	private BePaymentBreakdownRepository bePaymentBreakdownDao;

	@Autowired
	private BePaymentBreakdownQf bePaymentBreakdownQf;


	@Override
	public GenericRepository<BePaymentBreakdown> primaryDao() {
		return bePaymentBreakdownDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return null;
	}


	@SuppressWarnings("unchecked")
	public List<PaymentBreakdown> searchPagination(PaymentBreakdown dto, DataTableRequest<?> dataTableInRQ)
			throws IOException {
		return JsonUtil.transferToList(bePaymentBreakdownQf.searchAllByProperty(dto, dataTableInRQ),
				PaymentBreakdown.class);
	}


	@SuppressWarnings("unchecked")
	public PaymentBreakdown search(PaymentBreakdown dto) throws IOException {
		List<BePaymentBreakdown> bePaymentBreakdownList = bePaymentBreakdownQf.searchAllByProperty(dto, null);
		PaymentBreakdown payment = null;
		if (!BaseUtil.isListNull(bePaymentBreakdownList)) {
			BePaymentBreakdown bePaymentBreakdown = bePaymentBreakdownList.stream()
					.sorted(Comparator.comparingInt(BePaymentBreakdown::getPmtBreakdownId).reversed()).findFirst()
					.orElse(null);
			if (!BaseUtil.isObjNull(bePaymentBreakdown)) {
				payment = JsonUtil.transferToObject(bePaymentBreakdown, PaymentBreakdown.class);
			}
		}
		return payment;
	}
}