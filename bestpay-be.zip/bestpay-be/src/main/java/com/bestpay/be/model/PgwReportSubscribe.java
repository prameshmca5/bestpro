/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@Entity
@Table(name = "PGW_REPORT_SUBSCRIBE")
public class PgwReportSubscribe extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "RPT_SUB_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer rptSubId;

	@Column(name = "MERCHANT_ID")
	private String merchantId;

	@Column(name = "SETUP_DATE")
	private Timestamp setupDate;

	@Column(name = "EMAIL_PROFILE")
	private String emailProfile;

	@Column(name = "EMAIL_TO")
	private String emailTo;

	@Column(name = "EMAIL_CC")
	private String emailCc;

	@Column(name = "EMAIL_BCC")
	private String emailBcc;

	@Column(name = "REPORT_NAME")
	private String reportName;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "FREQ_H")
	private Integer freqH;

	@Column(name = "FREQ_D")
	private Integer freqD;

	@Column(name = "FREQ_W")
	private Integer freqW;

	@Column(name = "FREQ_M")
	private Integer freqM;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public PgwReportSubscribe() {
		// pgwReportSubscribe backend model
	}


	public Integer getRptSubId() {
		return rptSubId;
	}


	public void setRptSubId(Integer rptSubId) {
		this.rptSubId = rptSubId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public Timestamp getSetupDate() {
		return setupDate;
	}


	public void setSetupDate(Timestamp setupDate) {
		this.setupDate = setupDate;
	}


	public String getEmailProfile() {
		return emailProfile;
	}


	public void setEmailProfile(String emailProfile) {
		this.emailProfile = emailProfile;
	}


	public String getEmailTo() {
		return emailTo;
	}


	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}


	public String getEmailCc() {
		return emailCc;
	}


	public void setEmailCc(String emailCc) {
		this.emailCc = emailCc;
	}


	public String getEmailBcc() {
		return emailBcc;
	}


	public void setEmailBcc(String emailBcc) {
		this.emailBcc = emailBcc;
	}


	public String getReportName() {
		return reportName;
	}


	public void setReportName(String reportName) {
		this.reportName = reportName;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Integer getFreqH() {
		return freqH;
	}


	public void setFreqH(Integer freqH) {
		this.freqH = freqH;
	}


	public Integer getFreqD() {
		return freqD;
	}


	public void setFreqD(Integer freqD) {
		this.freqD = freqD;
	}


	public Integer getFreqW() {
		return freqW;
	}


	public void setFreqW(Integer freqW) {
		this.freqW = freqW;
	}


	public Integer getFreqM() {
		return freqM;
	}


	public void setFreqM(Integer freqM) {
		this.freqM = freqM;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}