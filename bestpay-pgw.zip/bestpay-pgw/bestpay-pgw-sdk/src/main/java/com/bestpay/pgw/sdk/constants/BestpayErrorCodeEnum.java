/**
 *
 */
package com.bestpay.pgw.sdk.constants;


/**
 * @author muhammad.hafidz
 * @since 27/7/2018 note: difference PgwErrorCodeEnum (int, String) |
 *        BestpayErrorCodeEnum (String, String)
 */
public enum BestpayErrorCodeEnum {
	BP00001("BP00001", "Missing required parameters"),
	BP00002("BP00002", "Merchant info not found"),
	BP00003("BP00003", "Merchant account issue. Please contact merchant"),
	// BP00004("BP00004", "System is busy now, temporary out of services.
	// Please try later"), // txn
	// blocked
	// due
	// to
	// mass
	// connection
	BP00005("BP00005", "Payment info incorrect"), // reqhash unmatch
	BP00006("BP00006", "This account doesn't authorize to use this channel"), // reqhash
																// unmatch
	BP00007("BP00007", "Currency unsupported"),
	BP00008("BP00008", "Transaction amount must less than maximum limit"),
	BP00009("BP00009", "Transaction amount must more than minimum limit"),
	BP00010("BP00010", "Not allow to process"),
	BP00011("BP00011", "Your request is not valid"), // Processor gateway
											// config not found
	BP00012("BP00012", "Your credit card number or expiration date is not valid"),
	// BP00013("BP00013", "System is busy now, temporary out of services.
	// Please try later"), // Insert
	// transaction
	// error
	BP00014("BP00014", "Payment timeout"), // Insert transaction error
	BP00015("BP00015", "Transaction info not found"),
	BP00016("BP00016", "Amount from bank do not match"),
	BP00017("BP00017", "Signature from bank not match"),
	// BP00018("BP00018", "System is busy now, temporary out of services.
	// Please try later"), // Update
	// transaction
	// status
	// error
	BP00019("BP00019", "System is busy now, temporary out of services"), // Attempt
															// to
															// update
															// non
															// pending
															// status
	BP00020("BP00020", "System is busy now, payment receipt cannot be shown. Please try later"), // openssl_decrypt
																				// failed
	BP00021("BP00021", "The system have detected that the your IP provided is blacklisted in the server"),
	BP00022("BP00022", "System is busy now, temporary out of services. Please try later "), // Update
																			// transaction
																			// error
	BP00023("BP00023", "Session ID from bank do not match"),
	BP00024("BP00024", "Your card number not valid"),
	BP00025("BP00025", "Your order id is already exist. Please contact your merchant"),
	BP00026("BP00026", "Transaction timeout"),
	BP00027("BP00027", "Merchant Id not match"),
	BP00028("BP00028", "Order Id not match"),
	BP00029("BP00029", "Currency not match"),
	BP00031("BP00031", "Hash not match"),
	BP00032("BP00032", "Transaction Error"),
	BP00033("BP00033", "Pending Authorization"),
	BP00034("BP00034", "Buyer Cancel Transaction"),
	BP00035("BP00035", "Invalid Bank"),
	BP00036("BP00036", "Maximum Transaction Limit Exceeded"),
	BP00037("BP00037", "Insufficient Funds"),
	BP00038("BP00038", "Transaction Not Permitted"),
	BP00039("BP00039", "Bank Code is null"),
	BP00040("BP00040", "Bank Code not match"),
	BP00041("BP00041", "Id No is null"),
	ERRPGW0500("500", " System is down ,Contact Administrator"),;

	private final String code;

	private final String message;


	BestpayErrorCodeEnum(String code, String message) {
		this.code = code;
		this.message = message;
	}


	public static BestpayErrorCodeEnum findByName(String name) {
		for (BestpayErrorCodeEnum v : BestpayErrorCodeEnum.values()) {
			if (v.name().equals(name)) {
				return v;
			}
		}

		return null;
	}


	public static String findInternalCode(String name) {
		for (BestpayErrorCodeEnum v : BestpayErrorCodeEnum.values()) {
			if (v.name().equals(name)) {
				return v.getCode();
			}
		}

		return null;
	}


	public String getMessage() {
		return message;
	}


	public String getCode() {
		return code;
	}

}
