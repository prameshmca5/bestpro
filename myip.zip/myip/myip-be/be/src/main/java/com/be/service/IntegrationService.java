/**
 *
 */
package com.be.service;


import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.be.client.IntegrationServiceClient;
import com.be.constants.QualifierConstants;
import com.be.model.BeConfig;
import com.be.sdk.constants.BeConfigConstants;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeServiceConstants;
import com.be.sdk.constants.RegulaFieldEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.DigitalSigning;
import com.be.sdk.model.IntegrationResponse;
import com.be.sdk.model.MRZdata;
import com.fasterxml.jackson.databind.JsonNode;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.JsonUtil;
import com.util.UidGenerator;
import com.util.constants.BaseConstants;


/**
 * @author michelle.angela
 *
 */
@Service(QualifierConstants.INTEGRATION_SVC)
@Qualifier(QualifierConstants.INTEGRATION_SVC)
public class IntegrationService {

	@Value("${" + BeConfigConstants.ACCURA_API_KEY + "}")
	private String apiKey;

	@Value("${" + BeConfigConstants.REGULA_X_TOKEN + "}")
	private String xToken;

	private static final Logger LOGGER = LoggerFactory.getLogger(IntegrationService.class);

	public IntegrationServiceClient integrationServiceClient;

	@Autowired
	BeConfigService beConfigSvc;


	public IntegrationServiceClient getIntegrationServiceClient() {
		if (BaseUtil.isObjNull(integrationServiceClient)) {
			integrationServiceClient = new IntegrationServiceClient("");
		}
		integrationServiceClient.setMessageId(UidGenerator.getMessageId());
		return integrationServiceClient;
	}


	public DigitalSigning docDigitalSigning(byte[] pdfByte, String fileName, String docType) throws Exception {
		BeConfig url = beConfigSvc.findByConfigCode(BeServiceConstants.URL_DIGI_SIGN);
		if (BaseUtil.isObjNull(url)) {
			throw new BeException(BeErrorCodeEnum.E400C004);
		}

		DigitalSigning dto = new DigitalSigning();
		dto.setContent(pdfByte);
		dto.setFileName(fileName);
		dto.setDocType(docType);
		LOGGER.info("pdfByte====={}", pdfByte);
		LOGGER.info("URL = {}", url.getConfigVal());
		return getIntegrationServiceClient().postForObject(url.getConfigVal(), dto, DigitalSigning.class);
	}


	public MRZdata readPassport(MRZdata dto) throws Exception {
		BeConfig url = beConfigSvc.findByConfigCode(BeServiceConstants.URL_ACCURA);
		if (BaseUtil.isObjNull(url)) {
			throw new BeException(BeErrorCodeEnum.E400C004);
		}
		LOGGER.info("URL = {}", url.getConfigVal());
		IntegrationResponse resp = getIntegrationServiceClient().postForObjectResp(url.getConfigVal(), dto,
				IntegrationResponse.class, apiKey);
		if (!BaseUtil.isObjNull(resp)) {
			if (BaseUtil.isEquals(resp.getStatus(), "Fail")) {
				throw new BeException(resp.getMessage());
			} else {
				LOGGER.info("REQUEST====={}", JsonUtil.objectMapper().valueToTree(resp.getData().getMrzData()));
				dto = resp.getData().getMrzData();
			}
		}
		return dto;
	}


	public MRZdata readPassportRegula(MRZdata dto) throws Exception {

		BeConfig urlSub = beConfigSvc.findByConfigCode(BeServiceConstants.URL_REGULA_SUB);
		BeConfig urlGet = beConfigSvc.findByConfigCode(BeServiceConstants.URL_REGULA_GET);
		BeConfig mrzConfig = beConfigSvc.findByConfigCode(BeServiceConstants.REGULA_TYPE);

		if (BaseUtil.isObjNull(urlSub) || BaseUtil.isObjNull(urlGet) || BaseUtil.isObjNull(mrzConfig)) {
			throw new BeException(BeErrorCodeEnum.E400C004);
		}

		List<MRZdata> mrZdatas = new ArrayList<>();
		mrZdatas.add(dto);
		Map<String, String> headers = new HashMap<>();
		headers.put("X-Token", xToken);
		String resp = getIntegrationServiceClient().postForObjectResp(urlSub.getConfigVal(), mrZdatas, String.class,
				headers);

		if (!BaseUtil.isObjNull(resp)) {

			JsonNode[] obj = getIntegrationServiceClient().getForObject(
					MessageFormat.format(urlGet.getConfigVal(), resp, Integer.parseInt(mrzConfig.getConfigVal())),
					JsonNode[].class, headers);

			JsonNode fields = obj[0].get("ListVerifiedFields");

			if (!BaseUtil.isObjNull(fields) && !BaseUtil.isObjNull(fields.get("pFieldMaps"))) {
				if (fields.get("pFieldMaps").isArray()) {
					LOGGER.info("REQUEST====={}", JsonUtil.objectMapper().valueToTree(fields.get("pFieldMaps")));
					Map<String, Object> fieldMap = new HashMap<>();
					for (JsonNode arrayElement : fields.get("pFieldMaps")) {
						String fieldName = RegulaFieldEnum.findFieldByCode(arrayElement.get("FieldType").asInt());
						if (!BaseUtil.isObjNull(fieldName)) {
							if (!BaseUtil.isObjNull(arrayElement.get("Field_MRZ"))) {
								fieldMap.put(fieldName, arrayElement.get("Field_MRZ").asText());
							} else if (!BaseUtil.isObjNull(arrayElement.get("Field_Visual"))) {
								fieldMap.put(fieldName, arrayElement.get("Field_Visual").asText());
							}
						}
					}
					dto = JsonUtil.transferToObject(JsonUtil.convertMapToJson(fieldMap), MRZdata.class);
					Date dob = new SimpleDateFormat("MM/dd/yyyy").parse(dto.getDob());
					Date expiryDt = new SimpleDateFormat("MM/dd/yyyy").parse(dto.getExpiryDate());
					dto.setDob(DateUtil.convertDate(dob, BaseConstants.DT_DD_MM_YYYY_SLASH));
					dto.setExpiryDate(DateUtil.convertDate(expiryDt, BaseConstants.DT_DD_MM_YYYY_SLASH));
				}
			} else {
				dto = new MRZdata();
			}
		}
		return dto;
	}
}
