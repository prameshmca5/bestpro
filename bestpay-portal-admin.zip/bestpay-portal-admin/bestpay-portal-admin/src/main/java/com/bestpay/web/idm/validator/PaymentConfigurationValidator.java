package com.bestpay.web.idm.validator;


import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.be.sdk.model.PaymentConfig;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ValidationUtil;


@Component("paymentConfigurationValidator")
public class PaymentConfigurationValidator extends AbstractController implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}


	@Override
	public void validate(Object object, Errors errors) {

		if (object instanceof PaymentConfig) {
			// Validate if fields are empty or a whitespace
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "configCode", MessageConstants.ERROR_FIELDS_CODE);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "configDesc", MessageConstants.ERROR_FIELDS_DESC);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "configVal", MessageConstants.ERROR_FIELDS_VAL);
		}

	}

}
