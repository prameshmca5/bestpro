/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.be.core.AbstractEntity;
import com.be.sdk.model.ConfigTripHealth;
import com.be.sdk.model.IQfCriteria;


/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_CONFIG_TRIP_HEALTH")
public class BeConfigTripHealth extends AbstractEntity implements Serializable, IQfCriteria<ConfigTripHealth> {

	private static final long serialVersionUID = -528839696303240902L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TRIP_HEALTH_ID")
	private Integer tripHealthId;

	@Column(name = "TRIP_HEALTH_DESC")
	private String tripHealthDesc;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "STATUS")
	private Boolean isActive;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;


	public Integer getTripHealthId() {
		return tripHealthId;
	}


	public void setTripHealthId(Integer tripHealthId) {
		this.tripHealthId = tripHealthId;
	}


	public String getTripHealthDesc() {
		return tripHealthDesc;
	}


	public void setTripHealthDesc(String tripHealthDesc) {
		this.tripHealthDesc = tripHealthDesc;
	}


	public Boolean getIsActive() {
		return isActive;
	}


	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
}
