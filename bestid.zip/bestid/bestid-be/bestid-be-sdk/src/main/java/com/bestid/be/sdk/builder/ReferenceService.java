/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.builder;


import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bestid.be.sdk.client.BeRestTemplate;
import com.bestid.be.sdk.constants.BeCacheConstants;
import com.bestid.be.sdk.constants.BeUrlConstants;
import com.bestid.be.sdk.model.City;
import com.bestid.be.sdk.model.Config;
import com.bestid.be.sdk.model.Country;
import com.bestid.be.sdk.model.Documents;
import com.bestid.be.sdk.model.Gender;
import com.bestid.be.sdk.model.MaritalStatus;
import com.bestid.be.sdk.model.Nationality;
import com.bestid.be.sdk.model.RefDocuments;
import com.bestid.be.sdk.model.RefEmbedRequest;
import com.bestid.be.sdk.model.RefEmbedResponse;
import com.bestid.be.sdk.model.RelationShip;
import com.bestid.be.sdk.model.State;
import com.bestid.be.sdk.model.StaticList;
import com.bestid.be.sdk.model.Status;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.constants.BaseConstants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
public class ReferenceService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public ReferenceService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	public boolean evict() {
		return evict(null);
	}


	public boolean evict(String prefixKey) {
		StringBuilder sbUrl = new StringBuilder();
		sbUrl.append(BeUrlConstants.REFERENCE).append("/evict");
		if (!BaseUtil.isObjNull(prefixKey)) {
			sbUrl.append("?prefixKey=" + prefixKey);
		}

		return restTemplate().getForObject(getServiceURI(sbUrl.toString()), boolean.class);
	}


	@SuppressWarnings("unchecked")
	public Map<String, String> findAllConfig() {
		return restTemplate().getForObject(getServiceURI(BeUrlConstants.REFERENCE + BeUrlConstants.CONFIG),
				HashMap.class);
	}


	public List<Config> findEqmConfig() {
		Config[] svcResp = restTemplate().getForObject(BeUrlConstants.CONFIG, Config[].class);
		return Arrays.asList(svcResp);
	}


	public List<Config> findEqmConfig(String configAgency) {
		StringBuilder sbUrl = new StringBuilder();
		sbUrl.append(BeUrlConstants.CONFIG).append("/{configAgency}");

		Map<String, Object> params = new HashMap<>();
		params.put("configAgency", configAgency);

		Config[] svcResp = restTemplate().getForObject(sbUrl.toString(), Config[].class, params);
		return Arrays.asList(svcResp);
	}


	public List<Country> getRefCountryLst() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_COUNTRY);
		Country[] refStats = restTemplate().getForObject(getServiceURI(sb.toString()), Country[].class);
		return Arrays.asList(refStats);
	}


	public List<City> findByAllCities() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_CITY);
		City[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), City[].class);
		return Arrays.asList(svcResp);
	}


	// find city
	public City findByCityCode(String cityCode) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_CITY);
		sb.append(BaseConstants.SLASH + cityCode);
		return restTemplate().getForObject(getServiceURI(sb.toString()), City.class);
	}


	public List<RefDocuments> getRefDocLst() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE + "/refDocList");
		RefDocuments[] refStats = restTemplate().getForObject(getServiceURI(sb.toString()), RefDocuments[].class);
		return Arrays.asList(refStats);
	}


	// list status
	public List<Status> findByAllStatus() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_STATUS);
		Status[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), Status[].class);
		return Arrays.asList(svcResp);
	}


	// find status
	public Status findByStatusCode(String statusCode) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_STATUS);
		sb.append(BaseConstants.SLASH + statusCode);
		return restTemplate().getForObject(getServiceURI(sb.toString()), Status.class);
	}


	public StaticList all() {
		StringBuilder sbUrl = new StringBuilder();
		sbUrl.append(BeUrlConstants.REFERENCE);
		StaticList svcResp = restTemplate().getForObject(getServiceURI(sbUrl.toString()), StaticList.class);
		return svcResp;
	}


	// list relation
	public List<RelationShip> findAllRelationShips() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_RELATION);
		RelationShip[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), RelationShip[].class);
		return Arrays.asList(svcResp);
	}


	public RelationShip findByRelationshipCode(String relationCode) {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_RELATION);
		sb.append(BaseConstants.SLASH + relationCode);

		RelationShip relationship = restTemplate().getForObject(getServiceURI(sb.toString()), RelationShip.class);

		return relationship;
	}


	// list of state
	public List<State> findAllState() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_STATE);
		State[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), State[].class);
		return Arrays.asList(svcResp);
	}


	public State findByStateCode(String stateCode) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_STATE);
		sb.append(BaseConstants.SLASH + stateCode);
		return restTemplate().getForObject(getServiceURI(sb.toString()), State.class);
	}


	// list of state with countries
	public List<Country> allCountry() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_COUNTRY);

		Country[] countryArray = restTemplate().getForObject(getServiceURI(sb.toString()), Country[].class);
		List<Country> countryList = Arrays.asList(countryArray);
		return countryList;
	}


	// list of nationality
	public List<Nationality> findAllNationality() {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_NATIONALITY);

		Nationality[] nationalityArray = restTemplate().getForObject(getServiceURI(sb.toString()),
				Nationality[].class);

		List<Nationality> nationalityList = Arrays.asList(nationalityArray);
		return nationalityList;
	}


	// nationality by code
	public Nationality findByNationalityCode(String ntnltyCode) {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_NATIONALITY);
		sb.append(BaseConstants.SLASH + ntnltyCode);

		Nationality nationality = restTemplate().getForObject(getServiceURI(sb.toString()), Nationality.class);

		return nationality;
	}


	public Nationality findNationalityByDesc(String ntnltyDescEn) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_NATIONALITY);
		sb.append("/" + ntnltyDescEn);
		return restTemplate().getForObject(getServiceURI(sb.toString()), Nationality.class);
	}


	public List<Status> getAllStatus() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_STATUS);
		Status[] statusArray = restTemplate().getForObject(getServiceURI(sb.toString()), Status[].class);
		return Arrays.asList(statusArray);
	}


	public RefEmbedResponse getRrefData(RefEmbedRequest refEmbedRequest) {
		return restTemplate().postForObject(getServiceURI(BeUrlConstants.REFERENCE + "/refData"), refEmbedRequest,
				RefEmbedResponse.class);
	}


	// list of marital status
	public List<MaritalStatus> findAllMaritalStatus() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_STATUS);

		MaritalStatus[] maritalStatusArray = restTemplate().getForObject(getServiceURI(sb.toString()),
				MaritalStatus[].class);

		List<MaritalStatus> maritalStatusList = Arrays.asList(maritalStatusArray);
		return maritalStatusList;
	}


	// marital status by code
	public MaritalStatus findByMaritalStatusCode(String maritalStatusCode) {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_STATUS);
		sb.append(BaseConstants.SLASH + maritalStatusCode);

		MaritalStatus maritalStatus = restTemplate().getForObject(getServiceURI(sb.toString()), MaritalStatus.class);

		return maritalStatus;
	}


	// list city by code
	public List<City> findAllCityCode() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_CITY);
		City[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), City[].class);
		return Arrays.asList(svcResp);
	}


	// list all documents
	public List<Documents> findAllDocuments() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_DOCUMENT);
		Documents[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), Documents[].class);
		return Arrays.asList(svcResp);
	}


	public Documents findByDocId(String trxnNo) {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_DOCUMENT);
		sb.append(BaseConstants.SLASH + trxnNo);

		Documents documents = restTemplate().getForObject(getServiceURI(sb.toString()), Documents.class);

		return documents;
	}


	// list all ref documents
	public List<RefDocuments> findAllRefDoc() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_DOCUMENT);
		RefDocuments[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), RefDocuments[].class);
		return Arrays.asList(svcResp);
	}


	public RefDocuments findByRefDocId(Integer docId) {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_DOCUMENT);
		sb.append(BaseConstants.SLASH + docId);

		RefDocuments refDocuments = restTemplate().getForObject(getServiceURI(sb.toString()), RefDocuments.class);

		return refDocuments;
	}


	// list of gender
	public List<Gender> findAllGenders() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_GENDER);
		Gender[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), Gender[].class);
		return Arrays.asList(svcResp);
	}


	public Gender findByGenderCd(String genderCd) {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_GENDER);
		sb.append(BaseConstants.SLASH + genderCd);

		Gender gender = restTemplate().getForObject(getServiceURI(sb.toString()), Gender.class);

		return gender;
	}


	public List<Country> findAllCountry() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_COUNTRY);
		Country[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), Country[].class);
		return Arrays.asList(svcResp);
	}


	public Country findByCountryCd(String cntryCode) {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_COUNTRY);
		sb.append(BaseConstants.SLASH + cntryCode);

		Country country = restTemplate().getForObject(getServiceURI(sb.toString()), Country.class);

		return country;
	}


	public List<Status> findAllStatus() {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_STATUS);
		Status[] svcResp = restTemplate().getForObject(getServiceURI(sb.toString()), Status[].class);
		return Arrays.asList(svcResp);
	}


	public Status findByStatusCd(String statusCode) {

		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BaseConstants.SLASH + BeCacheConstants.REF_TYP_STATUS);
		sb.append(BaseConstants.SLASH + statusCode);

		Status statusCd = restTemplate().getForObject(getServiceURI(sb.toString()), Status.class);

		return statusCd;
	}

}