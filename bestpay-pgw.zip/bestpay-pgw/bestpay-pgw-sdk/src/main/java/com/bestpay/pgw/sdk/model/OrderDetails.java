
package com.bestpay.pgw.sdk.model;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id", "username", "customerName", "location", "locationName", "orderDate", "status",
		"customerStatus", "product", "pin", "items", "itemCount", "total", "receipts", "totalPaid", "receiptCount",
		"fullyPaid", "amountRemaining", "type", "fee", "tax", "cost", "taxPct", "beneficiary",
		"beneficiaryBankAccount", "beneficiaryRealTime", "taxInvoiceNo", "channelType", "orderOriginatingIP",
		"promoDiscount", "promoCodeName", "deliveryFees", "earthPortPaymentStatusCode", "created", "updated",
		"createdBy", "updatedBy" })
public class OrderDetails {

	@JsonProperty("id")
	private String id;

	@JsonProperty("username")
	private String username;

	@JsonProperty("customerName")
	private String customerName;

	@JsonProperty("location")
	private String location;

	@JsonProperty("locationName")
	private String locationName;

	@JsonProperty("orderDate")
	private String orderDate;

	@JsonProperty("status")
	private String status;

	@JsonProperty("customerStatus")
	private String customerStatus;

	@JsonProperty("product")
	private String product;

	@JsonProperty("pin")
	private String pin;

	@JsonProperty("items")
	private List<Item> items = null;

	@JsonProperty("itemCount")
	private String itemCount;

	@JsonProperty("total")
	private String total;

	@JsonProperty("receipts")
	private Receipts receipts;

	@JsonProperty("totalPaid")
	private String totalPaid;

	@JsonProperty("receiptCount")
	private String receiptCount;

	@JsonProperty("fullyPaid")
	private String fullyPaid;

	@JsonProperty("amountRemaining")
	private String amountRemaining;

	@JsonProperty("type")
	private String type;

	@JsonProperty("fee")
	private String fee;

	@JsonProperty("tax")
	private String tax;

	@JsonProperty("cost")
	private String cost;

	@JsonProperty("taxPct")
	private String taxPct;

	@JsonProperty("beneficiary")
	private Beneficiary beneficiary;

	@JsonProperty("beneficiaryBankAccount")
	private String beneficiaryBankAccount;

	@JsonProperty("beneficiaryRealTime")
	private String beneficiaryRealTime;

	@JsonProperty("taxInvoiceNo")
	private String taxInvoiceNo;

	@JsonProperty("channelType")
	private String channelType;

	@JsonProperty("orderOriginatingIP")
	private String orderOriginatingIP;

	@JsonProperty("promoDiscount")
	private String promoDiscount;

	@JsonProperty("promoCodeName")
	private String promoCodeName;

	@JsonProperty("deliveryFees")
	private String deliveryFees;

	@JsonProperty("earthPortPaymentStatusCode")
	private String earthPortPaymentStatusCode;

	@JsonProperty("created")
	private String created;

	@JsonProperty("updated")
	private String updated;

	@JsonProperty("createdBy")
	private String createdBy;

	@JsonProperty("updatedBy")
	private String updatedBy;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<>();

	private String pid;

	private String currencyCode;

	private Float amount;

	private Boolean feeoption;

	private String beneficiaryId;

	private String beneficiaryBankLocation;

	private String webLink;


	@JsonProperty("id")
	public String getId() {
		return id;
	}


	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}


	@JsonProperty("username")
	public String getUsername() {
		return username;
	}


	@JsonProperty("username")
	public void setUsername(String username) {
		this.username = username;
	}


	@JsonProperty("customerName")
	public String getCustomerName() {
		return customerName;
	}


	@JsonProperty("customerName")
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	@JsonProperty("location")
	public String getLocation() {
		return location;
	}


	@JsonProperty("location")
	public void setLocation(String location) {
		this.location = location;
	}


	@JsonProperty("locationName")
	public String getLocationName() {
		return locationName;
	}


	@JsonProperty("locationName")
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}


	@JsonProperty("orderDate")
	public String getOrderDate() {
		return orderDate;
	}


	@JsonProperty("orderDate")
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}


	@JsonProperty("status")
	public String getStatus() {
		return status;
	}


	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}


	@JsonProperty("customerStatus")
	public String getCustomerStatus() {
		return customerStatus;
	}


	@JsonProperty("customerStatus")
	public void setCustomerStatus(String customerStatus) {
		this.customerStatus = customerStatus;
	}


	@JsonProperty("product")
	public String getProduct() {
		return product;
	}


	@JsonProperty("product")
	public void setProduct(String product) {
		this.product = product;
	}


	@JsonProperty("pin")
	public String getPin() {
		return pin;
	}


	@JsonProperty("pin")
	public void setPin(String pin) {
		this.pin = pin;
	}


	@JsonProperty("items")
	public List<Item> getItems() {
		return items;
	}


	@JsonProperty("items")
	public void setItems(List<Item> items) {
		this.items = items;
	}


	@JsonProperty("itemCount")
	public String getItemCount() {
		return itemCount;
	}


	@JsonProperty("itemCount")
	public void setItemCount(String itemCount) {
		this.itemCount = itemCount;
	}


	@JsonProperty("total")
	public String getTotal() {
		return total;
	}


	@JsonProperty("total")
	public void setTotal(String total) {
		this.total = total;
	}


	@JsonProperty("receipts")
	public Receipts getReceipts() {
		return receipts;
	}


	@JsonProperty("receipts")
	public void setReceipts(Receipts receipts) {
		this.receipts = receipts;
	}


	@JsonProperty("totalPaid")
	public String getTotalPaid() {
		return totalPaid;
	}


	@JsonProperty("totalPaid")
	public void setTotalPaid(String totalPaid) {
		this.totalPaid = totalPaid;
	}


	@JsonProperty("receiptCount")
	public String getReceiptCount() {
		return receiptCount;
	}


	@JsonProperty("receiptCount")
	public void setReceiptCount(String receiptCount) {
		this.receiptCount = receiptCount;
	}


	@JsonProperty("fullyPaid")
	public String getFullyPaid() {
		return fullyPaid;
	}


	@JsonProperty("fullyPaid")
	public void setFullyPaid(String fullyPaid) {
		this.fullyPaid = fullyPaid;
	}


	@JsonProperty("amountRemaining")
	public String getAmountRemaining() {
		return amountRemaining;
	}


	@JsonProperty("amountRemaining")
	public void setAmountRemaining(String amountRemaining) {
		this.amountRemaining = amountRemaining;
	}


	@JsonProperty("type")
	public String getType() {
		return type;
	}


	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}


	@JsonProperty("fee")
	public String getFee() {
		return fee;
	}


	@JsonProperty("fee")
	public void setFee(String fee) {
		this.fee = fee;
	}


	@JsonProperty("tax")
	public String getTax() {
		return tax;
	}


	@JsonProperty("tax")
	public void setTax(String tax) {
		this.tax = tax;
	}


	@JsonProperty("cost")
	public String getCost() {
		return cost;
	}


	@JsonProperty("cost")
	public void setCost(String cost) {
		this.cost = cost;
	}


	@JsonProperty("taxPct")
	public String getTaxPct() {
		return taxPct;
	}


	@JsonProperty("taxPct")
	public void setTaxPct(String taxPct) {
		this.taxPct = taxPct;
	}


	@JsonProperty("beneficiary")
	public Beneficiary getBeneficiary() {
		return beneficiary;
	}


	@JsonProperty("beneficiary")
	public void setBeneficiary(Beneficiary beneficiary) {
		this.beneficiary = beneficiary;
	}


	@JsonProperty("beneficiaryBankAccount")
	public String getBeneficiaryBankAccount() {
		return beneficiaryBankAccount;
	}


	@JsonProperty("beneficiaryBankAccount")
	public void setBeneficiaryBankAccount(String beneficiaryBankAccount) {
		this.beneficiaryBankAccount = beneficiaryBankAccount;
	}


	@JsonProperty("beneficiaryRealTime")
	public String getBeneficiaryRealTime() {
		return beneficiaryRealTime;
	}


	@JsonProperty("beneficiaryRealTime")
	public void setBeneficiaryRealTime(String beneficiaryRealTime) {
		this.beneficiaryRealTime = beneficiaryRealTime;
	}


	@JsonProperty("taxInvoiceNo")
	public String getTaxInvoiceNo() {
		return taxInvoiceNo;
	}


	@JsonProperty("taxInvoiceNo")
	public void setTaxInvoiceNo(String taxInvoiceNo) {
		this.taxInvoiceNo = taxInvoiceNo;
	}


	@JsonProperty("channelType")
	public String getChannelType() {
		return channelType;
	}


	@JsonProperty("channelType")
	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}


	@JsonProperty("orderOriginatingIP")
	public String getOrderOriginatingIP() {
		return orderOriginatingIP;
	}


	@JsonProperty("orderOriginatingIP")
	public void setOrderOriginatingIP(String orderOriginatingIP) {
		this.orderOriginatingIP = orderOriginatingIP;
	}


	@JsonProperty("promoDiscount")
	public String getPromoDiscount() {
		return promoDiscount;
	}


	@JsonProperty("promoDiscount")
	public void setPromoDiscount(String promoDiscount) {
		this.promoDiscount = promoDiscount;
	}


	@JsonProperty("promoCodeName")
	public String getPromoCodeName() {
		return promoCodeName;
	}


	@JsonProperty("promoCodeName")
	public void setPromoCodeName(String promoCodeName) {
		this.promoCodeName = promoCodeName;
	}


	@JsonProperty("deliveryFees")
	public String getDeliveryFees() {
		return deliveryFees;
	}


	@JsonProperty("deliveryFees")
	public void setDeliveryFees(String deliveryFees) {
		this.deliveryFees = deliveryFees;
	}


	@JsonProperty("earthPortPaymentStatusCode")
	public String getEarthPortPaymentStatusCode() {
		return earthPortPaymentStatusCode;
	}


	@JsonProperty("earthPortPaymentStatusCode")
	public void setEarthPortPaymentStatusCode(String earthPortPaymentStatusCode) {
		this.earthPortPaymentStatusCode = earthPortPaymentStatusCode;
	}


	@JsonProperty("created")
	public String getCreated() {
		return created;
	}


	@JsonProperty("created")
	public void setCreated(String created) {
		this.created = created;
	}


	@JsonProperty("updated")
	public String getUpdated() {
		return updated;
	}


	@JsonProperty("updated")
	public void setUpdated(String updated) {
		this.updated = updated;
	}


	@JsonProperty("createdBy")
	public String getCreatedBy() {
		return createdBy;
	}


	@JsonProperty("createdBy")
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	@JsonProperty("updatedBy")
	public String getUpdatedBy() {
		return updatedBy;
	}


	@JsonProperty("updatedBy")
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return additionalProperties;
	}


	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		additionalProperties.put(name, value);
	}


	public String getPid() {
		return pid;
	}


	public void setPid(String pid) {
		this.pid = pid;
	}


	public String getCurrencyCode() {
		return currencyCode;
	}


	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}


	public Float getAmount() {
		return amount;
	}


	public void setAmount(Float amount) {
		this.amount = amount;
	}


	public Boolean getFeeoption() {
		return feeoption;
	}


	public void setFeeoption(Boolean feeoption) {
		this.feeoption = feeoption;
	}


	public String getBeneficiaryId() {
		return beneficiaryId;
	}


	public void setBeneficiaryId(String beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}


	public void setAdditionalProperties(Map<String, Object> additionalProperties) {
		this.additionalProperties = additionalProperties;
	}


	public String getBeneficiaryBankLocation() {
		return beneficiaryBankLocation;
	}


	public void setBeneficiaryBankLocation(String beneficiaryBankLocation) {
		this.beneficiaryBankLocation = beneficiaryBankLocation;
	}


	public String getWebLink() {
		return webLink;
	}


	public void setWebLink(String webLink) {
		this.webLink = webLink;
	}

}
