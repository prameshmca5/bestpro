/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 * @author michelle.angela
 *
 */
public class PaymentKiple implements Serializable, IQfCriteria<PaymentKiple> {

	private static final long serialVersionUID = -2746951161156187836L;

	private Integer tvlPmtKipleId;

	private String pmtRefNo;

	private String cbsRefNo;

	private String rcptRefNo;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date trxnDt;

	private Channel channel;

	private String currency;

	private double amount;

	private PymntMsgCode statusCode;

	private PymntMsgCode pymntMsgCode;

	private Metadata pmtMthdMtdt;

	private String pmtBy;

	private Date pmtDt;

	private String docRefNo;

	private String messageId;

	private String reqData;


	public Integer getTvlPmtKipleId() {
		return tvlPmtKipleId;
	}


	public void setTvlPmtKipleId(Integer tvlPmtKipleId) {
		this.tvlPmtKipleId = tvlPmtKipleId;
	}


	public String getPmtRefNo() {
		return pmtRefNo;
	}


	public void setPmtRefNo(String pmtRefNo) {
		this.pmtRefNo = pmtRefNo;
	}


	public String getCbsRefNo() {
		return cbsRefNo;
	}


	public void setCbsRefNo(String cbsRefNo) {
		this.cbsRefNo = cbsRefNo;
	}


	public Date getTrxnDt() {
		return trxnDt;
	}


	public void setTrxnDt(Date trxnDt) {
		this.trxnDt = trxnDt;
	}


	public Channel getChannel() {
		return channel;
	}


	public void setChannel(Channel channel) {
		this.channel = channel;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public PymntMsgCode getStatusCode() {
		return statusCode;
	}


	public void setStatusCode(PymntMsgCode statusCode) {
		this.statusCode = statusCode;
	}


	public PymntMsgCode getPymntMsgCode() {
		return pymntMsgCode;
	}


	public void setPymntMsgCode(PymntMsgCode pymntMsgCode) {
		this.pymntMsgCode = pymntMsgCode;
	}


	public String getPmtBy() {
		return pmtBy;
	}


	public void setPmtBy(String pmtBy) {
		this.pmtBy = pmtBy;
	}


	public Date getPmtDt() {
		return pmtDt;
	}


	public void setPmtDt(Date pmtDt) {
		this.pmtDt = pmtDt;
	}


	public String getRcptRefNo() {
		return rcptRefNo;
	}


	public void setRcptRefNo(String rcptRefNo) {
		this.rcptRefNo = rcptRefNo;
	}


	public Metadata getPmtMthdMtdt() {
		return pmtMthdMtdt;
	}


	public void setPmtMthdMtdt(Metadata pmtMthdMtdt) {
		this.pmtMthdMtdt = pmtMthdMtdt;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public String getMessageId() {
		return messageId;
	}


	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}


	public String getReqData() {
		return reqData;
	}


	public void setReqData(String reqData) {
		this.reqData = reqData;
	}

}
