/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.model.MerAccSet;
import com.bestpay.be.sdk.model.MerBusCat;
import com.bestpay.be.sdk.model.MerChanSetWrapper;
import com.bestpay.be.sdk.model.MerFraudSet;
import com.bestpay.be.sdk.model.MerGenInfo;
import com.bestpay.be.sdk.model.MerRepSet;
import com.bestpay.be.sdk.model.MerRestriction;
import com.bestpay.be.sdk.model.MerSendAccInfo;
import com.bestpay.be.sdk.model.MerSettlementSet;
import com.bestpay.be.sdk.model.MerchantPid;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.pgw.sdk.model.IRProfile;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.form.MerchantLogoPaymentSettingForm;
import com.bestpay.web.util.WebUtil;
import com.google.gson.Gson;


/**
 * @author Atiqah
 * @since June 07, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_IDM_MERCHANT_LST)
public class MerchantController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MerchantController.class);

	private static final String ACTSTAT = "ACTSTAT";

	private static final String STATUS_LIST = "statusList";


	@GetMapping
	public ModelAndView merchant(MerAccInfo merAccInfo, BindingResult result, HttpServletRequest request,
			HttpSession session) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_IDM_MERCHANT_LST, "merchant", null, "merchant-script");
		mav.addObject(STATUS_LIST, staticData.status(ACTSTAT));
		mav.addObject("merAccInfo", merAccInfo);
		return mav;
	}


	// Search merchant
	@PostMapping(params = "search")
	public ModelAndView search(MerAccInfo merAccInfo, BindingResult result, HttpServletRequest request,
			HttpSession session) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_IDM_MERCHANT_LST, "merchant", null, "merchant-script");
		mav.addObject(STATUS_LIST, staticData.status(ACTSTAT));
		mav.addObject("merAccInfo", merAccInfo);
		LOGGER.info("Search merchant {}", merAccInfo);
		return mav;
	}


	// Reset searching merchant
	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute("merAccInfo") @Validated MerAccInfo merAccInfo, BindingResult result,
			HttpServletRequest request, HttpSession session) throws BeException {
		MerAccInfo accInfo = new MerAccInfo();
		LOGGER.info("--reset--");
		return merchant(accInfo, result, request, session);
	}


	@GetMapping(value = "/new")
	public ModelAndView createAccInfo(MerAccInfo merAccInfo, MerGenInfo merGenInfo, MerFraudSet merFraudSet,
			MerAccSet merAccSet, MerBusCat merBusCat, MerchantLogoPaymentSettingForm merPayPageSet,
			MerRepSet merRepSet, MerRestriction merRestriction, MerSettlementSet merSettlementSet,
			MerSendAccInfo merSendAccInfo, MerChanSetWrapper merChanSetWrapper, MerchantPid merchantPid,
			IRProfile irProfile, HttpSession session) throws BeException {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_MER_CRED);
		mav.addObject(STATUS_LIST, staticData.statusList());
		mav.addObject("channelList", staticData.channelList());
		mav.addObject("tab", "accountInfo");
		mav.addObject("stateList", staticData.stateList("MYS"));
		mav.addObject("countryList", staticData.countryList());
		mav.addObject("bankList", staticData.bankList());
		mav.addObject("subPlanList", staticData.subPlanList());
		mav.addObject("categoryList", staticData.catList());
		mav.addObject("cityList", staticData.cityList());
		mav.addObject("statusPlanList", staticData.status("SUBPLAN"));
		mav.addObject("statusAccList", staticData.status(ACTSTAT));
		mav.addObject("canUpdateSttlmntSet", true);
		mav.addObject("merchantPid", merchantPid);
		mav.addObject("irProfile", irProfile);

		return mav;
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String getApplicationInfoPaginated(@ModelAttribute("merAccInfo") MerAccInfo merAccInfo,
			HttpServletRequest request) {
		LOGGER.info("GET PAGINATED MERCHANT LIST....");
		DataTableResults<MerAccInfo> tasks = new DataTableResults<>();
		try {
			LOGGER.info("status merchant = {}", merAccInfo);
			tasks = getBeService().searchmerchant(merAccInfo, getPaginationRequest(request, true));
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(e.getMessage());
			tasks.setError(e.getMessage());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			tasks.setError(e.getMessage());
		}
		return new Gson().toJson(tasks);
	}
}