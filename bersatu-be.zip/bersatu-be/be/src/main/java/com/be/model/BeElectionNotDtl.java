/**
  * Copyright 2019
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the BE_ELECTION_NOT_DTL database table.
 *
 * @author Naem Othman
 * @since March 31, 2020
 */
@Entity
@Table(name = "BE_ELECTION_NOT_DTL")
public class BeElectionNotDtl extends AbstractEntity implements Serializable, IQfCriteria<BeElectionNotDtl> {

	/**
	 *
	 */
	private static final long serialVersionUID = -1250647810429275176L;

	@Id
	@Column(name = "ELECTION_NOT_DTL_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer electionNotDtlId;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "ELECTION_NOT_ID")
	private BeElectionNot electionNot;

	@Column(name = "MEMBER_ID")
	private Integer memberId;

	@Column(name = "ORG_DIVISION_CD")
	private String orgDivisionCd;

	@OneToOne
	@JoinColumn(name = "MEMBER_ID", insertable = false, updatable = false)
	private BeMemberProfile memberProfile;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getElectionNotDtlId() {
		return electionNotDtlId;
	}


	public void setElectionNotDtlId(Integer electionNotDtlId) {
		this.electionNotDtlId = electionNotDtlId;
	}


	public BeElectionNot getElectionNot() {
		return electionNot;
	}


	public void setElectionNot(BeElectionNot electionNot) {
		this.electionNot = electionNot;
	}


	public Integer getMemberId() {
		return memberId;
	}


	public void setMemberId(Integer memberId) {
		this.memberId = memberId;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public BeMemberProfile getMemberProfile() {
		return memberProfile;
	}


	public void setMemberProfile(BeMemberProfile memberProfile) {
		this.memberProfile = memberProfile;
	}


	public String getOrgDivisionCd() {
		return orgDivisionCd;
	}


	public void setOrgDivisionCd(String orgDivisionCd) {
		this.orgDivisionCd = orgDivisionCd;
	}

}