package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.util.Date;


public class KYCStatusResponse implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	String status;

	Date date;


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}

}
