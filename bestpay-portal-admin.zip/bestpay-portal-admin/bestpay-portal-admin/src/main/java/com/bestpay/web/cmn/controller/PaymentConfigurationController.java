package com.bestpay.web.cmn.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.PaymentConfig;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;


@Controller
@RequestMapping(value = PageConstants.PAGE_PAYMENT_CONFIGURATION)
public class PaymentConfigurationController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentConfigurationController.class);

	private static final String PAYMENT_CONFIGURATION = "payment-configuration";

	private static final String PAYMENT_CONFIGURATION_SCRIPT = "payment-configuration-script";

	private static final String PAYMENT_CONFIG = "paymentConfig";

	@Autowired
	@Qualifier("paymentConfigurationValidator")
	private Validator paymentConfigurationValidator;


	@Override
	protected void bindingPreparation(WebDataBinder binder) {
		binder.setValidator(paymentConfigurationValidator);
		super.bindingPreparation(binder);
	}


	/**
	 * View Payment Configuration
	 *
	 * @param paymentConfig
	 */
	@GetMapping
	public ModelAndView paymentConfig(PaymentConfig paymentConfig, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_PGW_CONFIG, PAYMENT_CONFIGURATION, null,
				PAYMENT_CONFIGURATION_SCRIPT);
		mav.addObject(PAYMENT_CONFIG, paymentConfig);
		return mav;
	}


	/**
	 * Get Payment Configuration paginated
	 *
	 * @param paymentConfig
	 */
	@GetMapping(value = "/paginated")
	public @ResponseBody String searchPaginated(@ModelAttribute(PAYMENT_CONFIG) PaymentConfig paymentConfig,
			HttpServletRequest request) throws BeException {
		getDefaultMav(PageTemplate.TEMP_PGW_CONFIG, PAYMENT_CONFIGURATION, null, PAYMENT_CONFIGURATION_SCRIPT);
		DataTableResults<PaymentConfig> tasks = getBeService().searchPaymentConfig(paymentConfig,
				getPaginationRequest(request, true));
		return new Gson().toJson(tasks);
	}


	/**
	 * Search Payment Configuration
	 *
	 * @param paymentConfig
	 */
	@PostMapping(params = "search")
	public ModelAndView search(PaymentConfig paymentConfig, HttpServletRequest request) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_PGW_CONFIG, null, null, PAYMENT_CONFIGURATION_SCRIPT);
		mav.addObject(PAYMENT_CONFIG, paymentConfig);
		return mav;
	}


	/**
	 * Reset search Payment Configuration
	 *
	 * @param paymentConfig
	 */
	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute(PAYMENT_CONFIG) @Validated PaymentConfig paymentConfig,
			BindingResult result, HttpServletRequest request, HttpSession session) {
		PaymentConfig payConfig = new PaymentConfig();
		LOGGER.info("--reset--");
		return paymentConfig(payConfig, result, request, session);
	}


	/**
	 * View Payment Configuration create form
	 *
	 * @param paymentConfig
	 */
	@GetMapping(value = "/new")
	public ModelAndView viewCreate(PaymentConfig paymentConfig, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_PGW_CONFIG_INFO);
		mav.addObject(PAYMENT_CONFIG, paymentConfig);
		mav.addObject("paymentConfigId", paymentConfig.getId());
		return mav;
	}


	/**
	 * Save new Payment Configuration
	 *
	 * @param id
	 * @param paymentConfig
	 */
	@PostMapping(value = "/{paymentConfigId}", params = "createPayConfig")
	public ModelAndView create(@Valid @ModelAttribute(PAYMENT_CONFIG) PaymentConfig paymentConfig,
			BindingResult result, HttpServletRequest request, HttpSession session) throws BeException {
		ModelAndView mav = new ModelAndView();
		UserProfile authUser = getCurrentUser();
		new PaymentConfig();
		if (result.hasErrors()) {
			return viewCreate(paymentConfig, result, request, session);
		}
		paymentConfig.setCreateId(authUser.getUserId());
		try {
			getBeService().createPaymentConfig(paymentConfig);
			mav.addObject(PAYMENT_CONFIG, paymentConfig);
			mav = getDefaultMav(PageTemplate.TEMP_PGW_CONFIG_INFO);
			mav.addAllObjects(PopupBox.success(null, null,
					messageService.getMessage(MessageConstants.SUCC_CREATE_PAY_CONFIG),
					PageConstants.PAGE_PAYMENT_CONFIGURATION));
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		return mav;
	}


	/**
	 * View payment configuration update form
	 *
	 * @param paymentConfigId
	 * @param PaymentConfig
	 */
	@GetMapping(value = "/{paymentConfigId}")
	public ModelAndView viewPaymentConfig(@PathVariable("paymentConfigId") Integer paymentConfigId,
			HttpServletRequest request, HttpSession session) throws BeException {
		PaymentConfig paymentConfig = getBeService().getPaymentConfigById(paymentConfigId);
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_PGW_CONFIG_INFO);
		mav.addObject(PAYMENT_CONFIG, paymentConfig);
		mav.addObject("paymentConfigId", paymentConfig.getId());
		return mav;
	}

}
