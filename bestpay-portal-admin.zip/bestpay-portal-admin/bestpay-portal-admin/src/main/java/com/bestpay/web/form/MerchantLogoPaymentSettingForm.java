/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.web.form;

import java.io.Serializable;
import java.util.List;

import com.bestpay.be.sdk.model.TrxnDocuments;
import com.bestpay.idm.sdk.model.Documents;
import com.bestpay.web.dto.FileUpload;

/**
 * @author Afif Saman
 * @since July 18, 2018
 */
public class MerchantLogoPaymentSettingForm implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1864073233598003483L;

	private Integer paymentId;

	private String protocolReturnUrl;

	private String returnUrl;

	private String returnUrlWithIpn;

	private String protocolCallbackUrl;

	private String callbackUrl;

	private String callbackUrlWithIpn;

	private String verifyKey;

	private Integer enableVerify;

	private String emailNotification;

	private String receipt;

	private Integer canModifyOid;

	private Integer canModifyAmt;

	private String cantModifyDesc;

	private String emailLock;

	private String nameLock;

	private String phoneLock;

	private String merchantId;

	private String docRefNo;

	private String sellerId;

	private String transactionType; // user create =C, update= U, profile
	// update = UP

	private List<FileUpload> fileUploads;

	private String docMgtId;

	// added for upload profile picture///
	private List<TrxnDocuments> trxnDocuments;

	private String refNo;

	private Documents profilePicture;

	private String psa;

	public String getProtocolReturnUrl() {
		return protocolReturnUrl;
	}

	public void setProtocolReturnUrl(String protocolReturnUrl) {
		this.protocolReturnUrl = protocolReturnUrl;
	}

	public String getReturnUrl() {
		return returnUrl;
	}

	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}

	public String getReturnUrlWithIpn() {
		return returnUrlWithIpn;
	}

	public void setReturnUrlWithIpn(String returnUrlWithIpn) {
		this.returnUrlWithIpn = returnUrlWithIpn;
	}

	public String getProtocolCallbackUrl() {
		return protocolCallbackUrl;
	}

	public void setProtocolCallbackUrl(String protocolCallbackUrl) {
		this.protocolCallbackUrl = protocolCallbackUrl;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public String getCallbackUrlWithIpn() {
		return callbackUrlWithIpn;
	}

	public void setCallbackUrlWithIpn(String callbackUrlWithIpn) {
		this.callbackUrlWithIpn = callbackUrlWithIpn;
	}

	public String getVerifyKey() {
		return verifyKey;
	}

	public void setVerifyKey(String verifyKey) {
		this.verifyKey = verifyKey;
	}

	public Integer getEnableVerify() {
		return enableVerify;
	}

	public void setEnableVerify(Integer enableVerify) {
		this.enableVerify = enableVerify;
	}

	public String getEmailNotification() {
		return emailNotification;
	}

	public void setEmailNotification(String emailNotification) {
		this.emailNotification = emailNotification;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public Integer getCanModifyOid() {
		return canModifyOid;
	}

	public void setCanModifyOid(Integer canModifyOid) {
		this.canModifyOid = canModifyOid;
	}

	public Integer getCanModifyAmt() {
		return canModifyAmt;
	}

	public void setCanModifyAmt(Integer canModifyAmt) {
		this.canModifyAmt = canModifyAmt;
	}

	public String getCantModifyDesc() {
		return cantModifyDesc;
	}

	public void setCantModifyDesc(String cantModifyDesc) {
		this.cantModifyDesc = cantModifyDesc;
	}

	public String getEmailLock() {
		return emailLock;
	}

	public void setEmailLock(String emailLock) {
		this.emailLock = emailLock;
	}

	public String getNameLock() {
		return nameLock;
	}

	public void setNameLock(String nameLock) {
		this.nameLock = nameLock;
	}

	public String getPhoneLock() {
		return phoneLock;
	}

	public void setPhoneLock(String phoneLock) {
		this.phoneLock = phoneLock;
	}

	public Integer getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getDocRefNo() {
		return docRefNo;
	}

	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public List<FileUpload> getFileUploads() {
		return fileUploads;
	}

	public void setFileUploads(List<FileUpload> fileUploads) {
		this.fileUploads = fileUploads;
	}

	public String getDocMgtId() {
		return docMgtId;
	}

	public void setDocMgtId(String docMgtId) {
		this.docMgtId = docMgtId;
	}

	public List<TrxnDocuments> getTrxnDocuments() {
		return trxnDocuments;
	}

	public void setTrxnDocuments(List<TrxnDocuments> trxnDocuments) {
		this.trxnDocuments = trxnDocuments;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public Documents getProfilePicture() {
		return profilePicture;
	}

	public void setProfilePicture(Documents profilePicture) {
		this.profilePicture = profilePicture;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getPsa() {
		return psa;
	}

	public void setPsa(String psa) {
		this.psa = psa;
	}

}