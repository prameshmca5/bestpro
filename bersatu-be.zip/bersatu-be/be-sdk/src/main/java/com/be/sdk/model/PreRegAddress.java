/**
 * Copyright 2019
 */
package com.be.sdk.model;


import java.io.Serializable;


/**
 *
 * @author Naem Othman
 * @since March 31, 2020
 */
public class PreRegAddress implements Serializable {

	private static final long serialVersionUID = 6016032592885161865L;

	private Integer preRegAddId;

	private Integer preRegId;

	private Integer addressTypeMtdtId;

	private String address1;

	private String address2;

	private String address3;

	private String postcode;

	private String cityCd;

	private String stateCd;

	private String countryCd;

	private boolean status;


	public Integer getPreRegAddId() {
		return preRegAddId;
	}


	public void setPreRegAddId(Integer preRegAddId) {
		this.preRegAddId = preRegAddId;
	}


	public Integer getPreRegId() {
		return preRegId;
	}


	public void setPreRegId(Integer preRegId) {
		this.preRegId = preRegId;
	}


	public Integer getAddressTypeMtdtId() {
		return addressTypeMtdtId;
	}


	public void setAddressTypeMtdtId(Integer addressTypeMtdtId) {
		this.addressTypeMtdtId = addressTypeMtdtId;
	}


	public String getAddress1() {
		return address1;
	}


	public void setAddress1(String address1) {
		this.address1 = address1;
	}


	public String getAddress2() {
		return address2;
	}


	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	public String getAddress3() {
		return address3;
	}


	public void setAddress3(String address3) {
		this.address3 = address3;
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getCityCd() {
		return cityCd;
	}


	public void setCityCd(String cityCd) {
		this.cityCd = cityCd;
	}


	public String getStateCd() {
		return stateCd;
	}


	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}


	public String getCountryCd() {
		return countryCd;
	}


	public void setCountryCd(String countryCd) {
		this.countryCd = countryCd;
	}


	public boolean isStatus() {
		return status;
	}


	public void setStatus(boolean status) {
		this.status = status;
	}

}