/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.exception;


import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.mysql.jdbc.AbandonedConnectionCleanupThread;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
@WebListener
public class DbConnectionClosedHandler implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		// initialized context
	}


	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		Enumeration<Driver> drivers = DriverManager.getDrivers();

		Driver driver = null;

		// clear drivers
		while (drivers.hasMoreElements()) {
			try {
				driver = drivers.nextElement();
				DriverManager.deregisterDriver(driver);

			} catch (SQLException ex) {
				// deregistration failed, might want to do something, log at
				// the
				// very least
			}
		}

		// MySQL driver leaves around a thread. This static method cleans it
		// up.
		try {
			AbandonedConnectionCleanupThread.shutdown();
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			// again failure, not much you can do
		}
	}

}