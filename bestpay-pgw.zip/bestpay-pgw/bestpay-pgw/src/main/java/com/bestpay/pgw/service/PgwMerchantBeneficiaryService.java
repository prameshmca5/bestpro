package com.bestpay.pgw.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.dao.PgwMerchantBeneficiaryRepository;
import com.bestpay.pgw.model.PgwMerchantBeneficiary;
import com.bestpay.pgw.util.QualifierConstants;


@Transactional
@Service(QualifierConstants.PGW_MERCHANT_BENEFICIARY_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_BENEFICIARY_SVC)
public class PgwMerchantBeneficiaryService extends AbstractService<PgwMerchantBeneficiary> {

	@Autowired
	private PgwMerchantBeneficiaryRepository merchantBeneficiaryDao;


	@Override
	public PgwMerchantBeneficiaryRepository primaryDao() {
		return merchantBeneficiaryDao;
	}


	public PgwMerchantBeneficiary findByMerchantBenefId(String merchantId) {
		return merchantBeneficiaryDao.findByMerchantBenefId(merchantId);
	}
	
	public PgwMerchantBeneficiary findByMerchantBenefId(String merchantId,String mtoId) {
		 return merchantBeneficiaryDao.findByMerchantBenefIdMtoid(merchantId,mtoId);
	}
}
