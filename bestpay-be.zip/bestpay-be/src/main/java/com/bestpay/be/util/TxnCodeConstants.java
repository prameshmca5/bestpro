/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.util;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public class TxnCodeConstants {

	private TxnCodeConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String HEADER_MESSAGE_ID = "X-Message-Id";

	public static final String HEADER_AUTHORIZATION = "Authorization";

	public static final String PERMISSION_CODE = "eqmTxnNo";

	public static final String TXN_REF_NO = "eqmTxnRefNo";

	public static final String EQM_INBOX_QUOTA_GET = "EQM_INBOX_QUOTA_GET";

	public static final String EQM_INBOX_QUOTA_POST = "EQM_INBOX_QUOTA_CRE";

	public static final String EQM_QUOTA_GET = "EQM_QUOTA_GET";

	public static final String EQM_QUOTA_CREATE = "EQM_QUOTA_CREATE";

	public static final String EQM_QUOTA_FIND = "EQM_QUOTA_FIND";

	public static final String EQM_SECTOR_FIND = "EQM_SECTOR_FIND";

	public static final String EQM_SECTOR_CRE = "EQM_SECTOR_CRE";

	public static final String EQM_SECTOR_UPD = "EQM_SECTOR_UPD";

	public static final String EQM_SECTOR_DEL = "EQM_SECTOR_DEL";

	public static final String EQM_REGAGNCY_FIND = "EQM_REGAGNCY_FIND";

	public static final String EQM_REGAGNCY_CRE = "EQM_REGAGNCY_CRE";

	public static final String EQM_REGAGNCY_UPD = "EQM_REGAGNCY_UPD";

	public static final String EQM_REGAGNCY_DEL = "EQM_REGAGNCY_DEL";

	public static final String EQM_FINANCIAL_FIND = "EQM_FINANCIAL_FIND";

	public static final String EQM_FINANCIAL_CRE = "EQM_FINANCIAL_CRE";

	public static final String EQM_FINANCIAL_UPD = "EQM_FINANCIAL_UPD";

	public static final String EQM_FINANCIAL_DEL = "EQM_FINANCIAL_DEL";

	public static final String EQM_WORKER_FIND = "EQM_WORKER_FIND";

	public static final String EQM_WORKER_CRE = "EQM_WORKER_CRE";

	public static final String EQM_WORKER_UPD = "EQM_WORKER_UPD";

	public static final String EQM_WORKER_DEL = "EQM_WORKER_DEL";

	public static final String EQM_CMPNY_CONSTRUCTION_FIND = "EQM_CMPNY_CONSTRUCTION_FIND";

	public static final String EQM_CMPNY_CONSTRUCTION_CRE = "EQM_CMPNY_CONSTRUCTION_CRE";

	public static final String EQM_CMPNY_CONSTRUCTION_UPD = "EQM_CMPNY_CONSTRUCTION_UPD";

	public static final String EQM_CMPNY_CONSTRUCTION_DEL = "EQM_CMPNY_CONSTRUCTION_DEL";

	public static final String EQM_CMPNY_MANUFACTURING_FIND = "EQM_CMPNY_MANUFACTURING_FIND";

	public static final String EQM_CMPNY_MANUFACTURING_CRE = "EQM_CMPNY_MANUFACTURING_CRE";

	public static final String EQM_CMPNY_MANUFACTURING_UPD = "EQM_CMPNY_MANUFACTURING_UPD";

	public static final String EQM_CMPNY_MANUFACTURING_DEL = "EQM_CMPNY_MANUFACTURING_DEL";

	public static final String EQM_CMPNY_PLANTATION_FIND = "EQM_CMPNY_PLANTATION_FIND";

	public static final String EQM_CMPNY_PLANTATION_CRE = "EQM_CMPNY_PLANTATION_CRE";

	public static final String EQM_CMPNY_PLANTATION_UPD = "EQM_CMPNY_PLANTATION_UPD";

	public static final String EQM_CMPNY_PLANTATION_DEL = "EQM_CMPNY_PLANTATION_DEL";

	public static final String EQM_CMPNY_SERVICES_FIND = "EQM_CMPNY_SERVICES_FIND";

	public static final String EQM_CMPNY_SERVICES_CRE = "EQM_CMPNY_SERVICES_CRE";

	public static final String EQM_CMPNY_SERVICES_UPD = "EQM_CMPNY_SERVICES_UPD";

	public static final String EQM_CMPNY_SERVICES_DEL = "EQM_CMPNY_SERVICES_DEL";

	public static final String EQM_CMPNY_AGRICULTURE_FIND = "EQM_CMPNY_AGRICULTURE_FIND";

	public static final String EQM_CMPNY_AGRICULTURE_CRE = "EQM_CMPNY_AGRICULTURE_CRE";

	public static final String EQM_CMPNY_AGRICULTURE_UPD = "EQM_CMPNY_AGRICULTURE_UPD";

	public static final String EQM_CMPNY_AGRICULTURE_DEL = "EQM_CMPNY_AGRICULTURE_DEL";

	public static final String EQM_CMPNY_SUMMARY_CRE = "EQM_CMPNY_SUMMARY_CRE";

	public static final String EQM_DQ_FIND = "EQM_DQ_FIND";

	public static final String EQM_DQ_CRE = "EQM_DQ_CRE";

	public static final String EQM_DQ_UPD = "EQM_DQ_UPD";

	public static final String EQM_APRVL_JTK_FIND = "EQM_APRVL_JTK_FIND";

	public static final String EQM_APRVL_JTK_CRE = "EQM_APRVL_JTK";

	public static final String EQM_APRVL_JTK_UPD = "EQM_APRVL_JTK_UPD";

	public static final String EQM_APRVL_CIDB_FIND = "EQM_APRVL_CIDB_FIND";

	public static final String EQM_APRVL_CIDB_CRE = "EQM_APRVL_CIDB";

	public static final String EQM_APRVL_CIDB_UPD = "EQM_APRVL_CIDB_UPD";

	public static final String EQM_APRVL_MITI_FIND = "EQM_APRVL_MITI_FIND";

	public static final String EQM_APRVL_MITI_CRE = "EQM_APRVL_MITI_CRE";

	public static final String EQM_APRVL_MITI_UPD = "EQM_APRVL_MITI_UPD";

	public static final String EQM_APRVL_MPIC_FIND = "EQM_APRVL_MPIC_FIND";

	public static final String EQM_APRVL_MPIC_CRE = "EQM_APRVL_MPIC_CRE";

	public static final String EQM_APRVL_MPIC_UPD = "EQM_APRVL_MPIC_UPD";

	public static final String EQM_APRVL_KPDNKK_FIND = "EQM_APRVL_KPDNKK_FIND";

	public static final String EQM_APRVL_KPDNKK_CRE = "EQM_APRVL_KPDNKK_CRE";

	public static final String EQM_APRVL_KPDNKK_UPD = "EQM_APRVL_KPDNKK_UPD";

	public static final String EQM_APRVL_MOTAC_CRE = "EQM_APRVL_MOTAC_CRE";

	public static final String EQM_APRVL_MOA_FIND = "EQM_APRVL_MOA_FIND";

	public static final String EQM_APRVL_MOA_CRE = "EQM_APRVL_MOA_CRE";

	public static final String EQM_APRVL_MOA_UPD = "EQM_APRVL_MOA_UPD";

	public static final String EQM_APRVL_KDN_FIND = "EQM_APRVL_KDN_FIND";

	public static final String EQM_APRVL_KDN_CRE = "EQM_APRVL_KDN_CRE";

	public static final String EQM_APRVL_KDN_UPD = "EQM_APRVL_KDN_UPD";

	public static final String EQM_APRVL_KDN_AMEND = "EQM_APRVL_KDN_AMEND";

	public static final String EQM_APRVL_KDN_CANCEL = "EQM_APRVL_KDN_CANCEL";

	public static final String EQM_CALC_CIDB = "EQM_CALC_CONSTRUCTION";

	public static final String EQM_CALC_MITI = "EQM_CALC_MANUFACTURING";

	public static final String EQM_CALC_MPIC = "EQM_CALC_PLANTATION";

	public static final String EQM_CALC_KPDNKK = "EQM_CALC_SERVICES";

	public static final String EQM_CALC_MOA = "EQM_CALC_AGRICULTURE";

	public static final String EQM_CALC_CIDB_UPD = "EQM_CALC_CIDB_UPD";

	public static final String EQM_CALC_MITI_UPD_XPORT = "EQM_CALC_MITI_UPD_XPORT";

	public static final String EQM_CALC_MITI_UPD_FMILL = "EQM_CALC_MITI_UPD_FMILL";

	public static final String EQM_CALC_KPDNKK_UPD = "EQM_CALC_KPDNKK_UPD";

	public static final String EQM_CALC_MOTAC_UPD = "EQM_CALC_MOTAC_UPD";

	public static final String EQM_VERIFY_KDN_FIND = "EQM_VERIFY_KDN_FIND";

	public static final String EQM_VERIFY_KDN_CRE = "EQM_VERIFY_KDN_CRE";

	public static final String EQM_VERIFY_KDN_UPD = "EQM_VERIFY_KDN_UPD";

	public static final String EQM_AGENT_PROFILE_CRE = "EQM_AGENT_PROFILE_CRE";

	public static final String EQM_CONFIG_CIDB_UPD = "EQM_CONFIG_CIDB_UPD";

	public static final String EQM_CONFIG_MOA_UPD = "EQM_CONFIG_MOA_UPD";

	public static final String EQM_CONFIG_MITI_UPD = "EQM_CONFIG_MITI_UPD";

	public static final String EQM_CONFIG_MPIC_UPD = "EQM_CONFIG_MPIC_UPD";

	public static final String EQM_CONFIG_KPDNKK_UPD = "EQM_CONFIG_KPDNKK_UPD";

	public static final String EQM_CONFIG_MOTAC_UPD = "EQM_CONFIG_MOTAC_UPD";

	public static final String EQM_CONFIG_MOA_UPD_CROPS = "EQM_CONFIG_MOA_UPD_CROPS";

	public static final String EQM_CONFIG_MOA_UPD_LVSTCK = "EQM_CONFIG_MOA_UPD_LVSTCK";

	public static final String EQM_CONFIG_MOA_UPD_SLGHTR = "EQM_CONFIG_MOA_UPD_SLGHTR";

	public static final String EQM_CONFIG_MOA_UPD_FSHRS = "EQM_CONFIG_MOA_UPD_FSHRS";

	public static final String EQM_CONFIG_MPIC_UPD_CROPS = "EQM_CONFIG_MPIC_UPD_CROPS";

	public static final String EQM_SCHEDULAR_QUOTA_SUBMIT = "EQM_SCH_QUOTA_SUBMIT";

	public static final String EQM_SCHEDULAR_QUOTA_PAY = "EQM_SCH_QUOTA_PAY";

	public static final String EQM_SCHEDULAR_QUOTA_PAID = "EQM_SCH_QUOTA_PAID";

	public static final String EQM_SCHEDULAR_QUOTA_CMP = "EQM_SCH_QUOTA_COMPLETED";

	public static final String EQM_SCHEDULAR_SPC_QUOTA_ALLOC = "EQM_SCH_SPECIAL_QUOTA_ALLOC";

	public static final String EQM_SCHEDULAR_SPC_QUOTA_SUBMIT = "EQM_SCH_SPECIAL_QUOTA_SUBMIT";

	public static final String EQM_NNS_QUOTA_CRE = "EQM_NNS_QUOTA_CRE";

	public static final String EQM_NNS_QUOTA_UPD = "EQM_NNS_QUOTA_UPD";

	public static final Integer EQM_LOGO_DOCID = 41;

	public static final Integer EQM_SGNTRE_DOCID = 36;

	public static final Integer EQM_STAMP_DOCID = 35;

	public static final Integer EQM_EMPCONTRACT_DOCID = 39;

	public static final Integer EQM_DEMANDLETTER_DOCID = 84;

	public static final Integer EQM_POWER_OF_ATTORNEY_DOCID = 85;

	public static final String CMN_RELATION_CRE = "EQM_RELATION_CRE";

	public static final String CMN_RELATION_UPD = "EQM_RELATION_UPD";

	public static final String CMN_RELATION_DEL = "EQM_RELATION_DEL";

}