/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
@Configuration
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class SpringAopConfig {

}