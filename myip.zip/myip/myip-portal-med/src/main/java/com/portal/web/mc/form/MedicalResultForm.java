/**
 * Copyright 2020. Bestinet Sdn Bhd
 */
package com.portal.web.mc.form;

import java.io.Serializable;
import java.util.Date;

import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.Tvl;

/**
 * @author muhammad.hafidz
 * @since 12/7/2020
 */
public class MedicalResultForm implements Serializable {

	private static final long serialVersionUID = 7974269053953896352L;
	
	private Tvl tvl;
	
	private Date dateFromMedicalResult;
	
	private Date dateToMedicalResult;
	
	private String emailToCompare;
	
	private Integer tvlProfId;
	
	private AcctTraveller accTvl;  
	
	private String collateCd; 
	
	private String statusCd; 
	
	private Boolean isMedDr;
	
	private String statusDesc; 
	
	private String remarksOperator; 
	
	private String collateDrCd;
	
	private String myIpSlipDocMgtId;
	
	private String medicalDocMgtId;

	
	/**
	 * @return the tvl
	 */
	public Tvl getTvl() {
		return tvl;
	}

	/**
	 * @param tvl the tvl to set
	 */
	public void setTvl(Tvl tvl) {
		this.tvl = tvl;
	}

	/**
	 * @return the dateFromMedicalResult
	 */
	public Date getDateFromMedicalResult() {
		return dateFromMedicalResult;
	}

	/**
	 * @param dateFromMedicalResult the dateFromMedicalResult to set
	 */
	public void setDateFromMedicalResult(Date dateFromMedicalResult) {
		this.dateFromMedicalResult = dateFromMedicalResult;
	}

	/**
	 * @return the dateToMedicalResult
	 */
	public Date getDateToMedicalResult() {
		return dateToMedicalResult;
	}

	/**
	 * @param dateToMedicalResult the dateToMedicalResult to set
	 */
	public void setDateToMedicalResult(Date dateToMedicalResult) {
		this.dateToMedicalResult = dateToMedicalResult;
	}

	/**
	 * @return the emailToCompare
	 */
	public String getEmailToCompare() {
		return emailToCompare;
	}

	/**
	 * @param emailToCompare the emailToCompare to set
	 */
	public void setEmailToCompare(String emailToCompare) {
		this.emailToCompare = emailToCompare;
	}

	/**
	 * @return the tvlProfId
	 */
	public Integer getTvlProfId() {
		return tvlProfId;
	}

	/**
	 * @param tvlProfId the tvlProfId to set
	 */
	public void setTvlProfId(Integer tvlProfId) {
		this.tvlProfId = tvlProfId;
	}

	public AcctTraveller getAccTvl() {
		return accTvl;
	}

	public void setAccTvl(AcctTraveller accTvl) {
		this.accTvl = accTvl;
	}

	public String getCollateCd() {
		return collateCd;
	}

	public void setCollateCd(String collateCd) {
		this.collateCd = collateCd;
	}

	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public Boolean getIsMedDr() {
		return isMedDr;
	}

	public void setIsMedDr(Boolean isMedDr) {
		this.isMedDr = isMedDr;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getRemarksOperator() {
		return remarksOperator;
	}

	public void setRemarksOperator(String remarksOperator) {
		this.remarksOperator = remarksOperator;
	}

	public String getCollateDrCd() {
		return collateDrCd;
	}

	public void setCollateDrCd(String collateDrCd) {
		this.collateDrCd = collateDrCd;
	}

	public String getMyIpSlipDocMgtId() {
		return myIpSlipDocMgtId;
	}

	public void setMyIpSlipDocMgtId(String myIpSlipDocMgtId) {
		this.myIpSlipDocMgtId = myIpSlipDocMgtId;
	}

	public String getMedicalDocMgtId() {
		return medicalDocMgtId;
	}

	public void setMedicalDocMgtId(String medicalDocMgtId) {
		this.medicalDocMgtId = medicalDocMgtId;
	}
	
}
