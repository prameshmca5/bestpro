/**
 *
 */
package com.bestid.be.repo;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidCertInfo;


/**
 * @author mukhlis.hamzah
 * @since Feb 14, 2019
 */
@Repository
@RepositoryDefinition(domainClass = BidCertInfo.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_CERT_INFO_REPOSITORY)
public interface BidCertInfoRepository extends GenericRepository<BidCertInfo> {

	@Query("select u from BidCertInfo u where u.applId= :applId")
	BidCertInfo findByApplId(@Param("applId") Integer applId);


	@Query("select u from BidCertInfo u where u.refno= :refno")
	BidCertInfo findByRefNo(@Param("refno") String refno);


	@Query("select u from BidCertInfo u where u.certRefNo= :certRefNo")
	BidCertInfo findByCertRefNo(@Param("certRefNo") String certRefNo);


	@Query("select u from BidCertInfo u where u.applId in :applId")
	List<BidCertInfo> findByApplIdList(@Param("applId") List<Integer> applId);
}
