/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwConfig;
import com.bestpay.be.model.PgwReferralMultiChannel;
import com.bestpay.be.model.RefBank;
import com.bestpay.be.model.RefCategory;
import com.bestpay.be.model.RefChannel;
import com.bestpay.be.model.RefCountry;
import com.bestpay.be.model.RefDocument;
import com.bestpay.be.model.RefFpxResponseCode;
import com.bestpay.be.model.RefNationality;
import com.bestpay.be.model.RefRelationship;
import com.bestpay.be.model.RefState;
import com.bestpay.be.model.RefStatus;
import com.bestpay.be.model.RefSubscriptionPlan;
import com.bestpay.be.sdk.constants.BeCacheConstants;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Bank;
import com.bestpay.be.sdk.model.Category;
import com.bestpay.be.sdk.model.Channel;
import com.bestpay.be.sdk.model.City;
import com.bestpay.be.sdk.model.Country;
import com.bestpay.be.sdk.model.Nationality;
import com.bestpay.be.sdk.model.RefDocuments;
import com.bestpay.be.sdk.model.RefEmbedRequest;
import com.bestpay.be.sdk.model.RefEmbedResponse;
import com.bestpay.be.sdk.model.RefFpxResponseCodeDto;
import com.bestpay.be.sdk.model.ReferralMultiChannel;
import com.bestpay.be.sdk.model.RelationShip;
import com.bestpay.be.sdk.model.State;
import com.bestpay.be.sdk.model.StaticList;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.sdk.model.SubscriptionPlan;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.service.CountryService;
import com.bestpay.be.service.RefBankService;
import com.bestpay.be.service.RefCategoryService;
import com.bestpay.be.service.RefCityService;
import com.bestpay.be.service.RefConfigService;
import com.bestpay.be.service.RefCountryService;
import com.bestpay.be.service.RefDocumentService;
import com.bestpay.be.service.RefFpxResponseCodeService;
import com.bestpay.be.service.RefNationalityService;
import com.bestpay.be.service.RefRelationshipService;
import com.bestpay.be.service.RefStateService;
import com.bestpay.be.service.RefSubscriptionPlanService;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 3, 2016
 */
@RestController
@RequestMapping(BeUrlConstants.REFERENCE)
public class ReferenceRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReferenceRestController.class);

	@Autowired
	private RefConfigService apjConfigSvc;

	@Autowired
	protected RefCountryService apjRefCountryService;

	@Autowired
	RefDocumentService apjRefDocServiceService;

	@Autowired
	private RefRelationshipService refRelationshipSvc;

	@Autowired
	private RefCityService apjCitySvc;

	@Autowired
	private RefRelationshipService relationService;

	@Autowired
	private RefStateService refStateSvc;

	@Autowired
	private CountryService countryService;

	@Autowired
	private RefNationalityService refNationalitySvc;

	@Autowired
	private RefBankService refBankSvc;

	@Autowired
	private RefCategoryService refCategorySvc;

	@Autowired
	private RefSubscriptionPlanService refSubscriptionPlanSvc;

	@Autowired
	private RefFpxResponseCodeService refFpxResponseCodeSvc;


	@GetMapping(consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public StaticList staticList(HttpServletRequest request) {

		StaticList cmnStatList = new StaticList();

		cmnStatList.setCityList(((List<City>) findAll(BeCacheConstants.REF_TYP_CITY, request, null)));
		cmnStatList.setCountryList(((List<Country>) findAll(BeCacheConstants.REF_TYP_COUNTRY, request, null)));
		cmnStatList.setRelationList(((List<RelationShip>) findAll(BeCacheConstants.REF_TYP_RELATION, request, null)));
		cmnStatList.setStateList(((List<State>) findAll(BeCacheConstants.REF_TYP_STATE, request, null)));
		cmnStatList.setStatusList(((List<Status>) findAll(BeCacheConstants.REF_TYP_STATUS, request, null)));

		return cmnStatList;
	}


	@GetMapping(value = BeUrlConstants.APJ_CONFIG, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public Map<String, String> sstConfig(HttpServletRequest request) {
		List<PgwConfig> confLst = apjConfigSvc.primaryDao().findAll();
		Map<String, String> config = new HashMap<>();
		if (!confLst.isEmpty()) {
			for (PgwConfig conf : confLst) {
				config.put(conf.getConfigCode(), conf.getConfigVal());
			}
		}
		return config;
	}


	@GetMapping(value = BeUrlConstants.APJ_CONFIG + "/{configCode}", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwConfig findConfig(@PathVariable String configCode, HttpServletRequest request) {
		return apjConfigSvc.findByConfigCode(configCode);
	}


	@GetMapping(value = "/getRefCountry", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<RefCountry> getRefCountryLst() {
		List<RefCountry> refCountryLst = apjRefCountryService.primaryDao().findAll();
		List<RefCountry> refCntry = new ArrayList<>();
		for (RefCountry r : refCountryLst) {
			refCntry.add(dozerMapper.map(r, RefCountry.class));
		}
		return refCntry;
	}


	@GetMapping(value = "/{refType}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public <T> T findAll(@PathVariable("refType") String refType, HttpServletRequest request,
			@RequestParam Map<String, String> requestParams) {
		if (BaseUtil.isEqualsCaseIgnore(BeCacheConstants.REF_TYP_CITY, refType)) {
			return (T) apjCitySvc.findAll();
		} else if (BaseUtil.isEqualsCaseIgnore(BeCacheConstants.REF_TYP_STATUS, refType)) {
			return (T) refStatusService.findAll();
		} else if (BaseUtil.isEqualsCaseIgnore(BeCacheConstants.REF_TYP_RELATION, refType)) {
			return (T) refRelationshipSvc.findAll();
		}
		return (T) Collections.emptyList();
	}


	@GetMapping(value = "/{refType}/{refCode}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public Object find(@PathVariable("refType") String refType, @PathVariable("refCode") String refCode,
			HttpServletRequest request, @RequestParam Map<String, String> requestParams) {

		if (BaseUtil.isEqualsCaseIgnore(BeCacheConstants.REF_TYP_CITY, refType)) {
			return apjCitySvc.findByCityCode(refCode);
		} else if (BaseUtil.isEqualsCaseIgnore(BeCacheConstants.REF_TYP_STATUS, refType)) {
			return refStatusService.findByStatusCode(refCode);
		} else if (BaseUtil.isEqualsCaseIgnore(BeCacheConstants.REF_TYP_RELATION, refType)) {
			return refRelationshipSvc.findByRelationCode(refCode);
		}
		return null;
	}


	@GetMapping(value = "/search/{refCode}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public Object findByStatusType(@PathVariable("refCode") String refCode, HttpServletRequest request) {
		if (!BaseUtil.isObjNull(refCode)) {
			return refStatusService.findByStatusType(refCode);
		}
		return null;
	}


	@GetMapping(value = "/refDocList", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<RefDocuments> getRefDocList(HttpServletRequest request) {
		List<RefDocuments> resList = new ArrayList<>();
		List<RefDocument> paymentTypeList = apjRefDocServiceService.findAll();

		RefDocuments doc;
		for (RefDocument cnt : paymentTypeList) {
			doc = dozerMapper.map(cnt, RefDocuments.class);
			resList.add(doc);
		}
		return resList;
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_RELATIONSHIP, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<RelationShip> getAllRelationship(HttpServletRequest request) throws BeException {

		List<RefRelationship> refRelationList = relationService.findAll();

		if (BaseUtil.isListNull(refRelationList)) {
			throw new BeException(BeErrorCodeEnum.I404APJ109);
		}

		List<RelationShip> relationShipList = new ArrayList<>();

		for (RefRelationship refRelationShip : refRelationList) {

			RelationShip relationShip = dozerMapper.map(refRelationShip, RelationShip.class);
			relationShipList.add(relationShip);
		}

		return relationShipList;
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_STATE, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<State> getStateList(HttpServletRequest request) {
		List<State> resList = new ArrayList<>();
		List<RefState> stateList = refStateSvc.allStates();

		for (RefState cnt : stateList) {
			State state = dozerMapper.map(cnt, State.class);
			resList.add(state);
		}
		return resList;
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_COUNTRY, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<Country> getCountryList(HttpServletRequest request) {
		List<Country> resList = new ArrayList<>();
		List<RefCountry> countryList = countryService.allCountries();

		for (RefCountry cnt : countryList) {
			Country country = dozerMapper.map(cnt, Country.class);
			resList.add(country);
		}
		return resList;
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_NATIONALITY, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Nationality> findAllNationality(HttpServletRequest request) throws BeException {

		List<RefNationality> refNationalityList = refNationalitySvc.findAll();

		List<Nationality> nationalityList = new ArrayList<>();

		if (BaseUtil.isListNull(refNationalityList)) {
			throw new BeException(BeErrorCodeEnum.I404APJ109);
		}

		for (RefNationality refNationality : refNationalityList) {

			Nationality nationality = dozerMapper.map(refNationality, Nationality.class);
			nationalityList.add(nationality);
		}

		return nationalityList;
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_NATIONALITY_CODE + "/{ntnltyCode}", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public Nationality findByNationalityCode(@PathVariable String ntnltyCode, HttpServletRequest request)
			throws BeException {

		RefNationality refNationality = refNationalitySvc.findByNationalityCode(ntnltyCode);

		if (BaseUtil.isObjNull(refNationality)) {
			throw new BeException(BeErrorCodeEnum.I404APJ109);
		}

		return dozerMapper.map(refNationality, Nationality.class);
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_NATIONALITY_DESC + "/{ntnltyDescEn}", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public Nationality findNationalityByDesc(@PathVariable String ntnltyDescEn, HttpServletRequest request)
			throws BeException {

		RefNationality refNationality = refNationalitySvc.findByDesc(ntnltyDescEn);

		if (BaseUtil.isObjNull(refNationality)) {
			throw new BeException(BeErrorCodeEnum.I404APJ109);
		}

		return dozerMapper.map(refNationality, Nationality.class);
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_STAUS, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<Status> getAllStatus(HttpServletRequest request) throws BeException {

		List<RefStatus> refStatusList = refStatusService.findAll();

		if (BaseUtil.isListNull(refStatusList)) {
			throw new BeException(BeErrorCodeEnum.I404APJ109);
		}

		List<Status> statusList = new ArrayList<>();

		for (RefStatus refStatus : refStatusList) {
			Status status = dozerMapper.map(refStatus, Status.class);
			statusList.add(status);
		}

		return statusList;
	}


	@PostMapping(value = "/refData", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public RefEmbedResponse getRrefData(HttpServletRequest request,
			@Valid @RequestBody RefEmbedRequest refEmbedRequest) throws BeException {

		RefEmbedResponse response = new RefEmbedResponse();
		if (refEmbedRequest != null) {
			if (refEmbedRequest.isEmbedNationality()) {
				List<Nationality> refNationalityList = findAllNationality(request);
				response.setRefNationality(refNationalityList);
			}

			if (!BaseUtil.isObjNull(refEmbedRequest.isEmbedStatus())) {
				List<Status> refStatusList = getAllStatus(request);
				response.setRefStatus(refStatusList);
			}
			if (!BaseUtil.isObjNull(refEmbedRequest.isEmbedCountry())) {
				try {
					List<Country> countLst = getCountryList(request);
					response.setRefCountry(countLst);
				} catch (Exception e) {
					LOGGER.error("Exception:", e);
					throw new BeException(BeErrorCodeEnum.E400IDM913);
				}

			}
			if (!BaseUtil.isObjNull(refEmbedRequest.isEmbedState())) {
				List<State> refStLst;
				try {
					refStLst = getStateList(request);
					response.setRefState(refStLst);
				} catch (Exception e) {
					LOGGER.error("Exception:", e);
					throw new BeException(BeErrorCodeEnum.E400IDM913);
				}

			}
		}

		return response;
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_CHANNEL, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<Channel> getChannelList(HttpServletRequest request) {
		List<Channel> resList = new ArrayList<>();
		List<RefChannel> channelList = refChannelSvc.findAll();

		for (RefChannel chn : channelList) {
			Channel channel = dozerMapper.map(chn, Channel.class);
			resList.add(channel);
		}
		return resList;
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_REF_MULTI_CHANNEL, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<ReferralMultiChannel> getAllRefMultiChannel(HttpServletRequest request) {
		List<ReferralMultiChannel> resList = new ArrayList<>();
		List<PgwReferralMultiChannel> channelList = pgwReferralMultiChannelService.findAll();

		for (PgwReferralMultiChannel chn : channelList) {
			ReferralMultiChannel multiChannel = dozerMapper.map(chn, ReferralMultiChannel.class);
			resList.add(multiChannel);
		}
		return resList;
	}


	@PostMapping(value = BeUrlConstants.GET_REF_MULTI_CHANNEL_BY_COMPREFID, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<ReferralMultiChannel> getRefMultiChannelByCompRefId(@RequestBody String compRefId,
			HttpServletRequest request) {
		List<ReferralMultiChannel> resList = new ArrayList<>();
		List<PgwReferralMultiChannel> channelList = pgwReferralMultiChannelService
				.findMultiChannelByCompRefId(compRefId);

		for (PgwReferralMultiChannel chn : channelList) {
			ReferralMultiChannel multiChannel = dozerMapper.map(chn, ReferralMultiChannel.class);
			resList.add(multiChannel);
		}
		return resList;
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_BANK, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<Bank> getBankList(HttpServletRequest request) {
		List<Bank> resList = new ArrayList<>();
		List<RefBank> bankList = refBankSvc.findAll();

		for (RefBank bnk : bankList) {
			Bank bank = dozerMapper.map(bnk, Bank.class);
			resList.add(bank);
		}
		return resList;
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_CAT, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<Category> getCategoryList(HttpServletRequest request) {
		List<Category> resCategory = new ArrayList<>();
		List<RefCategory> categoryList = refCategorySvc.findAll();

		for (RefCategory cat : categoryList) {
			Category category = dozerMapper.map(cat, Category.class);
			resCategory.add(category);
		}
		return resCategory;
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_SUB_PLAN, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public List<SubscriptionPlan> getSubscriptionPlanList(HttpServletRequest request) {
		List<SubscriptionPlan> resList = new ArrayList<>();
		List<RefSubscriptionPlan> subPlanList = refSubscriptionPlanSvc.findAll();

		for (RefSubscriptionPlan subPlan : subPlanList) {
			SubscriptionPlan subscriptionPlan = dozerMapper.map(subPlan, SubscriptionPlan.class);
			resList.add(subscriptionPlan);
		}
		return resList;
	}


	@GetMapping(value = BeUrlConstants.GET_ALL_FPX_RESPOND_CODE, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<RefFpxResponseCodeDto> getFpxResCode(HttpServletRequest request) {
		List<RefFpxResponseCodeDto> resCodeList = new ArrayList<>();
		List<RefFpxResponseCode> fpxResList = refFpxResponseCodeSvc.findAll();

		for (RefFpxResponseCode fpxRes : fpxResList) {
			RefFpxResponseCodeDto fpxResCode = dozerMapper.map(fpxRes, RefFpxResponseCodeDto.class);
			resCodeList.add(fpxResCode);
		}
		return resCodeList;
	}


	@GetMapping(value = "/getCountryDesc/{country}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public RefCountry getCountryDesc(@PathVariable String country, HttpServletRequest request) {
		new ArrayList<>();
		return countryService.findByCtrCode(country);
	}


	@GetMapping(value = "/getStatusDesc/{statusType}/{statusCode}", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public Status getStatusDesc(@PathVariable String statusType, @PathVariable String statusCode,
			HttpServletRequest request) {
		new ArrayList<>();
		RefStatus refStatus = refStatusService.findByStatusTypeAndCode(statusType, statusCode);
		return dozerMapper.map(refStatus, Status.class);
	}


	@PostMapping(value = BeUrlConstants.SUBSCRIPTION_PAGINATION, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public DataTableResults<SubscriptionPlan> searchChannelsPaginated(
			@Valid @RequestBody SubscriptionPlan subscriptionPlan, HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<RefSubscriptionPlan> result = refSubscriptionPlanSvc
				.searchSubscriptionByPagination(subscriptionPlan, dataTableInRQ);
		DataTableResults<SubscriptionPlan> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			dataTableInResp.setDraw(result.getDraw());
			dataTableInResp.setError(result.getError());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<SubscriptionPlan> chLst = new ArrayList<>();
				for (RefSubscriptionPlan bbp : result.getData()) {
					SubscriptionPlan chnl = dozerMapper.map(bbp, SubscriptionPlan.class);
					chLst.add(chnl);
				}
				dataTableInResp.setData(chLst);
			}
		}
		return dataTableInResp;
	}


	@PostMapping(value = BeUrlConstants.ADD_SUBSCRIPTION, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public boolean addSubscription(@Valid @RequestBody SubscriptionPlan subscriptionPlan, HttpServletRequest request)
			throws BeException {
		boolean isUpdated = true;
		if (subscriptionPlan == null) {
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		RefSubscriptionPlan newSubscription = dozerMapper.map(subscriptionPlan, RefSubscriptionPlan.class);

		super.refSubscriptionPlanService.create(newSubscription);
		return isUpdated;
	}


	@GetMapping(value = BeUrlConstants.GET_SUBSCRIPTION + "/{subscriptionPlanId}", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public SubscriptionPlan searchSubscriptionPlanById(@PathVariable Integer subscriptionPlanId,
			HttpServletRequest request) throws BeException {
		if (subscriptionPlanId == null) {
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		RefSubscriptionPlan refSubscriptionPlan = super.refSubscriptionPlanService.find(subscriptionPlanId);
		return dozerMapper.map(refSubscriptionPlan, SubscriptionPlan.class);
	}


	@GetMapping(value = BeUrlConstants.DEL_SUBSCRIPTION + "/{subscriptionPlanId}", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public boolean deleteSubsciption(@PathVariable Integer subscriptionPlanId, HttpServletRequest request) {
		try {
			if (subscriptionPlanId == null) {
				throw new BeException(BeErrorCodeEnum.E404BLC002);
			}

			super.refSubscriptionPlanService.primaryDao()
					.delete(super.refSubscriptionPlanService.find(subscriptionPlanId));
			return true;
		} catch (BeException ex) {
			LOGGER.info("{}", ex.getMessage());
		}
		return false;
	}


	@PostMapping(value = BeUrlConstants.STATUS_PAGINATION, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public DataTableResults<com.bestpay.be.sdk.model.RefStatus> searchChannelsPaginated(
			@Valid @RequestBody com.bestpay.be.sdk.model.RefStatus refStatus, HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<RefStatus> result = refStatusService.searchStatusByPagination(refStatus, dataTableInRQ);
		DataTableResults<com.bestpay.be.sdk.model.RefStatus> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			dataTableInResp.setDraw(result.getDraw());
			dataTableInResp.setError(result.getError());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<com.bestpay.be.sdk.model.RefStatus> stLst = new ArrayList<>();
				for (RefStatus bbp : result.getData()) {
					com.bestpay.be.sdk.model.RefStatus rfSt = dozerMapper.map(bbp,
							com.bestpay.be.sdk.model.RefStatus.class);
					stLst.add(rfSt);
				}
				dataTableInResp.setData(stLst);
			}
		}
		return dataTableInResp;
	}


	@PostMapping(value = BeUrlConstants.ADD_STATUS, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public boolean addStatus(@Valid @RequestBody com.bestpay.be.sdk.model.RefStatus refStatus,
			HttpServletRequest request) throws BeException {
		boolean isUpdated = true;
		if (refStatus == null) {
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		RefStatus newStatus = dozerMapper.map(refStatus, RefStatus.class);

		super.refStatusService.primaryDao().save(newStatus);
		return isUpdated;
	}


	@GetMapping(value = BeUrlConstants.GET_STATUS + "/{statusId}", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public com.bestpay.be.sdk.model.RefStatus searchStatusById(@PathVariable Integer statusId,
			HttpServletRequest request) throws BeException {
		if (statusId == null) {
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}
		RefStatus refStatus = super.refStatusService.find(statusId);
		return dozerMapper.map(refStatus, com.bestpay.be.sdk.model.RefStatus.class);
	}


	@GetMapping(value = BeUrlConstants.DEL_STATUS + "/{statusId}", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public boolean deleteStatus(@PathVariable Integer statusId, HttpServletRequest request) {
		try {
			if (statusId == null) {
				throw new BeException(BeErrorCodeEnum.E404BLC002);
			}
			return super.refStatusService.delete(statusId);
		} catch (BeException ex) {
			LOGGER.info("{}", ex.getMessage());
		}
		return false;
	}

}