package com.bestpay.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwMerchantPid;
import com.bestpay.be.util.QualifierConstants;


@Repository
@RepositoryDefinition(domainClass = PgwMerchantPid.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_PID_DAO)
public interface PgwMerchantPidRepository extends GenericRepository<PgwMerchantPid> {

	@Query("select u from PgwMerchantPid u where u.merchantId = :merchantId ")
	public PgwMerchantPid findByMerchantId(@Param("merchantId") String merchantId);
	
	@Query("select count(u) from PgwMerchantPid u ")
	public int totalRecords();

	@Query("select u from PgwMerchantPid u where u.merchantId = :merchantId and mtoId=:mtotype")
	public PgwMerchantPid findByMerchantIdUsingMTO(@Param("merchantId") String merchantId, @Param("mtotype") String mtotype);
}
