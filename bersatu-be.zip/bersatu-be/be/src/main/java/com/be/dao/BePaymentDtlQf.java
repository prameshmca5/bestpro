/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BePaymentDtl;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.PaymentDtl;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;


/**
 * @author nurul.naimma
 *
 * @since Jun 22, 2021
 */

@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_PAYMENT_QF)
public class BePaymentDtlQf extends QueryFactory<BePaymentDtl> {

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BePaymentDtl> searchByProperty(BePaymentDtl t) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<BePaymentDtl> searchAllByProperty(BePaymentDtl t) {
		CriteriaQuery<BePaymentDtl> cq = cb.createQuery(BePaymentDtl.class);
		Root<BePaymentDtl> root = cq.from(BePaymentDtl.class);
		List<Predicate> predicates = generateCriteria(cb, root, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public Long getCount(PaymentDtl dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BePaymentDtl> root = cq.from(BePaymentDtl.class);
		predicates.addAll(generateCriteria(cb, root, dto));

		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}


	public BePaymentDtl searchPaymentDtl(PaymentDtl dto) {

		BePaymentDtl result = null;
		CriteriaQuery<BePaymentDtl> cq = cb.createQuery(BePaymentDtl.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BePaymentDtl> root = cq.from(BePaymentDtl.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BePaymentDtl> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}


	public List<BePaymentDtl> searchAllByProperty(PaymentDtl dto, DataTableRequest<?> dataTableInRQ) {

		List<BePaymentDtl> result = new ArrayList<>();
		CriteriaQuery<BePaymentDtl> cq = cb.createQuery(BePaymentDtl.class);
		List<Predicate> predicates = new ArrayList<>();
		if (cq != null) {
			Root<BePaymentDtl> root = cq.from(BePaymentDtl.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq);

			cq.select(root);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					List<Order> orders = getOrderByClause(cb, root, pagination);
					cq.orderBy(orders);
				}
			}

			TypedQuery<BePaymentDtl> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			PaymentDtl dto = JsonUtil.transferToObject(criteria, PaymentDtl.class);

			if (!BaseUtil.isObjNull(dto.getPmtDtlId())) {
				predicates.add(cb.equal(from.get("pmtDtlId"), dto.getPmtDtlId()));
			}

			if (!BaseUtil.isObjNull(dto.getItemId())) {
				predicates.add(cb.equal(from.get("itemId"), dto.getItemId()));
			}
			
			if (!BaseUtil.isObjNull(dto.getPmtId())) {
				predicates.add(cb.equal(from.get("pmtId"), dto.getPmtId()));
			}
			
			if (!BaseUtil.isObjNull(dto.getPmtDtlRefNo())) {
				predicates.add(cb.like(from.get("pmtDtlRefNo"), "%" + dto.getPmtDtlRefNo() + "%"));
			}

		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

	private void joinFetch(From<?, ?> from, List<Predicate> predicates, PaymentDtl dto,
			CriteriaQuery<BePaymentDtl> cq) {
		from.fetch("payment", JoinType.LEFT);
	}

}
