package com.bestpay.pgw.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.PgwMultiChannel;
import com.bestpay.pgw.util.QualifierConstants;

 
/**
 * @author Afif Saman
 * @since July 11, 2018
 */

@Repository
@RepositoryDefinition(domainClass = PgwMultiChannel.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MULTI_CHANNEL_DAO)
public interface PgwMultiChannelRepository extends GenericRepository<PgwMultiChannel> {

	//@Query("select u from PgwMultiChannel u where u.merchantId = :merchantId ")
	@Query("select u from PgwMultiChannel u where u.merchantId = :merchantId  and u.status = 'A' and u.enable=1")
	public List<PgwMultiChannel> findMultiChannelByMerchantId(@Param("merchantId") String merchantId);

	@Query("select u from PgwMultiChannel u where u.merchantId = :merchantId and u.channel = :channel and u.status = :status")
	public PgwMultiChannel findActiveMultiChannelByMerIdAndChannel(@Param("merchantId") String merchantId, @Param("channel") String channel, @Param("status") String status);

	@Query("select count(u) from PgwMultiChannel u ")
	public int totalRecords();

}