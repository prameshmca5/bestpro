package com.bestpay.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.RefBank;
import com.bestpay.be.util.QualifierConstants;


@Repository
@RepositoryDefinition(domainClass = RefBank.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_BANK_DAO)
public interface RefBankRepository extends GenericRepository<RefBank> {

}