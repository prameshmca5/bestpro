/**
 * Copyright 2014. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since March 01, 2018
 */
public class BeServiceConstants {

	private BeServiceConstants() {
		throw new IllegalStateException("BeServiceConstants class");
	}
}