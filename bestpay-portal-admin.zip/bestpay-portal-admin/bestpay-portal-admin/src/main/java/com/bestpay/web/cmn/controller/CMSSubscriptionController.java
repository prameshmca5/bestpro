/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.SubscriptionPlan;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;


/**
 * @author Atiqah
 * @since June 07, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_CMS_SUBSCRIPTION_LST)
public class CMSSubscriptionController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CMSSubscriptionController.class);

	private static final String SUBSCRIPTION_LIST_SCRIPT = "subscription-list-script";

	private static final String SUBSCRIPTIONPLAN = "subsciptionPlan";

	private static final String SUBSCRIBE = "subscribe";


	@GetMapping
	public ModelAndView subscribe(SubscriptionPlan subsciptionPlan, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMS_SUBSCRIPTION, SUBSCRIBE, null,
				SUBSCRIPTION_LIST_SCRIPT);
		mav.addObject(SUBSCRIPTIONPLAN, subsciptionPlan);
		return mav;
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String searchPaginated(@ModelAttribute("subscription") SubscriptionPlan subsciptionPlan,
			HttpServletRequest request) throws BeException {
		getDefaultMav(PageTemplate.TEMP_CMS_SUBSCRIPTION, SUBSCRIBE, null, SUBSCRIPTION_LIST_SCRIPT);
		DataTableResults<SubscriptionPlan> tasks = getBeService().searchSubscriptionPlan(subsciptionPlan,
				getPaginationRequest(request, true));
		return new Gson().toJson(tasks);
	}


	// Search merchant
	@PostMapping(params = "search")
	public ModelAndView search(SubscriptionPlan subsciptionPlan, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMS_SUBSCRIPTION, "subscribeList", null,
				SUBSCRIPTION_LIST_SCRIPT);
		mav.addObject(SUBSCRIPTIONPLAN, subsciptionPlan);
		return mav;
	}


	// Reset searching merchant
	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute("merAccInfo") @Validated SubscriptionPlan subsciptionPlan,
			BindingResult result, HttpServletRequest request, HttpSession session) {
		SubscriptionPlan sub = new SubscriptionPlan();
		LOGGER.info("--reset--");
		return subscribe(sub, result, request, session);
	}


	@GetMapping(value = "/new")
	public ModelAndView createNewSubscriptionPlan(SubscriptionPlan subsciptionPlan, BindingResult result,
			HttpServletRequest request, HttpSession session) {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_CMS_SUBSCRIPTION_NEW);
		SubscriptionPlan sub = new SubscriptionPlan();
		mav.addObject(SUBSCRIPTIONPLAN, sub);
		return mav;
	}


	@PostMapping(value = "/addSubscription")
	public ModelAndView addSubscription(@Valid @ModelAttribute(SUBSCRIPTIONPLAN) SubscriptionPlan subsciptionPlan,
			BindingResult result, HttpServletRequest request, HttpSession session) throws BeException {
		ModelAndView mav;
		if (!result.hasErrors()) {
			boolean isUpdated = getBeService().addSubscriptionPlan(subsciptionPlan);
			LOGGER.info("Update Subscription {}", isUpdated);
			String msg;
			if (subsciptionPlan.getSubPlanId() != null) {
				msg = messageService.getMessage(MessageConstants.SUCC_UPDATE_SUBSCRIPTION);
			} else {
				msg = messageService.getMessage(MessageConstants.SUCC_CREATE_SUBSCRIPTION);
			}
			mav = getDefaultMav(PageTemplate.TEMP_CMS_SUBSCRIPTION, "subscriptionPlanlist", null,
					SUBSCRIPTION_LIST_SCRIPT);
			subsciptionPlan = new SubscriptionPlan();
			mav.addAllObjects(PopupBox.success("subscription", null, msg));
			mav.addAllObjects(PopupBox.success(null, null, msg, PageConstants.PAGE_CMS_SUBSCRIPTION_LST));
		} else {
			mav = new ModelAndView(PageTemplate.TEMP_CMS_SUBSCRIPTION_NEW);
		}
		mav.addObject(SUBSCRIPTIONPLAN, subsciptionPlan);
		return mav;
	}


	@GetMapping(value = "/update/{subPlanId}")
	public ModelAndView updateSubscription(@PathVariable("subPlanId") Integer subPlanId, HttpServletRequest request,
			HttpSession session) throws BeException {
		SubscriptionPlan subscriptionPlan = getBeService().getSubscriptionPlanById(subPlanId);
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_CMS_SUBSCRIPTION_NEW);
		mav.addObject(SUBSCRIPTIONPLAN, subscriptionPlan);
		return mav;
	}


	@GetMapping(value = "/delete/{subPlanId}")
	public ModelAndView deleteSubscription(@PathVariable("subPlanId") Integer subPlanId, HttpServletRequest request,
			HttpSession session) throws BeException {
		boolean isDeleted = getBeService().deleteSubsciption(subPlanId);
		LOGGER.info("Delete channel {}", isDeleted);
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMS_SUBSCRIPTION, "subscriptionPlanlist", null,
				SUBSCRIPTION_LIST_SCRIPT);

		mav.addAllObjects(PopupBox.success("subscription", null,
				messageService.getMessage(MessageConstants.SUCC_DELETE_SUBSCRIPTION)));
		mav.addAllObjects(
				PopupBox.success(null, null, messageService.getMessage(MessageConstants.SUCC_DELETE_SUBSCRIPTION),
						PageConstants.PAGE_CMS_SUBSCRIPTION_LST));
		SubscriptionPlan sub = new SubscriptionPlan();
		mav.addObject(SUBSCRIPTIONPLAN, sub);
		return mav;
	}

}