/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_MC_ADDRESS")
public class BeMcAddress extends AbstractEntity implements Serializable, IQfCriteria<BeMcAddress> {

	private static final long serialVersionUID = 7605254430750301523L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "MC_ADDR_ID")
	private Integer mcAddrId;

	@JsonIgnoreProperties("mcAddresses")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MC_PROF_ID")
	private BeMcProfile mcProfile;

	@Column(name = "MC_BRANCH_NAME")
	private String mcBranchName;

	@Column(name = "ADDR_1")
	private String addr1;

	@Column(name = "ADDR_2")
	private String addr2;

	@Column(name = "ADDR_3")
	private String addr3;

	@Column(name = "ADDR_4")
	private String addr4;

	// @OneToOne(fetch = FetchType.LAZY)
	// @JoinColumn(name = "CITY_CD")
	// private RefCity city;

	// @OneToOne(fetch = FetchType.LAZY)
	// @JoinColumn(name = "STATE_CD")
	// private RefState state;

	@Column(name = "CITY_DESC")
	private String cityDesc;

	@Column(name = "STATE_DESC")
	private String stateDesc;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNTRY_CD")
	private RefCountry country;

	@Column(name = "ZIPCODE")
	private String zipcode;

	@Column(name = "ADDR_TYPE")
	private String addrType;

	@Column(name = "LATITUDE")
	private Double latitude;

	@Column(name = "LONGITUDE")
	private Double longitude;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TZID")
	private RefTimeZone timezone;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getMcAddrId() {
		return mcAddrId;
	}


	public void setMcAddrId(Integer mcAddrId) {
		this.mcAddrId = mcAddrId;
	}


	public BeMcProfile getMcProfile() {
		return mcProfile;
	}


	public void setMcProfile(BeMcProfile mcProfile) {
		this.mcProfile = mcProfile;
	}


	public String getMcBranchName() {
		return mcBranchName;
	}


	public void setMcBranchName(String mcBranchName) {
		this.mcBranchName = mcBranchName;
	}


	public String getAddr1() {
		return addr1;
	}


	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}


	public String getAddr2() {
		return addr2;
	}


	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}


	public String getAddr3() {
		return addr3;
	}


	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}


	public String getAddr4() {
		return addr4;
	}


	public void setAddr4(String addr4) {
		this.addr4 = addr4;
	}

	// public RefCity getCity() {
	// return city;
	// }
	//
	// public void setCity(RefCity city) {
	// this.city = city;
	// }
	//
	// public RefState getState() {
	// return state;
	// }
	//
	// public void setState(RefState state) {
	// this.state = state;
	// }


	public RefCountry getCountry() {
		return country;
	}


	public String getCityDesc() {
		return cityDesc;
	}


	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc;
	}


	public String getStateDesc() {
		return stateDesc;
	}


	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc;
	}


	public void setCountry(RefCountry country) {
		this.country = country;
	}


	public String getZipcode() {
		return zipcode;
	}


	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}


	public String getAddrType() {
		return addrType;
	}


	public void setAddrType(String addrType) {
		this.addrType = addrType;
	}


	public Double getLatitude() {
		return latitude;
	}


	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}


	public Double getLongitude() {
		return longitude;
	}


	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}


	public RefTimeZone getTimezone() {
		return timezone;
	}


	public void setTimezone(RefTimeZone timezone) {
		this.timezone = timezone;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}
