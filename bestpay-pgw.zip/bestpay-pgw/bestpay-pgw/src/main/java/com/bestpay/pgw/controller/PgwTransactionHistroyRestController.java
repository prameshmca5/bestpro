package com.bestpay.pgw.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwTransactionHistory;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.service.PgwTransactionHistoryService;


/**
 * @author Ramesh Pongiannan
 * @since 01/05/2019
 */
@RestController
@RequestMapping(PgwUrlConstants.TRANS_HISTROY)
public class PgwTransactionHistroyRestController extends AbstractRestController {

	private static final Logger logger = LoggerFactory.getLogger(PgwTransactionHistroyRestController.class);

	@Autowired
	public PgwTransactionHistoryService pgwTransactionHistoryService;
 	
	@GetMapping(value = PgwUrlConstants.FIND_BY_ORDER_DET_HIST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<PgwTransactionHistory> findBySellerOrderNo(@RequestParam(value = "orderId") String orderId, HttpServletRequest request) {
			List<PgwTransactionHistory> transList = new ArrayList<>();
			List<PgwTransactionHistory> pgwTransactionHistory = pgwTransactionHistoryService.findByOrderIDGetDetails(orderId);
			for (PgwTransactionHistory c : pgwTransactionHistory) {
				transList.add(dozerMapper.map(c, PgwTransactionHistory.class));
			}
			logger.info("Collection Result {}", transList);
			return transList;
		}
}
