package com.bestpay.pgw.service;

import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.RefDocumentRepository;
import com.bestpay.pgw.model.RefDocument;
import com.bestpay.pgw.util.QualifierConstants;

@Transactional
@Service(QualifierConstants.REF_DOCUMENT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_DOCUMENT_SVC)
public class RefDocumentService extends AbstractService<RefDocument> {

	@Autowired
	private RefDocumentRepository refDocumentDao;

	@Override
	public GenericRepository<RefDocument> primaryDao() {
		return refDocumentDao;
	}

	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<RefDocument> findAllByTrxnNo(@Param("trxnNo") String trxnNo) {
		return refDocumentDao.findAllByTrxnNo(trxnNo);
	}

}