package com.be.controller;


import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.be.client.OcrRegulaServiceClient;
import com.be.core.AbstractRestController;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.constants.RegulaFieldEnum;
import com.be.sdk.model.RegulaOcrRequest;
import com.be.sdk.model.RegulaOcrResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.icao.sdk.client.RegularServiceClient;
import com.icao.sdk.model.RegularOcr.ContainerList;
import com.icao.sdk.model.RegularOcr.Root;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;


@RestController
@RequestMapping(BeUrlConstants.OCR)
public class OcrRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(OcrRestController.class);

	@Autowired
	private RegularServiceClient regularService;

	@Autowired
	private OcrRegulaServiceClient ocrRegulaService;


	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/regula/ocrid", method = RequestMethod.POST)
	public @ResponseBody List<List> ocrIdInfo(@RequestBody com.icao.sdk.model.RegularOcrRequest ocrReq,
			BindingResult result, HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {

		JSONObject dtl1 = new JSONObject();
		dtl1.put("scenario", ocrReq.getScenario());

		JSONObject dtl2 = new JSONObject();
		dtl2.put("image", ocrReq.getImage());

		JSONObject obj1 = new JSONObject();
		obj1.put("format", ocrReq.getFormat());
		obj1.put("light", 6);
		obj1.put("ImageData", (dtl2));

		JSONArray objArr = new JSONArray();
		objArr.add(obj1);

		JSONObject obj = new JSONObject();
		obj.put("processParam", dtl1);
		obj.put("List", objArr);

		LOGGER.info("REGULAR OCR REQUEST: {}", new ObjectMapper().valueToTree(obj));
		Object ocrRes = regularService.ocrIdCardDetails(obj);
		// LOGGER.info("REGULAR OCR RESPONSE: {}", new
		// ObjectMapper().valueToTree(ocrRes));
		Root root = new Root();
		ContainerList cntrList = new ContainerList();
		List<List> list2 = new ArrayList<>();
		new ArrayList<>();
		new ArrayList<>();
		try {
			root = JsonUtil.transferToObject(ocrRes, Root.class);
			cntrList = root.getContainerList();
			list2 = cntrList.getList();
			// int listCount = list2.size();
			// text = (List<Text>) ((List2) list2).getText();
			// fList = text.getFieldList();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list2;
	}


	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.OCR_MYKAD, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public RegulaOcrResponse ocrMyKadInfo(@RequestBody RegulaOcrRequest ocrReq, HttpServletRequest request)
			throws IOException, ParseException {

		RegulaOcrResponse dto = new RegulaOcrResponse();

		JSONObject dtl1 = new JSONObject();
		dtl1.put("scenario", ocrReq.getScenario());

		JSONObject dtl2 = new JSONObject();
		dtl2.put("image", ocrReq.getImage());

		JSONObject obj1 = new JSONObject();
		obj1.put("format", ocrReq.getFormat());
		obj1.put("light", 6);
		obj1.put("ImageData", (dtl2));

		JSONArray objArr = new JSONArray();
		objArr.add(obj1);

		JSONObject obj = new JSONObject();
		obj.put("processParam", dtl1);
		obj.put("List", objArr);

		LOGGER.info("REGULAR OCR REQUEST: {}", new ObjectMapper().valueToTree(obj));
		Object ocrRes = ocrRegulaService.ocrIdCardDetails(obj);

		JsonNode ocrNode = JsonUtil.transferToObject(ocrRes, JsonNode.class);
		if (!BaseUtil.isObjNull(ocrNode)) {
			JsonNode containerList = ocrNode.get("ContainerList");

			if (!BaseUtil.isObjNull(containerList) && !BaseUtil.isObjNull(containerList.get("List"))) {
				if (containerList.get("List").isArray()) {
					LOGGER.info("REQUEST====={}", JsonUtil.objectMapper().valueToTree(containerList.get("List")));
					Map<String, Object> fieldMap = new HashMap<>();
					for (JsonNode arrayElement : containerList.get("List")) {
						if (!BaseUtil.isObjNull(arrayElement.get("ListVerifiedFields"))) {
							JsonNode listVerifiedFields = arrayElement.get("ListVerifiedFields");
							if (!BaseUtil.isObjNull(listVerifiedFields.get("pFieldMaps"))) {
								if (listVerifiedFields.get("pFieldMaps").isArray()) {
									LOGGER.info("REQUEST====={}", JsonUtil.objectMapper()
											.valueToTree(listVerifiedFields.get("pFieldMaps")));

									for (JsonNode arrayElementField : listVerifiedFields.get("pFieldMaps")) {
										String fieldName = RegulaFieldEnum.findFieldByCode(
												arrayElementField.get("FieldType").asInt());
										if (!BaseUtil.isObjNull(fieldName)) {
											if (!BaseUtil.isObjNull(arrayElementField.get("Field_Visual"))) {
												fieldMap.put(fieldName,
														arrayElementField.get("Field_Visual").asText());
											}
										}
									}

								}
							}

						}

						if (ocrReq.isEmbedImage() && !BaseUtil.isObjNull(arrayElement.get("DocGraphicsInfo"))) {
							JsonNode docGraphicsInfo = arrayElement.get("DocGraphicsInfo");
							if (!BaseUtil.isObjNull(docGraphicsInfo.get("pArrayFields"))) {
								if (docGraphicsInfo.get("pArrayFields").isArray()) {

									for (JsonNode arrayElementField : docGraphicsInfo.get("pArrayFields")) {
										String imgType = arrayElementField.get("FieldName").asText();

										if (BaseUtil.isEqualsCaseIgnore(imgType, "Portrait")) {
											JsonNode imgElement = arrayElementField.get("image");

											if (!BaseUtil.isObjNull(imgElement)) {
												if (!BaseUtil.isObjNull(imgElement.get("format"))) {
													fieldMap.put("format",
															imgElement.get("format").asText());
												}
												if (!BaseUtil.isObjNull(imgElement.get("image"))) {
													fieldMap.put("image",
															imgElement.get("image").asText());
												}
											}
										}
									}

								}
							}

						}

					}
					
					dto = JsonUtil.transferToObject(JsonUtil.convertMapToJson(fieldMap), RegulaOcrResponse.class);

					if(BaseUtil.isObjNull(dto.getIdNo())) {
						dto = new RegulaOcrResponse();
					
					} else {
						String addressArray[] = dto.getAddress().split(Pattern.quote("^"));
						if (!BaseUtil.isObjNull(addressArray) && addressArray.length > 0) {

							if (!BaseUtil.isObjNull(addressArray[addressArray.length - 1])) {
								dto.setStateDesc(addressArray[addressArray.length - 1]);
							}

							if (!BaseUtil.isObjNull(addressArray[addressArray.length - 2])) {
								String poscodeCity = addressArray[addressArray.length - 2];
								String tempPostcode = poscodeCity.substring(0, 5).replaceAll("[^0-9]", "");
								dto.setPostcode(tempPostcode.length() == 5 ? tempPostcode : "");
								dto.setCityDesc(poscodeCity.substring(6, poscodeCity.length()));
							}

							for (int i = 1; i <= addressArray.length - 2; i++) {
								if (i == 1) {
									dto.setAddress1(addressArray[0]);
								}
								if (i == 2) {
									dto.setAddress2(addressArray[1]);
								}
								if (i == 3) {
									dto.setAddress3(addressArray[2]);
								}
							}
						}
						
						dto.setAddress(dto.getAddress().replace('^', ' '));
					}
				}
			} else {
				dto = new RegulaOcrResponse();
			}

		}

		return dto;
	}

}
