package com.bestpay.pgw.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.RefNationality;
import com.bestpay.pgw.util.QualifierConstants;

/**
 * @author Md Asif Aftab
 * @since 27th Feb 2018
 */

@Repository
@RepositoryDefinition(domainClass = RefNationality.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_NATIONALITY_DAO)
public interface RefNationalityRepository extends
		GenericRepository<RefNationality> {

	@Query("select u from RefNationality u where u.ntnltyCode = :ntnltyCode ")
	public RefNationality findByNationalityCode(
			@Param("ntnltyCode") String ntnltyCode);

	@Query("select u from RefNationality u where u.ntnltyDescEn = :ntnltyDescEn")
	public RefNationality findByDesc(@Param("ntnltyDescEn") String ntnltyDescEn);

}