/**
  * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.constants;


/**
 * @author Mary Jane Buenaventura
 * @since May 17, 2018
 */
public class PageTemplate {

	private PageTemplate() {
		throw new IllegalStateException("Utility class");
	}


	public static final String TEMP_COMPONENTS = "pg_components";

	public static final String TEMP_ERROR = "pg_error";

	public static final String TEMP_ERROR_403 = "pg_error403";

	public static final String TEMP_LOGIN = "login";

	public static final String IDM_FORGOT_PASSWRD = "forgot_password";

	public static final String TEMP_USERMGMT = "idm_usermgmt";

	public static final String TEMP_IDM_USR_CHNG_PWORD = "change-password";

	public static final String TEMP_IDM_USR_CRED = "user_profile";

	public static final String TEMP_IDM_USR_LST = "user_list";

	public static final String TEMP_DASHBOARD = "dashboard";

	public static final String TEMP_CMN_STTC_LST = "static_list";

	public static final String ANNOUNCEMENT = "announcement";

	public static final String TEMP_BLACKLIST = "blacklist";

	public static final String TEMP_BLACKLIST_CRT = "create_blacklist";

	public static final String TEMP_SETTLEMENT = "settlement";

	public static final String TEMP_DAILY_RPT = "transaction_daily_report";

	public static final String TEMP_DT_RNG_RPT = "transaction_date_range_report";

	public static final String TEMP_IDM_MERCHANT_LST = "merchant-list";

	public static final String TEMP_MER_CRED = "merchant-profile";

	public static final String TEMP_ACC_INFO = "account-info";

	public static final String TEMP_GEN_INFO = "general-info";

	public static final String TEMP_FRAUD_SET = "fraud-setting";

	public static final String TEMP_ACC_SET = "account-setting";

	public static final String TEMP_BUS_CAT = "business-category";

	public static final String TEMP_CHANNEL_SET = "channel-setting";

	public static final String TEMP_PAY_PAGE_SET = "payment-page-setting";

	public static final String TEMP_REPORT_SET = "report-setting";

	public static final String TEMP_RESTRICTION = "restriction";

	public static final String TEMP_SETTLEMENT_SET = "settlement-setting";

	public static final String TEMP_MER_USER = "merchant-user";

	public static final String TEMP_SEND_ACC_INFO = "send-acc-info";

	public static final String TEMP_TRANSACTION = "transaction_listing";

	public static final String TEMP_TOP10_TRANSACTION = "top10_transaction";

	public static final String TEMP_TRANSACTION_DTLS = "transaction_details";

	public static final String TEMP_TICKET = "ticket";

	public static final String TEMP_STTLMT_RPT = "settlement_report";

	public static final String TEMP_TEST_PAYLK = "testpaylink";

	public static final String TEMP_TEST_PAYLK_FORM = "testpaylinkform";

	public static final String TEMP_SEMT_TRANS_VIEW = "settlement_details";

	public static final String TEMP_SEMT_TRANS_INVOCE = "settlement_invoice";

	public static final String TEMP_TEST_RECEIPT = "receipt";

	public static final String TEMP_MER_FPX_PAYMENT = "merfpxpay2form";

	public static final String TEMP_TEST_PAYLK_2 = "mer_fpx_paylink";

	public static final String TEMP_CMS_CHANNEL = "cms-channel-list";

	public static final String TEMP_CMS_CHANNEL_NEW = "cms-channel-info";

	public static final String TEMP_SEMT_TRANS_RECEIPT = "settlement_receipt";

	public static final String UPDT_SETTLEMENT_STATUS = "update-settlement-status";

	public static final String TEMP_TICKET_CRT = "create_ticket";

	public static final String TEMP_DASH_TRANS_VIEW = "dashboard-transaction-list";

	public static final String TEMP_DASH_MRCHNT_VIEW = "dashboard-merchant-list";

	public static final String TEMP_DASH_TKT_VIEW = "dashboard-ticket-list";

	public static final String TEMP_CMS_MENU = "cms-menu-list";

	public static final String TEMP_CMS_SUBSCRIPTION = "cms-subscription-list";

	public static final String TEMP_CMS_SUBSCRIPTION_NEW = "cms-subscription-info";

	public static final String TEMP_CMS_STATUS = "cms-status-list";

	public static final String TEMP_CMS_STATUS_NEW = "cms-status-info";

	public static final String TEMP_CMS_MENU_NEW = "cms-menu-info";

	public static final String TEMP_REMITTENCE_SETTLEMENT = "remittence-settlement";

	public static final String TEMP_REMITT_SEMT_TRANS_VIEW = "remittence-settlement-details";

	public static final String TEMP_REMITT_SEMT_TRANS_INVOCE = "remittence-settlement-invoice";

	public static final String TEMP_REMITT_TRANSACTION_DTLS = "remittence-transaction-details";

	public static final String TEMP_MERCHANT_COMPANY = "merchant-company";

	public static final String TEMP_MER_MTO_MAP = "merchant-mto-mapping";

	public static final String TEMP_REFERRAL_INFO = "referral-info";

	public static final String REMIT_UPDT_SETTLEMENT_STATUS = "remittence-update-settlement-status";

	public static final String TEMP_REFERRAL_PROFILE = "referral-profile";

	public static final String TEMP_CHANNEL_SETTING = "channel-setting";

	public static final String TEMP_BENEFICIARY = "beneficiary";

	public static final String TEMP_SEND_COMPANY_ID = "send-company-id";

	public static final String TEMP_CREATE_BENEFICIARY = "create-beneficiary";

	public static final String TEMP_PROVIDER_LIST = "provider_list";

	public static final String TEMP_PROVIDER_NEW = "provider_new";

	public static final String TEMP_MULTI_PAYLK = "multipaylink";

	public static final String TEMP_MER_MTO_REGSTER = "merchant_mtoregister";

	public static final String TEMP_REMIT_STTLMT_RPT = "remittance-settlement-report";

	public static final String TEMP_PGW_CONFIG = "payment-configuration";

	public static final String TEMP_PGW_CONFIG_INFO = "payment-configuration-info";

	public static final String TEMP_EXCHANGE_RATE = "exchange-rates";
	
	public static final String TEMP_IPAY_CC = "ipay-cc";
	
	public static final String TEMP_IPAY_CC_FORM = "ipay-cc-form";

}
