
package com.bestpay.be.sdk.model;


import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id", "country", "countryCode", "currency", "isUser", "created" })
public class BeneficiaryAccount {

	@JsonProperty("id")
	private String id;

	@JsonProperty("country")
	private String country;

	@JsonProperty("countryCode")
	private String countryCode;

	@JsonProperty("currency")
	private String currency;

	@JsonProperty("isUser")
	private Boolean isUser;

	@JsonProperty("created")
	private String created;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<>();


	@JsonProperty("id")
	public String getId() {
		return id;
	}


	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}


	@JsonProperty("country")
	public String getCountry() {
		return country;
	}


	@JsonProperty("country")
	public void setCountry(String country) {
		this.country = country;
	}


	@JsonProperty("countryCode")
	public String getCountryCode() {
		return countryCode;
	}


	@JsonProperty("countryCode")
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}


	@JsonProperty("currency")
	public String getCurrency() {
		return currency;
	}


	@JsonProperty("currency")
	public void setCurrency(String currency) {
		this.currency = currency;
	}


	@JsonProperty("isUser")
	public Boolean getIsUser() {
		return isUser;
	}


	@JsonProperty("isUser")
	public void setIsUser(Boolean isUser) {
		this.isUser = isUser;
	}


	@JsonProperty("created")
	public String getCreated() {
		return created;
	}


	@JsonProperty("created")
	public void setCreated(String created) {
		this.created = created;
	}


	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return additionalProperties;
	}


	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		additionalProperties.put(name, value);
	}

}
