package com.bestpay.pgw.sdk.incentiveremit.model;


public class ExRateRequest {

	private String transferAmount;

	private String paymentMode;

	private String calcBy;

	private String locationId;

	private String payoutCountry;

	private String promotionCode;

	private String payoutPartnerId;


	public String getTransferAmount() {
		return transferAmount;
	}


	public void setTransferAmount(String transferAmount) {
		this.transferAmount = transferAmount;
	}


	public String getPaymentMode() {
		return paymentMode;
	}


	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}


	public String getCalcBy() {
		return calcBy;
	}


	public void setCalcBy(String calcBy) {
		this.calcBy = calcBy;
	}


	public String getLocationId() {
		return locationId;
	}


	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}


	public String getPayoutCountry() {
		return payoutCountry;
	}


	public void setPayoutCountry(String payoutCountry) {
		this.payoutCountry = payoutCountry;
	}


	public String getPromotionCode() {
		return promotionCode;
	}


	public void setPromotionCode(String promotionCode) {
		this.promotionCode = promotionCode;
	}


	public String getPayoutPartnerId() {
		return payoutPartnerId;
	}


	public void setPayoutPartnerId(String payoutPartnerId) {
		this.payoutPartnerId = payoutPartnerId;
	}

}
