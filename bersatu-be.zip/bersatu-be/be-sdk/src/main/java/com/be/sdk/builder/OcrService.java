package com.be.sdk.builder;


import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.RegulaOcrRequest;
import com.be.sdk.model.RegulaOcrResponse;


public class OcrService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public OcrService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	public RegulaOcrResponse regulaOcrMyKad(RegulaOcrRequest dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.OCR);
		sb.append(BeUrlConstants.OCR_MYKAD);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, RegulaOcrResponse.class);
	}

}
