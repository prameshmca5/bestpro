/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.qf;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidSubscriberUser;
import com.bstsb.util.BaseUtil;


/**
 * @author Naem Othman
 * @since March 04, 2019
 */
@Service(QualifierConstants.BID_SUBSCRIBER_USER_QF)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_SUBSCRIBER_USER_QF)
@Transactional
public class BidSubscriberUserQf extends QueryFactory<BidSubscriberUser> {

	protected Logger logger = LoggerFactory.getLogger(this.getClass());

	@PersistenceContext
	private EntityManager em;


	@Override
	public Specification<BidSubscriberUser> searchByProperty(final BidSubscriberUser t) {
		return new Specification<BidSubscriberUser>() {

			@Override
			public Predicate toPredicate(Root<BidSubscriberUser> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<Predicate> predLst = new ArrayList<>();

				if (!BaseUtil.isObjNull(t.getSubscrUsrId())) {
					predLst.add(cb.and(cb.equal(root.get("subscrUsrId"), t.getSubscrUsrId())));
				}

				if (!BaseUtil.isObjNull(t.getSecUserId())) {
					predLst.add(cb.and(cb.equal(root.get("secUserId"), t.getSecUserId())));
				}

				if (!BaseUtil.isObjNull(t.getSubscrId())) {
					predLst.add(cb.and(cb.equal(root.get("subscrId"), t.getSubscrId())));
				}

				if (!BaseUtil.isObjNull(t.getMobileNo())) {
					predLst.add(cb.and(cb.equal(root.get("mobileNo"), t.getMobileNo())));
				}

				if (!BaseUtil.isObjNull(t.getDeviceId())) {
					predLst.add(cb.and(cb.equal(root.get("deviceId"), t.getDeviceId())));
				}

				if (!BaseUtil.isObjNull(t.getInvitationCd())) {
					predLst.add(cb.and(cb.equal(root.get("invitationCd"), t.getInvitationCd())));
				}

				if (!BaseUtil.isObjNull(t.getStatus())) {
					predLst.add(cb.and(cb.equal(root.get("status"), t.getStatus())));
				}

				if (!BaseUtil.isListNull(predLst)) {
					return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
				}
				return query.getRestriction();
			}
		};
	}

}
