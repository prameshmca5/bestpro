/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.sgw.constants;


import java.io.File;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
public class ConfigConstants {

	private ConfigConstants() {
		throw new IllegalStateException("Constants class");
	}


	public static final String BASE_PACKAGE = "com.bestid";

	public static final String BASE_PACKAGE_REPO = "com.bestid.sgw.dao";

	public static final String BASE_PACKAGE_MODEL = "com.bestid.sgw.model";

	public static final String BASE_PACKAGE_CONTROLLER = "com.bestid.sgw.controller";

	public static final String PATH_PROJ_CONFIG = "bestid.config.path";

	public static final String PATH_CATALINA_HOME = "catalina.home";

	public static final String PATH_CATALINA_BASE = "catalina.base";

	public static final String PROJ_JBOSS_HOME = "jboss.server.config.dir";

	public static final String PROPERTY_FILENAME = "bestid-sgw";

	public static final String PROPERTIES_EXT = ".properties";

	public static final String FILE_SYS_RESOURCE = File.separator + PROPERTY_FILENAME + PROPERTIES_EXT;

	public static final String PROPERTY_CLASSPATH = "classpath:" + PROPERTY_FILENAME;

	public static final String FILE_PFX = "file:";

	public static final String DB_CONF_DRIVER = "mysql.db.driver";

	public static final String DB_CONF_URL = "mysql.db.url";

	public static final String DB_CONF_UNAME = "mysql.db.uname";

	public static final String DB_CONF_PWORD = "mysql.db.pword";

	public static final String DB_CONF_HIKARI_CONN_TIMEOUT = "mysql.db.pool.hikaricp.connectionTimeout";

	public static final String DB_CONF_HIKARI_IDLE_TIMEOUT = "mysql.db.pool.hikaricp.idleTimeout";

	public static final String DB_CONF_HIKARI_MAX_LIFETIME = "mysql.db.pool.hikaricp.maxLifetime";

	public static final String DB_CONF_HIKARI_CONN_QUERY = "mysql.db.pool.hikaricp.connectionTestQuery";

	public static final String DB_CONF_HIKARI_MIN_IDLE = "mysql.db.pool.hikaricp.minimumIdle";

	public static final String DB_CONF_HIKARI_MAX_POOL_SIZE = "mysql.db.pool.hikaricp.maximumPoolSize";

	public static final String DB_CONF_HIKARI_INIT_SQL = "mysql.db.pool.hikaricp.connectionInitSql";

	public static final String DB_CONF_HIKARI_VALID_TIMEOUT = "mysql.db.pool.hikaricp.validationTimeout";

	public static final String DB_CONF_HIKARI_LEAK_DETECT = "mysql.db.pool.hikaricp.leakDetectionThreshold";

	public static final String SVC_DM_URL = "dm.service.url";

	public static final String SVC_DM_TIMEOUT = "dm.service.timeout";

	public static final String SVC_SVC_URL = "svc.service.url";

	public static final String SVC_SVC_TIMEOUT = "svc.service.timeout";

	public static final String SVC_IDM_URL = "idm.service.url";

	public static final String SVC_IDM_TIMEOUT = "idm.service.timeout";

	public static final String SVC_IDM_SKEY = "idm.service.skey";

	public static final String SVC_IDM_CLIENT = "idm.service.client";

	public static final String SVC_NOT_URL = "not.service.url";

	public static final String SVC_NOT_TIMEOUT = "not.service.timeout";

}