/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.BlacklistCustomDao;
import com.bestpay.be.dao.PgwMerchantBlacklistRepository;
import com.bestpay.be.model.PgwMerchantBlacklist;
import com.bestpay.be.sdk.model.BlacklistInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Afif Saman
 * @since June 5, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_MERBLCKLST_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERBLCKLST_SVC)
public class PgwMerchantBlacklistService extends AbstractService<PgwMerchantBlacklist> {

	@Autowired
	private PgwMerchantBlacklistRepository blacklistDao;

	@Autowired
	private BlacklistCustomDao blacklistInfoDao;


	@Override
	public PgwMerchantBlacklistRepository primaryDao() {
		return blacklistDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwMerchantBlacklist> searchBlacklist(BlacklistInfo blacklistInfo,
			DataTableRequest dataTableInRQ) {
		return blacklistInfoDao.searchByPagination(blacklistInfo, dataTableInRQ);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantBlacklist findBlacklistByValue(String value) {
		return blacklistDao.findBlacklistByValue(value);
	}


	// @Cacheable(key =
	// "T(com.bestinet.commons.sdk.constants.CmnCacheConstants).CACHE_KEY_CMPNY_ACTVTY_ID.concat(#activityId)",
	// condition = "#activityId != null and #result != null")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public PgwMerchantBlacklist findByBlacklistId(String blcklstId) {
		int id = Integer.parseInt(blcklstId);
		return blacklistDao.findByBlacklistId(id);
	}

}