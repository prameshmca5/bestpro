/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeTvlMcAttendance;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.McAttendance;
import com.be.sdk.model.Tvl;
import com.be.service.BeAcctProfileService;
import com.util.BaseUtil;
import com.util.JsonUtil;


/**
 * @author Atiqah Khairuddin
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_ACCT_TRAVELLER_QF)
public class BeTvlMcAttendanceQf extends QueryFactory<BeTvlMcAttendance> {

	@Autowired
	BeAcctProfileService acctProfileSvc;

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BeTvlMcAttendance> searchByProperty(BeTvlMcAttendance t) {
		return (Root<BeTvlMcAttendance> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}


	@Override
	public List<BeTvlMcAttendance> searchAllByProperty(BeTvlMcAttendance t) {
		CriteriaQuery<BeTvlMcAttendance> cq = cb.createQuery(BeTvlMcAttendance.class);
		Root<BeTvlMcAttendance> from = cq.from(BeTvlMcAttendance.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			McAttendance dto = JsonUtil.transferToObject(criteria, McAttendance.class);
			
			if (!BaseUtil.isObjNull(dto.getAttendanceDtFrom())) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(dto.getAttendanceDtFrom());
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				Date endDate = cal.getTime();
				predicates.add(cb.greaterThanOrEqualTo(from.get("createDt"), endDate));
			}

			if (!BaseUtil.isObjNull(dto.getAttendanceDtTo())) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(dto.getAttendanceDtTo());
				cal.set(Calendar.HOUR_OF_DAY, 23);
				cal.set(Calendar.MINUTE, 59);
				cal.set(Calendar.SECOND, 59);
				Date endDate = cal.getTime();
				predicates.add(cb.lessThanOrEqualTo(from.get("createDt"), endDate));
			}
			
			if (!BaseUtil.isObjNull(dto.getMcProfId())) {
				predicates.add(cb.equal(from.get("mcProfId"), dto.getMcProfId()));
			}

		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

	/*
	 * @Override public List<Predicate> generateCriteria(CriteriaBuilder cb,
	 * From<?, ?> from, IQfCriteria<?> criteria) { List<Predicate> predicates =
	 * new ArrayList<>(); try { BeTvlMcAttendance dto =
	 * JsonUtil.transferToObject(criteria, BeTvlMcAttendance.class); if
	 * (!BaseUtil.isObjNull(dto.getStatusId())) {
	 * predicates.add(cb.equal(from.get("statusId"), dto.getStatusId())); } }
	 * catch (IOException e) { throw new BeException(BeErrorCodeEnum.E400C912);
	 * }
	 *
	 * return predicates; }
	 */

}
