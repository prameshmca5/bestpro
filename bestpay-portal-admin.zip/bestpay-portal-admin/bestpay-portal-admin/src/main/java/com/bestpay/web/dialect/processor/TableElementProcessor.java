/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dialect.processor;


import org.thymeleaf.Arguments;
import org.thymeleaf.dom.Element;
import org.thymeleaf.processor.ProcessorResult;

import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.dialect.AbstractBstElement;
import com.bestpay.web.dialect.constants.AttributeConstants;
import com.bestpay.web.dialect.constants.ElementConstants;
import com.bestpay.web.dialect.constants.ElementEnum;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class TableElementProcessor extends AbstractBstElement {

	public TableElementProcessor(String elementName) {
		super(elementName);
	}


	@Override
	protected ProcessorResult processElement(Arguments arguments, Element element) {
		String elementNm = getElementName(element);

		Element newElement = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_TABLE, false);
		newElement.setAttribute(AttributeConstants.ATTR_CLASS, "table-responsive");
		newElement.setRecomputeProcessorsImmediately(true);

		String attrClass = ElementEnum.findStyleByName(elementNm);

		if (!BaseUtil.isObjNull(element.getAttributeValue(AttributeConstants.ATTR_CLASS))) {
			attrClass = element.getAttributeValue(AttributeConstants.ATTR_CLASS) + " " + attrClass;
		} else if (!BaseUtil.isObjNull(element.getAttributeValue(AttributeConstants.ATTR_TH_CLASSAPPEND))) {
			attrClass = attrClass + " " + element.getAttributeValue(AttributeConstants.ATTR_TH_CLASSAPPEND);
		} else {
			attrClass = ElementEnum.findStyleByName(elementNm);
		}

		newElement.setAttribute(AttributeConstants.ATTR_CLASS, attrClass);

		if (BaseUtil.isObjNull(element.getAttributeValue(AttributeConstants.ATTR_DATA_PAGE_LEN))) {
			newElement.setAttribute("data-page-length", "15");
		}

		if (BaseUtil.isObjNull(element.getAttributeValue(AttributeConstants.ATTR_DATA_PAGING))) {
			newElement.setAttribute("data-paging", "true");
		}

		element.getParent().insertAfter(element, newElement);
		element.getParent().removeChild(element);

		return ProcessorResult.OK;
	}


	@Override
	public int getPrecedence() {
		return 100000;
	}
}
