/**
 *
 */
package com.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.BeTvlMcAttendance;


/**
 * @author Atiqah Khairuddin
 *
 */
@Lazy
@Repository
@RepositoryDefinition(domainClass = BeTvlMcAttendance.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_MC_ATTENDANCE_DAO)
public interface BeTvlMcAttendanceRepository extends GenericRepository<BeTvlMcAttendance> {

	/*
	 * @Query("select u from BeTvlMcAttendance u where u.tvlProfile.tvlProfile = :tvlProfile "
	 * ) BeTvlMcAttendance findByTvlProfile(@Param("tvlProfile") Integer
	 * tvlProfile);
	 */

	@Query("select u from BeTvlMcAttendance u where u.tvlProfile.tvlProfId = :tvlProfId ")
	BeTvlMcAttendance findByTvlProfile(@Param("tvlProfId") Integer tvlProfId);
}
