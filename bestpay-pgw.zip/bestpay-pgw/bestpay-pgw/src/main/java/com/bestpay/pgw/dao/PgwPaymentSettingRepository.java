/**
 *  
 */
package com.bestpay.pgw.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.PgwPaymentSetting;
import com.bestpay.pgw.util.QualifierConstants;

/**
 * @author Chaithanya Kumar
 * @since 10/07/2018
 */
@Repository
@RepositoryDefinition(domainClass = PgwPaymentSetting.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_PAY_SETTING_DAO)
public interface PgwPaymentSettingRepository extends GenericRepository<PgwPaymentSetting> {

	
	@Query("select u from PgwPaymentSetting u where u.merchantId=:merchantId ")
	public PgwPaymentSetting findByMerchantId (@Param("merchantId") String merchantId);
	 
}