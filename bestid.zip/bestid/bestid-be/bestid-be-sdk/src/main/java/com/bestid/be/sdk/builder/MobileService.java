/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.builder;


import com.bestid.be.sdk.client.BeRestTemplate;
import com.bestid.be.sdk.constants.BeUrlConstants;
import com.bestid.be.sdk.model.MessageResponse;
import com.bestid.be.sdk.model.MobileUser;
import com.bestid.be.sdk.model.TransSign;
import com.bestid.be.sdk.model.UsrProfile;


/**
 * @author Naem Othman
 * @since Feb 18, 2019
 */
public class MobileService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public MobileService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	public MessageResponse registerCert(TransSign transSign) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_REGISTRATION_CERT);
		return restTemplate.postForObject(getServiceURI(sb.toString()), transSign, MessageResponse.class);
	}


	public MessageResponse storeCert(TransSign transSign) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_STORE_CERT);
		return restTemplate.postForObject(getServiceURI(sb.toString()), transSign, MessageResponse.class);
	}


	public MessageResponse revokeCert(TransSign transSign) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_REVOKE_CERT);
		return restTemplate.postForObject(getServiceURI(sb.toString()), transSign, MessageResponse.class);
	}


	public MessageResponse submitCert(TransSign transSign) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_SUBMIT_CERT);
		return restTemplate.postForObject(getServiceURI(sb.toString()), transSign, MessageResponse.class);
	}


	public MessageResponse login(MobileUser mobileUser) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_LOGIN);
		return restTemplate.postForObject(getServiceURI(sb.toString()), mobileUser, MessageResponse.class);
	}


	public MessageResponse logout(MobileUser mobileUser) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_LOGOUT);
		return restTemplate.postForObject(getServiceURI(sb.toString()), mobileUser, MessageResponse.class);
	}


	public MessageResponse searchFace(MobileUser mobileUser) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_SEARCH_FACE);
		return restTemplate.postForObject(getServiceURI(sb.toString()), mobileUser, MessageResponse.class);
	}


	public MessageResponse verifyPinCode(MobileUser mobileUser) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_PINCODE_VERIFY);
		return restTemplate.postForObject(getServiceURI(sb.toString()), mobileUser, MessageResponse.class);
	}


	public MessageResponse updatePinCode(MobileUser mobileUser) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_PINCODE_UPDATE);
		return restTemplate.postForObject(getServiceURI(sb.toString()), mobileUser, MessageResponse.class);
	}


	public MessageResponse genInvCd(MobileUser mobileUser) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_GEN_INVITATION_CODE);
		return restTemplate.postForObject(getServiceURI(sb.toString()), mobileUser, MessageResponse.class);
	}


	public MessageResponse verifyInvCd(MobileUser mobileUser) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_VERIFY_INVITATION_CODE);
		return restTemplate.postForObject(getServiceURI(sb.toString()), mobileUser, MessageResponse.class);
	}


	public MessageResponse searchProfile(UsrProfile profile) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_SEARCH_PROFILE);
		return restTemplate.postForObject(getServiceURI(sb.toString()), profile, MessageResponse.class);
	}


	public MessageResponse verifyAuth(MobileUser mobileUser) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_VERIFY_AUTH);
		return restTemplate.postForObject(getServiceURI(sb.toString()), mobileUser, MessageResponse.class);
	}


	public MessageResponse verifyDigitalid(MobileUser mobileUser) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_VERIFY_DIGITALID);
		return restTemplate.postForObject(getServiceURI(sb.toString()), mobileUser, MessageResponse.class);
	}


	public MessageResponse registerProfile(MobileUser mobileUser) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE_REGISTER_PROFILE);
		return restTemplate.postForObject(getServiceURI(sb.toString()), mobileUser, MessageResponse.class);
	}

}