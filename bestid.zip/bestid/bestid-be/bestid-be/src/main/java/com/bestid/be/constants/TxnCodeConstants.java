/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
public class TxnCodeConstants {

	private TxnCodeConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String HEADER_MESSAGE_ID = "X-Message-Id";

	public static final String HEADER_AUTHORIZATION = "Authorization";

	public static final String HEADER_LANGUAGE = "X-Language";

	public static final String API_QR_IMAGE = "API_QR_IMAGE";

	public static final String API_AUTH_CHECK = "API_AUTH_CHECK";

	public static final String SEC_LOGIN = "SEC_LOGIN";

	public static final String SEC_LOGOUT = "SEC_LOGOUT";

	public static final String SEC_REGISTER_PIN = "SEC_REGISTER_PIN";

	public static final String SEC_REGISTER_PROFILE = "SEC_REGISTER_PROFILE";

	public static final String SEC_REGISTER_FACE = "SEC_REGISTER_FACE";

	public static final String SEC_VERIFY_PIN = "SEC_VERIFY_PIN";

	public static final String SEC_VERIFY_FACE = "SEC_VERIFY_FACE";

	public static final String SEC_VERIFY_QR = "SEC_VERIFY_QR";

	public static final String SEC_FETCH_ACTIVE_DEVICE = "SEC_FETCH_ACTIVE_DEVICE";

	public static final String API_LOGIN = "API_LOGIN";

	public static final String API_USER_SEARCH = "API_USER_SEARCH";

	public static final String API_USER_REGISTER = "API_USER_REGISTER";

	public static final String API_CONTACT_UPDATE = "API_CONTACT_UPDATE";

	public static final String API_DEVICE_SEARCH = "API_DEVICE_SEARCH";

	public static final String API_QR_GENERATE = "API_QR_GENERATE";

	public static final String API_ACTIVATION_CODE_GENERATE = "API_ACTIVATION_CODE_GENERATE";

	public static final String API_DIGITALID_REVOKE = "API_DIGITALID_REVOKE";

	public static final String API_QR_VERIFY = "API_QR_VERIFY";

	public static final String API_QR_CODE_GENERATE = "API_QR_CODE_GENERATE";

	public static final String API_QR_CODE_AUTHORIZE = "API_QR_CODE_AUTHORIZE";

	public static final String SEC_REGISTER_CERT = "SEC_REGISTER_CERT";

	public static final String SEC_STORE_CERT = "SEC_STORE_CERT";

	public static final String SEC_SUBMIT_CERT = "SEC_SUBMIT_CERT";

	public static final String SEC_REVOKE_CERT = "SEC_REVOKE_CERT";

	public static final String API_ACTIVATION_CODE_VERIFY = "API_ACTIVATION_CODE_VERIFY";

	public static final String API_UUID_VERIFY = "API_UUID_VERIFY";

	public static final String SEC_FACE_SEARCH = "SEC_FACE_SEARCH";

	public static final String SEC_INVITATION_CODE_GENERATE = "SEC_INVITATION_CODE_GENERATE";

	public static final String SEC_INVITATION_CODE_VERIFY = "SEC_INVITATION_CODE_VERIFY";

	public static final String API_AUTH_VERIFY = "API_AUTH_VERIFY";

	public static final String API_DIGITALID_VERIFY = "API_DIGITALID_VERIFY";
	
	public static final String API_DIGITALID_STATUS_CHECK = "API_DIGITALID_STATUS_CHECK";

	public static final String SUBSCRIBER_ADD = "SUBSCRIBER_ADD";

	public static final String SUBSCRIBER_LIST = "SUBSCRIBER_LIST";

	public static final String SEC_PROFILE_SEARCH = "SEC_PROFILE_SEARCH";

	public static final String SEC_PINCODE_VERIFY = "SEC_PINCODE_VERIFY";

	public static final String SEC_PINCODE_UPDATE = "SEC_PINCODE_UPDATE";

	public static final String MAINTENANCE_BIDCONFIG = "MAINTENANCE_BIDCONFIG";

}