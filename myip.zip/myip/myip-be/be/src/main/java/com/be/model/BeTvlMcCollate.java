/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_TVL_MC_COLLATE")
public class BeTvlMcCollate extends AbstractEntity implements Serializable, IQfCriteria<BeTvlMcCollate> {

	private static final long serialVersionUID = -7266879672042706729L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TVL_MC_COLLATE_ID")
	private Integer mcCollateId;

	@JsonIgnoreProperties("tvlMcCollates")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TVL_TEST_RESULT_ID")
	private BeTvlTestResult tvlTestResult;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MC_COLLATE_ID")
	private BeConfigMcCollate configMcCollate;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "RESULT_MTDT_ID")
	private RefMetadata resultMtdt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;


	public Integer getMcCollateId() {
		return mcCollateId;
	}


	public void setMcCollateId(Integer mcCollateId) {
		this.mcCollateId = mcCollateId;
	}


	public BeTvlTestResult getTvlTestResult() {
		return tvlTestResult;
	}


	public void setTvlTestResult(BeTvlTestResult tvlTestResult) {
		this.tvlTestResult = tvlTestResult;
	}


	public BeConfigMcCollate getConfigMcCollate() {
		return configMcCollate;
	}


	public void setConfigMcCollate(BeConfigMcCollate configMcCollate) {
		this.configMcCollate = configMcCollate;
	}


	public RefMetadata getResultMtdt() {
		return resultMtdt;
	}


	public void setResultMtdt(RefMetadata resultMtdt) {
		this.resultMtdt = resultMtdt;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
