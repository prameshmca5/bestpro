/**
 * Copyright 2019
 */
package com.be.sdk.constants;


/**
 * Constants for Mail Template Code
 *
 * @author mary.jane
 * @since Dec 21, 2018
 */
public class MailTemplateConstants {

	private MailTemplateConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String CMN_OTP = "CMN_OTP";

	public static final String IDM_REG_SUCCESS = "IDM_REGISTER_SUCCESS";

	public static final String TRAVEL_PAYMENT_SUCCESSFUL = "TRAVEL_PAYMENT_SUCCESSFUL";

	public static final String TRAVEL_PAYMENT_FAIL = "TRAVEL_PAYMENT_FAIL";

	public static final String TRAVEL_DQ_APPROVE = "TRAVEL_DQ_APPROVE";

	public static final String TRAVEL_DQ_RETURN = "TRAVEL_DQ_RETURN";

	public static final String TRAVEL_DQ_REJECT = "TRAVEL_DQ_REJECT";

	public static final String MED_RESULT_POSITIVE = "MED_RESULT_POSITIVE";

	public static final String MED_RESULT_NEGATIVE = "MED_RESULT_NEGATIVE";

	// fcm template
	public static final String FCM_ACTIVATE_ACCOUNT_SUCCESS = "FCM_ACTIVATE_ACCOUNT_SUCCESS";

	public static final String FCM_PAYMENT_SUCCESS = "FCM_PAYMENT_SUCCESS";

	public static final String FCM_PAYMENT_FAIL = "FCM_PAYMENT_FAIL";

	public static final String FCM_MEDICAL_RESULT_FIT = "FCM_MEDICAL_RESULT_FIT";

	public static final String FCM_MEDICAL_RESULT_UNFIT = "FCM_MEDICAL_RESULT_UNFIT";

	public static final String FCM_TRAVEL_TRIP_SUBMITTED = "FCM_TRAVEL_TRIP_SUBMITTED";

	public static final String FCM_TRAVEL_TRIP_RETURNED = "FCM_TRAVEL_TRIP_RETURNED";

	public static final String FCM_TRAVEL_TRIP_REJECTED = "FCM_TRAVEL_TRIP_REJECTED";

	public static final String FCM_TRAVEL_TRIP_APPROVED = "FCM_TRAVEL_TRIP_APPROVED";
}
