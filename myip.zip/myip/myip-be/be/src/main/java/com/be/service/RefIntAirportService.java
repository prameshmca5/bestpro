/**
 * Copyright 2020. Bestinet Sdn Bhd
 */
package com.be.service;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.RefIntAirportQf;
import com.be.dao.RefIntAirportRepository;
import com.be.model.RefIntAirport;
import com.be.sdk.constants.BeCacheConstants;
import com.be.sdk.model.IQfCriteria;

/**
 * @author nurul.naimma
 *
 * @since 11 Jul 2020
 */

@Lazy
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Service(QualifierConstants.REF_INT_AIRPORT_SVC)
@Qualifier(QualifierConstants.REF_INT_AIRPORT_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
public class RefIntAirportService extends AbstractService<RefIntAirport> {

	@Autowired
	private RefIntAirportRepository intAirportRepository;

	@Autowired
	private RefIntAirportQf intAirportQf;

	@Override
	public GenericRepository<RefIntAirport> primaryDao() {
		return intAirportRepository;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return intAirportQf.generateCriteria(cb, from, criteria);
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<RefIntAirport> getAllIntAirport() {
		return intAirportRepository.getAllIntAirport();
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<RefIntAirport> findAirportByCriteria(RefIntAirport intAirport) {
		return intAirportQf.searchAllByProperty(intAirport);
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public RefIntAirport saveAndUpdate(RefIntAirport intAirport) {
		return intAirportRepository.saveAndFlush(intAirport);
	}


}
