package com.be.sdk.constants;


/**
 * @author nurul.naimma
 *
 * @since 11 July 2020
 */

public enum MyIpDQStatusEnum {
	
	TVL_PROF("TRAVELLER_PROFILE", 1),
	TVL_INFO("TRAVEL_INFORMATION", 2),
	ITRY_INFO("ITENARARY_INFORMATION", 3),
	MED_RSLT("MEDICAL_RESULT", 4),
	OVERALL("OVERALL", 5);

	private final String section;

	private final Integer indicator;


	MyIpDQStatusEnum(String section, Integer indicator) {
		this.section = section;
		this.indicator = indicator;
	}


	public String getSection() {
		return section;
	}


	public Integer getIndicator() {
		return indicator;
	}


	public static MyIpDQStatusEnum findBySection(String section) {
		for (MyIpDQStatusEnum v : MyIpDQStatusEnum.values()) {
			if (v.getSection().equals(section)) {
				return v;
			}
		}
		return null;
	}
	
	public static MyIpDQStatusEnum findByIndicator(Integer indicator){
	     for(MyIpDQStatusEnum v : MyIpDQStatusEnum.values()){
	         if(v.getIndicator().equals(indicator)){
	             return v;
	         }
	     }
	     
	     return null;
	}

}
