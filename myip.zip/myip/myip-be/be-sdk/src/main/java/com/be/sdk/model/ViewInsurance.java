package com.be.sdk.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class ViewInsurance {
	
	private String relation;
	private String nationality;
	private String nameMrz;
	private String passportNo;
	private String gender;
	private Date dob;
	private String type;
	private Date passportExpiryDate;
	private String placeOfBirth;
	private String mobileCountryCode;
	private String mobileNo;
	private String email;
	private String email1;
	private String addr1;
	private String addr2;
	private String state;
	private String postalCode;
	private String city;
	private String country;
	private String contactName;
	private String contactMobileNoCountryCode;
	private String contactMobileNo;
	private String contactRelation;
	private String paymentReceipt;
	private String departureFrom;
	private Date departureDate;
	private Date departureTime;
	private String arrivalTo;
	private String arrivalDate;
	private Date arrivalTime;
	private String modeOfTravel;
	private String airlinesCode;
	private String flightNo;
	private String travelTicket;
	private String purposeOfTravel;
	private String durationStay;
	private String accomodationType;
	private String accomodationName;
	private String accomodationAddr1;
	private String accomodationAddr2;
	private String accomodationState;
	private String accomodationCountry;
	private String accomodationPostalCode;
	private String accomodationCity;
	private String accomodationProofOfStay;
	private List<FileUpload> fileUploadsPhoto;
	private String docMgtIdPhoto;
	private List<FileUpload> fileUploads;
	private List<FileUpload> fileUploadsPassport;
	
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getNameMrz() {
		return nameMrz;
	}
	public void setNameMrz(String nameMrz) {
		this.nameMrz = nameMrz;
	}
	public String getPassportNo() {
		return passportNo;
	}
	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Date getPassportExpiryDate() {
		return passportExpiryDate;
	}
	public void setPassportExpiryDate(Date passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}
	public String getPlaceOfBirth() {
		return placeOfBirth;
	}
	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}
	public String getMobileCountryCode() {
		return mobileCountryCode;
	}
	public void setMobileCountryCode(String mobileCountryCode) {
		this.mobileCountryCode = mobileCountryCode;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEmail1() {
		return email1;
	}
	public void setEmail1(String email1) {
		this.email1 = email1;
	}
	public String getAddr1() {
		return addr1;
	}
	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}
	public String getAddr2() {
		return addr2;
	}
	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getContactMobileNoCountryCode() {
		return contactMobileNoCountryCode;
	}
	public void setContactMobileNoCountryCode(String contactMobileNoCountryCode) {
		this.contactMobileNoCountryCode = contactMobileNoCountryCode;
	}
	public String getContactMobileNo() {
		return contactMobileNo;
	}
	public void setContactMobileNo(String contactMobileNo) {
		this.contactMobileNo = contactMobileNo;
	}
	public String getContactRelation() {
		return contactRelation;
	}
	public void setContactRelation(String contactRelation) {
		this.contactRelation = contactRelation;
	}
	public String getPaymentReceipt() {
		return paymentReceipt;
	}
	public void setPaymentReceipt(String paymentReceipt) {
		this.paymentReceipt = paymentReceipt;
	}
	public String getDepartureFrom() {
		return departureFrom;
	}
	public void setDepartureFrom(String departureFrom) {
		this.departureFrom = departureFrom;
	}
	public Date getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	public Date getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(Date departureTime) {
		this.departureTime = departureTime;
	}
	public String getArrivalTo() {
		return arrivalTo;
	}
	public void setArrivalTo(String arrivalTo) {
		this.arrivalTo = arrivalTo;
	}
	public String getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public Date getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(Date arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public String getModeOfTravel() {
		return modeOfTravel;
	}
	public void setModeOfTravel(String modeOfTravel) {
		this.modeOfTravel = modeOfTravel;
	}
	public String getAirlinesCode() {
		return airlinesCode;
	}
	public void setAirlinesCode(String airlinesCode) {
		this.airlinesCode = airlinesCode;
	}
	public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	public String getTravelTicket() {
		return travelTicket;
	}
	public void setTravelTicket(String travelTicket) {
		this.travelTicket = travelTicket;
	}
	public String getPurposeOfTravel() {
		return purposeOfTravel;
	}
	public void setPurposeOfTravel(String purposeOfTravel) {
		this.purposeOfTravel = purposeOfTravel;
	}
	public String getDurationStay() {
		return durationStay;
	}
	public void setDurationStay(String durationStay) {
		this.durationStay = durationStay;
	}
	public String getAccomodationType() {
		return accomodationType;
	}
	public void setAccomodationType(String accomodationType) {
		this.accomodationType = accomodationType;
	}
	public String getAccomodationName() {
		return accomodationName;
	}
	public void setAccomodationName(String accomodationName) {
		this.accomodationName = accomodationName;
	}
	public String getAccomodationAddr1() {
		return accomodationAddr1;
	}
	public void setAccomodationAddr1(String accomodationAddr1) {
		this.accomodationAddr1 = accomodationAddr1;
	}
	public String getAccomodationAddr2() {
		return accomodationAddr2;
	}
	public void setAccomodationAddr2(String accomodationAddr2) {
		this.accomodationAddr2 = accomodationAddr2;
	}
	public String getAccomodationState() {
		return accomodationState;
	}
	public void setAccomodationState(String accomodationState) {
		this.accomodationState = accomodationState;
	}
	public String getAccomodationCountry() {
		return accomodationCountry;
	}
	public void setAccomodationCountry(String accomodationCountry) {
		this.accomodationCountry = accomodationCountry;
	}
	public String getAccomodationPostalCode() {
		return accomodationPostalCode;
	}
	public void setAccomodationPostalCode(String accomodationPostalCode) {
		this.accomodationPostalCode = accomodationPostalCode;
	}
	public String getAccomodationCity() {
		return accomodationCity;
	}
	public void setAccomodationCity(String accomodationCity) {
		this.accomodationCity = accomodationCity;
	}
	public String getAccomodationProofOfStay() {
		return accomodationProofOfStay;
	}
	public void setAccomodationProofOfStay(String accomodationProofOfStay) {
		this.accomodationProofOfStay = accomodationProofOfStay;
	}
	public List<FileUpload> getFileUploadsPhoto() {
		return fileUploadsPhoto;
	}
	public void setFileUploadsPhoto(List<FileUpload> fileUploadsPhoto) {
		this.fileUploadsPhoto = fileUploadsPhoto;
	}
	public String getDocMgtIdPhoto() {
		return docMgtIdPhoto;
	}
	public void setDocMgtIdPhoto(String docMgtIdPhoto) {
		this.docMgtIdPhoto = docMgtIdPhoto;
	}
	public List<FileUpload> getFileUploads() {
		return fileUploads;
	}
	public void setFileUploads(List<FileUpload> fileUploads) {
		this.fileUploads = fileUploads;
	}
	public List<FileUpload> getFileUploadsPassport() {
		return fileUploadsPassport;
	}
	public void setFileUploadsPassport(List<FileUpload> fileUploadsPassport) {
		this.fileUploadsPassport = fileUploadsPassport;
	}
	

}
