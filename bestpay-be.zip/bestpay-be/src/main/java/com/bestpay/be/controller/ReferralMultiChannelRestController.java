/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwReferralMultiChannel;
import com.bestpay.be.model.RefChannel;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerChanSetWrapper;
import com.bestpay.be.sdk.model.ReferralMultiChannel;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;


/**
 * @author Atiqah Khairuddin
 * @since June 14, 2019
 */
@RestController
@RequestMapping(BeUrlConstants.REFFERAL_MULTI_CHANNEL)
public class ReferralMultiChannelRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReferralMultiChannelRestController.class);

	String skipValues = "[-+.^:,()*@/]";

	@Autowired
	protected ReferenceRestController referenceRestController;


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public boolean updateChannelSettings(@Valid @RequestBody MerChanSetWrapper merChanSetWrapper,
			HttpServletRequest request, HttpServletResponse response) throws BeException {

		List<RefChannel> refChannels = refChannelSvc.findAll();
		int index = 0;
		boolean isUpdated = false;
		LOGGER.info("Create new Channel Settings ... ");
		if (merChanSetWrapper == null) {// multi channel null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}

		List<PgwReferralMultiChannel> multiChannel = getDeletedChannels(merChanSetWrapper);
		for (PgwReferralMultiChannel channel : multiChannel) {
			super.pgwReferralMultiChannelService.primaryDao().delete(channel);
		}

		for (ReferralMultiChannel referralMultiChannel : merChanSetWrapper.getReferralMultiChannel()) {
			PgwReferralMultiChannel newChannel = dozerMapper.map(referralMultiChannel,
					PgwReferralMultiChannel.class);
			newChannel.setCompRefId(merChanSetWrapper.getCompRefId());
			newChannel.setEnable(1);
			newChannel.setStatus("A");
			newChannel.setCreateId(merChanSetWrapper.getUserId());
			newChannel.setUpdateId(merChanSetWrapper.getUserId());

			if (!BaseUtil.isObjNull(referralMultiChannel.getChannel())) {
				PgwReferralMultiChannel mulChannel = pgwReferralMultiChannelService
						.findActiveMultiChannelByCompRefIdAndChannel(merChanSetWrapper.getCompRefId(),
								referralMultiChannel.getChannel());
				if (!BaseUtil.isObjNull(mulChannel)) {
					if ((!BaseUtil.isObjNull(mulChannel.getRate())
							&& Double.compare(mulChannel.getRate(), referralMultiChannel.getRate()) != 0)
							|| !BaseUtil.isObjNull(referralMultiChannel.getRate())
							|| (!BaseUtil.isObjNull(mulChannel.getCost()) && Double.compare(mulChannel.getCost(),
									referralMultiChannel.getCost()) != 0)
							|| !BaseUtil.isObjNull(referralMultiChannel.getCost())
							|| mulChannel.getEnable() == 0) {
						mulChannel.setStatus("I");
						super.pgwReferralMultiChannelService.update(mulChannel);
						isUpdated = true;
					}
				} else {
					super.pgwReferralMultiChannelService.create(newChannel);
					isUpdated = true;
				}
			} else if (BaseUtil.isObjNull(referralMultiChannel.getChannel())
					&& (!BaseUtil.isObjNull(referralMultiChannel.getRate())
							|| !BaseUtil.isObjNull(referralMultiChannel.getCost()))) {
				String channel = refChannels.get(index).getPublicName();
				PgwReferralMultiChannel mulChannel = pgwReferralMultiChannelService
						.findActiveMultiChannelByCompRefIdAndChannel(merChanSetWrapper.getCompRefId(), channel);
				if (!BaseUtil.isObjNull(mulChannel) && mulChannel.getEnable() == 1) {
					mulChannel.setStatus("I");
					newChannel.setEnable(0);
					newChannel.setChannel(channel);
					super.pgwReferralMultiChannelService.update(mulChannel);
					super.pgwReferralMultiChannelService.create(newChannel);
					isUpdated = true;
				}
			}
			index++;
		}
		if (isUpdated) {
			return true;
		}
		return isUpdated;
	}


	@GetMapping(value = "/{compRefId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerChanSetWrapper getMerChanSetWrapperById(@PathVariable String compRefId) {

		List<ReferralMultiChannel> referralMultiChannel = new ArrayList<>();
		List<RefChannel> refChannels = refChannelSvc.findAll();
		MerChanSetWrapper merChanSetWrapper = new MerChanSetWrapper();
		merChanSetWrapper.setCompRefId(compRefId);
		List<PgwReferralMultiChannel> multiChannel = pgwReferralMultiChannelService
				.findMultiChannelByCompRefId(compRefId);
		for (RefChannel refChannel : refChannels) {
			boolean match = false;
			ReferralMultiChannel reflMultiChannel = new ReferralMultiChannel();
			for (PgwReferralMultiChannel channel : multiChannel) {
				if (BaseUtil.isEqualsCaseIgnore(refChannel.getPublicName(), channel.getChannel())) {
					match = true;
					reflMultiChannel = dozerMapper.map(channel, ReferralMultiChannel.class);
					if (channel.getEnable() == 0) {
						reflMultiChannel.setChannel(null);
					} else {
						merChanSetWrapper.setChannelCheck(true);
					}
				}
			}
			if (match) {
				referralMultiChannel.add(reflMultiChannel);
			} else {
				referralMultiChannel.add(new ReferralMultiChannel());
			}

		}
		merChanSetWrapper.setReferralMultiChannel(referralMultiChannel);
		return merChanSetWrapper;
	}


	private List<PgwReferralMultiChannel> getDeletedChannels(MerChanSetWrapper merChanSetWrapper) {
		List<PgwReferralMultiChannel> deletedChannels = new ArrayList<>();

		List<PgwReferralMultiChannel> merChanSets = new ArrayList<>();
		List<RefChannel> refChannels = refChannelSvc.findAll();
		List<PgwReferralMultiChannel> multiChannel = pgwReferralMultiChannelService
				.findMultiChannelByCompRefId(merChanSetWrapper.getCompRefId());
		for (RefChannel refChannel : refChannels) {
			boolean match = false;
			PgwReferralMultiChannel merChanSet1 = new PgwReferralMultiChannel();
			for (PgwReferralMultiChannel channel : multiChannel) {
				if (BaseUtil.isEqualsCaseIgnore(refChannel.getPublicName(), channel.getChannel())) {
					match = true;
					merChanSet1 = channel;

				}
			}
			if (match) {
				merChanSets.add(merChanSet1);
			}
		}

		boolean isExists = false;
		for (PgwReferralMultiChannel channel : merChanSets) {

			for (ReferralMultiChannel channelSetting : merChanSetWrapper.getReferralMultiChannel()) {
				if (channelSetting.getChannel() != null && channelSetting.getChannel().equals(channel.getChannel())
						&& channelSetting.getDeleted().equals("true")) {
					isExists = true;
				}
			}

			if (!isExists) {
				deletedChannels.add(channel);
			}
			isExists = false;

		}
		return deletedChannels;
	}

}
