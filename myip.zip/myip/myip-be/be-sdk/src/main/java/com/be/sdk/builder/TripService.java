/**
 *
 */
package com.be.sdk.builder;


import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.ConfigTripHealth;
import com.be.sdk.model.Trip;
import com.util.pagination.DataTableResults;


/**
 * @author michelle.angela
 *
 */
public class TripService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public TripService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<Trip> searchTripPagination(Trip dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRIP);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}


	public Trip getTrip(Trip dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRIP);
		sb.append(BeUrlConstants.GET_DETAIL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Trip.class);
	}


	public List<Trip> addTripInfo(Trip dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRIP);
		sb.append(BeUrlConstants.INFO_ADD);
		Trip[] tripArray = restTemplate().postForObject(getServiceURI(sb.toString()), dto, Trip[].class);
		return Arrays.asList(tripArray);
	}


	public List<ConfigTripHealth> getConfigTripHealth(ConfigTripHealth configTripHealth) throws Exception {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.CONFIG_TRIP_HEALTH);
		sb.append(BeUrlConstants.GET_CONFIG_TRIP_HEALTH);
		ConfigTripHealth[] configTripHealthArray = restTemplate().postForObject(getServiceURI(sb.toString()),
				configTripHealth, ConfigTripHealth[].class);

		return Arrays.asList(configTripHealthArray);
	}


	public Trip addTripHealths(Trip dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRIP).append(BeUrlConstants.HEALTH);
		sb.append(BeUrlConstants.INFO_ADD);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Trip.class);
	}

}
