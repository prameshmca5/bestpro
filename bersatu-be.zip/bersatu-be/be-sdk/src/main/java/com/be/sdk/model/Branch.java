/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author Ramesh Pongiannan
 *
 */
public class Branch implements Serializable, IQfCriteria<Branch> {

	private static final long serialVersionUID = 5466589728737397061L;

	private String branchCd;

	private String branchDesc;

	private String divisionCd;

	private Division division;

	private State state;

	private String status;

	private Timestamp createDt;

	private String createId;

	private Timestamp updateDt;

	private String updateId;


	public String getBranchCd() {
		return branchCd;
	}


	public void setBranchCd(String branchCd) {
		this.branchCd = branchCd;
	}


	public String getBranchDesc() {
		return branchDesc;
	}


	public String getDivisionCd() {
		return divisionCd;
	}


	public void setDivisionCd(String divisionCd) {
		this.divisionCd = divisionCd;
	}


	public void setBranchDesc(String branchDesc) {
		this.branchDesc = branchDesc;
	}


	public Division getDivision() {
		return division;
	}


	public void setDivision(Division division) {
		this.division = division;
	}


	public State getState() {
		return state;
	}


	public void setState(State state) {
		this.state = state;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
