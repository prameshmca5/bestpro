/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author michelle.angela
 *
 */
public class Channel implements Serializable {

	private static final long serialVersionUID = 5488333403242080283L;

	private String channelCode;

	private String channelName;
	
	private double minAmt;

	private double maxAmt;
	
	private String createId;

	private Timestamp createDt;

	private Timestamp updateDt;

	private String updateId;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public double getMinAmt() {
		return minAmt;
	}

	public void setMinAmt(double minAmt) {
		this.minAmt = minAmt;
	}

	public double getMaxAmt() {
		return maxAmt;
	}

	public void setMaxAmt(double maxAmt) {
		this.maxAmt = maxAmt;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	
}
