package com.bestpay.pgw.sdk.incentiveremit.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "SendTransactionResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class SendTransactionResult {

	@XmlElement(name = "CODE")
	private String code;

	@XmlElement(name = "AGENT_SESSION_ID")
	private String agentSessionId;

	@XmlElement(name = "MESSAGE")
	private String message;

	@XmlElement(name = "PINNO")
	private String pinNo;

	@XmlElement(name = "AGENT_TXNID")
	private String agentTxnId;

	@XmlElement(name = "COLLECT_AMT")
	private String collectAmt;

	@XmlElement(name = "COLLECT_CURRENCY")
	private String collectCurrency;

	@XmlElement(name = "SERVICE_CHARGE")
	private String serviceCharge;

	@XmlElement(name = "GST_CHARGE")
	private String gstCharge;

	@XmlElement(name = "TRANSFER_AMOUNT")
	private String transferAmount;

	@XmlElement(name = "EXCHANGE_RATE")
	private String exchangeRate;

	@XmlElement(name = "PAYOUTAMT")
	private String payoutAmt;

	@XmlElement(name = "PAYOUTCURRENCY")
	private String payoutCurrency;

	@XmlElement(name = "FEE_DISCOUNT")
	private String feeDiscount;

	@XmlElement(name = "ADDITIONAL_PREMIUM_RATE")
	private String additionalPremiumRate;

	@XmlElement(name = "TXN_DATE")
	private String txnDate;

	@XmlElement(name = "SETTLEMENT_AMOUNT")
	private String settlementAmount;


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getAgentSessionId() {
		return agentSessionId;
	}


	public void setAgentSessionId(String agentSessionId) {
		this.agentSessionId = agentSessionId;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public String getPinNo() {
		return pinNo;
	}


	public void setPinNo(String pinNo) {
		this.pinNo = pinNo;
	}


	public String getAgentTxnId() {
		return agentTxnId;
	}


	public void setAgentTxnId(String agentTxnId) {
		this.agentTxnId = agentTxnId;
	}


	public String getCollectAmt() {
		return collectAmt;
	}


	public void setCollectAmt(String collectAmt) {
		this.collectAmt = collectAmt;
	}


	public String getCollectCurrency() {
		return collectCurrency;
	}


	public void setCollectCurrency(String collectCurrency) {
		this.collectCurrency = collectCurrency;
	}


	public String getServiceCharge() {
		return serviceCharge;
	}


	public void setServiceCharge(String serviceCharge) {
		this.serviceCharge = serviceCharge;
	}


	public String getGstCharge() {
		return gstCharge;
	}


	public void setGstCharge(String gstCharge) {
		this.gstCharge = gstCharge;
	}


	public String getTransferAmount() {
		return transferAmount;
	}


	public void setTransferAmount(String transferAmount) {
		this.transferAmount = transferAmount;
	}


	public String getExchangeRate() {
		return exchangeRate;
	}


	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}


	public String getPayoutAmt() {
		return payoutAmt;
	}


	public void setPayoutAmt(String payoutAmt) {
		this.payoutAmt = payoutAmt;
	}


	public String getPayoutCurrency() {
		return payoutCurrency;
	}


	public void setPayoutCurrency(String payoutCurrency) {
		this.payoutCurrency = payoutCurrency;
	}


	public String getFeeDiscount() {
		return feeDiscount;
	}


	public void setFeeDiscount(String feeDiscount) {
		this.feeDiscount = feeDiscount;
	}


	public String getAdditionalPremiumRate() {
		return additionalPremiumRate;
	}


	public void setAdditionalPremiumRate(String additionalPremiumRate) {
		this.additionalPremiumRate = additionalPremiumRate;
	}


	public String getTxnDate() {
		return txnDate;
	}


	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}


	public String getSettlementAmount() {
		return settlementAmount;
	}


	public void setSettlementAmount(String settlementAmount) {
		this.settlementAmount = settlementAmount;
	}

}
