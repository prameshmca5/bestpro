/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.SecAuthorization;
import com.bestid.be.repo.GenericRepository;
import com.bestid.be.repo.SecAuthorizationRepository;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
@Transactional
@Service(QualifierConstants.AUTHORIZATION_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.AUTHORIZATION_SVC)
public class SecAuthorizationService extends AbstractService<SecAuthorization> {

	@Autowired
	@Qualifier(QualifierConstants.AUTHORIZATION_DAO)
	SecAuthorizationRepository authDao;


	@Override
	public GenericRepository<SecAuthorization> primaryDao() {
		return authDao;
	}


	public SecAuthorization findByClientIdAndTxnNo(String clientId, String trxnNo) {
		return authDao.findByClientIdAndTxnNo(clientId, trxnNo);
	}

}
