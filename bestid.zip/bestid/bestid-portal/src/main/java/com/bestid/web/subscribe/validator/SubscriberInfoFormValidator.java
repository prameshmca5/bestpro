/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.web.subscribe.validator;

import static com.bestid.web.util.constants.MessageConstants.ERROR_APPLCNT_EML;
import static com.bestid.web.util.constants.MessageConstants.ERROR_FIELDS_CMPNYREGNO;
import static com.bestid.web.util.constants.MessageConstants.ERROR_FIELDS_CMPNY_NAME;
import static com.bestid.web.util.constants.MessageConstants.ERROR_FIELDS_DIGITAL_ID;
import static com.bestid.web.util.constants.MessageConstants.ERROR_FIELDS_OWNER;
import static com.bestid.web.util.constants.MessageConstants.ERROR_FIELDS_OWNER_CNTCT;
import static com.bestid.web.util.constants.MessageConstants.ERROR_FIELDS_SYSTEM_LOGO_DOC;
import static com.bestid.web.util.constants.MessageConstants.ERROR_FIELDS_SYS_NAME;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestid.web.subscribe.form.SubscriberInfoForm;
import com.bestid.web.util.ValidationUtil;
import com.bstsb.util.BaseUtil;

/**
 * @author Suhada
 * @since Feb 26, 2019
 */
@Component("subscriberInfoFormValidator")
public class SubscriberInfoFormValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return SubscriberInfoForm.class.equals(clazz);
	}

	@Override
	public void validate(Object object, Errors errors) {
	
				
			
			if (object instanceof SubscriberInfoForm) {
				SubscriberInfoForm up = (SubscriberInfoForm) object;

				// Validate if fields are empty or a whitespace
				if(!up.getIndicator().equalsIgnoreCase("edit")) {
					ValidationUtil.rejectIfEmptyOrWhitespace(errors, "cmpnyRegNo", ERROR_FIELDS_CMPNYREGNO);
				}
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "companyInfo.cmpnyName", ERROR_FIELDS_CMPNY_NAME);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "companyInfo.cmpnyOwner", ERROR_FIELDS_OWNER);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "companyInfo.contactNo", ERROR_FIELDS_OWNER_CNTCT);
				ValidationUtil.rejectIfInvalidEmailFormat(errors, "companyInfo.email", ERROR_APPLCNT_EML);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "sysName", ERROR_FIELDS_SYS_NAME);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "subscrType", ERROR_FIELDS_DIGITAL_ID);
				
				if(BaseUtil.isObjNull(up.getFileUploads().get(0).getFile())) {
					ValidationUtil.rejectIfEmptyOrWhitespace(errors, "file", ERROR_FIELDS_SYSTEM_LOGO_DOC);

				}
				
			}

	}

}