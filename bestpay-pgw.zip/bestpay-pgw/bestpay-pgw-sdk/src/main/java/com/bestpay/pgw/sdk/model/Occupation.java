package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


public class Occupation implements Serializable {

	private static final long serialVersionUID = -7119391026900656003L;

	private Integer occupationId;

	private String occupationName;

	private Integer occupationGroupId;

	private String createId;

	private Timestamp createDt;

	private String updateId;

	private Timestamp updateDt;

	private Integer quotacount;


	public Integer getOccupationId() {
		return occupationId;
	}


	public String getOccupationName() {
		return occupationName;
	}


	public void setOccupationId(Integer occupationId) {
		this.occupationId = occupationId;
	}


	public void setOccupationName(String occupationName) {
		this.occupationName = occupationName;
	}


	public Integer getOccupationGroupId() {
		return occupationGroupId;
	}


	public void setOccupationGroupId(Integer occupationGroupId) {
		this.occupationGroupId = occupationGroupId;
	}


	public String getCreateId() {
		return createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Integer getQuotacount() {
		return quotacount;
	}


	public void setQuotacount(Integer quotacount) {
		this.quotacount = quotacount;
	}

}
