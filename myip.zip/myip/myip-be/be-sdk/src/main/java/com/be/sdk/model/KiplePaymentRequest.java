/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author Ramesh Pongiannan
 *
 */
@JsonInclude(Include.NON_NULL)
public class KiplePaymentRequest implements Serializable {

	private static final long serialVersionUID = -3875087908244978583L;

	private String ord_date;
	private double ord_totalamt;
	private double ord_gstamt;
	private String ord_shipname;
	private String ord_shipcountry;
	private String ord_mercref;
	private String ord_telephone;
	private String ord_email;
	private String ord_delcharges;
	private String ord_svccharges;
	private String ord_customfield1;
	private String ord_customfield2;
	private String ord_customfield3;
	private String ord_customfield4;
	private String ord_mercID;
	private String wcID;
	private String ord_key;
	private String returncode;
	private String version;
	private String merchant_hashvalue;
	 
	
	public String getOrd_date() {
		return ord_date;
	}
	public void setOrd_date(String ord_date) {
		this.ord_date = ord_date;
	}
	public double getOrd_totalamt() {
		return ord_totalamt;
	}
	public void setOrd_totalamt(double ord_totalamt) {
		this.ord_totalamt = ord_totalamt;
	}
	public double getOrd_gstamt() {
		return ord_gstamt;
	}
	public void setOrd_gstamt(double ord_gstamt) {
		this.ord_gstamt = ord_gstamt;
	}
	public String getOrd_shipname() {
		return ord_shipname;
	}
	public void setOrd_shipname(String ord_shipname) {
		this.ord_shipname = ord_shipname;
	}
	public String getOrd_shipcountry() {
		return ord_shipcountry;
	}
	public void setOrd_shipcountry(String ord_shipcountry) {
		this.ord_shipcountry = ord_shipcountry;
	}
	public String getOrd_mercref() {
		return ord_mercref;
	}
	public void setOrd_mercref(String ord_mercref) {
		this.ord_mercref = ord_mercref;
	}
	public String getOrd_telephone() {
		return ord_telephone;
	}
	public void setOrd_telephone(String ord_telephone) {
		this.ord_telephone = ord_telephone;
	}
	public String getOrd_email() {
		return ord_email;
	}
	public void setOrd_email(String ord_email) {
		this.ord_email = ord_email;
	}
	public String getOrd_delcharges() {
		return ord_delcharges;
	}
	public void setOrd_delcharges(String ord_delcharges) {
		this.ord_delcharges = ord_delcharges;
	}
	public String getOrd_svccharges() {
		return ord_svccharges;
	}
	public void setOrd_svccharges(String ord_svccharges) {
		this.ord_svccharges = ord_svccharges;
	}
	public String getOrd_customfield1() {
		return ord_customfield1;
	}
	public void setOrd_customfield1(String ord_customfield1) {
		this.ord_customfield1 = ord_customfield1;
	}
	public String getOrd_customfield2() {
		return ord_customfield2;
	}
	public void setOrd_customfield2(String ord_customfield2) {
		this.ord_customfield2 = ord_customfield2;
	}
	public String getOrd_customfield3() {
		return ord_customfield3;
	}
	public void setOrd_customfield3(String ord_customfield3) {
		this.ord_customfield3 = ord_customfield3;
	}
	public String getOrd_customfield4() {
		return ord_customfield4;
	}
	public void setOrd_customfield4(String ord_customfield4) {
		this.ord_customfield4 = ord_customfield4;
	}
	public String getOrd_mercID() {
		return ord_mercID;
	}
	public void setOrd_mercID(String ord_mercID) {
		this.ord_mercID = ord_mercID;
	}
	public String getWcID() {
		return wcID;
	}
	public void setWcID(String wcID) {
		this.wcID = wcID;
	}
	public String getOrd_key() {
		return ord_key;
	}
	public void setOrd_key(String ord_key) {
		this.ord_key = ord_key;
	}
	public String getReturncode() {
		return returncode;
	}
	public void setReturncode(String returncode) {
		this.returncode = returncode;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getMerchant_hashvalue() {
		return merchant_hashvalue;
	}
	public void setMerchant_hashvalue(String merchant_hashvalue) {
		this.merchant_hashvalue = merchant_hashvalue;
	}
}
