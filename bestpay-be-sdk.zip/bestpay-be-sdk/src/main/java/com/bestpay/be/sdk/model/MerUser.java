/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;


/**
 * @author Atiqah
 * @since June 20, 2018
 */
public class MerUser implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1864073233598003483L;

	private String merCat;

	private String rocNo;

	private String dba;

	private String reseller;

	private String newMerCat;

	private String newMerCatDesc;


	public String getMerCat() {
		return merCat;
	}


	public void setMerCat(String merCat) {
		this.merCat = merCat;
	}


	public String getRocNo() {
		return rocNo;
	}


	public void setRocNo(String rocNo) {
		this.rocNo = rocNo;
	}


	public String getDba() {
		return dba;
	}


	public void setDba(String dba) {
		this.dba = dba;
	}


	public String getReseller() {
		return reseller;
	}


	public void setReseller(String reseller) {
		this.reseller = reseller;
	}


	public String getNewMerCat() {
		return newMerCat;
	}


	public void setNewMerCat(String newMerCat) {
		this.newMerCat = newMerCat;
	}


	public String getNewMerCatDesc() {
		return newMerCatDesc;
	}


	public void setNewMerCatDesc(String newMerCatDesc) {
		this.newMerCatDesc = newMerCatDesc;
	}
}