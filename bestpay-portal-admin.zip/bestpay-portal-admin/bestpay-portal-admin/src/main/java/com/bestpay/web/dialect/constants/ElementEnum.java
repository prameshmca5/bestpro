/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dialect.constants;

/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public enum ElementEnum {

	ALERT("alert", ElementConstants.HTML_DIV, "alert"),
	ALERT_INFO("alert-info", ElementConstants.HTML_DIV, "alert alert-info"),
	ALERT_ERROR("alert-error", ElementConstants.HTML_DIV, "alert alert-danger"),
	ALERT_SUCCESS("alert-success", ElementConstants.HTML_DIV, "alert alert-success"),
	ALERT_WARN("alert-warn", ElementConstants.HTML_DIV, "alert alert-warning"),

	BADGE("badge", ElementConstants.HTML_SPAN, "badge badge-default"),
	BADGE_PRIMARY("badge-primary", ElementConstants.HTML_SPAN, "badge badge-primary"),
	BADGE_SECONDARY("badge-secondary", ElementConstants.HTML_SPAN, "badge badge-secondary"),
	BADGE_TERTIARY("badge-tertiary", ElementConstants.HTML_SPAN, "badge badge-tertiary"),

	BUTTON("btn", ElementConstants.HTML_BUTTON, "btn btn-white btn-cons"),
	BUTTON_PRIMARY("btn-primary", ElementConstants.HTML_BUTTON, "btn btn-primary btn-cons"),
	BUTTON_SECONDARY("btn-secondary", ElementConstants.HTML_BUTTON, "btn btn-secondary btn-cons"),
	BUTTON_TERTIARY("btn-tertiary", ElementConstants.HTML_BUTTON, "btn btn-tertiary btn-cons"),
	BUTTON_DANGER("btn-danger", ElementConstants.HTML_BUTTON, "btn btn-danger btn-cons"),
	BUTTON_INFO("btn-info", ElementConstants.HTML_BUTTON, "btn btn-info btn-cons"),
	BUTTON_ERROR("btn-error", ElementConstants.HTML_BUTTON, "btn btn-danger btn-cons"),
	BUTTON_SUCCESS("btn-success", ElementConstants.HTML_BUTTON, "btn btn-success btn-cons"),
	BUTTON_WARN("btn-warn", ElementConstants.HTML_BUTTON, "btn btn-warning btn-cons"),

	CHECKBOX("checkbox", ElementConstants.HTML_INPUT, "checkbox check-success checkbox-circle"),
	CHECKBOX_INLINE("checkbox-inline", ElementConstants.HTML_INPUT, "checkbox-inline"),

	ERROR("error", ElementConstants.HTML_SPAN, "errors"),

	FORM("form", ElementConstants.HTML_FORM, "form account-form"),

	FILE("file", ElementConstants.HTML_DIV, StyleConstants.STYLE_FILE_UPLOAD),
	FILE_BUTTON("btn-file", ElementConstants.HTML_DIV, "fileinput"),
	FILE_VIEW("file-view", ElementConstants.HTML_DIV, "cursor-pointer"),

	FILE_THUMBNAIL("file-thumbnail", ElementConstants.HTML_DIV, StyleConstants.STYLE_FILE_UPLOAD),
	FILE_THUMB_VIEW("file-thumbnail-view", ElementConstants.HTML_DIV, StyleConstants.STYLE_FILE_UPLOAD),

	INPUT("input", ElementConstants.HTML_INPUT, StyleConstants.STYLE_FORM_CONTROL),
	INPUT_AMOUNT("input-amount", ElementConstants.HTML_INPUT, StyleConstants.STYLE_FORM_CONTROL),
	INPUT_NUMBER("input-number", ElementConstants.HTML_INPUT, StyleConstants.STYLE_FORM_CONTROL),
	INPUT_DATE("input-date", ElementConstants.HTML_INPUT, "form-control datepicker"),
	INPUT_TIME("input-time", ElementConstants.HTML_INPUT, "form-control timepicker2"),
	INPUT_HIDDEN("input-hidden", ElementConstants.HTML_INPUT, StyleConstants.STYLE_FORM_CONTROL),
	INPUT_FILE("input-file", ElementConstants.HTML_INPUT, StyleConstants.STYLE_FORM_CONTROL),
	INPUT_PASSWORD("input-password", ElementConstants.HTML_INPUT, StyleConstants.STYLE_FORM_CONTROL),

	LABEL("label", ElementConstants.HTML_INPUT, "label"),

	MENU("menu", ElementConstants.HTML_UL, ""),

	OTP("otp", ElementConstants.HTML_DIV, ""), OTP_EMAIL("otp-email", ElementConstants.HTML_DIV, "input-group"),

	PANEL("panel", ElementConstants.HTML_DIV, StyleConstants.STYLE_FORM_CONTROL),

	PORTLET("portlet", ElementConstants.HTML_DIV, StyleConstants.STYLE_ROW_FLUID),
	PORTLET_DANGER("portlet-danger", ElementConstants.HTML_DIV, StyleConstants.STYLE_ROW_FLUID),
	PORTLET_SECOND("portlet-secondary", ElementConstants.HTML_DIV, StyleConstants.STYLE_ROW_FLUID),
	PORTLET_ICHECK("portlet-icheck", ElementConstants.HTML_DIV, StyleConstants.STYLE_ROW_FLUID),

	RADIO_GROUP("radio-group", ElementConstants.HTML_DIV, StyleConstants.STYLE_FORM_CONTROL),
	RADIO("radio", ElementConstants.HTML_INPUT, "radio-custom"),

	TABLE("table", ElementConstants.HTML_TABLE, "table table-custom-bordered table-hover table-condensed"),

	SELECT("select", ElementConstants.HTML_SELECT, "form-control select-filter"),

	SLABEL("slbl", ElementConstants.HTML_SPAN, "label label-default"),
	SLABEL_PRIMARY("slbl-primary", ElementConstants.HTML_SPAN, "label label-primary"),
	SLABEL_SECONDARY("slbl-secondary", ElementConstants.HTML_SPAN, "label label-secondary"),
	SLABEL_TERTIARY("slbl-tertiary", ElementConstants.HTML_SPAN, "label label-tertiary"),
	SLABEL_INFO("slbl-info", ElementConstants.HTML_SPAN, "label label-info"),
	SLABEL_ERROR("slbl-error", ElementConstants.HTML_SPAN, "label label-danger"),
	SLABEL_SUCCESS("slbl-success", ElementConstants.HTML_SPAN, "label label-success"),
	SLABEL_WARN("slbl-warn", ElementConstants.HTML_SPAN, "label label-warning")

	;

	private final String name;

	private final String processor;

	private final String style;

	private ElementEnum(String name, String processor, String style) {
		this.name = name;
		this.processor = processor;
		this.style = style;
	}

	public String getName() {
		return name;
	}

	public String getProcessor() {
		return processor;
	}

	public String getStyle() {
		return style;
	}

	public static String findStyleByName(String name) {
		for (ElementEnum v : ElementEnum.values()) {
			if (v.getName().equals(name)) {
				return v.getStyle();
			}
		}

		return null;
	}
}