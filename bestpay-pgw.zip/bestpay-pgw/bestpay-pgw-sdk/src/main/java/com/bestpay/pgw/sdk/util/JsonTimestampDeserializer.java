/**
 * Copyright 2016. Bestinet Sdn. Bhd.
 */
package com.bestpay.pgw.sdk.util;


import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bstsb.util.constants.BaseConstants;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;


/**
 * @author Mary Jane Buenaventura
 * @since Dec 6, 2016
 */
public class JsonTimestampDeserializer extends JsonDeserializer<Timestamp> {

	private static final Logger LOGGER = LoggerFactory.getLogger(JsonTimestampDeserializer.class);

	private SimpleDateFormat dateFormat = new SimpleDateFormat(BaseConstants.DT_DD_MM_YYYY_SLASH_TIME_A);


	@Override
	public Timestamp deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
		String timestamp = jp.getText().trim();
		try {
			Date dt = dateFormat.parse(timestamp);
			return new Timestamp(dt.getTime());
		} catch (ParseException e1) {
			LOGGER.error("Unable to parse timestamp: {} ", timestamp);
			return null;
		} catch (NumberFormatException e) {
			LOGGER.error("Unable to deserialize timestamp: {} ", timestamp);
			return null;
		}
	}

}
