package com.bestpay.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwFraudSetting;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */

@Repository
@RepositoryDefinition(domainClass = PgwFraudSetting.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_FRAUD_SET_DAO)
public interface PgwFraudSettingRepository extends GenericRepository<PgwFraudSetting> {

	@Query("select u from PgwFraudSetting u ")
	public PgwFraudSetting findAllFraudSetting();


	@Query("select u from PgwFraudSetting u where u.fraudId = :fraudId ")
	public PgwFraudSetting findByFraudSettingId(@Param("fraudId") int fraudSet);


	@Query("select u from PgwFraudSetting u where u.merchantId = :merchantId ")
	public PgwFraudSetting findFraudSettingByMerchantId(@Param("merchantId") String merchantId);


	@Query("select count(u) from PgwFraudSetting u ")
	public int totalRecords();

}