/**
 * 
 */
package com.be.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.RefDivision;
import com.be.model.RefParliament;

/**
 * @author Ramesh Pongiannan
 *
 */
@Lazy
@Repository
@RepositoryDefinition(domainClass = RefParliament.class, idClass = Integer.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_DIVISION_DAO)
public interface RefDivisionRepository extends GenericRepository<RefDivision> {

	@Query("select u from RefDivision u ")
	public List<RefDivision> findAll();

	@Query("select u from RefDivision u where u.divisionCd = :divisionCd ")
	public RefDivision findByDivisionCd(@Param("divisionCd") String divisionCd);
}
