package com.bestpay.pgw.controller;


import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.notify.sdk.util.BaseUtil;
import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwAuditTrail;
import com.bestpay.pgw.sdk.constants.PgwErrorCodeEnum;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.exception.PgwException;
import com.bestpay.pgw.sdk.model.PgwAuditTrailDto;
import com.bestpay.pgw.service.PgwAuditTrailService;
import com.bestpay.pgw.service.PgwTransactionService;


/**
 * @author Chaithanya Kumar
 * @since 03/07/2018
 */
@RestController
public class PgwAuditRestController extends AbstractRestController {

	private static final Logger logger = LoggerFactory.getLogger(PgwAuditRestController.class);

	@Autowired
	public PgwAuditTrailService pgwAuditService;

	@Autowired
	public PgwTransactionService pgwTransactionService;


	@PostMapping(value = PgwUrlConstants.SAVE_PGW_AUDIT_AUDIT, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwAuditTrailDto createPgwAudit(@RequestBody PgwAuditTrailDto pgwAudit, HttpServletRequest request) {
		PgwAuditTrailDto auditRes = null;
		try {
			if (BaseUtil.isObjNull(pgwAudit)) {
				throw new PgwException(PgwErrorCodeEnum.E404PGW114, new String[] {});
			}
			PgwAuditTrail p = dozerMapper.map(pgwAudit, PgwAuditTrail.class);
			p.setCreateId("system");
			PgwAuditTrail audit = pgwAuditService.create(p);
			auditRes = dozerMapper.map(audit, PgwAuditTrailDto.class);

		} catch (Exception e) {
			logger.info("Error in saving Pgw Audit {}", e.getMessage());
		}
		return auditRes;
	}

}
