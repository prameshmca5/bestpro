package com.be.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.codec.digest.DigestUtils;
import org.json.JSONObject;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.be.sdk.model.SenangPayResponds;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;

public class test {
	public static void main(String[] str) {
		StringBuilder reqhashParam = new StringBuilder();
		String mercSecret = "466162848833232";
		String secret = "3822-573";
		// No data
		//String order_id = "PMTBF2339566958";
		//available Records
		String order_id = "PMTBL1434081992";
		
		reqhashParam.append(mercSecret).append(secret).append(order_id);
		String hashCal = DigestUtils.md5Hex(reqhashParam.toString());
		System.out.println("Hash=>"+hashCal);
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("order_id", order_id);
		params.put("merchant_id", mercSecret);
		params.put("hash", hashCal);
		String url = "https://sandbox.senangpay.my/apiv1/query_order_status";
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		for (Map.Entry<String, String> entry : params.entrySet()) {
		    builder.queryParam(entry.getKey(), entry.getValue());
		}
		System.out.println("builder==>"+builder.toUriString());
		RestTemplate restTemplate = new RestTemplate();
		String getjson = restTemplate.getForObject(builder.toUriString(), String.class);
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			SenangPayResponds  spay = objectMapper.readValue(getjson, SenangPayResponds.class);
			System.out.println("Length=>"+spay.getData().size());
			System.out.println(spay.getMsg());
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
