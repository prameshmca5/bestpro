/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.builder;


import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.bestpay.pgw.sdk.client.PgwRestTemplate;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.model.Country;
import com.bestpay.pgw.sdk.model.PaymentType;
import com.bestpay.pgw.sdk.model.Status;


/**
 * @author Ilhomjon
 * @since Feb 22, 2018
 */
public class CommonService extends AbstractService {

	private PgwRestTemplate restTemplate;

	private Properties prop;

	private String url;


	public CommonService(PgwRestTemplate restTemplate, Properties prop, String url) {
		this.restTemplate = restTemplate;
		this.prop = prop;
		this.url = url;
	}


	@Override
	public PgwRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public Properties prop() {
		return prop;
	}


	@Override
	public String url() {
		return url;
	}


	public List<Country> allCountry() {

		List<Country> countryList = null;
		Country[] countryArray = restTemplate().getForObject(getServiceURI(PgwUrlConstants.COUNTRIES),
				Country[].class);
		countryList = Arrays.asList(countryArray);
		return countryList;
	}


	public List<PaymentType> getPaymentTypes() {
		List<PaymentType> paymentTypeList = null;
		PaymentType[] paymentTypes = restTemplate().getForObject(getServiceURI(PgwUrlConstants.REF_PAYMENT_TYPES),
				PaymentType[].class);
		paymentTypeList = Arrays.asList(paymentTypes);
		return paymentTypeList;
	}


	public List<Status> getPaymentTypesCode() {
		List<Status> paymentTypeList = null;
		Status[] paymentTypes = restTemplate().getForObject(getServiceURI(PgwUrlConstants.REF_PAYMENT_TYPES_CODE),
				Status[].class);
		paymentTypeList = Arrays.asList(paymentTypes);
		return paymentTypeList;
	}


	public List<Status> getRefStatus() {
		StringBuilder sb = new StringBuilder();
		sb.append(PgwUrlConstants.REF_PAYMENT_STATUS_CODE);
		Status[] refStats = restTemplate().getForObject(getServiceURI(sb.toString()), Status[].class);
		return Arrays.asList(refStats);
	}


	public Status getRefStatusNextItem(String statusCode) {
		StringBuilder sb = new StringBuilder();
		Status refStats = null;
		Map<String, Object> requestLst = new HashMap<>();
		requestLst.put("status_code", statusCode);
		sb.append(PgwUrlConstants.REF_PAYMENT_STATUS_CODE);
		refStats = restTemplate().getForObject(getServiceURI(sb.toString() + "/nextItem?status_code={status_code}"),
				Status.class, requestLst);
		return refStats;
	}
}