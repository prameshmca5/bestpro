/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;


/**
 * @author michelle.angela
 *
 */
public class TvlStat implements Serializable {

	private static final long serialVersionUID = -2564528964766943404L;

	private Integer tvlStatId;

	private Tvl tvl;

	private Integer statusInd;

	private Metadata dqStatMtdt;

	private Timestamp approvedDt;

	private Integer tvlId;

	private String remarks;

	private Integer dqStat;

	private TvlStat tvlStatus;

	private TvlStat tvlSect1;

	private TvlStat tvlSect2;

	private TvlStat tvlSect3;

	private TvlStat tvlSect4;

	private TvlStat tvlSect5;

	private TvlStat remarks1;

	private TvlStat remarks2;

	private TvlStat remarks3;

	private TvlStat remarks4;

	private TvlStat remarks5;

	private List<TvlStat> tvlStats;

	private Integer remarksMtdtId;

	private Metadata remarksMtdt;


	public Integer getTvlStatId() {
		return tvlStatId;
	}


	public void setTvlStatId(Integer tvlStatId) {
		this.tvlStatId = tvlStatId;
	}


	public Tvl getTvl() {
		return tvl;
	}


	public void setTvl(Tvl tvl) {
		this.tvl = tvl;
	}


	public Integer getStatusInd() {
		return statusInd;
	}


	public void setStatusInd(Integer statusInd) {
		this.statusInd = statusInd;
	}


	public Metadata getDqStatMtdt() {
		return dqStatMtdt;
	}


	public void setDqStatMtdt(Metadata dqStatMtdt) {
		this.dqStatMtdt = dqStatMtdt;
	}


	public Timestamp getApprovedDt() {
		return approvedDt;
	}


	public void setApprovedDt(Timestamp approvedDt) {
		this.approvedDt = approvedDt;
	}


	public Integer getTvlId() {
		return tvlId;
	}


	public void setTvlId(Integer tvlId) {
		this.tvlId = tvlId;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public Integer getDqStat() {
		return dqStat;
	}


	public void setDqStat(Integer dqStat) {
		this.dqStat = dqStat;
	}


	public TvlStat getTvlStatus() {
		return tvlStatus;
	}


	public void setTvlStatus(TvlStat tvlStatus) {
		this.tvlStatus = tvlStatus;
	}


	public TvlStat getTvlSect1() {
		return tvlSect1;
	}


	public void setTvlSect1(TvlStat tvlSect1) {
		this.tvlSect1 = tvlSect1;
	}


	public TvlStat getTvlSect2() {
		return tvlSect2;
	}


	public void setTvlSect2(TvlStat tvlSect2) {
		this.tvlSect2 = tvlSect2;
	}


	public TvlStat getTvlSect3() {
		return tvlSect3;
	}


	public void setTvlSect3(TvlStat tvlSect3) {
		this.tvlSect3 = tvlSect3;
	}


	public TvlStat getTvlSect4() {
		return tvlSect4;
	}


	public void setTvlSect4(TvlStat tvlSect4) {
		this.tvlSect4 = tvlSect4;
	}


	public TvlStat getTvlSect5() {
		return tvlSect5;
	}


	public void setTvlSect5(TvlStat tvlSect5) {
		this.tvlSect5 = tvlSect5;
	}


	public TvlStat getRemarks1() {
		return remarks1;
	}


	public void setRemarks1(TvlStat remarks1) {
		this.remarks1 = remarks1;
	}


	public TvlStat getRemarks2() {
		return remarks2;
	}


	public void setRemarks2(TvlStat remarks2) {
		this.remarks2 = remarks2;
	}


	public TvlStat getRemarks3() {
		return remarks3;
	}


	public void setRemarks3(TvlStat remarks3) {
		this.remarks3 = remarks3;
	}


	public TvlStat getRemarks4() {
		return remarks4;
	}


	public void setRemarks4(TvlStat remarks4) {
		this.remarks4 = remarks4;
	}


	public TvlStat getRemarks5() {
		return remarks5;
	}


	public void setRemarks5(TvlStat remarks5) {
		this.remarks5 = remarks5;
	}


	public List<TvlStat> getTvlStats() {
		return tvlStats;
	}


	public void setTvlStats(List<TvlStat> tvlStats) {
		this.tvlStats = tvlStats;
	}


	public Integer getRemarksMtdtId() {
		return remarksMtdtId;
	}


	public void setRemarksMtdtId(Integer remarksMtdtId) {
		this.remarksMtdtId = remarksMtdtId;
	}


	public Metadata getRemarksMtdt() {
		return remarksMtdt;
	}


	public void setRemarksMtdt(Metadata remarksMtdt) {
		this.remarksMtdt = remarksMtdt;
	}

}
