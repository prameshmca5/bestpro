/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwMerchantPid;
import com.bestpay.pgw.sdk.constants.PgwErrorCodeEnum;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.exception.PgwException;
import com.bestpay.pgw.sdk.model.MerchantPid;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.pgw.service.PgwMerchantPidService;


/**
 * @author Rashid
 * @since 25/03/2019
 */
@RestController
@RequestMapping(PgwUrlConstants.MTO_MERCHANT_PROFILE)
public class PgwMerchantPidRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(PgwMerchantPidRestController.class);

	@Autowired
	protected PgwMerchantPidService pgwMerchantPidService;


	@GetMapping(value = PgwUrlConstants.FIND_MERCHANT_PID, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })

	public List<MerchantPid> getMerChantPid(@RequestParam String merchantId) {
		List<MerchantPid> pidList = new ArrayList<>();
		List<PgwMerchantPid> pidLst = pgwMerchantPidService.findByMerchantPid(merchantId);

		if (BaseUtil.isListNullAndZero(pidLst)) {
			throw new PgwException(PgwErrorCodeEnum.E400PGW012, new String[] { merchantId });
		}
		try {
			for (int i = 0; i < pidLst.size(); i++) {
				pidList.add(dozerMapper.map(pidLst.get(i), MerchantPid.class));
			}
		} catch (Exception e) {

			LOGGER.error(e.getMessage());
		}
		return pidList;
	}


	@PostMapping(value = PgwUrlConstants.FIND_MERCHANT_IRCUSID, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwMerchantPid findByMerchantIdIRCusId(@RequestBody MerchantPid pid, HttpServletRequest request) {
		try {
			PgwMerchantPid mercpid = pgwMerchantPidService.findByMerchantMaxmoneyPid(pid.getMerchantId());
			if (!BaseUtil.isObjNull(mercpid)) {
				return dozerMapper.map(mercpid, PgwMerchantPid.class);
			}
		} catch (Exception e) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW115, new String[] { pid.getMerchantId() });
		}
		return null;
	}

}
