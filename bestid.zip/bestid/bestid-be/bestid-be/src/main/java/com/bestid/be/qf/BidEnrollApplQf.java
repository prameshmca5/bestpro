/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.qf;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidEnrollAppl;
import com.bstsb.util.BaseUtil;


/**
 * @author Naem Othman
 * @since March 04, 2019
 */
@Service(QualifierConstants.BID_ENROLL_APPL_QF)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_ENROLL_APPL_QF)
@Transactional
public class BidEnrollApplQf extends QueryFactory<BidEnrollAppl> {

	protected Logger logger = LoggerFactory.getLogger(this.getClass());

	@PersistenceContext
	private EntityManager em;


	@Override
	public Specification<BidEnrollAppl> searchByProperty(final BidEnrollAppl t) {
		return new Specification<BidEnrollAppl>() {

			@Override
			public Predicate toPredicate(Root<BidEnrollAppl> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<Predicate> predLst = new ArrayList<>();

				if (!BaseUtil.isObjNull(t.getApplId())) {
					predLst.add(cb.and(cb.equal(root.get("applId"), t.getApplId())));
				}

				if (!BaseUtil.isObjNull(t.getUserId())) {
					predLst.add(cb.and(root.get("userId").in(t.getUserId())));
				}

				if (!BaseUtil.isObjNull(t.getDeviceId())) {
					predLst.add(cb.and(cb.equal(root.get("deviceId"), t.getDeviceId())));
				}

				if (!BaseUtil.isObjNull(t.getApplDate())) {
					predLst.add(cb.and(cb.equal(root.get("applDate"), t.getApplDate())));
				}

				if (!BaseUtil.isObjNull(t.getStatus())) {
					predLst.add(cb.and(cb.equal(root.get("status"), t.getStatus())));
				}

				if (!BaseUtil.isObjNull(t.getRemarks())) {
					predLst.add(cb.and(cb.equal(root.get("remarks"), t.getRemarks())));
				}

				if (!BaseUtil.isObjNull(t.getActivationCode())) {
					predLst.add(cb.and(cb.equal(root.get("activationCode"), t.getActivationCode())));
				}

				if (!BaseUtil.isListNull(predLst)) {
					return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
				}
				return query.getRestriction();
			}
		};
	}

}
