/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.portal.web.validator;


import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.be.sdk.model.DoctorProfile;
import com.portal.constants.MessageConstants;
import com.portal.web.util.ValidationUtil;
import com.util.BaseUtil;
import com.util.model.CustomMultipartFile;
import com.util.model.FileUpload;


/**
 * @author Ramesh Pongianann
 * @since Aug 04, 2020
 */
@Component("doctorValidator")
public class DoctorValidator implements Validator {
	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}


	@Override
	public void validate(Object object, Errors errors) {
		DoctorProfile up = (DoctorProfile) object;
		System.out.println("VALIDATOR: " + up.getUserId());
		if (object instanceof DoctorProfile) {

			if (BaseUtil.isEqualsCaseIgnore("new", up.getAction())) {
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "userId", MessageConstants.ERROR_DOCT_FIELDS_USERID);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "password",MessageConstants.ERROR_DOCT_FIELDS_TEMPPASS);
			}
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "firstName", MessageConstants.ERROR_FIELDS_FIRSTNAME);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "email", MessageConstants.ERROR_DOCT_FIELDS_EMAIL);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "identityNo", MessageConstants.ERROR_DOCT_INV_IND_NO);
			/*ValidationUtil.rejectIfEmptyOrWhitespace(errors, "gender", MessageConstants.ERROR_FIELDS_GENDER);*/
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "userRoleGroupCode", MessageConstants.ERROR_DOCT_USER_ROLE_GROUP);
			
			if(BaseUtil.isEquals("MC_DOCTOR", up.getUserRoleGroupCode())) {
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "doctorId", MessageConstants.ERROR_USER_DOCTOR_COUNCILNO);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "division", MessageConstants.ERROR_USER_DOCTOR_DIVI);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "department", MessageConstants.ERROR_USER_DOCTOR_DEPART);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "designation", MessageConstants.ERROR_USER_DOCTOR_DEST);
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "medCertNo", MessageConstants.ERROR_USER_DOCTOR_MEDICNO);
				if (!BaseUtil.isObjNull(up.getFileUploadsSupportingDoc2())) {
					for (FileUpload fileUpload : up.getFileUploadsSupportingDoc2()) {
						CustomMultipartFile filename = fileUpload.getFile();
						if (BaseUtil.isEquals(filename.getFilename(), "")) {
							errors.rejectValue("fileUploadsSupportingDoc2[0].file", MessageConstants.ERROR_USER_DOCTOR_STAMP);
						}
					}
				}
				
				if (!BaseUtil.isObjNull(up.getFileUploadsSupportingDoc3())) {
					for (FileUpload fileUpload : up.getFileUploadsSupportingDoc3()) {
						CustomMultipartFile filename = fileUpload.getFile();
						if (BaseUtil.isEquals(filename.getFilename(), "")) {
							errors.rejectValue("fileUploadsSupportingDoc3[0].file", MessageConstants.ERROR_USER_DOCTOR_SIGN);
						}
					}
				}
			}
		 
			// Validate email if format is valid
			if (!BaseUtil.isObjNull(up.getEmail())) {
				ValidationUtil.rejectIfInvalidEmailFormat(errors, "email", MessageConstants.ERROR_DOCT_EMAIL_FORMAT);
			}

			if(!BaseUtil.isObjNull(up.getUserRoleGroupCode())) {
				// Check District Dropdown
				if(BaseUtil.isEqualsCaseIgnore("DIST_ADMIN", up.getUserRoleGroupCode())) {
					ValidationUtil.rejectIfEmptyOrWhitespace(errors, "userGroupRoleBranchCd", MessageConstants.ERROR_FIELDS_DISTRICT);
				}
				
				// Check State Dropdown
				if(BaseUtil.isEqualsCaseIgnore("STATE_ADMIN", up.getUserRoleGroupCode())) {
					ValidationUtil.rejectIfEmptyOrWhitespace(errors, "stateCd", MessageConstants.ERROR_FIELDS_STATE);
				}
			}
			
		}

		if (!errors.hasErrors()) {
			if (BaseUtil.isEqualsCaseIgnore("new", up.getUserId())) {
				ValidationUtil.rejectIfLengthIsInvalid(errors, "userId", MessageConstants.ERROR_LENGTH_NAME, 8);
			}
		}

	}
}