package com.be.sdk.model;

import java.util.Date;

public class Doctor {

	private Date regDateFrom;
	private Date regDateTo;
	private String doctorId;
	private String doctorName;
	private String status;
	public Date getRegDateFrom() {
		return regDateFrom;
	}
	public void setRegDateFrom(Date regDateFrom) {
		this.regDateFrom = regDateFrom;
	}
	public Date getRegDateTo() {
		return regDateTo;
	}
	public void setRegDateTo(Date regDateTo) {
		this.regDateTo = regDateTo;
	}
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
