/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwBusinessCategoryRepository;
import com.bestpay.be.model.PgwBusinessCategory;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Afif Saman
 * @since July 19, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_BUS_CAT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_BUS_CAT_SVC)
public class PgwBusinessCategoryService extends AbstractService<PgwBusinessCategory> {

	@Autowired
	private PgwBusinessCategoryRepository businessCategoryDao;


	@Override
	public PgwBusinessCategoryRepository primaryDao() {
		return businessCategoryDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwBusinessCategory findBusinessCategoryByMerchantId(String merchantId) {
		return businessCategoryDao.findBusinessCategoryByMerchantId(merchantId);
	}

}