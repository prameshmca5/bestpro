package com.bestpay.pgw.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.RefCity;
import com.bestpay.pgw.util.QualifierConstants;

/**
 * @author Md Asif Aftab
 * @since 27th Feb 2018
 */

@Repository
@RepositoryDefinition(domainClass = RefCity.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.APJ_CITY_DAO)
public interface RefCityRepository extends GenericRepository<RefCity> {

	@Query("select u from RefCity u where u.cityCode = :cityCode ")
	public RefCity findByCityCode(@Param("cityCode") String cityCode);

	@Query("select u from RefCity u where u.descEn = :cityDesc or u.descMy = :cityDesc")
	public RefCity findByCityDesc(@Param("cityDesc") String cityDesc);

	@Query("select u from RefCity u where u.cityCode = :cityCode and u.state=:stateCode ")
	public RefCity findByCityStateCode(@Param("cityCode") String cityCode,
			@Param("stateCode") String stateCode);

}