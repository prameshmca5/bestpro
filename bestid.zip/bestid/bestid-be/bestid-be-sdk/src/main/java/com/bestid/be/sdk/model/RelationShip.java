package com.bestid.be.sdk.model;

import java.io.Serializable;

/**
 * @author Md Asif Aftab
 * @since 3rd April 2018
 */

public class RelationShip implements Serializable {

	private static final long serialVersionUID = -5239869368744669544L;

	private String relationId;
	private String relationCode;
	private String relationDesc;

	public String getRelationId() {
		return relationId;
	}

	public void setRelationId(String relationId) {
		this.relationId = relationId;
	}

	public String getRelationCode() {
		return relationCode;
	}

	public void setRelationCode(String relationCode) {
		this.relationCode = relationCode;
	}

	public String getRelationDesc() {
		return relationDesc;
	}

	public void setRelationDesc(String relationDesc) {
		this.relationDesc = relationDesc;
	}

}
