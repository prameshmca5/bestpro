/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 * @author michelle.angela
 *
 */
public class Tvl implements Serializable, IQfCriteria<Tvl> {

	private static final long serialVersionUID = -3098755210840405743L;

	private Integer tvlId;

	private TvlProfile tvlProfile;

	private AcctProfile acctProfile;

	private Payment tvlPayment;

	private Trip tvlTrip;

	private Insurance tvlInsurance;

	private String tvlSlipId;

	private Status status;

	private String addr;

	private Boolean isActive;

	private boolean embedPayment;

	private boolean embedTrip;

	private boolean embedInsurance;

	public Integer statusId;

	private Integer tvlProfId;

	private List<McAttendance> mcAttendance;

	private Date pmtDt;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date createDtFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date createDtTo;

	private String name;

	private String passportNo;

	private String pmtRefNo;

	private String imageMy;

	private String imageLv;

	private boolean embedPaymentDtl;

	private boolean embedMedical;

	private String tvlTripCodeNo;

	private String trxnRefNo;

	private Integer acctProfId;

	private List<TvlStat> tvlStats;

	private boolean embedDQStat;

	private String statusMcAttndace;

	private TvlStat tvlStatus;

	private TvlStat tvlSect1;

	private TvlStat tvlSect2;

	private TvlStat tvlSect3;

	private TvlStat tvlSect4;

	private TvlStat tvlSect5;

	private Integer test;

	private boolean embedTraveller;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date submittedDateFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date submittedDateTo;

	private String fullName;

	private Integer acctTvlrId;

	private List<Integer> statusIdList;

	private String statusCd;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date departureDtFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date departureDtTo;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date arrivalDtFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date arrivalDtTo;

	private Double totalFee;

	private boolean embedMcCollates;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date attendanceDtFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date attendanceDtTo;

	private Integer mcProfId;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date pmtDtFrom;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date pmtDtTo;

	private String myIpSlipDocMgtId;

	private String tvlIsActiveStatus;

	private String medicalDocMgtId;

	private List<Integer> statusIdNotInList;

	private String countryCd;

	private String insuranceSlipDocMgtId;

	private String travelTicketDocMgtId;

	private String proofOfStayDocMgtId;

	private boolean embedDepartCntry;

	private boolean embedAcctProfile;

	private ConfigRiskStatus riskStatus;


	public Integer getTvlId() {
		return tvlId;
	}


	public void setTvlId(Integer tvlId) {
		this.tvlId = tvlId;
	}


	public TvlProfile getTvlProfile() {
		return tvlProfile;
	}


	public void setTvlProfile(TvlProfile tvlProfile) {
		this.tvlProfile = tvlProfile;
	}


	public Payment getTvlPayment() {
		return tvlPayment;
	}


	public void setTvlPayment(Payment tvlPayment) {
		this.tvlPayment = tvlPayment;
	}


	public Trip getTvlTrip() {
		return tvlTrip;
	}


	public void setTvlTrip(Trip tvlTrip) {
		this.tvlTrip = tvlTrip;
	}


	public Insurance getTvlInsurance() {
		return tvlInsurance;
	}


	public void setTvlInsurance(Insurance tvlInsurance) {
		this.tvlInsurance = tvlInsurance;
	}


	public String getTvlSlipId() {
		return tvlSlipId;
	}


	public void setTvlSlipId(String tvlSlipId) {
		this.tvlSlipId = tvlSlipId;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}


	public String getAddr() {
		return addr;
	}


	public void setAddr(String addr) {
		this.addr = addr;
	}


	public Boolean getIsActive() {
		return isActive;
	}


	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}


	public boolean isEmbedPayment() {
		return embedPayment;
	}


	public void setEmbedPayment(boolean embedPayment) {
		this.embedPayment = embedPayment;
	}


	public boolean isEmbedTrip() {
		return embedTrip;
	}


	public void setEmbedTrip(boolean embedTrip) {
		this.embedTrip = embedTrip;
	}


	public boolean isEmbedInsurance() {
		return embedInsurance;
	}


	public void setEmbedInsurance(boolean embedInsurance) {
		this.embedInsurance = embedInsurance;
	}


	public Integer getStatusId() {
		return statusId;
	}


	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}


	public Integer getTvlProfId() {
		return tvlProfId;
	}


	public void setTvlProfId(Integer tvlProfId) {
		this.tvlProfId = tvlProfId;
	}


	public List<McAttendance> getMcAttendance() {
		return mcAttendance;
	}


	public void setMcAttendance(List<McAttendance> mcAttendance) {
		this.mcAttendance = mcAttendance;
	}


	public Date getPmtDt() {
		return pmtDt;
	}


	public void setPmtDt(Date pmtDt) {
		this.pmtDt = pmtDt;
	}


	public Date getCreateDtFrom() {
		return createDtFrom;
	}


	public void setCreateDtFrom(Date createDtFrom) {
		this.createDtFrom = createDtFrom;
	}


	public Date getCreateDtTo() {
		return createDtTo;
	}


	public void setCreateDtTo(Date createDtTo) {
		this.createDtTo = createDtTo;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getPassportNo() {
		return passportNo;
	}


	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}


	public String getPmtRefNo() {
		return pmtRefNo;
	}


	public void setPmtRefNo(String pmtRefNo) {
		this.pmtRefNo = pmtRefNo;
	}


	public boolean isEmbedPaymentDtl() {
		return embedPaymentDtl;
	}


	public void setEmbedPaymentDtl(boolean embedPaymentDtl) {
		this.embedPaymentDtl = embedPaymentDtl;
	}


	public String getImageMy() {
		return imageMy;
	}


	public void setImageMy(String imageMy) {
		this.imageMy = imageMy;
	}


	public String getImageLv() {
		return imageLv;
	}


	public void setImageLv(String imageLv) {
		this.imageLv = imageLv;
	}


	public boolean isEmbedMedical() {
		return embedMedical;
	}


	public void setEmbedMedical(boolean embedMedical) {
		this.embedMedical = embedMedical;
	}


	public String getTvlTripCodeNo() {
		return tvlTripCodeNo;
	}


	public void setTvlTripCodeNo(String tvlTripCodeNo) {
		this.tvlTripCodeNo = tvlTripCodeNo;
	}


	public String getTrxnRefNo() {
		return trxnRefNo;
	}


	public void setTrxnRefNo(String trxnRefNo) {
		this.trxnRefNo = trxnRefNo;
	}


	public Integer getAcctProfId() {
		return acctProfId;
	}


	public void setAcctProfId(Integer acctProfId) {
		this.acctProfId = acctProfId;
	}


	public List<TvlStat> getTvlStats() {
		return tvlStats;
	}


	public void setTvlStats(List<TvlStat> tvlStats) {
		this.tvlStats = tvlStats;
	}


	public boolean isEmbedDQStat() {
		return embedDQStat;
	}


	public void setEmbedDQStat(boolean embedDQStat) {
		this.embedDQStat = embedDQStat;
	}


	public String getStatusMcAttndace() {
		return statusMcAttndace;
	}


	public void setStatusMcAttndace(String statusMcAttndace) {
		this.statusMcAttndace = statusMcAttndace;
	}


	public TvlStat getTvlStatus() {
		return tvlStatus;
	}


	public void setTvlStatus(TvlStat tvlStatus) {
		this.tvlStatus = tvlStatus;
	}


	public TvlStat getTvlSect1() {
		return tvlSect1;
	}


	public void setTvlSect1(TvlStat tvlSect1) {
		this.tvlSect1 = tvlSect1;
	}


	public TvlStat getTvlSect2() {
		return tvlSect2;
	}


	public void setTvlSect2(TvlStat tvlSect2) {
		this.tvlSect2 = tvlSect2;
	}


	public TvlStat getTvlSect3() {
		return tvlSect3;
	}


	public void setTvlSect3(TvlStat tvlSect3) {
		this.tvlSect3 = tvlSect3;
	}


	public TvlStat getTvlSect4() {
		return tvlSect4;
	}


	public void setTvlSect4(TvlStat tvlSect4) {
		this.tvlSect4 = tvlSect4;
	}


	public TvlStat getTvlSect5() {
		return tvlSect5;
	}


	public void setTvlSect5(TvlStat tvlSect5) {
		this.tvlSect5 = tvlSect5;
	}


	public Integer getTest() {
		return test;
	}


	public void setTest(Integer test) {
		this.test = test;
	}


	public Date getSubmittedDateFrom() {
		return submittedDateFrom;
	}


	public void setSubmittedDateFrom(Date submittedDateFrom) {
		this.submittedDateFrom = submittedDateFrom;
	}


	public Date getSubmittedDateTo() {
		return submittedDateTo;
	}


	public void setSubmittedDateTo(Date submittedDateTo) {
		this.submittedDateTo = submittedDateTo;
	}


	public AcctProfile getAcctProfile() {
		return acctProfile;
	}


	public void setAcctProfile(AcctProfile acctProfile) {
		this.acctProfile = acctProfile;
	}


	public boolean isEmbedTraveller() {
		return embedTraveller;
	}


	public void setEmbedTraveller(boolean embedTraveller) {
		this.embedTraveller = embedTraveller;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public Integer getAcctTvlrId() {
		return acctTvlrId;
	}


	public void setAcctTvlrId(Integer acctTvlrId) {
		this.acctTvlrId = acctTvlrId;
	}


	public List<Integer> getStatusIdList() {
		return statusIdList;
	}


	public void setStatusIdList(List<Integer> statusIdList) {
		this.statusIdList = statusIdList;
	}


	public String getStatusCd() {
		return statusCd;
	}


	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}


	public Date getDepartureDtFrom() {
		return departureDtFrom;
	}


	public void setDepartureDtFrom(Date departureDtFrom) {
		this.departureDtFrom = departureDtFrom;
	}


	public Date getDepartureDtTo() {
		return departureDtTo;
	}


	public void setDepartureDtTo(Date departureDtTo) {
		this.departureDtTo = departureDtTo;
	}


	public Double getTotalFee() {
		return totalFee;
	}


	public void setTotalFee(Double totalFee) {
		this.totalFee = totalFee;
	}


	public boolean isEmbedMcCollates() {
		return embedMcCollates;
	}


	public void setEmbedMcCollates(boolean embedMcCollates) {
		this.embedMcCollates = embedMcCollates;
	}


	public Date getAttendanceDtFrom() {
		return attendanceDtFrom;
	}


	public void setAttendanceDtFrom(Date attendanceDtFrom) {
		this.attendanceDtFrom = attendanceDtFrom;
	}


	public Date getAttendanceDtTo() {
		return attendanceDtTo;
	}


	public void setAttendanceDtTo(Date attendanceDtTo) {
		this.attendanceDtTo = attendanceDtTo;
	}


	public Integer getMcProfId() {
		return mcProfId;
	}


	public void setMcProfId(Integer mcProfId) {
		this.mcProfId = mcProfId;
	}


	public Date getArrivalDtFrom() {
		return arrivalDtFrom;
	}


	public void setArrivalDtFrom(Date arrivalDtFrom) {
		this.arrivalDtFrom = arrivalDtFrom;
	}


	public Date getArrivalDtTo() {
		return arrivalDtTo;
	}


	public void setArrivalDtTo(Date arrivalDtTo) {
		this.arrivalDtTo = arrivalDtTo;
	}


	public Date getPmtDtFrom() {
		return pmtDtFrom;
	}


	public void setPmtDtFrom(Date pmtDtFrom) {
		this.pmtDtFrom = pmtDtFrom;
	}


	public Date getPmtDtTo() {
		return pmtDtTo;
	}


	public void setPmtDtTo(Date pmtDtTo) {
		this.pmtDtTo = pmtDtTo;
	}


	public String getMyIpSlipDocMgtId() {
		return myIpSlipDocMgtId;
	}


	public void setMyIpSlipDocMgtId(String myIpSlipDocMgtId) {
		this.myIpSlipDocMgtId = myIpSlipDocMgtId;
	}


	public String getTvlIsActiveStatus() {
		return tvlIsActiveStatus;
	}


	public void setTvlIsActiveStatus(String tvlIsActiveStatus) {
		this.tvlIsActiveStatus = tvlIsActiveStatus;
	}


	public String getMedicalDocMgtId() {
		return medicalDocMgtId;
	}


	public void setMedicalDocMgtId(String medicalDocMgtId) {
		this.medicalDocMgtId = medicalDocMgtId;
	}


	public List<Integer> getStatusIdNotInList() {
		return statusIdNotInList;
	}


	public void setStatusIdNotInList(List<Integer> statusIdNotInList) {
		this.statusIdNotInList = statusIdNotInList;
	}


	public String getCountryCd() {
		return countryCd;
	}


	public void setCountryCd(String countryCd) {
		this.countryCd = countryCd;
	}


	public String getInsuranceSlipDocMgtId() {
		return insuranceSlipDocMgtId;
	}


	public void setInsuranceSlipDocMgtId(String insuranceSlipDocMgtId) {
		this.insuranceSlipDocMgtId = insuranceSlipDocMgtId;
	}


	public String getTravelTicketDocMgtId() {
		return travelTicketDocMgtId;
	}


	public void setTravelTicketDocMgtId(String travelTicketDocMgtId) {
		this.travelTicketDocMgtId = travelTicketDocMgtId;
	}


	public String getProofOfStayDocMgtId() {
		return proofOfStayDocMgtId;
	}


	public void setProofOfStayDocMgtId(String proofOfStayDocMgtId) {
		this.proofOfStayDocMgtId = proofOfStayDocMgtId;
	}


	public boolean isEmbedDepartCntry() {
		return embedDepartCntry;
	}


	public void setEmbedDepartCntry(boolean embedDepartCntry) {
		this.embedDepartCntry = embedDepartCntry;
	}


	public boolean isEmbedAcctProfile() {
		return embedAcctProfile;
	}


	public void setEmbedAcctProfile(boolean embedAcctProfile) {
		this.embedAcctProfile = embedAcctProfile;
	}


	public ConfigRiskStatus getRiskStatus() {
		return riskStatus;
	}


	public void setRiskStatus(ConfigRiskStatus riskStatus) {
		this.riskStatus = riskStatus;
	}

}
