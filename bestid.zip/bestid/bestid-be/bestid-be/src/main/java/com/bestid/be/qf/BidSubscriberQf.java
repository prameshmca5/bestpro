/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.qf;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidSubscriber;
import com.bestid.be.sdk.model.CompanyInfo;
import com.bestid.be.sdk.model.SubscriberInfo;
import com.bstsb.util.BaseUtil;

/**
 * @author Naem Othman
 * @since March 04, 2019
 */
@Service(QualifierConstants.BID_SUBSCRIBER_QF)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_SUBSCRIBER_QF)
@Transactional
public class BidSubscriberQf extends QueryFactory<BidSubscriber> {

	protected Logger logger = LoggerFactory.getLogger(this.getClass());

	@PersistenceContext
	private EntityManager em;

	@Override
	public Specification<BidSubscriber> searchByProperty(final BidSubscriber t) {
		return new Specification<BidSubscriber>() {

			@Override
			public Predicate toPredicate(Root<BidSubscriber> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<Predicate> predLst = new ArrayList<>();

				if (!BaseUtil.isObjNull(t.getSubscrId())) {
					predLst.add(cb.and(cb.equal(root.get("subscrId"), t.getSubscrId())));
				}

				if (!BaseUtil.isListNull(t.getSubscrIdList())) {
					predLst.add(cb.and(root.get("subscrId").in(t.getSubscrIdList())));
				}

				if (!BaseUtil.isObjNull(t.getSubscrCd())) {
					predLst.add(cb.and(cb.equal(root.get("subscrCd"), t.getSubscrCd())));
				}

				if (!BaseUtil.isObjNull(t.getStatus())) {
					predLst.add(cb.and(cb.equal(root.get("status"), t.getStatus())));
				}

				if (!BaseUtil.isObjNull(t.getSysName())) {
					predLst.add(cb.and(cb.equal(root.get("sysName"), t.getSysName())));
				}

				if (!BaseUtil.isObjNull(t.getCmpnyId())) {
					predLst.add(cb.and(cb.equal(root.get("cmpnyId"), t.getCmpnyId())));
				}

				if (!BaseUtil.isObjNull(t.getSubscrType())) {
					predLst.add(cb.and(cb.equal(root.get("subscrType"), t.getSubscrType())));
				}

				if (!BaseUtil.isListNull(predLst)) {
					return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
				}
				return query.getRestriction();
			}
		};
	}

	@SuppressWarnings("unchecked")
	public List<SubscriberInfo> findBySearchCriteria(SubscriberInfo si) {

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append(
				" select s.subscrCd , s.sysName , s.status , s.subscrType , u.cmpnyName , u.cmpnyRegNo , u.cmpnyOwner , u.email , u.contactNo , s.sysLogo  "
						+ "  from BidCompany u ,BidSubscriber s where u.cmpnyId= s.cmpnyId ");

		if (!BaseUtil.isObjNull(si.getSysName())) {
			queryBuilder.append(" and s.sysName like :sysName");
		}

		if (!BaseUtil.isObjNull(si.getSubscrCd())) {
			queryBuilder.append(" and s.subscrCd = :subscrCd ");
		}

		if (!BaseUtil.isObjNull(si.getCompanyInfo()) && !BaseUtil.isObjNull(si.getCompanyInfo().getCmpnyName())) {
			queryBuilder.append(" and u.cmpnyName like :cmpnyName");
		}

		if (!BaseUtil.isObjNull(si.getCompanyInfo()) && !BaseUtil.isObjNull(si.getCompanyInfo().getCmpnyRegNo())) {
			queryBuilder.append(" and u.cmpnyRegNo= :cmpnyRegNo ");
		}

		logger.info("Query{}", queryBuilder);

		Query query = em.createQuery(queryBuilder.toString());

		if (StringUtils.hasText(si.getSysName())) {
			query.setParameter("sysName", "%" + si.getSysName() + "%");
		}

		if (!BaseUtil.isObjNull(si.getSubscrCd())) {
			query.setParameter("subscrCd", si.getSubscrCd());
		}

		if (!BaseUtil.isObjNull(si.getCompanyInfo()) && !BaseUtil.isObjNull(si.getCompanyInfo().getCmpnyName())) {
			query.setParameter("cmpnyName", "%" + si.getCompanyInfo().getCmpnyName() + "%");
		}

		if (!BaseUtil.isObjNull(si.getCompanyInfo()) && !BaseUtil.isObjNull(si.getCompanyInfo().getCmpnyRegNo())) {
			query.setParameter("cmpnyRegNo", si.getCompanyInfo().getCmpnyRegNo());
		}

		List<Object[]> resultList = query.getResultList();
		List<SubscriberInfo> siData = new ArrayList<>();
		SubscriberInfo data = null;

		if (!BaseUtil.isListNull(resultList)) {

			for (Object[] result : resultList) {
				data = new SubscriberInfo();
				CompanyInfo companyInfo = new CompanyInfo();
				data.setSubscrCd(!StringUtils.isEmpty(result[0]) ? (String) result[0] : null);
				data.setSysName(!StringUtils.isEmpty(result[1]) ? (String) result[1] : null);
				data.setStatus(!StringUtils.isEmpty(result[2]) ? (String) result[2] : null);
				data.setSubscrType(!StringUtils.isEmpty(result[3]) ? (String) result[3] : null);
				companyInfo.setCmpnyName(!StringUtils.isEmpty(result[4]) ? (String) result[4] : null);
				companyInfo.setCmpnyRegNo(!StringUtils.isEmpty(result[5]) ? (String) result[5] : null);
				companyInfo.setCmpnyOwner(!StringUtils.isEmpty(result[6]) ? (String) result[6] : null);
				companyInfo.setEmail(!StringUtils.isEmpty(result[7]) ? (String) result[7] : null);
				companyInfo.setContactNo(!StringUtils.isEmpty(result[8]) ? (String) result[8] : null);
				data.setCompanyInfo(companyInfo);
				data.setSysLogo(!StringUtils.isEmpty(result[9]) ? (String) result[9] : null);
				siData.add(data);
			}

		}
		logger.info("SubscriberInfo list size: {}", siData.size());
		return siData;
	}

}
