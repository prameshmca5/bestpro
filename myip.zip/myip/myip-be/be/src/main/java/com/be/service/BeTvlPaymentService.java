/**
 *
 */
package com.be.service;


import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTvlPaymentQf;
import com.be.dao.BeTvlPaymentRepository;
import com.be.model.BeAcctProfile;
import com.be.model.BeAcctTraveller;
import com.be.model.BeConfigPaymentBreakdown;
import com.be.model.BeConfigPaymentStage;
import com.be.model.BeTvl;
import com.be.model.BeTvlPayment;
import com.be.model.BeTvlPaymentDtl;
import com.be.model.BeTvlPaymentInfo;
import com.be.model.BeTvlProfile;
import com.be.model.RefDocument;
import com.be.model.RefMetadata;
import com.be.model.RefPymntMsgCode;
import com.be.model.RefStatus;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.FileUploadConstants;
import com.be.sdk.constants.MailTemplateConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.AcctProfile;
import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.ConfigPaymentStage;
import com.be.sdk.model.Country;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Metadata;
import com.be.sdk.model.Payment;
import com.be.sdk.model.PaymentDtl;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlProfile;
import com.idm.sdk.exception.IdmException;
import com.idm.sdk.model.Fcm;
import com.idm.sdk.model.FcmDevice;
import com.idm.sdk.model.UserProfile;
import com.notify.sdk.constants.MailTypeEnum;
import com.notify.sdk.model.Notification;
import com.notify.sdk.util.MailUtil;
import com.report.sdk.model.Report;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.JsonUtil;
import com.util.UidGenerator;
import com.util.constants.BaseConstants;
import com.util.pagination.DataTableRequest;


/**
 * @author Ramesh Pongiannan
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_PAYMENT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_PAYMENT_SVC)
public class BeTvlPaymentService extends AbstractService<BeTvlPayment> {

	public static final String PREFIX_PAYMENT = "PMT";

	private static DecimalFormat df = new DecimalFormat("0.00");

	@Autowired
	private BeTvlPaymentRepository beTvlPaymentDao;

	@Autowired
	private BeTvlPaymentDtlService beTvlPaymentdtlsvc;

	@Autowired
	BeTvlPaymentQf beTvlPaymentQf;

	@Autowired
	BeTvlService beTvlSvc;

	@Autowired
	BeTvlProfileService beTvlProfileSvc;

	@Autowired
	BeConfigPaymentStageService beConfigPaymentStageSvc;

	@Autowired
	BeConfigService beConfigSvc;

	@Autowired
	RefMetadataService refMetadataSvc;

	@Autowired
	BeTvlPaymentInfoService beTvlPaymentInfoSvc;

	@Autowired
	RefStatusService refStatusSvc;

	@Autowired
	BeAcctProfileService beAcctProfileSvc;

	@Autowired
	BeAcctTravellerService beAcctTravellerSvc;

	@Autowired
	BeTvlPaymentKipleService beTvlPaymentKipleSvc;

	@Autowired
	RefDocumentService documentSvc;

	@Autowired
	BeTrxnDocumentService trxnDocumentSvc;


	@Override
	public GenericRepository<BeTvlPayment> primaryDao() {
		return beTvlPaymentDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beTvlPaymentQf.generateCriteria(cb, from, criteria);
	}


	public long getCount(Payment dto) {
		return beTvlPaymentQf.getCount(dto);
	}


	public BeTvlPayment searchBeTvlPayment(Payment dto) {
		return beTvlPaymentQf.searchPayment(dto);
	}


	@SuppressWarnings("unchecked")
	public List<Payment> searchBeTvlPaymentPagination(Payment dto, DataTableRequest<?> dataTableInRQ)
			throws IOException {
		return JsonUtil.transferToList(beTvlPaymentQf.searchPaymentPagination(dto, dataTableInRQ), Payment.class);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class })
	public BeTvlPayment addPaymentInfo(Payment dto, String user, HttpServletRequest request) throws IOException {

		BeTvlPayment beTvlPayment = beTvlPaymentDao.findByReferenceNo(dto.getPmtRefNo());
		if (BaseUtil.isObjNull(beTvlPayment)) {
			String dateStr = new SimpleDateFormat("yyMM").format(new Date());
			String length = beConfigSvc.findByConfigCode("ID_LENGTH").getConfigVal();
			beTvlPayment = JsonUtil.transferToObject(dto, BeTvlPayment.class);
			beTvlPayment.setPmtRefNo(generateRandomRefNo(Integer.parseInt(length), "IV", dateStr));
			// beTvlPayment.setRcptRefNo(generateRandomRefNo(Integer.parseInt(length),
			// "OR", dateStr));
			beTvlPayment.setCreateId(user);
			beTvlPayment.setUpdateId(user);
			beTvlPayment = update(beTvlPayment);

			if (!BaseUtil.isListNull(dto.getBeTvlPaymentDtls())) {
				List<BeTvl> beTvls = new ArrayList<>();
				// List<BeAcctTraveller> beAcctTravellers = new
				// ArrayList<>();
				RefStatus refStatus = new RefStatus();
				refStatus.setStatusType("PMT");
				refStatus.setStatusCd("PP");
				refStatus = refStatusSvc.searchAllByProperty(refStatus).get(0);

				List<BeTvlPaymentInfo> beTvlPaymentInfos = new ArrayList<>();
				ConfigPaymentStage dtoConfig = new ConfigPaymentStage();
				RefMetadata refMetadata = refMetadataSvc.findByMtdtTypeAndCd("PYMNT_IND", "D");
				Metadata metadata = new Metadata();
				metadata.setMtdtId(refMetadata.getMtdtId());
				dtoConfig.setPmtIndMtdt(metadata);

				dtoConfig.setPmtType(beConfigSvc.findByConfigCode("MYS_PMT").getConfigVal());
				BeConfigPaymentStage mysPmt = beConfigPaymentStageSvc.searchBeConfigPaymentStage(dtoConfig);

				dtoConfig.setPmtType(beConfigSvc.findByConfigCode("NON_MYS_PMT").getConfigVal());
				BeConfigPaymentStage nonMysPmt = beConfigPaymentStageSvc.searchBeConfigPaymentStage(dtoConfig);

				for (PaymentDtl paymentDtl : dto.getBeTvlPaymentDtls()) {

					BeTvlProfile beTvlProfile = JsonUtil.transferToObject(paymentDtl.getAcctTraveller(),
							BeTvlProfile.class);
					beTvlProfile.setAcctTraveller(
							JsonUtil.transferToObject(paymentDtl.getAcctTraveller(), BeAcctTraveller.class));
					beTvlProfile.setCreateId(user);
					beTvlProfile.setUpdateId(user);
					beTvlProfile = beTvlProfileSvc.create(beTvlProfile);

					BeTvlPaymentDtl beTvlPaymentDtl = new BeTvlPaymentDtl();
					beTvlPaymentDtl.setTvlProfile(beTvlProfile);
					beTvlPaymentDtl.setTvlPayment(beTvlPayment);
					beTvlPaymentDtl.setCreateId(user);
					beTvlPaymentDtl.setUpdateId(user);
					for (BeConfigPaymentBreakdown breakdown : nonMysPmt.getConfigPaymentBreakdowns()) {
						if (breakdown.getLevel() == 1) {
							beTvlPaymentDtl.setAmount(breakdown.getCharges());
							break;
						}
					}
					beTvlPaymentDtl = beTvlPaymentdtlsvc.update(beTvlPaymentDtl);

					if (!BaseUtil.isObjNull(beTvlProfile) && BaseUtil.isEquals("MYS",
							beTvlProfile.getAcctTraveller().getAcctPassport().getNationality().getCntryCd())) {
						setPaymentInfo(mysPmt.getConfigPaymentBreakdowns(), beTvlPaymentDtl, user,
								beTvlPaymentInfos);
					} else {
						setPaymentInfo(nonMysPmt.getConfigPaymentBreakdowns(), beTvlPaymentDtl, user,
								beTvlPaymentInfos);
					}

					if (BaseUtil.isObjNull(dto.getAcctProfile())
							|| BaseUtil.isObjNull(dto.getAcctProfile().getAcctProfId())) {
						UserProfile profile = getIdmService(request).getUserProfileById(user, false, false);
						dto.setAcctProfile(new AcctProfile());
						dto.getAcctProfile().setAcctProfId(profile.getProfId());
					}

					BeTvl beTvl = new BeTvl();
					beTvl.setTvlProfile(beTvlPaymentDtl.getTvlProfile());
					beTvl.setTvlPayment(beTvlPayment);
					beTvl.setTvlSlipId(UidGenerator.generateUid("SLIP"));
					beTvl.setAcctProfile(JsonUtil.transferToObject(dto.getAcctProfile(), BeAcctProfile.class));
					beTvl.setStatus(refStatus);
					beTvl.setIsActive(false);
					beTvl.setCreateId(user);
					beTvl.setUpdateId(user);
					beTvls.add(beTvl);

					// BeAcctTraveller beAcctTraveller = beAcctTravellerSvc
					// .find(beTvlProfile.getAcctTraveller().getAcctTvlrId());
					// beAcctTraveller.setIsPaid(true);
					// beAcctTravellers.add(beAcctTraveller);
				}
				beTvlSvc.saveList(beTvls);
				beTvlPaymentInfoSvc.saveList(beTvlPaymentInfos);
				// beAcctTravellerSvc.saveList(beAcctTravellers);
			}

			beTvlPaymentKipleSvc.addPaymentKipleInfo(beTvlPayment, user);
		}
		return beTvlPayment;
	}


	private void setPaymentInfo(Set<BeConfigPaymentBreakdown> breakdowns, BeTvlPaymentDtl beTvlPaymentDtl, String user,
			List<BeTvlPaymentInfo> beTvlPaymentInfos) {
		for (BeConfigPaymentBreakdown breakdown : breakdowns) {
			if (breakdown.getLevel() > 1) {
				BeTvlPaymentInfo paymentInfo = new BeTvlPaymentInfo();
				paymentInfo.setAmount(breakdown.getCharges());
				paymentInfo.setPmtBreakdown(breakdown);
				paymentInfo.setTvlPaymentDtl(beTvlPaymentDtl);
				paymentInfo.setCreateId(user);
				paymentInfo.setUpdateId(user);
				beTvlPaymentInfos.add(paymentInfo);
			}
		}
	}


	@Transactional(rollbackFor = Exception.class)
	public BeTvlPayment updatePaymentInfo(@RequestBody Payment dto, BeTvlPayment beTvlPayment,
			HttpServletRequest request) throws Exception {

		BeTvlPayment bvlPayment = new BeTvlPayment();
		List<RefDocument> invoiceDoc = new ArrayList<>();
		List<RefDocument> receiptDoc = new ArrayList<>();
		Report invoice = new Report();
		Report receipt = new Report();

		try {
			Set<BeTvlPaymentDtl> beTvlPaymentDtls = beTvlPayment.getBeTvlPaymentDtls();
			beTvlPayment.setCbsRefNo(dto.getCbsRefNo());
			RefPymntMsgCode refPymntMsgCode = new RefPymntMsgCode();
			refPymntMsgCode.setStatusCd(dto.getRespPymntMsgCode().getStatusCd());
			refPymntMsgCode.setRespCd(dto.getRespPymntMsgCode().getRespCd());
			refPymntMsgCode.setPymntMsgCodeId(dto.getRespPymntMsgCode().getPymntMsgCodeId());
			beTvlPayment.setStatusPymntMsgCode(refPymntMsgCode);
			beTvlPayment.setRespPymntMsgCode(refPymntMsgCode);
			if (BaseUtil.isEquals("01", beTvlPayment.getRespPymntMsgCode().getRespCd())) {
				beTvlPayment.setRcptRefNo(generateRandomRefNo(
						Integer.parseInt(beConfigSvc.findByConfigCode("ID_LENGTH").getConfigVal()), "OR",
						new SimpleDateFormat("yyMM").format(new Date())));
				beTvlPayment.setDocRefNo(UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC));
			}
			// JsonUtil.transferToObject(dto, BeTvlPayment.class);
			bvlPayment = update(beTvlPayment);

			if (!BaseUtil.isObjNull(dto.getStatus()) && BaseUtil.isEquals("PS", dto.getStatus().getStatusCd())) {
				List<BeTvlProfile> beTvlProfiles = new ArrayList<>();
				List<BeTvl> beTvls = new ArrayList<>();
				List<BeAcctTraveller> beAcctTravellers = new ArrayList<>();
				RefStatus refStatus = JsonUtil.transferToObject(dto.getStatus(), RefStatus.class);
				for (BeTvlPaymentDtl dtl : beTvlPaymentDtls) {
					dtl.getTvlProfile()
							.setTrxnRefNo(beTvlSvc.generateTrxnNo(
									dtl.getTvlProfile().getAcctPassport().getNationality().getCntryCd(),
									dtl.getTvlProfile().getAcctTraveller().getAcctTvlrId()));
					dtl.getTvlProfile().setUpdateId(dto.getUserPayId());
					beTvlProfiles.add(dtl.getTvlProfile());

					Tvl tvl = new Tvl();
					TvlProfile tvlProf = new TvlProfile();
					tvlProf.setTvlProfId(dtl.getTvlProfile().getTvlProfId());
					tvl.setTvlProfile(tvlProf);
					BeTvl beTvl = beTvlSvc.searchBeTravel(tvl);
					beTvl.setIsActive(true);
					beTvl.setStatus(refStatus);
					beTvls.add(beTvl);

					BeAcctTraveller beAcctTraveller = beAcctTravellerSvc
							.find(dtl.getTvlProfile().getAcctTraveller().getAcctTvlrId());
					beAcctTraveller.setIsPaid(true);
					beAcctTravellers.add(beAcctTraveller);

					List<BeTvlProfile> tvlProfileList = beTvlProfileSvc.searchBeTvlProfileByAcctTvlrIdAndStatusCd(
							dtl.getTvlProfile().getAcctTraveller().getAcctTvlrId(), "PF");

					if (!BaseUtil.isListNull(tvlProfileList)) {
						for (BeTvlProfile tvlProfile : tvlProfileList) {
							tvlProfile.setDisabled(true);
							tvlProfile.setUpdateId(dto.getUserPayId());
							beTvlProfiles.add(tvlProfile);
						}
					}
				}
				beTvlProfileSvc.saveList(beTvlProfiles);
				beTvlSvc.saveList(beTvls);
				beAcctTravellerSvc.saveList(beAcctTravellers);

			} else if (!BaseUtil.isObjNull(dto.getStatus())
					&& BaseUtil.isEquals("PF", dto.getStatus().getStatusCd())) {
				List<BeTvl> beTvls = new ArrayList<>();
				List<BeTvlProfile> beTvlProfiles = new ArrayList<>();
				RefStatus refStatus = JsonUtil.transferToObject(dto.getStatus(), RefStatus.class);
				for (BeTvlPaymentDtl dtl : beTvlPaymentDtls) {
					Tvl tvl = new Tvl();
					TvlProfile tvlProf = new TvlProfile();
					tvlProf.setTvlProfId(dtl.getTvlProfile().getTvlProfId());
					tvl.setTvlProfile(tvlProf);

					BeTvl beTvl = beTvlSvc.searchBeTravel(tvl);
					beTvl.setIsActive(false);
					beTvl.setStatus(refStatus);
					beTvls.add(beTvl);

					List<BeTvlProfile> tvlProfileList = beTvlProfileSvc.searchBeTvlProfileByAcctTvlrIdAndStatusCd(
							dtl.getTvlProfile().getAcctTraveller().getAcctTvlrId(), "PF");

					if (!BaseUtil.isListNull(tvlProfileList)) {
						for (BeTvlProfile tvlProfile : tvlProfileList) {
							if ((tvlProfileList.indexOf(tvlProfile) != tvlProfileList.size() - 1)
									&& (dtl.getTvlProfile().getTvlProfId() != tvlProfile.getTvlProfId())
									&& BaseUtil.isObjNull(tvlProfile.getDisabled())) {
								tvlProfile.setDisabled(true);
								tvlProfile.setUpdateId(dto.getUserPayId());
								beTvlProfiles.add(tvlProfile);
							}
						}
					}

				}
				beTvlProfileSvc.saveList(beTvlProfiles);
				beTvlSvc.saveList(beTvls);
			}

			beTvlPaymentKipleSvc.addPaymentKipleInfo(beTvlPayment, dto.getUserPayId());

			if (!BaseUtil.isObjNull(bvlPayment) && !BaseUtil.isEquals(dto.getUserPayId(), "")) {
				try {
					UserProfile profile = new UserProfile();
					profile.setUserId(dto.getUserPayId());
					List<UserProfile> userList = getIdmService(request).searchUsers(profile);
					if (!BaseUtil.isListNull(userList)) {
						Map<String, Object> map = new HashMap<>();
						map.put("fullName", userList.get(0).getFirstName());
						map.put("amount", bvlPayment.getAmount());
						map.put("paymentDate", !BaseUtil.isObjNull(bvlPayment.getPmtDt())
								? DateUtil.convertDate(bvlPayment.getPmtDt(), BaseConstants.DT_DD_MM_YYYY_SLASH)
								: null);
						List<AcctTraveller> travellerList = new ArrayList<>();
						if (bvlPayment.getBeTvlPaymentDtls().size() != 0) {
							map.put("travellerCount", bvlPayment.getBeTvlPaymentDtls().size());
							for (BeTvlPaymentDtl paymentDtl : bvlPayment.getBeTvlPaymentDtls()) {
								BeAcctTraveller beAccTraveller = paymentDtl.getTvlProfile().getAcctTraveller();
								AcctTraveller traveller = new AcctTraveller();
								traveller.setFullName(beAccTraveller.getFullName());
								traveller.setPassportNo(beAccTraveller.getAcctPassport().getPassportNo());
								Country country = new Country();
								country.setCntryDesc(beAccTraveller.getCountry().getCntryDesc());
								traveller.setNationality(country);
								traveller.setGender(BaseUtil.isEquals(beAccTraveller.getGender(), "M") ? "Male"
										: "Female");
								traveller.setDobStr(!BaseUtil.isObjNull(beAccTraveller.getDob())
										? DateUtil.convertDate(beAccTraveller.getDob(),
												BaseConstants.DT_DD_MM_YYYY_SLASH)
										: null);
								travellerList.add(traveller);
							}
							map.put("travellerList", travellerList);
						}

						if (!BaseUtil.isObjNull(userList.get(0).getEmail())) {
							Notification notification = new Notification();
							notification.setNotifyTo(userList.get(0).getEmail());
							notification.setMetaData(MailUtil.convertMapToJson(map));

							if (!BaseUtil.isObjNull(dto.getStatus())
									&& BaseUtil.isEquals("PS", dto.getStatus().getStatusCd())) {
								notification.setAttachments(new ArrayList<>());
								if (!BaseUtil.isObjNull(invoice) && !BaseUtil.isListNull(invoiceDoc)) {
									notification.getAttachments()
											.add(setNotificationAttachments(invoice, invoiceDoc.get(0)));
								}
								if (!BaseUtil.isObjNull(receipt) && !BaseUtil.isListNull(receiptDoc)) {
									notification.getAttachments()
											.add(setNotificationAttachments(receipt, receiptDoc.get(0)));
								}
								getNotifyService(request).addNotification(notification,
										MailTemplateConstants.TRAVEL_PAYMENT_SUCCESSFUL);
							} else if (!BaseUtil.isObjNull(dto.getStatus())
									&& BaseUtil.isEquals("PF", dto.getStatus().getStatusCd())) {
								getNotifyService(request).addNotification(notification,
										MailTemplateConstants.TRAVEL_PAYMENT_FAIL);
							}

							try {
								Integer profId = userList.get(0).getProfId();
								String userType = "TVL";
								if (profId > 0) {
									UserProfile userProfile = getIdmService(request)
											.getUserProfileByProfIdUserType(profId, userType, false, false);
									Map<String, Object> datamap = new LinkedHashMap<>();
									datamap.put("invoiceNo", bvlPayment.getPmtRefNo());
									datamap.put("paymentAmount", df.format(bvlPayment.getAmount()));
									datamap.put("noOfTraveller", travellerList.size());
									List<FcmDevice> devices = searchAllDevice(userProfile, request);

									if (!BaseUtil.isObjNull(dto.getStatus())
											&& BaseUtil.isEquals("PS", dto.getStatus().getStatusCd())) {
										addFCMNotification(devices, userProfile, datamap,
												MailTemplateConstants.FCM_PAYMENT_SUCCESS, request);
									} else if (!BaseUtil.isObjNull(dto.getStatus())
											&& BaseUtil.isEquals("PF", dto.getStatus().getStatusCd())) {
										addFCMNotification(devices, userProfile, datamap,
												MailTemplateConstants.FCM_PAYMENT_FAIL, request);
									}

								}
							} catch (Exception e) {
								// safety reason : ignore and check
								// if payload created
							}
						}

					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			return bvlPayment;
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	private List<FcmDevice> searchAllDevice(UserProfile userProfile, HttpServletRequest request) throws IdmException {
		FcmDevice fcmDevice = new FcmDevice();
		fcmDevice.setStatus(true);

		Fcm fcm = new Fcm();
		fcm.setUserId(userProfile.getUserId());
		fcm.setStatus(true);
		fcmDevice.setFcm(fcm);

		return getIdmService(request).searchFcmDevice(fcmDevice);
	}


	private void addFCMNotification(List<FcmDevice> devices, UserProfile userProfile, Map<String, Object> map,
			String template, HttpServletRequest request) {
		if (!BaseUtil.isObjNull(userProfile)) {
			if (!BaseUtil.isListNull(devices)) {
				for (FcmDevice device : devices) {
					if (!BaseUtil.isObjNull(device.getFcmToken())) {

						Notification notification = new Notification();
						notification.setNotifyTo(userProfile.getUserId());
						notification.setNotifyCc(device.getFcmToken());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setNotifyType(MailTypeEnum.FCM.getType());

						getNotifyService(request).addNotification(notification, template);
					}
				}
			}

		}
	}
}
