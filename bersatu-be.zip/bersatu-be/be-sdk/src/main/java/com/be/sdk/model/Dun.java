/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author Ramesh Pongiannan
 *
 */
public class Dun implements Serializable, IQfCriteria<Dun> {

	private static final long serialVersionUID = 5466589728737397061L;

	private String dunCd;

	private String dunDesc;

	private String parliamentCd;

	private Parliament parliament;

	private State state;

	private String status;

	private Timestamp createDt;

	private String createId;

	private Timestamp updateDt;

	private String updateId;


	public String getDunCd() {
		return dunCd;
	}


	public void setDunCd(String dunCd) {
		this.dunCd = dunCd;
	}


	public String getDunDesc() {
		return dunDesc;
	}


	public void setDunDesc(String dunDesc) {
		this.dunDesc = dunDesc;
	}


	public String getParliamentCd() {
		return parliamentCd;
	}


	public void setParliamentCd(String parliamentCd) {
		this.parliamentCd = parliamentCd;
	}


	public Parliament getParliament() {
		return parliament;
	}


	public void setParliament(Parliament parliament) {
		this.parliament = parliament;
	}


	public State getState() {
		return state;
	}


	public void setState(State state) {
		this.state = state;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
