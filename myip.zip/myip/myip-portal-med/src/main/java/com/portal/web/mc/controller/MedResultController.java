package com.portal.web.mc.controller;


import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.time.DateUtils;
import org.codehaus.groovy.syntax.TokenException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.be.sdk.exception.BeException;
import com.be.sdk.model.AcctPassport;
import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.ConfigMcCollate;
import com.be.sdk.model.DoctorProfile;
import com.be.sdk.model.McCollate;
import com.be.sdk.model.McProfile;
import com.be.sdk.model.Metadata;
import com.be.sdk.model.Payment;
import com.be.sdk.model.Status;
import com.be.sdk.model.TrxnDocuments;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlProfile;
import com.be.sdk.model.TvlTestResult;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.gson.Gson;
import com.idm.sdk.exception.IdmException;
import com.idm.sdk.model.UserProfile;
import com.idm.sdk.model.UserRole;
import com.portal.constants.AppConstants;
import com.portal.constants.CryptoBaseUtil;
import com.portal.constants.MessageConstants;
import com.portal.constants.PageConstants;
import com.portal.constants.PageTemplate;
import com.portal.constants.ProjectEnum;
import com.portal.core.AbstractController;
import com.portal.web.mc.form.MedicalResultForm;
import com.portal.web.util.WebUtil;
import com.report.sdk.constants.ReportErrorCodeEnum;
import com.report.sdk.constants.ReportTypeEnum;
import com.report.sdk.exception.ReportException;
import com.report.sdk.model.Report;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.JsonUtil;
import com.util.PopupBox;
import com.util.QRGenerator;
import com.util.constants.BaseConstants;
import com.util.model.RefDocuments;
import com.util.pagination.DataTableResults;


@Controller
@RequestMapping(value = PageConstants.PAGE_SEARCH_MCTEST_RESULT)
public class MedResultController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MedResultController.class);

	private static final String JS_FILENAME = "mcMedResult";

	private static final String MODULE = "mc_med_result";

	@Autowired
	@Qualifier("UpdtAprvMedResValidator")
	private Validator validator;


	@Override
	public void bindingPreparation(WebDataBinder binder) {
		binder.setValidator(validator);
		super.bindingPreparation(binder);
	}


	@GetMapping
	public ModelAndView list(@ModelAttribute("medResultForm") Tvl tvl, BindingResult result,
			HttpServletRequest request) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_MEDICAL_RESULT_SEARCH, MODULE, MODULE, null, JS_FILENAME);

		boolean isDrAccess = false;
		String userRoleGroupCode;

		UserProfile currentUser = getCurrentUser();
		userRoleGroupCode = currentUser.getUserRoleGroup().getUserGroupCode();
		if (BaseUtil.isEqualsCaseIgnore(userRoleGroupCode, "MC_DOCTOR")) {
			isDrAccess = true;
		}

		mav.addObject("medResultSearchForm", tvl);
		mav.addObject("isDrAccess", isDrAccess);
		return mav;
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String getApplicationInfoPaginated(@ModelAttribute("tvl") Tvl tvl, BindingResult result,
			HttpServletRequest request) {
		LOGGER.info("GET PAGINATED USER LIST....");

		UserProfile currentUser = getCurrentUser();
		DataTableResults<Tvl> travlr = null;
		LOGGER.info("REQUEST====={}", JsonUtil.objectMapper().valueToTree(tvl));
		try {
			tvl.setEmbedPayment(true);
			tvl.setEmbedMedical(true);
			tvl.setStatusIdList(new ArrayList<Integer>());

			new ArrayList<>();

			if (!BaseUtil.isObjNull(currentUser.getUserRoleGroup())) {
				if (BaseUtil.isEquals(currentUser.getUserRoleGroup().getUserGroupCode(), "MC_DOCTOR")) {
					// doc

					if ((tvl.getStatusCd() == "") && (tvl.getFullName() == "") && (tvl.getPassportNo() == "")
							&& (tvl.getAttendanceDtFrom() == null) && (tvl.getAttendanceDtTo() == null)) {
						for (Status status : staticData.findByStatusCd("MC_PEND")) {
							tvl.getStatusIdList().add(status.getStatusId());
						}
					}

					if (BaseUtil.isEquals(tvl.getStatusCd(), "ALL")) {
						tvl.getStatusIdList().add(staticData.statusByStatusType("MC_APR", "MC").getStatusId());
						tvl.getStatusIdList().add(staticData.statusByStatusType("MC_PEND", "MC").getStatusId());
						tvl.getStatusIdList().add(staticData.statusByStatusType("MC_REJ", "MC").getStatusId());
						// for (Status status :
						// staticData.findByStatusType("MC")) {
						// tvl.getStatusIdList().add(status.getStatusId());
						// }
						tvl.setStatusCd("");
					}

					if (!BaseUtil.isObjNull(tvl.getStatusCd())) {
						List<Status> statusLst = staticData.findByStatusCd(tvl.getStatusCd());
						tvl.setStatusId(statusLst.get(0).getStatusId());
					} else if ((!BaseUtil.isObjNull(tvl.getPassportNo()))
							|| (!BaseUtil.isObjNull(tvl.getFullName()))
							|| (!BaseUtil.isObjNull(tvl.getAttendanceDtFrom()))
							|| (!BaseUtil.isObjNull(tvl.getAttendanceDtTo()))) {
						for (Status status : staticData.findByStatusType("MC")) {
							tvl.getStatusIdList().add(status.getStatusId());
						}
					}
				} else {
					// operator
					if ((tvl.getStatusCd() == "") && (tvl.getFullName() == "") && (tvl.getPassportNo() == "")
							&& (tvl.getAttendanceDtFrom() == null) && (tvl.getAttendanceDtTo() == null)) {
						for (Status status : staticData.findByStatusCd("AT_VER")) {
							tvl.getStatusIdList().add(status.getStatusId());
						}
					}

					if (BaseUtil.isEquals(tvl.getStatusCd(), "ALL")) {
						for (Status status : staticData.findByStatusType("MC")) {
							tvl.getStatusIdList().add(status.getStatusId());
						}
						tvl.setStatusCd("");
					}

					if (!BaseUtil.isObjNull(tvl.getStatusCd())) {
						List<Status> statusLst = staticData.findByStatusCd(tvl.getStatusCd());
						tvl.setStatusId(statusLst.get(0).getStatusId());
					} else if ((!BaseUtil.isObjNull(tvl.getPassportNo()))
							|| (!BaseUtil.isObjNull(tvl.getFullName()))
							|| (!BaseUtil.isObjNull(tvl.getAttendanceDtFrom()))
							|| (!BaseUtil.isObjNull(tvl.getAttendanceDtTo()))) {
						for (Status status : staticData.findByStatusType("MC")) {
							tvl.getStatusIdList().add(status.getStatusId());
						}
					}
				}
			}

			if (!BaseUtil.isObjNull(tvl.getName())) {
				String nameUpper = tvl.getName().toUpperCase();
				tvl.setFullName(nameUpper);
			}

			if (!BaseUtil.isObjNull(tvl.getPassportNo())) {
				String passportNoUpper = tvl.getPassportNo().toUpperCase();
				tvl.setPassportNo(passportNoUpper);

			}

			TvlProfile tvlProfile = new TvlProfile();

			if (!BaseUtil.isObjNull(tvl.getPassportNo())) {
				AcctPassport acctPassport = new AcctPassport();
				acctPassport.setPassportNo(tvl.getPassportNo());
				tvlProfile.setAcctPassport(acctPassport);
			}

			if (!BaseUtil.isObjNull(tvl.getFullName())) {
				tvlProfile.setFullName(tvl.getFullName());
			}

			tvl.setTvlProfile(tvlProfile);

			if (!BaseUtil.isObjNull(currentUser.getProfId())
					&& !BaseUtil.isObjNull(currentUser.getUserRoleGroup())) {
				if (BaseUtil.isEquals(currentUser.getUserRoleGroup().getUserGroupCode(), "MC_DOCTOR")) {
					DoctorProfile doctorProfile = new DoctorProfile();
					doctorProfile.setDocProfId(currentUser.getProfId());
					doctorProfile = getBeService().profileService().getDoctorProfile(doctorProfile);
					if (!BaseUtil.isObjNull(doctorProfile)) {
						tvl.setMcProfId(doctorProfile.getBeMcProfile().getMcProfId());
					}
				} else {
					tvl.setMcProfId(currentUser.getProfId());
				}
			} else {
				tvl.setMcProfId(0);
			}

			// to filter based on countryCd of the OPERATOR/DOCTOR
			tvl.setCountryCd(currentUser.getCntryCd());
			travlr = getBeService().travelService().searchTravelPagination(tvl, getPaginationRequest(request, true));

			List<Tvl> tempListTvl = JsonUtil.objectMapper().convertValue(travlr.getData(),
					new TypeReference<List<Tvl>>() {
					});

			String keySecret = staticData.beConfig("HASH_SECRET_KEY");
			tempListTvl = tempListTvl.stream().map(tvlObj -> {
				String cyptString = CryptoBaseUtil.encrypt(tvlObj.getTvlProfile().getTvlProfId(), keySecret);
				tvlObj.setSecCdId(cyptString);
				return tvlObj;
			}).collect(Collectors.toList());

			travlr.setData(tempListTvl);
		} catch (Exception e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(e.getMessage());
		}

		return new Gson().toJson(travlr);
	}


	@GetMapping(value = "/{id}/approve")
	public ModelAndView viewApprove(@PathVariable int id,
			@ModelAttribute("medResultForm") MedicalResultForm medResultForm, BindingResult result,
			HttpServletRequest request) {
		String url_path_string = "test-result-search";
		// initialised model view
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_APPROVED_MEDICAL_RESULT, MODULE, MODULE, null,
				JS_FILENAME);

		// mav.addObject("doctor", doctor);
		mav.addObject(AppConstants.PORTAL_MODULE, url_path_string);
		// mav.addObject("refDocLst", getRefDocLst());
		List<ConfigMcCollate> configMcCollateLst = getBeService().reference()
				.findCollateByCriteria(new ConfigMcCollate());

		mav.addObject("configMcCollateLst", configMcCollateLst);
		mav.addObject("medResultForm", medResultForm);
		mav.addObject("view_traveller", true);
		LOGGER.info("viewApprove");

		return mav;
	}


	@GetMapping(value = "/{id}/update")
	public ModelAndView viewUpdate(@PathVariable("id") String ids,
			@ModelAttribute("medResultForm") MedicalResultForm medResultForm, BindingResult result,
			HttpServletRequest request) {
		String url_path_string = "";
		int id = 0;
		try {
			id = CryptoBaseUtil.decryptInteger(ids, staticData.beConfig("HASH_SECRET_KEY"));
		} catch (Exception e) {
			// TODO: handle exception
		}
		// initialised model view
		UserProfile currentUser = getCurrentUser();

		if (BaseUtil.isEquals(currentUser.getUserRoleGroup().getUserGroupCode(), "MC_DOCTOR")) {
			url_path_string = "appr_med";
			medResultForm.setIsMedDr(true);
		} else {
			url_path_string = "ver_med";
			medResultForm.setIsMedDr(false);
		}
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_UPDATE_MEDICAL_RESULT, url_path_string, url_path_string,
				null, JS_FILENAME);
		boolean isCanUpdate = false;

		// mav.addObject("doctor", doctor);
		Tvl trvlProf = null;
		McProfile mcProf = new McProfile();
		Tvl tvlRsult = new Tvl();
		TvlProfile tvlProfile = new TvlProfile();
		tvlProfile.setTvlProfId(id);
		tvlRsult.setTvlProfile(tvlProfile);
		tvlRsult.setEmbedTrip(true);
		tvlRsult.setEmbedMedical(true);
		tvlRsult.setEmbedTraveller(true);
		trvlProf = getBeService().travelService().getTravel(tvlRsult);

		UserProfile profile = new UserProfile();
		profile = getCurrentUser();
		mcProf.setMcProfId(profile.getProfId());
		mcProf = getBeService().profileService().getMcProfile(mcProf);

		medResultForm.setTvl(trvlProf);
		AcctTraveller acctTraveller = new AcctTraveller();

		acctTraveller.setAcctTvlrId(trvlProf.getTvlProfile().getAcctTraveller().getAcctTvlrId());
		acctTraveller.setView(true);
		acctTraveller = getBeService().travellerService().getAcctTraveller(acctTraveller);

		// set back detail
		if (!BaseUtil.isObjNull(trvlProf)) {
			if (!BaseUtil.isListNull(trvlProf.getTvlProfile().getTvlTestResults())) {
				TvlTestResult tvlTest = trvlProf.getTvlProfile().getTvlTestResults().get(0);
				medResultForm.getTvl().getTvlProfile().setTvlTestResult(tvlTest);

				String collateCd = "";

				if (tvlTest.getMedicalResult().equals(1)) {
					collateCd = "N";
				} else {
					collateCd = "P";
				}

				medResultForm.setCollateCd(collateCd);
				medResultForm.setCollateDrCd(collateCd);

				medResultForm.setStatusCd(trvlProf.getStatus().getStatusCd());
				medResultForm.setStatusDesc(trvlProf.getStatus().getStatusDesc());
			} else {
				medResultForm.setStatusCd(trvlProf.getStatus().getStatusCd());
				if (BaseUtil.isEqualsCaseIgnore(trvlProf.getStatus().getStatusCd(), "AT_VER")) {
					medResultForm.setStatusDesc("PENDING COLLATE MEDICAL");
				}
			}
		}

		if (!BaseUtil.isObjNull(currentUser)
				&& (!BaseUtil.isEquals(currentUser.getUserRoleGroup().getUserGroupCode(), "MC_DOCTOR"))) {
			if (!BaseUtil.isObjNull(trvlProf.getStatus())) {
				if (BaseUtil.isEquals(trvlProf.getStatus().getStatusCd(), "AT_VER")) {
					isCanUpdate = true;
				}
			}
		} else {
			if (BaseUtil.isEquals(trvlProf.getStatus().getStatusCd(), "MC_PEND")) {
				isCanUpdate = true;
				medResultForm.setRemarksOperator("YES");
			}
		}
		List<ConfigMcCollate> configMcCollateLst = getBeService().reference()
				.findCollateByCriteria(new ConfigMcCollate());

		// view myIp Slip
		String myIpSlipUrl = null;
		String myIpSlipDocMgtId = getTrxnDocumentDocMgtId(trvlProf.getTvlProfile().getDocRefNo(), "MYIP_SLIP");
		myIpSlipUrl = "/mcTest/report/viewreport.pdf?docMgtId=" + myIpSlipDocMgtId;

		medResultForm.setMyIpSlipDocMgtId(myIpSlipDocMgtId);
		mav.addObject("myIpSlipUrl", myIpSlipUrl);

		if (!BaseUtil.isListNull(trvlProf.getTvlProfile().getTvlTestResults())) {
			if (!BaseUtil.isObjNull(trvlProf.getTvlProfile().getTvlTestResults().get(0).getMedTestDt())) {
				TvlTestResult testResult = trvlProf.getTvlProfile().getTvlTestResults().get(0);
				if (!BaseUtil.isObjNull(testResult)) {
					Date validUpto = DateUtil.addDayToTimestamp(new Date(testResult.getMedTestDt().getTime()), 3);
					mav.addObject("validUpto", DateUtil.convertDate(validUpto, BaseConstants.DT_DD_MM_YYYY_SLASH));
				}
			}
		}

		// view medical report
		String medRptUrl = "";
		if (!BaseUtil.isListNull(trvlProf.getTvlProfile().getTvlTestResults())) {
			List<TvlTestResult> results = trvlProf.getTvlProfile().getTvlTestResults();
			TvlTestResult testResult = null;
			if (!BaseUtil.isListNull(results) && !BaseUtil.isListZero(results)) {
				testResult = results.get(0);
			}
			if (!BaseUtil.isObjNull(testResult)) {
				String medicalDocMgtId = getTrxnDocumentDocMgtId(testResult.getDocRefNo(), "MEDICAL_REPORT");
				medRptUrl = "/mcTest/report/viewreport.pdf?docMgtId=" + medicalDocMgtId;

				medResultForm.setMedicalDocMgtId(medicalDocMgtId);
				mav.addObject("medRptUrl", medRptUrl);

			}

			if (trvlProf.getIsActive()) {
				trvlProf.setTvlIsActiveStatus("ACTIVE");
			} else {
				trvlProf.setTvlIsActiveStatus("INACTIVE");
			}
		}

		mav.addObject("configMcCollateLst", configMcCollateLst);
		mav.addObject("medResultForm", medResultForm);

		mav.addObject("trvlProf", trvlProf);
		mav.addObject("mcProf", mcProf);
		mav.addObject("view_traveller", true);
		mav.addObject("isCanUpdate", isCanUpdate);
		mav.addObject("acctTraveller", acctTraveller);
		mav.addObject("acctPassport", acctTraveller.getAcctPassport());
		mav.addObject("usertype", currentUser.getUserRoleGroup().getUserGroupCode());
		return mav;
	}


	@PostMapping(params = "submit")
	public ModelAndView updateTestResult(@Validated @ModelAttribute("medResultForm") MedicalResultForm medResultForm,
			BindingResult result, HttpServletRequest request) {

		UserProfile currentUser = getCurrentUser();
		String url_path_string = "";
		List<ConfigMcCollate> configMcCollateLst = null;
		boolean isCanUpdate = false;
		Integer medicalResult = 0;
		TvlTestResult ttr = null;

		if (BaseUtil.isEquals(currentUser.getUserRoleGroup().getUserGroupCode(), "MC_DOCTOR")) {
			url_path_string = "appr_med";
			medResultForm.setIsMedDr(true);
		} else {
			url_path_string = "ver_med";
			medResultForm.setIsMedDr(false);
		}

		// initialised model view
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_UPDATE_MEDICAL_RESULT, url_path_string, url_path_string,
				null, JS_FILENAME);

		configMcCollateLst = getBeService().reference().findCollateByCriteria(new ConfigMcCollate());

		ttr = getDetails(medResultForm, configMcCollateLst, medicalResult);

		if (!result.hasErrors()) {
			try {

				if (!BaseUtil.isObjNull(medResultForm.getCollateCd())
						|| !BaseUtil.isObjNull(medResultForm.getCollateDrCd())) {
					if (BaseUtil.isEquals(medResultForm.getCollateCd(), "N")
							|| BaseUtil.isEquals(medResultForm.getCollateDrCd(), "N")) {
						medicalResult = 1;
					} else {
						medicalResult = 0;
					}
				}

				ttr = getDetails(medResultForm, configMcCollateLst, medicalResult);
				ttr = getBeService().medicalService().updateApprovedMedicalInfo(ttr);
				if (!BaseUtil.isObjNull(ttr)) {
					if (BaseUtil.isEquals(currentUser.getUserRoleGroup().getUserGroupCode(), "MC_DOCTOR")) {
						mav.addAllObjects(PopupBox.success(MessageConstants.SUC_APRV_TEST_RESULT, null,
								messageService.getMessage(MessageConstants.SUC_APRV_TEST_RESULT),
								PageConstants.PAGE_SEARCH_MCTEST_RESULT));
					} else {
						mav.addAllObjects(PopupBox.success(MessageConstants.SUC_UPDATE_TEST_RESULT, null,
								messageService.getMessage(MessageConstants.SUC_UPDATE_TEST_RESULT),
								PageConstants.PAGE_SEARCH_MCTEST_RESULT));
					}
				} else {
					if (BaseUtil.isEquals(currentUser.getUserRoleGroup().getUserGroupCode(), "MC_DOCTOR")) {
						mav.addAllObjects(PopupBox.success(MessageConstants.ERROR_APRV_TEST_RESULT, null,
								messageService.getMessage(MessageConstants.ERROR_APRV_TEST_RESULT)));
					} else {
						mav.addAllObjects(PopupBox.success(MessageConstants.ERROR_UPDATE_TEST_RESULT, null,
								messageService.getMessage(MessageConstants.ERROR_UPDATE_TEST_RESULT)));
					}

				}
			} catch (Exception e) {
				// TODO: handle exception
				mav.addAllObjects(PopupBox.success(MessageConstants.ERROR_UPDATE_TEST_RESULT, null,
						messageService.getMessage(MessageConstants.ERROR_UPDATE_TEST_RESULT)));
			}
		}

		if (!BaseUtil.isEquals(currentUser.getUserRoleGroup().getUserGroupCode(), "MC_DOCTOR")) {
			if (!BaseUtil.isObjNull(medResultForm.getStatusCd())) {
				if (BaseUtil.isEquals(medResultForm.getStatusCd(), "AT_VER")) {
					isCanUpdate = true;
				}
			}
		} else {
			if (BaseUtil.isEquals(medResultForm.getStatusCd(), "MC_PEND")) {
				isCanUpdate = true;
				medResultForm.setRemarksOperator("YES");
			}
		}

		Tvl trvlProf = null;
		Tvl tvlRsult = new Tvl();
		TvlProfile tvlProfile = new TvlProfile();
		tvlProfile.setTvlProfId(medResultForm.getTvl().getTvlProfile().getTvlProfId());
		tvlRsult.setTvlProfile(tvlProfile);
		tvlRsult.setEmbedMedical(true);
		tvlRsult.setEmbedTraveller(true);
		trvlProf = getBeService().travelService().getTravel(tvlRsult);

		AcctTraveller acctTraveller = new AcctTraveller();

		acctTraveller.setAcctTvlrId(trvlProf.getTvlProfile().getAcctTraveller().getAcctTvlrId());
		acctTraveller.setView(true);
		acctTraveller = getBeService().travellerService().getAcctTraveller(acctTraveller);

		mav.addObject("configMcCollateLst", configMcCollateLst);
		mav.addObject("medResultForm", medResultForm);
		mav.addObject("acctTraveller", acctTraveller);
		mav.addObject("trvlProf", trvlProf);
		mav.addObject("view_traveller", true);
		mav.addObject("isCanUpdate", isCanUpdate);
		return mav;
	}


	private TvlTestResult getDetails(MedicalResultForm medResultForm, List<ConfigMcCollate> configMcCollateLst,
			Integer medicalResult) {
		TvlTestResult ttr = new TvlTestResult();
		UserProfile up = getCurrentUser();

		ttr.setTvlProfId(medResultForm.getTvl().getTvlProfile().getTvlProfId());
		ttr.setMedicalResult(medicalResult);
		ttr.setCntryCd(up.getCntryCd());
		ttr.setMedTestDt(getSQLTimestamp());

		if (isDoctorAccess()) {
			ttr.setStatusId(staticData.statusByStatusType(ttr.getMedicalResult() == 1 ? "MC_APR" : "MC_REJ", "MC")
					.getStatusId());
			ttr.setDoctorProfId(up.getProfId());
			ttr.setDoctorRemarks(medResultForm.getTvl().getTvlProfile().getTvlTestResult().getDoctorRemarks());
		} else {
			ttr.setStatusId(staticData.statusByStatusType("MC_PEND", "MC").getStatusId());
			ttr.setMcProfId(up.getProfId());
			ttr.setRemarks(medResultForm.getTvl().getTvlProfile().getTvlTestResult().getRemarks());
		}

		/** manually set for now later need to get from screen */
		ttr.setMcCollates(new ArrayList<>());
		for (ConfigMcCollate config : configMcCollateLst) {
			McCollate mcCollate = new McCollate();
			mcCollate.setConfigMcCollate(config);
			mcCollate.setResultMtdt(
					staticData.findByMetadataType("ANSWER", ttr.getMedicalResult() == 0 ? "N" : "Y"));
			ttr.getMcCollates().add(mcCollate);
		}
		return ttr;
	}


	@RequestMapping(value = "/addDr", method = RequestMethod.GET)
	public ModelAndView index(@ModelAttribute("doctorProfile") DoctorProfile doctorProfile, BindingResult result)
			throws Exception {
		String url_path_string = "doc-add";
		ModelAndView mav = getDefaultMav(PageTemplate.PAGE_DOC_ADD, MODULE, null, null, JS_FILENAME);

		LOGGER.info("as1");

		mav.addObject(AppConstants.PORTAL_MODULE, url_path_string);
		mav.addObject("addType", true);
		return mav;
	}


	@PostMapping(value = "/addDr", params = "submit")
	public ModelAndView create(@Valid @ModelAttribute("doctorProfile") DoctorProfile doctorProfile,
			BindingResult result, HttpServletRequest request, HttpSession session) throws BeException {

		ModelAndView mav = getDefaultMav(PageTemplate.PAGE_DOC_ADD, MODULE, null, null, JS_FILENAME);

		try {
			doctorProfile.getBeMcProfile().setMcProfId(getCurrentUser().getProfId());

			/*
			 * UserProfile up = getCurrentUser();
			 * doctorProfile.getBeMcProfile().setMcProfId(up .getProfId());
			 */

			doctorProfile = getBeService().profileService().registerDoctor(doctorProfile);
			LOGGER.info("payload--" + doctorProfile);
			if (doctorProfile.getDocProfId() != null) {
				mav.addAllObjects(PopupBox.success("Register", null, "Record successfully created",
						PageConstants.PAGE_SEARCH_DOCTOR));
			} else {
				mav.addAllObjects(PopupBox.error("Register", null, "Record insersion failed"));
			}
		} catch (BeException beEx) {
			mav.addAllObjects(PopupBox.error("Register", null, "Exception occurred while inserting data"));
		}

		mav.addObject("doctorProfile", doctorProfile);
		// mav.addObject("refDocLst", getRefDocLst());
		return mav;
	}


	@ModelAttribute("appStatList")
	public List<Status> getAppStatusList() throws Exception {
		List<Status> statusList = staticData.findAllStatus();
		LOGGER.info("<<<<<< statLst size >>>>>>" + statusList.size());

		return statusList;
	}


	@RequestMapping(value = "/view/{id}")
	public ModelAndView view(@PathVariable("id") String ids,
			@ModelAttribute("medResultForm") MedicalResultForm medResultForm, BindingResult result,
			HttpServletRequest request) {
		String url_path_string = "";
		// initialised model view
		UserProfile currentUser = getCurrentUser();

		Integer id = CryptoBaseUtil.decryptInteger(ids, staticData.beConfig("HASH_SECRET_KEY"));

		if (BaseUtil.isEquals(currentUser.getUserRoleGroup().getUserGroupCode(), "MC_DOCTOR")) {
			url_path_string = "appr_med";
			medResultForm.setIsMedDr(true);
		} else {
			url_path_string = "ver_med";
			medResultForm.setIsMedDr(false);
		}
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_UPDATE_MEDICAL_RESULT, url_path_string, url_path_string,
				null, JS_FILENAME);
		boolean isCanUpdate = false;

		// mav.addObject("doctor", doctor);
		Tvl trvlProf = null;
		McProfile mcProf = new McProfile();
		Tvl tvlRsult = new Tvl();
		TvlProfile tvlProfile = new TvlProfile();
		tvlProfile.setTvlProfId(id);
		tvlRsult.setTvlProfile(tvlProfile);
		tvlRsult.setEmbedTrip(true);
		tvlRsult.setEmbedMedical(true);
		tvlRsult.setEmbedTraveller(true);
		trvlProf = getBeService().travelService().getTravel(tvlRsult);

		UserProfile profile = new UserProfile();
		profile = getCurrentUser();
		mcProf.setMcProfId(profile.getProfId());
		mcProf = getBeService().profileService().getMcProfile(mcProf);

		medResultForm.setTvl(trvlProf);
		AcctTraveller acctTraveller = new AcctTraveller();

		acctTraveller.setAcctTvlrId(trvlProf.getTvlProfile().getAcctTraveller().getAcctTvlrId());
		acctTraveller.setView(true);
		acctTraveller = getBeService().travellerService().getAcctTraveller(acctTraveller);

		// set back detail
		if (!BaseUtil.isObjNull(trvlProf)) {
			if (!BaseUtil.isListNull(trvlProf.getTvlProfile().getTvlTestResults())) {
				TvlTestResult tvlTest = trvlProf.getTvlProfile().getTvlTestResults().get(0);
				medResultForm.getTvl().getTvlProfile().setTvlTestResult(tvlTest);

				String collateCd = "";

				if (tvlTest.getMedicalResult().equals(1)) {
					collateCd = "N";
				} else {
					collateCd = "P";
				}

				medResultForm.setCollateCd(collateCd);
				medResultForm.setCollateDrCd(collateCd);

				medResultForm.setStatusCd(trvlProf.getStatus().getStatusCd());
				medResultForm.setStatusDesc(trvlProf.getStatus().getStatusDesc());
			} else {
				medResultForm.setStatusCd(trvlProf.getStatus().getStatusCd());
				if (BaseUtil.isEqualsCaseIgnore(trvlProf.getStatus().getStatusCd(), "AT_VER")) {
					medResultForm.setStatusDesc("PENDING COLLATE MEDICAL");
				}
			}
		}

		if (!BaseUtil.isObjNull(currentUser)
				&& (!BaseUtil.isEquals(currentUser.getUserRoleGroup().getUserGroupCode(), "MC_DOCTOR"))) {
			if (!BaseUtil.isObjNull(trvlProf.getStatus())) {
				if (BaseUtil.isEquals(trvlProf.getStatus().getStatusCd(), "AT_VER")) {
					isCanUpdate = true;
				}
			}
		} else {
			if (BaseUtil.isEquals(trvlProf.getStatus().getStatusCd(), "MC_PEND")) {
				isCanUpdate = true;
				medResultForm.setRemarksOperator("YES");
			}
		}
		List<ConfigMcCollate> configMcCollateLst = getBeService().reference()
				.findCollateByCriteria(new ConfigMcCollate());

		// view myIp Slip
		String myIpSlipUrl = null;
		String myIpSlipDocMgtId = getTrxnDocumentDocMgtId(trvlProf.getTvlProfile().getDocRefNo(), "MYIP_SLIP");
		myIpSlipUrl = "/mcTest/report/viewreport.pdf?docMgtId=" + myIpSlipDocMgtId;

		medResultForm.setMyIpSlipDocMgtId(myIpSlipDocMgtId);
		mav.addObject("myIpSlipUrl", myIpSlipUrl);

		if (!BaseUtil.isListNull(trvlProf.getTvlProfile().getTvlTestResults())) {
			if (!BaseUtil.isObjNull(trvlProf.getTvlProfile().getTvlTestResults().get(0).getMedTestDt())) {
				TvlTestResult testResult = trvlProf.getTvlProfile().getTvlTestResults().get(0);
				if (!BaseUtil.isObjNull(testResult)) {
					Date validUpto = DateUtil.addDayToTimestamp(new Date(testResult.getMedTestDt().getTime()), 3);
					mav.addObject("validUpto", DateUtil.convertDate(validUpto, BaseConstants.DT_DD_MM_YYYY_SLASH));
				}
			}
		}

		// view medical report
		String medRptUrl = "";
		if (!BaseUtil.isListNull(trvlProf.getTvlProfile().getTvlTestResults())) {
			List<TvlTestResult> results = trvlProf.getTvlProfile().getTvlTestResults();
			TvlTestResult testResult = null;
			if (!BaseUtil.isListNull(results) && !BaseUtil.isListZero(results)) {
				testResult = results.get(0);
			}
			if (!BaseUtil.isObjNull(testResult)) {
				String medicalDocMgtId = getTrxnDocumentDocMgtId(testResult.getDocRefNo(), "MEDICAL_REPORT");
				medRptUrl = "/mcTest/report/viewreport.pdf?docMgtId=" + medicalDocMgtId;

				medResultForm.setMedicalDocMgtId(medicalDocMgtId);
				mav.addObject("medRptUrl", medRptUrl);

				if (testResult.getStatusId() == 107) {

					/* Start Countdown Section */
					if (!BaseUtil.isObjNull(testResult.getMedTestDt())) {
						Date addedTimeMedTest = DateUtils.addHours(new Date(testResult.getMedTestDt().getTime()),
								Integer.parseInt(staticData.beConfig("MYIP_VLDTY")));
						mav.addObject("addedTimeMedTest", addedTimeMedTest);

						if (DateUtil.checkDateExpire(addedTimeMedTest)) {
							mav.addObject("isEnabled", true);
						}
					}

					/* End Countdown Section */

					// Date validUpto = DateUtil.addDayToTimestamp(new
					// Date(testResult.getMedTestDt().getTime()),
					// 3);
					// System.out.println("###ValidUpto: " + validUpto);
					// mav.addObject("validUpto",
					// DateUtil.convertDate(validUpto,
					// BaseConstants.DT_DD_MM_YYYY_SLASH));
				}

			}

			if (trvlProf.getIsActive()) {
				trvlProf.setTvlIsActiveStatus("ACTIVE");
			} else {
				trvlProf.setTvlIsActiveStatus("INACTIVE");
			}
		}

		mav.addObject("configMcCollateLst", configMcCollateLst);
		mav.addObject("medResultForm", medResultForm);

		mav.addObject("trvlProf", trvlProf);
		mav.addObject("mcProf", mcProf);
		mav.addObject("view_traveller", true);
		mav.addObject("isCanUpdate", isCanUpdate);
		mav.addObject("acctTraveller", acctTraveller);
		mav.addObject("acctPassport", acctTraveller.getAcctPassport());
		mav.addObject("usertype", currentUser.getUserRoleGroup().getUserGroupCode());
		return mav;
	}


	@ModelAttribute("isDoctorAccess")
	public boolean isDoctorAccess() {

		UserRole role = getCurrentUser().getRoles().get(0);

		return BaseUtil.isEqualsCaseIgnore(role.getRoleCode(), "MC_DOCTOR");

	}


	@ModelAttribute("getStatusList")
	public List<Status> getStatusList() {

		List<Status> types = null;

		try {
			types = staticData.statusList();
		} catch (Exception e) {
			// TODO: handle exception
		}

		return types;
	}


	@GetMapping(value = "/getQrcode")
	public @ResponseBody byte[] getImage(@RequestParam(value = "id", required = false) String imgId,
			@RequestParam(value = "imgType", required = false) String imgType, HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("-------");
		String[] content = new String[] { "paymentRef|status|date" };
		BufferedImage img = QRGenerator.generateQRCode(100, content);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte[] imageInByte = null;
		try {
			ImageIO.write(img, "jpg", baos);
			baos.flush();
			imageInByte = baos.toByteArray();
			String a = Base64.encodeBase64String(imageInByte);
			System.out.println("--- " + a);
		} catch (Exception e) {
			e.printStackTrace();
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return imageInByte;
	}


	@ModelAttribute("statusMC")
	public List<Status> getstatusMC() {
		List<Status> types = null;
		List<Status> statuslst = new ArrayList<>();
		UserProfile up = getCurrentUser();
		try {
			types = staticData.findByStatusTypeOrderBySequence("MC");

			if (!BaseUtil.isListNull(types)) {
				if (!BaseUtil.isObjNull(up.getUserRoleGroup())) {
					if (BaseUtil.isEquals(up.getUserRoleGroup().getUserGroupCode(), "MC_DOCTOR")) {
						for (Status type : types) {
							if (!BaseUtil.isEquals(type.getStatusCd(), "AT_VER")) {
								statuslst.add(type);
							}
						}
					} else {
						for (Status type : types) {
							statuslst.add(type);
						}
					}
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

		return statuslst;
	}


	@RequestMapping(value = "/medicalReport/viewreport.pdf", method = RequestMethod.GET)
	public @ResponseBody byte[] medicalReportPdf(
			@RequestParam(value = "reportName", required = false) String reportName,
			@RequestParam(value = "tvlProfId", required = false) Integer tvlProfId) throws Exception {
		LOGGER.info("medicalReportPdf reportName>>>>>", reportName);
		LOGGER.info("medicalReportPdf tvlProfId>>>>>", tvlProfId);

		Report rjd = null;
		try {
			Tvl dto = new Tvl();
			TvlProfile tvlProfile = new TvlProfile();
			tvlProfile.setTvlProfId(tvlProfId);
			dto.setTvlProfile(tvlProfile);

			rjd = getReportService().report().genMedicalReport(dto, ReportTypeEnum.PDF);
			if (BaseUtil.isObjNull(rjd)) {
				throw new ReportException(ReportErrorCodeEnum.I404RPT001, new Object[] { reportName });

			} else {
				LOGGER.info("MEDICAL REPORT>>>>>", rjd.getReportBytes());
				return rjd.getReportBytes();
			}

		} catch (TokenException e) {
			if (WebUtil.checkTokenError(e)) {
				try {
					throw e;
				} catch (TokenException e1) {
					e1.printStackTrace();
				}
			}
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {

			LOGGER.info(e.getMessage());

		}
		return null;
	}


	@ModelAttribute("collateLst")
	public List<Metadata> getCollateLst() {
		List<Metadata> metadataLst = new ArrayList<>();
		List<Metadata> metadataRstLst = new ArrayList<>();

		try {
			metadataLst = staticData.findByMetadataType("COLLATE");

			for (Metadata metadata : metadataLst) {
				if (metadata.isStatus()) {
					metadataRstLst.add(metadata);
				}
			}

		} catch (Exception e) {
		}

		return metadataRstLst;
	}


	private String getTrxnDocumentDocMgtId(String docRefNo, String docTrxnNo) {
		if (!BaseUtil.isObjNull(docRefNo)) {
			List<TrxnDocuments> docs = getBeService().trxnDocumentService().getTrxnDocuments(docRefNo);
			new ArrayList<>();
			List<RefDocuments> refDocs = staticData.findRefDocumentssByTrxnNo(docTrxnNo);
			if (!BaseUtil.isListNullZero(refDocs)) {
				// RefDocuments refDoc = refDocs.get(0);
				// if(!BaseUtil.isListNullZero(newLst)) {
				if (!BaseUtil.isListNull(docs) && !BaseUtil.isListZero(docs)) {
					String docMgtId = docs.get(0).getDocMgtId();
					return docMgtId;
				} else {
					return null;
				}
				// }
				// newLst = docs.stream().filter(res ->
				// res.getDocId()==refDoc.getDocId()).collect(Collectors.toList());
			}
		}

		return null;
	}


	@PostMapping(params = "reset")
	public ModelAndView reset(@RequestParam String reset, @ModelAttribute("medResultForm") Tvl medicalResultForm,
			BindingResult result, HttpServletRequest request, HttpSession session) {
		return list(new Tvl(), result, request);
	}


	@RequestMapping(value = "/report/viewreport.pdf", method = RequestMethod.GET)
	public @ResponseBody byte[] viewPdf(@RequestParam(value = "docMgtId", required = false) String docMgtId)
			throws Exception {
		byte[] doc = null;
		if (docMgtId == null) {
			return doc;
		} else {
			try {
				doc = getDmService(ProjectEnum.MYIP).downloadByte(docMgtId);
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
		return doc;
	}


	@RequestMapping(value = "/details/viewOfficialRcpt.pdf", method = RequestMethod.GET)
	public @ResponseBody byte[] genOfficialRcptPdf(
			@RequestParam(value = "reportName", required = false) String reportName,
			@RequestParam(value = "pmtRefNo", required = false) String pmtRefNo) throws Exception {
		LOGGER.info("PAYMENT CONFIRM return reportName>>>>>", reportName);
		LOGGER.info("PAYMENT CONFIRM return pmtRefNo>>>>>", pmtRefNo);

		Report rjd = null;
		try {
			Payment payment = new Payment();
			payment.setPmtRefNo(pmtRefNo);
			rjd = getReportService().report().genOfficialReceipt(payment, ReportTypeEnum.PDF);

			if (BaseUtil.isObjNull(rjd)) {
				throw new ReportException(ReportErrorCodeEnum.I404RPT001, new Object[] { reportName });

			} else {
				LOGGER.info("PAYMENT CONFIRM official receipt>>>>>", rjd.getReportBytes());
				return rjd.getReportBytes();
			}

		} catch (TokenException e) {
			if (WebUtil.checkTokenError(e)) {
				try {
					throw e;
				} catch (TokenException e1) {
					e1.printStackTrace();
				}
			}
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {

			LOGGER.info(e.getMessage());

		}
		return null;
	}

}
