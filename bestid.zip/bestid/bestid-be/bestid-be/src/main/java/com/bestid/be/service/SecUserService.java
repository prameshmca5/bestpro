/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.SecUser;
import com.bestid.be.model.SecUserDevice;
import com.bestid.be.repo.GenericRepository;
import com.bestid.be.repo.SecUserDeviceRepository;
import com.bestid.be.repo.SecUserRepository;


/**
 * @author roziana
 * @since Nov 19, 2018
 */
@Transactional
@Service(QualifierConstants.SEC_USER_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.SEC_USER_SVC)
public class SecUserService extends AbstractService<SecUser> {

	@Autowired
	@Qualifier(QualifierConstants.SEC_USER_REPOSITORY)
	SecUserRepository secUserDao;
	
	@Autowired
	@Qualifier(QualifierConstants.SEC_USER_DEVICE_REPOSITORY)
	SecUserDeviceRepository secUserDeviceDao;


	@Override
	public GenericRepository<SecUser> primaryDao() {
		return secUserDao;
	}


	public SecUser findByUserName(String userName) {
		return secUserDao.findUserName(userName);
	}
	
	public SecUser findByProfileId(String profileId) {
		return secUserDao.findProfileId(profileId);
	}

	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public SecUser createSecUserInfo(SecUser secUser, SecUserDevice secUserDevice) {
		secUser = secUserDao.save(secUser);
		secUserDevice.setUserId(secUser.getUserId());
		secUserDeviceDao.save(secUserDevice);
		return secUser;
	}
	
	public SecUser findByUserIdProfileId(int userId,String profileId) {
		return secUserDao.findUserIdProfileId(userId, profileId);
	}
}
