/**
 *
 */
package com.be.service;


import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeAirlinesProfileQf;
import com.be.dao.BeAirlinesProfileRepository;
import com.be.model.BeAirlinesAddress;
import com.be.model.BeAirlinesProfile;
import com.be.sdk.constants.FileUploadConstants;
import com.be.sdk.model.AirlinesProfile;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.TrxnDocuments;
import com.fasterxml.jackson.databind.JsonNode;
import com.idm.sdk.model.UserGroupBranch;
import com.idm.sdk.model.UserProfile;
import com.idm.sdk.model.UserType;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.UidGenerator;
import com.util.pagination.DataTableRequest;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_AIRLINES_PROFILE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_AIRLINES_PROFILE_SVC)
public class BeAirlinesProfileService extends AbstractService<BeAirlinesProfile> {

	@Autowired
	BeAirlinesProfileRepository beAirlinesProfileDao;

	@Autowired
	BeAirlinesProfileQf beAirlinesProfileQf;

	@Autowired
	BeAirlinesContactService beAirlinesContactSvc;

	@Autowired
	BeAirlinesPicService beAirlinesPicSvc;

	@Autowired
	BeAirlinesAddressService beAirlinesAddressSvc;

	@Autowired
	BeTrxnDocumentService beTrxnDocumentSvc;


	@Override
	public GenericRepository<BeAirlinesProfile> primaryDao() {
		return beAirlinesProfileDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beAirlinesProfileQf.generateCriteria(cb, from, criteria);
	}


	public BeAirlinesProfile searchBeAirlinesProfile(AirlinesProfile dto) {
		return beAirlinesProfileQf.searchBeAirlinesProfile(dto);
	}


	@SuppressWarnings("unchecked")
	public List<AirlinesProfile> searchAirlinesPagination(AirlinesProfile dto, DataTableRequest<?> dataTableInRQ)
			throws IOException {
		return JsonUtil.transferToList(beAirlinesProfileQf.searchBeAirlinesProfilePagination(dto, dataTableInRQ),
				AirlinesProfile.class);
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class })
	public BeAirlinesProfile createUpdate(BeAirlinesProfile beAirlinesProfile, BeAirlinesProfile beAirlinesProfileOri,
			List<TrxnDocuments> docs, HttpServletRequest request, String systemType) throws Exception {

		String userId = getCurrUserId(request);
		@SuppressWarnings("unused")
		boolean isEmpty = false;
		if (BaseUtil.isObjNull(beAirlinesProfile.getAirlinesProfId())) {
			isEmpty = true;
			beAirlinesProfile.setDocRefNo(UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC));
			beAirlinesProfile.setCreateId(userId);
		} else {
			beAirlinesProfile.setCreateId(beAirlinesProfileOri.getCreateId());
			beAirlinesProfile.setCreateDt(beAirlinesProfileOri.getCreateDt());
		}
		beAirlinesProfile.setUpdateId(userId);
		beAirlinesProfile = update(beAirlinesProfile);

		if (beAirlinesProfile.getAirlinesContacts().iterator().hasNext()) {
			beAirlinesContactSvc.createUpdate(beAirlinesProfile.getAirlinesContacts(), beAirlinesProfile, userId);
		}

		if (beAirlinesProfile.getAirlinesPics().iterator().hasNext()) {
			beAirlinesPicSvc.createUpdate(beAirlinesProfile.getAirlinesPics(), beAirlinesProfile, userId);
		}

		if (beAirlinesProfile.getAirlinesAddresses().iterator().hasNext()) {
			beAirlinesAddressSvc.createUpdate(beAirlinesProfile.getAirlinesAddresses(), beAirlinesProfile, userId);
		}

		if (!BaseUtil.isListNull(docs)) {
			beTrxnDocumentSvc.createUpdate(docs, userId, beAirlinesProfile.getDocRefNo());
		}

		UserProfile userProfile = new UserProfile();
		UserType userType = new UserType();
		UserGroupBranch usrGroupBranch = new UserGroupBranch();
		if (isEmpty == true) {
			userType.setUserTypeCode("AIR");
			userProfile.setUserType(userType);
			userProfile.setUserRoleGroupCode("AIRLINE_ADMIN");
			userProfile.setProfId(beAirlinesProfile.getAirlinesProfId());

			usrGroupBranch.setBranchCode("AIR" + beAirlinesProfile.getAirlinesProfId());
			usrGroupBranch.setUserGroupCode(userProfile.getUserRoleGroupCode());
			usrGroupBranch.setUserType(userType);
			usrGroupBranch.setSystemType(systemType);
		} else {
			userProfile.setEmail(beAirlinesProfile.getEmail());
			userProfile.setProfId(beAirlinesProfile.getAirlinesProfId());
			userProfile.setUserRoleGroupCode("AIRLINE_ADMIN");
			List<UserProfile> userProfiles = null;
			try {
				userProfiles = getIdmService(request).searchUserProfile(userProfile);
			} catch (Exception e) {

			}
			if (!BaseUtil.isListNull(userProfiles)) {
				userProfile = userProfiles.get(0);
			}
			usrGroupBranch.setBranchId(userProfile.getBranchId());
			List<UserGroupBranch> ugbList = getIdmService(request).searchUserGroupBranch(usrGroupBranch);
			if (!BaseUtil.isListNull(ugbList)) {
				usrGroupBranch = ugbList.get(0);
			}
		}

		userProfile.setNationalId(beAirlinesProfile.getIataRegNo());
		userProfile.setFirstName(beAirlinesProfile.getAirlinesName());
		userProfile.setEmail(beAirlinesProfile.getEmail());
		userProfile.setContactNo(beAirlinesProfile.getContactNo());

		if (!beAirlinesProfile.getAirlinesAddresses().isEmpty()) {
			userProfile.setCntryCd(
					beAirlinesProfile.getAirlinesAddresses().iterator().next().getCountry().getCntryCd());
		}

		usrGroupBranch.setBranchName(beAirlinesProfile.getAirlinesName());
		usrGroupBranch.setEmail(beAirlinesProfile.getEmail());
		usrGroupBranch.setContactNo(beAirlinesProfile.getContactNo());
		usrGroupBranch.setFaxNo(beAirlinesProfile.getFaxNo());

		if (beAirlinesProfile.getAirlinesAddresses().iterator().hasNext()) {
			for (BeAirlinesAddress obj : beAirlinesProfile.getAirlinesAddresses()) {
				if (BaseUtil.isEquals(obj.getAddrType(), "H")) {
					usrGroupBranch.setAddr1(obj.getAddr1());
					usrGroupBranch.setAddr2(obj.getAddr2());
					usrGroupBranch.setAddr3(obj.getAddr3());
					usrGroupBranch.setAddr4(obj.getAddr4());
					usrGroupBranch.setZipcode(obj.getZipcode());
					usrGroupBranch.setStateCd(
							!BaseUtil.isObjNull(obj.getState()) ? obj.getState().getStateCd() : null);
					usrGroupBranch.setCntryCd(
							!BaseUtil.isObjNull(obj.getCountry()) ? obj.getCountry().getCntryCd() : null);
				}
			}
		}

		if (isEmpty == true) {
			usrGroupBranch = getIdmService(request).createUserGroupBranch(usrGroupBranch);
		} else {
			usrGroupBranch = getIdmService(request).updateUserGroupBranch(usrGroupBranch);
		}

		if (!BaseUtil.isObjNull(usrGroupBranch)) {
			userProfile.setBranchId(usrGroupBranch.getBranchId());
		}

		if (isEmpty == true) {
			getIdmService(request).createUser(userProfile);
		} else {
			getIdmService(request).updateProfile(userProfile);
		}

		return beAirlinesProfile;
	}


	public long getCount(AirlinesProfile dto) {
		return beAirlinesProfileQf.getCount(dto);
	}


	public List<BeAirlinesProfile> searchAllByProperty(BeAirlinesProfile profile) {
		return beAirlinesProfileQf.searchAllByProperty(profile);
	}


	public List<BeAirlinesProfile> searchExistByProperty(BeAirlinesProfile profile) {
		return beAirlinesProfileQf.searchExistByProperty(profile);
	}
}
