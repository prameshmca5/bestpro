package com.bestpay.pgw.controller;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwMerchantProvider;
import com.bestpay.pgw.model.PgwTransaction;
import com.bestpay.pgw.model.RefFpxResponseCode;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.model.IpayEnquireOrderStatus;
import com.bestpay.pgw.sdk.model.RemittanceStatusDto;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.pgw.service.PgwTransactionService;
import com.bstsb.util.MediaType;


@RestController
@RequestMapping(PgwUrlConstants.IPAY_ORDER_SERVICE)
public class IpayRestController extends AbstractRestController {

	private static final Logger logger = LoggerFactory.getLogger(IpayRestController.class);
 
	@Autowired
	protected PgwTransactionService pgwTransactionService;

	 
	@GetMapping(value = PgwUrlConstants.IPAY_ORDER_ENQUIRE_STATUS, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public IpayEnquireOrderStatus getIPAYOrderStatus(@RequestParam String orderId) {

		IpayEnquireOrderStatus ipaystatus = new IpayEnquireOrderStatus();
		if (orderId != null) {
			PgwTransaction transaction = pgwTransactionService.findByMerOrderDetails(orderId);
			if (transaction != null ) {
				ipaystatus.setB4u_orderId(transaction.getOrderId());
				try {
					ipaystatus.setB4u_merchantId(transaction.getMerchantId());
					ipaystatus.setB4u_amount(transaction.getActAmt());
					ipaystatus.setB4u_currency(transaction.getActCur());
					ipaystatus.setB4u_channel(transaction.getChannel());
					ipaystatus.setB4u_orderId(transaction.getOrderId());
					ipaystatus.setB4u_tranId(transaction.getTransId());
					ipaystatus.setB4u_status(transaction.getStatus());
					ipaystatus.setB4u_bank(transaction.getBankName());
					ipaystatus.setB4u_errordesc(transaction.getResMsg());
					ipaystatus.setB4u_errorcode(transaction.getResCode());
					String payDate = null;
					String paymentDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(transaction.getPaymentDt());
					if (!BaseUtil.isObjNull(transaction.getPaymentDt())) {
						payDate = paymentDate;
					}
					ipaystatus.setB4u_txndate(payDate);
					ipaystatus.setB4u_ccName(transaction.getCcName());
					ipaystatus.setB4u_ccNo(transaction.getCcNo());
					
				} catch (Exception e) {
					ipaystatus.setB4u_errordesc("04");
					ipaystatus.setB4u_errorcode("76");
					ipaystatus.setB4u_status("Transaction Not Found");
					logger.info("IPAY ENQUIRE ORDER STATUS ISSUE {}", e.getMessage());
				}
			} else {
				ipaystatus.setB4u_errordesc("04");
				ipaystatus.setB4u_errorcode("76");
				ipaystatus.setB4u_status("Transaction Not Found");
				logger.info("IPAY ENQUIRE ORDER STATUS ISSUE....");
			}
		}
		return ipaystatus;
	}
	
	@GetMapping(value = PgwUrlConstants.IPAY_STATUS_SCHEDULER, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public String getIpayStatusByOrderId() throws Exception {
		StringBuilder sb = new StringBuilder();
		PgwMerchantProvider merchantProvider = pgwMerchantProviderService.findByMerchantBenefId("IPAYCC");
		String url = merchantProvider.getRequeryUrl();
		String merchantCode = merchantProvider.getAgentCode();
		List<PgwTransaction> transList = pgwTransactionService.findChannelAndStatusPast10days("IPAYCC", "pending");
		for(PgwTransaction transaction:transList) {
			String statusDesc = getStatusFromIpay(url,merchantCode,transaction.getOrderId(),Float.toString(transaction.getBillAmt()));
			if(!statusDesc.equals("Limited by per day maximum number of requery") ) {
				if(statusDesc.equals("00")) {
					transaction.setResMsg("Payment success");
					transaction.setStatus("success");
					transaction.setResCode("12");
				}else {
				RefFpxResponseCode refFpxResponseCode = refFpxResponseCodeService.findByMaxmoneyDesc(statusDesc);
				transaction.setResMsg(statusDesc);
				if(refFpxResponseCode!=null) {
					transaction.setResCode(refFpxResponseCode.getRespCode());
				}
				transaction.setStatus("fail");
				}
				pgwTransactionService.update(transaction);
				sb.append("Status changed for orderId: "+transaction.getOrderId());
			}
		}
		return sb.toString();
	}
	
	private String getStatusFromIpay(String url, String merchantCode, String refNo, String amount) throws Exception {
		HttpPost request = new HttpPost(url);

		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("MerchantCode", merchantCode));
		params.add(new BasicNameValuePair("RefNo", refNo));
		params.add(new BasicNameValuePair("Amount", amount));

		UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params,
				"UTF-8");
		request.setEntity(reqEntity);

		HttpClient client = HttpClientBuilder.create().build();
		HttpResponse response = client.execute(request);
		
		StringBuilder jsonString = new StringBuilder("");
		if (response.getStatusLine().getStatusCode() == 200 || response.getStatusLine().getStatusCode() == 201) {
			HttpEntity entity = response.getEntity();
			if (entity != null) {
				BufferedReader rd = new BufferedReader(
						new InputStreamReader(response.getEntity().getContent()));
				
				String line = "";
				while ((line = rd.readLine()) != null) {
					jsonString.append(line);
				}
				logger.info("{} {}",refNo,jsonString);
			}
		}
		return jsonString.toString();
	}
 
}
