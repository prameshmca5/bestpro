/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;

/**
 * @author michelle.angela
 *
 */
public class PaymentInfo implements Serializable {
	
	private static final long serialVersionUID = 4785733381239600385L;

	private Integer tvlPmtInfoId;
	
	private PaymentDtl tvlPaymentDtl;
	
	private ConfigPaymentBreakdown pmtBreakdown;
	
	private double amount;

	public Integer getTvlPmtInfoId() {
		return tvlPmtInfoId;
	}

	public void setTvlPmtInfoId(Integer tvlPmtInfoId) {
		this.tvlPmtInfoId = tvlPmtInfoId;
	}

	public PaymentDtl getTvlPaymentDtl() {
		return tvlPaymentDtl;
	}

	public void setTvlPaymentDtl(PaymentDtl tvlPaymentDtl) {
		this.tvlPaymentDtl = tvlPaymentDtl;
	}

	public ConfigPaymentBreakdown getPmtBreakdown() {
		return pmtBreakdown;
	}

	public void setPmtBreakdown(ConfigPaymentBreakdown pmtBreakdown) {
		this.pmtBreakdown = pmtBreakdown;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	
}
