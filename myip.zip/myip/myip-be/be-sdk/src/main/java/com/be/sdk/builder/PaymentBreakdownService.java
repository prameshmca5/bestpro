/**
 * 
 */
package com.be.sdk.builder;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.ConfigPaymentBreakdown;
import com.util.pagination.DataTableResults;

/**
 * @author Ramesh Pongiannan
 *
 */
public class PaymentBreakdownService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;
	
	public PaymentBreakdownService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}
	
	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}

	@Override
	public String url() {
		return url;
	}

	@SuppressWarnings("unchecked")
	public DataTableResults<ConfigPaymentBreakdown> searchPaymentBreakdownPagination(ConfigPaymentBreakdown dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENTBREAKDOWN);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}
	
	
	public ConfigPaymentBreakdown getPaymentBrkdwn(ConfigPaymentBreakdown dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.GET_DETAIL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, ConfigPaymentBreakdown.class);
	}
	
	public ConfigPaymentBreakdown addPaymentBrkdwnInfo(ConfigPaymentBreakdown dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.INFO_ADD);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, ConfigPaymentBreakdown.class);
	}
	
	public List<ConfigPaymentBreakdown> getPaymentBrkdwnList(ConfigPaymentBreakdown dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENTBREAKDOWN);
		sb.append(BeUrlConstants.GET_LIST);
		ConfigPaymentBreakdown[] objArray =  restTemplate().postForObject(getServiceURI(sb.toString()), dto, ConfigPaymentBreakdown[].class);
		return Arrays.asList(objArray);
	}
	
}
