/**
 * 
 */
package com.be.service;

import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTripAccommodationRepository;
import com.be.model.BeTripAccommodation;
import com.be.model.BeTvlTrip;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.TripAccommodation;
import com.util.BaseUtil;
import com.util.JsonUtil;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_TRIP_ACCOMMODATION_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TRIP_ACCOMMODATION_SVC)
public class BeTripAccommodationService extends AbstractService<BeTripAccommodation> {

	@Autowired
	BeTripAccommodationRepository beTripAccommodationDao;
	
	@Override
	public GenericRepository<BeTripAccommodation> primaryDao() {
		return beTripAccommodationDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public BeTripAccommodation createUpdate(TripAccommodation dto, BeTvlTrip beTvlTrip, String userId) throws IOException {
		
		BeTripAccommodation beTripAccommodation = JsonUtil.transferToObject(dto, BeTripAccommodation.class);
		if(BaseUtil.isObjNull(beTripAccommodation.getTripAccommodationId())) {
			beTripAccommodation.setTvlTrip(beTvlTrip);
			beTripAccommodation.setCreateId(userId);
		}
		beTripAccommodation.setUpdateId(userId);
		return update(beTripAccommodation);
	}

}
