package com.be.config;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.util.BaseUtil;


/**
 * @author Rajendra Veeramachineni
 * @since June 10, 2020
 */
@Component
public class HttpClientRestService {

	protected static final Logger logger = LoggerFactory.getLogger(HttpClientRestService.class);

	private X509TrustManager x509TrustManager = null;


	private HttpResponse callRestEndpoint(String basicAuth, String keystorePath, String keystorePassword, String url,
			String httpMethod, String jsonStr) throws ClientProtocolException {
		CloseableHttpResponse response = null;
		logger.info("<===========At the start of callRestEndpoint========>");
		CloseableHttpClient client = null;
		HttpPost post = null;
		HttpGet getObj = null;
		try {
			if (!BaseUtil.isObjNull(keystorePath) && !BaseUtil.isObjNull(keystorePassword)) {
				client = HttpClients.custom().setConnectionManager(handshakeSSL(keystorePath, keystorePassword))
						.build();
			} else {
				client = HttpClients.createDefault();
			}

			Header[] headers = new Header[3];
			headers[0] = new BasicHeader("Content-Type", "application/json");
			headers[1] = new BasicHeader("Authorization", basicAuth);
			headers[2] = new BasicHeader("Connection", "close");

			if (httpMethod.equals("POST")) {
				URIBuilder builder = new URIBuilder(url);
				post = new HttpPost(builder.build());
				StringEntity input = new StringEntity(jsonStr);
				post.setHeaders(headers);
				post.setEntity(input);
				response = client.execute(post);
				logger.info("<==========After client.execute(post)=========> {}", response);
			} else if (httpMethod.equals("GET")) {
				getObj = new HttpGet(url);
				getObj.setHeaders(headers);
				response = client.execute(getObj);
			}
		} catch (Exception e) {
			logger.info("Exception {}", e.getMessage());
		} finally {
			try {
				if (!BaseUtil.isObjNull(post)) {
					post.releaseConnection();
				} else if (!BaseUtil.isObjNull(getObj)) {
					getObj.releaseConnection();
				}
				client.close();
				response.close();
			} catch (IOException e) {
				logger.info("IOException {}", e.getMessage());
			}
		}
		return response;
	}


	protected PoolingHttpClientConnectionManager handshakeSSL(String keystorePath, String keystorePassword) {
		logger.info("<===========At the start of handshakeSSL()========>");
		PoolingHttpClientConnectionManager clientConnectionManager = null;
		try {
			String pathText = keystorePath;
			logger.debug("KeyStore path is===========>{} ", keystorePath);
			File file = new File(pathText);
			logger.info("KeyStore file path is===========>{} ", file.getPath());
			String password = keystorePassword;
			logger.debug("KeyStore password is===========>{} ", password);
			char[] passphrase = password.toCharArray();
			KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
			FileInputStream instream = null;
			try {
				instream = new FileInputStream(file);
				logger.debug("Before Loading KeyStore ===========>");
				keyStore.load(instream, passphrase); // path
				logger.debug("After Loading KeyStore");
			} finally {
				logger.debug("<===========Closing input stream for keystore==========>");
				instream.close();
			}
			TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			logger.debug("Before initializing TrustManagerFactory for KeyStore ===========>");
			tmf.init(keyStore);
			logger.debug("After initializing TrustManagerFactory for KeyStore ===========>");
			TrustManager[] trustManagers = tmf.getTrustManagers();
			x509TrustManager = (X509TrustManager) trustManagers[0];
			X509Certificate[] certificates = x509TrustManager.getAcceptedIssuers();
			Boolean isServerTrusted = isServerTrusted(certificates);
			logger.debug("<==========isServerTrusted========> : " + isServerTrusted);
			SSLContext sslcontext = SSLContext.getInstance("SSL");
			logger.debug("Before initializing SSLContext===========>");
			sslcontext.init(null, trustManagers, new java.security.SecureRandom());
			logger.debug("After initializing SSLContext===========>");
			SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslcontext,
					new String[] { "TLSv1.2" }, null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());
			logger.debug("Before Registry building ===========>");
			Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory> create()
					.register("http", PlainConnectionSocketFactory.getSocketFactory())
					.register("https", sslConnectionSocketFactory).build();
			logger.debug("After Registry building ===========>");
			clientConnectionManager = new PoolingHttpClientConnectionManager(registry);
			clientConnectionManager.setMaxTotal(100);
			clientConnectionManager.setDefaultMaxPerRoute(20);
		} catch (Exception e) {
			logger.debug("Error at handshakeSSL()===========>");
			e.printStackTrace();
		}
		return clientConnectionManager;
	}


	protected boolean isServerTrusted(X509Certificate[] certificates) {
		if ((certificates != null)) {
			logger.debug("Server certificate chain:");
			for (X509Certificate certificate : certificates) {
				logger.debug("Certificate public key : " + certificate.getPublicKey());
			}
		}
		if ((certificates != null) && (certificates.length == 1)) {
			X509Certificate certificate = certificates[0];
			try {
				certificate.checkValidity();
			} catch (CertificateException e) {
				logger.debug(e.toString());
				return false;
			}
			return true;
		} else {
			return false;
		}
	}


	public HttpResponse callRestGetEndPoint(String basicAuth, String keystorePath, String keystorePassword, String url)
			throws ClientProtocolException {
		return callRestEndpoint(basicAuth, keystorePath, keystorePassword, url, HttpMethod.GET.toString(), null);
	}


	public HttpResponse callRestPostEndPoint(String basicAuth, String keystorePath, String keystorePassword,
			String url, String jsonStr) throws ClientProtocolException {
		return callRestEndpoint(basicAuth, keystorePath, keystorePassword, url, HttpMethod.POST.toString(), jsonStr);
	}


	public HttpResponse callRestPostEndPoint(String basicAuth, String url, String jsonStr)
			throws ClientProtocolException {
		return callRestEndpoint(basicAuth, null, null, url, HttpMethod.POST.toString(), jsonStr);
	}

}
