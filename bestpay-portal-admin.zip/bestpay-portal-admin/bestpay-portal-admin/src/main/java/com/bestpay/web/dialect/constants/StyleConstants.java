/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dialect.constants;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class StyleConstants {

	private StyleConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String SPACE = " ";

	public static final String STYLE_FORM_CONTROL = "form-control";

	public static final String STYLE_FORM_BTN_INFO = "btn btn-info";

	public static final String STYLE_FORM_BTN_DEFAULT = "btn btn-default";

	public static final String STYLE_FORM_BTN_ERROR = "btn btn-error";

	public static final String STYLE_FORM_BTN_DANGER = "btn btn-danger";

	public static final String STYLE_FILE_UPLOAD = "fileupload";

	public static final String STYLE_ROW_FLUID = "row-fluid";

}