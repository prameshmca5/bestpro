/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.config;


import java.io.File;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.Ordered;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.MediaType;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;
import org.springframework.web.servlet.resource.GzipResourceResolver;
import org.springframework.web.servlet.resource.PathResourceResolver;
import org.springframework.web.servlet.resource.VersionResourceResolver;
import org.thymeleaf.dialect.IDialect;
import org.thymeleaf.extras.conditionalcomments.dialect.ConditionalCommentsDialect;
import org.thymeleaf.extras.springsecurity4.dialect.SpringSecurityDialect;
import org.thymeleaf.extras.tiles2.dialect.TilesDialect;
import org.thymeleaf.extras.tiles2.spring4.web.configurer.ThymeleafTilesConfigurer;
import org.thymeleaf.extras.tiles2.spring4.web.view.FlowAjaxThymeleafTilesView;
import org.thymeleaf.spring4.SpringTemplateEngine;
import org.thymeleaf.spring4.templateresolver.SpringResourceTemplateResolver;
import org.thymeleaf.spring4.view.AjaxThymeleafViewResolver;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import com.bestpay.idm.sdk.constants.BaseConstants;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.config.audit.AuditActionInterceptor;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.dialect.CustomBstDialect;
import com.bestpay.web.helper.WebHelper;


/**
 * Spring MVC Configuration
 *
 * @author Mary Jane Buenaventura
 * @since May 17, 2018
 */
@Configuration
@EnableWebMvc
@ComponentScan({ ConfigConstants.BASE_PACKAGE + ".*" })
public class WebMvcConfig extends WebMvcConfigurerAdapter {

	private static final Logger LOGGER = LoggerFactory.getLogger(WebMvcConfig.class);

	private static String propertyPath;


	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController(PageConstants.PAGE_LOGIN).setViewName("login");
		registry.addViewController(PageConstants.PAGE_ERROR).setViewName(PageTemplate.TEMP_ERROR);
		registry.addViewController(PageConstants.PAGE_ERROR_403).setViewName(PageTemplate.TEMP_ERROR_403);
		registry.setOrder(Ordered.HIGHEST_PRECEDENCE);
	}


	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**", "/scripts/**", "/images/**", "/fonts/**", "/styles/**",
				"/templates/**")
				.addResourceLocations("/resources/", "/scripts/", "/images/", "/fonts/", "/styles/", "/templates/")
				.setCachePeriod(3600).resourceChain(true).addResolver(new GzipResourceResolver())
				.addResolver(new VersionResourceResolver().addContentVersionStrategy("/**"))
				.addResolver(new PathResourceResolver());
		registry.addResourceHandler("/webjars/**").addResourceLocations("/webjars/").setCachePeriod(3600)
				.resourceChain(false);
		// Reports are created dynamically DO NOT set in cache
		registry.addResourceHandler("/report/**").addResourceLocations("/report/").resourceChain(true)
				.addResolver(new GzipResourceResolver())
				.addResolver(new VersionResourceResolver().addContentVersionStrategy("/**"))
				.addResolver(new PathResourceResolver());
	}


	@Bean
	public LocaleResolver localeResolver() {
		SessionLocaleResolver slr = new SessionLocaleResolver();
		slr.setDefaultLocale(Locale.ENGLISH);
		return slr;
	}


	@Bean
	public AuditActionInterceptor auditActionInterceptor() {
		return new AuditActionInterceptor();
	}


	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		LocaleChangeInterceptor localeChangeInterceptor = new LocaleChangeInterceptor();
		localeChangeInterceptor.setParamName("lang");
		registry.addInterceptor(localeChangeInterceptor);
		registry.addInterceptor(new SecurityInterceptor());
		registry.addInterceptor(new UnknownRequestParamInterceptor());
		registry.addInterceptor(auditActionInterceptor());
	}


	@Override
	@Description("HTTP Message Converters")
	public void configureMessageConverters(final List<HttpMessageConverter<?>> converters) {
		super.configureMessageConverters(converters);
		converters.add(new FormHttpMessageConverter());
		converters.add(new MappingJackson2HttpMessageConverter());
		converters.add(new Jaxb2RootElementHttpMessageConverter());
		converters.add(new StringHttpMessageConverter());

		ByteArrayHttpMessageConverter bam = new ByteArrayHttpMessageConverter();
		List<MediaType> mediaTypes = new LinkedList<>();
		mediaTypes.add(MediaType.IMAGE_JPEG);
		mediaTypes.add(MediaType.IMAGE_PNG);
		mediaTypes.add(MediaType.IMAGE_GIF);
		mediaTypes.add(MediaType.parseMediaType("application/pdf"));
		mediaTypes.add(MediaType.parseMediaType("application/vnd.ms-excel"));
		mediaTypes.add(MediaType.parseMediaType("application/woff"));
		mediaTypes.add(MediaType.parseMediaType("application/woff2"));
		mediaTypes.add(MediaType.parseMediaType("application/octet-stream"));
		bam.setSupportedMediaTypes(mediaTypes);
		converters.add(bam);
	}


	@Bean
	@Description("Thymeleaf Template Resolver using HTML 5")
	public ServletContextTemplateResolver templateResolver() {
		ServletContextTemplateResolver resolver = new ServletContextTemplateResolver();
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".html");
		resolver.setTemplateMode("HTML5");
		LOGGER.debug("thymleaf.template.cacheable: "
				+ messageSource().getMessage("thymleaf.template.cacheable", null, Locale.getDefault()));
		resolver.setCacheable(Boolean
				.valueOf(messageSource().getMessage("thymleaf.template.cacheable", null, Locale.getDefault())));
		return resolver;
	}


	@Bean
	@Description("Thymeleaf Template Engine with Spring Integration")
	public SpringTemplateEngine templateEngine() {
		Set<IDialect> dialects = new HashSet<>();
		dialects.add(new TilesDialect());
		dialects.add(new SpringSecurityDialect());
		dialects.add(new ConditionalCommentsDialect());
		dialects.add(new CustomBstDialect());

		SpringTemplateEngine engine = new SpringTemplateEngine();
		engine.setTemplateResolver(templateResolver());
		engine.setAdditionalDialects(dialects);
		engine.setMessageSource(messageSource());
		return engine;
	}


	@Bean
	@Description("Ajax Thymeleaf View Resolver")
	public AjaxThymeleafViewResolver tilesViewResolver() {
		AjaxThymeleafViewResolver resolver = new AjaxThymeleafViewResolver();
		resolver.setViewClass(FlowAjaxThymeleafTilesView.class);
		resolver.setTemplateEngine(templateEngine());
		resolver.setCharacterEncoding("UTF-8");
		resolver.setOrder(-1);
		return resolver;
	}


	@Bean
	@Description("Spring Resource Template")
	public SpringResourceTemplateResolver thymeleafSpringResource() {
		SpringResourceTemplateResolver resolver = new SpringResourceTemplateResolver();
		resolver.setTemplateMode("HTML5");
		return resolver;
	}


	@SuppressWarnings("deprecation")
	@Bean
	@Description("Tiles Configurer")
	public ThymeleafTilesConfigurer tilesConfigurer() {
		ThymeleafTilesConfigurer configurer = new ThymeleafTilesConfigurer();
		configurer.setDefinitions("/templates/tiles/*.xml");
		return configurer;
	}


	@Bean
	@Description("Multipart Resolver")
	public MultipartResolver filterMultipartResolver() {
		return new CommonsMultipartResolver();
	}


	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		PropertySourcesPlaceholderConfigurer ppc = new PropertySourcesPlaceholderConfigurer();
		FileSystemResource[] resources = new FileSystemResource[] {
				new FileSystemResource(getPropertyPath() + ConfigConstants.PROPERTIES_EXT) };
		ppc.setLocations(resources);
		ppc.setIgnoreUnresolvablePlaceholders(false);
		return ppc;
	}


	@Bean
	@Qualifier("messageSource")
	public MessageSource messageSource() {
		ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
		messageSource.setBasenames("classpath:messages/portal/locale", "classpath:messages/portal/message",
				"classpath:messages/app_url", ConfigConstants.FILE_PFX + getPropertyPath());
		messageSource.setUseCodeAsDefaultMessage(true);
		messageSource.setDefaultEncoding("UTF-8");
		messageSource.setCacheSeconds(1800);
		messageSource.setFallbackToSystemLocale(false);
		return messageSource;
	}


	public static String getPropertyPath() {
		if (!BaseUtil.isObjNull(propertyPath)) {
			return propertyPath;
		}
		// Get from PROJECT CONFIGURATION server
		String propertyHome = System.getProperty(ConfigConstants.PATH_PROJ_CONFIG) != null
				? System.getProperty(ConfigConstants.PATH_PROJ_CONFIG)
				: System.getenv(ConfigConstants.PATH_PROJ_CONFIG);
		LOGGER.debug("PROJECT CONFIGURATION HOME >> {}", propertyHome);
		File file = new File(propertyHome + ConfigConstants.FILE_SYS_RESOURCE);
		if (!file.exists()) {
			propertyHome = null;
		}

		// Get from TOMCAT server
		if (BaseUtil.isObjNull(propertyHome)) {
			propertyHome = System.getProperty(ConfigConstants.PATH_CATALINA_HOME) != null
					? System.getProperty(ConfigConstants.PATH_CATALINA_HOME)
					: System.getProperty(ConfigConstants.PATH_CATALINA_BASE);
			if (!BaseUtil.isObjNull(propertyHome)) {
				propertyHome = propertyHome + File.separator + "conf";
			}
			LOGGER.debug("CATALINA HOME >> {}", propertyHome);
			file = new File(propertyHome + ConfigConstants.FILE_SYS_RESOURCE);
			if (!file.exists()) {
				propertyHome = null;
			}
		}

		// Get from JBOSS server
		if (BaseUtil.isObjNull(propertyHome)) {
			propertyHome = System.getProperty(ConfigConstants.PROJ_JBOSS_HOME);
			if (!BaseUtil.isObjNull(propertyHome)) {
				propertyHome = propertyHome + File.separator + "configuration";
			}
			LOGGER.debug("JBOSS HOME >> {}", propertyHome);
			file = new File(propertyHome + ConfigConstants.FILE_SYS_RESOURCE);
			if (!file.exists()) {
				propertyHome = null;
			}
		}

		if (!BaseUtil.isObjNull(propertyHome)) {
			file = new File(propertyHome + ConfigConstants.FILE_SYS_RESOURCE);
			if (file.exists() && !file.isDirectory()) {
				propertyPath = propertyHome + File.separator + ConfigConstants.PROPERTY_FILENAME;
			} else {
				LOGGER.debug("Missing properties file >> {}{}", propertyHome, ConfigConstants.FILE_SYS_RESOURCE);
			}
		}

		// Get from Application CLASSPATH
		propertyPath = propertyPath != null ? propertyPath : ConfigConstants.PROPERTY_CLASSPATH;

		StringBuilder sb = new StringBuilder();
		sb.append(BaseConstants.NEW_LINE + BaseConstants.NEW_LINE);
		sb.append(BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("Application Properties");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("Path: " + propertyPath);
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		LOGGER.debug("Error message = {}", sb);

		return propertyPath;
	}


	@Bean
	public WebHelper webHelper() {
		return new WebHelper();
	}

}