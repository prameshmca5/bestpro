package com.bestpay.web.cmn.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.google.gson.Gson;


@Controller
@RequestMapping(value = PageConstants.DASHBOARD_MERCHANT)
public class DashboardMerchantController extends AbstractController {

	@GetMapping(value = "/{paramName}")
	public ModelAndView getTransListView(@PathVariable String paramName, HttpServletRequest request) {
		return getDefaultMav(PageTemplate.TEMP_DASH_MRCHNT_VIEW, "merchant", null, "dashboard-merchant-list-script");
	}


	@GetMapping(value = "/activeList")
	public @ResponseBody String searchPaginatedActive(HttpServletRequest request) throws BeException {
		return getSearchList("active", request);
	}


	@GetMapping(value = "/inactiveList")
	public @ResponseBody String searchPaginatedInactive(HttpServletRequest request) throws BeException {
		return getSearchList("inactive", request);
	}


	@GetMapping(value = "/newList")
	public @ResponseBody String searchPaginatedNew(HttpServletRequest request) throws BeException {
		return getSearchList("new", request);
	}


	private String getSearchList(String status, HttpServletRequest request) throws BeException {
		DataTableResults<MerAccInfo> tasks = new DataTableResults<>();
		MerAccInfo merAccInfo = new MerAccInfo();
		if (BaseUtil.isEquals(status, "active") || BaseUtil.isEquals(status, "inactive")
				|| BaseUtil.isEquals(status, "new")) {
			merAccInfo.setAcStatus(status.toUpperCase());
			tasks = getBeService().searchmerchant(merAccInfo, getPaginationRequest(request, true));
		}
		return new Gson().toJson(tasks);
	}

}
