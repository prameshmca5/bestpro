/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Afif Saman
 * @since Jul 10, 2018
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Channel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7092081913746216553L;
	private Integer channelId;
	private String publicName;
	private String privateName;
	private String type;
	private String logo;
	private String minCur;
	private Float minAmt;
	private String maxCur;
	private Float maxAmt;
	private String currency;
	private String name;
	private Integer expiryTime;

	public Integer getChannelId() {
		return channelId;
	}
	public void setChannelId(Integer channelId) {
		this.channelId = channelId;
	}
	public String getPublicName() {
		return publicName;
	}
	public void setPublicName(String publicName) {
		this.publicName = publicName;
	}
	public String getPrivateName() {
		return privateName;
	}
	public void setPrivateName(String privateName) {
		this.privateName = privateName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public String getMinCur() {
		return minCur;
	}
	public void setMinCur(String minCur) {
		this.minCur = minCur;
	}
	public Float getMinAmt() {
		return minAmt;
	}
	public void setMinAmt(Float minAmt) {
		this.minAmt = minAmt;
	}
	public String getMaxCur() {
		return maxCur;
	}
	public void setMaxCur(String maxCur) {
		this.maxCur = maxCur;
	}
	public Float getMaxAmt() {
		return maxAmt;
	}
	public void setMaxAmt(Float maxAmt) {
		this.maxAmt = maxAmt;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getExpiryTime() {
		return expiryTime;
	}
	public void setExpiryTime(Integer expiryTime) {
		this.expiryTime = expiryTime;
	}
}