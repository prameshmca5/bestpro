/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;


/**
 * @author Sridhar Kapidi
 * @since 20/11/2017
 */
@Entity
@Table(name = "REF_BANK")
public class RefBank extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -3186445980890420147L;

	@Id
	@Column(name = "BANK_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@Column(name = "BANK_NAME")
	private String bankName;

	@Column(name = "DISPLAY_NAME")
	private String displayName;

	@Column(name = "BANK_CODE")
	private String bankCode;

	@Column(name = "TYPE")
	private String type;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getDisplayName() {
		return displayName;
	}


	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}


	public String getBankCode() {
		return bankCode;
	}


	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {

		return null;
	}


	@Override
	public void setUpdateId(String updateId) {
		/*
		 * method ovverriding from super class
		 */

	}


	@Override
	public Timestamp getUpdateDt() {

		return null;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		/*
		 * method ovverriding from super class
		 */

	}

}
