/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@Entity
@Table(name = "PGW_BANK_DETAILS")
public class PgwBankDetails extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "BANK_DTL_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer bankDtlId;

	@Column(name = "MERCHANT_ID")
	private String merchantId;

	@Column(name = "BANK_ID")
	private Integer bankId;

	@Column(name = "ACCOUNT_NAME")
	private String accountName;

	@Column(name = "ACCOUNT_NUM")
	private String accountNum;

	@Column(name = "SETTLEMENT_FEE")
	private Double settlementFee;

	@Column(name = "MIN_SETTLE_AMT")
	private Double minSettleAmt;

	@Column(name = "TRANSACTION_RATE")
	private Double transactionRate;

	@Column(name = "TRANSACTION_FEE")
	private Double transactionFee;

	@Column(name = "GST_CC")
	private String gstCc;

	@Column(name = "ACC_TYPE")
	private String accTyppe;

	@Column(name = "IC_TYPE")
	private String icTyppe;

	@Column(name = "NUMBER")
	private Integer number;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getBankDtlId() {
		return bankDtlId;
	}


	public void setBankDtlId(Integer bankDtlId) {
		this.bankDtlId = bankDtlId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public Integer getBankId() {
		return bankId;
	}


	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}


	public String getAccountName() {
		return accountName;
	}


	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public String getAccountNum() {
		return accountNum;
	}


	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}


	public Double getSettlementFee() {
		return settlementFee;
	}


	public void setSettlementFee(Double settlementFee) {
		this.settlementFee = settlementFee;
	}


	public Double getMinSettleAmt() {
		return minSettleAmt;
	}


	public void setMinSettleAmt(Double minSettleAmt) {
		this.minSettleAmt = minSettleAmt;
	}


	public Double getTransactionRate() {
		return transactionRate;
	}


	public void setTransactionRate(Double transactionRate) {
		this.transactionRate = transactionRate;
	}


	public Double getTransactionFee() {
		return transactionFee;
	}


	public void setTransactionFee(Double transactionFee) {
		this.transactionFee = transactionFee;
	}


	public String getGstCc() {
		return gstCc;
	}


	public void setGstCc(String gstCc) {
		this.gstCc = gstCc;
	}


	public String getAccTyppe() {
		return accTyppe;
	}


	public void setAccTyppe(String accTyppe) {
		this.accTyppe = accTyppe;
	}


	public String getIcTyppe() {
		return icTyppe;
	}


	public void setIcTyppe(String icTyppe) {
		this.icTyppe = icTyppe;
	}


	public Integer getNumber() {
		return number;
	}


	public void setNumber(Integer number) {
		this.number = number;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}