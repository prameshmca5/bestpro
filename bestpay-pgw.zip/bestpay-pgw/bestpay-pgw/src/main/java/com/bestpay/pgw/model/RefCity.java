package com.bestpay.pgw.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;


/**
 * @author Md Asif Aftab
 * @since 27th Feb 2018
 */

@Entity
@Table(name = "REF_CITY")
public class RefCity extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = 2270425911125487517L;

	@Id
	@Column(name = "CITY_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String cityId;

	@Column(name = "CITY_CODE")
	private String cityCode;

	@Column(name = "CITY_DESC_EN")
	private String descEn;

	@Column(name = "CITY_DESC_MY")
	private String descMy;

	@Column(name = "STATE")
	private String state;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public String getCityId() {
		return cityId;
	}


	public void setCityId(String cityId) {
		this.cityId = cityId;
	}


	public String getCityCode() {
		return toUpper(cityCode);
	}


	public void setCityCode(String cityCode) {
		this.cityCode = toUpper(cityCode);
	}


	public String getDescEn() {
		return toUpper(descEn);
	}


	public void setDescEn(String descEn) {
		this.descEn = toUpper(descEn);
	}


	public String getDescMy() {
		return toUpper(descMy);
	}


	public void setDescMy(String descMy) {
		this.descMy = toUpper(descMy);
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Integer getId() {
		return null;
	}


	public void setId(Integer id) {
		/*
		 * setter method for id
		 */

	}

}
