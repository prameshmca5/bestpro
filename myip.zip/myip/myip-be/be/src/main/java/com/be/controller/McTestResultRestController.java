/**
 *
 */
package com.be.controller;


import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.model.BeTvl;
import com.be.model.BeTvlTestResult;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.McProfile;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlProfile;
import com.be.sdk.model.TvlTestResult;
import com.be.service.BeMcProfileService;
import com.be.service.BeTvlService;
import com.be.service.BeTvlTestResultService;
import com.dm.sdk.exception.DmException;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;


/**
 * @author Atiqah Khairuddin
 *
 */
@Lazy
@RestController
@RequestMapping(BeUrlConstants.MEDICAL)
public class McTestResultRestController extends AbstractRestController {

	@Autowired
	private BeTvlTestResultService beTvlTestResultServiceSvc;

	@Autowired
	BeMcProfileService mcProfileSvc;

	// @Autowired
	// RefDocumentService documentSvc;
	//
	// @Autowired
	// BeTrxnDocumentService trxnDocumentSvc;

	@Autowired
	BeTvlService tvlSvc;


	@PostMapping(value = BeUrlConstants.MEDICAL + BeUrlConstants.INFO_ADD, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public TvlTestResult updateApprovedMedicalInfo(@RequestBody TvlTestResult dto, HttpServletRequest request)
			throws IOException {

		BeTvlTestResult beTvlTestResult = null;
		try {

			if (!BaseUtil.isObjNull(dto)) {

				Tvl tvl = new Tvl();
				tvl.setTvlProfile(new TvlProfile());
				tvl.getTvlProfile().setTvlProfId(dto.getTvlProfId());
				tvl.setEmbedAcctProfile(true);
				BeTvl beTvl = tvlSvc.searchBeTravel(tvl);
				if (BaseUtil.isObjNull(beTvl)) {
					throw new BeException(BeErrorCodeEnum.I404C001);
				}

				if (BaseUtil.isObjNull(dto.getCntryCd()) && !BaseUtil.isObjNull(dto.getMcProfId())) {
					McProfile mcProfile = new McProfile();
					mcProfile.setMcProfId(dto.getMcProfId());
					mcProfile.setEmbedAddresses(true);
					mcProfile = mcProfileSvc.searchMcProfile(mcProfile);
					if (!BaseUtil.isObjNull(mcProfile) && !BaseUtil.isListNull(mcProfile.getMcAddresses())) {
						dto.setCntryCd(mcProfile.getMcAddresses().get(0).getCountry().getCntryCd());
					}
				}

				beTvlTestResult = beTvlTestResultServiceSvc.updateApprovedMedicalInfo(dto, beTvl.getTvlProfile(),
						getCurrUserId(request), request);

				if (!BaseUtil.isObjNull(dto.getDoctorProfId())) {
					beTvlTestResultServiceSvc.processDocumentAndNotification(beTvlTestResult, beTvl, request);
				}
			}
		} catch (DmException e) {
			throw new BeException(BeErrorCodeEnum.E500C010);
		} catch (Exception e) {
			if (BaseUtil.isObjNull(beTvlTestResult)) {
				throw new BeException(BeErrorCodeEnum.E500C001);
			} else {
				throw new BeException(e.getMessage());
			}
		}
		return JsonUtil.transferToObject(beTvlTestResult, TvlTestResult.class);
	}

}
