package com.bestpay.pgw.controller;


import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwMerchantProvider;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.model.Provider;
import com.bestpay.pgw.sdk.util.BaseUtil;



/**
 * @author Atiqah Khairuddin
 * @since March 28, 2019
 */
@RestController
@RequestMapping(PgwUrlConstants.PROVIDER)
public class PgwProviderRestController extends AbstractRestController {
	
	@GetMapping(value = "/{providerName}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public Provider findByProviderId(@PathVariable String providerName) {

		PgwMerchantProvider pgwMerchantProvider = super.pgwMerchantProviderService.findByMerchantBenefId(providerName);
		Provider provider = new Provider();
		if (!BaseUtil.isObjNull(pgwMerchantProvider)) {
			provider = dozerMapper.map(pgwMerchantProvider, Provider.class);
		}
		return provider;
	}

	 
	 
}
