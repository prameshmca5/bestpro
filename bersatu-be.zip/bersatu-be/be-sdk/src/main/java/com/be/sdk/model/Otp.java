package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author mohd.naem
 *
 */
public class Otp implements Serializable {

	private Timestamp transDt;

	private String transId;

	private String otp;

	private String contactNo;


	public Timestamp getTransDt() {
		return transDt;
	}


	public void setTransDt(Timestamp transDt) {
		this.transDt = transDt;
	}


	public String getTransId() {
		return transId;
	}


	public void setTransId(String transId) {
		this.transId = transId;
	}


	public String getOtp() {
		return otp;
	}


	public void setOtp(String otp) {
		this.otp = otp;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

}
