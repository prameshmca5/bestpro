/**
 * Copyright 2019
 */
package com.be.constants;


import java.io.File;

import com.util.constants.BaseConfigConstants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 17, 2018
 */
public class ConfigConstants {

	private ConfigConstants() {
		throw new IllegalStateException(ConfigConstants.class.getName());
	}


	public static final String BASE_PACKAGE = "com.be";

	public static final String BASE_PACKAGE_REPO = BASE_PACKAGE + ".dao";

	public static final String BASE_PACKAGE_MODEL = BASE_PACKAGE + ".model";

	public static final String BASE_PACKAGE_CONTROLLER = BASE_PACKAGE + ".controller";

	public static final String CACHE_JAVA_FILE = "T(" + BASE_PACKAGE + ".sdk.constants.BeCacheConstants)";

	public static final String PATH_PROJ_CONFIG = "bersatu.config.path";

	public static final String PROPERTY_FILENAME = "bersatu-be";

	public static final String SVC_BE_URL = "be.service.url";

	public static final String SVC_BE_TIMEOUT = "be.service.timeout";

	public static final String FILE_SYS_RESOURCE = File.separator + PROPERTY_FILENAME
			+ BaseConfigConstants.PROPERTIES_EXT;

	public static final String SYSTEM = "system";

	public static final String CONFIG_OTP_VALIDITY = "CONFIG_OTP_VALIDITY";

	public static final String PAYMENT_BATCH_ID = "PAYMENT_BATCH_ID";

	public static final String PORTAL_APP_URL = "portal.app.url";

	public static final String MERCHANT_ID = "MERCHANT_ID";

	public static final String MERCHANT_SECRET = "MERCHANT_SECRET";

	public static final String CC = "CC";

	public static final String PATH_REDIRECT_MOBILE = "/newPayment/redirectMobile";

	public static final String KIPLE_APP_URL = "kiple.app.url";

	public static final String ELECTION_MIN_AGE = "ELECTION_MIN_AGE";

	public static final String HQ = "HQ";

	public static final String STATE = "STATE";

	public static final String DIV = "DIV";

	public static final String CONFIG_CONTACT_NO = "CONFIG_CONTACT_NO";
	
	public static final String HASH_SECRET_KEY = "HASH_SECRET_KEY";
	
	public static final String SENANGPAY_APP_URL = "senangpay.app.url";
	
	public static final String PATH_SENAG_REDIRECT_MOBILE = "/newPayment/senangpayResponds";
	
	public static final String SMS_MAX_TEXT_LENGTH = "SMS_MAX_TEXT_LENGTH";
	
	public static final String HQ_APPROVE_DAY_01 = "HQ_APPROVE_DAY_01";
	
	public static final String DIV_VERIFY_DAY_01 = "DIV_VERIFY_DAY_01";
	
	public static final String DIV_VERIFY_DAY_02 = "DIV_VERIFY_DAY_02";
	
	public static final String DIV_VERIFY_DAY_03 = "DIV_VERIFY_DAY_03";
	
	public static final String SENANGPAY_MERCHANT_ID = "SENANGPAY_MERCHANT_ID";
	
	public static final String SENANGPAY_SECRET = "SENANGPAY_SECRET";
	
	public static final String SENANGPAY_ENQUERY_URL = "SENANGPAY_ENQUERY_URL";
	
	public static final String SENGPAY_ENQUIRY_BUFFER_TIME = "SENGPAY_ENQUIRY_BUFFER_TIME";
	
}