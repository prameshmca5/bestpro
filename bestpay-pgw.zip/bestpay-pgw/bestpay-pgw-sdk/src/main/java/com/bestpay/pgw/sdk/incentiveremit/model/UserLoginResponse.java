
package com.bestpay.pgw.sdk.incentiveremit.model;


import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "userLoginResponse", namespace = "iRemitWebservice")
public class UserLoginResponse {

	@XmlElement(name = "userLoginResult", namespace = "iRemitWebservice")
	private UserLoginResult userLoginResult;


	public UserLoginResult getUserLoginResult() {
		return userLoginResult;
	}


	public void setUserLoginResult(UserLoginResult userLoginResult) {
		this.userLoginResult = userLoginResult;
	}

}
