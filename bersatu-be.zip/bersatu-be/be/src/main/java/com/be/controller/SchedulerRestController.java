package com.be.controller;


import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.be.constants.ConfigConstants;
import com.be.constants.CryptoChangePwdSms;
import com.be.core.AbstractRestController;
import com.be.model.BeConfig;
import com.be.model.BeElectionNot;
import com.be.model.BeMemberAddress;
import com.be.model.BeMemberProfile;
import com.be.model.BePayment;
import com.be.model.BePaymentGateway;
import com.be.model.BePreReg;
import com.be.model.RefBranch;
import com.be.model.RefDivision;
import com.be.model.RefDocument;
import com.be.model.RefMetadata;
import com.be.model.RefState;
import com.be.model.RefStatus;
import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.constants.MailTemplateConstants;
import com.be.sdk.constants.ReferenceConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.Config;
import com.be.sdk.model.ElectionNot;
import com.be.sdk.model.ElectionNotDtl;
import com.be.sdk.model.MemberProfile;
import com.be.sdk.model.Payment;
import com.be.sdk.model.PaymentDtl;
import com.be.sdk.model.PreReg;
import com.be.sdk.model.SenangPayResponds;
import com.be.sdk.model.Status;
import com.be.service.BeConfigService;
import com.be.service.BeElectionNotDtlService;
import com.be.service.BeElectionNotService;
import com.be.service.BeMemberProfileService;
import com.be.service.BePaymentDtlService;
import com.be.service.BePaymentService;
import com.be.service.BePreRegService;
import com.be.service.RefBranchService;
import com.be.service.RefDivisionService;
import com.be.service.RefMetadataService;
import com.be.service.RefStateService;
import com.be.service.RefStatusService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.idm.sdk.constants.IdmRoleConstants;
import com.idm.sdk.model.UserGroupBranch;
import com.idm.sdk.model.UserProfile;
import com.mashape.unirest.http.options.Option;
import com.notify.sdk.constants.MailTypeEnum;
import com.notify.sdk.model.Notification;
import com.notify.sdk.util.MailUtil;
import com.report.sdk.constants.ReportTypeEnum;
import com.report.sdk.constants.ReportUrlConstants;
import com.report.sdk.model.Report;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.JsonUtil;
import com.util.MediaType;
import com.util.UidGenerator;


@RestController
@RequestMapping(BeUrlConstants.SCHEDULER)
public class SchedulerRestController extends AbstractRestController {

	@Autowired
	BeMemberProfileService beMemberProfileSvc;

	@Autowired
	RefStatusService refStatusSvc;

	@Autowired
	RefDivisionService refDivisionSvc;

	@Autowired
	RefBranchService refBranchSvc;

	@Autowired
	RefMetadataService refMetadataSvc;

	@Autowired
	BeElectionNotService beElectionNotSvc;

	@Autowired
	BeElectionNotDtlService beElectionNotDtlSvc;

	@Autowired
	BeConfigService beConfigSvc;

	@Autowired
	BePreRegService bePreRegSvc;

	@Autowired
	RefStateService refStateSvc;
	
	@Autowired
	private BePaymentService bePaymentSvc;
	
	@Autowired
	private BePaymentDtlService bePaymentDtlSvc;
	
	private BeRestTemplate restTemplate;


	@GetMapping(value = BeUrlConstants.MEMBER_CREDENTIAL, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public BeException createMemberCredential(HttpServletRequest request) throws IOException {
		String userId = getCurrUserId(request);

		MemberProfile memberProfile = new MemberProfile();
		memberProfile.setCredentialInd(0);

		List<BeMemberProfile> beMemberProfileList = beMemberProfileSvc.searchList(memberProfile);
		if (BaseUtil.isListNull(beMemberProfileList)) {
			return new BeException(BeErrorCodeEnum.I404C001);
		}

		beMemberProfileList.forEach(beMemberProfile -> {
			Timestamp currDt = DateUtil.getSQLTimestamp();
			beMemberProfile.setCredentialInd(2);
			beMemberProfile.setUpdateId(userId);
			beMemberProfile.setUpdateDt(currDt);
		});
		beMemberProfileSvc.updateAll(beMemberProfileList);

		beMemberProfileList.forEach(beMemberProfile -> {
			Timestamp currDt = DateUtil.getSQLTimestamp();
			try {
				String activationCode = UidGenerator.generateRandomNoInStr();
				UserProfile up = new UserProfile();
				up.setUserId(beMemberProfile.getIdNo());
				up.setProfId(beMemberProfile.getMemberId());
				up.setFirstName(beMemberProfile.getFullName());
				up.setNationalId(beMemberProfile.getIdNo());
				up.setEmail(beMemberProfile.getEmail());
				if (!BaseUtil.isObjNull(beMemberProfile.getGenderMtdtId())) {
					RefMetadata mtdtGender = refMetadataSvc.find(beMemberProfile.getGenderMtdtId());
					if (!BaseUtil.isObjNull(mtdtGender)) {
						up.setGender(mtdtGender.getMtdtCd());
					}

				}

				up.setContactNo(beMemberProfile.getContactNo());
				up.setUserRoleGroupCode(IdmRoleConstants.NORMAL_USER);
				up.setActivationCode(activationCode);
				up.setPassword(activationCode);

				UserGroupBranch userGroupBranch = new UserGroupBranch();
				userGroupBranch.setCityCd(beMemberProfile.getOrgDivisionCd());
				userGroupBranch.setStateCd(beMemberProfile.getOrgStateCd());
				List<UserGroupBranch> ugList = getIdmService(request).searchUserGroupBranch(userGroupBranch);
				if (!BaseUtil.isListNull(ugList)) {
					UserGroupBranch ug = ugList.get(0);
					up.setUserGroupRoleBranchCd(ug.getBranchCode());
					up.setUserGroupRoleBranchCode(ug.getBranchCode());
					up.setBranchId(ug.getBranchId());
					up.setCntryCd(ug.getStateCd());
				}

				up = getIdmService(request).createUser(up, true, true, false, false);
				if (!BaseUtil.isObjNull(up)) {
					RefStatus refStatus = refStatusSvc.find(beMemberProfile.getStatusId());
					String statusDesc = refStatus.getStatusDesc();
					String encrp = "passcode=" + activationCode;
					// BeConfig beConfig =
					// beConfigSvc.findByConfigCode(ConfigConstants.HASH_SECRET_KEY);
					String url = messageService.getMessage(ConfigConstants.PORTAL_APP_URL) + "/change-password/"
							+ CryptoChangePwdSms.urlStringPasscodeEncryption(encrp);

					// sms
					if (!BaseUtil.isObjNull(beMemberProfile.getContactNo())) {
						// MEMBER_REG_RESULT
						Map<String, Object> map = new HashMap<>();
						map.put("statusDesc", statusDesc);

						Notification notification = new Notification();
						notification.setNotifyTo(beMemberProfile.getContactNo());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setNotifyType(MailTypeEnum.SMS.getType());
						notification.setContent(beMemberProfile.getCreateId());
						getNotifyService(request).addNotification(notification,
								MailTemplateConstants.MEMBER_REG_RESULT_SMS);

						// MEMBER_SET_PWD
						map = new HashMap<>();
						map.put("url", url);

						notification = new Notification();
						notification.setNotifyTo(beMemberProfile.getContactNo());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setNotifyType(MailTypeEnum.SMS.getType());
						notification.setContent(beMemberProfile.getCreateId());
						getNotifyService(request).addNotification(notification,
								MailTemplateConstants.MEMBER_SET_PWD_SMS);
					}

					// email
					if (!BaseUtil.isObjNull(beMemberProfile.getEmail())) {
						// MEMBER_REG_RESULT
						Map<String, Object> map = new HashMap<>();
						map.put("statusDesc", statusDesc);
						map.put("fullName", beMemberProfile.getFullName());
						map.put("idNo", beMemberProfile.getIdNo());
						map.put("memberRefNo", beMemberProfile.getMemberNo().toUpperCase());

						RefDivision refDivision = refDivisionSvc
								.findByDivisionCd(beMemberProfile.getOrgDivisionCd());
						if (!BaseUtil.isObjNull(refDivision)) {
							map.put("divisionDesc", refDivision.getDivisionDesc());
						}

						RefBranch refBranch = refBranchSvc.findByBranchCd(beMemberProfile.getOrgBranchCd());
						if (!BaseUtil.isObjNull(refBranch)) {
							map.put("branchDesc", refBranch.getBranchDesc());
						}

						Notification notification = new Notification();
						notification.setNotifyTo(beMemberProfile.getEmail());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setNotifyType(MailTypeEnum.MAIL.getType());
						notification.setContent(beMemberProfile.getCreateId());
						getNotifyService(request).addNotification(notification,
								MailTemplateConstants.MEMBER_REG_RESULT_EMAIL);

						// MEMBER_SET_PWD
						map = new HashMap<>();
						map.put("url", url);
						notification = new Notification();
						notification.setNotifyTo(beMemberProfile.getEmail());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setNotifyType(MailTypeEnum.MAIL.getType());
						notification.setContent(beMemberProfile.getCreateId());
						getNotifyService(request).addNotification(notification,
								MailTemplateConstants.MEMBER_SET_PWD_EMAIL);
					}

					// fcm
					// MEMBER_REG_RESULT
					Map<String, Object> map = new HashMap<>();
					map.put("statusDesc", statusDesc);
					sendFcmNotification(beMemberProfile.getIdNo(), beMemberProfile.getCreateId(), map,
							MailTemplateConstants.MEMBER_REG_RESULT_FCM, request);

					// MEMBER_SET_PWD
					map = new HashMap<>();
					map.put("url", url);
					sendFcmNotification(beMemberProfile.getIdNo(), beMemberProfile.getCreateId(), map,
							MailTemplateConstants.MEMBER_SET_PWD_FCM, request);

					beMemberProfile.setCredentialInd(1);
				} else {
					beMemberProfile.setCredentialInd(0);
				}
			} catch (Exception e) {
				beMemberProfile.setCredentialInd(0);
			}

			beMemberProfile.setUpdateId(userId);
			beMemberProfile.setUpdateDt(currDt);
		});

		beMemberProfileSvc.updateAll(beMemberProfileList);

		return new BeException(BeErrorCodeEnum.E200C000);
	}


	@SuppressWarnings("unchecked")
	@GetMapping(value = BeUrlConstants.ELECTION_NOTIFICATION, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public BeException electionNotification(HttpServletRequest request) throws IOException {
		String userId = getCurrUserId(request);

		ElectionNot electionNot = new ElectionNot();
		electionNot.setNotifyInd(0);

		List<ElectionNot> electionNotList = beElectionNotSvc.searchPagination(electionNot, null);

		if (BaseUtil.isListNull(electionNotList)) {
			return new BeException(BeErrorCodeEnum.I404C001);
		}

		List<BeElectionNot> beElectionNotList = JsonUtil.transferToList(electionNotList, BeElectionNot.class);

		beElectionNotList.forEach(beElectionNot -> {
			Timestamp currDt = DateUtil.getSQLTimestamp();
			beElectionNot.setNotifyInd(2);
			beElectionNot.setUpdateId(userId);
			beElectionNot.setUpdateDt(currDt);
		});
		beElectionNotSvc.updateAll(beElectionNotList);

		beElectionNotList.forEach(beElectionNot -> {
			ElectionNotDtl electionNotDtl = new ElectionNotDtl();
			electionNotDtl.setElectionNotId(beElectionNot.getElectionNotId());

			try {
				List<ElectionNotDtl> electionNotDtlList = beElectionNotDtlSvc.searchPagination(electionNotDtl,
						null);

				if (!BaseUtil.isListNull(electionNotDtlList)) {
					List<ElectionNotDtl> electionNotDtls = new ArrayList<>();

					for (ElectionNotDtl election : electionNotDtlList) {

						UserProfile userProfile = getIdmService(request)
								.getUserProfileById(election.getCreateId(), false, false);

						if (!BaseUtil.isObjNull(userProfile)) {
							LOGGER.info(">>>>>>> USER TYPE >>>>>>>>>> "
									+ userProfile.getUserType().getUserTypeCode());
							if (userProfile.getUserType().getUserTypeCode().equals(ConfigConstants.HQ)
									|| userProfile.getUserType().getUserTypeCode()
											.equals(ConfigConstants.STATE)) {
								electionNotDtls.add(election);
							}
						}

					}

					if (!BaseUtil.isListNull(electionNotDtls)) {
						Map<String, Long> countByDiv = electionNotDtls.stream().collect(
								Collectors.groupingBy(ElectionNotDtl::getOrgDivisionCd, Collectors.counting()));

						countByDiv.forEach((k, v) -> {

							UserGroupBranch userGroupBranch = new UserGroupBranch();
							userGroupBranch.setCityCd(k);

							List<UserGroupBranch> userGroupBranchList = getIdmService(request)
									.searchUserGroupBranch(userGroupBranch);

							if (!BaseUtil.isListNull(userGroupBranchList)) {
								UserGroupBranch usrGroupBranch = userGroupBranchList.get(0);

								List<MemberProfile> memberProfileDtoList = new ArrayList<>();

								RefMetadata refMtdt = new RefMetadata();
								refMtdt.setMtdtType("VOTER_REG");
								List<RefMetadata> metaVoters = refMetadataSvc.findMetadataByCriteria(refMtdt);
								List<Integer> metaVotersIds = metaVoters.stream().filter((meta) -> {
									return meta.getMtdtCd().contains("VOTE_N")
											|| meta.getMtdtCd().contains("VOTE_NS");
								}).map((meta) -> meta.getMtdtId()).collect(Collectors.toList());

								MemberProfile memberProfile = new MemberProfile();
								memberProfile.setVoterRegMtdtIdList(metaVotersIds);
								memberProfile.setOrgDivisionCd(k);

								try {
									List<BeMemberProfile> beMemberProfileList = beMemberProfileSvc
											.searchList(memberProfile);
									if (!BaseUtil.isListNull(beMemberProfileList)) {
										beMemberProfileList.forEach(memProf -> {
											MemberProfile memberProf = new MemberProfile();

											memberProf.setMemberNo(memProf.getMemberNo());
											memberProf.setFullName(memProf.getFullName());
											memberProf.setContactNo(memProf.getContactNo());

											memberProfileDtoList.add(memberProf);
										});
									}
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}

								UserProfile userProfile = new UserProfile();
								userProfile.setBranchId(usrGroupBranch.getBranchId());
								userProfile.setUserRoleGroupCode(IdmRoleConstants.DIV_ADMIN);

								List<UserProfile> userProfileList = new ArrayList<>();
								try {
									userProfileList = getIdmService(request).searchUserProfile(userProfile);
								} catch (Exception e) {

								}

								if (!BaseUtil.isListNull(userProfileList)) {
									userProfileList.forEach(usrProfile -> {
										BeConfig beConfig = beConfigSvc
												.findByConfigCode(ConfigConstants.ELECTION_MIN_AGE);
										if (BaseUtil.isObjNull(beConfig)) {
											throw new BeException(BeErrorCodeEnum.E500C001);
										}
										// sms
										if (!BaseUtil.isObjNull(usrProfile.getContactNo())) {
											// MEMBER_ELECTION_LIST
											Map<String, Object> map = new HashMap<>();
											map.put("count", v);
											map.put("age", beConfig.getConfigVal());

											Notification notification = new Notification();
											notification.setNotifyTo(usrProfile.getContactNo());
											notification.setMetaData(MailUtil.convertMapToJson(map));
											notification.setNotifyType(MailTypeEnum.SMS.getType());
											notification.setContent(beElectionNot.getCreateId());
											getNotifyService(request).addNotification(notification,
													MailTemplateConstants.MEMBER_ELECTION_LIST_SMS);

										}

										// email
										if (!BaseUtil.isObjNull(usrProfile.getEmail())) {
											// MEMBER_ELECTION_LIST
											Report report = null;
											RefDocument doc = new RefDocument();
											doc.setDocDesc("SENARAI AHLI");
											doc.setType(ReportTypeEnum.PDF.getMimeType());
											try {
												electionNotDtl.setOrgDivisionCd(k);
												report = getReportService(request).report()
														.genElectListNotRgster(electionNotDtl,
																ReportTypeEnum.PDF);

											} catch (Exception e) {
												beElectionNot.setNotifyInd(0);
											}
											Map<String, Object> map = new HashMap<>();
											map.put("age", beConfig.getConfigVal());
											map.put("memberProfileList", memberProfileDtoList);

											Notification notification = new Notification();
											notification.setNotifyTo(usrProfile.getEmail());
											notification.setMetaData(MailUtil.convertMapToJson(map));
											notification.setNotifyType(MailTypeEnum.MAIL.getType());
											notification.setContent(beElectionNot.getCreateId());
											if (!BaseUtil.isObjNull(report)) {
												notification.setAttachments(new ArrayList<>());
												notification.getAttachments()
														.add(setNotificationAttachments(report, doc));
											}
											getNotifyService(request).addNotification(notification,
													MailTemplateConstants.MEMBER_ELECTION_LIST_EMAIL);

										}

										// fcm
										// MEMBER_ELECTION_LIST
										Map<String, Object> map = new HashMap<>();
										map.put("count", v);
										map.put("age", beConfig.getConfigVal());
										sendFcmNotification(usrProfile.getNationalId(),
												beElectionNot.getCreateId(), map,
												MailTemplateConstants.MEMBER_ELECTION_LIST_FCM, request);
									});
								}
							}
						});
						beElectionNot.setNotifyInd(1);
					} else {
						beElectionNot.setNotifyInd(0);
					}

				}

			} catch (IOException e) {
				beElectionNot.setNotifyInd(0);
			}

		});

		beElectionNotSvc.updateAll(beElectionNotList);

		return new BeException(BeErrorCodeEnum.E200C000);
	}


	@SuppressWarnings("unchecked")
	@GetMapping(value = BeUrlConstants.ELECTION_NOTIFICATION
			+ BeUrlConstants.ELECTION_NOTIFICATION_DIV, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public BeException electionNotificationDiv(HttpServletRequest request) throws IOException {
		String userId = getCurrUserId(request);

		ElectionNot electionNot = new ElectionNot();
		electionNot.setNotifyInd(0);

		List<ElectionNot> electionNotList = beElectionNotSvc.searchPagination(electionNot, null);

		if (BaseUtil.isListNull(electionNotList)) {
			return new BeException(BeErrorCodeEnum.I404C001);
		}

		List<BeElectionNot> beElectionNotList = JsonUtil.transferToList(electionNotList, BeElectionNot.class);

		beElectionNotList.forEach(beElectionNot -> {
			Timestamp currDt = DateUtil.getSQLTimestamp();
			beElectionNot.setNotifyInd(2);
			beElectionNot.setUpdateId(userId);
			beElectionNot.setUpdateDt(currDt);
		});
		beElectionNotSvc.updateAll(beElectionNotList);

		beElectionNotList.forEach(beElectionNot -> {
			ElectionNotDtl electionNotDtl = new ElectionNotDtl();
			electionNotDtl.setElectionNotId(beElectionNot.getElectionNotId());
			electionNotDtl.setOrgDivisionCd(beElectionNot.getOrgDivisionCd());

			try {
				List<ElectionNotDtl> electionNotDtlList = beElectionNotDtlSvc.searchPagination(electionNotDtl,
						null);

				if (!BaseUtil.isListNull(electionNotDtlList)) {
					List<ElectionNotDtl> electionNotDtls = new ArrayList<>();

					for (ElectionNotDtl election : electionNotDtlList) {

						UserProfile userProfile = getIdmService(request)
								.getUserProfileById(election.getCreateId(), false, false);

						if (!BaseUtil.isObjNull(userProfile)) {
							LOGGER.info(">>>>>>> USER TYPE >>>>>>>>>> "
									+ userProfile.getUserType().getUserTypeCode());
							if (userProfile.getUserType().getUserTypeCode().equals(ConfigConstants.DIV)) {
								electionNotDtls.add(election);
							}
						}
					}

					if (!BaseUtil.isListNull(electionNotDtlList)) {
						for (ElectionNotDtl electionDtl : electionNotDtlList) {
							MemberProfile memberProfile = new MemberProfile();
							memberProfile.setMemberId(electionDtl.getMemberId());
							memberProfile.setOrgDivisionCd(electionDtl.getOrgDivisionCd());

							MemberProfile memberPro = beMemberProfileSvc.search(memberProfile);
							LOGGER.info("preRegForm DTO{} " + new Gson().toJson(memberPro));

							// sms
							if (!BaseUtil.isObjNull(memberPro.getContactNo())) {
								// MEMBER_ELECTION_LIST
								Map<String, Object> map = new HashMap<>();

								Notification notification = new Notification();
								notification.setNotifyTo(memberPro.getContactNo());
								notification.setMetaData(MailUtil.convertMapToJson(map));
								notification.setNotifyType(MailTypeEnum.SMS.getType());
								notification.setContent(beElectionNot.getCreateId());
								getNotifyService(request).addNotification(notification,
										MailTemplateConstants.DIV_MEMBER_ELECTION_LIST_SMS);
							}

							// email
							if (!BaseUtil.isObjNull(memberPro.getEmail())) {
								// MEMBER_ELECTION_LIST
								UserGroupBranch userGroupBranch = new UserGroupBranch();
								userGroupBranch.setCityCd(memberPro.getOrgDivisionCd());

								List<UserGroupBranch> userGroupBranchList = getIdmService(request)
										.searchUserGroupBranch(userGroupBranch);
								if (!BaseUtil.isListNull(userGroupBranchList)) {
									UserGroupBranch usrGroupBranch = userGroupBranchList.get(0);

									Map<String, Object> map = new HashMap<>();
									map.put("fullName", memberPro.getFullName());
									map.put("division", usrGroupBranch.getBranchName());

									Notification notification = new Notification();
									notification.setNotifyTo(memberPro.getEmail());
									notification.setMetaData(MailUtil.convertMapToJson(map));
									notification.setNotifyType(MailTypeEnum.MAIL.getType());
									notification.setContent(beElectionNot.getCreateId());

									getNotifyService(request).addNotification(notification,
											MailTemplateConstants.DIV_MEMBER_ELECTION_LIST_EMAIL);
								}
							}

							// fcm
							// MEMBER_ELECTION_LIST
							Map<String, Object> map = new HashMap<>();
							sendFcmNotification(electionDtl.getCreateId(), beElectionNot.getCreateId(), map,
									MailTemplateConstants.DIV_MEMBER_ELECTION_LIST_FCM, request);
						}

						beElectionNot.setNotifyInd(1);
					} else {
						beElectionNot.setNotifyInd(0);
					}
				}
			} catch (IOException e) {
				beElectionNot.setNotifyInd(0);
			}

		});

		beElectionNotSvc.updateAll(beElectionNotList);

		return new BeException(BeErrorCodeEnum.E200C000);
	}


	@SuppressWarnings("unchecked")
	@GetMapping(value = BeUrlConstants.CONFIRMATION_EMAIL_REMINDER_DIV, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public BeException confirmationEmailReminderDiv(HttpServletRequest request) throws IOException, ParseException {

		Status status = new Status();
		status.setStatusId(2);

		PreReg preRegDto = new PreReg();
		preRegDto.setStatusId(2);
		// preRegDto.setOrgDivisionCd("B201");

		List<PreReg> preRegList = bePreRegSvc.searchList(preRegDto);

		if (BaseUtil.isListNull(preRegList)) {
			return new BeException(BeErrorCodeEnum.I404C001);
		}

		try {
			if (!BaseUtil.isListNull(preRegList)) {
				Map<String, Long> countByDiv = preRegList.stream()
						.collect(Collectors.groupingBy(PreReg::getOrgDivisionCd, Collectors.counting()));
				LOGGER.debug("days", countByDiv);

				countByDiv.forEach((k, v) -> {

					UserGroupBranch userGroupBranch = new UserGroupBranch();
					userGroupBranch.setCityCd(k);

					List<UserGroupBranch> userGroupBranchList = getIdmService(request)
							.searchUserGroupBranch(userGroupBranch);

					List<PreReg> regDtoList = new ArrayList<>();

					if (!BaseUtil.isListNull(userGroupBranchList)) {
						Map<String, Object> map = new HashMap<>();
						preRegDto.setOrgDivisionCd(k);

						List<PreReg> preRegisList = bePreRegSvc.searchList(preRegDto);
						preRegisList.forEach(preReg -> {
							PreReg reg = new PreReg();

							reg.setFullName(preReg.getFullName());
							reg.setIdNo(preReg.getIdNo());
							reg.setContactNo(preReg.getContactNo());
							reg.setOrgStateCd(
									refStateSvc.findByStateCode(preReg.getOrgStateCd()).getStateDesc());

							Date secondDate = DateUtil.convertTimestampToDate(preReg.getApplyDt());
							Date firstDate = new Date();

							long diffInMillies = Math.abs(secondDate.getTime() - firstDate.getTime());
							long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
							reg.setDays(diff);

							LOGGER.info("days: {} + applyDate: {} + applyBy: {}", diff, preReg.getApplyDt(),
									preReg.getApplyBy());
							
							BeConfig beConfig = beConfigSvc
									.findByConfigCode(ConfigConstants.DIV_VERIFY_DAY_01);
							if (BaseUtil.isObjNull(beConfig)) {
								throw new BeException(BeErrorCodeEnum.E500C004);
							}
							
							BeConfig beConfig2 = beConfigSvc
									.findByConfigCode(ConfigConstants.DIV_VERIFY_DAY_02);
							if (BaseUtil.isObjNull(beConfig2)) {
								throw new BeException(BeErrorCodeEnum.E500C004);
							}
							
							BeConfig beConfig3 = beConfigSvc
									.findByConfigCode(ConfigConstants.DIV_VERIFY_DAY_03);
							if (BaseUtil.isObjNull(beConfig3)) {
								throw new BeException(BeErrorCodeEnum.E500C004);
							}
							
							String countDays1 = beConfig.getConfigVal();
							Long day1 = Long.valueOf(countDays1);
							
							String countDays2 = beConfig2.getConfigVal();
							Long day2 = Long.valueOf(countDays2);
							
							String countDays3 = beConfig3.getConfigVal();
							Long day3 = Long.valueOf(countDays3);
							
							if (diff == day1 || diff == day2 || diff == day3) {
								regDtoList.add(reg);
							}
						});

						LOGGER.info("preRegList: {}" + new Gson().toJson(regDtoList));

						UserGroupBranch usrGroupBranch = userGroupBranchList.get(0);
						UserProfile userProfile = new UserProfile();
						userProfile.setBranchId(usrGroupBranch.getBranchId());
						userProfile.setUserRoleGroupCode(IdmRoleConstants.DIV_ADMIN);

						List<UserProfile> userProfileList = new ArrayList<>();

						try {
							userProfileList = getIdmService(request).searchUserProfile(userProfile);
						} catch (Exception e) {

						}

						if (!BaseUtil.isListNull(userProfileList)) {
							userProfileList.forEach(usrProfile -> {
								LOGGER.info("email: {}", usrProfile.getEmail());

								if (!BaseUtil.isListNull(regDtoList)) {
									map.put("preRegList", regDtoList);

									if (!BaseUtil.isObjNull(usrProfile.getEmail())) {
										Notification notification = new Notification();

										notification.setNotifyTo(usrProfile.getEmail());
										notification.setMetaData(MailUtil.convertMapToJson(map));
										notification.setNotifyType(MailTypeEnum.MAIL.getType());
										notification.setContent(usrProfile.getUserId());
										getNotifyService(request).addNotification(notification,
												MailTemplateConstants.DIV_REMINDER_REGISTRATION_APPROVAL);
									}
								}
							});
						}
					}
				});
			}

		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E400C004);
		}

		return new BeException(BeErrorCodeEnum.E200C000);
	}


	@SuppressWarnings("unchecked")
	@GetMapping(value = BeUrlConstants.CONFIRMATION_EMAIL_REMINDER_HQ, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public BeException confirmationEmailReminderHq(HttpServletRequest request) throws IOException, ParseException {

		getCurrUserId(request);
		DateUtil.getSQLTimestamp();

		Status status = new Status();
		status.setStatusId(2);

		PreReg preRegDto = new PreReg();
		preRegDto.setStatusId(2);
		// preRegDto.setOrgDivisionCd("B041");

		List<PreReg> preRegList = bePreRegSvc.searchList(preRegDto);
		List<PreReg> contentList = new ArrayList<>();

		if (BaseUtil.isListNull(preRegList)) {
			return new BeException(BeErrorCodeEnum.I404C001);
		}

		try {
			if (!BaseUtil.isListNull(preRegList)) {
				Map<String, Long> countByDiv = preRegList.stream()
						.collect(Collectors.groupingBy(PreReg::getOrgDivisionCd, Collectors.counting()));
				LOGGER.debug("days", countByDiv);

				// looping content
				countByDiv.forEach((k, v) -> {

					UserGroupBranch userGroupBranch = new UserGroupBranch();
					userGroupBranch.setCityCd(k);

					List<UserGroupBranch> userGroupBranchList = getIdmService(request)
							.searchUserGroupBranch(userGroupBranch);

					List<PreReg> regDtoList = new ArrayList<>();

					if (!BaseUtil.isListNull(userGroupBranchList)) {
						preRegDto.setOrgDivisionCd(k);

						PreReg regis = new PreReg();
						regis.setOrgStateCd(userGroupBranchList.get(0).getStateCd());
						regis.setBranchId(userGroupBranchList.get(0).getBranchId());
						regis.setTotalRegistration(v);

						List<PreReg> preRegisList = bePreRegSvc.searchList(preRegDto);

						preRegisList.forEach(preReg -> {
							PreReg reg = new PreReg();
							reg = dozerMapper.map(regis, PreReg.class);
							Date secondDate = DateUtil.convertTimestampToDate(preReg.getApplyDt());
							Date firstDate = new Date();

							long diffInMillies = Math.abs(secondDate.getTime() - firstDate.getTime());
							long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
							reg.setDays(diff);

							LOGGER.info("days: {} + applyDate: {} + applyBy: {}", diff, preReg.getApplyDt(),
									preReg.getApplyBy());

							BeConfig beConfig = beConfigSvc
									.findByConfigCode(ConfigConstants.HQ_APPROVE_DAY_01);
							if (BaseUtil.isObjNull(beConfig)) {
								throw new BeException(BeErrorCodeEnum.E500C004);
							}
							
							String days = beConfig.getConfigVal();
							
							if (diff == Long.valueOf(days)) {
								reg.setPreRegId(preReg.getPreRegId());
								regDtoList.add(reg);
							}
						});

						contentList.addAll(regDtoList);
					}
				});

				LOGGER.debug("contentList: {}" + new Gson().toJson(contentList));

				if (!BaseUtil.isListNull(contentList)) {
					List<BePreReg> listPreg = new ArrayList<>();
					for (PreReg preg : contentList) {
						BePreReg bpreg = dozerMapper.map(preg, BePreReg.class);
						bpreg = bePreRegSvc.find(preg.getPreRegId());
						bpreg.setStatusId(12);
						bpreg.setHqInd(1);
						listPreg.add(bpreg);
					}
					bePreRegSvc.updatePreRegList(listPreg);

					Map<Integer, Long> countByDivState = contentList.stream()
							.sorted(Comparator.comparingInt(PreReg::getBranchId))
							.collect(Collectors.groupingBy(PreReg::getBranchId, Collectors.counting()));
					LOGGER.debug("count", countByDivState);

					List<PreReg> regList = new ArrayList<>();
					// looping user
					countByDivState.forEach((k, v) -> {
						PreReg reg = new PreReg();
						UserGroupBranch userGroupBranch = getIdmService(request)
								.searchUserGroupBranchByBranchId(k);
						RefState refState = refStateSvc.findByStateCode(userGroupBranch.getStateCd());

						reg.setOrgStateCd(refState.getStateDesc());
						reg.setOrgBranchCd(userGroupBranch.getBranchName());
						reg.setTotalRegistration(v);
						regList.add(reg);
					});

					regList.sort(Comparator.comparing(PreReg::getOrgStateCd));
					LOGGER.debug("regList: {}" + new Gson().toJson(regList));

					UserProfile userProfile = new UserProfile();
					userProfile.setUserRoleGroupCode(IdmRoleConstants.HQ_ADMIN);

					List<UserProfile> userProfileList = new ArrayList<>();

					try {
						userProfileList = getIdmService(request).searchUserProfile(userProfile);
					} catch (Exception e) {

					}

					if (!BaseUtil.isListNull(userProfileList)) {
						userProfileList.forEach(usrProfile -> {
							LOGGER.debug("email: {}", usrProfile.getEmail());

							if (!BaseUtil.isListNull(regList)) {
								Map<String, Object> map = new HashMap<>();
								map.put("preRegList", regList);

								Notification notification = new Notification();

								notification.setNotifyTo(usrProfile.getEmail());
								notification.setMetaData(MailUtil.convertMapToJson(map));
								notification.setNotifyType(MailTypeEnum.MAIL.getType());
								notification.setContent(usrProfile.getUserId());
								getNotifyService(request).addNotification(notification,
										MailTemplateConstants.HQ_REMINDER_REGISTRATION_APPROVAL);
							}
						});
					}
				}

			}

		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E400C004);
		}

		return new BeException(BeErrorCodeEnum.E200C000);
	}


	@GetMapping(value = BeUrlConstants.UPDATE_MEMBER_CATEGORY_BY_AGE, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public BeException updateMemberCategoryByAge(HttpServletRequest request) throws IOException {
		String userId = getCurrUserId(request);

		/* update member category in preReg */
		PreReg preReg = new PreReg();

		List<BePreReg> bePreRegList = bePreRegSvc.searchBePreReg(preReg);
		if (BaseUtil.isListNull(bePreRegList)) {
			return new BeException(BeErrorCodeEnum.I404C001);
		}
		RefMetadata armada = refMetadataSvc.findByMtdtTypeMtdtCd("MBR_CAT", "TYPE_ARMDA");

		bePreRegList.forEach(bePreReg -> {
			Integer dobYear = DateUtil.getDateDiffInYears(bePreReg.getDob());

			if (!BaseUtil.isObjNull(bePreReg.getMemberCtrgyMtdtId())
					&& bePreReg.getMemberCtrgyMtdtId().equals(armada.getMtdtId())) {
				if (dobYear >= 35) {
					RefMetadata ahliKeseluruhan = refMetadataSvc.findByMtdtTypeMtdtCd("MBR_CAT", "TYPE_ALL");
					bePreReg.setMemberCtrgyMtdtId(ahliKeseluruhan.getMtdtId());
				}
			}

			LOGGER.debug("dobYear: {}", dobYear);
			Timestamp currDt = DateUtil.getSQLTimestamp();
			bePreReg.setUpdateId(userId);
			bePreReg.setUpdateDt(currDt);
		});
		bePreRegSvc.updateAll(bePreRegList);

		/* update member category in memberProfile */
		MemberProfile memberProfile = new MemberProfile();

		List<BeMemberProfile> beMemberProfileList = beMemberProfileSvc.searchList(memberProfile);
		if (BaseUtil.isListNull(beMemberProfileList)) {
			return new BeException(BeErrorCodeEnum.I404C001);
		}

		beMemberProfileList.forEach(beMemberProfile -> {
			Integer dobYear = DateUtil.getDateDiffInYears(beMemberProfile.getDob());

			if (!BaseUtil.isObjNull(beMemberProfile.getMemberCtrgyMtdtId())
					&& beMemberProfile.getMemberCtrgyMtdtId().equals(armada.getMtdtId())) {
				if (dobYear >= 35) {
					RefMetadata ahliKeseluruhan = refMetadataSvc.findByMtdtTypeMtdtCd("MBR_CAT", "TYPE_ALL");
					beMemberProfile.setMemberCtrgyMtdtId(ahliKeseluruhan.getMtdtId());
				}
			}

			LOGGER.debug("dobYear: {}", dobYear);
			Timestamp currDt = DateUtil.getSQLTimestamp();
			beMemberProfile.setUpdateId(userId);
			beMemberProfile.setUpdateDt(currDt);
		});
		beMemberProfileSvc.updateAll(beMemberProfileList);

		return new BeException(BeErrorCodeEnum.E200C000);
	}
	
	
	
	@GetMapping(value = BeUrlConstants.PAYMENT_ENQUARY_SENANGPAY, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public BeException updatePaymentGetSenangpayStatus(HttpServletRequest request) throws IOException {
		String userId = getCurrUserId(request);
		SenangPayResponds sngpay = new SenangPayResponds();
		Payment payment = new Payment();
		payment.setStatusId(5); // Pending Payment
		Timestamp tmpstamp =  DateUtil.getSQLTimestamp();
		payment.setPmtSchdulerDt(tmpstamp);
		String confVal = beConfigSvc.findByConfigCode(ConfigConstants.SENGPAY_ENQUIRY_BUFFER_TIME).getConfigVal();
		payment.setEnquirySchedularMinuts(Integer.parseInt(confVal));
		List<Payment> filtered = bePaymentSvc.searchPagination(payment, null);
		//List<Payment> filt = filtered.stream().limit(10).collect(Collectors.toList());
		
		for (Payment lstPmt : filtered) {
			try {
				//System.out.println(lstPmt.getPmtId() +"--"+lstPmt.getPmtDt());
				sngpay = getRequestQuery(lstPmt, request);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return new BeException(BeErrorCodeEnum.E200C000);
	}
	
	private SenangPayResponds getRequestQuery(Payment payment, HttpServletRequest request) throws Exception {
		SenangPayResponds  respds = new SenangPayResponds();
		if(!BaseUtil.isStringNull(payment.getPmtRefNo())) {
			//SET PARAMS TO SENANGPAY ENQUERY
			 
			// GET MERCHANT ID
			BeConfig merchId = beConfigSvc.findByConfigCode(ConfigConstants.SENANGPAY_MERCHANT_ID);
			String merchnatId = merchId.getConfigVal();
			BeConfig segSecrt = beConfigSvc.findByConfigCode(ConfigConstants.SENANGPAY_SECRET);
			String secret = segSecrt.getConfigVal();
			String order_id = payment.getPmtRefNo();
			// GET KIPLE URL
			//RefMetadata klpUrl = refMetadataService.findByMtdtId(55);
			StringBuilder reqhashParam = new StringBuilder();
			reqhashParam.append(merchnatId).append(secret).append(order_id);
			String hashCal = DigestUtils.md5Hex(reqhashParam.toString());
			
			Map<String, String> params = new HashMap<String, String>();
			params.put("order_id", order_id);
			params.put("merchant_id", merchnatId);
			params.put("hash", hashCal);
			BeConfig enqUrl = beConfigSvc.findByConfigCode(ConfigConstants.SENANGPAY_ENQUERY_URL);
			String url = enqUrl.getConfigVal();
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
			for (Map.Entry<String, String> entry : params.entrySet()) {
			    builder.queryParam(entry.getKey(), entry.getValue());
			}
			//System.out.println("builder==>"+builder.toUriString());
			RestTemplate restTemplate = new RestTemplate();
			String getjson = restTemplate.getForObject(builder.toUriString(), String.class);
			ObjectMapper objectMapper = new ObjectMapper();
			respds = objectMapper.readValue(getjson, SenangPayResponds.class);
 
			// UPDATE PAYMENT TABLE TO STATUS
			if(!BaseUtil.isObjNull(respds)) {
				Payment pmt = paymentUpdate(payment, request);
			}
		}
		return respds;	
	}
	
	
	public Payment paymentUpdate(Payment dto, HttpServletRequest request) throws IOException {

		//BePayment bePayment = dozerMapper.map(dto, BePayment.class);
		BePayment bePayment = bePaymentSvc.find(dto.getPmtId());

		if (BaseUtil.isObjNull(bePayment)) {
			throw new BeException(BeErrorCodeEnum.I404C001);
		}
		String statusCd = "FAILED";
		RefStatus pmtRefStatus = refStatusSvc.findByStatusCodeStatusType(statusCd, "PMT_STATUS");
		RefStatus preRefStatus = refStatusSvc.findByStatusCodeStatusType(statusCd, "REG_STATUS");

		String userId = getCurrUserId(request);
		Timestamp currDt = DateUtil.getSQLTimestamp();
 		bePayment.setStatusId(pmtRefStatus.getStatusId());
		bePayment.setPmtGwDt(currDt);
		bePayment.setUpdateId(userId);
		bePayment.setUpdateDt(currDt);
 
		List<Integer> preRegList = null;
		List<BeMemberProfile> beMemberProfileList = null;
		List<BePreReg> bePreRegs = new ArrayList<>();
		RefMetadata channelMtdt = new RefMetadata();
		if(BaseUtil.isEqualsCaseIgnore("FAILED", pmtRefStatus.getStatusCd())) {
			preRegList = bePayment.getPaymentDtlList().stream().map(paymentDtl -> {
				return BaseUtil.getInt(paymentDtl.getItemId());
			}).collect(Collectors.toList());

			PreReg preReg = new PreReg();
			preReg.setPreRegIdList(preRegList);
			List<BePreReg> bePreRegList = bePreRegSvc.searchBePreReg(preReg);
			if (BaseUtil.isListNull(bePreRegList)) {
				throw new BeException(BeErrorCodeEnum.E500C002);
			}

			channelMtdt = refMetadataSvc.find(bePayment.getChannelMtdtId());
			if (BaseUtil.isObjNull(channelMtdt)) {
				throw new BeException(BeErrorCodeEnum.E500C002);
			}
			
			
			for (BePreReg bePreReg : bePreRegList) {
				String Status = bePreReg.getStatusId().toString();
				if(BaseUtil.isEquals(Status, "1")|| BaseUtil.isEquals(Status, "8")) {
					bePreReg.setStatus(new RefStatus());
					bePreReg.getStatus().setStatusId(preRefStatus.getStatusId());
					bePreReg.setStatusId(preRefStatus.getStatusId());	 
					bePreRegs.add(bePreReg);
				}
			}
		}
			return bePaymentSvc.updatePostPayment2(bePayment, preRefStatus.getStatusId(), beMemberProfileList, bePreRegs);
	}
	 
}
