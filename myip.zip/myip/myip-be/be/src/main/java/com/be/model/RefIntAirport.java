/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;


/**
 * @author nurul.naimma
 *
 * @since 11 Jul 2020
 */

@Entity
@Table(name = "REF_INT_AIRPORT")
public class RefIntAirport extends AbstractEntity implements Serializable, IQfCriteria<RefIntAirport> {

	private static final long serialVersionUID = 1L;

	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "INT_AIRPORT_ID")
	private Integer intAirportId;

	@Id
	@Column(name = "IATA_CD")
	private String iataCd;

	@Column(name = "AIRPORT_NAME")
	private String airportName;

	@Column(name = "LOCATION")
	private String location;

	@Column(name = "CNTRY_CD")
	private String cntryCd;

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "STATUS")
	private boolean active;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;


	/**
	 * @return the intAirportId
	 */
	public Integer getIntAirportId() {
		return intAirportId;
	}


	/**
	 * @param intAirportId
	 *             the intAirportId to set
	 */
	public void setIntAirportId(Integer intAirportId) {
		this.intAirportId = intAirportId;
	}


	/**
	 * @return the iataCd
	 */
	public String getIataCd() {
		return iataCd;
	}


	/**
	 * @param iataCd
	 *             the iataCd to set
	 */
	public void setIataCd(String iataCd) {
		this.iataCd = iataCd;
	}


	/**
	 * @return the airportName
	 */
	public String getAirportName() {
		return airportName;
	}


	/**
	 * @param airportName
	 *             the airportName to set
	 */
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}


	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}


	/**
	 * @param location
	 *             the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}


	public String getCntryCd() {
		return cntryCd;
	}


	public void setCntryCd(String cntryCd) {
		this.cntryCd = cntryCd;
	}


	/**
	 * @return the active
	 */
	public boolean isActive() {
		return active;
	}


	/**
	 * @param active
	 *             the active to set
	 */
	public void setActive(boolean active) {
		this.active = active;
	}


	/**
	 * @return the createId
	 */
	@Override
	public String getCreateId() {
		return createId;
	}


	/**
	 * @param createId
	 *             the createId to set
	 */
	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	/**
	 * @return the createDt
	 */
	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	/**
	 * @param createDt
	 *             the createDt to set
	 */
	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	/**
	 * @return the updateDt
	 */
	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	/**
	 * @param updateDt
	 *             the updateDt to set
	 */
	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	/**
	 * @return the updateId
	 */
	@Override
	public String getUpdateId() {
		return updateId;
	}


	/**
	 * @param updateId
	 *             the updateId to set
	 */
	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
