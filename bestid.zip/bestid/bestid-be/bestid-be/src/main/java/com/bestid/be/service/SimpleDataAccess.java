/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.service;


import java.util.List;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
public interface SimpleDataAccess<S> {

	public <T> S create(final S s);


	public <T> S update(final S s);


	public <T> S find(final Integer id);


	public <T> List<S> findAll();


	public boolean delete(final Integer id);

}
