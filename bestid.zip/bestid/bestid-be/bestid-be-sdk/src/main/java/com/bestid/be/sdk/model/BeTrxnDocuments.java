/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;

import java.io.Serializable;

/**
 * @author ravindra kumar
 *
 */
public class BeTrxnDocuments implements Serializable {

	private static final long serialVersionUID = -6233327454297054142L;

	private String docRefNo;
	private Integer docId;
	private String docMgtId;
	private String reapjTrxnDocNo;
	private String docContentType;

	public BeTrxnDocuments() {
	}

	public BeTrxnDocuments(String docRefNo, Integer docId, String docMgtId,
			String docContentType) {
		this.docRefNo = docRefNo;
		this.docId = docId;
		this.docMgtId = docMgtId;
		this.docContentType = docContentType;
	}

	public String getDocRefNo() {
		return docRefNo;
	}

	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}

	public Integer getDocId() {
		return docId;
	}

	public void setDocId(Integer docId) {
		this.docId = docId;
	}

	public String getDocMgtId() {
		return docMgtId;
	}

	public void setDocMgtId(String docMgtId) {
		this.docMgtId = docMgtId;
	}

	public String getDocContentType() {
		return docContentType;
	}

	public void setDocContentType(String docContentType) {
		this.docContentType = docContentType;
	}

	public String getReapjTrxnDocNo() {
		return reapjTrxnDocNo;
	}

	public void setReapjTrxnDocNo(String reapjTrxnDocNo) {
		this.reapjTrxnDocNo = reapjTrxnDocNo;
	}

}