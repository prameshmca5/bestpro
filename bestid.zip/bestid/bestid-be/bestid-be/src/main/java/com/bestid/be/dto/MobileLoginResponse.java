/**
 * Copyright 2019. Bestinet Sdn Bhd
 */
package com.bestid.be.dto;


import java.io.Serializable;

import com.bstsb.idm.sdk.model.UserProfile;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author mohd.faisal
 * @since Feb 20, 2019
 */
@JsonInclude(Include.NON_NULL)
public class MobileLoginResponse implements Serializable {

	private static final long serialVersionUID = 1358462661569063742L;

	private String username;

	private String name;

	private String email;

	private String mobile;

	private String staffId;

	private String status;

	private String logoutstatus;

	private String loginstatus;


	public MobileLoginResponse() {
	}


	public MobileLoginResponse(UserProfile userProfile) {
		setUsername(userProfile.getUserId());
		setName(userProfile.getFullName());
		setEmail(userProfile.getEmail());
		setMobile(userProfile.getMobPhoneNo());
		setStaffId(userProfile.getNationalId());
		setStatus(userProfile.getStatus());

	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getStaffId() {
		return staffId;
	}


	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getLogoutstatus() {
		return logoutstatus;
	}


	public void setLogoutstatus(String logoutstatus) {
		this.logoutstatus = logoutstatus;
	}


	public String getLoginstatus() {
		return loginstatus;
	}


	public void setLoginstatus(String loginstatus) {
		this.loginstatus = loginstatus;
	}

}
