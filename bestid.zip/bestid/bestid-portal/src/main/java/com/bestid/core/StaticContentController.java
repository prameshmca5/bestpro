/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.core;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestid.web.idm.form.ComponentsForm;
import com.bestid.web.util.constants.AppConstants;
import com.bestid.web.util.constants.PageConstants;
import com.bestid.web.util.constants.PageTemplate;
import com.bestid.web.util.helper.ThemeHelper;
import com.bstsb.idm.sdk.model.IdmConfigDto;
import com.bstsb.util.MediaType;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
@Controller
public class StaticContentController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(StaticContentController.class);

	private static final String COMPONENTS = "components";

	@Autowired
	ThemeHelper themeHelper;


	@GetMapping(value = PageConstants.PAGE_SRC)
	public ModelAndView home(@RequestParam(value = "portal", required = false) String portal, HttpSession session) {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_DASHBOARD);

		if (isUserAuthenticated()) {
			return new ModelAndView("redirect:" + PageConstants.PAGE_DASHBOARD);
		} else {
			mav.setViewName(PageTemplate.MAIN_PAGE);
		}
		return mav;
	}


	@GetMapping(value = PageConstants.PAGE_COMPONENTS)
	public ModelAndView components(@PathVariable String item, ComponentsForm components) {
		String template = "pg_" + item;
		ModelAndView mav = getDefaultMav(template, COMPONENTS, null, null, COMPONENTS);
		mav.addObject(AppConstants.PAGE_TITLE, "Components");
		mav.addObject(COMPONENTS, components);
		mav.addObject("page", COMPONENTS);
		return mav;
	}


	@PostMapping(value = "/updateTheme", consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public @ResponseBody boolean components(@RequestBody List<IdmConfigDto> idmConfigDtoLst,
			ComponentsForm components) {
		boolean isUpdate = false;
		try {
			themeHelper.processObject(idmConfigDtoLst);
			staticData.addIdmConfig(idmConfigDtoLst);
			isUpdate = true;
		} catch (Exception e) {
			LOGGER.error("Exception: ", e);
		}
		return isUpdate;
	}


	@GetMapping(value = "/favicon.ico")
	public String favicon() {
		return "forward:/images/favicon.ico";
	}

}