/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidEnrollAppl;
import com.bestid.be.model.BidUserProfile;
import com.bestid.be.model.SecUserDevice;
import com.bestid.be.repo.BidEnrollApplRepository;
import com.bestid.be.repo.BidUserProfileRepository;
import com.bestid.be.repo.GenericRepository;
import com.bestid.be.repo.SecUserDeviceRepository;
import com.bestid.be.sdk.model.KioskCounter;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.DateUtil;


/**
 * @author mukhlis.hamzah
 * @since Feb 14, 2019
 */
@Transactional
@Service(QualifierConstants.BID_USER_PROFILE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_USER_PROFILE_SVC)
public class BidUserProfileService extends AbstractService<BidUserProfile> {

	@Autowired
	@Qualifier(QualifierConstants.BID_USER_PROFILE_REPOSITORY)
	BidUserProfileRepository bidUserProfileDao;

	@Autowired
	@Qualifier(QualifierConstants.SEC_USER_DEVICE_REPOSITORY)
	SecUserDeviceRepository secUserDeviceDao;

	@Autowired
	@Qualifier(QualifierConstants.BID_ENROLL_APPL_REPOSITORY)
	BidEnrollApplRepository bidEnrollApplDao;

	@Autowired
	@Qualifier(QualifierConstants.SEC_USER_DEVICE_SVC)
	SecUserDeviceService secUserDeviceSvc;


	@Override
	public GenericRepository<BidUserProfile> primaryDao() {
		return bidUserProfileDao;
	}


	public BidUserProfile findByUserId(int userId) {
		return bidUserProfileDao.findByUserId(userId);
	}


	public List<BidUserProfile> findUserByIdNType(String refNo, Integer userType) {
		return bidUserProfileDao.findUserByIdNType(refNo, userType);
	}


	public BidUserProfile findUserByRefNo(String refNo) {
		return bidUserProfileDao.findUserByRefNo(refNo);
	}


	public List<BidUserProfile> findUserByrefNoType(String refNo, Integer userType) {
		return bidUserProfileDao.findUserByrefNoType(refNo, userType);
	}


	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public KioskCounter saveUserInfo(BidUserProfile bUsrProf, SecUserDevice secUsrDvc, KioskCounter kioskCounter,
			String actvNo) {
		KioskCounter respCont = null;
		SecUserDevice secUserDvc = null;
		BidUserProfile bup = null;
		if (!BaseUtil.isObjNull(bUsrProf)) {
			bidUserProfileDao.save(bUsrProf);
		}

		bup = bidUserProfileDao.findUserByRefNo(kioskCounter.getIcNo());
		LOGGER.info("MACHINE ID::{}", kioskCounter.getDeviceInfo().getMachineId());
		if (BaseUtil.isObjNull(bup)) {
			return respCont;
		}

		SecUserDevice sud = new SecUserDevice();
		sud.setUserId(bup.getUserId());
		sud.setMachineId("-");
		sud.setMobileNo(kioskCounter.getPhoneNo());
		sud.setEmail(kioskCounter.getEmail());
		sud.setStatus("I");
		sud.setCreateId(kioskCounter.getDeviceInfo().getMachineId());
		sud.setUpdateId(kioskCounter.getDeviceInfo().getMachineId());
		secUserDeviceDao.save(sud);

		secUserDvc = secUserDeviceDao.findDeviceId(sud.getDeviceId());
		if (BaseUtil.isObjNull(secUserDvc)) {
			return respCont;
		}
		BidEnrollAppl bidEnrll = new BidEnrollAppl();
		bidEnrll.setDeviceId(secUserDvc.getDeviceId());
		bidEnrll.setUserId(bup.getUserId());
		bidEnrll.setApplDate(DateUtil.getSQLTimestamp());
		bidEnrll.setActivationCode(actvNo);
		bidEnrll.setStatus("A");
		bidEnrll.setCreateId(kioskCounter.getDeviceInfo().getMachineId());
		bidEnrll.setUpdateId(kioskCounter.getDeviceInfo().getMachineId());
		bidEnrollApplDao.save(bidEnrll);

		BidEnrollAppl bea = bidEnrollApplDao.findByUsrNDeviceId(secUserDvc.getDeviceId(), bup.getUserId());
		if (!BaseUtil.isObjNull(bea)) {
			respCont = new KioskCounter();
			respCont.setIdUser(String.valueOf(kioskCounter.getIcNo()));
			respCont.setApplId(String.valueOf(bea.getApplId()));
		}
		return respCont;
	}


	public BidUserProfile findBySecUserId(int secUserId) {
		return bidUserProfileDao.findBySecUserId(secUserId);
	}

}
