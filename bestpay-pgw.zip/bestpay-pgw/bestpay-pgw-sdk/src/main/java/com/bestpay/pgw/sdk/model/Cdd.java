
package com.bestpay.pgw.sdk.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "DOB",
    "address",
    "city",
    "country",
    "countryCode",
    "isCompleted",
    "isNonResident",
    "isPEP",
    "nationality",
    "nationalityCountry",
    "organization",
    "phone",
    "position",
    "postalCode",
    "state"
})
public class Cdd {

    @JsonProperty("DOB")
    private String dOB;
    @JsonProperty("address")
    private String address;
    @JsonProperty("city")
    private String city;
    @JsonProperty("country")
    private String country;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("isCompleted")
    private String isCompleted;
    @JsonProperty("isNonResident")
    private String isNonResident;
    @JsonProperty("isPEP")
    private String isPEP;
    @JsonProperty("nationality")
    private String nationality;
    @JsonProperty("nationalityCountry")
    private String nationalityCountry;
    @JsonProperty("organization")
    private String organization;
    @JsonProperty("phone")
    private String phone;
    @JsonProperty("position")
    private String position;
    @JsonProperty("postalCode")
    private String postalCode;
    @JsonProperty("state")
    private String state;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("DOB")
    public String getDOB() {
        return dOB;
    }

    @JsonProperty("DOB")
    public void setDOB(String dOB) {
        this.dOB = dOB;
    }

    @JsonProperty("address")
    public String getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(String address) {
        this.address = address;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    @JsonProperty("country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(String country) {
        this.country = country;
    }

    @JsonProperty("countryCode")
    public String getCountryCode() {
        return countryCode;
    }

    @JsonProperty("countryCode")
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @JsonProperty("isCompleted")
    public String getIsCompleted() {
        return isCompleted;
    }

    @JsonProperty("isCompleted")
    public void setIsCompleted(String isCompleted) {
        this.isCompleted = isCompleted;
    }

    @JsonProperty("isNonResident")
    public String getIsNonResident() {
        return isNonResident;
    }

    @JsonProperty("isNonResident")
    public void setIsNonResident(String isNonResident) {
        this.isNonResident = isNonResident;
    }

    @JsonProperty("isPEP")
    public String getIsPEP() {
        return isPEP;
    }

    @JsonProperty("isPEP")
    public void setIsPEP(String isPEP) {
        this.isPEP = isPEP;
    }

    @JsonProperty("nationality")
    public String getNationality() {
        return nationality;
    }

    @JsonProperty("nationality")
    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    @JsonProperty("nationalityCountry")
    public String getNationalityCountry() {
        return nationalityCountry;
    }

    @JsonProperty("nationalityCountry")
    public void setNationalityCountry(String nationalityCountry) {
        this.nationalityCountry = nationalityCountry;
    }

    @JsonProperty("organization")
    public String getOrganization() {
        return organization;
    }

    @JsonProperty("organization")
    public void setOrganization(String organization) {
        this.organization = organization;
    }

    @JsonProperty("phone")
    public String getPhone() {
        return phone;
    }

    @JsonProperty("phone")
    public void setPhone(String phone) {
        this.phone = phone;
    }

    @JsonProperty("position")
    public String getPosition() {
        return position;
    }

    @JsonProperty("position")
    public void setPosition(String position) {
        this.position = position;
    }

    @JsonProperty("postalCode")
    public String getPostalCode() {
        return postalCode;
    }

    @JsonProperty("postalCode")
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
