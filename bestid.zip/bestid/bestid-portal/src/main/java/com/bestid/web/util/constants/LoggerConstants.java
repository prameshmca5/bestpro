/**
 * Copyright 2018 - Bestinet Sdn Bhd
 */
package com.bestid.web.util.constants;

import com.bestid.core.AbstractController;

/**
 * @author Nigel Senin
 * @since 20/03/2019
 */
public class LoggerConstants extends AbstractController {

	private LoggerConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String USER_PROFILE = "userProfile: {}";
	
	public static final String PROFILE_PICTURE_DOCMGTID = "Profile Picture DocMgtId: {}";
	
	public static final String IDM_RESPONSE_ERROR = "IDM Response Error: {} - {}";
	
	public static final String DOM_RESPONSE_ERROR = "DOM Response Error: {} - {}";
	
	public static final String DM_EXCEPTION = "DmException: {}";
	
	

	public static final String LOGIN = "LOGIN";
	
}
