/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.web.cmn.controller;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestid.be.sdk.model.City;
import com.bestid.core.AbstractController;
import com.bestid.web.util.WebUtil;
import com.bestid.web.util.constants.CacheConstants;
import com.bestid.web.util.constants.MessageConstants;
import com.bestid.web.util.constants.PageConstants;
import com.bestid.web.util.constants.PageTemplate;
import com.bstsb.idm.sdk.exception.IdmException;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.PopupBox;
import com.bstsb.util.constants.BaseConstants;
import com.google.gson.Gson;


/**
 * @author Mary Jane Buenaventura
 * @since May 17, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_CMN_STATIC)
public class StaticListController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(StaticListController.class);

	private static final String PFX_IDM = "\n\tIDM : ";

	private static final String PFX_PORTAL = "\n\tPORTAL EMP : ";

	private static final String PFX_MNTCE = "mntce";

	private static final String PFX_STATLST = "statlst";

	@Autowired
	private CacheManager cacheManager;

	@Autowired
	RedisTemplate<String, String> redisTemplate;


	@GetMapping()
	public ModelAndView view() {
		return getDefaultMav(PageTemplate.TEMP_CMN_STTC_LST, PFX_MNTCE, PFX_STATLST);
	}


	@GetMapping(value = "/refresh")
	public ModelAndView refreshStaticList(@RequestParam("staticlistType") String staticlistType,
			HttpServletRequest request) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMN_STTC_LST, PFX_MNTCE, PFX_STATLST);
		String listName = "";
		String result = null;
		try {
			LOGGER.debug("Refresh static list : {}", staticlistType);
			result = processEvict(staticlistType);
			mav.addAllObjects(PopupBox.success(null, null,
					listName + messageService.getMessage(MessageConstants.SUCC_REFRSH),
					PageConstants.PAGE_CMN_STATIC));
		} catch (Exception e) {
			mav.addAllObjects(PopupBox
					.error(listName + messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
		}
		LOGGER.debug(result);
		return mav;
	}


	@PostMapping()
	public ModelAndView refreshAll(HttpServletRequest request) throws IdmException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMN_STTC_LST, PFX_MNTCE, PFX_STATLST);
		try {
			processEvict(null);
			mav.addAllObjects(PopupBox.success(null, null,
					messageService.getMessage(MessageConstants.SUCC_STLST_REFRSH), PageConstants.PAGE_CMN_STATIC));
		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
			mav.addAllObjects(PopupBox.error(messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
		}
		return mav;
	}


	private String processEvict(String prefixKey) throws IdmException {
		StringBuilder sb = new StringBuilder();
		sb.append("\n[Clearing Cache Buckets:");
		if (!BaseUtil.isObjNull(prefixKey)) {
			sb.append(" key - " + prefixKey);
		}
		try {
			if (!BaseUtil.isObjNull(prefixKey)) {
				Cache cache = cacheManager.getCache(CacheConstants.CACHE_BUCKET);
				Set<String> redisKeys = redisTemplate.keys(CacheConstants.CACHE_PREFIX + "*" + prefixKey + "*");
				// Store the keys in a List
				Iterator<String> it = redisKeys.iterator();
				while (it.hasNext()) {
					String data = it.next();
					LOGGER.debug("redisKey: {}", data);
					cache.evict(data);
				}
			} else {
				Cache cache = cacheManager.getCache(CacheConstants.CACHE_BUCKET);
				cache.clear();
				sb.append(PFX_PORTAL + true);
			}
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(BaseConstants.LOG_IDM_EXCEPTION, e.getMessage());
			sb.append(PFX_PORTAL + false);
		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
			sb.append(PFX_PORTAL + false);
		}

		try {
			if (!BaseUtil.isObjNull(prefixKey)) {
				sb.append(PFX_IDM + getIdmService().evict(prefixKey));
			} else {
				sb.append(PFX_IDM + getIdmService().evict());
			}
		} catch (IdmException e) {
			LOGGER.error(BaseConstants.LOG_IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			sb.append(PFX_IDM + false);
		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
			sb.append(PFX_IDM + false);
		}

		sb.append("\n]");
		return sb.toString();
	}


	@PostMapping(value = "/city")
	public @ResponseBody String getss(@RequestParam String stateCode, HttpServletRequest request) {
		List<City> stateList = staticData.cityList(stateCode);
		List<City> resSatetList = new ArrayList<>();
		if (!BaseUtil.isObjNull(stateList)) {
			try {
				for (City st : stateList) {
					if (BaseUtil.isEqualsCaseIgnore(st.getState(), stateCode)) {
						resSatetList.add(st);
					}
				}

				Collections.sort(resSatetList, new Comparator<City>() {

					@Override
					public int compare(City o1, City o2) {
						return o1.getDescEn().compareTo(o2.getDescEn());
					}
				});
			} catch (Exception e) {
				LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
			}
		}
		return new Gson().toJson(resSatetList);
	}
}