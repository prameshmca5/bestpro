/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.bestpay.be.model.PgwTicket;
import com.bestpay.be.sdk.model.Ticket;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.pagination.PaginationCriteria;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since November 13, 2018
 */
@Repository
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_TICKET_DAO)
public class TicketCustomDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(TicketCustomDao.class);

	private static final String MERCHANTID = "merchantId";

	private static final String WHERE_1_EQUALS_TO_1 = " where 1=1 ";

	@Autowired
	private PgwTicketRepository ticketDao;

	//
	@PersistenceContext
	private EntityManager entityManager;


	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}


	public DataTableResults<PgwTicket> searchByPagination(Ticket ticket, DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append("from PgwTicket r ");
		sb.append(WHERE_1_EQUALS_TO_1);

		if (!BaseUtil.isObjNull(ticket.getUserRoleGroupCode())) {
			if (BaseUtil.isEqualsCaseIgnore(ticket.getUserRoleGroupCode(), "ADM_SUPPORT")) {
				sb.append(" and r.supportId = :supportId ");
			}
			if (BaseUtil.isEqualsCaseIgnore(ticket.getUserRoleGroupCode(), "MER_ADMIN")) {
				sb.append(" and r.merchantId = :merchantId ");
			}
		}

		if (!BaseUtil.isObjNull(ticket.getSubject())) {
			sb.append(" and r.subject like :subject ");
		}

		if (!BaseUtil.isObjNull(ticket.getStatus())) {
			sb.append(" and r.status = :status ");
		}

		sb.append(" order by r.createDt desc ");

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause("r"));
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<PgwTicket> query = entityManager.createQuery(sb.toString(), PgwTicket.class);
		// Original Query
		TypedQuery<PgwTicket> query2 = entityManager.createQuery(sb.toString(), PgwTicket.class);

		if (!BaseUtil.isObjNull(ticket.getUserRoleGroupCode())) {
			if (BaseUtil.isEqualsCaseIgnore(ticket.getUserRoleGroupCode(), "ADM_SUPPORT")) {
				query.setParameter("supportId", ticket.getUserId());
				query2.setParameter("supportId", ticket.getUserId());
			}
			if (BaseUtil.isEqualsCaseIgnore(ticket.getUserRoleGroupCode(), "MER_ADMIN")) {
				query.setParameter(MERCHANTID, ticket.getMerchantId());
				query2.setParameter(MERCHANTID, ticket.getMerchantId());
			}
		}

		if (!BaseUtil.isObjNull(ticket.getSubject())) {
			query.setParameter("subject", "%" + ticket.getSubject() + "%");
			query2.setParameter("subject", "%" + ticket.getSubject() + "%");
		}

		if (!BaseUtil.isObjNull(ticket.getStatus())) {
			query.setParameter("status", ticket.getStatus());
			query2.setParameter("status", ticket.getStatus());
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwTicket> dataTableResult = new DataTableResults<>();
		List<PgwTicket> svcResp = query.getResultList();
		List<PgwTicket> svcResp2 = query2.getResultList();
		LOGGER.debug("Filtered Size: {}", svcResp.size());
		LOGGER.debug("Original Size: {}", svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : ticketDao.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		LOGGER.debug("isFilterByEmpty: {}", dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}
		return dataTableResult;
	}


	public Integer findRecentTicketByMerchId(String merchantId) {
		StringBuilder sb = new StringBuilder("select ticket.ticketId ");
		sb.append(" from PgwTicket ticket ");
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(" and ticket.merchantId = :merchantId ORDER BY ticket.createDt DESC ");

		TypedQuery<Integer> query = entityManager.createQuery(sb.toString(), Integer.class);
		query.setParameter(MERCHANTID, merchantId);
		query.setMaxResults(1);

		List<Integer> svcResp = query.getResultList();
		Integer pgwTicket = null;
		if (!svcResp.isEmpty()) {
			pgwTicket = svcResp.get(0);
		}
		return pgwTicket;
	}


	/**
	 * code added by Rashid for ticket update notification bug QA Defect
	 * #11068: Ticket - email
	 */
	public Integer findByTicket(Integer ticketId) {
		StringBuilder sb = new StringBuilder("select t.ticketId ");
		sb.append(" from PgwTicket t ");
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(" and t.ticketId = :ticketId ");
		TypedQuery<Integer> query = entityManager.createQuery(sb.toString(), Integer.class);
		query.setParameter("ticketId", ticketId);
		query.setMaxResults(1);

		List<Integer> svcResp = query.getResultList();
		Integer pgwTicket = null;
		if (!svcResp.isEmpty()) {
			pgwTicket = svcResp.get(0);
		}
		return pgwTicket;
	}


	public String findRecentFeedbackByTicketId(Integer ticketId) {
		StringBuilder sb = new StringBuilder("select ticket.feedback ");
		sb.append(" from PgwTicket ticket ");
		sb.append(WHERE_1_EQUALS_TO_1);
		sb.append(" and ticket.ticketId = :ticketId ");

		TypedQuery<String> query = entityManager.createQuery(sb.toString(), String.class);
		query.setParameter("ticketId", ticketId);

		List<String> svcResp = query.getResultList();
		String pgwTicket = null;
		if (!svcResp.isEmpty()) {
			pgwTicket = svcResp.get(0);
		}
		return pgwTicket;
	}


	public List<String> getCountOfAllStatus(String merchantId) {
		StringBuilder sb = new StringBuilder(" select concat(status,'-',cast(count(*) as int)) ");
		sb.append(" from PgwTicket t ");
		sb.append(WHERE_1_EQUALS_TO_1);
		if (!BaseUtil.isObjNull(merchantId) && !BaseUtil.isEquals(merchantId, "null")) {
			sb.append(" and t.merchantId = :merchantId ");
		}
		sb.append(" group by t.status ");

		TypedQuery<String> query = entityManager.createQuery(sb.toString(), String.class);
		if (!BaseUtil.isObjNull(merchantId) && !BaseUtil.isEquals(merchantId, "null")) {
			query.setParameter(MERCHANTID, merchantId);
		}
		return query.getResultList();
	}

}