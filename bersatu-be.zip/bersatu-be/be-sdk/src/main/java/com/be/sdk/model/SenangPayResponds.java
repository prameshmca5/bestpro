/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author Ramesh Pongiannan
 *
 * @since Dec 15, 2021
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class SenangPayResponds implements Serializable {

	private static final long serialVersionUID = -4552304969632049024L;

	private String status;

	private String msg;

	private List<SenangPayData> data;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public List<SenangPayData> getData() {
		return data;
	}

	public void setData(List<SenangPayData> data) {
		this.data = data;
	}
}
