package com.bestid.be.model;


import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author mukhlis.hamzah
 * @since Feb 14, 2019
 */
@Entity
@Table(name = "BID_USER_PROFILE")
public class BidUserProfile implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 4242376310477814640L;

	@Id
	@Column(name = "USER_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userId;

	@Column(name = "SEC_USER_ID")
	private Integer secUserId;

	@Column(name = "REF_NO")
	private String refNo;

	@Column(name = "USER_TYPE")
	private Integer userType;

	@Column(name = "FULL_NAME")
	private String fullName;

	@Column(name = "DOB")
	private Date dob;

	@Column(name = "POB")
	private String pob;

	@Column(name = "GENDER")
	private String gender;

	@Column(name = "RACE")
	private String race;

	@Column(name = "RELIGION")
	private String religion;

	@Column(name = "CITIZENSHIP")
	private String citizenship;

	@Column(name = "ADDRESS")
	private String addres;

	@Column(name = "POSTCODE")
	private String postcode;

	@Column(name = "CITY")
	private String city;

	@Column(name = "STATE")
	private String state;

	@Column(name = "COUNTRY")
	private String country;

	@Column(name = "ISSUE_DATE")
	private Date issueDate;

	@Column(name = "CNTRY_ISSUE")
	private String cntryIssue;

	@Column(name = "PHOTO_DOC_ID")
	private String photoDocId;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "REMARKS")
	private String remarks;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getRefNo() {
		return refNo;
	}


	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}


	public Integer getUserType() {
		return userType;
	}


	public void setUserType(Integer userType) {
		this.userType = userType;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public String getPob() {
		return pob;
	}


	public void setPob(String pob) {
		this.pob = pob;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getRace() {
		return race;
	}


	public void setRace(String race) {
		this.race = race;
	}


	public String getReligion() {
		return religion;
	}


	public void setReligion(String religion) {
		this.religion = religion;
	}


	public String getCitizenship() {
		return citizenship;
	}


	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}


	public String getAddres() {
		return addres;
	}


	public void setAddres(String addres) {
		this.addres = addres;
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public Date getIssueDate() {
		return issueDate;
	}


	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}


	public String getCntryIssue() {
		return cntryIssue;
	}


	public void setCntryIssue(String cntryIssue) {
		this.cntryIssue = cntryIssue;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getPhotoDocId() {
		return photoDocId;
	}


	public void setPhotoDocId(String photoDocId) {
		this.photoDocId = photoDocId;
	}


	public Integer getSecUserId() {
		return secUserId;
	}


	public void setSecUserId(Integer secUserId) {
		this.secUserId = secUserId;
	}

}
