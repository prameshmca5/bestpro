/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.client;


import java.io.IOException;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.Asserts;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.ErrorResponse;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;
import com.bstsb.util.UriUtil;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BeRestTemplate {

	private static final Logger LOGGER = LoggerFactory.getLogger(BeRestTemplate.class);

	private static final String URL_MUST_NOT_NULL = "'url' must not be null";

	CloseableHttpClient httpClient;


	public CloseableHttpClient getHttpClient() {
		return httpClient;
	}


	public void setHttpClient(CloseableHttpClient httpClient) {
		this.httpClient = httpClient;
	}


	public BeRestTemplate() {
		httpClient = HttpClients.createDefault();
	}


	public BeRestTemplate(CloseableHttpClient httpClient) {
		this.httpClient = httpClient;
	}


	public <T> T getForObject(String url, Class<T> responseType) throws BeException {
		return getForObject(url, responseType, null);
	}


	public <T> T getForObject(String url, Class<T> responseType, Map<String, Object> urlVariables) throws BeException {
		Asserts.notEmpty(url, URL_MUST_NOT_NULL);
		url = UriUtil.expandUriComponent(url, urlVariables);
		LOGGER.info("SST GET Request: {} ", url);
		T p = null;
		try {
			HttpGet httpGet = new HttpGet(url);
			CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
			LOGGER.info("SST GET Response Status: {} ", httpResponse.getStatusLine().getStatusCode());

			if (httpResponse.getStatusLine().getStatusCode() != 200) {
				String result = EntityUtils.toString(httpResponse.getEntity());
				ErrorResponse er = new ObjectMapper().readValue(result, ErrorResponse.class);
				throw new BeException(er.getErrorCode(), er.getErrorMessage());
			}

			String result = EntityUtils.toString(httpResponse.getEntity(), "utf-8");
			if (!BaseUtil.isObjNull(result)) {
				ObjectMapper mapper = new ObjectMapper();
				mapper.setSerializationInclusion(Include.NON_DEFAULT);
				p = mapper.readValue(result, responseType);
			}
		} catch (IOException ex) {

			throw new BeException(BeErrorCodeEnum.E503APJ000, new Object[] { url });
		}
		return p;
	}


	public <T> T postForObject(String url, Object requestBody, Class<T> responseType) throws BeException {
		return postForObject(url, requestBody, responseType, null);
	}


	public <T> T postForObject(String url, Object requestBody, Class<T> responseType, Map<String, Object> uriVariables)
			throws BeException {
		Asserts.notEmpty(url, URL_MUST_NOT_NULL);
		url = UriUtil.expandUriComponent(url, uriVariables);
		LOGGER.info("SST POST Request: {} ", url);
		T p = null;
		try {
			HttpPost httpPost = new HttpPost(url);

			if (!BaseUtil.isObjNull(requestBody)) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode node = mapper.convertValue(requestBody, JsonNode.class);
				LOGGER.info("SST POST Request Body: {} ", node);
				StringEntity input = new StringEntity(node.toString());
				input.setContentType(MediaType.APPLICATION_JSON);
				httpPost.setEntity(input);
			}

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			LOGGER.info("SST POST Response Status: {} ", httpResponse.getStatusLine().getStatusCode());

			if (httpResponse.getStatusLine().getStatusCode() != 200) {
				String result = EntityUtils.toString(httpResponse.getEntity());
				ErrorResponse er = new ObjectMapper().readValue(result, ErrorResponse.class);
				throw new BeException(er.getErrorCode(), er.getErrorMessage());
			}

			String result = EntityUtils.toString(httpResponse.getEntity());
			p = new ObjectMapper().readValue(result, responseType);
		} catch (IOException ex) {
			throw new BeException(BeErrorCodeEnum.E503APJ000, new Object[] { url });
		}
		return p;
	}


	public boolean deleteForObject(String url) throws BeException {
		Asserts.notEmpty(url, URL_MUST_NOT_NULL);
		LOGGER.info("SST DELETE Request: {} ", url);
		boolean isDel = false;
		try {
			HttpDelete httpDel = new HttpDelete(url);
			CloseableHttpResponse httpResponse = httpClient.execute(httpDel);
			LOGGER.info("SST DELETE Response Status: {} ", httpResponse.getStatusLine().getStatusCode());
		} catch (IOException ex) {
			throw new BeException(BeErrorCodeEnum.E503APJ000, new Object[] { url });
		}
		return isDel;
	}


	public <T> T putForObject(String url, Map<String, Object> uriVariables) throws BeException {
		return postForObject(url, null, null, uriVariables);
	}


	public <T> T putForObject(String url, Object requestBody, Class<T> responseType, Map<String, Object> uriVariables)
			throws BeException {
		Asserts.notEmpty(url, URL_MUST_NOT_NULL);
		url = UriUtil.expandUriComponent(url, uriVariables);
		LOGGER.info("SST PUT Request: {} ", url);
		T p = null;
		try {
			HttpPut httpPut = new HttpPut(url);
			if (!BaseUtil.isObjNull(requestBody)) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode node = mapper.convertValue(requestBody, JsonNode.class);
				LOGGER.info("SST PUT Request Body: {}", node);
				StringEntity input = new StringEntity(node.toString());
				input.setContentType(MediaType.APPLICATION_JSON);
				httpPut.setEntity(input);
			}

			CloseableHttpResponse httpResponse = httpClient.execute(httpPut);
			LOGGER.info("SST PUT Response Status: {} ", httpResponse.getStatusLine().getStatusCode());

			if (httpResponse.getStatusLine().getStatusCode() != 200) {
				statusCodeError(httpResponse.getEntity(), url);
			}

			String result = EntityUtils.toString(httpResponse.getEntity());
			p = new ObjectMapper().readValue(result, responseType);
		} catch (IOException ex) {
			throw new BeException(BeErrorCodeEnum.E503APJ000, new Object[] { url });
		}
		return p;
	}


	private void statusCodeError(HttpEntity entity, String url) throws BeException {
		try {
			String result = EntityUtils.toString(entity);
			ErrorResponse er = new ObjectMapper().readValue(result, ErrorResponse.class);
			throw new BeException(er.getErrorCode(), er.getErrorMessage());
		} catch (Exception e) {
			throw new BeException(BeErrorCodeEnum.E503APJ000, new Object[] { url });
		}
	}

}