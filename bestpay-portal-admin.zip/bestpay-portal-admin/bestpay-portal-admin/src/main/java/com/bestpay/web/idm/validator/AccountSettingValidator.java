/**
 * Copyright 2018 Bestinet Sdn Bhd
 */
package com.bestpay.web.idm.validator;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerAccSet;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ValidationUtil;


/**
 * @author Afif Saman
 * @since July 17, 2018
 */
@Component("accountSettingValidator")
public class AccountSettingValidator extends AbstractController implements Validator {

	private static final Logger LOGGER = LoggerFactory.getLogger(AccountSettingValidator.class);


	@Override
	public boolean supports(Class<?> clazz) {
		return MerAccSet.class.equals(clazz);
	}


	@Override
	public void validate(Object object, Errors errors) {
		// Validate if fields are empty or a whitespace

		errors.getFieldValue("psa");
		if (object instanceof MerAccSet) {
			MerAccSet merAccSet = (MerAccSet) object;
			boolean flag = false;
			try {
				flag = getBeService().isAccSetExistsByIcTypeAndIcNum(merAccSet);
			} catch (BeException e) {
				LOGGER.error(e.getMessage());
			}
			if (flag) {
				ValidationUtil.rejectIfEmptyOrWhitespace(errors, "pdpa", MessageConstants.ERROR_ACC_NUM_EXISTS);
			}
		}

	}
}
