/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwConfig;
import com.bestpay.be.util.QualifierConstants;

/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
@Repository
@RepositoryDefinition(domainClass = PgwConfig.class, idClass = Integer.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.CONFIG_PGW_CONFIG_DAO)
public interface RefConfigRepository extends GenericRepository<PgwConfig> {

	@Query("select u from PgwConfig u where u.configCode= :configCode ")
	public PgwConfig findByConfigCode(@Param("configCode") String configCode);

}