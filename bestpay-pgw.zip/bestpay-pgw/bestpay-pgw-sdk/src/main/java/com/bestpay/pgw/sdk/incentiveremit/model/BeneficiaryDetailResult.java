package com.bestpay.pgw.sdk.incentiveremit.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "GetBeneficiaryDetailResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class BeneficiaryDetailResult {

	@XmlElement(name = "CODE")
	private String code;

	@XmlElement(name = "SenderCustomerID")
	private String senderCustomerId;

	@XmlElement(name = "BeneficiarySno")
	private String beneficiarySno;

	@XmlElement(name = "BeneficiaryFirstName")
	private String beneficiaryFirstName;

	@XmlElement(name = "BeneficiaryMiddleName")
	private String beneficiaryMiddleName;

	@XmlElement(name = "BeneficiaryLastName")
	private String beneficiaryLastName;

	@XmlElement(name = "BeneficiaryAddress")
	private String beneficiaryAddress;

	@XmlElement(name = "BeneficiaryCity")
	private String beneficiaryCity;

	@XmlElement(name = "BeneficiaryCountry")
	private String beneficiaryCountry;

	@XmlElement(name = "BeneficiaryPhoneno")
	private String beneficiaryPhoneno;

	@XmlElement(name = "BeneficiaryMobile")
	private String beneficiaryMobile;

	@XmlElement(name = "BeneficiaryIDType")
	private String beneficiaryIdType;

	@XmlElement(name = "BeneficiaryIDNumber")
	private String beneficiaryIdNumber;

	@XmlElement(name = "BeneficiaryIDIssuePlace")
	private String beneficiaryIdIssuePlace;

	@XmlElement(name = "BeneficiaryEmail")
	private String beneficiaryEmail;

	@XmlElement(name = "BeneficiaryRelationShip")
	private String beneficiaryRelationShip;

	@XmlElement(name = "BeneficiaryBankName")
	private String beneficiaryBankName;

	@XmlElement(name = "BeneficiaryBankBranchName")
	private String beneficiaryBankBranchName;

	@XmlElement(name = "BeneficiaryBankAccountNumber")
	private String beneficiaryBankAccountNumber;

	@XmlElement(name = "BeneficiaryInformation")
	private String beneficiaryInformation;


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getSenderCustomerId() {
		return senderCustomerId;
	}


	public void setSenderCustomerId(String senderCustomerId) {
		this.senderCustomerId = senderCustomerId;
	}


	public String getBeneficiarySno() {
		return beneficiarySno;
	}


	public void setBeneficiarySno(String beneficiarySno) {
		this.beneficiarySno = beneficiarySno;
	}


	public String getBeneficiaryFirstName() {
		return beneficiaryFirstName;
	}


	public void setBeneficiaryFirstName(String beneficiaryFirstName) {
		this.beneficiaryFirstName = beneficiaryFirstName;
	}


	public String getBeneficiaryMiddleName() {
		return beneficiaryMiddleName;
	}


	public void setBeneficiaryMiddleName(String beneficiaryMiddleName) {
		this.beneficiaryMiddleName = beneficiaryMiddleName;
	}


	public String getBeneficiaryLastName() {
		return beneficiaryLastName;
	}


	public void setBeneficiaryLastName(String beneficiaryLastName) {
		this.beneficiaryLastName = beneficiaryLastName;
	}


	public String getBeneficiaryAddress() {
		return beneficiaryAddress;
	}


	public void setBeneficiaryAddress(String beneficiaryAddress) {
		this.beneficiaryAddress = beneficiaryAddress;
	}


	public String getBeneficiaryCity() {
		return beneficiaryCity;
	}


	public void setBeneficiaryCity(String beneficiaryCity) {
		this.beneficiaryCity = beneficiaryCity;
	}


	public String getBeneficiaryCountry() {
		return beneficiaryCountry;
	}


	public void setBeneficiaryCountry(String beneficiaryCountry) {
		this.beneficiaryCountry = beneficiaryCountry;
	}


	public String getBeneficiaryPhoneno() {
		return beneficiaryPhoneno;
	}


	public void setBeneficiaryPhoneno(String beneficiaryPhoneno) {
		this.beneficiaryPhoneno = beneficiaryPhoneno;
	}


	public String getBeneficiaryMobile() {
		return beneficiaryMobile;
	}


	public void setBeneficiaryMobile(String beneficiaryMobile) {
		this.beneficiaryMobile = beneficiaryMobile;
	}


	public String getBeneficiaryIdType() {
		return beneficiaryIdType;
	}


	public void setBeneficiaryIdType(String beneficiaryIdType) {
		this.beneficiaryIdType = beneficiaryIdType;
	}


	public String getBeneficiaryIdNumber() {
		return beneficiaryIdNumber;
	}


	public void setBeneficiaryIdNumber(String beneficiaryIdNumber) {
		this.beneficiaryIdNumber = beneficiaryIdNumber;
	}


	public String getBeneficiaryIdIssuePlace() {
		return beneficiaryIdIssuePlace;
	}


	public void setBeneficiaryIdIssuePlace(String beneficiaryIdIssuePlace) {
		this.beneficiaryIdIssuePlace = beneficiaryIdIssuePlace;
	}


	public String getBeneficiaryEmail() {
		return beneficiaryEmail;
	}


	public void setBeneficiaryEmail(String beneficiaryEmail) {
		this.beneficiaryEmail = beneficiaryEmail;
	}


	public String getBeneficiaryRelationShip() {
		return beneficiaryRelationShip;
	}


	public void setBeneficiaryRelationShip(String beneficiaryRelationShip) {
		this.beneficiaryRelationShip = beneficiaryRelationShip;
	}


	public String getBeneficiaryBankName() {
		return beneficiaryBankName;
	}


	public void setBeneficiaryBankName(String beneficiaryBankName) {
		this.beneficiaryBankName = beneficiaryBankName;
	}


	public String getBeneficiaryBankBranchName() {
		return beneficiaryBankBranchName;
	}


	public void setBeneficiaryBankBranchName(String beneficiaryBankBranchName) {
		this.beneficiaryBankBranchName = beneficiaryBankBranchName;
	}


	public String getBeneficiaryBankAccountNumber() {
		return beneficiaryBankAccountNumber;
	}


	public void setBeneficiaryBankAccountNumber(String beneficiaryBankAccountNumber) {
		this.beneficiaryBankAccountNumber = beneficiaryBankAccountNumber;
	}


	public String getBeneficiaryInformation() {
		return beneficiaryInformation;
	}


	public void setBeneficiaryInformation(String beneficiaryInformation) {
		this.beneficiaryInformation = beneficiaryInformation;
	}

}
