/**
 *
 */
package com.be.sdk.builder;


import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.AcctPassport;
import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.Insurance;
import com.be.sdk.model.MRZdata;
import com.be.sdk.model.TvlStat;
import com.util.pagination.DataTableResults;


/**
 * @author michelle.angela
 *
 */
public class TravellerService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public TravellerService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<AcctTraveller> searchTravellerPagination(AcctTraveller dto,
			Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVELLER);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}


	public AcctTraveller getAcctTraveller(AcctTraveller dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVELLER);
		sb.append(BeUrlConstants.GET_DETAIL);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, AcctTraveller.class);
	}


	public AcctTraveller addTravellerInfo(AcctTraveller dto, Integer acctProfId) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVELLER);
		sb.append(BeUrlConstants.INFO_ADD);
		sb.append("?acctProfId=" + acctProfId);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, AcctTraveller.class);
	}


	public Insurance addInurance(Insurance dto, Integer acctProfId) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVELLER).append(BeUrlConstants.INSURANCE);
		sb.append(BeUrlConstants.INFO_ADD);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Insurance.class);
	}


	public TvlStat verifyTraveller(TvlStat dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVELLER);
		sb.append(BeUrlConstants.VERIFY);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, TvlStat.class);
	}


	public AcctPassport searchAcctPassport(AcctPassport acctPassport) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVELLER);
		sb.append(BeUrlConstants.SEARCH_PASSPORT);
		return restTemplate().postForObject(getServiceURI(sb.toString()), acctPassport, AcctPassport.class);
	}


	public List<AcctTraveller> searchAcctTravellerList(AcctTraveller dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVELLER);
		sb.append(BeUrlConstants.SEARCH_TRAVELLER);
		AcctTraveller[] profileArray = restTemplate().postForObject(getServiceURI(sb.toString()), dto,
				AcctTraveller[].class);
		return Arrays.asList(profileArray);
	}


	public MRZdata readPassport(MRZdata dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVELLER);
		sb.append(BeUrlConstants.READ_PASSPORT);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, MRZdata.class);
	}


	public List<TvlStat> dqVerifyTraveller(List<TvlStat> dto, Integer tvlId) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVELLER);
		sb.append(BeUrlConstants.DQ).append(BeUrlConstants.VERIFY);
		sb.append("?tvlId=" + tvlId);
		TvlStat[] tvlStatArray = restTemplate().postForObject(getServiceURI(sb.toString()), dto, TvlStat[].class);
		return Arrays.asList(tvlStatArray);
	}
	
	@SuppressWarnings("unchecked")
	public DataTableResults<Insurance> searchInsurancePagination(Insurance dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVELLER).append(BeUrlConstants.INSURANCE);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}
	
	public List<AcctTraveller> getAcctTravellerList(AcctTraveller dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRAVELLER);
		sb.append(BeUrlConstants.GET_LIST);
		AcctTraveller[] travellerArray = restTemplate().postForObject(getServiceURI(sb.toString()), dto,
				AcctTraveller[].class);
		return Arrays.asList(travellerArray);
	}
}
