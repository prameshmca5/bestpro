/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.model;


import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@Entity
@Table(name = "PGW_MERCHANT_PROFILE")
public class PgwMerchantProfile extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "MER_PROF_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer merProfId;

	@Column(name = "MERCHANT_ID")
	private String merchantId;

	@Column(name = "COMPANY")
	private String company;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "DOMAIN")
	private String domain;

	@Column(name = "SALES_PIC")
	private String salesPic;

	@Column(name = "AC_STATUS")
	private String acStatus;

	@Column(name = "SUBSCRIPTION_PLAN")
	private String subscriptionPlan;

	@Column(name = "MONTHLY_CANCEL")
	private Float monthlyCancel;

	@Column(name = "MONTHLY_CHARGEBACK")
	private Float monthlyChargeback;

	@Column(name = "TOTAL_CHARGEBACK")
	private Float totalChargeback;

	@Column(name = "HIGHRISK")
	private Integer highrisk;

	@Column(name = "START_CONTRACT_DATE")
	private Date startContractDate;

	@Column(name = "EXPIRE_DATE")
	private Date expireDate;

	@Column(name = "MEMO")
	private String memo;

	@Column(name = "OWNER_DIRECTOR_NATIONAL_ID")
	private String ownerDirectorNationalId;

	@Column(name = "OWNER_DIRECTOR_NAME")
	private String ownerDirectorName;

	@Column(name = "COMP_REF_ID")
	private String companyRefId;

	@Column(name = "SOURCE_OF_INCOME")
	private String sourceOfIncome;

	@Column(name = "NATURE_OF_BUSINESS")
	private String natureOfBusiness;
	
	@Column(name = "PDPA")
	private Integer pdpa;
		
	@Column(name = "COMP_REF_FLAG")
	private String compRefFlag;
	

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public PgwMerchantProfile() {
		// pgwMerchantProfile backend model
	}


	public Integer getMerProfId() {
		return merProfId;
	}


	public void setMerProfId(Integer merProfId) {
		this.merProfId = merProfId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getCompany() {
		return company;
	}


	public void setCompany(String company) {
		this.company = company;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getDomain() {
		return domain;
	}


	public void setDomain(String domain) {
		this.domain = domain;
	}


	public String getSalesPic() {
		return salesPic;
	}


	public void setSalesPic(String salesPic) {
		this.salesPic = salesPic;
	}


	public String getAcStatus() {
		return acStatus;
	}


	public void setAcStatus(String acStatus) {
		this.acStatus = acStatus;
	}


	public String getSubscriptionPlan() {
		return subscriptionPlan;
	}


	public void setSubscriptionPlan(String subscriptionPlan) {
		this.subscriptionPlan = subscriptionPlan;
	}


	public Float getMonthlyCancel() {
		return monthlyCancel;
	}


	public void setMonthlyCancel(Float monthlyCancel) {
		this.monthlyCancel = monthlyCancel;
	}


	public Float getMonthlyChargeback() {
		return monthlyChargeback;
	}


	public void setMonthlyChargeback(Float monthlyChargeback) {
		this.monthlyChargeback = monthlyChargeback;
	}


	public Float getTotalChargeback() {
		return totalChargeback;
	}


	public void setTotalChargeback(Float totalChargeback) {
		this.totalChargeback = totalChargeback;
	}


	public Integer getHighrisk() {
		return highrisk;
	}


	public void setHighrisk(Integer highrisk) {
		this.highrisk = highrisk;
	}


	public Date getStartContractDate() {
		return startContractDate;
	}


	public void setStartContractDate(Date startContractDate) {
		this.startContractDate = startContractDate;
	}


	public Date getExpireDate() {
		return expireDate;
	}


	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}


	public String getMemo() {
		return memo;
	}


	public void setMemo(String memo) {
		this.memo = memo;
	}


	public String getOwnerDirectorNationalId() {
		return ownerDirectorNationalId;
	}


	public void setOwnerDirectorNationalId(String ownerDirectorNationalId) {
		this.ownerDirectorNationalId = ownerDirectorNationalId;
	}


	public String getOwnerDirectorName() {
		return ownerDirectorName;
	}


	public void setOwnerDirectorName(String ownerDirectorName) {
		this.ownerDirectorName = ownerDirectorName;
	}


	public String getCompanyRefId() {
		return companyRefId;
	}


	public void setCompanyRefId(String companyRefId) {
		this.companyRefId = companyRefId;
	}


	public String getSourceOfIncome() {
		return sourceOfIncome;
	}


	public void setSourceOfIncome(String sourceOfIncome) {
		this.sourceOfIncome = sourceOfIncome;
	}


	public String getNatureOfBusiness() {
		return natureOfBusiness;
	}


	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public Integer getPdpa() {
		return pdpa;
	}


	public void setPdpa(Integer pdpa) {
		this.pdpa = pdpa;
	}

 
	public String getCompRefFlag() {
		return compRefFlag;
	}


	public void setCompRefFlag(String compRefFlag) {
		this.compRefFlag = compRefFlag;
	}

	
}
