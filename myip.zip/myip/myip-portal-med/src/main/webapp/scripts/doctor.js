$(document).ready(function() {
	let rolcode = $("#userRoleGroupCode").val();
	if(rolcode =="MC_DOCTOR"){
		 $("#docMedcotId").css('display', 'block');
		}else {
			$("#docMedcotId").css('display', 'none');
		}
	
	$(window).keydown(function(event){
	    if(event.keyCode == 13) {
	      event.preventDefault();
	      return false;
	    }
	  });
	
	var oTableUserLst = $('#tblUserLst').DataTable({
		"processing": true,
	    "serverSide": true,
	    'responsive': true,
	    'destroy' : true,
	    "columns": [
	    		{ "data": null, "orderable" : false },
	            { "data": "userId" },
	            { "data": "firstName" },
	            { "data": "lastName" },
	            { "data": "userRoleGroup.userGroupDesc" },
	            { "data": "status", "orderable" : true, 
	            	"render": function ( data, type, row ) {
	            		var status = "-", statusDesc;
  	            		if(data) {
  	            			var color = "badge-primary";
  	            			if(data == 'A') {
  	            				color = "badge-success"; 
  	            				statusDesc = "ACTIVE";
  	            			} else if(data == 'F') {
  	            				color = "badge-warning";
  	            				statusDesc = "PENDING ACTIVATION";  
  	            			} else  {
  	            				color = "badge-danger";
  	            				statusDesc = "DEACTIVATED";
  	            			}
  	            			status = "<span class='badge badge-secondary " + color + "'>" + statusDesc + "</span>";
  	            		}
            			return status;
	            	}
	            },
	          ],
		"ajax": $.fn.dataTable.pipeline({
			"pages" : 1,
        	"type" : "GET",
            "url": contextPath + "/searchDr/paginated",
            "action": 'xhttp',
            'beforeSend': dtRequestHeader,
            "dataSrc": dtDataSrc,
            "data": function ( data ) {
            	data.firstName = $("#firstName").val();
            	data.lastName = $("#lastName").val();
            	data.status = $('#status').find(":selected").val();
            	data.userRoleGroupCode = $('#userRoleGroupCode').find(":selected").val();
            },
            "error": function(){  // error handling
            	console.log("error");
            }
      	 }),
      	"initComplete": function(settings, json) {
      		$('input#firstName').unbind();
      		$('input#lastName').unbind();
      		$('input#status').unbind();
      		$('#searchFilter').bind('click', function(e) {
            	portalUtil.showMainLoading(true);
            	oTableUserLst
            	.column(1).search($('input#firstName').val())
            	.column(2).search($('input#lastName').val())
                .column(4).search($('#status').find(":selected").val())
                if($('#userRoleGroupCode') != undefined) {
                	oTableUserLst.column(3).search($('#userRoleGroupCode').find(":selected").val())
                }
                oTableUserLst.draw();
            	$(".em-toggle").click();
            });
            $('#searchClear').bind('click', function(e) {
            	$('input#firstName').val("")
            	$('input#lastName').val("")
            	$("#status").val("").select2();
            	$("#userRoleGroupCode").val("").select2();
            	oTableUserLst.columns().search("").draw();
            	$(".em-toggle").click();
            });
           
        },
        "language" : {
			"emptyTable" : prop.dtbEmptyTable
		},
      	"fnDrawCallback": function ( oSettings ) { processRowNum(oSettings); hidePagination(this,"#tblUserLst");portalUtil.showMainLoading(false);} 
	});
	
	$('#tblUserLst').dataTable().fnSetFilteringEnterPress();
	$('#tblUserLst tbody').on( 'click', 'tr', function () {
		
        var d = oTableUserLst.row( this ).data();
       // console.log(d);
        if(d.userRoleGroup.userGroupDesc!="MC DOCTOR"){
        	location.href = contextPath + "/user-list/user?id=" + d.secCdId;
        }else {
        location.href = contextPath + "/searchDr/addDr?id=" + d.secCdId;
        }
    });
	$('#tblUserLst tbody').on( 'mouseover', 'tr', function () {
		var d = oTableUserLst.row( this ).data();
		if(d != undefined) { $(this).addClass('cursor-pointer'); }
    });

	$('#dobPckr').daterangepicker({
	    singleDatePicker: true,
	    showDropdowns: true,
	    endDate : new Date(),
	    maxDate: new Date(),
	    minYear: 1901,
	    maxYear: parseInt(moment().format('YYYY'), 15),
	    locale: { format: "DD/MM/YYYY" },
	}, function(start, end, label) {
		$('input[name="dob"]').val(start.format('DD/MM/YYYY'))
	});
	
	/*
	$("#userRoleGroupCode").change(function(){
		var urgc = $('#userRoleGroupCode').attr('class');
		if(!urgc.includes('urgSrch')) {
			var code = $('#userRoleGroupCode').find(":selected").val();
			if(code) {			
				var inputURL = contextPath + '/user-list/userGroup/child/' + code
				var inputData = {}
				portalUtil.showMainLoading(true);
				$.ajax({
					headers : {
						'X-CSRF-Token' : csrf_token
					},
					type: "POST", 
					url: inputURL, 
					data: inputData,
				}).done(function(data) {
					if(data.selCountry) {
						$("#stateDrpdwn").attr("style", null);
					} else {
						$("#stateCd").val(null);
						$("#stateDrpdwn").attr("style", "display:none");
					}
					
					if(data.selBranch) {
						$("#branchDrpdwn").attr("style", "");
					} else {
						$("#userGroupRoleBranchCd").val(null);
						$("#branchDrpdwn").attr("style", "display:none");
					}
					portalUtil.showMainLoading(false);
				});
			}
		}
	});
	*/
	$("#userRoleGroupCode").change(function(){
		var code = $('#userRoleGroupCode').find(":selected").val();
		if(code) {			
			portalUtil.showMainLoading(true);
			if(code=="MC_DOCTOR"){
				 
				$("#docMedcotId").css('display', 'block');
			}else {
				$("#docMedcotId").css('display', 'none');
			}
		}
			portalUtil.showMainLoading(false);
	});
});

function checkUserIdExists(userId) {
    var uid = $(userId).val();
    var inputURL = contextPath + '/user-list/checkUserIdExists'
    var inputData = { userId: uid}
    
    $.ajax({
		headers : {
			'X-CSRF-Token' : csrf_token
		},
		type: "GET", 
		url: inputURL, 
		 data: inputData,
	}).done(function(data) {
		document.getElementById("userId").disabled = true;
	});
		
}

function displayPassword() {
	  var x = document.getElementById("password");
	  if (x.type === "password") {
	    x.type = "text";
	  } else {
	    x.type = "password";
	  }
	}

/*
$(document).ready(function() {
	var start = $('input[name="createDtFrom"]').val('');
    var end =  $('input[name="createDtTo"]').val('');
    function cb(start, end) {
        if(start) {
            $('input[name="createDtFrom"]').val(start.format('DD/MM/YYYY'));            
        }
        
        if(end) {
            $('input[name="createDtTo"]').val(end.format('DD/MM/YYYY'));            
        }
    }

    $('#createDtRange').daterangepicker({
        minDate: moment("2020-01-01"),
        startDate: start,
        endDate: end,
        minYear: 2019,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    });

    $('#createDtRange').on('apply.daterangepicker', function(ev, picker) {
        $('input[name="createDtFrom"]').val(picker.startDate.format('DD/MM/YYYY'));   
        $('input[name="createDtTo"]').val(picker.endDate.format('DD/MM/YYYY'));   
    });

    $('#createDtRange').on('cancel.daterangepicker', function(ev, picker) {
        $('input[name="createDtFrom"]').val('');   
        $('input[name="createDtTo"]').val('');   
    });
    
    var oTblDocLst = $('#tblDocLst').DataTable({
    	"processing" : true,
    	"serverSide" : true,
    	'responsive' : true,
    	'destroy' : true,
    	"columns" : [ 
    		{ "data": null, "searchable" : false, "orderable" : false },
    		{ "data" : "departureDt",
    		"render" : function(data, type, row) {
    			if (data) {
    				var date = new Date(data);
    				var dd = date.getDate();
    				var mm = date.getMonth() + 1;
    				var yyyy = date.getFullYear();

    				if (dd < 10) {
    					dd = "0" + dd;
    				}
    				if (mm < 10) {
    					mm = "0" + mm;
    				}

    				return dd + "/" + mm + "/" + yyyy;
    			}
    			return "-";
    		},
    	}, 
    	{
    		"data" : "identityNo",
    		"render" : function(data, type, row) {
    			return data || "-";
    		},
    	}, 
    	{
    		"data" : "fullName.toUpperCase()",
    		"render" : function(data, type, row) {
    			return data || "-";
    		},
    	},
    	{
    		"data" : "isActive",
    		"render" : function(data, type, row) {
    			return data.isActive ? "ACTIVE" : "EXPIRED";
    		},
    	}, 
    	 { "data": null, "searchable" : false, "orderable" : false, 
          	"render": function ( data, type, row ) {
//          		return "haha";
          		var transferCase ='<center><a title="View Profile" class="mr-2" href=' + contextPath + '/tvlHstry/'+  row.docProfId +' ><i class="fa fa-exchange fa-lg"></i></a>';
          		transferCase += '<a title="View Profile" class="mr-2" href=' + contextPath + '/refund/updateStatus/'+ row.docProfId +' ><i class="fa fa-edit fa-lg"></i></a></center>';
          		return transferCase;
          	}
    	}, ],
    	"ajax" : $.fn.dataTable.pipeline({
    		"pages" : 1,
    		"type" : "GET",
    		"url" : contextPath + "/searchDr/paginated",
    		"action" : 'xhttp',
    		'beforeSend' : dtRequestHeader,
    		"dataSrc" : dtDataSrc,
    		"data" : function(data) {
//    			data.createDtFrom = $('input[name="createDtFrom"]').val();
//            	data.createDtTo = $('input[name="createDtTo"]').val();
//            	data.identityNo = $("#identityNo").val();
//            	data.fullName = $("#fullName").val();        	
//            	data.status = $("#status").val();
    		},
    		"error" : function() { // error handling
    		}
    	}),

    	"initComplete": function(settings, json) {
      		$('input#createDtFrom').unbind();
      		$('input#createDtTo').unbind();
    		$('input#identityNo').unbind();
      		$('input#fullName').unbind();  		  		
      		$('input#status').unbind();
      		$('#searchFilter').bind('click', function(e) {
            	portalUtil.showMainLoading(true);
            	oTblDocLst
                .column(1).search($('input[name="createDtFrom"]').val())
                .column(1).search($('input[name="createDtTo"]').val())
                .column(2).search($('input#identityNo').val())
                .column(3).search($('input#fullName').val())
                .column(4).search($('input#status').val())
                oTblDocLst.draw();
            	$(".em-toggle").click();
            });
      		$('#searchClear').bind('click', function(e) {
      			$('input[name="createDtFrom"]').val("")
            	$('input[name="createDtTo"]').val("")
            	$('input#identityNo').val("")
            	$('input#fullName').val("")
            	$('input#fullName').val("")
            	$('input#status').val("")
    			oTblDocLst.columns().search("").draw();
    			$(".em-toggle").click();
    		});
           
        },
    	
    	"fnDrawCallback" : function(oSettings) {
    		processRowNum(oSettings);
    		hidePagination(this, "#tblTvlHome");
    		portalUtil.showMainLoading(false);
    	}
    });
    
});
*/