/**
 * Copyright 2019
 */
package com.be.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 17, 2018
 */
public class QualifierConstants {

	private QualifierConstants() {
		throw new IllegalStateException(QualifierConstants.class.getName());
	}


	public static final String TRANS_MANAGER = "transactionManager";

	public static final String ENTITY_MANAGER = "entityManagerFactory";

	public static final String ENTITY_MANAGER_UNIT = "emf";

	public static final String SCOPE_PROTOTYPE = "prototype";

	public static final String MESSAGE_SVC = "messageService";

	public static final String REF_STATUS_DAO = "refStatusDao";

	public static final String REF_STATUS_CUSTOM_DAO = "refStatusCustomDao";

	public static final String REF_STATUS_SVC = "refStatusSvc";

	public static final String REF_COUNTRY_DAO = "refCountryDao";

	public static final String REF_COUNTRY_QF = "refCountryQf";

	public static final String REF_COUNTRY_SVC = "refCountrySvc";

	public static final String REF_DOCUMENT_DAO = "refDocumentDao";

	public static final String BE_DOCUMENT_QF = "beDocumentQf";

	public static final String REF_DOCUMENT_SVC = "refDocumentSvc";

	public static final String REF_STATE_SVC = "refStateSvc";

	public static final String REF_STATE_DAO = "refStateDao";

	public static final String REF_STATE_QF = "refStateQf";

	public static final String REF_CITY_DAO = "refCityDao";

	public static final String REF_CITY_QF = "refCityQf";

	public static final String REF_CITY_SVC = "refCitySvc";

	public static final String BE_AUDIT_TRAIL_DAO = "beAuditTrailDao";

	public static final String BE_AUDIT_TRAIL_SVC = "beAuditTrailSvc";

	public static final String BE_CONFIG_DAO = "beConfigDao";

	public static final String BE_CONFIG_SVC = "beConfigSvc";

	public static final String BE_CTRL_GEN_SERVICE = "beCtrlGenSvc";

	public static final String BE_CTRL_GEN_DAO = "beCtrlGenDao";

	public static final String BE_TRXN_DOC_DAO = "beTrxnDocumentDao";

	public static final String BE_TRXN_DOC_QF = "beTrxnDocumentQf";

	public static final String BE_TRXN_DOC_SVC = "beTrxnDocumentSvc";

	public static final String REF_METADATA_DAO = "refMetadataDao";

	public static final String REF_METADATA_QF = "refMetadataQf";

	public static final String REF_METADATA_SVC = "refMetadataSvc";

	public static final String REF_REASON_DAO = "refReasonDao";

	public static final String REF_REASON_QF = "refReasonQf";

	public static final String REF_REASON_SVC = "refReasonSvc";

	public static final String BE_MEMBER_PROFILE_DAO = "beMemberProfileDao";

	public static final String BE_MEMBER_PROFILE_SVC = "beMemberProfileSvc";

	public static final String BE_MEMBER_PROFILE_QF = "beMemberProfileQf";

	public static final String BE_MEMBER_ADDRESS_DAO = "beMemberAddressDao";

	public static final String BE_MEMBER_ADDRESS_SVC = "beMemberAddressSvc";

	public static final String BE_MEMBER_ADDRESS_QF = "beMemberAddressQf";

	public static final String BE_PAYMENT_DAO = "bePaymentDao";

	public static final String BE_PAYMENT_SVC = "bePaymentSvc";

	public static final String BE_PAYMENT_QF = "bePaymentQf";

	public static final String BE_PAYMENT_DTL_DAO = "bePaymentDtlDao";

	public static final String BE_PAYMENT_DTL_SVC = "bePaymentDtlSvc";

	public static final String BE_PAYMENT_DTL_QF = "bePaymentDtlQf";

	public static final String BE_PAYMENT_GW_DAO = "bePaymentGwDao";

	public static final String BE_PAYMENT_GW_SVC = "bePaymentGwSvc";

	public static final String BE_PAYMENT_BREAKDOWN_DAO = "bePaymentBreakdownDao";

	public static final String BE_PAYMENT_BREAKDOWN_SVC = "bePaymentBreakdownSvc";

	public static final String BE_PAYMENT_BREAKDOWN_QF = "bePaymentBreakdownQf";

	public static final String BE_PRE_REG_DAO = "bePreRegDao";

	public static final String BE_PRE_REG_SVC = "bePreRegSvc";

	public static final String BE_PRE_REG_QF = "bePreRegQf";

	public static final String BE_PRE_REG_ADDRESS_DAO = "bePreRegAddressDao";

	public static final String BE_PRE_REG_ADDRESS_SVC = "bePreRegAddressSvc";

	public static final String BE_WATCHLIST_DAO = "beWatchlistDao";

	public static final String BE_WATCHLIST_SVC = "beWatchlistSvc";

	public static final String BE_WATCHLIST_QF = "beWatchlistQf";

	public static final String REF_PARLIAMENT_DAO = "refParliamentDao";

	public static final String REF_PARLIAMENT_SVC = "refParliamentSvc";

	public static final String REF_PARLIAMENT_QF = "refParliamentQf";

	public static final String REF_DUN_DAO = "refDunDao";

	public static final String REF_DUN_SVC = "refDunSvc";

	public static final String REF_DUN_QF = "refDunQf";

	public static final String REF_DIVISION_DAO = "refDivisionDao";

	public static final String REF_DIVISION_SVC = "refDivisionSvc";

	public static final String REF_DIVISION_QF = "refDivisionQf";

	public static final String REF_BRANCH_DAO = "refBranchDao";

	public static final String REF_BRANCH_SVC = "refBranchSvc";

	public static final String REF_BRANCH_QF = "refBranchQf";

	public static final String BE_ELECTION_NOT_DAO = "beElectionNotDao";

	public static final String BE_ELECTION_NOT_SVC = "beElectionNotSvc";

	public static final String BE_ELECTION_NOT_QF = "beElectionNotQf";

	public static final String BE_ELECTION_NOT_DTL_DAO = "beElectionNotDtlDao";

	public static final String BE_ELECTION_NOT_DTL_SVC = "beElectionNotDtlSvc";

	public static final String BE_ELECTION_NOT_DTL_QF = "beElectionNotDtlQf";

	public static final String REF_PMT_GATEWAY_RESP_DAO = "refPmtGatewayRespDao";

	public static final String REF_PMT_GATEWAY_RESP_SVC = "refPmtGatewayRespSvc";

	public static final String REF_PMT_GATEWAY_RESP_QF = "refPmtGatewayRespQf";

	public static final String REF_POSITION_SVC = "refPositionSvc";

	public static final String REF_POSITION_DAO = "refPositionDao";

	public static final String REF_POSITION_CUSTOM_DAO = "refPositionCustomDao";

}