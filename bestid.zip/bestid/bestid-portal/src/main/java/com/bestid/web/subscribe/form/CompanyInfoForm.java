/**
 *
 */
package com.bestid.web.subscribe.form;

import java.sql.Timestamp;

/**
 * @author suhada
 * @since Feb 22, 2019
 */
public class CompanyInfoForm implements java.io.Serializable {

	private static final long serialVersionUID = -4580023133535435091L;

	private int cmpnyId;
	private String cmpnyName;
	private String cmpnyRegNo;
	private String cmpnyOwner;
	private String contactNo;
	private String email;
	private String createId;
	private Timestamp createDt;
	private String updateId;
	private Timestamp updateDt;

	public int getCmpnyId() {
		return cmpnyId;
	}

	public void setCmpnyId(int cmpnyId) {
		this.cmpnyId = cmpnyId;
	}

	public String getCmpnyName() {
		return cmpnyName;
	}

	public void setCmpnyName(String cmpnyName) {
		this.cmpnyName = cmpnyName;
	}

	public String getCmpnyRegNo() {
		return cmpnyRegNo;
	}

	public void setCmpnyRegNo(String cmpnyRegNo) {
		this.cmpnyRegNo = cmpnyRegNo;
	}

	public String getCmpnyOwner() {
		return cmpnyOwner;
	}

	public void setCmpnyOwner(String cmpnyOwner) {
		this.cmpnyOwner = cmpnyOwner;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCreateId() {
		return createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public String getUpdateId() {
		return updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}
