/**
 *
 */
package com.be.sdk.builder;


import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.AckSlip;
import com.be.sdk.model.MemberBlastMessage;
import com.be.sdk.model.MemberProfile;
import com.util.BaseUtil;
import com.util.pagination.DataTableResults;


/**
 * @author mohd.naem
 *
 */
public class MemberService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public MemberService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<MemberProfile> searchPaginated(MemberProfile dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<MemberProfile> searchPaginatedList(MemberProfile dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.SEARCH_PAGINATIONS);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}


	// use to search for unique column only, or else return latest data in db
	public MemberProfile searchMemberProfile(MemberProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.SEARCH);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, MemberProfile.class);
	}


	public MemberProfile createMemberProfile(MemberProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.CREATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, MemberProfile.class);
	}


	public MemberProfile updateMemberProfile(MemberProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.UPDATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, MemberProfile.class);
	}


	public Integer countMemberProfile(MemberProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.COUNT);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Integer.class);
	}


	public MemberProfile updateMemberTransfer(MemberProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.TRANSFER);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, MemberProfile.class);
	}


	public Integer checkValidityRegIdNo(String idNo) {
		StringBuilder sbUrl = new StringBuilder();
		sbUrl.append(BeUrlConstants.MEMBER).append(BeUrlConstants.CHECK_VALID_REG_IDNO);
		if (!BaseUtil.isObjNull(idNo)) {
			sbUrl.append("?idNo=" + idNo);
		}

		return restTemplate().getForObject(getServiceURI(sbUrl.toString()), Integer.class);
	}


	public MemberProfile updateMemberProfileBlock(MemberProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.BLOCK);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, MemberProfile.class);
	}


	public List<MemberProfile> updateEndorsement(List<MemberProfile> dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.UPDATE_ENDORSEMENT_STATUS);
		MemberProfile[] memberProfileArray = restTemplate().postForObject(getServiceURI(sb.toString()), dto,
				MemberProfile[].class);
		return Arrays.asList(memberProfileArray);
	}


	public AckSlip searchAcknowledgementSlip(MemberProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.ACK_SLIP);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, AckSlip.class);
	}


	public List<MemberProfile> searchMemberProfileList(MemberProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.SEARCH_LIST);
		MemberProfile[] memberProfileArray = restTemplate().postForObject(getServiceURI(sb.toString()), dto,
				MemberProfile[].class);
		return Arrays.asList(memberProfileArray);
	}
	
	public Integer blastMessage(MemberBlastMessage dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.BLAST_MESSAGE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Integer.class);
	}
	
	public Integer checkValidityMigrationIdNo(String idNo) {
		StringBuilder sbUrl = new StringBuilder();
		sbUrl.append(BeUrlConstants.MEMBER).append(BeUrlConstants.CHECK_VALID_MIGRATION_IDNO);
		if (!BaseUtil.isObjNull(idNo)) {
			sbUrl.append("?idNo=" + idNo);
		}

		return restTemplate().getForObject(getServiceURI(sbUrl.toString()), Integer.class);
	}
	
	public MemberProfile updateProfilePhoto(MemberProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.UPDATE_PROFILE_PHOTO);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, MemberProfile.class);
	}

}