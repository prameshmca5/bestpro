/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.builder;


import com.bestid.be.sdk.client.BeRestTemplate;
import com.bestid.be.sdk.constants.BeUrlConstants;
import com.bestid.be.sdk.model.KioskCounter;
import com.bestid.be.sdk.model.MessageResponse;
import com.bestid.be.sdk.model.MobileUser;
import com.bestid.be.sdk.model.QrDigitalId;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
public class ApiService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public ApiService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	public MessageResponse generateQrCodeDigitalIdInfo(QrDigitalId qrDigitalId) {
		StringBuilder restUrl = new StringBuilder();
		restUrl.append(BeUrlConstants.API_GENERATE_QR);
		return restTemplate().postForObject(getServiceURI(restUrl.toString()), qrDigitalId, MessageResponse.class);
	}


	public MessageResponse searchDevice(KioskCounter kioskCounter) {
		StringBuilder restUrl = new StringBuilder();
		restUrl.append(BeUrlConstants.API_DEVICE_SEARCH);
		return restTemplate().postForObject(getServiceURI(restUrl.toString()), kioskCounter, MessageResponse.class);
	}


	public MessageResponse searchUser(KioskCounter kioskCounter) {
		StringBuilder restUrl = new StringBuilder();
		restUrl.append(BeUrlConstants.API_USER_SEARCH);
		return restTemplate().postForObject(getServiceURI(restUrl.toString()), kioskCounter, MessageResponse.class);
	}


	public MessageResponse registerUser(KioskCounter kioskCounter) {
		StringBuilder restUrl = new StringBuilder();
		restUrl.append(BeUrlConstants.API_USER_REGISTER);
		return restTemplate().postForObject(getServiceURI(restUrl.toString()), kioskCounter, MessageResponse.class);
	}


	public MessageResponse updateContact(KioskCounter kioskCounter) {
		StringBuilder restUrl = new StringBuilder();
		restUrl.append(BeUrlConstants.API_CONTACT_UPDATE);
		return restTemplate().postForObject(getServiceURI(restUrl.toString()), kioskCounter, MessageResponse.class);
	}


	public MessageResponse genActCode(KioskCounter kioskCounter) {
		StringBuilder restUrl = new StringBuilder();
		restUrl.append(BeUrlConstants.API_ACTIVATION_CODE_GENERATE);
		return restTemplate().postForObject(getServiceURI(restUrl.toString()), kioskCounter, MessageResponse.class);
	}


	public MessageResponse verifyActCode(KioskCounter kioskCounter) {
		StringBuilder restUrl = new StringBuilder();
		restUrl.append(BeUrlConstants.API_ACTIVATION_CODE_VERIFY);
		return restTemplate().postForObject(getServiceURI(restUrl.toString()), kioskCounter, MessageResponse.class);
	}
	
	public MessageResponse verifyQrCode(QrDigitalId qrDigitalId) {
		StringBuilder restUrl = new StringBuilder();
		restUrl.append(BeUrlConstants.API_VERIFY_QR_CODE);
		return restTemplate().postForObject(getServiceURI(restUrl.toString()), qrDigitalId, MessageResponse.class);
	}
	
	public MessageResponse verifyPhoto(KioskCounter kioskCounter) {
		StringBuilder restUrl = new StringBuilder();
		restUrl.append(BeUrlConstants.API_VERIFY_PHOTO);
		return restTemplate().postForObject(getServiceURI(restUrl.toString()), kioskCounter, MessageResponse.class);
	}
	
	public MessageResponse digitalIdStatusCheck(KioskCounter kioskCounter) {
		StringBuilder restUrl = new StringBuilder();
		restUrl.append(BeUrlConstants.API_DIGITALID_STATUS_CHECK);
		return restTemplate().postForObject(getServiceURI(restUrl.toString()), kioskCounter, MessageResponse.class);
	}




	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}

}