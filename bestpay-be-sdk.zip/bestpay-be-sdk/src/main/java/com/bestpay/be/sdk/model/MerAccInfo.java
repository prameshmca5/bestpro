/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;


/**
 * @author Atiqah
 * @since June 7, 2018
 */
public class MerAccInfo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 2448031649370389092L;

	private Integer merProfId;

	private String merchantId;

	private String email;

	private String company;

	private String domain;

	private String salesPic;

	private String subscriptionPlan;

	private String acStatus;

	private Float monthlyCancel;

	private Float monthlyChargeback;

	private Float totalChargeback;

	private Integer highrisk;

	private Date startContractDate;

	private Date expireDate;

	private String memo;

	private String ownerDirectorName;

	private String ownerDirectorNationalId;

	private Integer pdpa;

	private String companyRefId;

	private String beneficiaryId;

	private String userId;

	private Timestamp createDt;

	private Timestamp updateDt;

	private String oldMerchantId;

	private String natureOfBusiness;

	private String sourceOfIncome;

	private String companyType;

	private String fullName;

	private Date dob;

	private String gender;

	private String mobPhoneNo;

	private String compRefFlag;
	
	private String termsndcond;


	public Integer getMerProfId() {
		return merProfId;
	}


	public void setMerProfId(Integer merProfId) {
		this.merProfId = merProfId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getCompany() {
		return company;
	}


	public void setCompany(String company) {
		this.company = company;
	}


	public String getDomain() {
		return domain;
	}


	public void setDomain(String domain) {
		this.domain = domain;
	}


	public String getSalesPic() {
		return salesPic;
	}


	public void setSalesPic(String salesPic) {
		this.salesPic = salesPic;
	}


	public String getSubscriptionPlan() {
		return subscriptionPlan;
	}


	public void setSubscriptionPlan(String subscriptionPlan) {
		this.subscriptionPlan = subscriptionPlan;
	}


	public String getAcStatus() {
		return acStatus;
	}


	public void setAcStatus(String acStatus) {
		this.acStatus = acStatus;
	}


	public Float getMonthlyCancel() {
		return monthlyCancel;
	}


	public void setMonthlyCancel(Float monthlyCancel) {
		this.monthlyCancel = monthlyCancel;
	}


	public Float getMonthlyChargeback() {
		return monthlyChargeback;
	}


	public void setMonthlyChargeback(Float monthlyChargeback) {
		this.monthlyChargeback = monthlyChargeback;
	}


	public Float getTotalChargeback() {
		return totalChargeback;
	}


	public void setTotalChargeback(Float totalChargeback) {
		this.totalChargeback = totalChargeback;
	}


	public Integer getHighrisk() {
		return highrisk;
	}


	public void setHighrisk(Integer highrisk) {
		this.highrisk = highrisk;
	}


	public Date getStartContractDate() {
		return startContractDate;
	}


	public void setStartContractDate(Date startContractDate) {
		this.startContractDate = startContractDate;
	}


	public Date getExpireDate() {
		return expireDate;
	}


	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}


	public String getMemo() {
		return memo;
	}


	public void setMemo(String memo) {
		this.memo = memo;
	}


	public String getOwnerDirectorName() {
		return ownerDirectorName;
	}


	public void setOwnerDirectorName(String ownerDirectorName) {
		this.ownerDirectorName = ownerDirectorName;
	}


	public String getOwnerDirectorNationalId() {
		return ownerDirectorNationalId;
	}


	public void setOwnerDirectorNationalId(String ownerDirectorNationalId) {
		this.ownerDirectorNationalId = ownerDirectorNationalId;
	}


	public Integer getPdpa() {
		return pdpa;
	}


	public void setPdpa(Integer pdpa) {
		this.pdpa = pdpa;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getCompanyRefId() {
		return companyRefId;
	}


	public void setCompanyRefId(String companyRefId) {
		this.companyRefId = companyRefId;
	}


	public String getBeneficiaryId() {
		return beneficiaryId;
	}


	public void setBeneficiaryId(String beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getOldMerchantId() {
		return oldMerchantId;
	}


	public void setOldMerchantId(String oldMerchantId) {
		this.oldMerchantId = oldMerchantId;
	}


	public String getNatureOfBusiness() {
		return natureOfBusiness;
	}


	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}


	public String getSourceOfIncome() {
		return sourceOfIncome;
	}


	public void setSourceOfIncome(String sourceOfIncome) {
		this.sourceOfIncome = sourceOfIncome;
	}


	public String getCompanyType() {
		return companyType;
	}


	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getMobPhoneNo() {
		return mobPhoneNo;
	}


	public void setMobPhoneNo(String mobPhoneNo) {
		this.mobPhoneNo = mobPhoneNo;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getCompRefFlag() {
		return compRefFlag;
	}


	public void setCompRefFlag(String compRefFlag) {
		this.compRefFlag = compRefFlag;
	}


	public String getTermsndcond() {
		return termsndcond;
	}


	public void setTermsndcond(String termsndcond) {
		this.termsndcond = termsndcond;
	}
	
}