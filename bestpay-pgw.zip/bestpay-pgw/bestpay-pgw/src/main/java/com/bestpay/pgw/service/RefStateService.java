package com.bestpay.pgw.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.RefStateRepository;
import com.bestpay.pgw.model.RefState;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.pgw.util.QualifierConstants;


@Transactional
@Service(QualifierConstants.REF_STATE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_STATE_SVC)
public class RefStateService extends AbstractService<RefState> {

	@Autowired
	private RefStateRepository stateDao;


	@Override
	public GenericRepository<RefState> primaryDao() {
		return stateDao;
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	@Override
	public List<RefState> findAll() {
		return stateDao.findAll();
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public RefState findByStateCode(String stateCode) {
		return stateDao.findByStateCode(stateCode);
	}


	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<RefState> findByStateDesc(String stateDesc) {
		return stateDao.findByStateDesc(stateDesc);
	}


	public String getStateDescByStateCd(String stateCd) {
		RefState refState = stateDao.findByStateCode(stateCd);
		if (!BaseUtil.isObjNull(refState)) {
			return refState.getStateDesc();
		} else {
			return null;
		}
	}

}
