package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;


/**
 * The persistent class for the REF_COUNTRY database table.
 *
 * @author Atiqah Khairuddin
 * @since Sept 17, 2020
 */
@Entity
@Table(name = "REF_TIMEZONE")
public class RefTimeZone extends AbstractEntity implements Serializable, IQfCriteria<RefTimeZone> {

	private static final long serialVersionUID = -6510355585641387606L;

	@Id
	@Column(name = "TZID")
	private String tzid;

	@Column(name = "UTC_CODE")
	private String utcCode;

	@Column(name = "TIMEZONE_ID")
	private String timeZoneId;

	@Column(name = "TIMEZONE_DESC")
	private String timeZoneDesc;

	@Column(name = "CNTRY_CD")
	private String cntryCd;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;


	public RefTimeZone() {
		// DO NOTHING
	}


	public String getTzid() {
		return tzid;
	}


	public void setTzid(String tzid) {
		this.tzid = tzid;
	}


	public String getUtcCode() {
		return utcCode;
	}


	public void setUtcCode(String utcCode) {
		this.utcCode = utcCode;
	}


	public String getTimeZoneId() {
		return timeZoneId;
	}


	public void setTimeZoneId(String timeZoneId) {
		this.timeZoneId = timeZoneId;
	}


	public String getTimeZoneDesc() {
		return timeZoneDesc;
	}


	public void setTimeZoneDesc(String timeZoneDesc) {
		this.timeZoneDesc = timeZoneDesc;
	}


	public String getCntryCd() {
		return cntryCd;
	}


	public void setCntryCd(String cntryCd) {
		this.cntryCd = cntryCd;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}