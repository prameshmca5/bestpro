/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author Atiqah Khairuddin
 * @since May 23, 2019
 */
public class ReferralMultiChannel implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 6645623423283005357L;

	private Integer refMulChannelId;

	private String compRefId;

	private String channel;

	private String channelName;

	private Double rate;

	private Double cost;

	private Double additionalCost;

	private Double monthlyFee;

	private Double feeOption;

	private String status;

	private Integer enable;

	private String createId;

	private Timestamp createDt;

	private String updateId;

	private Timestamp updateDt;

	private String deleted;


	public Integer getRefMulChannelId() {
		return refMulChannelId;
	}


	public void setRefMulChannelId(Integer refMulChannelId) {
		this.refMulChannelId = refMulChannelId;
	}


	public String getCompRefId() {
		return compRefId;
	}


	public void setCompRefId(String compRefId) {
		this.compRefId = compRefId;
	}


	public String getChannel() {
		return channel;
	}


	public String getChannelName() {
		return channelName;
	}


	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public Double getRate() {
		return rate;
	}


	public void setRate(Double rate) {
		this.rate = rate;
	}


	public Double getCost() {
		return cost;
	}


	public void setCost(Double cost) {
		this.cost = cost;
	}


	public Double getAdditionalCost() {
		return additionalCost;
	}


	public void setAdditionalCost(Double additionalCost) {
		this.additionalCost = additionalCost;
	}


	public Double getMonthlyFee() {
		return monthlyFee;
	}


	public void setMonthlyFee(Double monthlyFee) {
		this.monthlyFee = monthlyFee;
	}


	public Double getFeeOption() {
		return feeOption;
	}


	public void setFeeOption(Double feeOption) {
		this.feeOption = feeOption;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Integer getEnable() {
		return enable;
	}


	public void setEnable(Integer enable) {
		this.enable = enable;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getDeleted() {
		return deleted;
	}


	public void setDeleted(String deleted) {
		this.deleted = deleted;
	}

}