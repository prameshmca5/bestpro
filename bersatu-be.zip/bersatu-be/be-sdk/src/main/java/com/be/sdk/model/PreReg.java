/**
  * Copyright 2019
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;


/**
 *
 * @author Naem Othman
 * @since March 31, 2020
 */
public class PreReg implements Serializable, IQfCriteria<PreReg> {

	private static final long serialVersionUID = 6016032592885161865L;

	private Integer preRegId;

	private List<Integer> preRegIdList;

	private String txnId;

	private List<String> txnIdList;

	private String appRefNo;

	private String fullName;

	private String idNo;

	private Integer genderMtdtId;

	private Integer religionMtdtId;

	private Date dob;

	private Integer ethnicMtdtId;

	private String contactNo;

	private String email;

	private Integer eduMtdtId;

	private String eduDesc;

	private Integer occupationMtdtId;

	private String orgStateCd;

	private String orgStateDesc;

	private String orgDivisionCd;

	private String orgDivisionDesc;

	private String orgBranchCd;
	
	private String orgBranchDesc;

	private Integer voterRegMtdtId;

	private String docRefNo;

	private String sprStateCd;

	private String parliamentCode;

	private String dunCode;

	private Integer memberCtrgyMtdtId;

	private String memberCtrgyMtdtDesc;

	private Integer memberTypeMtdtId;

	private String passcode;

	private Integer statusId;

	private List<Integer> statusIdList;

	private Integer channelMtdtId;

	private String applyBy;

	private Timestamp applyDt;

	private String applyRemarks;

	private String approveBy;

	private Timestamp approveDt;

	private String approveRemarks;

	private List<TrxnDocuments> trxnDocumentList;

	private List<PreRegAddress> preRegAddressList;

	private Timestamp applyDtFrom;

	private Timestamp applyDtTo;

	private Status status;

	private Payment payment;

	private String channelMtdtCd;

	private Integer regExistMtdtId;

	private boolean isNotIn;

	private KiplePaymentRequest kiplePaymentRequest;

	private String statusCd;

	private String statusDesc;

	private String userId;

	private Integer positionId;

	private Date applyDte;

	private Long days;

	private Integer hqInd;

	private Long totalRegistration;

	private Integer branchId;

	private List<Integer> channelMtdtIdList;


	public Integer getPreRegId() {
		return preRegId;
	}


	public void setPreRegId(Integer preRegId) {
		this.preRegId = preRegId;
	}


	public String getTxnId() {
		return txnId;
	}


	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}


	/**
	 * @return the txnIdList
	 */
	public List<String> getTxnIdList() {
		return txnIdList;
	}


	/**
	 * @param txnIdList
	 *             the txnIdList to set
	 */
	public void setTxnIdList(List<String> txnIdList) {
		this.txnIdList = txnIdList;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getIdNo() {
		return idNo;
	}


	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}


	public Integer getGenderMtdtId() {
		return genderMtdtId;
	}


	public void setGenderMtdtId(Integer genderMtdtId) {
		this.genderMtdtId = genderMtdtId;
	}


	public Integer getReligionMtdtId() {
		return religionMtdtId;
	}


	public void setReligionMtdtId(Integer religionMtdtId) {
		this.religionMtdtId = religionMtdtId;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public Integer getEthnicMtdtId() {
		return ethnicMtdtId;
	}


	public void setEthnicMtdtId(Integer ethnicMtdtId) {
		this.ethnicMtdtId = ethnicMtdtId;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Integer getEduMtdtId() {
		return eduMtdtId;
	}


	public void setEduMtdtId(Integer eduMtdtId) {
		this.eduMtdtId = eduMtdtId;
	}


	public String getEduDesc() {
		return eduDesc;
	}


	public void setEduDesc(String eduDesc) {
		this.eduDesc = eduDesc;
	}


	public Integer getOccupationMtdtId() {
		return occupationMtdtId;
	}


	public void setOccupationMtdtId(Integer occupationMtdtId) {
		this.occupationMtdtId = occupationMtdtId;
	}


	public String getOrgStateCd() {
		return orgStateCd;
	}


	public void setOrgStateCd(String orgStateCd) {
		this.orgStateCd = orgStateCd;
	}


	public String getOrgDivisionCd() {
		return orgDivisionCd;
	}


	public void setOrgDivisionCd(String orgDivisionCd) {
		this.orgDivisionCd = orgDivisionCd;
	}


	public String getOrgBranchCd() {
		return orgBranchCd;
	}


	public void setOrgBranchCd(String orgBranchCd) {
		this.orgBranchCd = orgBranchCd;
	}
	
	
	public String getOrgBranchDesc() {
		return orgBranchDesc;
	}


	public void setOrgBranchDesc(String orgBranchDesc) {
		this.orgBranchDesc = orgBranchDesc;
	}


	public Integer getVoterRegMtdtId() {
		return voterRegMtdtId;
	}


	public void setVoterRegMtdtId(Integer voterRegMtdtId) {
		this.voterRegMtdtId = voterRegMtdtId;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public String getPasscode() {
		return passcode;
	}


	public void setPasscode(String passcode) {
		this.passcode = passcode;
	}


	public Integer getStatusId() {
		return statusId;
	}


	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}


	public Integer getChannelMtdtId() {
		return channelMtdtId;
	}


	public void setChannelMtdtId(Integer channelMtdtId) {
		this.channelMtdtId = channelMtdtId;
	}


	public String getApplyBy() {
		return applyBy;
	}


	public void setApplyBy(String applyBy) {
		this.applyBy = applyBy;
	}


	public Timestamp getApplyDt() {
		return applyDt;
	}


	public void setApplyDt(Timestamp applyDt) {
		this.applyDt = applyDt;
	}


	public String getApplyRemarks() {
		return applyRemarks;
	}


	public void setApplyRemarks(String applyRemarks) {
		this.applyRemarks = applyRemarks;
	}


	public String getApproveBy() {
		return approveBy;
	}


	public void setApproveBy(String approveBy) {
		this.approveBy = approveBy;
	}


	public Timestamp getApproveDt() {
		return approveDt;
	}


	public void setApproveDt(Timestamp approveDt) {
		this.approveDt = approveDt;
	}


	public String getApproveRemarks() {
		return approveRemarks;
	}


	public void setApproveRemarks(String approveRemarks) {
		this.approveRemarks = approveRemarks;
	}


	public List<TrxnDocuments> getTrxnDocumentList() {
		return trxnDocumentList;
	}


	public void setTrxnDocumentList(List<TrxnDocuments> trxnDocumentList) {
		this.trxnDocumentList = trxnDocumentList;
	}


	public List<PreRegAddress> getPreRegAddressList() {
		return preRegAddressList;
	}


	public void setPreRegAddressList(List<PreRegAddress> preRegAddressList) {
		this.preRegAddressList = preRegAddressList;
	}


	public Timestamp getApplyDtFrom() {
		return applyDtFrom;
	}


	public void setApplyDtFrom(Timestamp applyDtFrom) {
		this.applyDtFrom = applyDtFrom;
	}


	public Timestamp getApplyDtTo() {
		return applyDtTo;
	}


	public void setApplyDtTo(Timestamp applyDtTo) {
		this.applyDtTo = applyDtTo;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}


	public String getAppRefNo() {
		return appRefNo;
	}


	public void setAppRefNo(String appRefNo) {
		this.appRefNo = appRefNo;
	}


	public List<Integer> getPreRegIdList() {
		return preRegIdList;
	}


	public void setPreRegIdList(List<Integer> preRegIdList) {
		this.preRegIdList = preRegIdList;
	}


	public String getParliamentCode() {
		return parliamentCode;
	}


	public void setParliamentCode(String parliamentCode) {
		this.parliamentCode = parliamentCode;
	}


	public String getDunCode() {
		return dunCode;
	}


	public void setDunCode(String dunCode) {
		this.dunCode = dunCode;
	}


	public Integer getMemberCtrgyMtdtId() {
		return memberCtrgyMtdtId;
	}


	public void setMemberCtrgyMtdtId(Integer memberCtrgyMtdtId) {
		this.memberCtrgyMtdtId = memberCtrgyMtdtId;
	}


	public Integer getMemberTypeMtdtId() {
		return memberTypeMtdtId;
	}


	public void setMemberTypeMtdtId(Integer memberTypeMtdtId) {
		this.memberTypeMtdtId = memberTypeMtdtId;
	}


	public Payment getPayment() {
		return payment;
	}


	public void setPayment(Payment payment) {
		this.payment = payment;
	}


	public String getChannelMtdtCd() {
		return channelMtdtCd;
	}


	public void setChannelMtdtCd(String channelMtdtCd) {
		this.channelMtdtCd = channelMtdtCd;
	}


	public Integer getRegExistMtdtId() {
		return regExistMtdtId;
	}


	public void setRegExistMtdtId(Integer regExistMtdtId) {
		this.regExistMtdtId = regExistMtdtId;
	}


	public List<Integer> getStatusIdList() {
		return statusIdList;
	}


	public void setStatusIdList(List<Integer> statusIdList) {
		this.statusIdList = statusIdList;
	}


	public boolean isNotIn() {
		return isNotIn;
	}


	public void setNotIn(boolean isNotIn) {
		this.isNotIn = isNotIn;
	}


	/**
	 * @return the kiplePaymentRequest
	 */
	public KiplePaymentRequest getKiplePaymentRequest() {
		return kiplePaymentRequest;
	}


	/**
	 * @param kiplePaymentRequest
	 *             the kiplePaymentRequest to set
	 */
	public void setKiplePaymentRequest(KiplePaymentRequest kiplePaymentRequest) {
		this.kiplePaymentRequest = kiplePaymentRequest;
	}


	public String getStatusCd() {
		return statusCd;
	}


	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}


	public String getStatusDesc() {
		return statusDesc;
	}


	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public Integer getPositionId() {
		return positionId;
	}


	public void setPositionId(Integer positionId) {
		this.positionId = positionId;
	}


	public Date getApplyDte() {
		return applyDte;
	}


	public void setApplyDte(Date applyDte) {
		this.applyDte = applyDte;
	}


	public String getOrgStateDesc() {
		return orgStateDesc;
	}


	public void setOrgStateDesc(String orgStateDesc) {
		this.orgStateDesc = orgStateDesc;
	}


	public String getOrgDivisionDesc() {
		return orgDivisionDesc;
	}


	public void setOrgDivisionDesc(String orgDivisionDesc) {
		this.orgDivisionDesc = orgDivisionDesc;
	}


	public String getMemberCtrgyMtdtDesc() {
		return memberCtrgyMtdtDesc;
	}


	public void setMemberCtrgyMtdtDesc(String memberCtrgyMtdtDesc) {
		this.memberCtrgyMtdtDesc = memberCtrgyMtdtDesc;
	}


	public Long getDays() {
		return days;
	}


	public void setDays(Long days) {
		this.days = days;
	}


	/**
	 * @return the sprStateCd
	 */
	public String getSprStateCd() {
		return sprStateCd;
	}


	/**
	 * @param sprStateCd
	 *             the sprStateCd to set
	 */
	public void setSprStateCd(String sprStateCd) {
		this.sprStateCd = sprStateCd;
	}


	/**
	 * @return the hqInd
	 */
	public Integer getHqInd() {
		return hqInd;
	}


	/**
	 * @param hqInd
	 *             the hqInd to set
	 */
	public void setHqInd(Integer hqInd) {
		this.hqInd = hqInd;
	}


	public Long getTotalRegistration() {
		return totalRegistration;
	}


	public void setTotalRegistration(Long v) {
		totalRegistration = v;
	}


	public Integer getBranchId() {
		return branchId;
	}


	public void setBranchId(Integer branchId) {
		this.branchId = branchId;
	}


	public List<Integer> getChannelMtdtIdList() {
		return channelMtdtIdList;
	}


	public void setChannelMtdtIdList(List<Integer> channelMtdtIdList) {
		this.channelMtdtIdList = channelMtdtIdList;
	}

}