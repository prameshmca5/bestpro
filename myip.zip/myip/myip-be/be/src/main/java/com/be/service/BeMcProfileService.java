/**
 * 
 */
package com.be.service;

import java.io.IOException;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeMcProfileQf;
import com.be.dao.BeMcProfileRepository;
import com.be.model.BeMcAddress;
import com.be.model.BeMcProfile;
import com.be.sdk.constants.FileUploadConstants;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.McProfile;
import com.be.sdk.model.TrxnDocuments;
import com.idm.sdk.model.UserGroupBranch;
import com.idm.sdk.model.UserProfile;
import com.idm.sdk.model.UserType;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.UidGenerator;
import com.util.pagination.DataTableRequest;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_MC_PROFILE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_MC_PROFILE_SVC)
public class BeMcProfileService extends AbstractService<BeMcProfile> {

	@Autowired
	BeMcProfileRepository beMcProfileDao;
	
	@Autowired
	BeMcProfileQf beMcProfileQf;
	
	@Autowired
	BeMcOwnerService beMcOwnerSvc;
	
	@Autowired
	BeMcPicService beMcPicSvc;
	
	@Autowired
	BeMcAddressService beMcAddressSvc;
	
	@Autowired
	BeTrxnDocumentService beTrxnDocumentSvc;
	
	@Override
	public GenericRepository<BeMcProfile> primaryDao() {
		return beMcProfileDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beMcProfileQf.generateCriteria(cb, from, criteria);
	}

	public BeMcProfile searchBeMcProfile(McProfile dto) {
		return beMcProfileQf.searchBeMcProfile(dto);
	}
	
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class})
	public BeMcProfile createUpdate(BeMcProfile beMcProfile, BeMcProfile beMcProfileOri, 
			List<TrxnDocuments> docs, HttpServletRequest request, String systemType) {
		
		String userId = getCurrUserId(request);
		
		if(BaseUtil.isObjNull(beMcProfile.getMcProfId())) {
			beMcProfile.setDocRefNo(UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC));
			beMcProfile.setCreateId(userId);
		}else {
			beMcProfile.setCreateId(beMcProfileOri.getCreateId());
			beMcProfile.setCreateDt(beMcProfileOri.getCreateDt());
		}
		beMcProfile.setUpdateId(userId);
		beMcProfile = update(beMcProfile);
		
		if(beMcProfile.getMcOwners().iterator().hasNext()) {
			beMcOwnerSvc.createUpdate(beMcProfile.getMcOwners(), beMcProfile, userId);
		}
		
		if(beMcProfile.getMcPics().iterator().hasNext()) {
			beMcPicSvc.createUpdate(beMcProfile.getMcPics(), beMcProfile, userId);
		}
		
		if(beMcProfile.getMcAddresses().iterator().hasNext()) {
			beMcAddressSvc.createUpdate(beMcProfile.getMcAddresses(), beMcProfile, userId);
		}
		
		if (!BaseUtil.isListNull(docs)) {
			beTrxnDocumentSvc.createUpdate(docs, userId, beMcProfile.getDocRefNo());
		}
		
		if(BaseUtil.isObjNull(beMcProfileOri)) {
			UserProfile userProfile = new UserProfile();
			UserType userType = new UserType();
			userProfile.setNationalId(beMcProfile.getMcRegNo());
			userProfile.setFirstName(beMcProfile.getMcName());
	//		userProfile.setDob(dto.getDob());
	//		userProfile.setGender(dto.getGender());
			userProfile.setEmail(beMcProfile.getEmail());
			userProfile.setContactNo(beMcProfile.getContactNo());
			userType.setUserTypeCode("MC");
			userProfile.setUserType(userType);
			userProfile.setUserRoleGroupCode("MC_ADMIN");
			userProfile.setProfId(beMcProfile.getMcProfId());
			userProfile.setUserGroupRoleBranchCd("MC"+beMcProfile.getMcProfId());
			if(!beMcProfile.getMcAddresses().isEmpty())
				userProfile.setCntryCd(beMcProfile.getMcAddresses().iterator().next().getCountry().getCntryCd());
			
			UserGroupBranch usrGroupBranch = new UserGroupBranch();
			usrGroupBranch.setBranchCode("MC"+beMcProfile.getMcProfId());
			usrGroupBranch.setBranchName(beMcProfile.getMcName());
			usrGroupBranch.setEmail(beMcProfile.getEmail());
			usrGroupBranch.setContactNo(beMcProfile.getContactNo());
			usrGroupBranch.setFaxNo(beMcProfile.getFaxNo());
			usrGroupBranch.setUserGroupCode("MC_ADMIN");
			usrGroupBranch.setSystemType(systemType);
			UserType usrType = new UserType();
			usrType.setUserTypeCode("MC");
			usrGroupBranch.setUserType(usrType);
			
			if(beMcProfile.getMcAddresses().iterator().hasNext()) {
				for(BeMcAddress obj : beMcProfile.getMcAddresses()) {
					if(BaseUtil.isEquals(obj.getAddrType(), "H")) {
						usrGroupBranch.setAddr1(obj.getAddr1());
						usrGroupBranch.setAddr2(obj.getAddr2());
						usrGroupBranch.setAddr3(obj.getAddr3());
						usrGroupBranch.setAddr4(obj.getAddr4());
						usrGroupBranch.setZipcode(obj.getZipcode());
//						usrGroupBranch.setStateCd(!BaseUtil.isObjNull(obj.getState()) ? obj.getState().getStateCd() : null);
						usrGroupBranch.setCntryCd(!BaseUtil.isObjNull(obj.getCountry()) ? obj.getCountry().getCntryCd() : null);
					}
				}
			}
			
			usrGroupBranch = getIdmService(request).createUserGroupBranch(usrGroupBranch);
			
			if(!BaseUtil.isObjNull(usrGroupBranch)) {
				userProfile.setBranchId(usrGroupBranch.getBranchId());
			}
			
			getIdmService(request).createUser(userProfile);
		}
		return beMcProfile;
	}
	
	public List<BeMcProfile> searchAllByProperty(BeMcProfile profile) {
		return beMcProfileQf.searchAllByProperty(profile);
	}
	
	@SuppressWarnings("unchecked")
	public List<McProfile> searchDoctorPagination(McProfile dto, DataTableRequest<?> dataTableInRQ) 
			throws IOException {
		return JsonUtil.transferToList(beMcProfileQf.searchBeMcProfilePagination(dto, dataTableInRQ), 
				McProfile.class);
	}
	
	public long getCount(McProfile dto) {
		return beMcProfileQf.getCount(dto);
	}
	
	public McProfile searchMcProfile(McProfile dto) throws IOException {
		return JsonUtil.transferToObject(beMcProfileQf.searchBeMcProfile(dto), McProfile.class);
	}
}
