/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.model.SettlementRptInfo;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.report.sdk.constants.ReportTypeEnum;
import com.bestpay.report.sdk.model.Report;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ReportUtil;
import com.bestpay.web.util.WebUtil;
import com.google.gson.Gson;


/**
 * @author Atiqah Khairuddin
 * @since August 13, 2019
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_REMIT_STTLMNT_RPT)
public class RemittanceSettlementReportController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(RemittanceSettlementReportController.class);

	private static final String ERROR_EXCEPTION = "Error exception {}";

	private static final String SETTLE_DATE_FROM = "sttleDateFrom";

	private static final String SETTLE_DATE_TO = "sttleDateTo";


	@GetMapping
	public ModelAndView view(SettlementRptInfo settlementRptInfo, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		// Removing session attributes if any
		session.removeAttribute(SETTLE_DATE_FROM);
		session.removeAttribute(SETTLE_DATE_TO);

		return getDefaultMav(PageTemplate.TEMP_REMIT_STTLMT_RPT, "report", null,
				"remittance-settlement-report-script");
	}


	@PostMapping(params = "search")
	public ModelAndView search(@ModelAttribute("settlementRptInfo") SettlementRptInfo settlementRptInfo,
			BindingResult result, HttpServletRequest request, HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_REMIT_STTLMT_RPT, "report", null,
				"remittance-settlement-report-script");

		// Set session attributes
		session.setAttribute(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom());
		session.setAttribute(SETTLE_DATE_TO, settlementRptInfo.getSttleDateTo());

		mav.addObject("settlementRptInfo", settlementRptInfo);
		return mav;
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String getSttlmntRptInfoPaginated(
			@ModelAttribute("settlementRptInfo") SettlementRptInfo settlementRptInfo, BindingResult result,
			HttpServletRequest request) {
		LOGGER.info("GET PAGINATED SETTLEMENT REPORT LIST....");
		UserProfile authUser = getCurrentUser();
		LOGGER.info("User ID = {}", authUser);
		settlementRptInfo.setMerProfId(authUser.getProfId());
		DataTableResults<SettlementRptInfo> reports = null;
		try {
			reports = getBeService().searchRemittanceSettlementReport(settlementRptInfo,
					getPaginationRequest(request, true));
		} catch (Exception e) {
			if (WebUtil.checkSystemDown(e)) {
				LOGGER.error(e.getMessage());
			}
			LOGGER.error(e.getMessage());
		}

		return new Gson().toJson(reports);
	}


	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute("settlementRptInfo") @Validated SettlementRptInfo settlementRptInfo,
			BindingResult result, HttpServletRequest request, HttpSession session) {
		SettlementRptInfo sttlmntRptInfo = new SettlementRptInfo();
		return view(sttlmntRptInfo, result, request, session);
	}


	@GetMapping(value = "print/genSettlementReport")
	public @ResponseBody Report genSettlementReport(
			@ModelAttribute("settlementRptInfo") SettlementRptInfo settlementRptInfo,
			@RequestParam(value = SETTLE_DATE_FROM, required = false) String sttleDateFrom,
			@RequestParam(value = SETTLE_DATE_TO, required = false) String sttleDateTo, HttpServletRequest request,
			HttpSession session) {

		Report report = null;
		try {
			report = getReportService().genAllRemitSettlementRpt(sttleDateFrom, sttleDateTo, ReportTypeEnum.PDF,
					false, 0);
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.debug(ERROR_EXCEPTION, e);
		}
		return report;
	}


	@GetMapping(value = "print/settlementCsvReport.xls")
	public @ResponseBody ResponseEntity<byte[]> genCSVDataReport(
			@ModelAttribute("settlementRptInfo") SettlementRptInfo settlementRptInfo, BindingResult result,
			HttpServletRequest request, HttpSession session) {

		Date fromDate = (Date) request.getSession(true).getAttribute(SETTLE_DATE_FROM);
		Date toDate = (Date) request.getSession(true).getAttribute(SETTLE_DATE_TO);
		DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String frmDt = !BaseUtil.isObjNull(fromDate) ? sdf.format(fromDate) : "";
		String toDt = !BaseUtil.isObjNull(toDate) ? sdf.format(toDate) : "";

		try {
			Report report = getReportService().genAllRemitSettlementRpt(frmDt, toDt, ReportTypeEnum.CSV, false, 0);
			if (!BaseUtil.isObjNull(report)) {
				byte[] fb = report.getReportBytes();
				return new ResponseEntity<>(fb, ReportUtil.getHttpHeadersCSV("SettlementReport", fb.length),
						HttpStatus.OK);
			} else {
				LOGGER.error(ERROR_EXCEPTION, report);
			}

		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.debug(ERROR_EXCEPTION, e);
		}
		return null;
	}

}