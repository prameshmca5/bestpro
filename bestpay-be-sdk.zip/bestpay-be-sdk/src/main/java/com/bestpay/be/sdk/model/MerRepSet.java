/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;

import java.io.Serializable;

/**
 * @author Atiqah
 * @since June 20, 2018
 */
public class MerRepSet implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1864073233598003483L;
	private String status;
	private Integer freqD;
	private Integer freqW;
	private Integer freqM;
	private String emailProfile;
	private String emailTo;
	private String emailCc;
	private String emailBcc;
	private String merchantId;
	private String email1;
	private String email2;
	private String emailMisc;
	private String userId;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getFreqD() {
		return freqD;
	}

	public void setFreqD(Integer freqD) {
		this.freqD = freqD;
	}
	
	public Integer getFreqW() {
		return freqW;
	}
	
	public void setFreqW(Integer freqW) {
		this.freqW = freqW;
	}
	
	public Integer getFreqM() {
		return freqM;
	}
	
	public void setFreqM(Integer freqM) {
		this.freqM = freqM;
	}
	
	public String getEmailProfile() {
		return emailProfile;
	}
	
	public void setEmailProfile(String emailProfile) {
		this.emailProfile = emailProfile;
	}
	
	public String getEmailTo() {
		return emailTo;
	}
	
	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}
	
	public String getEmailCc() {
		return emailCc;
	}
	
	public void setEmailCc(String emailCc) {
		this.emailCc = emailCc;
	}
	
	public String getEmailBcc() {
		return emailBcc;
	}
	
	public void setEmailBcc(String emailBcc) {
		this.emailBcc = emailBcc;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getEmail1() {
		return email1;
	}

	public void setEmail1(String email1) {
		this.email1 = email1;
	}

	public String getEmail2() {
		return email2;
	}

	public void setEmail2(String email2) {
		this.email2 = email2;
	}

	public String getEmailMisc() {
		return emailMisc;
	}

	public void setEmailMisc(String emailMisc) {
		this.emailMisc = emailMisc;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}