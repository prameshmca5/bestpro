/**
 * 
 */
package com.be.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.model.BeTvlRefund;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.TvlRefund;
import com.be.service.BeTvlRefundService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;
import com.util.pagination.DataTableRequest;
import com.util.pagination.DataTableResults;

/**
 * @author Ramesh Pongianann
 *
 */
@Lazy
@RestController
@RequestMapping(BeUrlConstants.PAYMENTREFUND)
public class RefundRestController extends AbstractRestController {

	
	@Autowired
	private BeTvlRefundService beTvlRefundSvc;
	
	@PostMapping(value = BeUrlConstants.SEARCH_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<TvlRefund> searchRefundPaginated(@RequestBody TvlRefund dto,
			HttpServletRequest request) throws IOException {

		DataTableRequest<TvlRefund> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) beTvlRefundSvc.getCount(dto);
		
		List<TvlRefund> filtered = beTvlRefundSvc.searchBeTvlPaymentRefundPagination(dto, dataTableInRQ);
		
		if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("ALL DATA: {}", totalCount);
            LOGGER.debug("ALL filtered DATA : {}", filtered);
        }

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}
	
	@PostMapping(value = BeUrlConstants.GET_DETAIL, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public TvlRefund getRefundDetail(@RequestBody TvlRefund dto, HttpServletRequest request) throws IOException {
		return JsonUtil.transferToObject(beTvlRefundSvc.searchBeTvlRefund(dto), TvlRefund.class);
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.INFO_ADD, consumes = { MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
 	public TvlRefund addRefundfo(@RequestBody TvlRefund dto, HttpServletRequest request) throws IOException {
		try {
			TvlRefund tvlRefund = null;
			if(!BaseUtil.isObjNull(dto)) {
				tvlRefund = JsonUtil.transferToObject(beTvlRefundSvc.addRefundInfo(dto, getCurrUserId(request)), TvlRefund.class);
			}
			return tvlRefund;
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}
	
	@Transactional(rollbackFor = Exception.class)
	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public BeTvlRefund update(@RequestBody TvlRefund dto, HttpServletRequest request) throws IOException {
		
		if(BaseUtil.isObjNull(dto) || BaseUtil.isObjNull(dto.getTvlRefundId())) {
			throw new BeException(BeErrorCodeEnum.E400C913);
		}
		try {
			BeTvlRefund beTvlRefund = beTvlRefundSvc.createUpdate(dto, getCurrUserId(request));	
			return JsonUtil.transferToObject(beTvlRefund, BeTvlRefund.class);
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}
}
