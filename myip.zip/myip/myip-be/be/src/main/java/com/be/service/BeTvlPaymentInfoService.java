/**
 * 
 */
package com.be.service;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTvlPaymentInfoRepository;
import com.be.model.BeTvlPaymentInfo;
import com.be.sdk.model.IQfCriteria;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_PAYMENT_INFO_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_PAYMENT_INFO_SVC)
public class BeTvlPaymentInfoService extends AbstractService<BeTvlPaymentInfo> {

	@Autowired
	BeTvlPaymentInfoRepository beTvlPaymentInfoDao;
	
	@Override
	public GenericRepository<BeTvlPaymentInfo> primaryDao() {
		return beTvlPaymentInfoDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<BeTvlPaymentInfo> saveList(List<BeTvlPaymentInfo> infos) {
		return beTvlPaymentInfoDao.save(infos);
	}
}
