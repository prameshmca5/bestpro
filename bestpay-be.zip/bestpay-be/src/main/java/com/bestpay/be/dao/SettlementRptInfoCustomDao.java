/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.model.PgwSettlement;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.SettlementRptInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.pagination.PaginationCriteria;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Mary Jane Buenaventura
 * @since May 4, 2018
 */
@Repository
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.STTLMNTINFO_CUSTOM_DAO)
public class SettlementRptInfoCustomDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(SettlementRptInfoCustomDao.class);

	private static final String SETTLE_DATE_FROM = "sttleDateFrom";

	private static final String SETTLE_DATE_TO = "sttleDateTo";

	private static final String SETTLE_DATE = "settleDate";

	@Autowired
	private PgwSettlementRepository settlementDao;

	//
	@PersistenceContext
	private EntityManager entityManager;


	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}


	/**
	 * Search Settlement Report by pagination
	 *
	 * @param settlementRptInfo
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */

	public DataTableResults<PgwSettlement> searchByPagination(SettlementRptInfo settlementRptInfo,
			DataTableRequest dataTableInRQ, PgwMerchantProfile pgwMerchantProfile) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append("from PgwSettlement r ");
		sb.append(" where 1=1 ");

		if (!BaseUtil.isObjNull(pgwMerchantProfile.getMerchantId())) {
			sb.append(" and r.merchantId = :merchantId ");
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getSettleDate())) {
			sb.append(" and r.settleDate = :settleDate ");
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			sb.append("and r.settleDate>=:sttleDateFrom ");
		} else if (BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& !BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			sb.append("and r.settleDate<=:sttleDateTo ");
		} else if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& !BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			sb.append("and r.settleDate between :sttleDateFrom and :sttleDateTo ");
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getSettlementId())) {
			sb.append(" and r.settlementId = :settlementId ");
		}

		if (StringUtils.hasText(settlementRptInfo.getChequeNo())) {
			sb.append(" and r.chequeNo like :chequeNo ");
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getAmount())) {
			sb.append(" and r.amount = :amount ");
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getActualAmount())) {
			sb.append(" and r.actualAmount = :actualAmount ");
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getCostPenalty())) {
			sb.append(" and r.costPenalty = :costPenalty ");
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getExtraFee())) {
			sb.append(" and r.extraFee = :extraFee ");
		}

		sb.append(" order by r.createDt desc ");

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause("r"));
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.info(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<PgwSettlement> query = entityManager.createQuery(sb.toString(), PgwSettlement.class);
		// Original Query
		TypedQuery<PgwSettlement> query2 = entityManager.createQuery(sb.toString(), PgwSettlement.class);

		if (!BaseUtil.isObjNull(pgwMerchantProfile.getMerchantId())) {
			query.setParameter("merchantId", pgwMerchantProfile.getMerchantId());
			query2.setParameter("merchantId", pgwMerchantProfile.getMerchantId());
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getSettleDate())) {
			query.setParameter(SETTLE_DATE, settlementRptInfo.getSettleDate());
			query2.setParameter(SETTLE_DATE, settlementRptInfo.getSettleDate());
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			query.setParameter(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom(), TemporalType.DATE);
			query2.setParameter(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom(), TemporalType.DATE);
		} else if (BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& !BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			query.setParameter(SETTLE_DATE_TO, settlementRptInfo.getSttleDateTo(), TemporalType.DATE);
			query2.setParameter(SETTLE_DATE_TO, settlementRptInfo.getSttleDateTo(), TemporalType.DATE);
		} else if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& !BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			query.setParameter(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom(), TemporalType.DATE);
			query.setParameter(SETTLE_DATE_TO, settlementRptInfo.getSttleDateTo(), TemporalType.DATE);
			query2.setParameter(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom(), TemporalType.DATE);
			query2.setParameter(SETTLE_DATE_TO, settlementRptInfo.getSttleDateTo(), TemporalType.DATE);
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getSettlementId())) {
			query.setParameter("settlementId", settlementRptInfo.getSettlementId());
			query2.setParameter("settlementId", settlementRptInfo.getSettlementId());
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getChequeNo())) {
			query.setParameter("chequeNo", settlementRptInfo.getChequeNo());
			query2.setParameter("chequeNo", settlementRptInfo.getChequeNo());
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getAmount())) {
			query.setParameter("amount", settlementRptInfo.getAmount());
			query2.setParameter("amount", settlementRptInfo.getAmount());
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getActualAmount())) {
			query.setParameter("actualAmount", settlementRptInfo.getActualAmount());
			query2.setParameter("actualAmount", settlementRptInfo.getActualAmount());
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getCostPenalty())) {
			query.setParameter("costPenalty", settlementRptInfo.getCostPenalty());
			query2.setParameter("costPenalty", settlementRptInfo.getCostPenalty());
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getExtraFee())) {
			query.setParameter("extraFee", settlementRptInfo.getExtraFee());
			query2.setParameter("extraFee", settlementRptInfo.getExtraFee());
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwSettlement> dataTableResult = new DataTableResults<>();
		List<PgwSettlement> svcResp = query.getResultList();
		List<PgwSettlement> svcResp2 = query2.getResultList();
		LOGGER.debug("Filtered Size: {}", svcResp.size());
		LOGGER.debug("Original Size: {}", svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : settlementDao.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		LOGGER.debug("isFilterByEmpty: {}", dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}
		return dataTableResult;
	}


	/**
	 * Search Remittance Settlement Report by pagination
	 *
	 * @param settlementRptInfo
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */

	public DataTableResults<PgwSettlement> searchRemitSettlementReportByPagination(SettlementRptInfo settlementRptInfo,
			DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append("from PgwSettlement r ");
		sb.append(" where 1=1 ");
		sb.append(" and r.channel != '' ");

		if (!BaseUtil.isObjNull(settlementRptInfo.getSettleDate())) {
			sb.append(" and r.settleDate = :settleDate ");
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			sb.append("and r.settleDate>=:sttleDateFrom ");
		} else if (BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& !BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			sb.append("and r.settleDate<=:sttleDateTo ");
		} else if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& !BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			sb.append("and r.settleDate between :sttleDateFrom and :sttleDateTo ");
		}

		sb.append(" order by r.createDt desc ");

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause("r"));
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.info(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<PgwSettlement> query = entityManager.createQuery(sb.toString(), PgwSettlement.class);
		// Original Query
		TypedQuery<PgwSettlement> query2 = entityManager.createQuery(sb.toString(), PgwSettlement.class);

		if (!BaseUtil.isObjNull(settlementRptInfo.getSettleDate())) {
			query.setParameter(SETTLE_DATE, settlementRptInfo.getSettleDate());
			query2.setParameter(SETTLE_DATE, settlementRptInfo.getSettleDate());
		}

		if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			query.setParameter(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom(), TemporalType.DATE);
			query2.setParameter(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom(), TemporalType.DATE);
		} else if (BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& !BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			query.setParameter(SETTLE_DATE_TO, settlementRptInfo.getSttleDateTo(), TemporalType.DATE);
			query2.setParameter(SETTLE_DATE_TO, settlementRptInfo.getSttleDateTo(), TemporalType.DATE);
		} else if (!BaseUtil.isObjNull(settlementRptInfo.getSttleDateFrom())
				&& !BaseUtil.isObjNull(settlementRptInfo.getSttleDateTo())) {
			query.setParameter(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom(), TemporalType.DATE);
			query.setParameter(SETTLE_DATE_TO, settlementRptInfo.getSttleDateTo(), TemporalType.DATE);
			query2.setParameter(SETTLE_DATE_FROM, settlementRptInfo.getSttleDateFrom(), TemporalType.DATE);
			query2.setParameter(SETTLE_DATE_TO, settlementRptInfo.getSttleDateTo(), TemporalType.DATE);
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwSettlement> dataTableResult = new DataTableResults<>();
		List<PgwSettlement> svcResp = query.getResultList();
		List<PgwSettlement> svcResp2 = query2.getResultList();
		LOGGER.debug("Filtered Size: {}", svcResp.size());
		LOGGER.debug("Original Size: {}", svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : settlementDao.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		LOGGER.debug("isFilterByEmpty: {}", dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}
		return dataTableResult;
	}

}