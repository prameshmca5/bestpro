/**
 * 
 */
package com.be.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeMcPicRepository;
import com.be.model.BeMcPic;
import com.be.model.BeMcProfile;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_MC_PIC_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_MC_PIC_SVC)
public class BeMcPicService extends AbstractService<BeMcPic> {

	@Autowired
	BeMcPicRepository beMcPicDao;
	
	@Override
	public GenericRepository<BeMcPic> primaryDao() {
		return beMcPicDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}

	public Set<BeMcPic> createUpdate(Set<BeMcPic> set, BeMcProfile mcProfile, String userId){
		
		List<BeMcPic> beMcPics = new ArrayList<>();
		set.stream().forEach(pic -> {
			if(BaseUtil.isObjNull(pic.getMcPicId())) {
				pic.setCreateId(userId);
				pic.setMcProfile(mcProfile);
			}else {
				BeMcPic picOri = find(pic.getMcPicId());
				pic.setMcProfile(picOri.getMcProfile());
				pic.setCreateId(picOri.getCreateId());
				pic.setCreateDt(picOri.getCreateDt());
			}
			pic.setUpdateId(userId);
			beMcPics.add(pic);
		});		
		beMcPicDao.save(beMcPics);
		return set;
	}
}
