/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.web.cmn.form;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import com.bestid.be.sdk.exception.BeException;
import com.bestid.be.sdk.model.City;
import com.bestid.be.sdk.model.Country;
import com.bestid.be.sdk.model.Gender;
import com.bestid.be.sdk.model.MaritalStatus;
import com.bestid.be.sdk.model.Nationality;
import com.bestid.be.sdk.model.RefDocuments;
import com.bestid.be.sdk.model.RelationShip;
import com.bestid.be.sdk.model.State;
import com.bestid.be.sdk.model.Status;
import com.bestid.config.audit.AuditActionPolicy;
import com.bestid.core.AbstractService;
import com.bestid.web.util.WebUtil;
import com.bestid.web.util.constants.AppConstants;
import com.bestid.web.util.constants.CacheConstants;
import com.bstsb.idm.sdk.exception.IdmException;
import com.bstsb.idm.sdk.model.AuditAction;
import com.bstsb.idm.sdk.model.IdmConfigDto;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.constants.BaseConstants;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
@Component
public class StaticData extends AbstractService {

	private static final Logger LOGGER = LoggerFactory.getLogger(StaticData.class);

	@Autowired
	CacheManager cacheManager;


	@SuppressWarnings("unchecked")
	private Map<String, String> refMap(String entityType) {
		String cacheKey = CacheConstants.CACHE_KEY_REF.concat(entityType);
		Cache cache = cacheManager.getCache(CacheConstants.CACHE_BUCKET);
		Cache.ValueWrapper cv = cache.get(cacheKey);

		if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
			return (Map<String, String>) cv.get();
		}

		Map<String, String> objMap;
		try {
			switch (entityType) {
			case ServiceConstants.STAT_LST_CONFIG:
				objMap = getBeService().reference().findAllConfig();
				break;
			case ServiceConstants.STAT_IDM_CONFIG:
				objMap = getIdmService().findAllConfig();
				break;
			default:
				objMap = new HashMap<>();
				break;
			}
			if (!BaseUtil.isObjNull(objMap)) {
				cache.put(cacheKey, objMap);
			}
			return objMap;
		} catch (IdmException e) {
			LOGGER.error(BaseConstants.LOG_IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
		} catch (BeException e) {
			LOGGER.error(AppConstants.LOG_BE_EXCEPTION, e.getMessage());
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
		}
		return null;
	}


	@SuppressWarnings("rawtypes")
	private Object refList(String entityType) {
		String cacheKey = CacheConstants.CACHE_KEY_REF.concat(entityType);
		Cache cache = cacheManager.getCache(CacheConstants.CACHE_BUCKET);
		Cache.ValueWrapper cv = cache.get(cacheKey);

		if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
			return cv.get();
		}
		List objLst = null;
		try {
			switch (entityType) {
			case ServiceConstants.STAT_LST_STATUS:
				objLst = getBeService().reference().getAllStatus();
				break;
			case ServiceConstants.STAT_LST_STATE:
				objLst = getBeService().reference().findAllState();
				break;
			case ServiceConstants.COUNTRY_LST:
				objLst = getBeService().reference().findAllCountry();
				break;
			case ServiceConstants.STAT_LST_CITY:
				objLst = getBeService().reference().findByAllCities();
				break;
			case ServiceConstants.STAT_LST_DOCUMENT:
				objLst = getBeService().reference().getRefDocLst();
				break;
			case ServiceConstants.STAT_LST_RELATIONSHIP:
				objLst = getBeService().reference().findAllRelationShips();
				break;
			case ServiceConstants.STAT_LST_NATIONALITY:
				objLst = getBeService().reference().findAllNationality();
				break;
			case ServiceConstants.STAT_LST_MARITAL_STATUS:
				objLst = getBeService().reference().findAllMaritalStatus();
				break;
			case ServiceConstants.STAT_LST_GENDER:
				objLst = getBeService().reference().findAllGenders();
				break;
			default:
				objLst = null;
				break;
			}

			if (!BaseUtil.isListNullZero(objLst)) {
				cache.put(cacheKey, objLst);
			}
			return objLst;
		} catch (IdmException e) {
			LOGGER.error(BaseConstants.LOG_IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkTokenError(e)) {
				throw e;
			}
		} catch (BeException e) {
			LOGGER.error(AppConstants.LOG_BE_EXCEPTION, e.getMessage());
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
		}
		return null;
	}


	public Map<String, String> defaultMaritalStatusList() {
		Map<String, String> map = new HashMap<>();
		map.put("M", "Married");
		map.put("S", "Single");
		map.put("D", "Divorced");
		return map;
	}


	public Map<String, String> defaultReligionStatusList() {
		Map<String, String> map = new HashMap<>();
		map.put("M", "Islam");
		map.put("C", "Cristianity");
		map.put("B", "Bhuddism");
		map.put("NM", "Other Religion");
		return map;
	}


	@SuppressWarnings("unchecked")
	public List<RelationShip> relationList() {
		return (List<RelationShip>) refList(ServiceConstants.STAT_LST_RELATIONSHIP);
	}


	// nationality
	@SuppressWarnings("unchecked")
	public List<Nationality> nationalityList() {
		return (List<Nationality>) refList(ServiceConstants.STAT_LST_NATIONALITY);
	}


	@SuppressWarnings("unchecked")
	public Nationality findByNationalityCode(String code) {

		List<Nationality> lst = (List<Nationality>) refList(ServiceConstants.STAT_LST_NATIONALITY);

		for (Nationality obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getNtnltyCode())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public List<MaritalStatus> maritalStatusList() {
		return (List<MaritalStatus>) refList(ServiceConstants.STAT_LST_MARITAL_STATUS);
	}


	@SuppressWarnings("unchecked")
	public MaritalStatus maritalStatusByCode(String code) {

		List<MaritalStatus> lst = (List<MaritalStatus>) refList(ServiceConstants.STAT_LST_MARITAL_STATUS);

		for (MaritalStatus obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getMaritalStatusCode())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public RelationShip relationByCode(String code) {
		List<RelationShip> lst = (List<RelationShip>) refList(ServiceConstants.STAT_LST_RELATIONSHIP);
		for (RelationShip obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getRelationCode())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public Map<String, String> sstConfig() {
		return ((Map<String, String>) refList(ServiceConstants.STAT_LST_CONFIG));
	}


	public String idmConfig(String config) {
		Map<String, String> idmConfig = refMap(ServiceConstants.STAT_IDM_CONFIG);
		return (idmConfig != null) ? idmConfig.get(config) : "";
	}


	public void addIdmConfig(List<IdmConfigDto> idmConfigDto) {
		String cacheKey = CacheConstants.CACHE_KEY_REF.concat(ServiceConstants.STAT_IDM_CONFIG);
		Cache cache = cacheManager.getCache(CacheConstants.CACHE_BUCKET);
		cache.evict(cacheKey);

		Map<String, String> idmConfig = getIdmService().createIdmConfig(idmConfigDto);
		if (!BaseUtil.isObjNull(idmConfig)) {
			cache.put(cacheKey, idmConfig);
		}
	}


	@SuppressWarnings("unchecked")
	public List<State> getAllStateList() {

		List<State> resState = null;

		try {
			resState = ((List<State>) refList(ServiceConstants.STAT_LST_STATE));

			if (!BaseUtil.isListNull(resState)) {

				Collections.sort(resState, new Comparator<State>() {

					@Override
					public int compare(State o1, State o2) {
						return o1.getStateDesc().compareTo(o2.getStateDesc());
					}
				});
			}

		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
		}

		return resState;
	}


	public List<State> stateList() {
		return getAllStateList();
	}


	@SuppressWarnings("unchecked")
	public List<State> stateList(String country) {
		List<State> lst = (List<State>) refList(ServiceConstants.STAT_LST_STATE);
		List<State> newLst = new ArrayList<>();
		for (State obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(country, obj.getCountry())) {
				newLst.add(obj);
			}
		}

		Collections.sort(newLst, new Comparator<State>() {

			@Override
			public int compare(State o1, State o2) {
				return o1.getStateDesc().compareTo(o2.getStateDesc());
			}
		});
		return newLst;
	}


	@SuppressWarnings("unchecked")
	public State state(String stateCode) {
		List<State> lst = (List<State>) refList(ServiceConstants.STAT_LST_STATE);
		for (State obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(stateCode, obj.getStateCode())) {
				return obj;
			}
		}
		return null;
	}


	public String stateDesc(String stateCode) {
		State state = state(stateCode);
		if (!BaseUtil.isObjNull(state)) {
			return state.getStateDesc();
		}
		return "";
	}


	@SuppressWarnings("unchecked")
	public List<State> getStateListByCountry(String country) {
		List<State> resStateIn = null;
		try {
			List<State> resState = ((List<State>) refList(ServiceConstants.STAT_LST_STATE));
			if (!BaseUtil.isListNull(resState)) {
				resStateIn = new ArrayList<>();
				for (State st : resState) {
					if (BaseUtil.isEqualsCaseIgnore(st.getCountry(), country)) {
						resStateIn.add(st);
					}
				}
				Collections.sort(resStateIn, new Comparator<State>() {

					@Override
					public int compare(State o1, State o2) {
						return o1.getStateDesc().compareTo(o2.getStateDesc());
					}
				});
			}

		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
		}
		return resStateIn;
	}


	@SuppressWarnings("unchecked")
	public List<Country> getAllCountryList() {
		return ((List<Country>) refList(ServiceConstants.COUNTRY_LST));
	}


	@SuppressWarnings("unchecked")
	public List<Country> getCountryListByCountryCode(String cntryCode) {

		List<Country> countryList = ((List<Country>) refList(ServiceConstants.COUNTRY_LST));

		List<Country> countryList2 = new ArrayList<>();

		if (!BaseUtil.isListNull(countryList)) {

			try {
				for (Country country : countryList) {

					if (BaseUtil.isEqualsCaseIgnore(country.getCntryCode(), cntryCode)) {
						countryList2.add(country);
					}
				}
			} catch (Exception e) {
				LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
			}
		}
		return countryList2;
	}


	public String sstConfig(String key) {
		if (!BaseUtil.isObjNull(key)) {
			Map<String, String> conf = sstConfig();
			return conf.get(key);
		}
		return BaseConstants.EMPTY_STRING;
	}


	public Map<String, String> defaultStatusList() {
		Map<String, String> map = new HashMap<>();
		map.put("A", "ACTIVE");
		map.put("I", "INACTIVE");
		return map;
	}


	public Map<String, String> defaultUserStatusList() {
		Map<String, String> map = new HashMap<>();
		map.put("A", "ACTIVE");
		map.put("I", "INACTIVE");
		map.put("F", "PENDING ACTIVATION");
		return map;
	}


	public void addUserAction(AuditActionPolicy auditPolicy, String userId, String reqData) {
		try {
			AuditAction audit = new AuditAction();
			audit.setPortal(messageService.getMessage("app.portal.type"));
			audit.setPage(auditPolicy.page());
			audit.setAuditInfo(auditPolicy.action());
			audit.setUserId(userId);
			audit.setLookupInfo(reqData);
			getIdmService().createAuditAction(audit);
		} catch (Exception e) {
			LOGGER.error("IDM-AuditAction Response Error: {}", e.getMessage());
		}
	}


	// Document
	@SuppressWarnings("unchecked")
	public List<RefDocuments> refDocList(String trxnNo) {
		List<RefDocuments> lst = (List<RefDocuments>) refList(ServiceConstants.STAT_LST_DOCUMENT);
		List<RefDocuments> newLst = new ArrayList<>();
		if (!BaseUtil.isObjNull(lst)) {
			for (RefDocuments obj : lst) {
				if (BaseUtil.isEqualsCaseIgnore(trxnNo, obj.getTrxnNo())) {
					newLst.add(obj);
				}
			}
		}
		return newLst;
	}


	@SuppressWarnings("unchecked")
	public List<RefDocuments> findAllRefDoc() {
		return (List<RefDocuments>) refList(ServiceConstants.STAT_LST_DOCUMENT);
	}


	@SuppressWarnings("unchecked")
	public RefDocuments findByDocumentCode(String code) {

		List<RefDocuments> lst = (List<RefDocuments>) refList(ServiceConstants.STAT_LST_DOCUMENT);

		for (RefDocuments obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getTrxnNo())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public List<State> findAllState() {
		return (List<State>) refList(ServiceConstants.STAT_LST_STATE);
	}


	@SuppressWarnings("unchecked")
	public State findByStateCode(String code) {

		List<State> lst = (List<State>) refList(ServiceConstants.STAT_LST_STATE);

		for (State obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getStateCode())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public List<City> cityList() {
		return (List<City>) refList(ServiceConstants.STAT_LST_CITY);
	}


	@SuppressWarnings("unchecked")
	public City city(String cityCode) {

		List<City> cityLst = (List<City>) refList(ServiceConstants.STAT_LST_CITY);

		for (City city : cityLst) {

			if (BaseUtil.isEqualsCaseIgnore(cityCode, city.getCityCode())) {
				return city;
			}
		}
		return null;
	}


	public String cityDesc(String cityCode) {
		City city = city(cityCode);
		if (!BaseUtil.isObjNull(city)) {
			return city.getDescEn();
		}
		return "";
	}


	@SuppressWarnings("unchecked")
	public List<City> cityList(String state) {

		List<City> lst = (List<City>) refList(ServiceConstants.STAT_LST_CITY);

		List<City> newLst = new ArrayList<>();

		for (City obj : lst) {

			if (BaseUtil.isEqualsCaseIgnore(state, obj.getState())) {
				newLst.add(obj);
			}
		}

		Collections.sort(newLst, new Comparator<City>() {

			@Override
			public int compare(City o1, City o2) {
				return o1.getState().compareTo(o2.getState());
			}
		});

		return newLst;
	}


	@SuppressWarnings("unchecked")
	public List<Country> countryList() {
		return (List<Country>) refList(ServiceConstants.COUNTRY_LST);
	}


	@SuppressWarnings("unchecked")
	public List<Country> countrySourceList() {
		List<Country> lst = (List<Country>) refList(ServiceConstants.COUNTRY_LST);
		List<Country> newLst = new ArrayList<>();
		for (Country obj : lst) {
			if (!obj.getCntryInd().isEmpty()) {
				newLst.add(obj);
			}
		}

		Collections.sort(newLst, new Comparator<Country>() {

			@Override
			public int compare(Country o1, Country o2) {
				return o1.getCntryInd().compareTo(o2.getCntryInd());
			}
		});
		return newLst;
	}


	@SuppressWarnings("unchecked")
	public Country country(String code) {
		List<Country> lst = (List<Country>) refList(ServiceConstants.COUNTRY_LST);
		for (Country obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getCntryCode())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public String countryDesc(String code) {
		List<Country> lst = (List<Country>) refList(ServiceConstants.COUNTRY_LST);
		for (Country obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getCntryCode())) {
				return obj.getCntryDesc();
			}
		}
		return "";
	}


	@SuppressWarnings("unchecked")
	public List<RelationShip> findAllRelationShips() {
		return (List<RelationShip>) refList(ServiceConstants.STAT_LST_RELATIONSHIP);
	}


	@SuppressWarnings("unchecked")
	public List<Gender> findAllGenders() {
		return (List<Gender>) refList(ServiceConstants.STAT_LST_GENDER);
	}


	@SuppressWarnings("unchecked")
	public Gender findByGenderCd(String code) {
		List<Gender> lst = (List<Gender>) refList(ServiceConstants.STAT_LST_GENDER);
		for (Gender obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getGenderCd())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public List<Status> statusList() {
		return (List<Status>) refList(ServiceConstants.STAT_LST_STATUS);
	}


	@SuppressWarnings("unchecked")
	public List<Status> findAllStatus() {
		return (List<Status>) refList(ServiceConstants.STAT_LST_STATUS);
	}


	@SuppressWarnings("unchecked")
	public Status findByStatusCd(String code) {

		List<Status> lst = (List<Status>) refList(ServiceConstants.STAT_LST_STATUS);

		for (Status obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getStatusCode())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public List<Country> findAllCountry() {
		return (List<Country>) refList(ServiceConstants.COUNTRY_LST);
	}


	@SuppressWarnings("unchecked")
	public List<Status> status(String statusType) {
		List<Status> statusList = (List<Status>) refList(ServiceConstants.STAT_LST_STATUS);
		List<Status> statLst = new ArrayList<>();
		if (statusType != null && !BaseUtil.isListNullZero(statusList)) {
			for (Status stat : statusList) {
				if (BaseUtil.isEqualsCaseIgnore(statusType, stat.getStatusType())) {
					statLst.add(stat);
				}
			}
		}
		return statLst;
	}


	public String statusDescByStatusType(String code, String statusType) {
		List<Status> lst = status(statusType);
		for (Status obj : lst) {
			if (BaseUtil.isEqualsCaseIgnoreAny(statusType, obj.getStatusType())
					&& BaseUtil.isEqualsCaseIgnore(code, obj.getStatusCode())) {
				return obj.getStatusDescEn();
			}
		}
		return null;
	}


	public Status statusByStatusTypeStatusCode(String code, String statusType) {
		List<Status> lst = status(statusType);
		for (Status obj : lst) {
			if (BaseUtil.isEqualsCaseIgnoreAny(statusType, obj.getStatusType())
					&& BaseUtil.isEqualsCaseIgnore(code, obj.getStatusCode())) {
				return obj;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public String statusDesc(String code) {
		List<Status> lst = (List<Status>) refList(ServiceConstants.STAT_LST_STATUS);
		for (Status obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getStatusCode())) {
				return obj.getStatusDescEn();
			}
		}
		return "";
	}

}