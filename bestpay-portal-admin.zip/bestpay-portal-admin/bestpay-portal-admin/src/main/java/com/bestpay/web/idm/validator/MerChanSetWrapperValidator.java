package com.bestpay.web.idm.validator;


import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.web.core.AbstractController;


@Component("merChanSetWrapperValidator")
public class MerChanSetWrapperValidator extends AbstractController implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}


	@Override
	public void validate(Object object, Errors errors) {
		// channel setting validation
	}
}
