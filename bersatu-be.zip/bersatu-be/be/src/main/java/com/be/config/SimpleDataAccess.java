/**
 * Copyright 2019
 */
package com.be.config;


import java.util.Collection;
import java.util.List;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 17, 2018
 */
public interface SimpleDataAccess<S> {

	S create(final S s);


	S update(final S s);


	Collection<S> updateAll(final Collection<S> s);


	S find(final Integer id);


	List<S> findAll();


	boolean delete(final Integer id);


	Collection<S> deleteAll(final Collection<S> s);

}
