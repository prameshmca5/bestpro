/**
 * 
 */
package com.be.client;

import java.lang.reflect.Field;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.http.Header;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.util.BaseUtil;

/**
 * @author michelle.angela
 *
 */
public class IntegrationServiceClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(IntegrationServiceClient.class);

	private static IntegrationServiceClient instance = null;

	private static IntegrationRestTemplate restTemplate;

	private static Properties prop;

	private String url;

	private String clientId;

	private String token;

	private String authToken;

	private String messageId;
	
	private int readTimeout;

	private IntegrationServiceClient() {}
	
	public IntegrationServiceClient(String url) {
		this.url = url;
		initialize();
	}

	public IntegrationServiceClient(String url, int readTimeout) {
		this.url = url;
		this.readTimeout = readTimeout;
		initialize();
	}
	
	public IntegrationServiceClient(String url, String clientId, int readTimeout) {
		this.url = url;
		this.clientId = clientId;
		this.readTimeout = readTimeout;
		initialize();
	}

	private static IntegrationServiceClient getInstance() {
		if (instance == null) {
			instance = new IntegrationServiceClient();
		}

		return instance;
	}

	private void initialize() {
		restTemplate = new IntegrationRestTemplate();
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	
	public void setUrl(String url) {
		this.url = url;
	}
	
	public void setReadTimeout(int readTimeout) {
		this.readTimeout = readTimeout;
	}
	
	public static void setRestTemplate(IntegrationRestTemplate restTemplate) {
		IntegrationServiceClient.restTemplate = restTemplate;
	}

	private IntegrationRestTemplate getRestTemplate() throws Exception {
//		CloseableHttpClient httpClient = HttpClients.createDefault();
//		if (messageId == null) {
//			throw new BeException(BeErrorCodeEnum.E400C001);
//		}
//		if (authToken != null) {
//			httpClient = new HttpAuthClient(authToken, messageId, readTimeout).getHttpClient();
//		} else {
//			httpClient = new HttpAuthClient(clientId, token, messageId, readTimeout).getHttpClient();
//		}
//		restTemplate.setHttpClient(httpClient);
		return restTemplate;
	}
	
	private IntegrationRestTemplate getRestTemplateDefault() throws Exception {
		return restTemplate;
	}

	private String getServiceURI(String serviceName) {
		String uri = url + serviceName;
		LOGGER.info("Service Rest URL: " + uri);
		return uri;
	}
	
	@SuppressWarnings("rawtypes")
	private String getServiceURI(String serviceName, Object param){	
		if(serviceName.contains("${rest.default.url}")) serviceName = serviceName.replace("${rest.default.url}", prop.getProperty("rest.default.url"));
		if(serviceName.contains("${version}")) serviceName = serviceName.replace("${version}", prop.getProperty("version"));
		String uri = url + serviceName;
		LOGGER.info("Service Rest URL: " + uri);
		for(Field f : param.getClass().getDeclaredFields()){
			 try {
				 f.setAccessible(true);
				 Object obj = f.get(param);
				 if(!BaseUtil.isObjNull(obj)) {
					 if(String.class == f.getType()) {
						 uri = uri + "&" + f.getName() + "=" + (String) obj;
					 } else if(Integer.class == f.getType()) {
						 uri = uri + "&" + f.getName() + "=" + obj;
					 } else if(Long.class == f.getType()) {
						 uri = uri + "&" + f.getName() + "=" + obj;
					 } else if(Date.class == f.getType()) {
						 uri = uri + "&" + f.getName() + "=" + obj;
					 } else if(List.class == f.getType()) {
						 List lst = (List) obj;
						 String str = "";
						 for (Iterator iterator = lst.iterator(); iterator.hasNext();) {
							Object object = (Object) iterator.next();
							str = str + "," + object;
						 }
						 uri = uri + "&" + f.getName() + "=" + str.substring(1, str.length());
					 }
				 }
			} catch (Exception e) {
				LOGGER.info(e.getMessage());
				continue;
			}
		}
		return uri;
	}
	
	@SuppressWarnings("rawtypes")
	private String getServiceURI(String serviceName, Set<Map.Entry<String, Object>> reqParams) {
		if (serviceName.contains("${prefix}")) serviceName = serviceName.replace("${prefix}", prop.getProperty("prefix"));
		if (serviceName.contains("${version}")) serviceName = serviceName.replace("${version}", prop.getProperty("version"));
		StringBuffer sb = new StringBuffer();
		sb.append(url + serviceName);
		
		if(!BaseUtil.isObjNull(reqParams)) {
			sb.append("?1=1");
			for(Map.Entry<String, Object> entry : reqParams) {
				if(!BaseUtil.isObjNull(entry.getValue())) {
					LOGGER.info("PARAMS: {} - {}", entry.getKey(), entry.getValue() );
					if(entry.getValue() instanceof List) {
						List lst = (List) entry.getValue();
						String str = "";
						for (Iterator iterator = lst.iterator(); iterator.hasNext();) {
							Object object = (Object) iterator.next();
							str = str + "," + object;
						}
						sb.append("&" + entry.getKey() + "=" + str.substring(1, str.length()));
					} else {
						sb.append("&" + entry.getKey() + "=" + entry.getValue());
					}
				}
			}
		}
		
		LOGGER.info("Service Rest URL: " + sb.toString());
		return sb.toString();
	}
	
	public <T> T getForObject(String url, Class<T> responseType) throws Exception {
		return getRestTemplate().getForObject(getServiceURI(url), responseType);
	}
	
	public <T> T getForObject(String url, Object param, Class<T> responseType) throws Exception {
		return getRestTemplate().getForObject(getServiceURI(url, param), responseType);
	}
	
	public <T> T getForObject(String url, Set<Map.Entry<String, Object>> reqParams, Class<T> responseType) throws Exception {
		return getRestTemplate().getForObject(getServiceURI(url, reqParams), responseType);
	}
	
	public <T> T getForObject(String url, Map<String, Object> urlVariables, Class<T> responseType) throws Exception {
		return getRestTemplate().getForObject(getServiceURI(url), responseType, urlVariables, null);
	}
	
	public <T> T getForObject(String url, Set<Map.Entry<String, Object>> reqParams, Map<String, Object> urlVariables, Class<T> responseType) throws Exception {
		return getRestTemplate().getForObject(getServiceURI(url, reqParams), responseType, urlVariables, null);
	}
	
	public <T> T getForObject(String url, Class<T> responseType, Map<String, String> headers) throws Exception {
		return getRestTemplate().getForObject(getServiceURI(url), responseType, headers);
	}
	
	public <T> T postForObject(String url, Object requestBody, Class<T> responseType) throws Exception {
		return getRestTemplate().postForObject(getServiceURI(url), requestBody, responseType);
    }
	
	public <T> T postForObject(String url, Set<Map.Entry<String, Object>> reqParams, Object requestBody, Class<T> responseType) throws Exception {
		return getRestTemplate().postForObject(getServiceURI(url, reqParams), requestBody, responseType);
    }
    
    public <T> T postForObject(String url, Object requestBody, Class<T> responseType, Map<String, Object> uriVariables) throws Exception {
    	return getRestTemplate().postForObject(getServiceURI(url), requestBody, responseType, uriVariables);
    }
    
    public <T> T postForObject(String url, Set<Map.Entry<String, Object>> reqParams, Object requestBody, Class<T> responseType, Map<String, Object> uriVariables) throws Exception {
    	return getRestTemplate().postForObject(getServiceURI(url, reqParams), requestBody, responseType, uriVariables);
    }
    
    public boolean deleteForObject(String url) throws Exception {
    	return getRestTemplate().deleteForObject(getServiceURI(url));
    }
    
    public boolean deleteForObject(String url, Map<String, Object> uriVariables) throws Exception {
    	return getRestTemplate().deleteForObject(getServiceURI(url), uriVariables);
    }
	
    public Object putForObject(String url, Map<String, Object> uriVariables) throws Exception {
    	return getRestTemplate().putForObject(getServiceURI(url), uriVariables);
    }

    public Object putForObject(String url, Object requestBody, Map<String, Object> uriVariables) throws Exception {
    	return getRestTemplate().putForObject(getServiceURI(url), requestBody, uriVariables);
    }
    
    public <T> T postForObjectDefault(String url, Object requestBody, Class<T> responseType) throws Exception {
		return getInstance().postForObject(getServiceURI(url), requestBody, responseType);
    }
    
    public <T> T postForObjectResp(String url, Object requestBody, Class<T> responseType, String apiKey) throws Exception {
		return getRestTemplate().postForObjectResp(url, requestBody, responseType, apiKey);
    }
    
    public <T> T postForObjectResp(String url, Object requestBody, Class<T> responseType, Map<String, String> headers) throws Exception {
		return getRestTemplate().postForObjectResp(url, requestBody, responseType, headers);
    }
}
