package com.bestpay.pgw.sdk.constants;


public class PgwFPXConstants {

	public static final String FPX_MSG_BE = "BE";

	public static final String FPX_MSG_AR = "AR";

	public static final String FPX_MSG_AE = "AE";

	public static final String FPX_MSG_TOKEN_B2C = "01";

	public static final String FPX_MSG_TOKEN_B2B = "02";

	public static final String FPX_TRANS_CURRENCY = "MYR";

	public static final String FPX_VERSION = "7.0";

	public static final String PAY_TYPE_B2C = "B2C";

	public static final String PAY_TYPE_B2B = "B2B";

	public static final String FPX_BANK_CODE = "01";

	public static final String FPX_RESPONSE_CODE_00 = "00";

	public static final String FPX_RESPONSE_CODE_01 = "01";

	public static final String FPX_RESPONSE_CODE_99 = "99"; // if response code
													// 99 means
													// pending for
													// approval

	public static final String FPX_RESPONSE_CODE_09 = "09";

	public static final String FPX_RESPONSE_CODE_12 = "12";

	public static final String PAY_FPX_CHANNEL_B2C = "B2C";

	public static final String PAY_FPX_CHANNEL_B2B = "B2B";


	private PgwFPXConstants() {
	}
}
