
package com.bestpay.be.sdk.model;


import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "nationality:Malaysian", "isPEP:false" })
public class RiskScoreCard {

	@JsonProperty("nationality:Malaysian")
	private String nationalityMalaysian;

	@JsonProperty("isPEP:false")
	private String isPEPFalse;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<>();


	@JsonProperty("nationality:Malaysian")
	public String getNationalityMalaysian() {
		return nationalityMalaysian;
	}


	@JsonProperty("nationality:Malaysian")
	public void setNationalityMalaysian(String nationalityMalaysian) {
		this.nationalityMalaysian = nationalityMalaysian;
	}


	@JsonProperty("isPEP:false")
	public String getIsPEPFalse() {
		return isPEPFalse;
	}


	@JsonProperty("isPEP:false")
	public void setIsPEPFalse(String isPEPFalse) {
		this.isPEPFalse = isPEPFalse;
	}


	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return additionalProperties;
	}


	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		additionalProperties.put(name, value);
	}

}
