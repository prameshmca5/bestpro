/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.config;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bestpay.be.service.MessageService;
import com.bestpay.idm.sdk.client.IdmServiceClient;
import com.bestpay.report.sdk.client.ReportServiceClient;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
@Configuration
public class ServiceConfig implements InitializingBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceConfig.class);

	@Autowired
	MessageService messageService;

	private String idmUrl;

	private int idmTimeout;

	private String reportUrl;

	private int reportTimeout;


	@Bean
	public IdmServiceClient idmService() {
		return new IdmServiceClient(idmUrl, idmTimeout);
	}


	@Bean
	public ReportServiceClient reportService() {
		return new ReportServiceClient(reportUrl, reportTimeout);
	}


	@Override
	public void afterPropertiesSet() throws Exception {
		idmUrl = messageService.getMessage(ConfigConstants.SVC_IDM_URL);
		idmTimeout = Integer.valueOf(messageService.getMessage(ConfigConstants.SVC_IDM_TIMEOUT));
		reportUrl = messageService.getMessage(ConfigConstants.SVC_RPT_URL);
		reportTimeout = Integer.valueOf(messageService.getMessage(ConfigConstants.SVC_RPT_TIMEOUT));

		LOGGER.info("\n[Integration Service :: \n\tIDM Service :: {} \t- Timeout (seconds) :: {} \n", idmUrl,
				idmTimeout);
	}

}