package com.be.service;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.controller.McAttendanceRestController;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeDoctorProfileRepository;
import com.be.dao.BeMcProfileRepository;
import com.be.dao.BeTvlTestResultRepository;
import com.be.model.BeConfigMcCollate;
import com.be.model.BeDoctorProfile;
import com.be.model.BeMcProfile;
import com.be.model.BeTvl;
import com.be.model.BeTvlMcCollate;
import com.be.model.BeTvlProfile;
import com.be.model.BeTvlTestResult;
import com.be.model.RefDocument;
import com.be.model.RefMetadata;
import com.be.sdk.constants.BeServiceConstants;
import com.be.sdk.constants.FileUploadConstants;
import com.be.sdk.constants.MailTemplateConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.DigitalSigning;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.McCollate;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlProfile;
import com.be.sdk.model.TvlTestResult;
import com.dm.sdk.model.Documents;
import com.idm.sdk.exception.IdmException;
import com.idm.sdk.model.Fcm;
import com.idm.sdk.model.FcmDevice;
import com.idm.sdk.model.UserProfile;
import com.notify.sdk.constants.MailTypeEnum;
import com.notify.sdk.model.Notification;
import com.notify.sdk.util.MailUtil;
import com.report.sdk.constants.ReportTypeEnum;
import com.report.sdk.model.Report;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.UidGenerator;


/**
 * @author Atiqah Khairuddin
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_TEST_RESULT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_TEST_RESULT_SVC)
public class BeTvlTestResultService extends AbstractService<BeTvlTestResult> {

	private static final Logger LOGGER = LoggerFactory.getLogger(McAttendanceRestController.class);

	@Autowired
	private BeTvlTestResultRepository beTvlTestResulDao;

	@Autowired
	BeTvlService beTvlSvc;

	@Autowired
	BeTvlMcCollateService beTvlMcCollateServicevc;

	@Autowired
	BeTrxnDocumentService beTrxnDocumentSvc;

	@Autowired
	BeMcProfileRepository beMcProfileDao;

	@Autowired
	BeDoctorProfileRepository beDoctorProfileDao;

	@Autowired
	RefDocumentService documentSvc;

	@Autowired
	BeTrxnDocumentService trxnDocumentSvc;

	@Autowired
	IntegrationService integrationSvc;


	@Override
	public GenericRepository<BeTvlTestResult> primaryDao() {
		return beTvlTestResulDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class })
	public BeTvlTestResult updateApprovedMedicalInfo(TvlTestResult dto, BeTvlProfile beTvlProfile, String userId,
			HttpServletRequest request) throws IOException {

		BeTvlTestResult beTvlTestResult = beTvlTestResulDao.findByTvlProfile(dto.getTvlProfId());

		if (BaseUtil.isObjNull(beTvlTestResult)) {
			beTvlTestResult = new BeTvlTestResult();
			beTvlTestResult.setMcRefNo(UidGenerator.generateUid(BeServiceConstants.MC_PREFIX));
			beTvlTestResult.setMcProfId(dto.getMcProfId());
			beTvlTestResult.setTvlProfile(beTvlProfile);
			beTvlTestResult.setDocRefNo(UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC));
			beTvlTestResult.setCntryCd(dto.getCntryCd());
			beTvlTestResult.setRemarks(dto.getRemarks());
			beTvlTestResult.setCreateId(userId);
		}

		beTvlTestResult.setMedTestDt(dto.getMedTestDt());
		beTvlTestResult.setDoctorProfId(dto.getDoctorProfId());
		beTvlTestResult.setMedicalResult(dto.getMedicalResult());
		beTvlTestResult.setDoctorRemarks(dto.getDoctorRemarks());
		beTvlTestResult.setStatusId(dto.getStatusId());
		beTvlTestResult.setUpdateId(userId);
		beTvlTestResult = update(beTvlTestResult);

		LOGGER.debug("test result id : {}", beTvlTestResult.getTvlTestResultId());

		if (!BaseUtil.isObjNull(dto.getStatusId())) {
			beTvlSvc.updateStatus(beTvlProfile.getTvlProfId(), dto.getStatusId());
		}

		if (!BaseUtil.isListNull(dto.getMcCollates())) {

			for (McCollate mcCollate : dto.getMcCollates()) {

				RefMetadata metadata = new RefMetadata();
				metadata.setMtdtId(mcCollate.getResultMtdt().getMtdtId());

				BeConfigMcCollate beConfigMcCollate = new BeConfigMcCollate();
				beConfigMcCollate.setMcCollateId(mcCollate.getConfigMcCollate().getMcCollateId());

				BeTvlMcCollate beTvlMcCollate = beTvlMcCollateServicevc.findBeTvlMcCollate(
						beTvlTestResult.getTvlTestResultId(), beConfigMcCollate.getMcCollateId());

				if (BaseUtil.isObjNull(beTvlMcCollate)) {
					beTvlMcCollate = new BeTvlMcCollate();
					beTvlMcCollate.setTvlTestResult(beTvlTestResult);
					beTvlMcCollate.setConfigMcCollate(beConfigMcCollate);
					beTvlMcCollate.setCreateId(userId);
				}
				beTvlMcCollate.setResultMtdt(metadata);
				beTvlMcCollate.setUpdateId(userId);
				beTvlMcCollate = beTvlMcCollateServicevc.update(beTvlMcCollate);
			}
		}

		if (!BaseUtil.isListNull(dto.getTrxnDocumentList())) {
			beTrxnDocumentSvc.createUpdate(dto.getTrxnDocumentList(), userId, beTvlTestResult.getDocRefNo());
		}

		return beTvlTestResult;
	}


	private void sendingNotification(BeTvlTestResult beTvlTestResult, BeTvlProfile beTvlProfile,
			HttpServletRequest request) {
		try {
			// any error here will be consume by void
			String templateFcm = null;
			if (beTvlTestResult.getMedicalResult().compareTo(1) == 0) {
				templateFcm = MailTemplateConstants.FCM_MEDICAL_RESULT_FIT;
			} else if (beTvlTestResult.getMedicalResult().compareTo(0) == 0) {
				templateFcm = MailTemplateConstants.FCM_MEDICAL_RESULT_UNFIT;
			}
			Tvl tvlDto = new Tvl();
			tvlDto.setTvlProfile(new TvlProfile());
			tvlDto.getTvlProfile().setTvlProfId(beTvlProfile.getTvlProfId());
			tvlDto.setEmbedTraveller(true);
			BeTvl beTvl = beTvlSvc.searchBeTravel(tvlDto);
			Integer profId = beTvl.getAcctProfile().getAcctProfId();
			String userType = "TVL";
			// UserProfile profile =
			// getIdmService(request).getUserProfileByProfId(profId, false,
			// false);
			UserProfile profile = getIdmService(request).getUserProfileByProfIdUserType(profId, userType, false,
					false);

			Map<String, Object> datamap = new LinkedHashMap<>();
			datamap.put("passportNo", beTvlProfile.getAcctPassport().getPassportNo());
			datamap.put("medTestDt",
					!BaseUtil.isObjNull(beTvlTestResult.getMedTestDt())
							? DateUtil.getFormatBigEndianWithSlash(beTvlTestResult.getMedTestDt())
							: null);
			List<FcmDevice> devices = searchAllDevice(profile, request);
			addFCMNotification(devices, profile, datamap, templateFcm, request);
		} catch (Exception e) {
			// safety reason : ignore and check if
			// payload created
		}
	}


	private List<FcmDevice> searchAllDevice(UserProfile userProfile, HttpServletRequest request) throws IdmException {
		FcmDevice fcmDevice = new FcmDevice();
		fcmDevice.setStatus(true);

		Fcm fcm = new Fcm();
		fcm.setUserId(userProfile.getUserId());
		fcm.setStatus(true);
		fcmDevice.setFcm(fcm);

		return getIdmService(request).searchFcmDevice(fcmDevice);
	}


	private void addFCMNotification(List<FcmDevice> devices, UserProfile userProfile, Map<String, Object> map,
			String template, HttpServletRequest request) {
		if (!BaseUtil.isObjNull(userProfile)) {
			if (!BaseUtil.isListNull(devices)) {
				for (FcmDevice device : devices) {
					if (!BaseUtil.isObjNull(device.getFcmToken())) {

						Notification notification = new Notification();
						notification.setNotifyTo(userProfile.getUserId());
						notification.setNotifyCc(device.getFcmToken());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setNotifyType(MailTypeEnum.FCM.getType());

						getNotifyService(request).addNotification(notification, template);
					}
				}
			}

		}
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class })
	public void processDocumentAndNotification(BeTvlTestResult beTvlTestResult, BeTvl beTvl,
			HttpServletRequest request) {

		try {
			BeTvlProfile beTvlProfile = beTvl.getTvlProfile();
			List<RefDocument> mcRptDoc = new ArrayList<>();
			Report mcRpt = null;
			List<Documents> docList = new ArrayList<>();
			mcRptDoc = documentSvc.findAllByTrxnNo(FileUploadConstants.DOC_TRXN_MEDICAL_REPORT);
			Tvl tvlDto = new Tvl();
			tvlDto.setTvlProfile(new TvlProfile());
			tvlDto.getTvlProfile().setTvlProfId(beTvlProfile.getTvlProfId());
			tvlDto.setStatusId(beTvlTestResult.getStatusId());

			if (!BaseUtil.isListNull(mcRptDoc)) {
				mcRpt = getReportService(request).report().genMedicalReport(tvlDto, ReportTypeEnum.PDF);
				if (!BaseUtil.isObjNull(mcRpt.getReportBytes())) {
					DigitalSigning digitalSigning = integrationSvc.docDigitalSigning(mcRpt.getReportBytes(),
							mcRptDoc.get(0).getDocDesc(), "R");
					mcRpt.setReportBytes(digitalSigning.getContent());
					docList.add(trxnDocumentSvc.upload(mcRptDoc.get(0), mcRpt, beTvlTestResult.getMcRefNo(),
							request));
					trxnDocumentSvc.createUpdateDoc(docList, getCurrUserId(request),
							beTvlTestResult.getDocRefNo());
				}
			}

			BeTvlProfile tvlProfile = beTvlTestResult.getTvlProfile();
			if (!BaseUtil.isObjNull(tvlProfile)) {
				Map<String, Object> map = new HashMap<>();
				map.put("fullName", tvlProfile.getFullName());
				if (!BaseUtil.isObjNull(beTvlTestResult.getMcProfId())) {
					BeMcProfile beMcProfile = beMcProfileDao.findOne(beTvlTestResult.getMcProfId());
					if (!BaseUtil.isObjNull(beMcProfile)) {
						map.put("mcName", beMcProfile.getMcName());
					}

				}
				map.put("mcDt",
						!BaseUtil.isObjNull(beTvlTestResult.getMedTestDt())
								? DateUtil.getFormatBigEndianWithSlash(beTvlTestResult.getMedTestDt())
								: null);
				map.put("passportNo",
						!BaseUtil.isObjNull(beTvlProfile.getAcctPassport())
								? beTvlProfile.getAcctPassport().getPassportNo()
								: null);
				map.put("nationality",
						!BaseUtil.isObjNull(beTvlProfile.getAcctPassport().getNationality())
								? beTvlProfile.getAcctPassport().getNationality().getCntryDesc()
								: null);
				map.put("gender", BaseUtil.isEquals(beTvlProfile.getGender(), "M") ? "MALE" : "FEMALE");
				map.put("screenDt",
						!BaseUtil.isObjNull(beTvlTestResult.getMedTestDt())
								? DateUtil.getFormatBigEndianWithSlash(beTvlTestResult.getMedTestDt())
								: null);

				if (!BaseUtil.isObjNull(beTvlTestResult.getDoctorProfId())) {
					BeDoctorProfile beDoctorProfile = beDoctorProfileDao
							.findOne(beTvlTestResult.getDoctorProfId());
					if (!BaseUtil.isObjNull(beDoctorProfile)) {
						map.put("aprvdBy", beDoctorProfile.getFullName());
					}
				}

				String templateCode = null;
				if (beTvlTestResult.getMedicalResult().compareTo(0) == 0) {
					templateCode = MailTemplateConstants.MED_RESULT_POSITIVE;
				} else if (beTvlTestResult.getMedicalResult().compareTo(1) == 0) {
					templateCode = MailTemplateConstants.MED_RESULT_NEGATIVE;
				}

				if (!BaseUtil.isObjNull(beTvl.getAcctProfile()) && !BaseUtil.isObjNull(templateCode)) {
					Notification notification = new Notification();
					notification.setNotifyTo(beTvl.getAcctProfile().getEmail());
					notification.setMetaData(MailUtil.convertMapToJson(map));
					if (!BaseUtil.isObjNull(mcRpt) && !BaseUtil.isListNull(mcRptDoc)) {
						notification.setAttachments(new ArrayList<>());
						notification.getAttachments().add(setNotificationAttachments(mcRpt, mcRptDoc.get(0)));
					}
					getNotifyService(request).addNotification(notification, templateCode);

					sendingNotification(beTvlTestResult, beTvlProfile, request);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BeException(e.getMessage());
		}
	}

}
