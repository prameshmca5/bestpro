package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.util.List;
import java.util.Map;


public class BankStatement implements Serializable {

	private static final long serialVersionUID = -5658698593122809192L;

	private Integer fnclInfoId;

	private String bankName;

	private String bankCode;

	private String acctNo;

	// @NumberFormat(style = Style.NUMBER, pattern = "#,###")
	private Double acctBal;

	private String month;

	private Map<Integer, String> months;

	private String errors;

	private List<FileUpload> fileItemList;

	private FileUpload fileItem;

	private String bankStmtDocId;

	private String numAccount;

	private boolean canJtkAksEdit;


	public BankStatement() {
	}


	public BankStatement(Integer fnclInfoId, String bankName, String acctNo, Double acctBal) {
		this.fnclInfoId = fnclInfoId;
		this.bankName = bankName;
		this.acctNo = acctNo;
		this.acctBal = acctBal;
	}


	public BankStatement(Integer fnclInfoId, String bankName, String acctNo, Double acctBal, String bankStmtDocId) {
		this.fnclInfoId = fnclInfoId;
		this.bankName = bankName;
		this.acctNo = acctNo;
		this.acctBal = acctBal;
		this.bankStmtDocId = bankStmtDocId;
	}


	public Integer getFnclInfoId() {
		return fnclInfoId;
	}


	public void setFnclInfoId(Integer fnclInfoId) {
		this.fnclInfoId = fnclInfoId;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getBankCode() {
		return bankCode;
	}


	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}


	public String getAcctNo() {
		return acctNo;
	}


	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}


	public Double getAcctBal() {
		return acctBal;
	}


	public void setAcctBal(Double acctBal) {
		this.acctBal = acctBal;
	}


	public String getMonth() {
		return month;
	}


	public void setMonth(String month) {
		this.month = month;
	}


	public Map<Integer, String> getMonths() {
		return months;
	}


	public void setMonths(Map<Integer, String> months) {
		this.months = months;
	}


	public String getErrors() {
		return errors;
	}


	public void setErrors(String errors) {
		this.errors = errors;
	}


	public String getBankStmtDocId() {
		return bankStmtDocId;
	}


	public void setBankStmtDocId(String bankStmtDocId) {
		this.bankStmtDocId = bankStmtDocId;
	}


	public List<FileUpload> getFileItemList() {
		return fileItemList;
	}


	public void setFileItemList(List<FileUpload> fileItemList) {
		this.fileItemList = fileItemList;
	}


	public void setFileItem(FileUpload fileItem) {
		this.fileItem = fileItem;
	}


	public FileUpload getFileItem() {
		return fileItem;
	}


	public String getNumAccount() {
		return numAccount;
	}


	public void setNumAccount(String numAccount) {
		this.numAccount = numAccount;
	}


	public boolean isCanJtkAksEdit() {
		return canJtkAksEdit;
	}


	public void setCanJtkAksEdit(boolean canJtkAksEdit) {
		this.canJtkAksEdit = canJtkAksEdit;
	}

}
