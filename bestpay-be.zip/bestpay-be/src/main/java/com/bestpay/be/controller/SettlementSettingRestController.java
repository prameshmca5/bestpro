/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwBankDetails;
import com.bestpay.be.model.PgwMerchantProvider;
import com.bestpay.be.model.PgwSettlement;
import com.bestpay.be.model.PgwSettlementConfig;
import com.bestpay.be.model.PgwTransaction;
import com.bestpay.be.model.PgwTransactionAmount;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerSettlementSet;
import com.bestpay.be.sdk.model.TransactionRptInfo;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.service.PgwBankDetailsService;
import com.bestpay.be.service.PgwMerchantProviderService;
import com.bestpay.be.service.PgwTransactionService;
import com.bestpay.be.util.BaseConstants;
import com.bestpay.notify.sdk.constants.MailTemplate;
import com.bestpay.notify.sdk.constants.MailTypeEnum;
import com.bestpay.notify.sdk.model.MailAttachment;
import com.bestpay.notify.sdk.model.Notification;
import com.bestpay.notify.sdk.util.MailUtil;
import com.bestpay.report.sdk.exception.ReportException;
import com.bestpay.report.sdk.model.Report;
import com.bstsb.util.DateUtil;
import com.bstsb.util.MediaType;


/**
 * @author Afif Saman
 * @since July 24, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.STTLMNT_SET)
public class SettlementSettingRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(SettlementSettingRestController.class);

	private static final String INCENTIVE_REMIT = "INCENTIVE_REMIT";

	@Autowired
	protected PgwTransactionService pgwTransactionSvc;

	@Autowired
	protected PgwBankDetailsService pgwBankDetailsSvc;

	@Autowired
	protected PgwMerchantProviderService pgwMerchantProviderServiceSvc;


	@GetMapping(value = "/{merchantId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerSettlementSet getMerSettlementSetById(@PathVariable String merchantId) {

		PgwSettlementConfig pgwSettlementConfig = pgwSettlementConfigService
				.findSettlementConfigByMerchantId(merchantId);
		PgwSettlement recentSettlements = pgwSettlementService.findRecentSettlementByMerchId(merchantId);
		PgwSettlement nextSettlements = pgwSettlementService.findNextSettlementByMerchId(merchantId);
		MerSettlementSet merSettlementSet = new MerSettlementSet();
		if (!BaseUtil.isObjNull(pgwSettlementConfig)) {
			merSettlementSet = dozerMapper.map(pgwSettlementConfig, MerSettlementSet.class);
			settlementSet(merSettlementSet, recentSettlements, nextSettlements);
		}
		return merSettlementSet;
	}


	private void settlementSet(MerSettlementSet merSettlementSet, PgwSettlement recentSettlements,
			PgwSettlement nextSettlements) {
		if (!BaseUtil.isObjNull(merSettlementSet.getReserveDay()) && merSettlementSet.getReserveDay() == 1) {
			if (!BaseUtil.isObjNull(recentSettlements)) {
				merSettlementSet.setRecentSettleDt(getMondayOfNextWeek(recentSettlements.getSettleDate()));
			}
			if (!BaseUtil.isObjNull(nextSettlements)) {
				merSettlementSet.setNextSettleDt(getMondayOfNextWeek(nextSettlements.getSettleDate()));
			}
		} else if (!BaseUtil.isObjNull(merSettlementSet.getReserveDay()) && merSettlementSet.getReserveDay() == 2) {
			if (!BaseUtil.isObjNull(recentSettlements)) {
				merSettlementSet.setRecentSettleDt(getFirstDateOfNextMonth(recentSettlements.getSettleDate()));
			}
			if (!BaseUtil.isObjNull(nextSettlements)) {
				merSettlementSet.setNextSettleDt(getFirstDateOfNextMonth(nextSettlements.getSettleDate()));
			}
		}
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public boolean updateSettlementSetting(@Valid @RequestBody MerSettlementSet merSettlementSet,
			HttpServletRequest request, HttpServletResponse response) throws BeException {

		LOGGER.info("Create new Settlement Setting ... ");
		if (merSettlementSet == null) {// Settlement Setting null
			throw new BeException(BeErrorCodeEnum.E404SSC001);
		}

		PgwSettlementConfig pgwSettlementConfig = pgwSettlementConfigService
				.findSettlementConfigByMerchantId(merSettlementSet.getMerchantId());
		if (BaseUtil.isObjNull(pgwSettlementConfig)) {
			PgwSettlementConfig newSttlmntConfig = dozerMapper.map(merSettlementSet, PgwSettlementConfig.class);
			newSttlmntConfig.setCreateId(merSettlementSet.getUserId());
			newSttlmntConfig.setUpdateId(merSettlementSet.getUserId());
			super.pgwSettlementConfigService.create(newSttlmntConfig);
		} else {
			pgwSettlementConfig.setReserveDay(merSettlementSet.getReserveDay());
			pgwSettlementConfig.setUpdateId(merSettlementSet.getUserId());
			super.pgwSettlementConfigService.update(pgwSettlementConfig);
		}

		return true;
	}


	@GetMapping(value = BeUrlConstants.SETTLEMENT, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public void setSettlements(@RequestParam(value = "channel", required = true) String channel,
			@RequestParam(value = "merchantId", required = true) String merchantId,
			@RequestParam(value = "fromDate", required = true) String fromDate,
			@RequestParam(value = "toDate", required = true) String toDate, HttpServletRequest request)
			throws ParseException, ReportException {
		int reserveDay = -1;
		if ((channel != null && !channel.isEmpty()) && (merchantId != null && !merchantId.isEmpty())
				&& (fromDate != null && !fromDate.isEmpty()) && (toDate != null && !toDate.isEmpty())) {
			Date start = DateUtil.getFormatDate(fromDate, BaseConstants.DT_DD_MM_YYYY_DASH);
			Date end = DateUtil.getFormatDate(toDate, BaseConstants.DT_DD_MM_YYYY_DASH);

			if (BaseUtil.isEquals(channel, INCENTIVE_REMIT)) {
				setSettlementsbyChannel(merchantId, INCENTIVE_REMIT, start, end, 2);
			} else {
				setSettlementsbyMerchantId(merchantId, start, end, reserveDay, request);
			}
		}
	}


	@GetMapping(value = "/settlementTest", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public void setSettlementsTest(@RequestParam(value = "channel", required = false) String channel,
			String merchantId, @RequestParam(value = "fromDate", required = true) String fromDate,
			@RequestParam(value = "toDate", required = true) String toDate, HttpServletRequest request)
			throws ParseException {
		if ((channel != null && !channel.isEmpty()) && (fromDate != null && !fromDate.isEmpty())
				&& (toDate != null && !toDate.isEmpty())) {
			Date start = DateUtil.getFormatDate(fromDate, BaseConstants.DT_DD_MM_YYYY_DASH);
			Date end = DateUtil.getFormatDate(toDate, BaseConstants.DT_DD_MM_YYYY_DASH);

			setSettlementsbyChannel(merchantId, INCENTIVE_REMIT, start, end, 2);
		}
	}


	@GetMapping(value = BeUrlConstants.SETTLEMENT_MONTHLY, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public void setSettlementsMonthly(HttpServletRequest request) throws ParseException, ReportException {
		Date start = new Date();
		Date end = new Date();
		int reserveDay = -1;
		LOGGER.info("Setting monthly Settlements...");
		List<PgwSettlementConfig> pgwSettlementConfigList = pgwSettlementConfigService.findSettlementConfig();
		for (PgwSettlementConfig pgwSettlementconfig : pgwSettlementConfigList) {

			if (!BaseUtil.isObjNull(pgwSettlementconfig)) {

				String merchantId = pgwSettlementconfig.getMerchantId();
				reserveDay = pgwSettlementconfig.getReserveDay();

				if (pgwSettlementconfig.getReserveDay() == 2) {

					start = getFirstDateOfPreviousMonth(start);
					end = getEndDateOfPreviousMonth(end);
					String channelType = "";
					List<PgwTransaction> pgwTransactionFromQuery = pgwTransactionSvc
							.findTransactionByChannelAndSetID(INCENTIVE_REMIT, 0, start, end);

					for (PgwTransaction pgwTransaction : pgwTransactionFromQuery) {
						channelType = pgwTransaction.getChannel();
					}
					if (BaseUtil.isEquals(channelType, INCENTIVE_REMIT)) {
						setSettlementsbyChannel(merchantId, INCENTIVE_REMIT, start, end, 2);
					} else {
						setSettlementsbyMerchantId(merchantId, start, end, reserveDay, request);
					}
				}

			}
			start = new Date();
			end = new Date();
		}
	}


	@GetMapping(value = BeUrlConstants.SETTLEMENT_WEEKLY, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public void setSettlementsWeekly(HttpServletRequest request) throws ParseException, ReportException {
		Date start = new Date();
		Date end = new Date();
		int reserveDay = -1;
		LOGGER.info("Setting weekly Settlements.... ");
		List<PgwSettlementConfig> pgwSettlementConfigList = pgwSettlementConfigService.findSettlementConfig();
		for (PgwSettlementConfig pgwSettlementconfig : pgwSettlementConfigList) {

			if (!BaseUtil.isObjNull(pgwSettlementconfig)) {

				String merchantId = pgwSettlementconfig.getMerchantId();
				reserveDay = pgwSettlementconfig.getReserveDay();
				if (pgwSettlementconfig.getReserveDay() == 1) {
					start = getDate(start, -7);
					end = getDate(end, -1);
					setSettlementsbyMerchantId(merchantId, start, end, reserveDay, request);
				}

			}
			start = new Date();
			end = new Date();
		}
	}


	public void setSettlementsbyMerchantId(String merchantId, Date start, Date end, int reserveDay,
			HttpServletRequest request) throws ParseException, ReportException {

		String email = null;
		List<PgwTransaction> pgwTransactionFromQuery = pgwTransactionSvc.findTransactionByMerchantAndSetID(merchantId,
				0, start, end);

		PgwBankDetails pgwBankDetails = pgwBankDetailsSvc.findBankDetailsByMerchantId(merchantId);

		PgwTransactionAmount pgwTransactionAmount = pgwTransactionSvc.findSumTransactionByMerchantId(merchantId,
				start, end);

		DecimalFormat df = new DecimalFormat("#.##");
		PgwSettlement pgwSettlement = new PgwSettlement();

		if (!BaseUtil.isListNull(pgwTransactionFromQuery)) {
			for (PgwTransaction pgwTran : pgwTransactionFromQuery) {

				pgwSettlement.setMerchantId(pgwTran.getMerchantId());
				if (!BaseUtil.isObjNull(pgwBankDetails)) {
					pgwSettlement.setMerchantBankAcc(pgwBankDetails.getAccountName());
					pgwSettlement.setMerchantAccNo(pgwBankDetails.getAccountNum());
					pgwSettlement.setPsa(pgwBankDetails.getPsa());
				}
				pgwSettlement.setChequeNo(" ");
				pgwSettlement.setBankinSlip(" ");
				pgwSettlement.setCurAmt(pgwTran.getActCur());
				if(pgwTransactionAmount.getBillAmount()!=null) {
					pgwSettlement.setAmount(Double.valueOf(df.format(pgwTransactionAmount.getBillAmount())));
				}else {
					pgwSettlement.setAmount(0.00d);
				}
				if(pgwTransactionAmount.getTransactionRate()!=null) {
					pgwSettlement.setCurrencyRate(Double.valueOf(df.format(pgwTransactionAmount.getTransactionRate())));
				}else {
					pgwSettlement.setCurrencyRate(0.00d);
				}
				pgwSettlement.setCurActAmount(pgwTran.getActCur());
				if(pgwTransactionAmount.getActualAmount()!=null) {
					pgwSettlement.setActualAmount(Double.valueOf(df.format(pgwTransactionAmount.getActualAmount())));
				}else {
					pgwSettlement.setActualAmount(0.00d);
				}
				pgwSettlement.setSettlementFee(0.00d);
				pgwSettlement.setCurCostPenalty("MYR");
				pgwSettlement.setCostPenalty(0.00d);
				pgwSettlement.setCurExtraFee("MYR");
				pgwSettlement.setExtraFee(0.00d);
				pgwSettlement.setCurChargeback("MYR");
				pgwSettlement.setChargeback(0.00d);
				pgwSettlement.setCurRefund("MYR");
				pgwSettlement.setRefund(0.00d);
				pgwSettlement.setCurRefundPart("MYR");
				pgwSettlement.setRefundPart(0.00d);
				pgwSettlement.setCurAdminFee("MYR");
				pgwSettlement.setAdminFee(0.00d);
				pgwSettlement.setCurTransTotalAmt("MYR");
				pgwSettlement.setTransRec(" ");
				pgwSettlement.setMemo("Test");
				pgwSettlement.setModifyDate(new Date());
				pgwSettlement.setCreateDate(new Date());
				pgwSettlement.setSettleDate(new Date());
				pgwSettlement.setDeleted(0);
				pgwSettlement.setStatus("PENDING");
				pgwSettlement.setOrderId(pgwTran.getOrderId());
				pgwSettlement.setCreateDt(new Timestamp(new Date().getTime()));
				pgwSettlement.setUpdateDt(new Timestamp(new Date().getTime()));
				pgwSettlement.setStartDate(start);
				pgwSettlement.setEndDate(end);
				if (reserveDay == 1) {
					pgwSettlement.setReserveDay("WEEKLY");
				} else if (reserveDay == 2) {
					pgwSettlement.setReserveDay("MONTHLY");
				}

				email = pgwTran.getBillingEmail();
			}
			pgwSettlementService.create(pgwSettlement);
			int setId = pgwSettlementService.findSettlementId(merchantId,
					DateUtil.getFormatDate(DateUtil.convertDate(new Date(), BaseConstants.DT_YYYY_MM_DD_DASH),
							BaseConstants.DT_YYYY_MM_DD_DASH));
			LOGGER.info(
					" Settlement Done for Merchant : {} SettlemntId: {} startDate: {} endDate: {}  reserveDay: {} Amount: {} ",
					pgwSettlement.getMerchantId(), pgwSettlement.getSettlementId(), pgwSettlement.getStartDate(),
					pgwSettlement.getEndDate(), pgwSettlement.getReserveDay(), pgwSettlement.getAmount());
			pgwTransactionSvc.updateTransactionByMerchant(merchantId, setId, start, end);
			if (!BaseUtil.isListZero(pgwTransactionFromQuery)) {
				sendMailSettlements(merchantId, Integer.toString(setId), start, end, email, request);
			}
		}

	}


	/* remittence settlement */
	public void setSettlementsbyChannel(String merchantId, String channel, Date start, Date end, int reserveDay)
			throws ParseException {

		List<PgwTransaction> pgwTransactionFromQuery = pgwTransactionSvc.findTransactionByChannelAndSetID(channel, 0,
				start, end);

		Integer pgwTotalTransactionAmount = pgwTransactionSvc.findTotalTransactionByChannel(channel, start, end);
		LOGGER.info("total transaction {}", pgwTotalTransactionAmount);

		PgwMerchantProvider pgwMerchantProvider = pgwMerchantProviderServiceSvc.findProviderByChannel(channel);

		double chargeAmtByTrans = pgwMerchantProvider.getChargeAmount()
				+ (pgwMerchantProvider.getChargeAmount() * 0.06);
		double totalChargeAmount = pgwTotalTransactionAmount * (chargeAmtByTrans);
		LOGGER.info("total chagre amount {}", totalChargeAmount);

		PgwTransactionAmount pgwTransactionAmount = pgwTransactionSvc.findSumTransactionByChannel(channel, start,
				end);

		DecimalFormat df = new DecimalFormat("#.##");
		PgwSettlement pgwSettlement = new PgwSettlement();

		if (!BaseUtil.isListNull(pgwTransactionFromQuery)) {
			for (PgwTransaction pgwTran : pgwTransactionFromQuery) {
				pgwSettlement.setMerchantId(merchantId);
				pgwSettlement.setChannel(channel);
				pgwSettlement.setMerchantBankAcc(" ");
				pgwSettlement.setMerchantAccNo(" ");
				pgwSettlement.setPsa("0");
				pgwSettlement.setChequeNo(" ");
				pgwSettlement.setBankinSlip(" ");
				pgwSettlement.setCurAmt(pgwTran.getActCur());
				if(pgwTransactionAmount.getBillAmount()!=null) {
					pgwSettlement.setAmount(Double.valueOf(df.format(pgwTransactionAmount.getBillAmount())));
				}else {
					pgwSettlement.setAmount(0.00d);
				}
				pgwSettlement.setCurrencyRate(Double.valueOf(df.format(totalChargeAmount)));
				pgwSettlement.setCurActAmount(pgwTran.getActCur());
				if(pgwTransactionAmount.getActualAmount()!=null) {
				pgwSettlement.setActualAmount(Double.valueOf(df.format(pgwTransactionAmount.getActualAmount())));
				}else {
					pgwSettlement.setActualAmount(0.00d);
				}
				pgwSettlement.setSettlementFee(0.00d);
				pgwSettlement.setCurCostPenalty("MYR");
				pgwSettlement.setCostPenalty(0.00d);
				pgwSettlement.setCurExtraFee("MYR");
				pgwSettlement.setExtraFee(0.00d);
				pgwSettlement.setCurChargeback("MYR");
				pgwSettlement.setChargeback(0.00d);
				pgwSettlement.setCurRefund("MYR");
				pgwSettlement.setRefund(0.00d);
				pgwSettlement.setCurRefundPart("MYR");
				pgwSettlement.setRefundPart(0.00d);
				pgwSettlement.setCurAdminFee("MYR");
				pgwSettlement.setAdminFee(0.00d);
				pgwSettlement.setCurTransTotalAmt("MYR");
				pgwSettlement.setTransRec(" ");
				pgwSettlement.setMemo("Test");
				pgwSettlement.setModifyDate(new Date());
				pgwSettlement.setCreateDate(new Date());
				pgwSettlement.setSettleDate(new Date());
				pgwSettlement.setDeleted(0);
				pgwSettlement.setStatus("PENDING");
				pgwSettlement.setOrderId(pgwTran.getOrderId());
				pgwSettlement.setCreateDt(new Timestamp(new Date().getTime()));
				pgwSettlement.setUpdateDt(new Timestamp(new Date().getTime()));
				pgwSettlement.setStartDate(start);
				pgwSettlement.setEndDate(end);
				if (reserveDay == 1) {
					pgwSettlement.setReserveDay("WEEKLY");
				} else if (reserveDay == 2) {
					pgwSettlement.setReserveDay("MONTHLY");
				}
			}
			pgwSettlementService.create(pgwSettlement);
			int setId = pgwSettlementService.findSettlementIdByChannel(channel,
					DateUtil.getFormatDate(DateUtil.convertDate(new Date(), BaseConstants.DT_YYYY_MM_DD_DASH),
							BaseConstants.DT_YYYY_MM_DD_DASH));
			LOGGER.info(
					" Settlement Done for Channel : {} SettlemntId: {} startDate: {} endDate: {}  reserveDay: {} Amount: {} ",
					pgwSettlement.getChannel(), pgwSettlement.getSettlementId(), pgwSettlement.getStartDate(),
					pgwSettlement.getEndDate(), pgwSettlement.getReserveDay(), pgwSettlement.getAmount());
			pgwTransactionSvc.updateTransactionByChannel(channel, setId, start, end);
		}

	}


	public void sendMailSettlements(String merchantId, String setId, Date start, Date end, String email,
			HttpServletRequest request) throws ReportException {
		Report report = getReportService().genSettlementRpt(merchantId, setId,
				DateUtil.convertDate(start, BaseConstants.DT_DD_MM_YYYY_DASH),
				DateUtil.convertDate(end, BaseConstants.DT_DD_MM_YYYY_DASH));
		Map<String, Object> map = new HashMap<>();
		map.put("merchantId", merchantId);
		map.put("fromDate", DateUtil.convertDate(start, BaseConstants.DT_DD_MM_YYYY_DASH));
		map.put("toDate", DateUtil.convertDate(end, BaseConstants.DT_DD_MM_YYYY_DASH));
		map.put("setId", setId);
		Notification notification = new Notification();
		notification.setNotifyTo(email);
		notification.setSubject(
				MessageFormat.format(MailTemplate.SETTLEMENT_TRANSACTION_LIST.getSubject(), merchantId));
		notification.setMetaData(MailUtil.convertMapToJson(map));
		List<MailAttachment> attachments = new ArrayList<>();
		if (!BaseUtil.isObjNull(report)) {
			attachments.add(new MailAttachment(report.getFileName(), report.getReportBytes(), report.getMimeType()));
		}
		notification.setAttachments(attachments);
		getNotifyService(request).addNotification(notification, MailTypeEnum.MAIL,
				MailTemplate.SETTLEMENT_TRANSACTION_LIST);

	}


	@PostMapping(value = BeUrlConstants.MER_STMNS_DETAILS, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<PgwTransaction> generateSettlementCronJob(@Valid @RequestBody TransactionRptInfo transactionRptInfo,
			HttpServletRequest request) {

		if (BaseUtil.isEquals(transactionRptInfo.getChannel(), INCENTIVE_REMIT)) {
			return pgwTransactionSvc.findTransactionByChannelAndSetID(transactionRptInfo.getChannel(),
					transactionRptInfo.getSetId().intValue(), transactionRptInfo.getFromDate(),
					transactionRptInfo.getToDate());
		} else {
			return pgwTransactionSvc.findTransactionByMerchantAndSetID(transactionRptInfo.getMerchantId(),
					transactionRptInfo.getSetId().intValue(), transactionRptInfo.getFromDate(),
					transactionRptInfo.getToDate());
		}
	}


	private Date getFirstDateOfNextMonth(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, 1);
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
		return cal.getTime();
	}


	private Date getMondayOfNextWeek(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		LOGGER.info("Day is = {}", cal.get(Calendar.DAY_OF_WEEK));
		// First day of the week is Sunday. If settle Date is on Sunday, add 1
		// day instead of 1 week
		if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
			cal.add(Calendar.DAY_OF_WEEK, 1);
		} else {
			cal.add(Calendar.WEEK_OF_YEAR, 1);
			cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		}

		return cal.getTime();
	}


	private Date getDate(Date date, int days) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.DATE, days);
		return c.getTime();
	}


	private Date getFirstDateOfPreviousMonth(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.MONTH, -1);
		c.set(Calendar.DATE, 1);
		return c.getTime();
	}


	private Date getEndDateOfPreviousMonth(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.MONTH, -1);
		c.set(Calendar.DATE, 1);
		c.set(Calendar.DATE, c.getActualMaximum(Calendar.DAY_OF_MONTH));
		return c.getTime();
	}

}
