package com.bestpay.pgw.sdk.incentiveremit.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "getTransactionStatusResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class TransactionStatusResponse {

	@XmlElement(name = "CODE")
	private String code;

	@XmlElement(name = "REFNO")
	private String refNo;

	@XmlElement(name = "STATUS")
	private String status;

	@XmlElement(name = "STATUS_DATE")
	private String statusDate;


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getRefNo() {
		return refNo;
	}


	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getStatusDate() {
		return statusDate;
	}


	public void setStatusDate(String statusDate) {
		this.statusDate = statusDate;
	}

}
