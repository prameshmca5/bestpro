/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;


/**
 * @author michelle.angela
 *
 */
public class AirlinesAddress implements Serializable {

	private static final long serialVersionUID = -9019759970787426427L;

	private Integer airlinesAddrId;
	
	private AirlinesProfile airlinesProfile;
	
	private String addr1;

	private String addr2;

	private String addr3;

	private String addr4;
	
	private String cityDesc;

	private String stateDesc;
	
	private City city;

	private State state;
	
	private Country country;
	
	private String zipcode;
	
	private String addrType;

	public Integer getAirlinesAddrId() {
		return airlinesAddrId;
	}

	public void setAirlinesAddrId(Integer airlinesAddrId) {
		this.airlinesAddrId = airlinesAddrId;
	}

	public AirlinesProfile getAirlinesProfile() {
		return airlinesProfile;
	}

	public void setAirlinesProfile(AirlinesProfile airlinesProfile) {
		this.airlinesProfile = airlinesProfile;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getAddr3() {
		return addr3;
	}

	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}

	public String getAddr4() {
		return addr4;
	}

	public void setAddr4(String addr4) {
		this.addr4 = addr4;
	}

	public String getCityDesc() {
		return cityDesc;
	}

	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc;
	}

	public String getStateDesc() {
		return stateDesc;
	}

	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc;
	}

	public City getCity() {
		return city;
	}

	public void setCity(City city) {
		this.city = city;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getAddrType() {
		return addrType;
	}

	public void setAddrType(String addrType) {
		this.addrType = addrType;
	}

}
