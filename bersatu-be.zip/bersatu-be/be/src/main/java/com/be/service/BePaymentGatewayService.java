/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.be.service;


import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BePaymentGatewayRepository;
import com.be.model.BePaymentGateway;
import com.be.sdk.model.IQfCriteria;


/**
 * @author mohd.naem
 * @since March 31 , 2021
 */
@Service(QualifierConstants.BE_PAYMENT_GW_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_PAYMENT_GW_SVC)
@Transactional
public class BePaymentGatewayService extends AbstractService<BePaymentGateway> {

	protected static Logger logger = LoggerFactory.getLogger(BePaymentGatewayService.class);

	@Autowired
	private BePaymentGatewayRepository bePaymentGatewayDao;


	@Override
	public GenericRepository<BePaymentGateway> primaryDao() {
		return bePaymentGatewayDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return null;
	}
}