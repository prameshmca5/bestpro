package com.bestpay.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwTicket;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since November 13, 2018
 */

@Repository
@RepositoryDefinition(domainClass = PgwTicket.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_TICKET_DAO)
public interface PgwTicketRepository extends GenericRepository<PgwTicket> {

	@Query("select u from PgwTicket u where u.ticketId = :ticketId ")
	public PgwTicket findByTicketId(@Param("ticketId") int ticketId);


	@Query("select u from PgwTicket u where u.merchantId = :merchantId ")
	public PgwTicket findByMerchantId(@Param("merchantId") String merchantId);


	@Query("select u from PgwTicket u where u.supportId = :supportId ")
	public PgwTicket findBySupportId(@Param("supportId") String supportId);


	@Query("select u from PgwTicket u where u.merchantId = :merchantId and u.ticketId = :ticketId ")
	public PgwTicket findByMerchantIdTicketId(@Param("merchantId") String merchantId,
			@Param("ticketId") Integer ticketId);


	@Query(" select u.ticketId from PgwTicket u where u.merchantId=:merchantId order by createDt desc")
	public int findTicketId(@Param("merchantId") String merchantId);


	@Query("select count(u) from PgwTicket u ")
	public int totalRecords();

}