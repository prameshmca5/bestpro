package com.bestpay.be.sdk.model;


import java.util.Date;

import com.bestpay.be.sdk.constants.BaseConstants;
import com.bstsb.util.serializer.JsonDateSerializer;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SettlementInfo {

	private Integer settlementId;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH)
	private Date createDate;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH)
	private Date modifyDate;

	private String merchantBankAcc;

	private String merchantAccNo;

	private String chequeNo;

	private String merchantId;

	private String bankinSlip;

	private Double amount;

	private Double actualAmount;

	private Double costPenalty;

	private Double extraFee;

	private Double chargeback;

	private String status;

	private String orderId;

	private String userType;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH)
	private Date settleDate;

	private String reserveDay;

	private Double currencyRate;

	private String settlementFee;

	private Integer setId;

	private String userRoleGroupCode;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH)
	private Date startDate;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_DD_MM_YYYY_SLASH)
	private Date endDate;

	private Integer sst;

	private String curAmt;

	private String userId;

	private String curCostPenalty;

	private String channel;


	public Integer getSettlementId() {
		return settlementId;
	}


	public void setSettlementId(Integer settlementId) {
		this.settlementId = settlementId;
	}


	public Date getCreateDate() {
		return createDate;
	}


	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}


	public Date getModifyDate() {
		return modifyDate;
	}


	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}


	public String getMerchantBankAcc() {
		return merchantBankAcc;
	}


	public void setMerchantBankAcc(String merchantBankAcc) {
		this.merchantBankAcc = merchantBankAcc;
	}


	public String getChequeNo() {
		return chequeNo;
	}


	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}


	public String getBankinSlip() {
		return bankinSlip;
	}


	public void setBankinSlip(String bankinSlip) {
		this.bankinSlip = bankinSlip;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public Double getActualAmount() {
		return actualAmount;
	}


	public void setActualAmount(Double actualAmount) {
		this.actualAmount = actualAmount;
	}


	public Double getCostPenalty() {
		return costPenalty;
	}


	public void setCostPenalty(Double costPenalty) {
		this.costPenalty = costPenalty;
	}


	public Double getExtraFee() {
		return extraFee;
	}


	public void setExtraFee(Double extraFee) {
		this.extraFee = extraFee;
	}


	public Double getChargeback() {
		return chargeback;
	}


	public void setChargeback(Double chargeback) {
		this.chargeback = chargeback;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public Date getSettleDate() {
		return settleDate;
	}


	public void setSettleDate(Date settleDate) {
		this.settleDate = settleDate;
	}


	public Date getStartDate() {
		return startDate;
	}


	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	public Date getEndDate() {
		return endDate;
	}


	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}


	public String getMerchantAccNo() {
		return merchantAccNo;
	}


	public void setMerchantAccNo(String merchantAccNo) {
		this.merchantAccNo = merchantAccNo;
	}


	public String getReserveDay() {
		return reserveDay;
	}


	public void setReserveDay(String reserveDay) {
		this.reserveDay = reserveDay;
	}


	public Double getCurrencyRate() {
		return currencyRate;
	}


	public void setCurrencyRate(Double currencyRate) {
		this.currencyRate = currencyRate;
	}


	public String getSettlementFee() {
		return settlementFee;
	}


	public void setSettlementFee(String settlementFee) {
		this.settlementFee = settlementFee;
	}


	public Integer getSetId() {
		return setId;
	}


	public void setSetId(Integer setId) {
		this.setId = setId;
	}


	public Integer getSst() {
		return sst;
	}


	public void setSst(Integer sst) {
		this.sst = sst;
	}


	public String getCurAmt() {
		return curAmt;
	}


	public void setCurAmt(String curAmt) {
		this.curAmt = curAmt;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getCurCostPenalty() {
		return curCostPenalty;
	}


	public void setCurCostPenalty(String curCostPenalty) {
		this.curCostPenalty = curCostPenalty;
	}


	public String getUserRoleGroupCode() {
		return userRoleGroupCode;
	}


	public void setUserRoleGroupCode(String userRoleGroupCode) {
		this.userRoleGroupCode = userRoleGroupCode;
	}


	public String getUserType() {
		return userType;
	}


	public void setUserType(String userType) {
		this.userType = userType;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}

}
