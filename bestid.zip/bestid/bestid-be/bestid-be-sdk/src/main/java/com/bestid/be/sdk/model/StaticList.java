package com.bestid.be.sdk.model;


import java.io.Serializable;
import java.util.List;


/**
 * @author Md Asif Aftab
 * @since 3rd April 2018
 */

public class StaticList implements Serializable {

	private static final long serialVersionUID = 3767816590456566754L;

	private List<City> cityList;

	private List<Country> countryList;

	private List<State> stateList;

	private List<RelationShip> relationList;

	private List<Status> statusList;

	private List<Documents> documentList;

	private List<Nationality> nationalityList;


	public List<City> getCityList() {
		return cityList;
	}


	public void setCityList(List<City> cityList) {
		this.cityList = cityList;
	}


	public List<Country> getCountryList() {
		return countryList;
	}


	public void setCountryList(List<Country> countryList) {
		this.countryList = countryList;
	}


	public List<State> getStateList() {
		return stateList;
	}


	public void setStateList(List<State> stateList) {
		this.stateList = stateList;
	}


	public List<RelationShip> getRelationList() {
		return relationList;
	}


	public void setRelationList(List<RelationShip> relationList) {
		this.relationList = relationList;
	}


	public List<Status> getStatusList() {
		return statusList;
	}


	public void setStatusList(List<Status> statusList) {
		this.statusList = statusList;
	}


	public List<Documents> getDocumentList() {
		return documentList;
	}


	public void setDocumentList(List<Documents> documentList) {
		this.documentList = documentList;
	}


	public List<Nationality> getNationalityList() {
		return nationalityList;
	}


	public void setNationalityList(List<Nationality> nationalityList) {
		this.nationalityList = nationalityList;
	}

}
