/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.constants;


import java.io.File;

import com.bstsb.util.constants.BaseConfigConstants;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
public class ConfigConstants {

	private ConfigConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String BASE_PACKAGE = "com.bestid.be";

	public static final String BASE_PACKAGE_REPO = BASE_PACKAGE + ".repo";

	public static final String BASE_PACKAGE_MODEL = BASE_PACKAGE + ".model";

	public static final String BASE_PACKAGE_CONTROLLER = BASE_PACKAGE + ".controller";

	public static final String PATH_PROJ_CONFIG = "bestid.config.path";

	public static final String PROPERTY_FILENAME = "bestid-be";

	public static final String FILE_SYS_RESOURCE = File.separator + PROPERTY_FILENAME
			+ BaseConfigConstants.PROPERTIES_EXT;

	public static final String PROPERTY_CLASSPATH = BaseConfigConstants.CLASSPATH_PFX + PROPERTY_FILENAME;

	public static final String CACHE_JAVA_FILE = "T(com.bestid.be.constants.CacheConstants)";

	public static final String SVC_CAMVI_URL = "camvi.service.url";

	public static final String SVC_CAMVI_UNAME = "camvi.service.uname";

	public static final String SVC_CAMVI_PWORD = "camvi.service.pword";

	public static final String SVC_CAMVI_FACE_MIN_VAL = "camvi.service.face.min.val";

	public static final String SVC_IDM_URL = "idm.service.url";

	public static final String SVC_IDM_TIMEOUT = "idm.service.timeout";

	public static final String SVC_IDM_SKEY = "idm.service.skey";

	public static final String SVC_IDM_EKEY = "idm.service.ekey";

	public static final String SVC_IDM_CLIENT = "idm.service.client";

	public static final String SVC_MISIGNET_URL = "misignet.service.url";

	public static final String SVC_MISIGNET_PORT = "misignet.service.port";

	public static final String SVC_CS2_URL = "cs2.service.url";

	public static final String SVC_CS2_PROJ_ID = "cs2.service.proj.id";

	public static final String BID_CHCK_QR_EXP_DT = "bid.qr.cd.exp.dt";

	public static final String BID_CAMVI_GRP_ID = "bid.camvi.grp.id";

	public static final String BID_ICAO_SWITCH = "bid.icao.switch";

	public static final String SVC_DM_URL = "dm.service.url";

	public static final String SVC_DM_TIMEOUT = "dm.service.timeout";

	public static final String SVC_MSCTG_URL = "msctg.service.url";

	public static final String SVC_MSCTG_UNAME = "msctg.service.uname";

	public static final String SVC_MSCTG_PWORD = "msctg.service.pword";

}