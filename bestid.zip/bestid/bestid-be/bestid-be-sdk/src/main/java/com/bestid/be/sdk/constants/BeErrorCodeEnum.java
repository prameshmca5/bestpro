/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public enum BeErrorCodeEnum {

	E200BST000(200, "Successful"),

	// Error 400
	E400BST001(400, "X-Message-Id Header is missing"),
	E400BST002(400, "Authorization Header is missing"),
	E400BST003(400, "Bad Request"),
	E400BST004(400, "Invalid Date Format {0}."),
	E400BST005(400, "Missing Required Field [{0}]"),
	E400BST006(400, "Invalid Security Hashing."),

	// Error 401
	E401BST001(401, "Unauthorized Access"),

	// Error 404
	E404BST001(404, "No Record Found"),
	E404BST002(404, "Update Failed. No Record Found."),
	E404BST003(404, "No Record Found [{0}]"),
	E404BST004(404, "The record doesn't exists {0}"),

	// Error 408
	E408BST001(408, "Request timed out connecting to IDM after <response time>/<timeout duration>"),
	E408BST002(408, "Request timed out connecting to Mongo after <response time>/<timeout duration>"),
	E408BST003(408, "Request timed out connecting to Cache service after <response time>/<timeout duration>"),

	// Error 409
	E409BST001(409, "Record already exists"),
	E409BST002(409, "Create Failed. Record already exists."),

	// Error 500
	E500BST001(500, "Create/Update Failed."),
	E500BST002(500, "Pin code mismatch."),
	E500BST003(500, "Face ID mismatch."),
	E500BST004(500, "External System Error"),
	E500BST005(500, "Invalid login for {0}."),
	E500BST006(500, "ICAO validation fail."),
	E500BST007(500, "Image mismatch."),

	// Error 503
	E503BST000(503, "Service Unreachable"),
	E503BST001(503, "System unavailable. Please contact administrator."),;

	public final int code;

	public final String message;


	BeErrorCodeEnum(int code, String message) {
		this.code = code;
		this.message = message;
	}


	public static BeErrorCodeEnum findByName(String name) {
		for (BeErrorCodeEnum v : BeErrorCodeEnum.values()) {
			if (v.name().equals(name)) {
				return v;
			}
		}

		return null;
	}


	public static int findInternalCode(String name) {
		for (BeErrorCodeEnum v : BeErrorCodeEnum.values()) {
			if (v.name().equals(name)) {
				return v.getCode();
			}
		}

		return 0;
	}


	public String getMessage() {
		return message;
	}


	public int getCode() {
		return code;
	}
}
