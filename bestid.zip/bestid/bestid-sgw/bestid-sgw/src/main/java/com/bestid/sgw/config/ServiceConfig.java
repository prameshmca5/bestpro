/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.sgw.config;


import java.util.Locale;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bestid.be.sdk.client.BeServiceClient;
import com.bestid.sgw.constants.ConfigConstants;
import com.bstsb.dm.sdk.client.DmServiceClient;
import com.bstsb.idm.sdk.client.IdmServiceClient;
import com.bstsb.util.constants.BaseConstants;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
@Configuration
public class ServiceConfig implements InitializingBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceConfig.class);

	private String idmUrl;

	private int idmTimeout;

	private String beUrl;

	private int beTimeout;

	private String dmUrl;

	private int dmTimeout;

	@Autowired
	MessageSource messageSource;


	@Bean
	public Mapper dozerMapper() {
		return new DozerBeanMapper();
	}


	@Bean
	public ObjectMapper objectMapper() {
		return new ObjectMapper();
	}


	@Bean
	public IdmServiceClient idmService() {
		return new IdmServiceClient(idmUrl, idmTimeout);
	}


	@Bean
	public BeServiceClient beService() {
		return new BeServiceClient(beUrl, beTimeout);
	}


	@Bean
	public DmServiceClient dmService() {
		return new DmServiceClient(dmUrl, dmTimeout);
	}


	@Override
	public void afterPropertiesSet() throws Exception {
		idmUrl = messageSource.getMessage(ConfigConstants.SVC_IDM_URL, null, Locale.getDefault());
		idmTimeout = Integer
				.valueOf(messageSource.getMessage(ConfigConstants.SVC_IDM_TIMEOUT, null, Locale.getDefault()));
		beUrl = messageSource.getMessage(ConfigConstants.SVC_SVC_URL, null, Locale.getDefault());
		beTimeout = Integer
				.valueOf(messageSource.getMessage(ConfigConstants.SVC_SVC_TIMEOUT, null, Locale.getDefault()));
		dmUrl = messageSource.getMessage(ConfigConstants.SVC_DM_URL, null, Locale.getDefault());
		dmTimeout = Integer
				.valueOf(messageSource.getMessage(ConfigConstants.SVC_DM_TIMEOUT, null, Locale.getDefault()));
		StringBuilder sb = new StringBuilder();
		sb.append(BaseConstants.NEW_LINE + BaseConstants.NEW_LINE);
		sb.append(BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("Integration Service");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("IDM Service URL: " + idmUrl + "\t- Timeout (seconds): " + idmTimeout + BaseConstants.NEW_LINE);
		sb.append("DM Service URL: " + dmUrl + "\t- Timeout (seconds): " + dmTimeout + BaseConstants.NEW_LINE);
		sb.append("BE Service URL: " + beUrl + "\t- Timeout (seconds): " + beTimeout);
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		LOGGER.debug("{}", sb);
	}

}