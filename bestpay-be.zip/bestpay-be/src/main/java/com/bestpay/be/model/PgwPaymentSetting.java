/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * @author Atiqah Khairuddin
 * @since June 26, 2018
 */
@Entity
@Table(name = "PGW_PAYMENT_SETTING")
public class PgwPaymentSetting extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "PMT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer paymentId;

	@Column(name = "MERCHANT_ID")
	private String merchantId;

	@Column(name = "SELLER_ID")
	private String sellerId;

	@Column(name = "RETURN_URL")
	private String returnUrl;

	@Column(name = "RETURN_URL_WITH_IPN")
	private String returnUrlWithIpn;

	@Column(name = "CALLBACK_URL")
	private String callbackUrl;

	@Column(name = "CALLBACK_URL_WITH_IPN")
	private String callbackUrlWithIpn;

	@Column(name = "VERIFY_KEY")
	private String verifyKey;

	@Column(name = "ENABLE_VERIFY")
	private Integer enableVerify;

	@Column(name = "EMAIL_NOTIFICATION")
	private String emailNotification;

	@Column(name = "RECEIPT")
	private String receipt;

	@Column(name = "CAN_MODIFY_OID")
	private Integer canModifyOid;

	@Column(name = "CAN_MODIFY_AMT")
	private Integer canModifyAmt;

	@Column(name = "CANT_MODIFY_DESC")
	private String cantModifyDesc;

	@Column(name = "EMAIL_LOCK")
	private String emailLock;

	@Column(name = "NAME_LOCK")
	private String nameLock;

	@Column(name = "PHONE_LOCK")
	private String phoneLock;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "DOC_MGT_ID")
	private String docMgtId;


	public PgwPaymentSetting() {
		// pgwPaymentSetting backend model
	}


	public Integer getPaymentId() {
		return paymentId;
	}


	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}


	public String getSellerId() {
		return sellerId;
	}


	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getReturnUrl() {
		return returnUrl;
	}


	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}


	public String getReturnUrlWithIpn() {
		return returnUrlWithIpn;
	}


	public void setReturnUrlWithIpn(String returnUrlWithIpn) {
		this.returnUrlWithIpn = returnUrlWithIpn;
	}


	public String getCallbackUrl() {
		return callbackUrl;
	}


	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}


	public String getCallbackUrlWithIpn() {
		return callbackUrlWithIpn;
	}


	public void setCallbackUrlWithIpn(String callbackUrlWithIpn) {
		this.callbackUrlWithIpn = callbackUrlWithIpn;
	}


	public String getVerifyKey() {
		return verifyKey;
	}


	public void setVerifyKey(String verifyKey) {
		this.verifyKey = verifyKey;
	}


	public Integer getEnableVerify() {
		return enableVerify;
	}


	public void setEnableVerify(Integer enableVerify) {
		this.enableVerify = enableVerify;
	}


	public String getEmailNotification() {
		return emailNotification;
	}


	public void setEmailNotification(String emailNotification) {
		this.emailNotification = emailNotification;
	}


	public String getReceipt() {
		return receipt;
	}


	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}


	public Integer getCanModifyOid() {
		return canModifyOid;
	}


	public void setCanModifyOid(Integer canModifyOid) {
		this.canModifyOid = canModifyOid;
	}


	public Integer getCanModifyAmt() {
		return canModifyAmt;
	}


	public void setCanModifyAmt(Integer canModifyAmt) {
		this.canModifyAmt = canModifyAmt;
	}


	public String getCantModifyDesc() {
		return cantModifyDesc;
	}


	public void setCantModifyDesc(String cantModifyDesc) {
		this.cantModifyDesc = cantModifyDesc;
	}


	public String getEmailLock() {
		return emailLock;
	}


	public void setEmailLock(String emailLock) {
		this.emailLock = emailLock;
	}


	public String getNameLock() {
		return nameLock;
	}


	public void setNameLock(String nameLock) {
		this.nameLock = nameLock;
	}


	public String getPhoneLock() {
		return phoneLock;
	}


	public void setPhoneLock(String phoneLock) {
		this.phoneLock = phoneLock;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getDocMgtId() {
		return docMgtId;
	}


	public void setDocMgtId(String docMgtId) {
		this.docMgtId = docMgtId;
	}

}