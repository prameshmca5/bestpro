/**
 * 
 */
package com.be.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.BeConfigTripHealth;
import com.be.model.BeTripAccommodation;
import com.be.model.BeTvlTrip;
import com.be.model.BeTvlTripHealth;

/**
 * @author michelle.angela
 *
 */
@Lazy
@Repository
@RepositoryDefinition(domainClass = BeTripAccommodation.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TRIP_ACCOMMODATION_DAO)
public interface BeTripAccommodationRepository extends GenericRepository<BeTripAccommodation> {

}
