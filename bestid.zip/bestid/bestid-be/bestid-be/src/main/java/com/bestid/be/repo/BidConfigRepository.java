/**
 *
 */
package com.bestid.be.repo;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidConfig;


/**
 * @author roziana
 * @since Feb 26, 2019
 */
@Repository
@RepositoryDefinition(domainClass = BidConfig.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_CONFIG_REPOSITORY)
public interface BidConfigRepository extends GenericRepository<BidConfig> {

	@Query("select u from BidConfig u where u.configCd= :configCd")
	BidConfig findByConfigCd(@Param("configCd") String configCd);


	@Query("select u from BidConfig u where u.configId= :configId")
	BidConfig findByConfigId(@Param("configId") Integer configId);


	@Query("select count(u) from BidConfig u")
	int totalRecords();

}
