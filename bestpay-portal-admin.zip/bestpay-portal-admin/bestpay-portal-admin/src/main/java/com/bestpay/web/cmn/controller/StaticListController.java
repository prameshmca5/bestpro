/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.City;
import com.bestpay.be.sdk.model.State;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.constants.CacheConstants;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.WebUtil;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;

/**
 * @author Mary Jane Buenaventura
 * @since May 17, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_CMN_STATIC)
public class StaticListController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(StaticListController.class);

	private static final String EXCEPTION = "Exception: {}";

	private static final String IDM_EXCEPTION = "IdmException: {}";

	private static final String TIDM = "\n\tIDM : ";

	private static final String TPORTAL_EMP = "\n\tPORTAL EMP : ";

	private static final String TREPORT = "\n\tREPORT : ";

	private static final String MNTCE = "mntce";

	private static final String STATLST = "statlst";

	@Autowired
	RedisTemplate<String, String> redisTemplate;

	@GetMapping
	public ModelAndView view() {
		return getDefaultMav(PageTemplate.TEMP_CMN_STTC_LST, MNTCE, STATLST);
	}

	@GetMapping(value = "/refresh")
	public ModelAndView refreshStaticList(@RequestParam("staticlistType") String staticlistType,
			HttpServletRequest request) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMN_STTC_LST, MNTCE, STATLST);
		String listName = "";
		String result = null;
		try {
			LOGGER.debug("Refresh static list : {}", staticlistType);
			result = processEvict(staticlistType);
			mav.addAllObjects(PopupBox.success(null, null,
					listName + messageService.getMessage(MessageConstants.SUCC_REFRSH), PageConstants.PAGE_CMN_STATIC));
		} catch (Exception e) {
			mav.addAllObjects(
					PopupBox.error(listName + messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
		}
		LOGGER.debug(result);
		return mav;
	}

	@PostMapping
	public ModelAndView refreshAll(HttpServletRequest request) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMN_STTC_LST, MNTCE, STATLST);
		try {
			processEvict(null);
			mav.addAllObjects(PopupBox.success(null, null,
					messageService.getMessage(MessageConstants.SUCC_STLST_REFRSH), PageConstants.PAGE_CMN_STATIC));
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
			mav.addAllObjects(PopupBox.error(messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
		}
		return mav;
	}

	private String processEvict(String prefixKey) {
		StringBuilder sb = new StringBuilder();
		sb.append("\n[Clearing Cache Buckets:");
		if (!BaseUtil.isObjNull(prefixKey)) {
			sb.append(" key - " + prefixKey);
		}
		try {
			if (!BaseUtil.isObjNull(prefixKey)) {
				Cache cache = cacheManager.getCache(CacheConstants.CACHE_BUCKET);
				Set<String> redisKeys = redisTemplate.keys(CacheConstants.CACHE_PREFIX + "*" + prefixKey + "*");
				// Store the keys in a List
				Iterator<String> it = redisKeys.iterator();
				while (it.hasNext()) {
					String data = it.next();
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug("redisKey: {}", data);
					}
					cache.evict(data);
				}
			} else {
				Cache cache = cacheManager.getCache(CacheConstants.CACHE_BUCKET);
				cache.clear();
				sb.append(TPORTAL_EMP + true);
			}
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(IDM_EXCEPTION, e.getMessage());
			sb.append(TPORTAL_EMP + false);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
			sb.append(TPORTAL_EMP + false);
		}

		try {
			if (!BaseUtil.isObjNull(prefixKey)) {
				sb.append(TIDM + getIdmService().evict(prefixKey));
			} else {
				sb.append(TIDM + getIdmService().evict());
			}
		} catch (IdmException e) {
			LOGGER.error(IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			sb.append(TIDM + false);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
			sb.append(TIDM + false);
		}

		try {
			if (!BaseUtil.isObjNull(prefixKey)) {
				sb.append(TREPORT + getReportService().evict(prefixKey));
			} else {
				sb.append(TREPORT + getReportService().evict());
			}
		} catch (IdmException e) {
			LOGGER.error(IDM_EXCEPTION, e.getMessage());
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			sb.append(TREPORT + false);
		} catch (Exception e) {
			LOGGER.error(EXCEPTION, e.getMessage());
			sb.append(TREPORT + false);
		}

		sb.append("\n]");
		return sb.toString();
	}

	@PostMapping(value = "/city")
	public @ResponseBody String getss(@RequestParam String stateCode, HttpServletRequest request) throws BeException {
		List<City> stateList = staticData.cityList(stateCode);
		List<City> resSatetList = new ArrayList<>();
		if (!BaseUtil.isObjNull(stateList)) {
			try {
				for (City st : stateList) {
					if (BaseUtil.isEqualsCaseIgnore(st.getState(), stateCode)) {
						resSatetList.add(st);
					}
				}

				Collections.sort(resSatetList, new Comparator<City>() {

					@Override
					public int compare(City o1, City o2) {
						return o1.getDescEn().compareTo(o2.getDescEn());
					}
				});
			} catch (Exception e) {
				LOGGER.error(EXCEPTION, e.getMessage());
			}
		}
		return new Gson().toJson(resSatetList);
	}

	@PostMapping(value = "/state")
	public @ResponseBody String getState(@RequestParam String countryCode, HttpServletRequest request)
			throws BeException {
		List<State> stateList = staticData.stateList(countryCode);
		List<State> resStateList = new ArrayList<>();
		if (!BaseUtil.isObjNull(stateList)) {
			try {
				for (State st : stateList) {

					if (BaseUtil.isEqualsCaseIgnore(st.getCountry(), countryCode)) {
						resStateList.add(st);
					}
				}

				Collections.sort(resStateList, new Comparator<State>() {

					@Override
					public int compare(State o1, State o2) {
						return o1.getStateDesc().compareTo(o2.getStateDesc());
					}
				});
			} catch (Exception e) {
				LOGGER.error(EXCEPTION, e.getMessage());
			}
		}
		return new Gson().toJson(resStateList);
	}
}