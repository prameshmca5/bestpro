/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwMerchantBeneficiary;
import com.bestpay.pgw.sdk.constants.PgwErrorCodeEnum;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.exception.PgwException;
import com.bestpay.pgw.sdk.model.MerchantBeneficiary;
import com.bestpay.pgw.sdk.util.BaseUtil;


/**
 * @author Ramesh
 * @since 22/06/2019
 */
@RestController
@RequestMapping(PgwUrlConstants.MERCHANT_BENEFICIARY)
public class PgwMerchantBeneficiaryRestController extends AbstractRestController {

	@GetMapping(value = PgwUrlConstants.FIND_MERCHANT_IRCUSID, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MerchantBeneficiary findByMerchantIdIRCusId(@RequestParam String merchantId, @RequestParam String mtoId,
			HttpServletRequest request) {
		try {
			PgwMerchantBeneficiary benefi = pgwMerchantBeneficiaryService.findByMerchantBenefId(merchantId, mtoId);
			if (!BaseUtil.isObjNull(benefi)) {
				return dozerMapper.map(benefi, MerchantBeneficiary.class);
			}
		} catch (Exception e) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW115, new String[] { merchantId });
		}
		return null;
	}

}
