/**
 *
 */
package com.bestid.web.util;


import java.text.DecimalFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.bestid.core.AbstractController;
import com.bstsb.iam.CustomUserDetails;
import com.bstsb.idm.sdk.constants.IdmUserTypeConstants;
import com.bstsb.idm.sdk.model.UserProfile;
import com.bstsb.util.BaseUtil;


/**
 * @author Jhayne
 *
 */
public class PaymentSwitch extends AbstractController {

	@Autowired
	private MessageSource messageSource;


	public MessageSource getMessageSource() {
		return messageSource;
	}


	public String creditBal() {
		UserProfile userProfile = null;
		new DecimalFormat("###,###.00");
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (!BaseUtil.isObjNull(auth) && auth.isAuthenticated()) {
			CustomUserDetails cud = (CustomUserDetails) auth.getPrincipal();
			userProfile = cud.getProfile();
			if (BaseUtil.isEqualsCaseIgnore(IdmUserTypeConstants.WRKR, userProfile.getUserType())) {
				cud.getUserProfile();
			}
		}
		return "0.00";
	}

}