/**
  * Copyright 2019
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;


/**
 *
 * @author Naem Othman
 * @since March 31, 2020
 */
public class MemberProfile implements Serializable, IQfCriteria<MemberProfile> {

	private static final long serialVersionUID = 6016032592885161865L;

	private Integer memberId;

	private String txnId;

	private List<String> txnIdList;

	private String memberRefNo;

	private String memberNo;

	private String fullName;

	private String idNo;

	private Integer genderMtdtId;

	private String genderMtdtDesc;

	private Integer religionMtdtId;

	private String religionMtdtDesc;

	private Date dob;

	private Integer ethnicMtdtId;

	private String ethnicMtdtDesc;

	private String contactNo;

	private String email;

	private Integer eduMtdtId;

	private String eduMtdtDesc;

	private String eduDesc;

	private Integer occupationMtdtId;

	private String occupationMtdtDesc;

	private String orgStateCd;

	private String orgStateDesc;

	private String orgDivisionCd;

	private String orgDivisionDesc;

	private String orgBranchCd;

	private String orgBranchDesc;

	private Integer voterRegMtdtId;

	private List<Integer> voterRegMtdtIdList;

	private String voterRegMtdtDesc;

	private String docRefNo;

	private String sprStateCd;
	
	private String sprStateDesc;

	private String parliamentCode;

	private String parliamentDesc;

	private String dunCode;

	private String dunDesc;

	private Integer memberCtrgyMtdtId;

	private String memberCtrgyMtdtDesc;

	private Integer memberTypeMtdtId;

	private String memberTypeMtdtDesc;

	private Integer statusId;

	private List<Integer> statusIdList;

	private Integer channelMtdtId;

	private String applyBy;

	private Timestamp applyDt;

	private String applyRemarks;

	private String approveBy;

	private Timestamp approveDt;

	private String approveRemarks;

	private List<TrxnDocuments> trxnDocumentList;

	private List<MemberAddress> memberAddressList;

	private Timestamp applyDtFrom;

	private Timestamp applyDtTo;

	private Status status;

	private Integer preRegId;

	private Integer regExistMtdtId;

	private boolean isNotIn;

	private Integer credentialInd;

	private boolean isNotInCredentialInd;

	private Date dobTo;

	private Double itemAmount;

	private String pmtDtlRefNo;

	private String currency;

	private Integer positionId;

	private Date applyDte;

	private String transferRemarks;

	private Integer endtStatusId;


	public Integer getMemberId() {
		return memberId;
	}


	public void setMemberId(Integer memberId) {
		this.memberId = memberId;
	}


	public String getTxnId() {
		return txnId;
	}


	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}


	/**
	 * @return the txnIdList
	 */
	public List<String> getTxnIdList() {
		return txnIdList;
	}


	/**
	 * @param txnIdList
	 *             the txnIdList to set
	 */
	public void setTxnIdList(List<String> txnIdList) {
		this.txnIdList = txnIdList;
	}


	public String getMemberRefNo() {
		return memberRefNo;
	}


	public void setMemberRefNo(String memberRefNo) {
		this.memberRefNo = memberRefNo;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getIdNo() {
		return idNo;
	}


	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}


	public Integer getGenderMtdtId() {
		return genderMtdtId;
	}


	public void setGenderMtdtId(Integer genderMtdtId) {
		this.genderMtdtId = genderMtdtId;
	}


	public Integer getReligionMtdtId() {
		return religionMtdtId;
	}


	public void setReligionMtdtId(Integer religionMtdtId) {
		this.religionMtdtId = religionMtdtId;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public Integer getEthnicMtdtId() {
		return ethnicMtdtId;
	}


	public void setEthnicMtdtId(Integer ethnicMtdtId) {
		this.ethnicMtdtId = ethnicMtdtId;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Integer getEduMtdtId() {
		return eduMtdtId;
	}


	public void setEduMtdtId(Integer eduMtdtId) {
		this.eduMtdtId = eduMtdtId;
	}


	public String getEduDesc() {
		return eduDesc;
	}


	public void setEduDesc(String eduDesc) {
		this.eduDesc = eduDesc;
	}


	public Integer getOccupationMtdtId() {
		return occupationMtdtId;
	}


	public void setOccupationMtdtId(Integer occupationMtdtId) {
		this.occupationMtdtId = occupationMtdtId;
	}


	public String getOrgStateCd() {
		return orgStateCd;
	}


	public void setOrgStateCd(String orgStateCd) {
		this.orgStateCd = orgStateCd;
	}


	public String getOrgDivisionCd() {
		return orgDivisionCd;
	}


	public void setOrgDivisionCd(String orgDivisionCd) {
		this.orgDivisionCd = orgDivisionCd;
	}


	public String getOrgBranchCd() {
		return orgBranchCd;
	}


	public void setOrgBranchCd(String orgBranchCd) {
		this.orgBranchCd = orgBranchCd;
	}


	public Integer getVoterRegMtdtId() {
		return voterRegMtdtId;
	}


	public void setVoterRegMtdtId(Integer voterRegMtdtId) {
		this.voterRegMtdtId = voterRegMtdtId;
	}


	public String getDocRefNo() {
		return docRefNo;
	}


	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}


	public String getParliamentCode() {
		return parliamentCode;
	}


	public void setParliamentCode(String parliamentCode) {
		this.parliamentCode = parliamentCode;
	}


	public String getDunCode() {
		return dunCode;
	}


	public void setDunCode(String dunCode) {
		this.dunCode = dunCode;
	}


	public Integer getMemberCtrgyMtdtId() {
		return memberCtrgyMtdtId;
	}


	public void setMemberCtrgyMtdtId(Integer memberCtrgyMtdtId) {
		this.memberCtrgyMtdtId = memberCtrgyMtdtId;
	}


	public Integer getMemberTypeMtdtId() {
		return memberTypeMtdtId;
	}


	public void setMemberTypeMtdtId(Integer memberTypeMtdtId) {
		this.memberTypeMtdtId = memberTypeMtdtId;
	}


	public Integer getStatusId() {
		return statusId;
	}


	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}


	public Integer getChannelMtdtId() {
		return channelMtdtId;
	}


	public void setChannelMtdtId(Integer channelMtdtId) {
		this.channelMtdtId = channelMtdtId;
	}


	public String getApplyBy() {
		return applyBy;
	}


	public void setApplyBy(String applyBy) {
		this.applyBy = applyBy;
	}


	public Timestamp getApplyDt() {
		return applyDt;
	}


	public void setApplyDt(Timestamp applyDt) {
		this.applyDt = applyDt;
	}


	public String getApplyRemarks() {
		return applyRemarks;
	}


	public void setApplyRemarks(String applyRemarks) {
		this.applyRemarks = applyRemarks;
	}


	public String getApproveBy() {
		return approveBy;
	}


	public void setApproveBy(String approveBy) {
		this.approveBy = approveBy;
	}


	public Timestamp getApproveDt() {
		return approveDt;
	}


	public void setApproveDt(Timestamp approveDt) {
		this.approveDt = approveDt;
	}


	public String getApproveRemarks() {
		return approveRemarks;
	}


	public void setApproveRemarks(String approveRemarks) {
		this.approveRemarks = approveRemarks;
	}


	public List<TrxnDocuments> getTrxnDocumentList() {
		return trxnDocumentList;
	}


	public void setTrxnDocumentList(List<TrxnDocuments> trxnDocumentList) {
		this.trxnDocumentList = trxnDocumentList;
	}


	public List<MemberAddress> getMemberAddressList() {
		return memberAddressList;
	}


	public void setMemberAddressList(List<MemberAddress> memberAddressList) {
		this.memberAddressList = memberAddressList;
	}


	public Timestamp getApplyDtFrom() {
		return applyDtFrom;
	}


	public void setApplyDtFrom(Timestamp applyDtFrom) {
		this.applyDtFrom = applyDtFrom;
	}


	public Timestamp getApplyDtTo() {
		return applyDtTo;
	}


	public void setApplyDtTo(Timestamp applyDtTo) {
		this.applyDtTo = applyDtTo;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}


	public String getGenderMtdtDesc() {
		return genderMtdtDesc;
	}


	public void setGenderMtdtDesc(String genderMtdtDesc) {
		this.genderMtdtDesc = genderMtdtDesc;
	}


	public String getReligionMtdtDesc() {
		return religionMtdtDesc;
	}


	public void setReligionMtdtDesc(String religionMtdtDesc) {
		this.religionMtdtDesc = religionMtdtDesc;
	}


	public String getEthnicMtdtDesc() {
		return ethnicMtdtDesc;
	}


	public void setEthnicMtdtDesc(String ethnicMtdtDesc) {
		this.ethnicMtdtDesc = ethnicMtdtDesc;
	}


	public String getEduMtdtDesc() {
		return eduMtdtDesc;
	}


	public void setEduMtdtDesc(String eduMtdtDesc) {
		this.eduMtdtDesc = eduMtdtDesc;
	}


	public String getOccupationMtdtDesc() {
		return occupationMtdtDesc;
	}


	public void setOccupationMtdtDesc(String occupationMtdtDesc) {
		this.occupationMtdtDesc = occupationMtdtDesc;
	}


	public String getOrgStateDesc() {
		return orgStateDesc;
	}


	public void setOrgStateDesc(String orgStateDesc) {
		this.orgStateDesc = orgStateDesc;
	}


	public String getOrgDivisionDesc() {
		return orgDivisionDesc;
	}


	public void setOrgDivisionDesc(String orgDivisionDesc) {
		this.orgDivisionDesc = orgDivisionDesc;
	}


	public String getOrgBranchDesc() {
		return orgBranchDesc;
	}


	public void setOrgBranchDesc(String orgBranchDesc) {
		this.orgBranchDesc = orgBranchDesc;
	}


	public String getVoterRegMtdtDesc() {
		return voterRegMtdtDesc;
	}


	public void setVoterRegMtdtDesc(String voterRegMtdtDesc) {
		this.voterRegMtdtDesc = voterRegMtdtDesc;
	}


	public String getParliamentDesc() {
		return parliamentDesc;
	}


	public void setParliamentDesc(String parliamentDesc) {
		this.parliamentDesc = parliamentDesc;
	}


	public String getDunDesc() {
		return dunDesc;
	}


	public void setDunDesc(String dunDesc) {
		this.dunDesc = dunDesc;
	}


	public String getMemberCtrgyMtdtDesc() {
		return memberCtrgyMtdtDesc;
	}


	public void setMemberCtrgyMtdtDesc(String memberCtrgyMtdtDesc) {
		this.memberCtrgyMtdtDesc = memberCtrgyMtdtDesc;
	}


	public String getMemberTypeMtdtDesc() {
		return memberTypeMtdtDesc;
	}


	public void setMemberTypeMtdtDesc(String memberTypeMtdtDesc) {
		this.memberTypeMtdtDesc = memberTypeMtdtDesc;
	}


	public List<Integer> getVoterRegMtdtIdList() {
		return voterRegMtdtIdList;
	}


	public void setVoterRegMtdtIdList(List<Integer> voterRegMtdtIdList) {
		this.voterRegMtdtIdList = voterRegMtdtIdList;
	}


	public Integer getPreRegId() {
		return preRegId;
	}


	public void setPreRegId(Integer preRegId) {
		this.preRegId = preRegId;
	}


	public Integer getRegExistMtdtId() {
		return regExistMtdtId;
	}


	public void setRegExistMtdtId(Integer regExistMtdtId) {
		this.regExistMtdtId = regExistMtdtId;
	}


	public List<Integer> getStatusIdList() {
		return statusIdList;
	}


	public void setStatusIdList(List<Integer> statusIdList) {
		this.statusIdList = statusIdList;
	}


	public boolean isNotIn() {
		return isNotIn;
	}


	public void setNotIn(boolean isNotIn) {
		this.isNotIn = isNotIn;
	}


	public Integer getCredentialInd() {
		return credentialInd;
	}


	public void setCredentialInd(Integer credentialInd) {
		this.credentialInd = credentialInd;
	}


	public Date getDobTo() {
		return dobTo;
	}


	public void setDobTo(Date dobTo) {
		this.dobTo = dobTo;
	}


	public String getMemberNo() {
		return memberNo;
	}


	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}


	public Double getItemAmount() {
		return itemAmount;
	}


	public void setItemAmount(Double itemAmount) {
		this.itemAmount = itemAmount;
	}


	public String getPmtDtlRefNo() {
		return pmtDtlRefNo;
	}


	public void setPmtDtlRefNo(String pmtDtlRefNo) {
		this.pmtDtlRefNo = pmtDtlRefNo;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public Integer getPositionId() {
		return positionId;
	}


	public void setPositionId(Integer positionId) {
		this.positionId = positionId;
	}


	public Date getApplyDte() {
		return applyDte;
	}


	public void setApplyDte(Date applyDte) {
		this.applyDte = applyDte;
	}


	/**
	 * @return the sprStateCd
	 */
	public String getSprStateCd() {
		return sprStateCd;
	}


	/**
	 * @param sprStateCd
	 *             the sprStateCd to set
	 */
	public void setSprStateCd(String sprStateCd) {
		this.sprStateCd = sprStateCd;
	}


	public String getTransferRemarks() {
		return transferRemarks;
	}


	public void setTransferRemarks(String transferRemarks) {
		this.transferRemarks = transferRemarks;
	}


	public Integer getEndtStatusId() {
		return endtStatusId;
	}


	public void setEndtStatusId(Integer endtStatusId) {
		this.endtStatusId = endtStatusId;
	}


	/**
	 * @return the isNotInCredentialInd
	 */
	public boolean isNotInCredentialInd() {
		return isNotInCredentialInd;
	}


	/**
	 * @param isNotInCredentialInd
	 *             the isNotInCredentialInd to set
	 */
	public void setNotInCredentialInd(boolean isNotInCredentialInd) {
		this.isNotInCredentialInd = isNotInCredentialInd;
	}
	
	public String getSprStateDesc() {
		return sprStateDesc;
	}


	public void setSprStateDesc(String sprStateDesc) {
		this.sprStateDesc = sprStateDesc;
	}

}