/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.config.audit;


import com.bestpay.web.constants.BaseConstants;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public enum AuditActionPolicy {

	LOGIN(BaseConstants.LOGIN, "Logged In"),
	LOGIN_FAILED(BaseConstants.LOGIN, "Logged In Failed"),
	LOGOUT(BaseConstants.LOGIN, "Logged out"),
	FORCE_LOGOUT(BaseConstants.LOGIN, "Force/Session Logged out"),
	FORGOT_PASSWORD("FORGOT PASSWORD", "Reset Password"),
	CHANGE_PWORD("CHANGE PASSWORD", "Change Password"),
	CHANGE_PWORD_FT("CHANGE PASSWORD", "First Time Password"),

	MANAGE_USERS("MANAGE USERS", "View Manage Users"),
	CREATE_USER(BaseConstants.USER_PROFILE, "Create User Profile"),
	UPDATE_USER(BaseConstants.USER_PROFILE, "Update User Profile"),
	UPDATE_PROF(BaseConstants.USER_PROFILE, "Update Profile"),
	RESET_PWORD(BaseConstants.USER_PROFILE, "Reset Password"),
	ACTIVATE_USER(BaseConstants.USER_PROFILE, "Activate User"),
	DEACTIVATE_USER(BaseConstants.USER_PROFILE, "Dectivate User"),
	RESEND_CRED(BaseConstants.USER_PROFILE, "Resend User Credentials"),;

	private final String page;

	private final String action;


	AuditActionPolicy(final String page, final String action) {
		this.page = page;
		this.action = action;
	}


	public String page() {
		return page;
	}


	public String action() {
		return action;
	}

}
