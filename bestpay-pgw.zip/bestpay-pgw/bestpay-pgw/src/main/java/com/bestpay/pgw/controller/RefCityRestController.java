package com.bestpay.pgw.controller;


import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.RefCity;
import com.bestpay.pgw.sdk.constants.PgwErrorCodeEnum;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.exception.PgwException;
import com.bestpay.pgw.sdk.model.City;
import com.bestpay.pgw.service.RefCityService;


@RestController
@RequestMapping(PgwUrlConstants.CITY)
public class RefCityRestController extends AbstractRestController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private RefCityService apjCitySvc;


	@GetMapping(consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<City> findAll(@RequestParam(value = "embededState", required = false) String embededState) {

		List<RefCity> cities = apjCitySvc.findAll();
		List<City> citiess = new ArrayList<>();
		Mapper mapper = new DozerBeanMapper();

		for (RefCity city : cities) {

			City cityObj = mapper.map(city, City.class);

			/**
			 * if (embededState != null &&
			 * embededState.equalsIgnoreCase("true")) {
			 *
			 * RefState state = refStateService.findByStateCode(city
			 * .getState());
			 *
			 * if (state != null) { cityObj.setStateObj(mapper.map(state,
			 * State.class)); } }
			 */

			citiess.add(cityObj);
		}

		logger.debug("cities : {} ", citiess.size());
		return citiess;
	}


	@GetMapping(value = "{cityCode}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public RefCity find(@PathVariable String cityCode) {

		RefCity city = apjCitySvc.findByCityCode(cityCode);

		if (city == null) {
			throw new PgwException(PgwErrorCodeEnum.I404APJ109);
		}
		return city;
	}


	@GetMapping(value = "/{cityCode}/{stateCode}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public RefCity fidCityByCityStateCode(@PathVariable String cityCode, @PathVariable String stateCode) {

		RefCity city = apjCitySvc.findByCityStateCode(cityCode, stateCode);

		if (city == null) {
			throw new PgwException(PgwErrorCodeEnum.I404APJ109);
		}
		return city;
	}

}