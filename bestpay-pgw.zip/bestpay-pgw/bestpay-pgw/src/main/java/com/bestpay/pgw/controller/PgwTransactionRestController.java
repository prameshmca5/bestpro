package com.bestpay.pgw.controller;


import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwBankDetails;
import com.bestpay.pgw.model.PgwConfig;
import com.bestpay.pgw.model.PgwMultiChannel;
import com.bestpay.pgw.model.PgwTransaction;
import com.bestpay.pgw.model.PgwTransactionHistory;
import com.bestpay.pgw.model.RefBank;
import com.bestpay.pgw.model.RefFpxBestpayCode;
import com.bestpay.pgw.sdk.constants.PgwConstants;
import com.bestpay.pgw.sdk.constants.PgwErrorCodeEnum;
import com.bestpay.pgw.sdk.constants.PgwFPXConstants;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.exception.PgwException;
import com.bestpay.pgw.sdk.model.FpxPayResponse;
import com.bestpay.pgw.sdk.model.PgwTransactionDto;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.pgw.service.PgwBankDetailsService;
import com.bestpay.pgw.service.PgwCtrlGenService;
import com.bestpay.pgw.service.PgwMultiChannelService;
import com.bestpay.pgw.service.PgwTransactionHistoryService;
import com.bestpay.pgw.service.PgwTransactionService;
import com.bestpay.pgw.service.RefBankService;
import com.bestpay.pgw.service.RefConfigService;
import com.bestpay.pgw.service.RefFpxBestpayCodeService;


/**
 * @author Chaithanya Kumar
 * @since 03/07/2018
 */
@RestController
public class PgwTransactionRestController extends AbstractRestController {

	private static final Logger logger = LoggerFactory.getLogger(PgwTransactionRestController.class);

	@Autowired
	public PgwTransactionService pgwTransactionService;

	@Autowired
	public PgwCtrlGenService pgwCtrlGen;

	@Autowired
	public RefBankService bankService;

	@Autowired
	public PgwTransactionHistoryService transHistoryService;

	@Autowired
	public PgwMultiChannelService multiChannelService;

	@Autowired
	public PgwBankDetailsService pgwBankDetailsService;

	@Autowired
	public RefConfigService configService;

	@Autowired
	public RefFpxBestpayCodeService refFpxBestpayCodeService;

	@GetMapping(value = PgwUrlConstants.FIND_BY_ORDER_ID_TRANSID, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwTransactionDto findBySellerOrderNo(@RequestParam(value = "transId") String transId,
			@RequestParam(value = "orderId") String orderId, HttpServletRequest request) {
		try {
			PgwTransaction pgwTransaction = pgwTransactionService.findByOrderIDAndTransID(transId, orderId);
			if (!BaseUtil.isObjNull(pgwTransaction)) {
				return dozerMapper.map(pgwTransaction, PgwTransactionDto.class);
			}
		} catch (Exception e) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW112, new String[] { orderId, transId });
		}
		return null;
	}


	@GetMapping(value = PgwUrlConstants.FIND_BY_MERCHANT_ID_ORDER_ID, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwTransactionDto findByMerchantIdAndOrderId(@RequestParam(value = "merchantId") String merchantId,
			@RequestParam(value = "orderId") String orderId, HttpServletRequest request) {
		try {
			PgwTransaction pgwTransaction = pgwTransactionService.findByMerchantIDAndOrderID(merchantId, orderId);
			if (!BaseUtil.isObjNull(pgwTransaction)) {
				return dozerMapper.map(pgwTransaction, PgwTransactionDto.class);
			}
		} catch (Exception e) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW115, new String[] { orderId, merchantId });
		}
		return null;
	}


	@PostMapping(value = PgwUrlConstants.CREATE_PGW_TRANSACTION, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwTransactionDto createPgwTransaction(@RequestBody PgwTransactionDto pgwTrans,
			HttpServletRequest request) {
		if (BaseUtil.isObjNull(pgwTrans)) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW113, new String[] {});
		}
		if (BaseUtil.isObjNull(pgwTrans.getTransId())) {
			String transId = pgwCtrlGen.generateRefNo();
			pgwTrans.setTransId(transId);
			pgwTrans.setStatus(PgwConstants.TRANS_STAT_PENDING);
		}
		PgwTransaction res = pgwTransactionService.create(dozerMapper.map(pgwTrans, PgwTransaction.class));
		// create transaction history
		saveTransHistory(res);
		return dozerMapper.map(res, PgwTransactionDto.class);
	}


	@GetMapping(value = PgwUrlConstants.UPDATE_CHANNEL_AND_BANK, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwTransactionDto updateBankandChannel(@RequestParam(value = "transId") String transId,
			@RequestParam(value = "orderId") String orderId, @RequestParam(value = "bankId") String bankId,
			@RequestParam(value = "channel") String channel, HttpServletRequest request) {
		PgwTransaction ptr = pgwTransactionService.findByOrderIDAndTransID(transId, orderId);
		if (BaseUtil.isObjNull(ptr)) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW112, new String[] { orderId, transId });
		}
		RefBank bank = bankService.findByBankCode(bankId);
		if (!BaseUtil.isObjNull(bank)) {
			ptr.setBankName(bank.getDisplayName());
		}
		ptr.setBankCode(bankId);
		ptr.setChannel(channel);
		PgwTransaction transaction = pgwTransactionService.update(ptr);
		// create transaction history
		saveTransHistory(transaction);
		return dozerMapper.map(transaction, PgwTransactionDto.class);
	}


	@PostMapping(value = PgwUrlConstants.UPDATE_PGW_TRANSACTION, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })

	public PgwTransactionDto updatePgwTransaction(@RequestBody PgwTransactionDto transaction,
			HttpServletRequest request) {
		if (BaseUtil.isObjNull(transaction)) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW111, new String[] {});
		}
		PgwTransaction ptr = pgwTransactionService.findByOrderIDAndTransID(transaction.getTransId(),
				transaction.getOrderId());
		if (BaseUtil.isObjNull(ptr)) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW112,
					new String[] { transaction.getTransId(), transaction.getOrderId() });
		}
		ptr.setStatus(transaction.getStatus());
		ptr.setResMsg(transaction.getResMsg());
		PgwTransaction transRes = pgwTransactionService.update(ptr);
		return dozerMapper.map(transRes, PgwTransactionDto.class);
	}


	@PostMapping(value = PgwUrlConstants.ADD_FPX_RESPONSE, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwTransactionDto updateResponse(@RequestBody FpxPayResponse fpxPayResponse, HttpServletRequest request) {

		if (BaseUtil.isObjNull(fpxPayResponse)) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW113, new String[] {});
		}

		PgwTransaction transaction = pgwTransactionService.findByOrderIDAndTransID(
				fpxPayResponse.getFpx_sellerExOrderNo(), fpxPayResponse.getFpx_sellerOrderNo());

		if (BaseUtil.isObjNull(transaction)) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW112, new String[] {
					fpxPayResponse.getFpx_sellerExOrderNo(), fpxPayResponse.getFpx_sellerOrderNo() });
		}

		RefFpxBestpayCode fpxBestpayCode = refFpxBestpayCodeService
				.findBestpayCodeDescr(fpxPayResponse.getFpx_debitAuthCode());

		logger.info("updating online payment");
		logger.info("fpx code = {} && bestpay code = {}, bestpay description = {}", fpxPayResponse.getFpx_debitAuthCode(), fpxBestpayCode.getBestpayCode(), fpxBestpayCode.getBestpayDescription());
		// set transaction status
		if (BaseUtil.isEqualsCaseIgnore(fpxPayResponse.getFpx_debitAuthCode(),
				PgwFPXConstants.FPX_RESPONSE_CODE_00)) {
			transaction.setStatus(PgwConstants.TRANS_STAT_SUCCESS);
		} else if (BaseUtil.isEqualsCaseIgnore(fpxPayResponse.getFpx_debitAuthCode(),
				PgwFPXConstants.FPX_RESPONSE_CODE_99)) {
			transaction.setStatus(PgwConstants.TRANS_STAT_PENDING);
		} else if (BaseUtil.isEqualsCaseIgnore(fpxPayResponse.getFpx_debitAuthCode(),
				PgwFPXConstants.FPX_RESPONSE_CODE_09)) {
			transaction.setStatus(PgwConstants.TRANS_STAT_PENDING);
		} else if (BaseUtil.isEqualsCaseIgnore(fpxPayResponse.getFpx_debitAuthCode(),
				PgwFPXConstants.FPX_RESPONSE_CODE_12)) {
			transaction.setStatus(PgwConstants.TRANS_STAT_INVALID);
		} else {
			transaction.setStatus(PgwConstants.TRANS_STAT_FAIL);
		}

		transaction.setRefId(fpxPayResponse.getFpx_fpxTxnId());
		transaction.setResCode(fpxPayResponse.getFpx_debitAuthCode());
		transaction.setResMsg(fpxBestpayCode.getBestpayDescription());
		transaction.setTransAmt(Float.parseFloat(fpxPayResponse.getFpx_txnAmount()));
		// calculate Actual Amount
		try {
			Float finalAmt = getActualAmount(transaction.getMerchantId(), transaction.getChannel(),
					Float.parseFloat(fpxPayResponse.getFpx_txnAmount()));
			transaction.setActAmt(finalAmt);
			Float transrate = Float.parseFloat(fpxPayResponse.getFpx_txnAmount()) - finalAmt;
			DecimalFormat df = new DecimalFormat("#.##");

			transaction.setTransRate(Float.valueOf(df.format(transrate)));
		} catch (Exception e) {
			logger.info("Error while calculating Actual Amount  {}", e.getMessage());
		}

		PgwTransaction res = pgwTransactionService.update(transaction);
		// create transaction history
		saveTransHistory(res);
		return dozerMapper.map(res, PgwTransactionDto.class);
	}


	@GetMapping(value = PgwUrlConstants.FIND_FPX_PENDING_TRANS, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<PgwTransactionDto> findFpxPendingTransactions(HttpServletRequest request) {
		List<PgwTransactionDto> transList = new ArrayList<>();
		try {
			Integer timebuffer = 10;
			PgwConfig config = configService.findByConfigCode(PgwConstants.FPX_SCHEDULAR_TIME_BUFFER);
			if (!BaseUtil.isObjNull(config)) {
				timebuffer();
			}

			Date currentDate = new Date();
			Calendar cal = Calendar.getInstance();
			// remove next line if you're always using the current time.
			cal.setTime(currentDate);
			cal.add(Calendar.MINUTE, -timebuffer);
			Date paymentTime = cal.getTime();

			List<PgwTransaction> pgwTrans = pgwTransactionService.findFpxPendingTransactions(paymentTime);
			for (PgwTransaction t : pgwTrans) {
				PgwTransactionDto transction = dozerMapper.map(t, PgwTransactionDto.class);
				transList.add(transction);
				Integer retryCount = 1;
				if (!BaseUtil.isObjNull(transction.getRetryCnt())) {
					retryCount = transction.getRetryCnt() + 1;
				}
				pgwTransactionService.updateRetryCount(retryCount, t.getTransId());
			}
		} catch (Exception e) {
			logger.info("Error in Fpx Pending transaction history  {}", e.getMessage());
		}
		return transList;
	}


	/**
	 * @author mohammad.rashid
	 */
	private Integer timebuffer() {
		Integer timebuffer = 0;
		PgwConfig config = configService.findByConfigCode(PgwConstants.FPX_SCHEDULAR_TIME_BUFFER);
		if (!BaseUtil.isObjNull(config)) {
			try {
				timebuffer = Integer.parseInt(config.getConfigVal());
			} catch (Exception e) {
				logger.info("Error in finding value from config  {} ", e.getMessage());
			}
		}
		return timebuffer;
	}


	private void saveTransHistory(PgwTransaction p) {
		try {
			PgwTransactionHistory h = dozerMapper.map(p, PgwTransactionHistory.class);
			h.setId(null);
			transHistoryService.create(h);
		} catch (Exception e1) {
			logger.info("Error in creating transaction history {}", e1.getMessage());
		}
	}


	// calculating actual amount based on rate and cost which ever is highest
	// with respect to Bill amount
	private Float getActualAmount(String merchantId, String channel, Float billAmt) {
		Float actualAmt = billAmt;
		try {

			Double percentage = 0.0d;
			Double fixedAmt = 0.0d;
			PgwBankDetails bankDetails = pgwBankDetailsService.findByMerchantId(merchantId);
			if (!BaseUtil.isObjNull(bankDetails)) {
				percentage = bankDetails.getTransactionRate();
				fixedAmt = bankDetails.getTransactionFee();
			}

			Double gstValue = 0.0d;
			PgwConfig config = configService.findByConfigCode(PgwConstants.PGW_CONFIG_GST);
			if (!BaseUtil.isObjNull(config)) {
				gstValue = Double.parseDouble(config.getConfigVal());
			}

			PgwMultiChannel res = multiChannelService.findActiveMultiChannelByMerIdAndChannel(merchantId, channel);
			if (!BaseUtil.isObjNull(res)) {
				percentage = res.getRate();
				fixedAmt = res.getCost();
			}

			Double percentageAmt = 0.0d;
			if (percentage != null && percentage > 0) {
				percentageAmt = (double) (billAmt * (float) (percentage / 100));
			}
			DecimalFormat df = new DecimalFormat("#.##");

			if (percentageAmt > fixedAmt) {
				Double gst = percentageAmt * gstValue;
				actualAmt = (float) (billAmt - (percentageAmt + Double.valueOf(df.format(gst))));
			} else if (fixedAmt != null && fixedAmt > 0) {
				Double gst = fixedAmt * gstValue;
				actualAmt = (float) (billAmt - (fixedAmt + Double.valueOf(df.format(gst))));
			}
		} catch (NumberFormatException e) {
			logger.info("Error in getting GST value from config {}", e.getMessage());
		} catch (Exception e) {
			logger.info("Error Calculating Actual Amount {}", e.getMessage());
		}
		return actualAmt;
	}
	
	@GetMapping(value = PgwUrlConstants.FIND_BY_MERCHANT_ID_REFID, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwTransactionDto findByMerchantIdByRefId(@RequestParam(value = "refId") String refId,
			 HttpServletRequest request) {
		try {
			PgwTransaction pgwTransaction = pgwTransactionService.findByMerchantIDAndRefId(refId);
			if (!BaseUtil.isObjNull(pgwTransaction)) {
				return dozerMapper.map(pgwTransaction, PgwTransactionDto.class);
			}
		} catch (Exception e) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW115, new String[] { refId });
		}
		return null;
	}
	 	
	@GetMapping(value = PgwUrlConstants.UPDATE_TRANS_STATUS_MAXMONEY, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwTransactionDto updateTransStatus(@RequestParam(value = "oid") String oid,
			@RequestParam(value = "status") String status, @RequestParam(value = "errcode") String errcode,
			@RequestParam(value = "resdsMessage") String resdsMessage,
			 HttpServletRequest request) {
		PgwTransaction ptr = pgwTransactionService.findByMerchantIDAndRefId(oid);
		if (BaseUtil.isObjNull(ptr)) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW112, new String[] { oid });
		}
		ptr.setStatus(status);
		ptr.setResCode(errcode);
		ptr.setResMsg(resdsMessage);
		PgwTransaction transaction = pgwTransactionService.update(ptr);
		// create transaction history
		saveTransHistory(transaction);
		return dozerMapper.map(transaction, PgwTransactionDto.class);
	}
	
	@GetMapping(value = PgwUrlConstants.FIND_REMIT_PENDING_TRANS, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<PgwTransactionDto> findRemitPendingTransactions(HttpServletRequest request) {
		List<PgwTransactionDto> transList = new ArrayList<>();
		try {
			Integer timebuffer = 10;
			PgwConfig config = configService.findByConfigCode(PgwConstants.FPX_SCHEDULAR_TIME_BUFFER);
			if (!BaseUtil.isObjNull(config)) {
				timebuffer();
			}

			Date currentDate = new Date();
			Calendar cal = Calendar.getInstance();
			// remove next line if you're always using the current time.
			cal.setTime(currentDate);
			cal.add(Calendar.MINUTE, -timebuffer);
			Date paymentTime = cal.getTime();

			List<PgwTransaction> pgwTrans = pgwTransactionService.findRemitPendingTransactions(paymentTime);
			for (PgwTransaction t : pgwTrans) {
				PgwTransactionDto transction = dozerMapper.map(t, PgwTransactionDto.class);
				transList.add(transction);
				Integer retryCount = 1;
				if (!BaseUtil.isObjNull(transction.getRetryCnt())) {
					retryCount = transction.getRetryCnt() + 1;
				}
				pgwTransactionService.updateRetryCount(retryCount, t.getTransId());
			}
		} catch (Exception e) {
			logger.info("Error in Remit Pending transaction history  {}", e.getMessage());
		}
		return transList;
	}
	
	
	@GetMapping(value = PgwUrlConstants.UPDATE_TRANS_STATUS_IRBILLPLZ, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwTransactionDto updateTransStatusIRBillPlz(@RequestParam(value = "oid") String oid,
			@RequestParam(value = "status") String status,
			@RequestParam(value = "errcode") String errcode,
			@RequestParam(value = "resdsMessage") String resdsMessage,
			@RequestParam(value = "billplzid") String billplzid,
			 HttpServletRequest request) {
		PgwTransaction ptr = pgwTransactionService.findByMerchantIDAndRefId(oid);
		if (BaseUtil.isObjNull(ptr)) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW112, new String[] { oid });
		}
		ptr.setStatus(status);
		ptr.setResMsg(resdsMessage);
		ptr.setResCode(errcode);
		ptr.setSubmerId(billplzid);
		PgwTransaction transaction = pgwTransactionService.update(ptr);
		// create transaction history
		saveTransHistory(transaction);
		return dozerMapper.map(transaction, PgwTransactionDto.class);
	}
	
	 @GetMapping(value = PgwUrlConstants.FIND_BY_MERCHANT_ID_SUBMERID, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public PgwTransactionDto findByMerchantIdBySubmerId(@Valid @RequestParam(value = "submerId") String submerId,
			 HttpServletRequest request) {
		try {
			PgwTransaction pgwTransaction = pgwTransactionService.findByMerchantIDAndSubmerId(submerId);
			if (!BaseUtil.isObjNull(pgwTransaction)) {
				return dozerMapper.map(pgwTransaction, PgwTransactionDto.class);
			}
		} catch (Exception e) {
			throw new PgwException(PgwErrorCodeEnum.E404PGW115, new String[] { submerId });
		}
		return null;
	} 
	 
	 @GetMapping(value = PgwUrlConstants.FIND_BY_TRANSACTION_ID_ORDERID, consumes = {
				MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
		public PgwTransactionDto findByMerchantIdByOrderId(@Valid @RequestParam(value = "transOrderId") String transOrderId,
				 HttpServletRequest request) {
			try {
				PgwTransaction pgwTransaction = pgwTransactionService.findByMerOrderDetails(transOrderId);
				if (!BaseUtil.isObjNull(pgwTransaction)) {
					return dozerMapper.map(pgwTransaction, PgwTransactionDto.class);
				}
			} catch (Exception e) {
				throw new PgwException(PgwErrorCodeEnum.E404PGW115, new String[] { transOrderId });
			}
			return null;
		} 
		 
	 @PostMapping(value = PgwUrlConstants.UPDATE_TRANS_STATUS_IPAY, consumes = {
				MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
		public PgwTransactionDto updateTransStatusIpay(@RequestBody PgwTransactionDto pgwTrans,HttpServletRequest request) {
			PgwTransaction ptr = pgwTransactionService.findByMerOrderDetails(pgwTrans.getOrderId());
			ptr.setStatus(pgwTrans.getStatus());
			ptr.setResMsg(pgwTrans.getResMsg());
			ptr.setResCode(pgwTrans.getResCode());
			ptr.setBankCntry(pgwTrans.getBankCntry());
			ptr.setBankCode(pgwTrans.getBankCode());
			ptr.setCcName(pgwTrans.getCcName());
			ptr.setBankName(pgwTrans.getBankName());
			ptr.setCcNo(pgwTrans.getCcNo());
			ptr.setPaymentId(pgwTrans.getPaymentId());
			if (BaseUtil.isObjNull(ptr)) {
				throw new PgwException(PgwErrorCodeEnum.E404PGW112, new String[] { pgwTrans.getOrderId() });
			}
			PgwTransaction transaction = pgwTransactionService.update(ptr);
			// create transaction history
			saveTransHistory(transaction);
			return dozerMapper.map(transaction, PgwTransactionDto.class);
		}
}
