/**
 *  
 */
package com.bestpay.pgw.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.PgwTransaction;
import com.bestpay.pgw.util.QualifierConstants;

/**
 * @author Chaithanya Kumar
 * @since 10/07/2018
 */
@Repository
@RepositoryDefinition(domainClass = PgwTransaction.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_TRANSACTION_DAO)
public interface PgwTransactionRepository extends GenericRepository<PgwTransaction> {

	
	@Query("select u from PgwTransaction u where u.transId=:transId and u.orderId=:orderId")
	public PgwTransaction findByOrderIDAndTransID (@Param("transId") String transId, @Param("orderId") String orderId);

	@Query("select u from PgwTransaction u where u.merchantId=:merchantId and u.orderId=:orderId")
	public PgwTransaction findByMerchantIDAndOrderID (@Param("merchantId") String merchantId, @Param("orderId") String orderId);
	
	
	@Query("select u from PgwTransaction u where (u.channel='FPX' or u.channel='B2C' or u.channel='B2B') and u.status='pending' and u.createDt <=:paymentTime ")
	public List<PgwTransaction> findFpxPendingTransactions (@Param("paymentTime") Date paymentTime );
	
	@Modifying
	@Query("update PgwTransaction u set u.retryCnt=:retryCnt  where u.transId=:transId ")
	public Integer updateRetryCount (@Param("retryCnt") Integer retryCnt,@Param("transId") String transId );

	@Query("select u from PgwTransaction u where u.refId=:refId")
	public PgwTransaction findByMerchantIDAndRefID (@Param("refId") String refId);
	
	@Query("select u from PgwTransaction u where u.orderId=:orderId")
	public PgwTransaction findByMerchantIdAndOrderDetails (@Param("orderId") String orderId);
	
	@Query("select u from PgwTransaction u where (u.channel='MAX_MONEY') and u.status='pending' and u.createDt <=:paymentTime ")
	public List<PgwTransaction> findRemitPendingTransactions (@Param("paymentTime") Date paymentTime );

	@Query("select u from PgwTransaction u where u.submerId=:submerId")
	public PgwTransaction findByMerchantIDAndSubmerchantId(@Param("submerId") String submerId);
	
	@Query("select u from PgwTransaction u where u.channel=:channel and u.status=:status and datediff(now(),u.paymentDt)<9")
	public List<PgwTransaction> findChannelAndStatusPast10days(@Param("channel") String channel,@Param("status") String status);
	
}