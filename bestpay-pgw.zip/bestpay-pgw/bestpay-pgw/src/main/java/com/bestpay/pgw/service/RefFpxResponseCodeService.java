/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.FpxResponseCodeRepository;
import com.bestpay.pgw.model.RefFpxResponseCode;
import com.bestpay.pgw.util.QualifierConstants;
/**
 * @author Sridhar Kapidi
 * @since 29/11/2017
 */
@Service(QualifierConstants.FPX_RESPONSE_CODE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.FPX_RESPONSE_CODE_SVC)
@Transactional
public class RefFpxResponseCodeService extends AbstractService<RefFpxResponseCode>{

	@Autowired
	private FpxResponseCodeRepository fpxResponseCodeDao;
	
	@Override
	public GenericRepository<RefFpxResponseCode> primaryDao() {
		return fpxResponseCodeDao;
	}
	
	public RefFpxResponseCode findByFpxCode(String fpxCode){
		return fpxResponseCodeDao.findByFpxCode(fpxCode);
	}
	
	public List<RefFpxResponseCode> findByFpxDesc(String fpxDesc){
		return fpxResponseCodeDao.findByFpxDesc(fpxDesc);
	}
	
	public RefFpxResponseCode findByMaxmoneyDesc(String desc){
		return fpxResponseCodeDao.findByMaxmoneyDesc(desc);
	}
}