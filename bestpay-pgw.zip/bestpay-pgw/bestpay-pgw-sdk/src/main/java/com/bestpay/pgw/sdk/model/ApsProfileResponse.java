package com.bestpay.pgw.sdk.model;


import java.io.Serializable;


public class ApsProfileResponse implements Serializable {

	private String merchantId;

	private String url;

	private String verifyKey;


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public String getVerifyKey() {
		return verifyKey;
	}


	public void setVerifyKey(String verifyKey) {
		this.verifyKey = verifyKey;
	}

}
