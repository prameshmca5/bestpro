/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;


/**
 * @author Atiqah
 * @since June 20, 2018
 */
public class MerSendAccInfo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1864073233598003483L;

	private String loginId;

	private String email;

	private Integer merProfId;

	private String merchantId;

	private Integer pdpa;


	public String getLoginId() {
		return loginId;
	}


	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Integer getMerProfId() {
		return merProfId;
	}


	public void setMerProfId(Integer merProfId) {
		this.merProfId = merProfId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public Integer getPdpa() {
		return pdpa;
	}


	public void setPdpa(Integer pdpa) {
		this.pdpa = pdpa;
	}

}