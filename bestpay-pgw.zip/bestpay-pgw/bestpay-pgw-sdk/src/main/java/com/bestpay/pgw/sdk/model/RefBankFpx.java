/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


public class RefBankFpx implements Serializable {

	private static final long serialVersionUID = -3186445980890420147L;

	private int id;

	private String bankName;

	private String displayName;

	private String bankCode;

	private String type;

	private String createId;

	private Timestamp createDt;


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getDisplayName() {
		return displayName;
	}


	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}


	public String getBankCode() {
		return bankCode;
	}


	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

}
