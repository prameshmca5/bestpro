/**
 * Copyright 2019
 */
package com.be.core;


import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.core.RedisTemplate;

import com.be.config.HttpClientRestService;
import com.be.model.RefDocument;
import com.be.model.RefStatus;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.ReferenceConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.MemberProfile;
import com.be.sdk.model.PreReg;
import com.be.sdk.model.Watchlist;
import com.be.service.BeMemberProfileService;
import com.be.service.BePreRegService;
import com.be.service.BeWatchlistService;
import com.be.service.MessageService;
import com.be.service.RefStatusService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.idm.sdk.model.Fcm;
import com.idm.sdk.model.FcmDevice;
import com.notify.sdk.constants.MailTypeEnum;
import com.notify.sdk.model.Attachment;
import com.notify.sdk.model.ByteAttachment;
import com.notify.sdk.model.Notification;
import com.notify.sdk.util.MailUtil;
import com.report.sdk.model.Report;
import com.util.BaseUtil;
import com.util.constants.BaseConfigConstants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2017
 */
public abstract class AbstractRestController extends GenericAbstract {

	protected static final Logger LOGGER = LoggerFactory.getLogger(AbstractRestController.class);

	@Autowired
	protected Mapper dozerMapper;

	@Autowired
	protected ObjectMapper objectMapper;

	@Autowired
	protected CacheManager cacheManager;

	@Autowired
	protected RedisTemplate<String, String> redisTemplate;

	@Autowired
	protected MessageService messageService;

	@Autowired
	private HttpClientRestService httpClientRestService;

	@Autowired
	BeMemberProfileService beMemberProfileSvc;

	@Autowired
	RefStatusService refStatusSvc;

	@Autowired
	BePreRegService bePreRegSvc;

	@Autowired
	BeWatchlistService beWatchlistSvc;


	@Override
	protected String getCurrUserId(HttpServletRequest request) {
		return String.valueOf(request.getAttribute("currUserId"));
	}


	protected String getCurrUserFullname(HttpServletRequest request) {
		return String.valueOf(request.getAttribute("currUserFname"));
	}


	protected Timestamp getSQLTimestamp() {
		Calendar calendar = Calendar.getInstance();
		java.util.Date now = calendar.getTime();
		return new java.sql.Timestamp(now.getTime());
	}


	public String getPwordEkey() {
		return messageService.getMessage(BaseConfigConstants.SVC_IDM_EKEY);
	}


	public HttpClientRestService getHttpClientRestService() {
		return httpClientRestService;
	}


	public void setHttpClientRestService(HttpClientRestService httpClientRestService) {
		this.httpClientRestService = httpClientRestService;
	}


	protected void sendFcmNotification(String userId, String createId, Map<String, Object> map, String fcmTemplate,
			HttpServletRequest request) {
		FcmDevice fcmDevice = new FcmDevice();
		fcmDevice.setStatus(true);
		fcmDevice.setFcm(new Fcm());
		fcmDevice.getFcm().setUserId(userId);
		fcmDevice.getFcm().setStatus(true);
		List<FcmDevice> devices = getIdmService(request).searchFcmDevice(fcmDevice);
		if (!BaseUtil.isListNull(devices)) {
			for (FcmDevice device : devices) {
				if (!BaseUtil.isObjNull(device.getFcmToken())) {
					Notification notification = new Notification();
					notification.setNotifyTo(userId);
					notification.setNotifyCc(device.getFcmToken());
					notification.setMetaData(MailUtil.convertMapToJson(map));
					notification.setNotifyType(MailTypeEnum.FCM.getType());
					notification.setContent(createId);
					getNotifyService(request).addNotification(notification, fcmTemplate);
				}
			}
		}
	}


	public Attachment setNotificationAttachments(Report report, RefDocument refDoc) {
		ByteAttachment attachment = new ByteAttachment();
		if (!BaseUtil.isObjNull(report)) {
			attachment.setFile(report.getReportBytes());
			attachment.setFileName(refDoc.getDocDesc());
			attachment.setMimeType(refDoc.getType());
		}
		return attachment;
	}


	public void checkValidRegIdNo(String idNo) {
		// check duplicate idNo PEND/VER
		RefStatus status = refStatusSvc.findByStatusCodeStatusType(ReferenceConstants.REG_STATUS_REJ,
				ReferenceConstants.STATUS_TYPE_REG_STATUS);
		PreReg preReg = new PreReg();
		preReg.setIdNo(idNo);
		preReg.setStatusId(status.getStatusId());
		preReg.setNotIn(true);
		int preRegCount = (int) bePreRegSvc.getCount(preReg);
		if (preRegCount != 0) {
			throw new BeException(BeErrorCodeEnum.I409C001);
		}

		MemberProfile memberProf = new MemberProfile();
		memberProf.setIdNo(idNo);
		memberProf.setStatusId(status.getStatusId());
		memberProf.setNotIn(true);
		int memberProfCount = (int) beMemberProfileSvc.getCount(memberProf);
		if (memberProfCount != 0) {
			throw new BeException(BeErrorCodeEnum.I409C001);
		}

		Watchlist watchlist = new Watchlist();
		watchlist.setIdNo(idNo);
		watchlist.setStatus(true);
		int watchlistCount = (int) beWatchlistSvc.getCount(watchlist);
		if (watchlistCount != 0) {
			throw new BeException(BeErrorCodeEnum.I409C003);
		}
	}


	public void checkContactNo(String contactNo) {
		// check duplicate contact no
		RefStatus status = refStatusSvc.findByStatusCodeStatusType(ReferenceConstants.REG_STATUS_REJ,
				ReferenceConstants.STATUS_TYPE_REG_STATUS);
		PreReg preReg = new PreReg();
		preReg.setContactNo(contactNo);
		preReg.setStatusId(status.getStatusId());
		preReg.setNotIn(true);
		int preRegCount = (int) bePreRegSvc.getCount(preReg);
		if (preRegCount != 0) {
			throw new BeException(BeErrorCodeEnum.I409C001);
		}

		MemberProfile memberProf = new MemberProfile();
		memberProf.setContactNo(contactNo);
		memberProf.setStatusId(status.getStatusId());
		memberProf.setNotIn(true);
		int memberProfCount = (int) beMemberProfileSvc.getCount(memberProf);
		if (memberProfCount != 0) {
			throw new BeException(BeErrorCodeEnum.I409C001);
		}

		Watchlist watchlist = new Watchlist();
		watchlist.setContactNo(contactNo);
		watchlist.setStatus(true);
		int watchlistCount = (int) beWatchlistSvc.getCount(watchlist);
		if (watchlistCount != 0) {
			throw new BeException(BeErrorCodeEnum.I409C003);
		}
	}

}