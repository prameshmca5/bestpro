package com.bestid.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class ServiceConstants {

	public static final String STAT_LST_CONFIG = "APJ_CONFIG";

	public static final String STAT_LST_SECTOR = "SECTOR";

	public static final String STAT_LST_STATE = "STATE";

	public static final String STAT_LST_CITY = "CITY";

	public static final String STAT_LST_COUNTRY = "COUNTRY";

	public static final String STAT_LST_RELATIONSHIP = "RELATIONSHIPSHIP";

	public static final String STAT_LST_DOCUMENT = "DOCUMENT";

	public static final String STAT_LST_NATIONALITY = "NATIONALITY";

	public static final String STAT_LST_MARITAL_STATUS = "MARITAL_STATUS";

	public static final String STAT_LST_LANE = "LANE";

	public static final String STAT_LST_GENDER = "GENDER";

	public static final String STAT_LST_PAYMENT_TYPE = "PAYMENT_TYPE";

	public static final String STAT_LST_ENTRY_TYPE = "ENTRY_TYPE";

	public static final String STAT_LST_VISA_TYPE = "VISA_TYPE";

	public static final String STAT_LST_VISA_CHANNEL = "VISA_CHANNEL";

	public static final String STAT_LST_STAY_PURPOSE = "STAY_PURPOSE";


	private ServiceConstants() {
		throw new IllegalStateException("ServiceConstants class");
	}
}