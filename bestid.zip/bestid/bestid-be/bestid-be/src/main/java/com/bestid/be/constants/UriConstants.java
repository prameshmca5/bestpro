/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.constants;

/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
public class UriConstants {

	private UriConstants() {
		throw new IllegalStateException("Utility class");
	}

	public static final String SERVICES = "/services";

	public static final String API_SERVICES = SERVICES + "/api";

	public static final String API_GENERATE_QR = API_SERVICES + "/generateQR";

	public static final String API_QR_IMAGE = API_SERVICES + "/qrImage";

	public static final String API_AUTHENTICATE_CHECK = API_SERVICES + "/authCheck";

	public static final String MOBILE_SERVICES = SERVICES + "/mobile";

	public static final String MOBILE_LOGIN = MOBILE_SERVICES + "/login";

	public static final String MOBILE_LOGOUT = MOBILE_SERVICES + "/logout";

	public static final String MOBILE_REGISTRATION_FDCU = MOBILE_SERVICES + "/registration/fdcu";

	public static final String MOBILE_REGISTRATION_PIN = MOBILE_SERVICES + "/registration/pin";

	public static final String MOBILE_VERIFICATION_PIN = MOBILE_SERVICES + "/verification/pin";

	public static final String MOBILE_REGISTRATION_FACE = MOBILE_SERVICES + "/registration/faceId";

	public static final String MOBILE_VERIFICATION_FACE = MOBILE_SERVICES + "/verification/faceId";

	public static final String MOBILE_VERIFICATION_QR = MOBILE_SERVICES + "/verification/qrAuth";

	public static final String MOBILE_FIND_ACTIVE_DEVICE = MOBILE_SERVICES + "/activeDevice";

	public static final String NOTIFICATIONS = "/notifications";

	public static final String NOTIFY_SEND_ALL = NOTIFICATIONS + "/sendAll";

	public static final String NOTIFY_MAIL = NOTIFICATIONS + "/mail";

	public static final String NOTIFY_MAIL_SEND = NOTIFICATIONS + "/mail/send";

	public static final String NOTIFY_SMS = NOTIFICATIONS + "/sms";

	public static final String NOTIFY_SMS_SEND = NOTIFICATIONS + "/sms/send";

	public static final String NOTIFY_CONFIG = NOTIFICATIONS + "/config";

	public static final String MAIL_TEMPLATE = NOTIFICATIONS + "/mail/templates";

	public static final String UPDATE_MAIL_TEMPLATE = NOTIFICATIONS + "/mail/template/update";

	public static final String API_LOGIN = API_SERVICES + "/login";

	public static final String API_USER_SEARCH = API_SERVICES + "/user/search";

	public static final String API_USER_REGISTER = API_SERVICES + "/user/register";

	public static final String API_CONTACT_UPDATE = API_SERVICES + "/contact/update";

	public static final String API_DEVICE_SEARCH = API_SERVICES + "/device/search";

	public static final String API_ACTIVATION_CODE_GENERATE = API_SERVICES + "/activationCode/generate";

	public static final String API_DIGITALID_REVOKE = API_SERVICES + "/digitalid/revoke";

	public static final String API_QR_VERIFY = API_SERVICES + "/qr/verify";

	public static final String MOBILE_REGISTRATION_CERT = MOBILE_SERVICES + "/registration/cert";

	public static final String MOBILE_STORE_CERT = MOBILE_SERVICES + "/store/cert";

	public static final String MOBILE_SUBMIT_CERT = MOBILE_SERVICES + "/submit/cert";

	public static final String MOBILE_REVOKE_CERT = MOBILE_SERVICES + "/revoke/cert";

	public static final String API_QR_CODE_GENERATE = API_SERVICES + "/digitalid/qr/generate";

	public static final String API_QR_CODE_AUTHORIZE = API_SERVICES + "/authorize/qr/generate";

	public static final String API_QR_CODE_VERIFY = API_SERVICES + "/qr/verify";

	public static final String API_ACTIVATION_CODE_VERIFY = API_SERVICES + "/activationCode/verify";

	public static final String API_UUID_VALIDATION = API_SERVICES + "/uuid/verify";

	public static final String API_PHOTO_VALIDATION = API_SERVICES + "/photo/verify";
	
	public static final String API_DIGITALID_STATUS_CHECK = API_SERVICES + "/digitalId/status/check";

	public static final String MOBILE_SEARCH_FACE = MOBILE_SERVICES + "/face/search";

	public static final String MOBILE_INVITATION_CODE_GENERATE = MOBILE_SERVICES + "/invCode/generate";

	public static final String MOBILE_INVITATION_CODE_VERIFY = MOBILE_SERVICES + "/invCode/verify";

	public static final String MOBILE_AUTH_VALIDATION = MOBILE_SERVICES + "/auth/verify";

	public static final String MOBILE_DIGITALID_VALIDATION = MOBILE_SERVICES + "/digitalId/verify";
	
	

	public static final String MOBILE_REGISTRATION_PROFILE = MOBILE_SERVICES + "/profile/register";

	public static final String SUBSCRIBER_SERVICES = SERVICES + "/subscriber";

	public static final String SUBSCRIBER_ADD = SUBSCRIBER_SERVICES + "/addSubscriber";

	public static final String SUBSCRIBER_SEARCH_COMPANY = SUBSCRIBER_SERVICES + "/searchCompany";

	public static final String SUBSCRIBER_LIST = SUBSCRIBER_SERVICES + "/subscriberList";

	public static final String SUBSCRIBER_DEACTIVATED = SUBSCRIBER_SERVICES + "/subscriberDeactivated";

	public static final String MOBILE_SEARCH_PROFILE = MOBILE_SERVICES + "/profile/search";

	public static final String MOBILE_PINCODE_VERIFY = MOBILE_SERVICES + "/pinCode/verify";

	public static final String MOBILE_PINCODE_UPDATE = MOBILE_SERVICES + "/pinCode/update";
}