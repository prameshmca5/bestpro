/**
 *
 */
package com.bestpay.pgw.service;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.PgwTransactionRepository;
import com.bestpay.pgw.model.PgwTransaction;
import com.bestpay.pgw.util.QualifierConstants;


/**
 * @author Chaithanya Kumar
 * @since 10/07/2018
 */
@Service(QualifierConstants.PGW_TRANSACTION_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_TRANSACTION_SVC)
@Transactional
public class PgwTransactionService extends AbstractService<PgwTransaction> {

	@Autowired
	private PgwTransactionRepository pgwTransactionDao;


	@Override
	public GenericRepository<PgwTransaction> primaryDao() {
		return pgwTransactionDao;
	}


	public PgwTransaction findByOrderIDAndTransID(String transId, String orderId) {
		return pgwTransactionDao.findByOrderIDAndTransID(transId, orderId);
	}


	public PgwTransaction findByMerchantIDAndOrderID(String merchantId, String orderId) {
		return pgwTransactionDao.findByMerchantIDAndOrderID(merchantId, orderId);
	}


	public List<PgwTransaction> findFpxPendingTransactions(Date paymentTime) {
		return pgwTransactionDao.findFpxPendingTransactions(paymentTime);
	}


	public Integer updateRetryCount(Integer retryCnt, String transId) {
		return pgwTransactionDao.updateRetryCount(retryCnt, transId);
	}
	
	public PgwTransaction findByMerchantIDAndRefId(String refId) {
		return pgwTransactionDao.findByMerchantIDAndRefID(refId);
	}
	
	public PgwTransaction findByMerOrderDetails(String orderId) {
		return pgwTransactionDao.findByMerchantIdAndOrderDetails(orderId);
	}
	
	public List<PgwTransaction> findRemitPendingTransactions(Date paymentTime) {
		return pgwTransactionDao.findRemitPendingTransactions(paymentTime);
	}


	public PgwTransaction findByMerchantIDAndSubmerId(String submerId) {
		return pgwTransactionDao.findByMerchantIDAndSubmerchantId(submerId);
	}
	
	public List<PgwTransaction> findChannelAndStatusPast10days(String channel, String status){
		return pgwTransactionDao.findChannelAndStatusPast10days(channel, status);
	}

	
}