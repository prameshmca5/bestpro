/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author Atiqah Khairuddin
 * @since March 28, 2019
 */
public class Provider implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private int providerId;

	private String providerPublicName;

	private String providerName;

	private String address1;

	private String address2;

	private String address3;

	private String postcode;

	private String city;

	private String state;

	private String country;

	private String email;

	private String phone;

	private String ssmId;

	private String picName;

	private String picEmail;

	private String picPhone;

	private String apikey;

	private String url;

	private String password;

	private String fpxUrl;

	private String requeryUrl;

	private String bestpayRedirectUrl;

	private String bestpayCallbackUrl;

	private String bestpayBackendCallbackUrl;

	private String agentCode;

	private String userId;

	private String agentSessionId;

	private String collectionId;

	private String authCode;

	private Timestamp createDt;

	private String createId;

	private String updateId;

	private Timestamp updateDt;


	public int getProviderId() {
		return providerId;
	}


	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}


	public String getProviderPublicName() {
		return providerPublicName;
	}


	public void setProviderPublicName(String providerPublicName) {
		this.providerPublicName = providerPublicName;
	}


	public String getProviderName() {
		return providerName;
	}


	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}


	public String getAddress1() {
		return address1;
	}


	public void setAddress1(String address1) {
		this.address1 = address1;
	}


	public String getAddress2() {
		return address2;
	}


	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	public String getAddress3() {
		return address3;
	}


	public void setAddress3(String address3) {
		this.address3 = address3;
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getSsmId() {
		return ssmId;
	}


	public void setSsmId(String ssmId) {
		this.ssmId = ssmId;
	}


	public String getPicName() {
		return picName;
	}


	public void setPicName(String picName) {
		this.picName = picName;
	}


	public String getPicEmail() {
		return picEmail;
	}


	public void setPicEmail(String picEmail) {
		this.picEmail = picEmail;
	}


	public String getPicPhone() {
		return picPhone;
	}


	public void setPicPhone(String picPhone) {
		this.picPhone = picPhone;
	}


	public String getApikey() {
		return apikey;
	}


	public void setApikey(String apikey) {
		this.apikey = apikey;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getFpxUrl() {
		return fpxUrl;
	}


	public void setFpxUrl(String fpxUrl) {
		this.fpxUrl = fpxUrl;
	}


	public String getRequeryUrl() {
		return requeryUrl;
	}


	public void setRequeryUrl(String requeryUrl) {
		this.requeryUrl = requeryUrl;
	}


	public String getBestpayRedirectUrl() {
		return bestpayRedirectUrl;
	}


	public void setBestpayRedirectUrl(String bestpayRedirectUrl) {
		this.bestpayRedirectUrl = bestpayRedirectUrl;
	}


	public String getBestpayCallbackUrl() {
		return bestpayCallbackUrl;
	}


	public void setBestpayCallbackUrl(String bestpayCallbackUrl) {
		this.bestpayCallbackUrl = bestpayCallbackUrl;
	}


	public String getBestpayBackendCallbackUrl() {
		return bestpayBackendCallbackUrl;
	}


	public void setBestpayBackendCallbackUrl(String bestpayBackendCallbackUrl) {
		this.bestpayBackendCallbackUrl = bestpayBackendCallbackUrl;
	}


	public String getAgentCode() {
		return agentCode;
	}


	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getAgentSessionId() {
		return agentSessionId;
	}


	public void setAgentSessionId(String agentSessionId) {
		this.agentSessionId = agentSessionId;
	}


	public String getCollectionId() {
		return collectionId;
	}


	public void setCollectionId(String collectionId) {
		this.collectionId = collectionId;
	}


	public String getAuthCode() {
		return authCode;
	}


	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}
