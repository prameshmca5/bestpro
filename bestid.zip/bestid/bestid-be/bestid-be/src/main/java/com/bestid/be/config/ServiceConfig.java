/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.config;


import java.util.Locale;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bestid.be.constants.ConfigConstants;
import com.bstsb.camvi.sdk.client.CamviServiceClient;
import com.bstsb.cert.sdk.client.Cs2ServiceClient;
import com.bstsb.cert.sdk.client.MsctgServiceClient;
import com.bstsb.dm.sdk.client.DmServiceClient;
import com.bstsb.icao.sdk.client.IcaoServiceClient;
import com.bstsb.idm.sdk.client.IdmServiceClient;
import com.bstsb.notify.sdk.client.NotServiceClient;
import com.bstsb.signet.sdk.client.SignetServiceClient;
import com.bstsb.util.CryptoUtil;
import com.bstsb.util.constants.BaseConfigConstants;
import com.bstsb.util.constants.BaseConstants;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Mary Jane Buenaventura
 * @since May 8, 2018
 */
@Configuration
public class ServiceConfig implements InitializingBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceConfig.class);

	@Value("${" + BaseConfigConstants.SVC_IDM_URL + "}")
	private String idmUrl;

	@Value("${" + BaseConfigConstants.SVC_IDM_TIMEOUT + "}")
	private int idmTimeout;

	@Value("${" + ConfigConstants.SVC_CAMVI_URL + "}")
	private String camviUrl;

	@Value("${" + ConfigConstants.SVC_CAMVI_UNAME + "}")
	private String camviUname;

	@Value("${" + ConfigConstants.SVC_CAMVI_PWORD + "}")
	private String camviPword;

	@Value("${" + ConfigConstants.SVC_CAMVI_FACE_MIN_VAL + "}")
	private double camviFaceMinVal;

	@Value("${" + BaseConfigConstants.SVC_NOT_URL + "}")
	private String notUrl;

	@Value("${" + BaseConfigConstants.SVC_NOT_TIMEOUT + "}")
	private int notTimeout;

	@Value("${" + ConfigConstants.SVC_CS2_URL + "}")
	private String cs2Url;

	@Value("${" + ConfigConstants.SVC_CS2_PROJ_ID + "}")
	private String cs2ProjId;

	@Value("${" + ConfigConstants.SVC_MISIGNET_URL + "}")
	private String miSignetUrl;

	@Value("${" + ConfigConstants.SVC_MISIGNET_PORT + "}")
	private Integer miSignetPort;

	@Value("${" + BaseConfigConstants.SVC_DM_URL + "}")
	private String dmUrl;

	@Value("${" + BaseConfigConstants.SVC_DM_TIMEOUT + "}")
	private int dmTimeout;

	@Value("${" + BaseConfigConstants.SVC_ICAO_URL + "}")
	private String icaoUrl;

	@Value("${" + BaseConfigConstants.SVC_ICAO_KEY + "}")
	private String icaoKey;

	@Value("${" + BaseConfigConstants.SVC_ICAO_TIMEOUT + "}")
	private int icaoTimeout;

	@Value("${" + ConfigConstants.SVC_MSCTG_URL + "}")
	private String msctgUrl;

	@Value("${" + ConfigConstants.SVC_MSCTG_UNAME + "}")
	private String msctgUname;

	@Value("${" + ConfigConstants.SVC_MSCTG_PWORD + "}")
	private String msctgPword;

	@Autowired
	MessageSource messageSource;


	@Bean
	public Mapper dozerMapper() {
		return new DozerBeanMapper();
	}


	@Bean
	public ObjectMapper objectMapper() {
		return new ObjectMapper();
	}


	@Bean
	public IdmServiceClient idmService() {
		return new IdmServiceClient(idmUrl, idmTimeout);
	}


	@Bean
	public NotServiceClient notService() {
		return new NotServiceClient(notUrl, notTimeout);
	}


	@Bean
	public CamviServiceClient camviService() {
		return new CamviServiceClient(camviUrl, camviUname, camviPword, camviFaceMinVal);
	}


	@Bean
	public Cs2ServiceClient cs2ServiceClient() {
		return new Cs2ServiceClient(cs2Url, Long.parseLong(cs2ProjId));
	}


	@Bean
	public MsctgServiceClient msctgServiceClient() {
		String skey = messageSource.getMessage(BaseConfigConstants.SVC_IDM_SKEY, null, Locale.getDefault());
		return new MsctgServiceClient(msctgUname, CryptoUtil.decrypt(msctgPword, skey), msctgUrl);
	}


	@Bean
	public SignetServiceClient miSignetService() {
		return new SignetServiceClient(miSignetUrl, miSignetPort);
	}


	@Bean
	public DmServiceClient dmService() {
		return new DmServiceClient(dmUrl, dmTimeout);
	}


	@Bean
	public IcaoServiceClient icaoService() {
		return new IcaoServiceClient(icaoUrl, icaoKey, icaoTimeout);
	}


	@Override
	public void afterPropertiesSet() throws Exception {
		final String TIMEOUT = "\t- Timeout (seconds): ";
		final String URL = "URL : ";
		StringBuilder sb = new StringBuilder();
		sb.append(BaseConstants.NEW_LINE + BaseConstants.NEW_LINE);
		sb.append(BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("Integration Service");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("IDM Service URL: " + idmUrl + TIMEOUT + idmTimeout + BaseConstants.NEW_LINE);
		sb.append("NOT Service URL: " + notUrl + TIMEOUT + notTimeout + BaseConstants.NEW_LINE);
		sb.append("DM Service URL: " + dmUrl + TIMEOUT + dmTimeout + BaseConstants.NEW_LINE);
		sb.append("MISIGNET Service URL: " + miSignetUrl + ":" + miSignetPort + BaseConstants.NEW_LINE);
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append(BaseConstants.NEW_LINE);
		sb.append(BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("CAMVI Credentials");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append(URL + camviUrl + BaseConstants.NEW_LINE);
		sb.append("Username : " + camviUname + BaseConstants.NEW_LINE);
		sb.append("Password : " + camviPword);
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append(BaseConstants.NEW_LINE);
		sb.append(BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("CS2 Credentials");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append(URL + cs2Url + BaseConstants.NEW_LINE);
		sb.append("Project Id : " + cs2ProjId);
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append(BaseConstants.NEW_LINE);
		sb.append(BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("ICAO Credentials");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append(URL + icaoUrl + TIMEOUT + icaoTimeout + BaseConstants.NEW_LINE);
		sb.append("Project Key : " + icaoKey);
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append(BaseConstants.NEW_LINE);
		sb.append(BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("MSC Trustgate Credentials");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append(URL + msctgUrl + BaseConstants.NEW_LINE);
		sb.append("Username : " + msctgUname + BaseConstants.NEW_LINE);
		sb.append("Password : " + msctgPword);
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);

		LOGGER.info("{}", sb);
	}

}