package com.bestpay.be.sdk.model;


public class RegisterBeneficiaryRequest {

	private String senderCustomerId;

	private String firstName;

	private String middleName;

	private String lastName;

	private String address;

	private String city;

	private String country;

	private String mobile;

	private String email;

	private String relationShip;


	public String getSenderCustomerId() {
		return senderCustomerId;
	}


	public void setSenderCustomerId(String senderCustomerId) {
		this.senderCustomerId = senderCustomerId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getMiddleName() {
		return middleName;
	}


	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getRelationShip() {
		return relationShip;
	}


	public void setRelationShip(String relationShip) {
		this.relationShip = relationShip;
	}

}
