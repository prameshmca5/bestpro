package com.bestpay.be.controller;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwOfflineRequestPayment;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.PaymentLinkInfo;
import com.bestpay.be.sdk.model.PgwOfflineRequestPaymentDto;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.notify.sdk.constants.MailTemplate;
import com.bestpay.notify.sdk.constants.MailTypeEnum;
import com.bestpay.notify.sdk.model.Notification;
import com.bestpay.notify.sdk.util.MailUtil;
import com.bstsb.util.MediaType;

/**
 * @author Ramesh Pogiannan
 * @since June 6, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.PAYMENT_LINK)
public class PaymentLinkRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentLinkRestController.class);

	@PostMapping(value = BeUrlConstants.PAYMENT_LINK_PAGINATION, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public DataTableResults<PgwOfflineRequestPayment> settlementListPaginated(
			@Valid @RequestBody PgwOfflineRequestPaymentDto pgwTraceRequestPayment, HttpServletRequest request) {

		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwOfflineRequestPayment> result = pgwOfflineRequestPaymentService
				.searchPaymentLink(pgwTraceRequestPayment, dataTableInRQ);

		DataTableResults<PgwOfflineRequestPayment> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<PgwOfflineRequestPayment> bpLst = new ArrayList<>();
				for (PgwOfflineRequestPayment bbp : result.getData()) {
					PgwOfflineRequestPayment trustee = dozerMapper.map(bbp, PgwOfflineRequestPayment.class);
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		return dataTableInResp;
	}

	@PostMapping(value = BeUrlConstants.GENERATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public PaymentLinkInfo addPaymentLink(@Valid @RequestBody PaymentLinkInfo paylinkinfo, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		LOGGER.info("Create new payment Link ... ");
		if (paylinkinfo == null) {// paylinkinfo null
			throw new BeException(BeErrorCodeEnum.E404PLC001);
		}

		PgwOfflineRequestPayment ptrpayment = new PgwOfflineRequestPayment();
		PgwOfflineRequestPayment orderinfo = super.pgwOfflineRequestPaymentService
				.findOrderIdByValue(paylinkinfo.getOrderId());

		if (BaseUtil.isObjNull(orderinfo)) {
			ptrpayment.setMerchantId(paylinkinfo.getMerchantId());
			ptrpayment.setEmail(paylinkinfo.getEmail());
			ptrpayment.setChannel(paylinkinfo.getChannel());
			ptrpayment.setCurrency(paylinkinfo.getCurrency());
			ptrpayment.setOrderId(paylinkinfo.getOrderId());
			ptrpayment.setAmount(paylinkinfo.getAmount());
			ptrpayment.setName(paylinkinfo.getName());
			ptrpayment.setEmail(paylinkinfo.getEmail());
			ptrpayment.setCcEmail(paylinkinfo.getCcEmail());
			ptrpayment.setMobile(paylinkinfo.getMobile());
			ptrpayment.setDescription(paylinkinfo.getDescription());
			ptrpayment.setReqhash(paylinkinfo.getReqhash());
			super.pgwOfflineRequestPaymentService.create(ptrpayment);
		} else {
			throw new BeException(BeErrorCodeEnum.I404APJ110);
		}
		return paylinkinfo;
	}

	@GetMapping(value = "/{orderId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public PgwOfflineRequestPayment getPaymentLinkByTraceId(@PathVariable String orderId) {
		LOGGER.info("Welcome to Trace Value");
		PgwOfflineRequestPayment paylkInfo = super.pgwOfflineRequestPaymentService.findPayLinkByTraceId(orderId);
		if (!BaseUtil.isObjNull(paylkInfo)) {
			paylkInfo = dozerMapper.map(paylkInfo, PgwOfflineRequestPayment.class);
		}
		return paylkInfo;
	}

	@GetMapping(value = "/{orderId}/email", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public PgwOfflineRequestPayment getPaymentLinkById(@PathVariable String orderId, HttpServletRequest request) {

		PgwOfflineRequestPayment paylkInfo = super.pgwOfflineRequestPaymentService.findPayLinkByTraceId(orderId);
		if (!BaseUtil.isObjNull(paylkInfo)) {
			paylkInfo = dozerMapper.map(paylkInfo, PgwOfflineRequestPayment.class);
		}
		String reqhash = BeUrlConstants.OFFLINE_PAYMENT_LINK + "/merchantpay/offlinepay/" + paylkInfo.getReqhash();
		String amountdisp = paylkInfo.getCurrency() + " " + paylkInfo.getAmount();
		Map<String, Object> map = new HashMap<>();
		map.put("merchantId", paylkInfo.getMerchantId());
		map.put("merchantName", paylkInfo.getName());
		map.put("reqHash", reqhash);
		map.put("Email", paylkInfo.getEmail());
		map.put("ccEmail", paylkInfo.getCcEmail());
		map.put("orderId", paylkInfo.getOrderId());
		map.put("subject", paylkInfo.getDescription());
		map.put("amount", amountdisp);

		Notification notification = new Notification();
		notification.setNotifyTo(paylkInfo.getEmail());
		notification.setNotifyCc(paylkInfo.getCcEmail());
		notification.setSubject(MessageFormat.format(paylkInfo.getDescription(), paylkInfo.getMerchantId()));
		notification.setMetaData(MailUtil.convertMapToJson(map));
		getNotifyService(request).addNotification(notification, MailTypeEnum.MAIL, MailTemplate.OFFLINE_PAYMENT_LINK);
		LOGGER.info("Email Triggering successfully");
		return paylkInfo;
	}
}
