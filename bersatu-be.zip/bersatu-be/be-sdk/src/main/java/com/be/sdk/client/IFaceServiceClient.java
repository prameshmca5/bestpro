/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.sdk.client;


import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.be.sdk.constants.BeConfigConstants;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.PersonDto;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;


/**
 * @author nurul.naimma
 *
 * @since Jul 13, 2021
 */
public class IFaceServiceClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(IFaceServiceClient.class);

	private String url;

	private String username;

	private String password;

	private double minConfidence;


	public IFaceServiceClient(String url, String username, String password, double minConfidence) {
		this.url = url;
		this.username = username;
		this.password = password;
		this.minConfidence = minConfidence;
	}


	private String openConnection() {
		StringBuilder urlSb = new StringBuilder();
		urlSb.append(url);
		urlSb.append(BeUrlConstants.USER_LOGIN);

		LOGGER.debug("Open Connection URL: {} ", urlSb);

		try {
			String token = Unirest.post(urlSb.toString())
					.header(BeConfigConstants.CONTENT_TYPE, BeConfigConstants.FORM_URL_ENCODED)
					.field(BeConfigConstants.PARAM_USERNAME, username)
					.field(BeConfigConstants.PARAM_PASSWORD, password).asString().getBody();

			LOGGER.info("Open Connection TOKEN: {} ", token);

			return token;
		} catch (UnsupportedOperationException | UnirestException e) {
			LOGGER.error(e.getMessage());
		}

		return null;
	}


	private String closeConnection(String key) {
		StringBuilder urlSb = new StringBuilder();
		urlSb.append(url);
		urlSb.append(BeUrlConstants.USER_LOGOUT);

		LOGGER.debug("Close Connection URL:{} ", urlSb);
		try {
			return Unirest.post(urlSb.toString())
					.header(BeConfigConstants.HEADER_AUTHORIZATION, key.replaceAll("\"", "")).asString().getBody();
		} catch (UnsupportedOperationException | UnirestException e) {
			LOGGER.error(e.getMessage());
		}

		return null;
	}


	/**
	 * Compare Face Image
	 *
	 * @param imageData1
	 *             - base64 String
	 * @param imageData2
	 *             - base64 String
	 * @return
	 */
	public boolean compareFaceImage(String imageData1, String imageData2) {
		StringBuilder urlSb = new StringBuilder();
		urlSb.append(url);
		urlSb.append(BeUrlConstants.FACE_IMG_COMPARE);

		LOGGER.info("Verify Face Image URL: {} ", urlSb);
		String key = openConnection();

		if (key == null) {
			throw new BeException(BeErrorCodeEnum.E400C914, new Object[] { url });
		}

		LOGGER.info("Compare Face Image 1: {} ", imageData1);
		LOGGER.info("Compare Face Image 2: {} ", imageData2);

		String result = null;
		try {
			result = Unirest.post(urlSb.toString())
					.header(BeConfigConstants.CONTENT_TYPE, BeConfigConstants.FORM_URL_ENCODED)
					.header(BeConfigConstants.HEADER_AUTHENTICATION, key)
					.field(BeConfigConstants.PARAM_IMAGE_DATA_1, BeConfigConstants.PFX_DATA_IMAGE + imageData1)
					.field(BeConfigConstants.PARAM_IMAGE_DATA_2, BeConfigConstants.PFX_DATA_IMAGE + imageData2)
					.asString().getBody();
			LOGGER.info("Compare Face Image Result: {} ", result);
		} catch (UnirestException e) {
			LOGGER.error(e.getMessage());
			throw new BeException(BeErrorCodeEnum.E503C006, new Object[] { url });
		} finally {
			closeConnection(key);
		}

		PersonDto person = null;
		if (result != null) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_DEFAULT);
			try {
				person = mapper.readValue(result, PersonDto.class);
				LOGGER.info("Similarity: {} ", person.getSimilarity());
				if (person.getSimilarity() >= minConfidence) {
					return true;
				}
			} catch (IOException ex) {
				LOGGER.error(ex.getMessage());
				throw new BeException(BeErrorCodeEnum.E503C006, new Object[] { url });
			}
		}
		return false;
	}

}
