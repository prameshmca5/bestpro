/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.service;


import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.config.ConfigConstants;
import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.RefChannelRepository;
import com.bestpay.pgw.model.RefChannel;
import com.bestpay.pgw.util.QualifierConstants;


/**
 * @author Afif Saman
 * @since Jul 10, 2018
 */
@Transactional
@Service(QualifierConstants.REF_CHANNEL_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_CHANNEL_SVC)
public class RefChannelService extends AbstractService<RefChannel> {

	@Autowired
	RefChannelRepository refChannelDao;

 
	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_CHANNEL_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	@Override
	public List<RefChannel> findAll() {
		return refChannelDao.findAll();
	}


	@Override
	public GenericRepository<RefChannel> primaryDao() {
		return refChannelDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public RefChannel findRefChannelByPublicName(String publicName) {
		return refChannelDao.findRefChannelByPublicName(publicName);
	}

}
