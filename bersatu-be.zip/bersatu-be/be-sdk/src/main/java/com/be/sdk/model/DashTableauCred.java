package com.be.sdk.model;

import java.io.Serializable;

public class DashTableauCred implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4098071592087055740L;
	private String tablUrl;
	private String tablUrlAdmin;
	private String tablUrlNonSprRgstr;
	private String tablUrlMmbrMangmnt;
	private String tablUserName;
	private String tableauTokenUrl;
	private String tableUrlVoting;

 
	public DashTableauCred(String url,String tablUrlAdmin,String tablUrlNonSprRgstr,String tablUrlMmbrMangmnt,String tablUserName,String tableauTokenUrl, String tableUrlVoting) {
		this.tablUrl = url;
		this.tablUrlAdmin = tablUrlAdmin;
		this.tablUrlNonSprRgstr = tablUrlNonSprRgstr;
		this.tablUrlMmbrMangmnt = tablUrlMmbrMangmnt;
		this.tablUserName = tablUserName;
		this.tableauTokenUrl = tableauTokenUrl;
		this.tableUrlVoting = tableUrlVoting;
	}
 
	public String getTablUrl() {
		return tablUrl;
	}

	public void setTablUrl(String tablUrl) {
		this.tablUrl = tablUrl;
	}


	public String getTablUserName() {
		return tablUserName;
	}


	public void setTablUserName(String tablUserName) {
		this.tablUserName = tablUserName;
	}


	public String getTableauTokenUrl() {
		return tableauTokenUrl;
	}


	public void setTableauTokenUrl(String tableauTokenUrl) {
		this.tableauTokenUrl = tableauTokenUrl;
	}


	public String getTablUrlAdmin() {
		return tablUrlAdmin;
	}


	public void setTablUrlAdmin(String tablUrlAdmin) {
		this.tablUrlAdmin = tablUrlAdmin;
	}


	public String getTablUrlNonSprRgstr() {
		return tablUrlNonSprRgstr;
	}


	public void setTablUrlNonSprRgstr(String tablUrlNonSprRgstr) {
		this.tablUrlNonSprRgstr = tablUrlNonSprRgstr;
	}


	public String getTablUrlMmbrMangmnt() {
		return tablUrlMmbrMangmnt;
	}


	public void setTablUrlMmbrMangmnt(String tablUrlMmbrMangmnt) {
		this.tablUrlMmbrMangmnt = tablUrlMmbrMangmnt;
	}


	public String getTableUrlVoting() {
		return tableUrlVoting;
	}


	public void setTableUrlVoting(String tableUrlVoting) {
		this.tableUrlVoting = tableUrlVoting;
	}
	
}
