/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author michelle.angela
 *
 */
public class FieldMaps implements Serializable {

	private static final long serialVersionUID = 2789466499244524819L;
		
	@JsonProperty("FieldType")
	private int fieldType;
	
	@JsonProperty("Field_MRZ")
	private String fieldMrz;

	public int getFieldType() {
		return fieldType;
	}

	public void setFieldType(int fieldType) {
		this.fieldType = fieldType;
	}

	public String getFieldMrz() {
		return fieldMrz;
	}

	public void setFieldMrz(String fieldMrz) {
		this.fieldMrz = fieldMrz;
	}		

}
