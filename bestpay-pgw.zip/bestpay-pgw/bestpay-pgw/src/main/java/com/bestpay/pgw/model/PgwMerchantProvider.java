package com.bestpay.pgw.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.pgw.core.AbstractEntity;


/**
 * @author Atiqah Khairuddin
 * @since March 28, 2019
 */
@Entity
@Table(name = "PGW_MERCHANT_PROVIDER")
public class PgwMerchantProvider extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "PROVIDER_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer providerId;

	@Column(name = "PROVIDER_PUBLIC_NAME")
	private String providerPublicName;

	@Column(name = "PROVIDER_NAME")
	private String providerName;

	@Column(name = "PROVIDER_ADDRESS_1")
	private String address1;

	@Column(name = "PROVIDER_ADDRESS_2")
	private String address2;

	@Column(name = "PROVIDER_ADDRESS_3")
	private String address3;

	@Column(name = "PROVIDER_POSTCODE")
	private String postcode;

	@Column(name = "PROVIDER_CITY")
	private String city;

	@Column(name = "PROVIDER_STATE")
	private String state;

	@Column(name = "PROVIDER_COUNTRY")
	private String country;

	@Column(name = "PROVIDER_EMAIL")
	private String email;

	@Column(name = "PROVIDER_PHONE")
	private String phone;

	@Column(name = "PROVIDER_SSM_ID")
	private String ssmId;

	@Column(name = "PROVIDER_PIC_NAME")
	private String picName;

	@Column(name = "PROVIDER_PIC_EMAIL")
	private String picEmail;

	@Column(name = "PROVIDER_PIC_PHONE")
	private String picPhone;

	@Column(name = "PROVIDER_API_KEY")
	private String apikey;

	@Column(name = "PROVIDER_URL")
	private String url;

	@Column(name = "PROVIDER_PASSWORD")
	private String password;

	@Column(name = "PROVIDER_FPX_URL")
	private String fpxUrl;

	@Column(name = "PROVIDER_REQUERY_URL")
	private String requeryUrl;

	@Column(name = "PROVIDER_BESTPAY_REDIRECT_URL")
	private String bestpayRedirectUrl;

	@Column(name = "PROVIDER_BESTPAY_CALLBACK_URL")
	private String bestpayCallbackUrl;

	@Column(name = "PROVIDER_BESTPAY_BACKEND_CALLBACK_URL")
	private String bestpayBackendCallbackUrl;

	@Column(name = "PROVIDER_AGENT_CODE")
	private String agentCode;

	@Column(name = "PROVIDER_USER_ID")
	private String userId;

	@Column(name = "PROVIDER_AGENT_SESSION_ID")
	private String agentSessionId;

	@Column(name = "PROVIDER_COLLECTION_ID")
	private String collectionId;

	@Column(name = "PROVIDER_AUTH_CODE")
	private String authCode;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getProviderId() {
		return providerId;
	}


	public void setProviderId(Integer providerId) {
		this.providerId = providerId;
	}


	public String getProviderPublicName() {
		return providerPublicName;
	}


	public void setProviderPublicName(String providerPublicName) {
		this.providerPublicName = providerPublicName;
	}


	public String getProviderName() {
		return providerName;
	}


	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}


	public String getAddress1() {
		return address1;
	}


	public void setAddress1(String address1) {
		this.address1 = address1;
	}


	public String getAddress2() {
		return address2;
	}


	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	public String getAddress3() {
		return address3;
	}


	public void setAddress3(String address3) {
		this.address3 = address3;
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getSsmId() {
		return ssmId;
	}


	public void setSsmId(String ssmId) {
		this.ssmId = ssmId;
	}


	public String getPicName() {
		return picName;
	}


	public void setPicName(String picName) {
		this.picName = picName;
	}


	public String getPicEmail() {
		return picEmail;
	}


	public void setPicEmail(String picEmail) {
		this.picEmail = picEmail;
	}


	public String getPicPhone() {
		return picPhone;
	}


	public void setPicPhone(String picPhone) {
		this.picPhone = picPhone;
	}


	public String getApikey() {
		return apikey;
	}


	public void setApikey(String apikey) {
		this.apikey = apikey;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getFpxUrl() {
		return fpxUrl;
	}


	public void setFpxUrl(String fpxUrl) {
		this.fpxUrl = fpxUrl;
	}


	public String getRequeryUrl() {
		return requeryUrl;
	}


	public void setRequeryUrl(String requeryUrl) {
		this.requeryUrl = requeryUrl;
	}


	public String getBestpayRedirectUrl() {
		return bestpayRedirectUrl;
	}


	public void setBestpayRedirectUrl(String bestpayRedirectUrl) {
		this.bestpayRedirectUrl = bestpayRedirectUrl;
	}


	public String getBestpayCallbackUrl() {
		return bestpayCallbackUrl;
	}


	public void setBestpayCallbackUrl(String bestpayCallbackUrl) {
		this.bestpayCallbackUrl = bestpayCallbackUrl;
	}


	public String getBestpayBackendCallbackUrl() {
		return bestpayBackendCallbackUrl;
	}


	public void setBestpayBackendCallbackUrl(String bestpayBackendCallbackUrl) {
		this.bestpayBackendCallbackUrl = bestpayBackendCallbackUrl;
	}


	public String getAgentCode() {
		return agentCode;
	}


	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getAgentSessionId() {
		return agentSessionId;
	}


	public void setAgentSessionId(String agentSessionId) {
		this.agentSessionId = agentSessionId;
	}


	public String getCollectionId() {
		return collectionId;
	}


	public void setCollectionId(String collectionId) {
		this.collectionId = collectionId;
	}


	public String getAuthCode() {
		return authCode;
	}


	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}
