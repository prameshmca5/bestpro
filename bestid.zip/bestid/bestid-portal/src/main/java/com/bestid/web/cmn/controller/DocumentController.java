/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.web.cmn.controller;


import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bestid.core.AbstractController;
import com.bestid.web.util.WebUtil;
import com.bestid.web.util.constants.PageConstants;
import com.bestid.web.util.constants.ProjectEnum;
import com.bestid.web.util.helper.WebHelper;
import com.bstsb.dm.sdk.model.Documents;
import com.bstsb.idm.sdk.exception.IdmException;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.constants.BaseConstants;


/**
 * @author Mary Jane Buenaventura
 * @since May 17, 2018
 */
@Controller
@RequestMapping(PageConstants.DOCUMENTS)
public class DocumentController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(DocumentController.class);

	private static final String LOG_DOWNLOAD = "Download: {}";


	@GetMapping(value = "/download/{docId}")
	public @ResponseBody Documents download(@PathVariable String docId, HttpServletRequest request,
			HttpSession session) {
		Documents docResp = null;
		if (!BaseUtil.isObjNull(docId)) {
			try {
				LOGGER.debug(LOG_DOWNLOAD, docId);
				docResp = getDocInCache(ProjectEnum.BESTID, docId);
			} catch (IdmException e) {
				if (WebUtil.checkTokenError(e)) {
					throw e;
				}
				LOGGER.error(BaseConstants.LOG_IDM_EXCEPTION, e.getMessage());
			} catch (Exception e) {
				LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
			}
		}
		return docResp;
	}


	@GetMapping(value = "/download/content/{docId}", produces = { "image/jpeg", "image/gif", "image/png",
			"application/pdf" })
	public @ResponseBody ResponseEntity<byte[]> downloadContent(@PathVariable String docId, HttpServletRequest request,
			HttpSession session) {
		byte[] fb = null;
		Documents docResp = null;

		if (!BaseUtil.isObjNull(docId)) {
			try {
				LOGGER.debug(LOG_DOWNLOAD, docId);
				docResp = getDocInCache(ProjectEnum.BESTID, docId);
			} catch (IdmException e) {
				LOGGER.error(BaseConstants.LOG_IDM_EXCEPTION, e.getMessage());
			} catch (Exception e) {
				LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
			}
			if (docResp != null) {
				if (BaseUtil.isObjNull(docResp.getFilename())) {
					docResp.setFilename(docId);
				}
				LOGGER.debug("FILENAME: {}", docResp.getFilename());
				LOGGER.debug("CONTENT TYPE: {}", docResp.getContentType());
				LOGGER.debug("CONTENT: {}", docResp.getContent());
				try {
					fb = docResp.getContent();
				} catch (Exception e) {
					LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
					fb = docResp.getContent();
				}
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.parseMediaType(docResp.getContentType()));
				String filename = genFileName(docId, docResp.getContentType());
				headers.setContentDispositionFormData(filename, filename);
				headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
				return new ResponseEntity<>(fb, headers, HttpStatus.OK);
			} else {
				try {
					String url = new WebHelper().baseUrl() + "/webjars/calumma-webjar/images/no_image.jpg";
					LOGGER.info("NO IMAGE URL: {}", url);
					fb = Base64.encodeBase64(IOUtils.toByteArray((new URL(url)).openStream()), true);
				} catch (MalformedURLException e) {
					LOGGER.error("MalformedURLException: {}", e);
				} catch (IOException e) {
					LOGGER.error("IOException: {}", e);
				}
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.parseMediaType(MediaType.IMAGE_JPEG_VALUE));
				String filename = genFileName(docId, MediaType.IMAGE_JPEG_VALUE);
				headers.setContentDispositionFormData(filename, filename);
				headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
				return new ResponseEntity<>(fb, headers, HttpStatus.OK);
			}
		}
		return null;
	}


	@GetMapping(value = "/{projId}/download/{docId}")
	public @ResponseBody Documents download(@PathVariable String projId, @PathVariable String docId,
			HttpServletRequest request, HttpSession session) {
		Documents docResp = null;
		if (!BaseUtil.isObjNull(docId)) {
			try {
				LOGGER.debug(LOG_DOWNLOAD, docId);
				docResp = getDocInCache(ProjectEnum.BESTID, docId);
			} catch (IdmException e) {
				if (WebUtil.checkTokenError(e)) {
					throw e;
				}
				LOGGER.error(BaseConstants.LOG_IDM_EXCEPTION, e.getMessage());
			} catch (Exception e) {
				LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
			}
		}
		return docResp;
	}


	@PostMapping(value = "/upload/{projId}")
	public @ResponseBody Documents upload(@PathVariable String projId, Documents fileUpd, HttpServletRequest request,
			HttpSession session) {
		LOGGER.info("Document Upload: {}", objectMapper.valueToTree(fileUpd));
		Documents doc = null;
		try {
			if (!BaseUtil.isObjNull(fileUpd) && !BaseUtil.isObjNull(fileUpd.getContent())) {
				fileUpd.setContent(Base64.decodeBase64(fileUpd.getContent()));
			}
			doc = getDmService(ProjectEnum.findByName(projId)).upload(fileUpd);
		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
		}
		return doc;
	}


	private String genFileName(String fileNm, String contentType) {
		String filename = fileNm;
		if (BaseUtil.isEquals(contentType, "image/jpeg")) {
			filename += ".jpg";
		} else if (BaseUtil.isEquals(contentType, "image/gif")) {
			filename += ".gif";
		} else if (BaseUtil.isEquals(contentType, "image/png")) {
			filename += ".png";
		} else if (BaseUtil.isEquals(contentType, "application/pdf")) {
			filename += ".pdf";
		}
		return filename;
	}

}