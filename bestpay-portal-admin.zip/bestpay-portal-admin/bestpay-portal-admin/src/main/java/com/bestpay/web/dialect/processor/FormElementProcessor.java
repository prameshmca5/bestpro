/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dialect.processor;


import org.thymeleaf.Arguments;
import org.thymeleaf.dom.Element;
import org.thymeleaf.processor.ProcessorResult;

import com.bestpay.web.dialect.AbstractBstElement;
import com.bestpay.web.dialect.constants.AttributeConstants;
import com.bestpay.web.dialect.constants.ElementConstants;


/**
 * Convert the <bst:form> node to a normal <form> node
 *
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class FormElementProcessor extends AbstractBstElement {

	public FormElementProcessor(String elementName) {
		super(elementName);
	}


	@Override
	protected ProcessorResult processElement(Arguments arguments, Element element) {
		getElementName(element);
		// Convert the <bst:form> node to a normal <form> node
		Element newElement = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_FORM,
				false);

		if (element.getAttributeValue(AttributeConstants.ATTR_METHOD) == null) {
			newElement.setAttribute(AttributeConstants.ATTR_METHOD, "POST");
		}

		final Element inCsrf = new Element(ElementConstants.HTML_INPUT);
		inCsrf.setAttribute(AttributeConstants.ATTR_TYPE, "hidden");
		inCsrf.setAttribute(AttributeConstants.ATTR_NAME, "_csrf");
		inCsrf.setAttribute("th:value", "${_csrf.token}");

		newElement.addChild(inCsrf);

		newElement.setRecomputeProcessorsImmediately(true);
		element.getParent().insertAfter(element, newElement);
		element.getParent().removeChild(element);

		return ProcessorResult.OK;
	}


	@Override
	public int getPrecedence() {
		return 100000;
	}

}