/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.Date;
import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.TransactionRepository;
import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.model.PgwTransaction;
import com.bestpay.be.model.PgwTransactionAmount;
import com.bestpay.be.qf.PgwTransactionQf;
import com.bestpay.be.sdk.model.Transaction;
import com.bestpay.be.sdk.model.TransactionRptInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;


/**
 * N.N. Shuhada 05 June 2018
 */

@Service(QualifierConstants.PGW_TRANSACTION_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_TRANSACTION_SVC)
@Transactional(QualifierConstants.TRANS_MANAGER)
public class PgwTransactionService extends AbstractService<PgwTransaction> {

	@Autowired
	private TransactionRepository pgwTransactionDao;

	@Autowired
	private PgwTransactionQf pgwTransactionQf;


	@Override
	public GenericRepository<PgwTransaction> primaryDao() {
		return pgwTransactionDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwTransaction> searchTranLst(Transaction transactionList,
			DataTableRequest dataTableInRQ) {
		return pgwTransactionQf.searchTranLst(transactionList, dataTableInRQ);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwTransaction> searchTransactionRpt(TransactionRptInfo transactionRptInfo,
			DataTableRequest dataTableInRQ, PgwMerchantProfile pgwMerchantProfile) {
		return pgwTransactionQf.searchTransactionRpt(transactionRptInfo, dataTableInRQ, pgwMerchantProfile);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwTransaction> loadTransRptInfo(TransactionRptInfo transactionRptInfo,
			PgwMerchantProfile pgwMerchantProfile) {
		return pgwTransactionQf.loadTransRptInfo(transactionRptInfo, pgwMerchantProfile);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwTransaction findDetailByTranId(String transId) {
		return pgwTransactionDao.findUserByTranId(transId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwTransaction> searchTop10TranLst(Transaction transactionList,
			DataTableRequest dataTableInRQ) {
		return pgwTransactionQf.searchTop10TranLst(transactionList, dataTableInRQ);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwTransaction> findTransactionByMerchantAndSetID(String merchantId, int setId, Date start, Date end) {
		return pgwTransactionDao.findTransactionByMerchantAndSetId(merchantId, setId, start, end);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwTransactionAmount findSumTransactionByMerchantId(String merchantId, Date start, Date end) {
		return pgwTransactionDao.findSumTransactionByMerchantId(merchantId, start, end);
	}


	@javax.transaction.Transactional()
	public int updateTransactionByMerchant(String merchantId, Integer setID, Date start, Date end) {
		return pgwTransactionDao.updateTransactionByMerchant(merchantId, setID, start, end);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwTransaction> findDetailBySetId(String merchId, Integer setTransId) {
		return pgwTransactionDao.findDetailBySetIdByAllTransaction(merchId, setTransId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwTransaction> findDetailBySetIdTrans(Integer setTransId) {
		return pgwTransactionDao.findDetailBySetIdByAllTrans(setTransId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<String> getTransListByMonth(String merchantId) {
		return pgwTransactionQf.getTransListByMonth(merchantId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwTransaction> getTodaysSuccessfulTransactions(String merchantId,
			DataTableRequest dataTableInRQ) {
		return pgwTransactionQf.getTodaysSuccessfulTransactions(merchantId, dataTableInRQ);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwTransaction> getMonthlySuccessfulTransactions(String merchantId,
			DataTableRequest dataTableInRQ) {
		return pgwTransactionQf.getMonthlySuccessfulTransactions(merchantId, dataTableInRQ);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public long getTodaysCountSuccessfulTransactions(String merchantId) {
		return pgwTransactionQf.getTodaysCountSuccessfulTransactions(merchantId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public String getSumAndCountOfMonth(String merchantId) {
		return pgwTransactionQf.getSumAndCountOfMonth(merchantId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public double getSumOfBillAmt() {
		return pgwTransactionDao.getSumOfBillAmt();
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwTransaction> findTransactionByChannelAndSetID(String channel, int setId, Date start, Date end) {
		return pgwTransactionDao.findTransactionByChannelAndSetID(channel, setId, start, end);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwTransactionAmount findSumTransactionByChannel(String channel, Date start, Date end) {
		return pgwTransactionDao.findSumTransactionByChannel(channel, start, end);
	}


	@javax.transaction.Transactional()
	public int updateTransactionByChannel(String channel, Integer setID, Date start, Date end) {
		return pgwTransactionDao.updateTransactionByChannel(channel, setID, start, end);
	}


	@javax.transaction.Transactional()
	public int findTotalTransactionByChannel(String channel, Date start, Date end) {
		return pgwTransactionDao.findTotalTransactionByChannel(channel, start, end);
	}

}