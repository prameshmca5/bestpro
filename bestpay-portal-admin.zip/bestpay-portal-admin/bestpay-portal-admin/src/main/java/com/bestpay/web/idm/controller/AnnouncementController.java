/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.idm.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.codehaus.groovy.syntax.TokenException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.notify.sdk.model.AnnouncementDto;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.form.Announcement;
import com.bestpay.web.util.WebUtil;

@Controller
@RequestMapping(value = PageConstants.PAGE_ANNOUNCEMENT)
public class AnnouncementController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AnnouncementController.class);

	private static final String ANNOUNCEMENT_CREATE = "announcementCreate";

	@GetMapping
	public ModelAndView view(Announcement announcement, BindingResult result, HttpSession session) {
		return getDefaultMav(PageTemplate.ANNOUNCEMENT);
	}

	@PostMapping(value = "/{type}")
	public ModelAndView post(@PathVariable String type,
			@ModelAttribute("announcement") @Valid Announcement announcement, BindingResult result,
			HttpServletRequest request, HttpSession session) throws Exception {
		ModelAndView mav = new ModelAndView(PageTemplate.ANNOUNCEMENT);

		LOGGER.info("Type: {}", type);

		if (BaseUtil.isEqualsCaseIgnore("new", type) && !result.hasErrors()) {

			try {

				Announcement announce = new Announcement();
				announce.setAnncMessage(announcement.getAnncMessage());
				announce.setAnncTitle(announcement.getAnncTitle());

				AnnouncementDto announcemnt = dozerMapper.map(announcement, AnnouncementDto.class);

				AnnouncementDto notAnnouc = getNotifyService().createAnnouncement(announcemnt);

				if (notAnnouc != null) {
					mav.addAllObjects(com.bstsb.util.PopupBox.success(ANNOUNCEMENT_CREATE, null,
							messageService.getMessage(MessageConstants.SUCC_ANNOUCEMENT),
							PageConstants.PAGE_ANNOUNCEMENT));
				} else {
					mav.addAllObjects(com.bstsb.util.PopupBox.error(ANNOUNCEMENT_CREATE, null,
							messageService.getMessage(MessageConstants.ERROR_CRE_ANNOUNCEMENT),
							PageConstants.PAGE_ANNOUNCEMENT));
				}
			} catch (TokenException e) {
				if (WebUtil.checkTokenError(e)) {
					throw e;
				}
				mav.addAllObjects(com.bstsb.util.PopupBox.error(ANNOUNCEMENT_CREATE,
						messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
				mav.addAllObjects(com.bstsb.util.PopupBox.error(ANNOUNCEMENT_CREATE,
						messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
			} catch (BeException e) {
				mav.addAllObjects(com.bstsb.util.PopupBox.error(ANNOUNCEMENT_CREATE, null, e.getMessage()));
			} catch (Exception e) {
				mav.addAllObjects(com.bstsb.util.PopupBox.error(ANNOUNCEMENT_CREATE,
						messageService.getMessage(MessageConstants.ERROR_UNABLE_TO_PROCESS)));
			}
		}

		mav.addObject("announcement", announcement);
		mav.addObject("actUrl", type);

		return mav;

	}
}