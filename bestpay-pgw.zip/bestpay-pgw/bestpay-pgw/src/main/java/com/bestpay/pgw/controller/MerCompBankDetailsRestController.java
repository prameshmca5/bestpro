/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwMerchantCompanyBankDetails;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.model.MerCompBankDetails;
import com.bestpay.pgw.sdk.util.BaseUtil;
import org.springframework.http.MediaType;
 

/**
 * @author Atiqah Khairuddin
 * @since May 29, 2019
 */
@RestController
@RequestMapping(PgwUrlConstants.MER_COMP_BANK_DETAILS)
public class MerCompBankDetailsRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MerCompBankDetailsRestController.class);

	String skipValues = "[-+.^:,()*@/]";

	@Autowired
	protected ReferenceRestController referenceRestController;

	

	@GetMapping(value = "/{compRefId}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public MerCompBankDetails getBenDetailsByCompRefId(@PathVariable String compRefId) {

		PgwMerchantCompanyBankDetails pgwMerchantCompanyBankDetails = super.pgwMerchantCompanyBankDetailsService
				.findBeneficiaryByCompRefId(compRefId);
		LOGGER.info("CompanyRefereence Id {}",compRefId);
		MerCompBankDetails merCompBankDetails = new MerCompBankDetails();
		if (!BaseUtil.isObjNull(pgwMerchantCompanyBankDetails)) {
			merCompBankDetails = dozerMapper.map(pgwMerchantCompanyBankDetails, MerCompBankDetails.class);
		}
		return merCompBankDetails;
	}

	

	@GetMapping(value = PgwUrlConstants.GET_BANK_DETAILS_BY_COMPBANKID + "/{compBankId}", consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public MerCompBankDetails getBenDetailsByCompBankId(@PathVariable Integer compBankId) {

		PgwMerchantCompanyBankDetails pgwMerchantCompanyBankDetails = super.pgwMerchantCompanyBankDetailsService
				.findBeneficiaryByCompBankId(compBankId);
		LOGGER.info("CompanyRefereence Id {}",compBankId);
		MerCompBankDetails merCompBankDetails = new MerCompBankDetails();
		if (!BaseUtil.isObjNull(pgwMerchantCompanyBankDetails)) {
			merCompBankDetails = dozerMapper.map(pgwMerchantCompanyBankDetails, MerCompBankDetails.class);
		}

		return merCompBankDetails;
	}
}
