package com.bestpay.be.sdk.model;


public class Dashboard {

	private String transList;

	private long totalTodaysTransactions;

	private String transactionAmt;

	private int totalMonthlyTransactions;

	private int activeMerchants;

	private int inActiveMerchants;

	private int newMerchants;

	private String sumOfSettlementAmt;

	private int openTickets;

	private int inProgressTickets;

	private int resolvedTickets;

	private String userRoleGroup;


	public String getTransList() {
		return transList;
	}


	public void setTransList(String transList) {
		this.transList = transList;
	}


	public long getTotalTodaysTransactions() {
		return totalTodaysTransactions;
	}


	public void setTotalTodaysTransactions(long totalTodaysTransactions) {
		this.totalTodaysTransactions = totalTodaysTransactions;
	}


	public String getTransactionAmt() {
		return transactionAmt;
	}


	public void setTransactionAmt(String transactionAmt) {
		this.transactionAmt = transactionAmt;
	}


	public int getTotalMonthlyTransactions() {
		return totalMonthlyTransactions;
	}


	public void setTotalMonthlyTransactions(int totalMonthlyTransactions) {
		this.totalMonthlyTransactions = totalMonthlyTransactions;
	}


	public int getActiveMerchants() {
		return activeMerchants;
	}


	public void setActiveMerchants(int activeMerchants) {
		this.activeMerchants = activeMerchants;
	}


	public int getInActiveMerchants() {
		return inActiveMerchants;
	}


	public void setInActiveMerchants(int inActiveMerchants) {
		this.inActiveMerchants = inActiveMerchants;
	}


	public int getNewMerchants() {
		return newMerchants;
	}


	public void setNewMerchants(int newMerchants) {
		this.newMerchants = newMerchants;
	}


	public String getSumOfSettlementAmt() {
		return sumOfSettlementAmt;
	}


	public void setSumOfSettlementAmt(String sumOfSettlementAmt) {
		this.sumOfSettlementAmt = sumOfSettlementAmt;
	}


	public int getOpenTickets() {
		return openTickets;
	}


	public void setOpenTickets(int openTickets) {
		this.openTickets = openTickets;
	}


	public int getInProgressTickets() {
		return inProgressTickets;
	}


	public void setInProgressTickets(int inProgressTickets) {
		this.inProgressTickets = inProgressTickets;
	}


	public int getResolvedTickets() {
		return resolvedTickets;
	}


	public void setResolvedTickets(int resolvedTickets) {
		this.resolvedTickets = resolvedTickets;
	}


	public String getUserRoleGroup() {
		return userRoleGroup;
	}


	public void setUserRoleGroup(String userRoleGroup) {
		this.userRoleGroup = userRoleGroup;
	}

}
