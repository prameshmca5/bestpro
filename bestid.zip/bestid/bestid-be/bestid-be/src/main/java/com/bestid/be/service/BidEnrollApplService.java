/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.BidEnrollAppl;
import com.bestid.be.model.BidUserProfile;
import com.bestid.be.model.SecUserDevice;
import com.bestid.be.qf.BidEnrollApplQf;
import com.bestid.be.repo.BidEnrollApplRepository;
import com.bestid.be.repo.BidUserProfileRepository;
import com.bestid.be.repo.GenericRepository;
import com.bestid.be.repo.SecUserDeviceRepository;
import com.bestid.be.sdk.model.KioskCounter;
import com.bstsb.util.BaseUtil;


/**
 * @author mukhlis.hamzah
 * @since Feb 14, 2019
 */
@Transactional
@Service(QualifierConstants.BID_ENROLL_APPL_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BID_ENROLL_APPL_SVC)
public class BidEnrollApplService extends AbstractService<BidEnrollAppl> {

	@Autowired
	@Qualifier(QualifierConstants.BID_ENROLL_APPL_REPOSITORY)
	BidEnrollApplRepository bidEnrollApplDao;

	@Autowired
	@Qualifier(QualifierConstants.BID_USER_PROFILE_REPOSITORY)
	BidUserProfileRepository bidUserProfileDao;

	@Autowired
	@Qualifier(QualifierConstants.SEC_USER_DEVICE_REPOSITORY)
	SecUserDeviceRepository secUserDeviceDao;

	@Autowired
	@Qualifier(QualifierConstants.BID_ENROLL_APPL_QF)
	BidEnrollApplQf bidEnrollApplQf;


	@Override
	public GenericRepository<BidEnrollAppl> primaryDao() {
		return bidEnrollApplDao;
	}


	public BidEnrollAppl findByDeviceId(int deviceId, String status) {
		return bidEnrollApplDao.findByDeviceId(deviceId, status);
	}


	public BidEnrollAppl findByApplId(int applId) {
		return bidEnrollApplDao.findByApplId(applId);
	}


	public BidEnrollAppl findByActvCdDvcId(int deviceId, String activationCode) {
		return bidEnrollApplDao.findByActvCdDvcId(deviceId, activationCode);
	}


	public BidEnrollAppl findByUsrNDeviceIdSts(int deviceId, int userId, String status) {
		return bidEnrollApplDao.findByUsrNDeviceIdSts(deviceId, userId, status);
	}


	public BidEnrollAppl findByUsrNDeviceId(int deviceId, int userId) {
		return bidEnrollApplDao.findByUsrNDeviceId(deviceId, userId);
	}


	public BidEnrollAppl findByApplIdDvcId(Integer applId, Integer deviceId) {
		return bidEnrollApplDao.findByApplIdDvcId(applId, deviceId);
	}


	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public KioskCounter saveActvCd(BidEnrollAppl bidEnrAppl, KioskCounter kioskCounter) {
		if (!BaseUtil.isObjNull(bidEnrAppl)) {
			bidEnrollApplDao.save(bidEnrAppl);
		}

		BidUserProfile bup = bidUserProfileDao.findUserByRefNo(kioskCounter.getIcNo());
		LOGGER.info("MACHINE ID::{}", kioskCounter.getDeviceInfo().getMachineId());
		SecUserDevice secUserDvc = secUserDeviceDao.findDeviceByMobileNo(kioskCounter.getPhoneNo());

		if (!BaseUtil.isObjNull(bup)) {
			bup.setStatus("A");
			bidUserProfileDao.save(bup);
		}

		if (!BaseUtil.isObjNull(secUserDvc)) {
			secUserDvc.setStatus("A");
			secUserDeviceDao.save(secUserDvc);
		}
		return kioskCounter;
	}


	public List<BidEnrollAppl> searchByProperty(BidEnrollAppl bidEnrollAppl) {
		return bidEnrollApplDao.findAll(bidEnrollApplQf.searchByProperty(bidEnrollAppl));
	}


	public BidEnrollAppl findByActvCd(String activationCode) {
		return bidEnrollApplDao.findByActvCd(activationCode);
	}
}
