/**
 * Copyright 2019. Universal Recruitment Platform
 */
package com.be.sdk.model;


/**
 * @author mary.jane
 *
 */
public interface IQfCriteria<T> {

}
