/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.report.config;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.bestid.be.sdk.client.BeServiceClient;
import com.bestid.be.sdk.constants.ServiceConstants;
import com.bestid.be.sdk.exception.BeException;
import com.bestid.be.sdk.model.City;
import com.bestid.be.sdk.model.Country;
import com.bestid.be.sdk.model.MaritalStatus;
import com.bestid.be.sdk.model.Nationality;
import com.bestid.be.sdk.model.State;
import com.bestid.report.sdk.constants.RptCacheConstants;
import com.bestid.report.util.ConfigConstants;
import com.bestid.report.util.WebUtil;
import com.bstsb.idm.sdk.exception.IdmException;
import com.bstsb.util.BaseUtil;


/**
 * @author Mary Jane Buenaventura
 * @since May 8, 2018
 */
@Component
public class StaticData implements InitializingBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(StaticData.class);

	@Autowired
	CacheManager cacheManager;

	@Autowired
	MessageSource messageSource;

	@Autowired
	private BeServiceClient beService;


	@Override
	public void afterPropertiesSet() throws Exception {
		String skey = messageSource.getMessage(ConfigConstants.SVC_IDM_SKEY, null, Locale.getDefault());
		String clientId = messageSource.getMessage(ConfigConstants.SVC_IDM_CLIENT, null, Locale.getDefault());
		beService.setToken(skey);
		beService.setClientId(clientId);
	}


	private BeServiceClient getBeService() {
		beService.setAuthToken(null);
		beService.setMessageId(String.valueOf(UUID.randomUUID()));
		return beService;
	}


	@SuppressWarnings("unchecked")
	public Map<String, String> cmnConfig() {
		return ((Map<String, String>) getList(ServiceConstants.STAT_LST_CONFIG));
	}


	@SuppressWarnings("unchecked")
	private Object getList(String entityType) {
		String cacheKey = RptCacheConstants.CACHE_STATIC_RPT.concat(entityType);
		Cache cache = cacheManager.getCache(RptCacheConstants.CACHE_BUCKET);
		Cache.ValueWrapper cv = cache.get(cacheKey);

		if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_CITY)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return cv.get();
			}
			try {
				List<City> objLst = getBeService().reference().findByAllCities();
				if (!BaseUtil.isListNullZero(objLst)) {
					cache.put(cacheKey, objLst);
				}
				return objLst;
			} catch (IdmException | BeException e) {
				if (WebUtil.checkTokenError(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
			return null;

		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_CONFIG)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return cv.get();
			}
			try {
				Map<String, String> objMap = getBeService().reference().findAllConfig();
				if (!BaseUtil.isObjNull(objMap)) {
					cache.put(cacheKey, objMap);
				}
				return objMap;
			} catch (IdmException | BeException e) {
				if (WebUtil.checkTokenError(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
			return null;

		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_STATE)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return cv.get();
			}
			try {
				LOGGER.info("STAT_LST_STATE");
				List<State> objLst = getBeService().reference().findAllState();

				if (!BaseUtil.isListNullZero(objLst)) {
					cache.put(cacheKey, objLst);
				}
				return objLst;
			} catch (IdmException e) {
				if (WebUtil.checkTokenError(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
			return null;

		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_COUNTRY)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return cv.get();
			}
			try {
				List<Country> objLst = getBeService().reference().allCountry();
				if (!BaseUtil.isListNullZero(objLst)) {
					cache.put(cacheKey, objLst);
				}
				return objLst;
			} catch (IdmException e) {
				if (WebUtil.checkTokenError(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
			return null;
		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_NATIONALITY)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			}
			try {
				List<Nationality> objLst = getBeService().reference().findAllNationality();
				if (!BaseUtil.isListNullZero(objLst)) {
					cache.put(cacheKey, objLst);
				}
				return objLst;
			} catch (IdmException e) {
				if (WebUtil.checkTokenError(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
			return null;
		} else if (BaseUtil.isEquals(entityType, ServiceConstants.STAT_LST_MARITAL_STATUS)) {
			if (!BaseUtil.isObjNull(cv) && !BaseUtil.isObjNull(cv.get())) {
				return (cv.get());
			} else {
				try {
					List<MaritalStatus> objLst = getBeService().reference().findAllMaritalStatus();
					if (!BaseUtil.isListNullZero(objLst)) {
						cache.put(cacheKey, objLst);
					}
					return objLst;
				} catch (IdmException e) {
					if (WebUtil.checkTokenError(e)) {
						throw e;
					}
				} catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
				return null;
			}
		} else {
			return null;
		}

	}


	@SuppressWarnings("unchecked")
	public List<City> cityList() {
		return (List<City>) getList(ServiceConstants.STAT_LST_CITY);
	}


	@SuppressWarnings("unchecked")
	public City city(String cityCode) {
		List<City> cityLst = (List<City>) getList(ServiceConstants.STAT_LST_CITY);
		for (City city : cityLst) {
			if (BaseUtil.isEqualsCaseIgnore(cityCode, city.getCityCode())) {
				return city;
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public List<State> stateList() {
		return (List<State>) getList(ServiceConstants.STAT_LST_STATE);
	}


	@SuppressWarnings("unchecked")
	public List<State> cityList(String state) {
		List<State> lst = (List<State>) getList(ServiceConstants.STAT_LST_STATE);
		List<State> newLst = new ArrayList<>();
		for (State obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(state, obj.getStateCode())) {
				newLst.add(obj);
			}
		}
		return newLst;
	}


	@SuppressWarnings("unchecked")
	public List<State> stateList(String country) {
		List<State> lst = (List<State>) getList(ServiceConstants.STAT_LST_STATE);
		List<State> newLst = new ArrayList<>();
		if (!BaseUtil.isListNullZero(lst)) {
			for (State obj : lst) {
				if (BaseUtil.isEqualsCaseIgnore(country, obj.getCountry())) {
					newLst.add(obj);
				}
			}
		}
		return newLst;
	}


	@SuppressWarnings("unchecked")
	public State state(String stateCode) {
		List<State> lst = (List<State>) getList(ServiceConstants.STAT_LST_STATE);
		if (!BaseUtil.isListNullZero(lst)) {
			for (State obj : lst) {
				if (BaseUtil.isEqualsCaseIgnore(stateCode, obj.getStateCode())) {
					return obj;
				}
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public List<Country> countryList() {
		return (List<Country>) getList(ServiceConstants.STAT_LST_COUNTRY);
	}


	@SuppressWarnings("unchecked")
	public List<Country> countrySourceList() {
		List<Country> lst = (List<Country>) getList(ServiceConstants.STAT_LST_COUNTRY);
		List<Country> newLst = new ArrayList<>();
		if (!BaseUtil.isListNullZero(lst)) {
			for (Country obj : lst) {
				if (!obj.getCntryInd().isEmpty()) {
					newLst.add(obj);
				}
			}
		}
		return newLst;
	}


	@SuppressWarnings("unchecked")
	public Country country(String code) {
		List<Country> lst = (List<Country>) getList(ServiceConstants.STAT_LST_COUNTRY);
		if (!BaseUtil.isListNullZero(lst)) {
			for (Country obj : lst) {
				if (BaseUtil.isEqualsCaseIgnore(code, obj.getCntryCode())) {
					return obj;
				}
			}
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public List<Nationality> nationalityList() {
		return (List<Nationality>) getList(ServiceConstants.STAT_LST_NATIONALITY);
	}


	@SuppressWarnings("unchecked")
	public Nationality nationalityByCode(String code) {

		List<Nationality> lst = (List<Nationality>) getList(ServiceConstants.STAT_LST_NATIONALITY);
		if (!BaseUtil.isListNullZero(lst)) {
			for (Nationality obj : lst) {
				if (BaseUtil.isEqualsCaseIgnore(code, obj.getNtnltyCode())) {
					return obj;
				}
			}
		}
		return null;
	}


	public Map<String, String> defaultMaritalStatusList() {
		Map<String, String> map = new HashMap<>();
		map.put("M", "Married");
		map.put("S", "Single");
		map.put("D", "Divorced");
		return map;
	}


	@SuppressWarnings("unchecked")
	public MaritalStatus maritalStatusByCode(String code) {

		List<MaritalStatus> lst = (List<MaritalStatus>) getList(ServiceConstants.STAT_LST_MARITAL_STATUS);

		for (MaritalStatus obj : lst) {
			if (BaseUtil.isEqualsCaseIgnore(code, obj.getMaritalStatusCode())) {
				return obj;
			}
		}
		return null;
	}

}