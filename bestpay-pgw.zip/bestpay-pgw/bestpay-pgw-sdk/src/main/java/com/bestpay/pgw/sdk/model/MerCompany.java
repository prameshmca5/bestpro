package com.bestpay.pgw.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


public class MerCompany implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private Integer companyId;

	private String compRefId;

	private String companyName;

	private String address1;

	private String address2;

	private String address3;

	private String postcode;

	private String city;

	private String state;

	private String country;

	private String email;

	private String phone;

	private String picName;

	private String picEmail;

	private String picPhone;

	private String callbackUrl;

	private String relationship;

	private String createId;

	private Timestamp createDt;

	private Timestamp updateDt;

	private String updateId;

	private String stateMy;

	private String stateNonMy;

	private String cityMy;

	private String cityNonMy;

	private String protocolCallbackUrl;


	public String getProtocolCallbackUrl() {
		return protocolCallbackUrl;
	}


	public void setProtocolCallbackUrl(String protocolCallbackUrl) {
		this.protocolCallbackUrl = protocolCallbackUrl;
	}


	public String getCityMy() {
		return cityMy;
	}


	public void setCityMy(String cityMy) {
		this.cityMy = cityMy;
	}


	public String getCityNonMy() {
		return cityNonMy;
	}


	public void setCityNonMy(String cityNonMy) {
		this.cityNonMy = cityNonMy;
	}


	public String getStateMy() {
		return stateMy;
	}


	public void setStateMy(String stateMy) {
		this.stateMy = stateMy;
	}


	public String getStateNonMy() {
		return stateNonMy;
	}


	public void setStateNonMy(String stateNonMy) {
		this.stateNonMy = stateNonMy;
	}


	public Integer getCompanyId() {
		return companyId;
	}


	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}


	public String getCompRefId() {
		return compRefId;
	}


	public void setCompRefId(String compRefId) {
		this.compRefId = compRefId;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public String getAddress1() {
		return address1;
	}


	public void setAddress1(String address1) {
		this.address1 = address1;
	}


	public String getAddress2() {
		return address2;
	}


	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	public String getAddress3() {
		return address3;
	}


	public void setAddress3(String address3) {
		this.address3 = address3;
	}


	public String getPostcode() {
		return postcode;
	}


	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getPicName() {
		return picName;
	}


	public void setPicName(String picName) {
		this.picName = picName;
	}


	public String getPicEmail() {
		return picEmail;
	}


	public void setPicEmail(String picEmail) {
		this.picEmail = picEmail;
	}


	public String getPicPhone() {
		return picPhone;
	}


	public void setPicPhone(String picPhone) {
		this.picPhone = picPhone;
	}


	public String getCallbackUrl() {
		return callbackUrl;
	}


	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}


	public String getRelationship() {
		return relationship;
	}


	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

}
