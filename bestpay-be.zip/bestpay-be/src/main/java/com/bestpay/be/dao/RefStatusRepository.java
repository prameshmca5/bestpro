/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.RefStatus;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 3, 2016
 */
@Repository
@RepositoryDefinition(domainClass = RefStatus.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_STATUS_DAO)
public interface RefStatusRepository extends GenericRepository<RefStatus> {

	@Override
	@Query("select u from RefStatus u order by statusDescEn asc")
	public List<RefStatus> findAll();


	@Query("select u from RefStatus u where u.statusCode = :statusCode order by statusDescEn asc")
	public RefStatus findByStatusCode(@Param("statusCode") String statusCode);


	@Query("select u from RefStatus u where u.statusType = :statusType")
	public List<RefStatus> findByStatusType(@Param("statusType") String statusType);


	@Query("select u from RefStatus u where u.statusDescEn = TRIM(:statusDescEn) order by statusDescEn asc")
	public RefStatus findByStatusDescEn(@Param("statusDescEn") String statusDescEn);


	@Query("select u from RefStatus u where u.statusType = :statusType and u.statusCode = :statusCode ")
	public RefStatus findByTypeAndCode(@Param("statusType") String statusType, @Param("statusCode") String statusCode);


	@Query("select count(u) from RefStatus u ")
	public int totalRecords();

}