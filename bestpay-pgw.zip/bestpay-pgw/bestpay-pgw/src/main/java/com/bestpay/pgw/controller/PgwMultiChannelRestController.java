/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.pgw.core.AbstractRestController;
import com.bestpay.pgw.model.PgwMultiChannel;
import com.bestpay.pgw.sdk.constants.PgwErrorCodeEnum;
import com.bestpay.pgw.sdk.constants.PgwUrlConstants;
import com.bestpay.pgw.sdk.exception.PgwException;
import com.bestpay.pgw.sdk.model.MultiChannel;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.pgw.service.PgwMultiChannelService;


/**
 * @author Chaithanya
 * @since 19/07/2018
 */
@RestController
@RequestMapping(PgwUrlConstants.MULTI_CHANNEL_SETTING)
public class PgwMultiChannelRestController extends AbstractRestController {

	@Autowired
	protected PgwMultiChannelService pgwMultiChannelService;


	@GetMapping(value = PgwUrlConstants.FIND_BY_MERCHANT_ID, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<MultiChannel> getMerChanSetWrapperById(@RequestParam String merchantId) {
		List<MultiChannel> multichannelList = new ArrayList<>();
		List<PgwMultiChannel> channelLst = pgwMultiChannelService.findMultiChannelByMerchantId(merchantId);
		if (BaseUtil.isListNullAndZero(channelLst)) {
			throw new PgwException(PgwErrorCodeEnum.E400PGW012, new String[] { merchantId });
		}
		for (PgwMultiChannel c : channelLst) {
			multichannelList.add(dozerMapper.map(c, MultiChannel.class));
		}
		return multichannelList;
	}

}
