/**
 * 
 */
package com.be.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeAirlinesContactRepository;
import com.be.model.BeAirlinesContact;
import com.be.model.BeAirlinesProfile;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_AIRLINES_CONTACT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_AIRLINES_CONTACT_SVC)
public class BeAirlinesContactService extends AbstractService<BeAirlinesContact> {

	@Autowired
	BeAirlinesContactRepository beAirlinesOwnerDao;
	
	@Override
	public GenericRepository<BeAirlinesContact> primaryDao() {
		return beAirlinesOwnerDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<BeAirlinesContact> createUpdate(Set<BeAirlinesContact> set, BeAirlinesProfile airlinesProfile, String userId){
		
		List<BeAirlinesContact> beAirlinesContacts = new ArrayList<>();
		set.stream().forEach(contact -> {
			if(BaseUtil.isObjNull(contact.getAirlinesContactId())) {
				contact.setCreateId(userId);
				contact.setAirlinesProfile(airlinesProfile);
			}else {
				BeAirlinesContact contactOri = find(contact.getAirlinesContactId());
				contact.setAirlinesProfile(contactOri.getAirlinesProfile());
				contact.setCreateId(contactOri.getCreateId());
				contact.setCreateDt(contactOri.getCreateDt());
			}
			contact.setUpdateId(userId);
			beAirlinesContacts.add(contact);
		});		
		return beAirlinesOwnerDao.save(beAirlinesContacts);
	}
}
