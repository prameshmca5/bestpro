/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;

/**
 * @author michelle.angela
 *
 */
public class AirlinesContact implements Serializable {

	private static final long serialVersionUID = 1841107470748263660L;

	private Integer airlinesContactId;

	private AirlinesProfile airlinesProfile;
	 
	private Metadata titleTypeMtdt;
	
	private String fullName;
	
	private String contactNo;
	
	private String email;
	
	private Boolean isActive;

	public Integer getAirlinesContactId() {
		return airlinesContactId;
	}

	public void setAirlinesContactId(Integer airlinesContactId) {
		this.airlinesContactId = airlinesContactId;
	}

	public AirlinesProfile getAirlinesProfile() {
		return airlinesProfile;
	}

	public void setAirlinesProfile(AirlinesProfile airlinesProfile) {
		this.airlinesProfile = airlinesProfile;
	}

	public Metadata getTitleTypeMtdt() {
		return titleTypeMtdt;
	}

	public void setTitleTypeMtdt(Metadata titleTypeMtdt) {
		this.titleTypeMtdt = titleTypeMtdt;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
}
