/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.RefPaymentTypeRepository;
import com.bestpay.be.model.RefPaymentType;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Zia
 * @since Feb 22, 2018
 */
@Service(QualifierConstants.REF_PAYMENT_TYPE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_PAYMENT_TYPE_SVC)
@Transactional(QualifierConstants.TRANS_MANAGER)
public class RefPaymentTypeService extends AbstractService<RefPaymentType> {

	@Autowired
	private RefPaymentTypeRepository paymentTypeDao;


	@Override
	public GenericRepository<RefPaymentType> primaryDao() {
		return paymentTypeDao;
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = true, rollbackFor = Exception.class)
	public List<RefPaymentType> getAllPaymentTypes() {
		return paymentTypeDao.findAll();
	}

}