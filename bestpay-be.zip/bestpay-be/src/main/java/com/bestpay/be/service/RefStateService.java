/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.RefStateRepository;
import com.bestpay.be.model.RefState;
import com.bestpay.be.sdk.constants.BeCacheConstants;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Ilhomjon
 * @since Feb 22, 2018
 */
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Service(QualifierConstants.REF_STATE_SVC)
@Qualifier(QualifierConstants.REF_STATE_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
public class RefStateService extends AbstractService<RefState> {

	@Autowired
	private RefStateRepository stateRepository;


	@Override
	public GenericRepository<RefState> primaryDao() {
		return stateRepository;
	}


	@Cacheable(key = "T(com.bestpay.be.sdk.constants.BeCacheConstants).CACHE_KEY_STATE_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public List<RefState> allStates() {
		return stateRepository.findAllStates();
	}


	@Cacheable(key = "(T(com.bestpay.be.sdk.constants.BeCacheConstants).CACHE_KEY_STATE).concat(#stateCode)", condition = "#stateCode != null and #result != null")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public RefState findByStateCode(String stateCode) {
		return stateRepository.findByStateCode(stateCode);
	}

}