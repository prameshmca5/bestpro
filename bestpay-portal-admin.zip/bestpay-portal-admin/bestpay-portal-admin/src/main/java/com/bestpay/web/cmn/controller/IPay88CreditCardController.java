package com.bestpay.web.cmn.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.model.MerPayPageSet;
import com.bestpay.be.sdk.model.PaymentLinkInfo;
import com.bestpay.be.sdk.model.Provider;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.web.constants.AppConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;

@Controller
@RequestMapping(value = PageConstants.PAGE_IPAY88_CC)
public class IPay88CreditCardController extends AbstractController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TestPaymentLinkController.class);
	
	@GetMapping
	public ModelAndView view( HttpSession session, HttpServletResponse response)
			throws BeException {
		LOGGER.info("WELCOME PAYMENT LINK PAGE");

		PaymentLinkInfo paylkinfo = new PaymentLinkInfo();
		Date date = new Date();
		Random r = new Random(System.currentTimeMillis());
		Integer randnumber = ((1 + r.nextInt(2)) * 10000 + r.nextInt(10000));
		String curdat = new SimpleDateFormat("yyyyMMdd").format(date);
		String orderId = curdat + randnumber;
		paylkinfo.setOrderId(orderId);
		paylkinfo.setCurrency("MYR");

		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_IPAY_CC, "Test Payment Link", null);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.pgw.tst.lst"));

		mav.addObject("ipay88", paylkinfo);
		List<MerPayPageSet> channelList = getBeService().getMerChantpaymentListByCompRefId("migrstem");
		mav.addObject("channel", channelList);
		return mav;

	}
	
	@PostMapping
	public ModelAndView viewpost(@ModelAttribute("ipay88") PaymentLinkInfo paymentLinkInfo,
			 BindingResult result, HttpServletRequest request, HttpServletResponse response)
			throws BeException {

		// Generate URL
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_IPAY_CC_FORM, "ipay88 creditcard form", null);
		String currency = "MYR";
		String merid = paymentLinkInfo.getMerchantId();
		MerAccInfo accInfo = getBeService().getAccInfoById(merid);

		Provider provider = getBeService().findProviderByChannel("IPAYCC");
		StringBuilder sb = new StringBuilder(provider.getBestpayRedirectUrl());
		String s = "//";
//		String url = sb.substring(0,sb.indexOf("/",sb.indexOf(s)));
//		url = url+"/ipaycreditcard";
		paymentLinkInfo.setMerPayUrl(sb.substring(0,sb.indexOf("/",sb.indexOf(s)+2))+"/ipaycreditcard");
		//paymentLinkInfo.setMerPayUrl("http://localhost:8070/bestpay-portal-pgw/ipaycreditcard");
		paymentLinkInfo.setName(accInfo.getCompany());
		paymentLinkInfo.setEmail(accInfo.getEmail());
		paymentLinkInfo.setMerchantId(merid);

		// get verify key
		MerPayPageSet payPageSet = getBeService().getMerPayPageSetById(merid);
		String verifykey = null;
		if (!BaseUtil.isObjNull(payPageSet)) {
			verifykey = payPageSet.getVerifyKey();
		}

		System.out.println("VERIFYKEY--" + verifykey);

		StringBuilder reqhashParam = new StringBuilder();
		DigestUtils.sha256Hex(reqhashParam.toString());
		reqhashParam.append(paymentLinkInfo.getMerchantId()).append(currency).append(paymentLinkInfo.getOrderId())
				// .append(new
				// BigDecimal(paymentLinkInfo.getAmount()).setScale(2,
				// BigDecimal.ROUND_HALF_UP))
				.append(paymentLinkInfo.getAmount()).append(verifykey);
		String requestHash = DigestUtils.sha256Hex(reqhashParam.toString());
		paymentLinkInfo.setReqhash(requestHash);
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.pgw.tst.lst"));
		
		System.out.println(provider.getFpxUrl());
		
		//mav.addObject("ipay88", paymentLinkInfo);
		mav.addObject("paymentLink", sb.substring(0,sb.indexOf("/",sb.indexOf(s)+2))+"/ipaycreditcard");
		mav.addObject("verifyKey", verifykey);

		return mav;
	}

}
