/**
 * 
 */
package com.bestid.be.sdk.model;

import java.io.Serializable;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author roziana
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class QrDetail implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4467595892047513845L;
	
	private String guid;
	
	private Timestamp expiredDt;
	
	private Integer license;
	
	private String clientId;

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public Timestamp getExpiredDt() {
		return expiredDt;
	}

	public void setExpiredDt(Timestamp expiredDt) {
		this.expiredDt = expiredDt;
	}

	public Integer getLicense() {
		return license;
	}

	public void setLicense(Integer license) {
		this.license = license;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	

}
