package com.bestpay.pgw.service;


import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.PgwMerchantProfileRepository;
import com.bestpay.pgw.model.PgwMerchantProfile;
import com.bestpay.pgw.util.QualifierConstants;


@Service(QualifierConstants.PGW_MERCHANT_PROFILE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERCHANT_PROFILE_SVC)
@Transactional
public class PgwMerchantProfileService extends AbstractService<PgwMerchantProfile> {

	@Autowired
	private PgwMerchantProfileRepository pgwMerchantProfileDao;


	@Override
	public GenericRepository<PgwMerchantProfile> primaryDao() {
		return pgwMerchantProfileDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwMerchantProfile findbyMerchantId(String merchantId) {
		return pgwMerchantProfileDao.findbyMerchantId(merchantId);
	}

}
