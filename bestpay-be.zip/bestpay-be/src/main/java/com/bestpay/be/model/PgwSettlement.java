/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.model;


import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * @author Afif Saman
 * @since June 6, 2018
 */
@Entity
@Table(name = "PGW_SETTLEMENT")
public class PgwSettlement extends AbstractEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SETID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer settlementId;

	@Column(name = "MERCHANTID")
	private String merchantId;

	@Column(name = "MERCHANT_BANK_ACC")
	private String merchantBankAcc;

	@Column(name = "MERCHANT_ACC_NO")
	private String merchantAccNo;

	@Column(name = "CHEQUE_NO")
	private String chequeNo;

	@Column(name = "RESERVE_DAY")
	private String reserveDay;

	@Column(name = "BANKIN_SLIP")
	private String bankinSlip;

	@Column(name = "CUR_AMT")
	private String curAmt;

	@Column(name = "AMOUNT")
	private Double amount;

	@Column(name = "CURRENCY_RATE")
	private Double currencyRate;

	@Column(name = "CUR_ACTUAL_AMOUNT")
	private String curActAmount;

	@Column(name = "ACTUAL_AMOUNt")
	private Double actualAmount;

	@Column(name = "SETTLEMENT_FEE")
	private Double settlementFee;

	@Column(name = "CUR_COSTPENALTY")
	private String curCostPenalty;

	@Column(name = "COST_PENALTY")
	private Double costPenalty;

	@Column(name = "CUR_EXTRAFEE")
	private String curExtraFee;

	@Column(name = "EXTRA_FEE")
	private Double extraFee;

	@Column(name = "CUR_CHARGEBACK")
	private String curChargeback;

	@Column(name = "CHARGEBACK")
	private Double chargeback;

	@Column(name = "CUR_REFUND")
	private String curRefund;

	@Column(name = "REFUND")
	private Double refund;

	@Column(name = "CUR_REFUNDPART")
	private String curRefundPart;

	@Column(name = "REFUND_PART")
	private Double refundPart;

	@Column(name = "CUR_ADMINFEE")
	private String curAdminFee;

	@Column(name = "ADMIN_FEE")
	private Double adminFee;

	@Column(name = "CUR_TRANS_TOTAL_AMT")
	private String curTransTotalAmt;

	@Column(name = "TRANS_TOTAL_AMT")
	private Double transTotalAmt;

	@Column(name = "TRANS_REC")
	private String transRec;

	@Column(name = "MEMO")
	private String memo;

	@Column(name = "START_DATE")
	private Date startDate;

	@Column(name = "END_DATE")
	private Date endDate;

	@Column(name = "MODIFY_DATE")
	private Date modifyDate;

	@Column(name = "CREATE_DATE")
	private Date createDate;

	@Column(name = "SETTLE_DATE")
	private Date settleDate;

	@Column(name = "DELETED")
	private Integer deleted;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "ORDER_ID")
	private String orderId;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "PSA")
	private String psa;
	
	@Column(name = "CHANNEL")
	private String channel;


	public PgwSettlement() {
		// pgwSettlement backend model
	}


	public Integer getSettlementId() {
		return settlementId;
	}


	public void setSettlementId(Integer settlementId) {
		this.settlementId = settlementId;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getMerchantBankAcc() {
		return merchantBankAcc;
	}


	public void setMerchantBankAcc(String merchantBankAcc) {
		this.merchantBankAcc = merchantBankAcc;
	}


	public String getMerchantAccNo() {
		return merchantAccNo;
	}


	public void setMerchantAccNo(String merchantAccNo) {
		this.merchantAccNo = merchantAccNo;
	}


	public String getChequeNo() {
		return chequeNo;
	}


	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}


	public String getBankinSlip() {
		return bankinSlip;
	}


	public void setBankinSlip(String bankinSlip) {
		this.bankinSlip = bankinSlip;
	}


	public String getCurAmt() {
		return curAmt;
	}


	public void setCurAmt(String curAmt) {
		this.curAmt = curAmt;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public Double getCurrencyRate() {
		return currencyRate;
	}


	public void setCurrencyRate(Double currencyRate) {
		this.currencyRate = currencyRate;
	}


	public String getCurActAmount() {
		return curActAmount;
	}


	public void setCurActAmount(String curActAmount) {
		this.curActAmount = curActAmount;
	}


	public Double getActualAmount() {
		return actualAmount;
	}


	public void setActualAmount(Double actualAmount) {
		this.actualAmount = actualAmount;
	}


	public Double getSettlementFee() {
		return settlementFee;
	}


	public void setSettlementFee(Double settlementFee) {
		this.settlementFee = settlementFee;
	}


	public String getCurCostPenalty() {
		return curCostPenalty;
	}


	public void setCurCostPenalty(String curCostPenalty) {
		this.curCostPenalty = curCostPenalty;
	}


	public Double getCostPenalty() {
		return costPenalty;
	}


	public void setCostPenalty(Double costPenalty) {
		this.costPenalty = costPenalty;
	}


	public String getCurExtraFee() {
		return curExtraFee;
	}


	public void setCurExtraFee(String curExtraFee) {
		this.curExtraFee = curExtraFee;
	}


	public Double getExtraFee() {
		return extraFee;
	}


	public void setExtraFee(Double extraFee) {
		this.extraFee = extraFee;
	}


	public String getCurChargeback() {
		return curChargeback;
	}


	public void setCurChargeback(String curChargeback) {
		this.curChargeback = curChargeback;
	}


	public Double getChargeback() {
		return chargeback;
	}


	public void setChargeback(Double chargeback) {
		this.chargeback = chargeback;
	}


	public String getCurRefund() {
		return curRefund;
	}


	public void setCurRefund(String curRefund) {
		this.curRefund = curRefund;
	}


	public Double getRefund() {
		return refund;
	}


	public void setRefund(Double refund) {
		this.refund = refund;
	}


	public String getCurRefundPart() {
		return curRefundPart;
	}


	public void setCurRefundPart(String curRefundPart) {
		this.curRefundPart = curRefundPart;
	}


	public Double getRefundPart() {
		return refundPart;
	}


	public void setRefundPart(Double refundPart) {
		this.refundPart = refundPart;
	}


	public String getCurAdminFee() {
		return curAdminFee;
	}


	public void setCurAdminFee(String curAdminFee) {
		this.curAdminFee = curAdminFee;
	}


	public Double getAdminFee() {
		return adminFee;
	}


	public void setAdminFee(Double adminFee) {
		this.adminFee = adminFee;
	}


	public String getCurTransTotalAmt() {
		return curTransTotalAmt;
	}


	public void setCurTransTotalAmt(String curTransTotalAmt) {
		this.curTransTotalAmt = curTransTotalAmt;
	}


	public Double getTransTotalAmt() {
		return transTotalAmt;
	}


	public void setTransTotalAmt(Double transTotalAmt) {
		this.transTotalAmt = transTotalAmt;
	}


	public String getTransRec() {
		return transRec;
	}


	public void setTransRec(String transRec) {
		this.transRec = transRec;
	}


	public String getMemo() {
		return memo;
	}


	public void setMemo(String memo) {
		this.memo = memo;
	}


	public Integer getDeleted() {
		return deleted;
	}


	public void setDeleted(Integer deleted) {
		this.deleted = deleted;
	}


	public Date getModifyDate() {
		return modifyDate;
	}


	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}


	public Date getCreateDate() {
		return createDate;
	}


	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}


	public Date getSettleDate() {
		return settleDate;
	}


	public void setSettleDate(Date settleDate) {
		this.settleDate = settleDate;
	}


	public String settleDate() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getStatus() {
		return status;
	}


	public String getReserveDay() {
		return reserveDay;
	}


	public void setReserveDay(String reserveDay) {
		this.reserveDay = reserveDay;
	}


	public Date getStartDate() {
		return startDate;
	}


	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	public Date getEndDate() {
		return endDate;
	}


	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}


	public String getPsa() {
		return psa;
	}


	public void setPsa(String psa) {
		this.psa = psa;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}

}