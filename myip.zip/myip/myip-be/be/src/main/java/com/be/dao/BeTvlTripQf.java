/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeAcctPassport;
import com.be.model.BeAcctProfile;
import com.be.model.BeAcctTraveller;
import com.be.model.BeTvl;
import com.be.model.BeTvlProfile;
import com.be.model.BeTvlStat;
import com.be.model.BeTvlTrip;
import com.be.model.RefStatus;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.AcctProfile;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Trip;
import com.be.service.BeAcctPassportService;
import com.be.service.RefStatusService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;


/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_TRIP_QF)
public class BeTvlTripQf extends QueryFactory<BeTvlTrip> {

	@Autowired
	BeTvlProfileQf beTvlProfileQf;
	// BeTvlProfileService tvlProfileSvc;

	@Autowired
	BeAcctPassportService acctPassportSvc;

	@Autowired
	RefStatusService refStatusSvc;

	@Autowired
	BeAcctProfileQf beAcctProfileQf;

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BeTvlTrip> searchByProperty(BeTvlTrip t) {
		return (Root<BeTvlTrip> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}


	@Override
	public List<BeTvlTrip> searchAllByProperty(BeTvlTrip t) {
		CriteriaQuery<BeTvlTrip> cq = cb.createQuery(BeTvlTrip.class);
		Root<BeTvlTrip> from = cq.from(BeTvlTrip.class);
		List<Predicate> predicates = generateCriteria(cb, from, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public List<BeTvlTrip> searchBeTvlTripPagination(Trip dto, DataTableRequest<?> dataTableInRQ) {

		List<BeTvlTrip> result = new ArrayList<>();
		CriteriaQuery<BeTvlTrip> cq = cb.createQuery(BeTvlTrip.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlTrip> root = cq.from(BeTvlTrip.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq, false);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					cq.orderBy(getOrderByClause(cb, root, pagination));
				}
			}

			TypedQuery<BeTvlTrip> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}


	public BeTvlTrip searchBeTvlTrip(Trip dto) {

		BeTvlTrip result = null;
		CriteriaQuery<BeTvlTrip> cq = cb.createQuery(BeTvlTrip.class);
		List<Predicate> predicates = new ArrayList<>();

		if (cq != null) {
			Root<BeTvlTrip> root = cq.from(BeTvlTrip.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			joinFetch(root, predicates, dto, cq, true);

			cq.select(root).distinct(true);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));
			TypedQuery<BeTvlTrip> tQuery = em.createQuery(cq);

			try {
				result = tQuery.getSingleResult();
			} catch (NoResultException e) {
				return null;
			}
		}
		return result;
	}


	public Long getCount(Trip dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeTvlTrip> root = cq.from(BeTvlTrip.class);
		predicates.addAll(generateCriteria(cb, root, dto));
		joinCount(root, predicates, dto, cq);

		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			Trip dto = JsonUtil.transferToObject(criteria, Trip.class);

			if (!BaseUtil.isObjNull(dto.getSubmittedDateFrom())) {
				predicates.add(cb.greaterThanOrEqualTo(from.get("submitDt"), dto.getSubmittedDateFrom()));
			}

			if (!BaseUtil.isObjNull(dto.getSubmittedDateTo())) {
				predicates.add(cb.lessThanOrEqualTo(from.get("submitDt"), dto.getSubmittedDateTo()));
			}

			if (!BaseUtil.isObjNull(dto.getTvlTripId())) {
				predicates.add(cb.equal(from.get("tvlTripId"), dto.getTvlTripId()));
			}

			if (!BaseUtil.isObjNull(dto.getTvlTripCodeNo())) {
				predicates.add(cb.equal(from.get("tvlTripCodeNo"), dto.getTvlTripCodeNo()));
			}

			if (!BaseUtil.isObjNull(dto.getDepartureDtFrom())) {
				predicates.add(cb.greaterThanOrEqualTo(from.get("departureDt"), dto.getDepartureDtFrom()));
			}

			if (!BaseUtil.isObjNull(dto.getDepartureDtTo())) {
				predicates.add(cb.lessThanOrEqualTo(from.get("departureDt"), dto.getDepartureDtTo()));
			}

			if (!BaseUtil.isObjNull(dto.getArrivalDtFrom())) {
				predicates.add(cb.greaterThanOrEqualTo(from.get("arrivalDt"), dto.getArrivalDtFrom()));
			}

			if (!BaseUtil.isObjNull(dto.getArrivalDtTo())) {
				predicates.add(cb.lessThanOrEqualTo(from.get("arrivalDt"), dto.getArrivalDtTo()));
			}

		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void joinFetch(From<?, ?> from, List<Predicate> predicates, Trip dto, CriteriaQuery<BeTvlTrip> cq,
			boolean allDtls) {

		from.fetch("departureAirport", JoinType.LEFT);
		from.fetch("arrivalAirport", JoinType.LEFT);
		from.fetch("departureAirportRtn", JoinType.LEFT);
		from.fetch("arrivalAirportRtn", JoinType.LEFT);

		Join<BeTvlTrip, BeTvl> tvls = (Join) from.fetch("tvls", JoinType.INNER);
		if (dto.isEmbedTvlStats()) {
			Join<BeTvl, BeTvlStat> tvlStats = (Join) tvls.fetch("tvlStats", JoinType.LEFT);
			tvlStats.fetch("dqStatMtdt", JoinType.LEFT);
		}
		Join<BeTvl, RefStatus> status = (Join) tvls.fetch("status", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getStatusId())) {
			predicates.addAll(refStatusSvc.generateCriteria(cb, status, dto));
		}

		Join<BeTvlTrip, BeTvlProfile> tvlProfile = (Join) tvls.fetch("tvlProfile", JoinType.LEFT);
		predicates.addAll(beTvlProfileQf.generateCriteria(cb, tvlProfile, dto));

		Join<BeTvlProfile, BeAcctPassport> passport = (Join) tvlProfile.fetch("acctPassport", JoinType.LEFT);
		predicates.addAll(acctPassportSvc.generateCriteria(cb, passport, dto));

		if (allDtls) {
			from.fetch("tripHealths", JoinType.LEFT);
			from.fetch("tripAccommodations", JoinType.LEFT);
		}

		if (!BaseUtil.isObjNull(dto.getAcctProfId())) {
			AcctProfile acctProfileDto = new AcctProfile();
			acctProfileDto.setAcctProfId(dto.getAcctProfId());
			Join<BeTvlProfile, BeAcctTraveller> acctTraveller = (Join) tvlProfile.fetch("acctTraveller",
					JoinType.LEFT);
			Join<BeAcctTraveller, BeAcctProfile> acctProfile = (Join) acctTraveller.fetch("acctProfile",
					JoinType.LEFT);
			predicates.addAll(beAcctProfileQf.generateCriteria(cb, acctProfile, acctProfileDto));
		}
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void joinCount(From<?, ?> from, List<Predicate> predicates, Trip dto, CriteriaQuery<Long> cq) {

		Join<BeTvlTrip, BeTvl> tvls = (Join) from.join("tvls", JoinType.INNER);
		Join<BeTvl, RefStatus> status = (Join) tvls.join("status", JoinType.LEFT);
		if (!BaseUtil.isObjNull(dto.getStatusId())) {
			predicates.addAll(refStatusSvc.generateCriteria(cb, status, dto));
		}

		Join<BeTvlTrip, BeTvlProfile> tvlProfile = (Join) tvls.join("tvlProfile", JoinType.LEFT);
		predicates.addAll(beTvlProfileQf.generateCriteria(cb, tvlProfile, dto));

		Join<BeTvlProfile, BeAcctPassport> passport = (Join) tvlProfile.join("acctPassport", JoinType.LEFT);
		predicates.addAll(acctPassportSvc.generateCriteria(cb, passport, dto));

		if (!BaseUtil.isObjNull(dto.getAcctProfId())) {
			AcctProfile acctProfileDto = new AcctProfile();
			acctProfileDto.setAcctProfId(dto.getAcctProfId());
			Join<BeTvlProfile, BeAcctTraveller> acctTraveller = (Join) tvlProfile.join("acctTraveller",
					JoinType.LEFT);
			Join<BeAcctTraveller, BeAcctProfile> acctProfile = (Join) acctTraveller.join("acctProfile",
					JoinType.LEFT);
			predicates.addAll(beAcctProfileQf.generateCriteria(cb, acctProfile, acctProfileDto));
		}
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<BeTvlTrip> searchByPropertyGroupByTvlTripCodeNo(Trip dto) {

		List<BeTvlTrip> result = new ArrayList<>();
		CriteriaQuery<BeTvlTrip> cq = cb.createQuery(BeTvlTrip.class);
		List<Predicate> predicates = new ArrayList<>();

		AcctProfile acctProfileDto = new AcctProfile();
		acctProfileDto.setAcctProfId(dto.getAcctProfId());

		if (cq != null) {
			Root<BeTvlTrip> root = cq.from(BeTvlTrip.class);
			predicates.addAll(generateCriteria(cb, root, dto));
			Join<BeTvlTrip, BeTvl> tvls = (Join) root.fetch("tvls", JoinType.INNER);
			Join<BeTvl, BeAcctProfile> acctProfile = (Join) tvls.fetch("acctProfile", JoinType.INNER);
			predicates.addAll(beAcctProfileQf.generateCriteria(cb, acctProfile, acctProfileDto));

			cq.select(root).distinct(true);
			List<Expression<?>> groupBy = new ArrayList<>();
			groupBy.add(root.get("tvlTripCodeNo"));
			cq.where(predicates.toArray(new Predicate[predicates.size()])).groupBy(groupBy);
			TypedQuery<BeTvlTrip> tQuery = em.createQuery(cq);

			result = tQuery.getResultList();

		}
		return result;
	}

}
