/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.form;

import java.io.Serializable;
import java.util.Date;

public class Announcement implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int anncId;
	private String anncTitle;
	private String anncMessage;
	private Date anncDate;
	private String statusCd;
	private String createId;
	private Date createDt;
	private String updateId;
	private Date updateDt;
	public int getAnncId() {
		return anncId;
	}
	public void setAnncId(int anncId) {
		this.anncId = anncId;
	}
	public String getAnncTitle() {
		return anncTitle;
	}
	public void setAnncTitle(String anncTitle) {
		this.anncTitle = anncTitle;
	}
	public String getAnncMessage() {
		return anncMessage;
	}
	public void setAnncMessage(String anncMessage) {
		this.anncMessage = anncMessage;
	}
	public Date getAnncDate() {
		return anncDate;
	}
	public void setAnncDate(Date anncDate) {
		this.anncDate = anncDate;
	}
	public String getStatusCd() {
		return statusCd;
	}
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	public String getCreateId() {
		return createId;
	}
	public void setCreateId(String createId) {
		this.createId = createId;
	}
	public Date getCreateDt() {
		return createDt;
	}
	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}
	public String getUpdateId() {
		return updateId;
	}
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	public Date getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}
	
}
