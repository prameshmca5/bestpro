/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Country;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.model.MerCompBankDetails;
import com.bestpay.be.sdk.model.MerCompany;
import com.bestpay.be.sdk.model.MerGenInfo;
import com.bestpay.be.sdk.model.MerchantPid;
import com.bestpay.be.sdk.model.Provider;
import com.bestpay.be.sdk.model.SettlementInfo;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.sdk.model.Transaction;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.report.sdk.constants.ReportTypeEnum;
import com.bestpay.report.sdk.model.Report;
import com.bestpay.web.config.iam.CustomUserDetails;
import com.bestpay.web.constants.AppConstants;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.WebUtil;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;


/**
 * @author Atiqah Khairuddin
 * @since March 25, 2019
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_REMITTENCE_STTLMNT)
public class RemittenceSettlementController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(RemittenceSettlementController.class);

	private static final String REMITT_SET_VIEW = "remittSetview";

	private static final String REMITTENCE_SETTLEMENT = "remittenceSettlement";

	private static final String STLMNTSTAT = "STLMNTSTAT";

	private static final String STATUSLIST = "statusList";


	@GetMapping
	public ModelAndView view(SettlementInfo settlementInfo, BindingResult result, HttpSession session)
			throws BeException {
		LOGGER.info("Welcome Admin SETTLEMENT PAGE");
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_REMITTENCE_SETTLEMENT, REMITTENCE_SETTLEMENT, null,
				"remittence-settlement-script");
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.pgw.sttl.lst"));
		List<Status> status = staticData.status(STLMNTSTAT);
		mav.addObject(STATUSLIST, status);
		settlementInfo.setUserType(getCurrentUser().getUserRoleGroupCode());
		mav.addObject("settlementInfo", settlementInfo);
		return mav;
	}


	// Search settlement
	@PostMapping(params = "search")
	public ModelAndView search(SettlementInfo settlementInfo, BindingResult result, HttpSession session)
			throws BeException {
		LOGGER.info("Welcome Admin REMITTENCE SETTLEMENT PAGE");
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_REMITTENCE_SETTLEMENT, REMITTENCE_SETTLEMENT, null,
				"remittence-settlement-script");
		mav.addObject(AppConstants.PAGE_TITLE, messageService.getMessage("lbl.pgw.sttl.lst"));
		List<Status> status = staticData.status(STLMNTSTAT);
		mav.addObject(STATUSLIST, status);
		mav.addObject("settlementInfo", settlementInfo);
		LOGGER.info("Search date {}", settlementInfo.getSettleDate());
		return mav;
	}


	// Reset searching settlement
	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute("settlementInfo") @Validated SettlementInfo settlementInfo,
			BindingResult result, HttpServletRequest request, HttpSession session) throws BeException {
		SettlementInfo settleInfo = new SettlementInfo();
		LOGGER.info("--reset--");
		return view(settleInfo, result, session);
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String getApplicationInfoPaginated(
			@ModelAttribute("settlementInfo") SettlementInfo settlementInfo, HttpServletRequest request) {
		LOGGER.info("GET PAGINATED REMITTENCE SETTLEMENT LIST....");
		DataTableResults<SettlementInfo> tasks = new DataTableResults<>();
		try {
			LOGGER.info("Search remittence settlement status {}", settlementInfo.getStatus());
			tasks = getBeService().searchRemittenceSettlement(settlementInfo, getPaginationRequest(request, true));
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(e.getMessage());
			tasks.setError(e.getMessage());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			tasks.setError(e.getMessage());
		}

		return new Gson().toJson(tasks);
	}


	@GetMapping(value = "/{setId}")
	public ModelAndView viewlisttrasaction(@PathVariable("setId") Integer setId,
			@ModelAttribute("transactionList") Transaction transactionList, HttpServletRequest request)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_REMITT_SEMT_TRANS_VIEW, REMITT_SET_VIEW, null);
		transactionList.setSetId(setId);
		try {
			List<Transaction> resList = getBeService().getTransSettleList(transactionList);
			if (BaseUtil.isListNullAndZero(resList)) {
				mav.addObject("setlmtTransList", "No Record Found");
			}
			mav.addObject("setlmtTransList", resList);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return mav;
	}


	/**
	 * Transaction Details Page
	 *
	 * @param transId
	 * @param Transaction
	 * @param result
	 * @return
	 */
	@GetMapping(value = "/transaction-details/{transId}")
	public ModelAndView viewTransDetails(@PathVariable String transId,
			@ModelAttribute("transaction") Transaction transaction, BindingResult result) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_REMITT_TRANSACTION_DTLS, "trans", null);

		try {
			Transaction transDtl = getBeService().getTransDtlsById(transId);
			String desc = transDtl.getResMsg().replaceAll("_", " ");
			transDtl.setResMsg(desc);
			MerAccInfo merAccInfo = getBeService().getAccInfoById(transDtl.getMerchantId());
			MerchantPid merchantPid = getBeService().findMerchantPidByMerchantId(transDtl.getMerchantId());
			MerCompany merchantCompany = getBeService().getMerchantCompanyByCompanyId(merAccInfo.getCompanyRefId());
			MerCompBankDetails merCompBankDetails = getBeService()
					.getCompRefBankDetailsByCompRefId(merAccInfo.getCompanyRefId());
			mav.addObject("merchantCompany", merchantCompany);

			LOGGER.info("created_date = {}", transDtl.getCreateDt());
			mav.addObject("merAccInfo", merAccInfo);
			mav.addObject("transaction", transDtl);
			mav.addObject("merchantPid", merchantPid);
			mav.addObject("merCompBankDetails", merCompBankDetails);
		} catch (BeException e) {
			LOGGER.error("Transaction Details = {}", e);
		}

		return mav;
	}


	@GetMapping(value = "/invoice/{setId}")
	public ModelAndView viewlistinvoice(@PathVariable("setId") Integer setId,
			@ModelAttribute("settlementDetails") SettlementInfo settlementInfo, HttpServletRequest request)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_REMITT_SEMT_TRANS_INVOCE, REMITT_SET_VIEW, null);
		try {
			SettlementInfo resList = getBeService().getSettlementInfoById(setId);
			MerGenInfo merGenInfo = getBeService().getGenInfoById(resList.getMerchantId());
			Provider provider = getBeService().findProviderByChannel(resList.getChannel());
			Country country = getBeService().getCountryDescByCountryCode(provider.getCountry());
			String cityDesc = staticData.cityDesc(provider.getCity());
			String stateDesc = staticData.stateDesc(provider.getState());
			LOGGER.info("EMAIL DETAILS ==> {}", merGenInfo.getEmail());
			mav.addObject("settlementDetails", resList);
			mav.addObject("merGenInfo", merGenInfo);
			mav.addObject("country", country.getCntryDesc());
			mav.addObject("city", cityDesc);
			mav.addObject("state", stateDesc);
			mav.addObject("provider", provider);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return mav;

	}


	@GetMapping(value = "/update/{settlementId}")
	public ModelAndView viewUpdate(@PathVariable("settlementId") Integer settlementId,
			@ModelAttribute("settlementInfo") SettlementInfo settlementInfo, HttpServletRequest request)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.REMIT_UPDT_SETTLEMENT_STATUS,
				"remittence-update-settlement-status", null);
		SettlementInfo settlement = getBeService().getSettlementInfoById(settlementId);
		mav.addObject(REMITTENCE_SETTLEMENT, settlement);
		mav.addObject(STATUSLIST, staticData.status(STLMNTSTAT));
		return mav;
	}


	@PostMapping(value = "/update/{settlementId}", params = "update")
	public ModelAndView updateSettlement(@PathVariable Integer settlementId,
			@ModelAttribute("settlementInfo") SettlementInfo settlementInfo, BindingResult result)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.REMIT_UPDT_SETTLEMENT_STATUS,
				"remittence-update-settlement-status", null);
		UserProfile authUser = getCurrentUser();
		settlementInfo.setUserId(authUser.getUserId());
		settlementInfo.setSettlementId(settlementId);
		LOGGER.info("Result = {}", result);
		String listSettlement = "";
		if (!result.hasErrors()) {
			try {
				getBeService().updateSettlementStatus(settlementInfo);
				SettlementInfo settleInfo = getBeService().getSettlementInfoById(settlementId);
				settlementInfo = dozerMapper.map(settleInfo, SettlementInfo.class);
				mav.addAllObjects(PopupBox.success(REMITTENCE_SETTLEMENT, null,
						messageService.getMessage(MessageConstants.SUCC_UPD_SETTLEMENT_STATUS)));
				LOGGER.info("Successfully update settlement status");
				mav.addAllObjects(PopupBox.success(null, null,
						listSettlement + messageService.getMessage(MessageConstants.SUCC_UPD_SETTLEMENT_STATUS),
						PageConstants.PAGE_REMITTENCE_STTLMNT));
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
		mav.addObject(STATUSLIST, staticData.status(STLMNTSTAT));
		mav.addObject(REMITTENCE_SETTLEMENT, settlementInfo);
		return mav;
	}


	@GetMapping(value = "print/genSettlementInvoice")
	public @ResponseBody Report genSettlementInvoice(@ModelAttribute("SettlementInfo") SettlementInfo settlementInfo,
			@RequestParam(value = "settlementId", required = true) Integer settlementId, BindingResult result,
			HttpServletRequest request, HttpSession session) {

		Report report = null;
		try {
			report = getReportService().genRemittanceSettlementInvoice(settlementId, ReportTypeEnum.PDF, true);
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.debug("Error {}", e);
		}
		return report;
	}


	@GetMapping(value = "print/genSettlementReceipt")
	public @ResponseBody Report genSettlementReceipt(@ModelAttribute("SettlementInfo") SettlementInfo settlementInfo,
			@RequestParam(value = "settlementId", required = true) Integer settlementId, BindingResult result,
			HttpServletRequest request, HttpSession session) {

		Report report = null;
		try {
			report = getReportService().genSettlementReceipt(settlementId, ReportTypeEnum.PDF, true);
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.debug("Error {}", e);
		}
		return report;
	}


	@Override
	public UserProfile getCurrentUser() {
		UserProfile userProfile = null;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth.isAuthenticated()) {
			CustomUserDetails cud = (CustomUserDetails) auth.getPrincipal();
			userProfile = cud.getProfile();
		}
		return userProfile;
	}


	@GetMapping(value = "print/genTransDetailsReport")
	public @ResponseBody Report genTransDetailsReport(@ModelAttribute("transaction") Transaction transaction,
			@RequestParam(value = "transId", required = true) String transId, BindingResult result,
			HttpServletRequest request, HttpSession session) {

		Report report = null;
		try {
			report = getReportService().genRemitTransDetailsRpt(transId, ReportTypeEnum.PDF, true);
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
		} catch (Exception e) {
			LOGGER.debug("Exception {}", e);
		}
		return report;
	}

}