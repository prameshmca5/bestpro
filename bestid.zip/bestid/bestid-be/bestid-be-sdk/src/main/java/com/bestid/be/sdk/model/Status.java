/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestid.be.sdk.model;


import java.io.Serializable;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
public class Status implements Serializable {

	private static final long serialVersionUID = 607657392585361232L;

	private String statusId;

	private String statusCode;

	private String statusDescEn;

	private String statusType;


	public String getStatusId() {
		return statusId;
	}


	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}


	public String getStatusCode() {
		return statusCode;
	}


	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}


	public String getStatusDescEn() {
		return statusDescEn;
	}


	public void setStatusDescEn(String statusDescEn) {
		this.statusDescEn = statusDescEn;
	}


	public String getStatusType() {
		return statusType;
	}


	public void setStatusType(String statusType) {
		this.statusType = statusType;
	}

}