/**
 *
 */
package com.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.be.constants.QualifierConstants;
import com.be.core.GenericRepository;
import com.be.model.BeTvlTestResult;


/**
 * @author Atiqah Khairuddin
 *
 */
@Lazy
@Repository
@RepositoryDefinition(domainClass = BeTvlTestResult.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_TEST_RESULT_DAO)
public interface BeTvlTestResultRepository extends GenericRepository<BeTvlTestResult> {

	@Query("select u from BeTvlTestResult u where u.tvlProfile.tvlProfId = :tvlProfId ")
	BeTvlTestResult findByTvlProfile(@Param("tvlProfId") Integer tvlProfId);
}
