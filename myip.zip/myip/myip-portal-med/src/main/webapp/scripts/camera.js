var capturePID = 0;
var captureName = "";
var numCapture = 0;
var resultPID = 0;
var frameCanvas = 0;
var curFrame = 0;
var detecting = 0;
var lastDetectRequestTime = 0;
var localstream;
var video;
var camIcon;
var xStaffId;
var xEmail;
var xFaceId;
var xPhotoId;
var a;
var defaultCaptureMsg = 'Click <i class="fa fa-play" aria-hidden="true"></i> to start the camera.';

//var defaultCaptureMsg = 'Click <i class="fa fa-upload" aria-hidden="true"></i> to upload an image or <i class="fa fa-play" aria-hidden="true"></i> to start the camera.';

$(function() {
	$(".verify1").cropperImage({
		altImage: window.contextPath + '/images/default-alt-profile.png',
        padding: "10px",
        maxWidth: "250px",
        checkIcaoCriteria: false,
        maxWidthAction: null,
        heightSource: "280px",
        aspectRatio: 3 / 4,
        hideUpload: true,
        defaultImage: window.contextPath + '/images/camera_close.png',
        params: {
        	image: this,
	        start: "trvlid",
	        email: "email",
	        faceId: "faceid",
	        photoId: "xPhotoId"
        },
        icaoFeatures: [
			{key: "singleFace",text: "Single Face"},
        	{key: "faceDetected",text: "Face Detected"},
        	{key: "focus",text: "Focus"},
        	{key: "eyesOpen",text: "Eyes Open"},
        	{key: "portraitImage",text: "Portrait Style"}
        ],
        messages : {
        	defaultMsg: 'Click <i class="fa fa-play" aria-hidden="true"></i> to start the camera.',
        	qualityErrorMsg: '<span class="text-danger">Quality failed!</span>',
        	icaoErrorMsg: '<span class="text-danger">ICAO failed!</span>',
        	successMsg: '<span class="text-success">Success upload</span>',
        	failMsg: '<span class="text-danger">Failed Upload</span>',
        	icaoSuccessMsg: '<span class="text-success">Icao checking success!</span>',
        },
        enrollService: false,
        urlQualityCheck: window.contextPath + "/mcVerifyAttendance?quality",
        urlIcaoCheck: window.contextPath + "/mcVerifyAttendance?icao",
        urlEnrollCheck: window.contextPath + "/mcVerifyAttendance?enroll",
        showDefaultBase64: true,
        base64: function(){
        	console.log("base64",this.base64);
        	$('.inputImageLv').val(this.base64);
        	$('input#imageLv').val(this.base64.replace('data:image/png;base64,', ''));
        },
        callback: function () {
            console.log("result", this); 
//            
    		$('#verifyPhotoId .btnSubmitFinal').trigger('click');
//            
//            if(this!=null){
//				if(this.photoId!=null) $('#photoIdField').val(this.photoId);
//				if(this.faceId!=null) $('#faceIdField').val(this.faceId);
//				if(this.id!=null) $('#passIdField').val(this.id);
//				
//
////	    		embedDataMrz(this.mRZdata);
//	    	}
        },
        response: function(){
        	portalUtil.showMainLoading(this.status == 1 ? true : false);
        }
    });
	
	$('#chk1').attr('checked', 'checked');
	$('#btnStart').show();
	$('#btnStop').hide();
	$('#btnCapture').hide();
	$('#captureMsg').html(defaultCaptureMsg);
	$("#inputFile").change(function(a) {
        window.sourceCanvas = null;
        var b = a.target.files[0];
        displayImageFile(b);
    });
	
	

	$('#passportExpDate').daterangepicker({
	    singleDatePicker: true,
	    showDropdowns: true,
//	    endDate : new Date(),
	    minDate: new Date(),
	    minYear: parseInt(moment().format('YYYY'), 15),
//	    maxYear: parseInt(moment().format('YYYY'), 15),
	    locale: { format: "DD/MM/YYYY" },
	}, function(start, end, label) {
		$('input[name="acctPassport.passportExpiryDt"]').val(start.format('DD/MM/YYYY'))
	});

	$('#dobDate').daterangepicker({
	    singleDatePicker: true,
	    showDropdowns: true,
	    endDate : new Date(),
	    maxDate: new Date(),
	    minYear: 1901,
	    maxYear: parseInt(moment().format('YYYY'), 15),
	    locale: { format: "DD/MM/YYYY" },
	}, function(start, end, label) {
		$('input[name="dob"]').val(start.format('DD/MM/YYYY'))
	});

	$(document).on('click','#checkbox-declare',function(){
		console.log($(this).prop("checked"));
		if($('#submitProceed').length>0){
			
			$('#submitClose').prop('disabled',!$(this).prop("checked"));
			$('#submitProceed').prop('disabled',!$(this).prop("checked"));
		}
		
	})
	
});

function initImageFile(x,y,z,a) {
	//debugger;
	stopCamera();

	xStaffId = 'EMP000341';
	xEmail = 'roziana@bestinet.com.my';
	xFaceId = ('13'===null || '13'==='null')? '' : '13';
	xPhotoId = '5c9ae95977b8bbb5bb62aab2';
	/*
	xStaffId = x;
	xEmail = y;
	xFaceId = (z===null || z==='null')? '' : z;
	xPhotoId = a;*/
	$("#inputFile").click();
	reset();
	$("#canvas-preview").hide();
	
	var drop   = document.getElementById('drop');
    if(window.FileReader) { 
    	  addEventHandler(window, 'load', function() {
    	  	
    	    function cancel(e) {
    	      if (e.preventDefault) { e.preventDefault(); }
    	      return false;
    	    }
    	  
    	    // Tells the browser that we *can* drop on this target
    	    addEventHandler(drop, 'dragover', cancel);
    	    addEventHandler(drop, 'dragenter', cancel);
    	  });
    	}
    
    addEventHandler(drop, 'drop', function (e) {
    	  e = e || window.event; // get window.event if e argument missing (in IE)   
    	  if (e.preventDefault) { e.preventDefault(); } // stops the browser from redirecting off to the image.

    	  var dt    = e.dataTransfer;
    	  displayImageFile(dt.files[0]);
    	  return false;
    	});
}

function drawOnSourceCanvas(img) {
	console.log("image",img);
	window.sourceCanvas || (window.sourceCanvas = document.createElement("canvas"));
    if (window.sourceCanvas) {
    	// limit the size of the source image, this is to prevent the request from being too big in size for tomcat to handle
    	var scale = 1;
    	if (img.width > 2000 || img.height > 2000) {
    		if (2000 / img.width < scale) {
    			scale = 2000 / img.width;
    		}
    		if (2000 / img.height < scale) {
    			scale = 2000 / img.height;
    		}
    	}
    	window.sourceCanvas.width = img.width * scale;
        window.sourceCanvas.height = img.height * scale;
        window.sourceCanvas.getContext("2d").drawImage(img, 0, 0, img.width, img.height, 0, 0, window.sourceCanvas.width, window.sourceCanvas.height);
    }
}

function addEventHandler(obj, evt, handler) {
    if(obj.addEventListener) {
        // W3C method
        obj.addEventListener(evt, handler, false);
    } else if(obj.attachEvent) {
        // IE method.
        obj.attachEvent('on'+evt, handler);
    } else {
        // Old school method.
        obj['on'+evt] = handler;
    }
}

function displayImageFile(b) {
    b.type.match(/image.*/) && (a = new FileReader, a.onload = function(a) {
        var d = new Image;
        d.onload = function() {
            //$("#inputFileName").val(b.name);
            window.filename = b.name;
           // $("#result-panel").hide();
            //$("#image-panel").show();
            drawOnSourceCanvas(this);
            drawSourceImage();            
            $("#inputFile").val("")
        };
        d.src = a.target.result
    }, a.readAsDataURL(b))
}

function drawSourceImage() {
    if (window.sourceCanvas) {
        var a = $("#canvas-container").width();
        var b = $("#canvas-container").height();
        a = calculateDimension(window.sourceCanvas.width, window.sourceCanvas.height, a, b);
        window.proportion = window.sourceCanvas.width / a.width;
        b = $("#canvas-portrait");
        b = b[0];
        b.width = 800; 
        b.height = 500;
        b.getContext("2d").drawImage(window.sourceCanvas, 0, 0,
            window.sourceCanvas.width, window.sourceCanvas.height, 0, 0, b.width, b.height);
        if (parent.onImageChange) {
        	parent.onImageChange(window.sourceCanvas, window.filename)
        }
        
        var canvas = document.getElementById("canvas-portrait");
        $('#canvas-portrait').show();
        $('#canvas-portrait').cropper('destroy')
        $('#canvas-portrait').cropper({
        	dragMode: 'move',
        	  aspectRatio: 2 / 3,
        	  cropBoxResizable: false,
        	  autoCropArea: 1,
              strict: false,
              guides: false,
              maxCropBoxWidth: canvas.width,
              maxCropBoxHeight: canvas.height,
              restore: false,
              center: false,
              highlight: false,
              cropBoxMovable: false,
              toggleDragModeOnDblclick: false,
        	});
        $("#btnCrop").show();
    	$('#captureMsg').html('Click Crop & Check Quality button.');
    }
}

function calculateDimension(a, b, c, d) {
    c = {
        width: c,
        height: d
    };
    a > c.width || b > c.height ? (a /= b, b = c.width / a, b <= c.height ? c.height = Math.round(b) : c.width = Math.round(c.height * a)) : (c.width = a, c.height = b);
    return c
}

function initCamera(x,y,z,a) {
	xStaffId = 'EMP000341';
	xEmail = 'roziana@bestinet.com.my';
	xFaceId = ('13'===null || '13'==='null')? '' : '13';
	xPhotoId = '5c9ae95977b8bbb5bb62aab2';
	camIcon = $('#video').siblings("img")
	
    reset();
    var constraints = { audio: false, video: { width: { min: 320, ideal: 800 }, height: { min: 240, ideal: 600 } } }; 

    navigator.mediaDevices.getUserMedia(constraints)
	    .then(function(mediaStream) {
	    	video = $("#video").show()[0];
	    	video.srcObject = mediaStream;
	      	video.onloadedmetadata = function() {
	      		console.log(video);
	        if(video!=null) video.play();
	        
	        camIcon.hide();
	        $('#btnUpload').hide();
	        $('#btnStart').hide();
	    	$('#btnStop').show();
	    	$('#btnCapture').show();
	    	$("#canvas-preview").hide();
	      };
	      localstream = mediaStream; 
	      
	      $('#captureMsg').html('Click <i class="fa fa-camera"></i> to capture photo. Click <i class="fa fa-stop"></i> to stop the camera.');
    }).catch(function(err) {
    	if(err.name === 'NotFoundError'){
    		portalUtil.showMessage("Camera not available. Please check your camera's connection to capture photo.","warning");	
    	}
    	console.log(err.name + ": " + err.message); }); // always check for errors at the end.
    
}

function stopCamera() {
	$('#btnUpload').show();
	$('#btnStart').show();
	$('#btnStop').hide();
	$('#btnCapture').hide();
	if(localstream) {
		video = $("#video");
		video.src = "";
		localstream.getTracks()[0].stop();
	}
	$('#captureMsg').html(defaultCaptureMsg);
}

function captureVideo() {
    var b = document.createElement("canvas");
    var ratio =  video.videoWidth/video.videoHeight;
    b.width = 800;
    b.height = b.width/ratio;
    b.getContext("2d").drawImage(video, 0, 0, b.width, b.height);
    var canvas = document.getElementById("canvas-portrait");
    var ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0,0, canvas.width, canvas.height);
    $('#canvas-portrait').show();
    $('#canvas-portrait').cropper('destroy')
    $('#canvas-portrait').cropper({
    	dragMode: 'move',
    	  aspectRatio: 2 / 3,
    	  cropBoxResizable: false,
    	  autoCropArea: 1,
          strict: false,
          guides: false,
          maxCropBoxWidth: canvas.width,
          maxCropBoxHeight: canvas.height,
          restore: false,
          center: false,
          highlight: false,
          cropBoxMovable: false,
          toggleDragModeOnDblclick: false,
    	});
    stopCamera()
    $('#video').hide();
    $('#btnStart').show();
	$('#btnStop').hide();
	$('#btnCapture').hide();
	$("#btnCrop").show();
	$('#captureMsg').html('Click Crop & Check Quality button.');
}

function cropImage() {
	//debugger;
	portalUtil.showMainLoading(true);
	var croppedCanvas = $("#canvas-portrait").cropper('getCroppedCanvas');
	var canvaURL = croppedCanvas.toDataURL();
	a = {
	        image: canvaURL,
	        start: xStaffId,
	        email: xEmail,
	        faceId: xFaceId,
	        photoId: xPhotoId	        
	    };
	
    $.ajax({
        'async' : false,
		'global' : false,
		headers : {
			'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
		},
		type: "POST",
		action : 'xhttp',
        url: window.contextPath + "/mcVerifyAttendance?quality",
        data: a
    }).done(function(a) {
    	
    	var img =  new Image();
		img.src = canvaURL;
		img.height = "300";
		$('#video').hide();
		$('#canvas-portrait').cropper('destroy')
		$("#canvas-portrait").hide();
		$("#canvas-preview").show();
		$("#canvas-preview").html(img);
		//$("#btnIcao").show();
		$("#icaoCriteria").show();    	
		$("#faceDetected").attr("disabled", "disabled");
		$("#singleFace").attr("disabled", "disabled");
		$("#focus").attr("disabled", "disabled");
		
		checkIcao();
		
    	/*if(a.result == 'pass') {
    		checkIcao();
    		//$("#btnCrop").html("Image Quality <i class='fa fa-check-circle' aria-hidden='true' style='color:#4caf50;'></i>")
    		var img =  new Image();
    		img.src = canvaURL;
    		img.height = "300";
    		$('#video').hide();
    		$('#canvas-portrait').cropper('destroy')
    		$("#canvas-portrait").hide();
    		$("#canvas-preview").show();
    		$("#canvas-preview").html(img);
    		//$("#btnIcao").show();
    		//$("#icaoCriteria").show();    	
    		$("#faceDetected").attr("disabled", "disabled");
    		$("#singleFace").attr("disabled", "disabled");
    		$("#focus").attr("disabled", "disabled");
    		//$('#captureMsg').html('Select ICAO Criteria below and click Check ICAO button.');
    		
    		
    	} else {
    		//$("#btnCrop").html("Image Quality <i class='fa fa-times-circle' aria-hidden='true' style='color:#dc3545;'></i>")
    		//$('#captureMsg').html(defaultCaptureMsg);
    	}
    	$("#btnCrop").prop('disabled', true);*/
    	portalUtil.showMainLoading(false);
    })/*.fail(function() {
    	reset();
        $.messager.alert("Error", "Face detection error", "error")
        portalUtil.showMainLoading(false);
    })*/
    
}

function checkIcao() {
	//debugger;
	portalUtil.showMainLoading(true);
	var img = $("#canvas-preview > img");
	var features = [];
	
    $('.icaoCriteria:checkbox:checked').each(function() {
    	features.push($(this).attr('id'));
    });
    
	var src = img[0].src.replace('data:image/png;base64,', '');
	$("#imageLv").val(src);
	a = {
	        image: src,
	        start: xStaffId,
	        email: xEmail,
	        faceId: xFaceId,
	        photoId: xPhotoId,
	        icaoCriteria: features.join(',')
	    };
    $.ajax({
		'global' : false,
		headers : {
			'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
		},
		type: "POST",
		action : 'xhttp',
        url: window.contextPath + "/mcVerifyAttendance?icao",
        data: a
    }).done(function(a) {
    	enrollFaceId();
    	/*icaoResult(a.singleFace, $("#singleFace"));
		icaoResult(a.faceDetected, $("#faceDetected"));
		icaoResult(a.imageInterpolated, $("#imageInterpolated"));
		icaoResult(a.constraintsFullFrontal, $("#constraintsFullFrontal"));
		icaoResult(a.constraintsPassport, $("#constraintsPassport"));
		icaoResult(a.resolution, $("#resolution"));
		icaoResult(a.pose, $("#pose"));
		icaoResult(a.gazeFrontal, $("#gazeFrontal"));
		icaoResult(a.mouthClosed, $("#mouthClosed"));
		icaoResult(a.nonOccluded, $("#nonOccluded"));
		icaoResult(a.background, $("#background"));
		icaoResult(a.focus, $("#focus"));
		icaoResult(a.faceShadow, $("#faceShadow"));
		icaoResult(a.notHotspots, $("#notHotspots"));
		icaoResult(a.exposure, $("#exposure"));
		icaoResult(a.expressionNeutral, $("#expressionNeutral"));
		icaoResult(a.eyesOpen, $("#eyesOpen"));
		icaoResult(a.colour, $("#colour"));
		icaoResult(a.noReflections, $("#noReflections"));
		icaoResult(a.noGlasses, $("#noGlasses"));
		$(".icaoCriteria").attr("disabled", "disabled");
    	$("#btnIcao").prop('disabled', true);
    	*/
    	
    	/*if(a.result == 'pass') {
    		//$("#btnIcao").html("ICAO Passed <i class='fa fa-check-circle' aria-hidden='true' style='color:#4caf50;'></i>")
    		//$("#btnCamvi").show();
    		//$('#captureMsg').html('Click Finish to save the photo for Face verification.');
    		
    		//enrollFaceId();
    	} else {
    		//$("#btnIcao").html("ICAO Failed <i class='fa fa-times-circle' aria-hidden='true' style='color:#dc3545;'></i>")
    		$("#btnCamvi").hide();
    		$('#captureMsg').html(defaultCaptureMsg);
    	}
    	icaoResult(a.singleFace, $("#singleFace"));
		icaoResult(a.faceDetected, $("#faceDetected"));
		icaoResult(a.imageInterpolated, $("#imageInterpolated"));
		icaoResult(a.constraintsFullFrontal, $("#constraintsFullFrontal"));
		icaoResult(a.constraintsPassport, $("#constraintsPassport"));
		icaoResult(a.resolution, $("#resolution"));
		icaoResult(a.pose, $("#pose"));
		icaoResult(a.gazeFrontal, $("#gazeFrontal"));
		icaoResult(a.mouthClosed, $("#mouthClosed"));
		icaoResult(a.nonOccluded, $("#nonOccluded"));
		icaoResult(a.background, $("#background"));
		icaoResult(a.focus, $("#focus"));
		icaoResult(a.faceShadow, $("#faceShadow"));
		icaoResult(a.notHotspots, $("#notHotspots"));
		icaoResult(a.exposure, $("#exposure"));
		icaoResult(a.expressionNeutral, $("#expressionNeutral"));
		icaoResult(a.eyesOpen, $("#eyesOpen"));
		icaoResult(a.colour, $("#colour"));
		icaoResult(a.noReflections, $("#noReflections"));
		icaoResult(a.noGlasses, $("#noGlasses"));
		$(".icaoCriteria").attr("disabled", "disabled");
    	$("#btnIcao").prop('disabled', true);*/
    	portalUtil.showMainLoading(false);
    })/*.fail(function() {
    	reset();
        $.messager.alert("Error", "Face detection error", "error")
        portalUtil.showMainLoading(false);
    })*/
   // enrollFaceId();
}

function icaoResult(res, eCheck) {
	var element = eCheck.siblings('.label-text');
	if(res) { 
		eCheck.attr("checked", "checked");
		element[0].classList.add("green")
	} else {
		element[0].classList.add("red")
	}
}

function enrollFaceId() {
	//debugger;
	portalUtil.showMainLoading(true);
	var result;
	var img = $("#canvas-preview > img");
	var src = img[0].src.replace('data:image/png;base64,', '')
	
	a = {
	        image: src,
	        start: xStaffId,
	        staffId: xStaffId,
	        email: xEmail,
	        faceId: xFaceId,
	        photoId: xPhotoId
	    };
    $.ajax({
        'async' : false,
		'global' : false,
		headers : {
			'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
		},
		type: "POST",
		action : 'xhttp',
        url: window.contextPath + "/mcVerifyAttendance?enroll",
        data: a
    }).done(function(a) {
		$('#verifyPhotoId .btnSubmitFinal').trigger('click');
    	if(a.personId != null) {
    		//$("#btnCamvi").html("Completed <i class='fa fa-check-circle' aria-hidden='true' style='color:#4caf50;'></i>")
    		//$("#btnCamvi").show();
    		
    		console.log($('#verifyPhotoId'));
    		
    		$('#verifyPhotoId .btnSubmitFinal').trigger('click');
    		result = true;
    	} else {
    		$("#btnCamvi").html("Registration Failed <i class='fa fa-times-circle' aria-hidden='true' style='color:#dc3545;'></i>")
    		$("#btnCamvi").hide();
    	}
    	$("#btnCamvi").prop('disabled', true);
    	portalUtil.showMainLoading(false);
    }).fail(function() {
    	reset();
        $.messager.alert("Error", "Face detection error", "error");
        portalUtil.showMainLoading(false);
    })
    //debugger;
    if(result) {
    	var faceIds = document.getElementById("faceIds");
    	faceIds.src = faceIds.src + "?hash=" + new Date().getTime();
    	/*$('#captureMsg').html('Photo is successfully saved. ' + defaultCaptureMsg);
	    portalUtil.showSuccess("Photo successfully saved", function() {
	    	var path = window.location.pathname
	    	console.log(path)
	    	if(contextPath || contextPath != "") {
	    		console.log("context is here")
	    		path = window.location.pathname.split("/");
		    	path.splice(0,2)
		    	path = path.join("/")
		    	redirectURL("/" + path + "?next=photo");

	    	} 
	    	redirectURL( path + "?next=photo");
	    });*/
    }
    console.log($('#verifyPhotoId'));
//    $('#verifyPhotoId').append()
//    $('#verifyPhotoId').submit();
	//$('#verifyPhotoId .btnSubmitFinal').trigger('click');
}

function reset() {
	$('#canvas-portrait').hide();
	$('#canvas-portrait').cropper('destroy')
	$('#btnCapture').hide();
	$('#btnStop').hide();
	capturePID = 0;
	captureName = "";
	numCapture = 0;
	var cropTitle = $('#btnCrop').attr('title');
	$('#btnCrop').text(cropTitle);
	$('#btnCrop').removeAttr('disabled');
	$('#btnCrop').hide();
	var icaoTitle = $('#btnIcao').attr('title');
	$('#btnIcao').text(icaoTitle);
	$('#btnIcao').removeAttr('disabled');
	$('#btnIcao').hide();
	var camviTitle = $('#btnCamvi').attr('title');
	$('#btnCamvi').text(camviTitle);
	$('#btnCamvi').removeAttr('disabled');
	$('#btnCamvi').hide();
	$('.icaoCriteria').each(function() {
		var element = $(this).siblings('.label-text');
		element[0].classList.remove("green");
		element[0].classList.remove("red");
		$(this).removeAttr('checked');
		$(this).removeAttr("disabled");
	});
	$('#singleFace').attr('checked','checked');
	$('#constraintsFullFrontal').attr('checked','checked');
	$('#background').attr('checked','checked');
	$('#focus').attr('checked','checked');
	$('#faceDetected').attr('checked','checked');
	$('#icaoCriteria').hide();	
	$('#btnUpload').show();
	$('#captureMsg').html(defaultCaptureMsg);
}


$(function ($) {
    var video;
    // var localstream;
    // var cropper;
    var onVideoLoad = false;

    $.fn.cropperImage = function (options) {
    	var mainThis = this;
        var parent = null;
        var cropper = null;
        var varcroppedImageDataURL = null;
        var localstream;

        var settings = $.extend({
        	altImage: null,
            // These are the defaults.
            maxWidth: "200px",
            maxWidthAction: null,
            heightSource: "300px",
            padding: "10px",
            aspectRatio: 3 / 4,
            fit: 0,
            // autoCropArea: 0,
            defaultImage: '',
            checkIcaoCriteria: true,
            enrollService: true,
            hideUpload: false,
            hideCamera: false,
            pathDocumentView: null,
            icaoFeatures: [
            	{key: "singleFace",text: "Single Face"},
            	{key: "faceDetected",text: "Face Detected"},
            	{key: "focus",text: "Focus"}
            ],
            btnUploadImageClass: 'btnUploadImage',
            btnCropImageClass: 'btnCropImage',
            btnSnapVideoClass: 'btnSnapVideo',
            btnEnableVideoClass: 'btnEnableVideo',
            btnDisableVideoClass: 'btnDisableVideo',
            messageBoxClass: 'cropperImage-action-text',
            messages : {
            	defaultMsg: 'Click <i class="fa fa-upload" aria-hidden="true"></i> to upload an image or <i class="fa fa-play" aria-hidden="true"></i> to start the camera.',
            	qualityErrorMsg: 'Quality failed!',
            	icaoErrorMsg: 'ICAO failed!',
            	successMsg: 'Success upload',
            	failMsg: 'Failed Upload',
            	icaoSuccessMsg: 'Icao checking success!',
            },
            showDefaultBase64: false,
            
        }, options);
        
        console.log(settings);
        
//
//		console.log(settings.icaoFeatures.map(a=>a.key));
//        
//     // Now it can be used reliably with $.map()
//    	var icaoFeaturesArray = $.map( settings.icaoFeatures, function( val, i ) {
//    	  // Do something
////    		return va
//    		console.log(i,val.key);
//    	});
//    	
        
        settings.pathDocumentView = this.attr("file-path");
        settings.params = {
    		start: this.data("trvlid"),
	        email: this.data("email"),
	        faceId: this.data("faceid"),
	        photoId: this.data("photoid")
        };
        
        buildTemplate();

        
        
        function buildTemplate() {
//        	console.log(mainThis);
        	
			var mainTempLayout = $('<div/>').addClass("cropperImage-layout rounded");
			var mainTempSourceLayout = $('<div/>').addClass("cropperImage-source-layout border");
			mainTempSourceLayout.append($("<div/>").addClass("col-source"));
			mainTempSourceLayout.find('.col-source').append(
					$("<div/>").addClass("cropperImage-source cropperImage-class-none")
					.append(
							$("<img/>").addClass("cropperImage-source-image cropperImage-class-none")
					).append(
							$("<video/>").addClass("cropperImage-source-video cropperImage-class-none")
							.html("Your browser does not support the video tag.")
					)
			);
			
			var photoIdSrc = settings.showDefaultBase64==true 
				?  settings.params.photoId!=null ? settings.params.photoId : null
				:  settings.params.photoId!=null ? settings.pathDocumentView+settings.params.photoId : null
			
			mainTempSourceLayout.find('.col-source').append(
					$("<div/>").addClass("cropperImage-ouput")
					.append(
							$("<img/>").addClass("cropperImage-output-image")
							.attr("border",0).css("background","white")
							.css("border",0).css("text-decoration","none").css("outline","none")
							.attr("src",photoIdSrc)
					)
			);
			
			var mainTempActionLayout = $('<div/>').addClass("cropperImage-action-layout border");
//			mainTempActionLayout.append($("<div/>").addClass("col-source cropperImage-action pb-1 text-center"));
//
//			mainTempActionLayout.find('.col-source').append(
//					$("<input/>").addClass("cropperImage-class-none").attr("id","fileInput").attr("type","file").attr("accept","image/*")
//			);
//			
//			if(!settings.hideUpload){
//				mainTempActionLayout.find('.col-source').append(
//						$("<bst:btn-sm-error/>").addClass("text-center btnUploadImage").attr("type","button")
//						.append(
//							$("<em/>").addClass("btnIconInitial fa fa-upload").attr("aria-hidden",true)
//						)
//				);
//			}
//			
//			mainTempActionLayout.find('.col-source').append(
//					$("<bst:btn-sm-error/>").addClass("btnIconInitialOuter text-center btnCropImage cropperImage-class-none").attr("type","button")
//					.html("Verify")
//			);
//			mainTempActionLayout.find('.col-source').append(
//					$("<bst:btn-sm-error/>").addClass("text-center btnSnapVideo cropperImage-class-none").attr("type","button")
//					.append(
//						$("<em/>").addClass("btnIconInitial fa fa-camera").attr("aria-hidden",true)
//					)
//			);
//			
//
//			if(!settings.hideCamera){
//				mainTempActionLayout.find('.col-source').append(
//						$("<bst:btn-sm-error/>").addClass("text-center btnEnableVideo").attr("type","button")
//						.append(
//							$("<em/>").addClass("btnIconInitial fa fa-play").attr("aria-hidden",true)
//						)
//				);
//			}
//			mainTempActionLayout.find('.col-source').append(
//					$("<bst:btn-sm-error/>").addClass("text-center btnDisableVideo cropperImage-class-none").attr("type","button")
//					.append(
//						$("<em/>").addClass("btnIconInitial fa fa-stop").attr("aria-hidden",true)
//					)
//			);
//			
//			mainTempActionLayout.append($("<div/>").addClass("col-source cropperImage-action-text pt-1 text-center"));
			mainTempActionLayout.append($("<div/>").addClass("row"));
			var mainTempActionLayoutRow = mainTempActionLayout.find('.row');
			
			mainTempActionLayoutRow.append($("<div/>").addClass("col col-left"));
			
			var mainTempActionLayoutColLeft = mainTempActionLayoutRow.find('.col-left');
			
			if(settings.altImage!=null)
			{
				mainTempActionLayoutRow.append($("<div/>").addClass("col-md-auto col-right d-flex align-items-center justify-content-center"));
				var mainTempActionLayoutColRight = mainTempActionLayoutRow.find('.col-right');
				
//				setup altImage
				mainTempActionLayoutColRight.append($("<img/>").addClass('p-2').attr('src',settings.altImage).css('height','90px'));
			}
			
			mainTempActionLayoutColLeft.append($("<div/>").addClass("col-source cropperImage-action pb-1 text-center"));

			mainTempActionLayoutColLeft.find('.col-source').append(
					$("<input/>").addClass("cropperImage-class-none").attr("id","fileInput").attr("type","file").attr("accept","image/*")
			);
			
			if(!settings.hideUpload){
				mainTempActionLayoutColLeft.find('.col-source').append(
						$("<bst:btn-sm-error/>").addClass("text-center btnUploadImage").attr("type","button")
						.append(
							$("<em/>").addClass("btnIconInitial fa fa-upload").attr("aria-hidden",true)
						)
				);
			}
			
			mainTempActionLayoutColLeft.find('.col-source').append(
					$("<bst:btn-sm-error/>").addClass("btnIconInitialOuter text-center btnCropImage cropperImage-class-none").attr("type","button")
					.html("Crop &amp; Save")
			);
			

			mainTempActionLayoutColLeft.find('.col-source').append(
						$("<bst:btn-sm-error/>").addClass("text-center btnSnapVideo cropperImage-class-none").attr("type","button")
						.append(
							$("<em/>").addClass("btnIconInitial fa fa-camera").attr("aria-hidden",true)
						)
				);

			if(!settings.hideCamera){
				mainTempActionLayoutColLeft.find('.col-source').append(
						$("<bst:btn-sm-error/>").addClass("text-center btnEnableVideo").attr("type","button")
						.append(
							$("<em/>").addClass("btnIconInitial fa fa-play").attr("aria-hidden",true)
						)
				);
			}
			
			mainTempActionLayoutColLeft.find('.col-source').append(
					$("<bst:btn-sm-error/>").addClass("text-center btnDisableVideo cropperImage-class-none").attr("type","button")
					.append(
						$("<em/>").addClass("btnIconInitial fa fa-stop").attr("aria-hidden",true)
					)
			);
			
			mainTempActionLayoutColLeft.append($("<div/>").addClass("col-source cropperImage-action-text pt-1 text-center"));

			
			mainTempLayout.append(mainTempSourceLayout);
			mainTempLayout.append(mainTempActionLayout);
			mainThis.append(mainTempLayout);
			
			parent = mainThis.find(".cropperImage-layout");
			
			mainThis.find('.col-source').css('max-width', settings.maxWidth);
			mainThis.find('.col-source.cropperImage-action').css('max-width', settings.maxWidthAction != null ? settings.maxWidthAction : '100%');
			mainThis.find('.col-source.cropperImage-action-text').css('max-width', settings.maxWidthAction != null ? settings.maxWidthAction : '100%');
			mainThis.find('.cropperImage-source-layout')
	            .css('height', settings.heightSource);
	        // parent.find('.cropperImage-ouput')
	        //     .css('height', settings.heightSource);
			mainThis.find('.cropperImage-source-layout .col-source')
	            .css('padding', settings.padding);
			mainThis.find('.cropperImage-action-layout .col-source')
	            .css('padding', settings.padding);
			mainThis.find('.cropperImage-ouput').css('background-image',settings.params.photoId==null ? 'url('+settings.defaultImage+')' : null);
	        
	        if(settings.checkIcaoCriteria){
//	        	var parentDiv = $("<div/>").addClass("cropperImage-criteria-icao cropperImage-class-none text-center border rounded");
//	        	
//	        	$.each(settings.icaoFeatures,function(index,value){
//	        		var divT = $("<span/>").css('display','inline-block').css('margin','0 10px');
//	        		divT.append($("<label/>").val(value).addClass("cropperImage-criteria-icao-input data-"+value.key));
//	        		divT.append($('<p/>').html(value.text).css('font-size','12px'));
//	        		parentDiv.append(divT);
//	        	});
//	        	
//	        	mainThis.append(parentDiv);
	        	var parentDiv = $("<div/>").addClass("position-relative cropperImage-criteria-icao cropperImage-class-none text-center border rounded");
	        	
	        	parentDiv.append($("<span/>").addClass("cropperImage-criteria-icao-text cropperImage-class-none success").append($("<i/>").addClass("fa fa-check text-success")).append("All ICAO face checking criteria PASS"));
	        	parentDiv.append($("<span/>").addClass("cropperImage-criteria-icao-text cropperImage-class-none failed text-danger").append($("<i/>").addClass("fa fa-exclamation-circle")).append("View ICAO Checking"));
	        	var layoutCriteria = $("<div/>").addClass("position-absolute text-left col-12 cropperImage-criteria-icao-card cropperImage-class-none").append($("<div/>").addClass("row p-1"));
//	        	layoutCriteria = ;
	        	$.each(settings.icaoFeatures,function(index,value){
	        		var divT = $("<p/>").addClass('col-4').addClass("col cropperImage-criteria-icao-input data-"+value.key).html(value.text);
//	        		var divT = $("<span/>").addClass('col-4')
//	        		.css('display','inline-block')
//	        		.css('padding-right','8px')
//	        		.css('padding-left','22px')
//	        		.css('margin','0 0')
////	        		.append($('<span/>').addClass('row'));
//	        		.append($("<p/>").addClass("col cropperImage-criteria-icao-input data-"+value.key).html(value.text));
//	        		divT.find('span.row').append($("<p/>").addClass("col cropperImage-criteria-icao-input data-"+value.key).html(value.text));
//	        		divT.find('span.row').append($('<p/>').addClass('col-auto').html(value.text).css('font-size','12px'));
	        		layoutCriteria.find("div").append(divT);
	        	});
	        	
	        	parentDiv.append(layoutCriteria);
	        	
	        	mainThis.append(parentDiv);
	        }
		}

        function calculateSizeKbBase64String(base64) {
            var stringLength = base64.length - 'data:image/png;base64,'.length;
            var sizeInBytes = 4 * Math.ceil((stringLength / 3)) * 0.5624896334383812;
            return sizeInBytes / 1024;
        }

        // setup display crop / show image
        function setupShowImage(base64) {
            parent.find(".cropperImage-source-image").addClass("cropperImage-class-none");
            parent.find(".cropperImage-source-video").addClass("cropperImage-class-none");
            parent.find(".cropperImage-source").addClass("cropperImage-class-none");

            parent.find(".cropperImage-ouput").removeClass("cropperImage-class-none");
            parent.find(".cropperImage-ouput").css('background-image', 'none');
            
            console.log("parent",parent.find(".cropperImage-ouput"));
            parent.find('.cropperImage-ouput').css('background-image',base64==null ? 'url('+settings.defaultImage+')' : null);
	        


            cropper.cropper('reset');
            cropper.cropper('clear');
            cropper.cropper('destroy');
            // cropper.cropper('replace', null);

            parent.find(".cropperImage-ouput .cropperImage-output-image").attr("src", base64);
            options.base64.call({base64:base64});

            settings.params = {
            	image: base64,
            	start: settings.params.start,
    	        email: settings.params.email,
    	        faceId: settings.params.faceId,
    	        photoId: settings.params.photoId
            };
            checkQuality();
            // showImageAfterCrop();
        }

        function checkQuality() {
        	

        	var features = settings.checkIcaoCriteria ? settings.icaoFeatures.map(a=>a.key) : [];
    		$.each(features,function(index,value){
    			mainThis.find('.cropperImage-criteria-icao-input.data-'+value).removeClass("ticked failed");
    			
    		});
//        	settings.params.image = base64;

            options.response.call({status:1});

        	
        	$.ajax({
    			'global' : false,
    			headers : {
    				'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
    			},
    			type: "POST",
    			action : 'xhttp',
    	        url: settings.urlQualityCheck,
    	        data: settings.params
    	    }).done(function(a) {
    	    	if(a.result == 'pass') {

    	        	if(!settings.checkIcaoCriteria){
    	        		options.callback.call(a);
    	        		return;
    	        	}
    	    		
//    	    		enrollId(0,enroll);
    	    		checkIcao();
    	    	} else {

    	            options.response.call({status:0});
    	    		parent.find("."+settings.messageBoxClass).html(settings.messages.qualityErrorMsg);
//    	    		//$(enroll).find("#btnIcao").html("Failed Upload <i class='fa fa-times-circle' aria-hidden='true' style='color:#dc3545;'></i>")
//    	    		$(enroll).find("#btnCamvi").hide();
//    	    		$(enroll).find('#captureMsg').html(defaultCaptureMsgQualityCheck);
    	    	}
    	    	
    	    }).fail(function() {
	            options.response.call({status:0});
	    		parent.find("."+settings.messageBoxClass).html(settings.messages.qualityErrorMsg);
    	    })
		}

        function checkIcao() {
        	
        	// Now it can be used reliably with $.map()
        	var icaoFeaturesArray = $.map( settings.icaoFeatures, function( val, i ) {
        	  // Do something
//        		return va
        	});
        	
        	var features = settings.checkIcaoCriteria ? settings.icaoFeatures.map(a=>a.key) : [];
    		
//    		console.log("find",parent.find('.cropperImage-criteria-icao'));
    		
    		mainThis.find('.cropperImage-criteria-icao').removeClass('cropperImage-class-none')
    		

            settings.params = {
            	image: settings.params.image.replace('data:image/png;base64,', ''),
            	start: settings.params.start,
    	        email: settings.params.email,
    	        faceId: settings.params.faceId,
    	        photoId: settings.params.photoId,
		        icaoCriteria: features.join(',')
            };
            
    	    
    		
        	$.ajax({
    			'global' : false,
    			headers : {
    				'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
    			},
    			type: "POST",
    			action : 'xhttp',
    	        url: settings.urlIcaoCheck,
    	        data: settings.params
    	    }).done(function(a) {
	    		$.each(features,function(index,value){
	    			mainThis.find('.cropperImage-criteria-icao-input.data-'+value).removeClass("ticked failed");
//	    			console.log(value,a,a[value],parent.find('.cropperImage-criteria-icao-input[value='+value+']'));
	    			if(a[value]==true){
	    				mainThis.find('.cropperImage-criteria-icao-input.data-'+value).addClass("ticked");
	    			}
	    			else{
	    				mainThis.find('.cropperImage-criteria-icao-input.data-'+value).addClass("failed");
	    			}
	    		});
	    		mainThis.find('.cropperImage-criteria-icao').removeClass('cropperImage-class-none');
	    		mainThis.find('.cropperImage-criteria-icao-text').addClass('cropperImage-class-none');
	    		
    	    	if(a.result == 'pass') {
//    	    		enrollId(0,enroll);
    	    		mainThis.find('.cropperImage-criteria-icao-text.success').removeClass('cropperImage-class-none');


    	        	if(!settings.enrollService){
        	    		parent.find("."+settings.messageBoxClass).html(settings.messages.icaoSuccessMsg);
        	    		console.log(parent.find("."+settings.messageBoxClass),settings.messages.icaoSuccessMsg);
    		            options.response.call({status:0});
    	        		options.callback.call(a);
    	        		return;
    	        	}
    	    		
    	    		checkEnroll();
    	    	} else {
    	    		mainThis.find('.cropperImage-criteria-icao-text.failed').removeClass('cropperImage-class-none');


    	            options.response.call({status:0});
    	    		parent.find("."+settings.messageBoxClass).html(settings.messages.icaoErrorMsg);
//    	    		//$(enroll).find("#btnIcao").html("Failed Upload <i class='fa fa-times-circle' aria-hidden='true' style='color:#dc3545;'></i>")
//    	    		$(enroll).find("#btnCamvi").hide();
//    	    		$(enroll).find('#captureMsg').html(defaultCaptureMsgQualityCheck);
    	    	}
    	    	
    	    }).fail(function() {
	            options.response.call({status:0});
	    		parent.find("."+settings.messageBoxClass).html(settings.messages.icaoErrorMsg);
    	    })
		}

        function checkEnroll(a) {
        	


        	
        	$.ajax({
    			'global' : false,
    			headers : {
    				'X-CSRF-Token' : $("meta[name='_csrf']").attr("content")
    			},
    			type: "POST",
    			action : 'xhttp',
    	        url: settings.urlEnrollCheck,
    	        data: settings.params
    	    }).done(function(a) {
	    		parent.find("."+settings.messageBoxClass).html(settings.messages.successMsg);
                options.callback.call(a);
	            options.response.call({status:0});
    	    }).fail(function() {

	            options.response.call({status:0});
	    		parent.find("."+settings.messageBoxClass).html(settings.messages.failMsg);
                
    	    });
		}

        function createCropImage() {
            varcroppedImageDataURL = cropper
                .cropper('getCroppedCanvas', {
                    // width: 200,
                    // height: 400,
                    imageSmoothingEnabled: true,
                    imageSmoothingQuality: "high",
                })
                .toDataURL();

            // console.log(varcroppedImageDataURL);
            scaleSourceForShow(varcroppedImageDataURL);
        }

        function scaleSourceForShow(base64) {

            var img = document.createElement('img');

            // When the event "onload" is triggered we can resize the image.
            img.onload = function () {
                // We create a canvas and get its context.
                var canvas = document.createElement('canvas');
                var ctx = canvas.getContext('2d');

                var scale = 1;
                var scaleWidth, scaleHeight;

                if (this.width > 1000 || this.height > 1000) {
                    if (1000 / this.width < scale) {
                        scale = 1000 / this.width;

                    }
                    if (1000 / this.height < scale) {
                        scale = 1000 / this.height;
                    }
                }

                scaleWidth = img.width * scale;
                scaleHeight = img.height * scale;

                // We set the dimensions at the wanted size.
                canvas.width = scaleWidth;
                canvas.height = scaleHeight;

                // We resize the image with the canvas method drawImage();
                ctx.drawImage(this, 0, 0, scaleWidth, scaleHeight);

                var dataURI = canvas.toDataURL();

                parent.find('.'+settings.btnCropImageClass).addClass("cropperImage-class-none");
                parent.find('.'+settings.btnDisableVideoClass).addClass("cropperImage-class-none");
                parent.find('.'+settings.btnEnableVideoClass).addClass("cropperImage-class-none");
                parent.find('.'+settings.btnSnapVideoClass).addClass("cropperImage-class-none");

                parent.find('.'+settings.btnEnableVideoClass).removeClass("cropperImage-class-none");
                parent.find('.'+settings.btnUploadImageClass).removeClass("cropperImage-class-none");
                setupShowImage(canvas.toDataURL());

            };
            img.src = base64;
        }



        function initiateCropper() {
            cropper = parent.find('.cropperImage-source-image').cropper({
                aspectRatio: options.aspectRatio,
                dragMode: "move",
                cropBoxMovable: false,
                cropBoxResizable: false,
//                viewMode: 3,
                autoCropArea: 1,
                viewMode: settings.fit,
//                minCropBoxWidth: mainThis.width(),
//                minCropBoxHeight: mainThis.height(),
            });
        }

        function stopVideo(){
            if(video!=null){
                
                video.pause();
                localstream.getTracks()[0].stop();
            }
        }

        function startVideo() {
            var videoSource = parent.find(".col-source .cropperImage-source-video");
            var constraints = { audio: false, video: true }; 

            
            var constraints = {
                audio: false, video: {aspectRatio: options.aspectRatio},
                // width: { min: 440, ideal: 1080, max: 1080 },
                // height: { min: 700, ideal: 1920 },
                // aspectRatio: 0.777777778,
                frameRate: { max: 60 },
                facingMode: { exact: "user" }
            };

            navigator.mediaDevices.getUserMedia(constraints)
            .then(function(mediaStream) {
                    try {

                
                parent.find('.'+settings.btnUploadImageClass).addClass("cropperImage-class-none");
                parent.find('.'+settings.btnSnapVideoClass).removeClass("cropperImage-class-none");
                parent.find('.'+settings.btnEnableVideoClass).addClass("cropperImage-class-none");
                parent.find('.'+settings.btnDisableVideoClass).removeClass("cropperImage-class-none");
                
                localstream = mediaStream;
                video = parent.find(".col-source .cropperImage-source-video").show()[0];
                video.srcObject = mediaStream;
                video.onloadedmetadata = function() {
                if(video) video.play();
                parent.find(".col-source .cropperImage-source").removeClass("cropperImage-class-none");
                videoSource.removeClass("cropperImage-class-none");
                parent.find(".col-source .cropperImage-ouput").addClass("cropperImage-class-none");

            };
                    } catch (error) {
                        
                    }
                localstream = mediaStream;
            }).catch(function(err) {
            
            console.log(err.name + ": " + err.message); 
            });
            
        }

        function initiateFileReader() {
            parent.find("#fileInput").on("change", function () {
                var file = $(this);
                if (this.files && this.files[0]) {
                    if (this.files[0].type.match(/^image\//)) {
                        var reader = new FileReader();
                        reader.onload = function (evt) {
                            setupNewImageCropLayout(evt.target.result);
                            file.val("");
                        };
                        reader.readAsDataURL(this.files[0]);
                    } else {
                        alert("Invalid file type! Please select an image file.");
                    }
                } else {
                    alert("No file(s) selected.");
                }
            });
        }

         // Capture video frame
         function captureVideo() {
            var canvas = document.createElement("canvas");
            videoLayout = parent.find(".capture #videoSource").get(0);
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;

            canvas.getContext("2d").drawImage(video, 0, 0, canvas.width, canvas.height);
            // stopVideo();
            stopVideo();
            setupNewImageCropLayout(canvas.toDataURL());
        }


        // setup crop source image / replace
        function setupNewImageCropLayout(base64) {
            initiateCropper();
            cropper.cropper('reset');
            cropper.cropper('clear');
            
            parent.find(".cropperImage-source-video").addClass("cropperImage-class-none");
            parent.find(".cropperImage-ouput").addClass("cropperImage-class-none");
            parent.find(".cropperImage-source").removeClass("cropperImage-class-none");
            parent.find('.'+settings.btnSnapVideoClass).addClass("cropperImage-class-none");
            parent.find('.'+settings.btnDisableVideoClass).addClass("cropperImage-class-none");
            parent.find('.'+settings.btnEnableVideoClass).addClass("cropperImage-class-none");

            
            parent.find('.'+settings.btnCropImageClass).removeClass("cropperImage-class-none");

            cropper.cropper('replace', base64);
        }
        
        function defaultStatus(){
        	parent.find('.'+settings.btnDisableVideoClass).addClass("cropperImage-class-none");
            parent.find(".cropperImage-source").addClass("cropperImage-class-none");
            parent.find(".cropperImage-source-video").addClass("cropperImage-class-none");
            parent.find(".cropperImage-ouput").removeClass("cropperImage-class-none"); 
            parent.find('.'+settings.btnUploadImageClass).removeClass("cropperImage-class-none");
        	parent.find('.'+settings.btnEnableVideoClass).removeClass("cropperImage-class-none");
        	parent.find('.'+settings.btnSnapVideoClass).addClass("cropperImage-class-none");
        	parent.find('.cropperImage-action-text').html(settings.messages.defaultMsg);
//        	defaultCaptureMsg
        }

        // initiateCropper();
        initiateFileReader();
        defaultStatus();

        $(parent).on("click", "."+settings.btnCropImageClass, function () {
            createCropImage();
            // showCrop(false);
        });

        $(parent).on("click", "."+settings.btnUploadImageClass, function () {
            $(parent).find("#fileInput").click();
        });

        $(parent).on("click", "."+settings.btnEnableVideoClass, function () {
            startVideo();
        });

        $(parent).on("click", "."+settings.btnSnapVideoClass, function () {
            captureVideo();
        });

        $(parent).on("click", "."+settings.btnDisableVideoClass, function () {
            stopVideo();
            defaultStatus();
        });
    }
}( jQuery ));