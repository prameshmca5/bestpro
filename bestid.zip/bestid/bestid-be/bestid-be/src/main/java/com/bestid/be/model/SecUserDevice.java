/**
 *
 */
package com.bestid.be.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author roziana
 * @since Nov 19, 2018
 */
@Entity
@Table(name = "SEC_USER_DEVICE")
public class SecUserDevice implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -5704861532471388589L;

	@Id
	@Column(name = "DEVICE_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer deviceId;

	@Column(name = "USERNAME")
	private String userName;

	@Column(name = "USER_ID")
	private int userId;

	@Column(name = "MACHINE_ID")
	private String machineId;

	@Column(name = "SDK_VERSION")
	private String sdkVersion;

	@Column(name = "MODEL")
	private String model;

	@Column(name = "BRAND")
	private String brand;

	@Column(name = "MANUFACTURER")
	private String manufacturer;

	@Column(name = "GEO_LOCATION")
	private String geoLocation;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "CERT_STATUS")
	private String certStatus;

	@Column(name = "IS_CERT_INSTALL")
	private String isCertInstall;

	@Column(name = "MOBILE_NO")
	private String mobileNo;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "UUID")
	private String uuid;

	@Column(name = "UUID_EXPIRED_DT")
	private Timestamp uuidExpDt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getDeviceId() {
		return deviceId;
	}


	public void setDeviceId(Integer deviceId) {
		this.deviceId = deviceId;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getMachineId() {
		return machineId;
	}


	public void setMachineId(String machineId) {
		this.machineId = machineId;
	}


	public String getSdkVersion() {
		return sdkVersion;
	}


	public void setSdkVersion(String sdkVersion) {
		this.sdkVersion = sdkVersion;
	}


	public String getModel() {
		return model;
	}


	public void setModel(String model) {
		this.model = model;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getManufacturer() {
		return manufacturer;
	}


	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}


	public String getGeoLocation() {
		return geoLocation;
	}


	public void setGeoLocation(String geoLocation) {
		this.geoLocation = geoLocation;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getCertStatus() {
		return certStatus;
	}


	public void setCertStatus(String certStatus) {
		this.certStatus = certStatus;
	}


	public String getIsCertInstall() {
		return isCertInstall;
	}


	public void setIsCertInstall(String isCertInstall) {
		this.isCertInstall = isCertInstall;
	}


	public String getUuid() {
		return uuid;
	}


	public void setUuid(String uuid) {
		this.uuid = uuid;
	}


	public Timestamp getUuidExpDt() {
		return uuidExpDt;
	}


	public void setUuidExpDt(Timestamp uuidExpDt) {
		this.uuidExpDt = uuidExpDt;
	}

}
