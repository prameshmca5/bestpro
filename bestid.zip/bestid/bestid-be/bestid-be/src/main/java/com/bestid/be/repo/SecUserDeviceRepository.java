/**
 *
 */
package com.bestid.be.repo;


import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.SecUserDevice;


/**
 * @author roziana
 * @since Nov 19, 2018
 */
@Repository
@RepositoryDefinition(domainClass = SecUserDevice.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.SEC_USER_DEVICE_REPOSITORY)
public interface SecUserDeviceRepository extends GenericRepository<SecUserDevice> {

	@Query("select u from SecUserDevice u where u.deviceId= :deviceId")
	public SecUserDevice findDeviceId(@Param("deviceId") int deviceId);


	@Query("select u from SecUserDevice u where u.userName= :userName and u.machineId= :machineId")
	public SecUserDevice findDeviceByUserMachine(@Param("userName") String userName,
			@Param("machineId") String machineId);


	@Query("select u from SecUserDevice u where u.status= :status")
	public List<SecUserDevice> findStatus(@Param("status") String status);


	@Query("select u from SecUserDevice u where u.machineId= :machineId")
	public SecUserDevice findDeviceByMachineId(@Param("machineId") String machineId);


	@Query("select u from SecUserDevice u where u.mobileNo= :mobileNo")
	public SecUserDevice findDeviceByMobileNo(@Param("mobileNo") String mobileNo);


	@Query("select u from SecUserDevice u where u.uuid= :uuid")
	public SecUserDevice findByUuid(@Param("uuid") String uuid);


	@Query("select u from SecUserDevice u where u.machineId= :machineId and u.uuid= :uuid")
	public SecUserDevice findDeviceByUidMachineId(@Param("machineId") String machineId, @Param("uuid") String uuid);


	@Query("select u from SecUserDevice u where u.userId= :userId and u.uuid= :uuid")
	public SecUserDevice findDeviceByUserIdUuid(@Param("userId") int userId, @Param("uuid") String uuid);


	@Query("select u from SecUserDevice u where u.userId= :userId and u.machineId= :machineId")
	public SecUserDevice findDeviceByUserIdMachineId(@Param("userId") int userId,
			@Param("machineId") String machineId);
}
