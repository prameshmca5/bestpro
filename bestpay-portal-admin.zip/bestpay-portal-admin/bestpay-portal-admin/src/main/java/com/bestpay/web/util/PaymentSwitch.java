/**
 * 
 */
package com.bestpay.web.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.bestpay.idm.sdk.constants.IdmUserTypeConstants;
import com.bestpay.idm.sdk.model.UserProfile;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.config.iam.CustomUserDetails;
import com.bestpay.web.core.AbstractController;

/**
 * @author Jhayne
 *
 */
public class PaymentSwitch extends AbstractController {

	@Autowired
	private MessageSource messageSource;

	public MessageSource getMessageSource() {
		return messageSource;
	}

	public String creditBal() {
		UserProfile userProfile = null;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (!BaseUtil.isObjNull(auth) && auth.isAuthenticated()) {
			CustomUserDetails cud = (CustomUserDetails) auth.getPrincipal();
			userProfile = cud.getProfile();
			if (BaseUtil.isEqualsCaseIgnore(IdmUserTypeConstants.MER, userProfile.getUserType())) {
				cud.getUserProfile();
			}
		}
		return "0.00";
	}

}