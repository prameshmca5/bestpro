/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bestpay.be.core.AbstractEntity;


/**
 * N.N. Shuhada 04 June 2018
 */
@Entity
@Table(name = "PGW_TRANSACTION")
public class PgwTransaction extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = 2259157691585213733L;

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name = "TRANID")
	private String transId;

	@Column(name = "REF_ID")
	private String refId;

	@Column(name = "CHANNEL")
	private String channel;

	@Column(name = "MERCHANTID")
	private String merchantId;

	@Column(name = "SUBMER_ID")
	private String submerId;

	@Column(name = "EXCHANGE_ID")
	private String exhangeId;

	@Column(name = "SELLER_ID")
	private String sellerId;

	@Column(name = "BILLING_NAME")
	private String billingName;

	@Column(name = "BILLING_EMAIL")
	private String billingEmail;

	@Column(name = "BILLING_MOBILE")
	private String billingMobile;

	@Column(name = "BILLING_INFO")
	private String billingInfo;

	@Column(name = "ORDER_ID")
	private String orderId;

	@Column(name = "BILL_AMT")
	private Float billAmt;

	@Column(name = "PAYMENT_DATE")
	private Timestamp paymentDt;

	@Column(name = "TRANS_AMT")
	private Float transAmt;

	@Column(name = "TRANSACTION_RATE")
	private Float transRate;

	@Column(name = "ACTUAL_CURRENCY")
	private String actCur;

	@Column(name = "ACTUAL_AMT")
	private Float actAmt;

	@Column(name = "CONVERT_CURRENCY")
	private String convertCur;

	@Column(name = "CONVERT_AMT")
	private Float convertAmt;

	@Column(name = "BANK_CODE")
	private String bankCode;

	@Column(name = "BANK_NAME")
	private String bankName;

	@Column(name = "BANK_COUNTRY")
	private String bankCntry;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "REQUEST_CODE")
	private String reqCode;

	@Column(name = "RESPONSE_CODE")
	private String resCode;

	@Column(name = "RESPONSE_MSG")
	private String resMsg;

	@Column(name = "RETRY_COUNT")
	private Integer retryCnt;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "SET_ID")
	private Integer setId;

	@Column(name = "TRANSACTION_FEE")
	private Float transFee;

	@Column(name = "TAX")
	private Float tax;

	@Column(name = "CURRENCY_UNIT")
	private Integer curUnit;

	@Column(name = "PIN_NO")
	private String pinNo;


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getTransId() {
		return transId;
	}


	public void setTransId(String transId) {
		this.transId = transId;
	}


	public String getRefId() {
		return refId;
	}


	public void setRefId(String refId) {
		this.refId = refId;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getSubmerId() {
		return submerId;
	}


	public void setSubmerId(String submerId) {
		this.submerId = submerId;
	}


	public String getExhangeId() {
		return exhangeId;
	}


	public void setExhangeId(String exhangeId) {
		this.exhangeId = exhangeId;
	}


	public String getSellerId() {
		return sellerId;
	}


	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}


	public String getBillingName() {
		return billingName;
	}


	public void setBillingName(String billingName) {
		this.billingName = billingName;
	}


	public String getBillingEmail() {
		return billingEmail;
	}


	public void setBillingEmail(String billingEmail) {
		this.billingEmail = billingEmail;
	}


	public String getBillingMobile() {
		return billingMobile;
	}


	public void setBillingMobile(String billingMobile) {
		this.billingMobile = billingMobile;
	}


	public String getBillingInfo() {
		return billingInfo;
	}


	public void setBillingInfo(String billingInfo) {
		this.billingInfo = billingInfo;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public Float getBillAmt() {
		return billAmt;
	}


	public void setBillAmt(Float billAmt) {
		this.billAmt = billAmt;
	}


	public Timestamp getPaymentDt() {
		return paymentDt;
	}


	public void setPaymentDt(Timestamp paymentDt) {
		this.paymentDt = paymentDt;
	}


	public Float getTransAmt() {
		return transAmt;
	}


	public void setTransAmt(Float transAmt) {
		this.transAmt = transAmt;
	}


	public Float getTransRate() {
		return transRate;
	}


	public void setTransRate(Float transRate) {
		this.transRate = transRate;
	}


	public String getActCur() {
		return actCur;
	}


	public void setActCur(String actCur) {
		this.actCur = actCur;
	}


	public Float getActAmt() {
		return actAmt;
	}


	public void setActAmt(Float actAmt) {
		this.actAmt = actAmt;
	}


	public String getConvertCur() {
		return convertCur;
	}


	public void setConvertCur(String convertCur) {
		this.convertCur = convertCur;
	}


	public Float getConvertAmt() {
		return convertAmt;
	}


	public void setConvertAmt(Float convertAmt) {
		this.convertAmt = convertAmt;
	}


	public String getBankCode() {
		return bankCode;
	}


	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getBankCntry() {
		return bankCntry;
	}


	public void setBankCntry(String bankCntry) {
		this.bankCntry = bankCntry;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getReqCode() {
		return reqCode;
	}


	public void setReqCode(String reqCode) {
		this.reqCode = reqCode;
	}


	public String getResCode() {
		return resCode;
	}


	public void setResCode(String resCode) {
		this.resCode = resCode;
	}


	public String getResMsg() {
		return resMsg;
	}


	public void setResMsg(String resMsg) {
		this.resMsg = resMsg;
	}


	public Integer getRetryCnt() {
		return retryCnt;
	}


	public void setRetryCnt(Integer retryCnt) {
		this.retryCnt = retryCnt;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Integer getSetId() {
		return setId;
	}


	public void setSetId(Integer setId) {
		this.setId = setId;
	}


	public Float getTransFee() {
		return transFee;
	}


	public void setTransFee(Float transFee) {
		this.transFee = transFee;
	}


	public Float getTax() {
		return tax;
	}


	public void setTax(Float tax) {
		this.tax = tax;
	}


	public Integer getCurUnit() {
		return curUnit;
	}


	public void setCurUnit(Integer curUnit) {
		this.curUnit = curUnit;
	}


	public String getPinNo() {
		return pinNo;
	}


	public void setPinNo(String pinNo) {
		this.pinNo = pinNo;
	}

}