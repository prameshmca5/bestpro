package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.RefPosition;
import com.be.model.RefStatus;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Position;
import com.be.sdk.model.Status;
import com.util.BaseUtil;
import com.util.JsonUtil;


@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_POSITION_CUSTOM_DAO)
public class RefPositionQf extends QueryFactory<RefPosition> {

	@PersistenceContext
	private EntityManager em;


	@Override
	public Specification<RefPosition> searchByProperty(final RefPosition t) {
		return (Root<RefPosition> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
			List<Predicate> predLst = generateCriteria(cb, root, t);

			if (predLst != null && !CollectionUtils.isEmpty(predLst)) {
				return query.where(predLst.toArray(new Predicate[predLst.size()])).getRestriction();
			}

			return query.getRestriction();
		};
	}


	@Override
	public List<RefPosition> searchAllByProperty(RefPosition t) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<RefPosition> cq = cb.createQuery(RefPosition.class);
		Root<RefPosition> statusRoot = cq.from(RefPosition.class);
		List<Predicate> predicates = generateCriteria(cb, statusRoot, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			Position dto = JsonUtil.transferToObject(criteria, Position.class);

			if (!BaseUtil.isObjNull(dto)) {
				if (!BaseUtil.isObjNull(dto.getPositionId())) {
					predicates.add(cb.equal(from.get("positionId"), dto.getPositionId()));
				}

				if (!BaseUtil.isObjNull(dto.getPositionCd())) {
					predicates.add(cb.equal(from.get("positionCd"), dto.getPositionCd()));
				}

				if (!BaseUtil.isObjNull(dto.getPositionDesc())) {
					predicates.add(cb.like(from.get("positionDesc"), "%" + dto.getPositionDesc() + "%"));
				}

				if (!BaseUtil.isObjNull(dto.isActive())) {
					predicates.add(cb.equal(from.get("status"), dto.isActive()));
				}

			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

}
