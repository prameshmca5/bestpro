package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonTimestampDeserializer;
import com.util.serializer.JsonTimestampSerializer;


@Entity
@Table(name = "BE_PAYMENT")
public class BePayment extends AbstractEntity implements Serializable, IQfCriteria<BePayment> {

	/**
	 *
	 */
	private static final long serialVersionUID = 6723281272583273849L;

	@Id
	@Column(name = "PMT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer pmtId;

	@Column(name = "TXN_ID")
	private String txnId;

	@Column(name = "PMT_TYPE_MTDT_ID")
	private Integer pmtTypeMtdtId;

	@Column(name = "PMT_REF_NO")
	private String pmtRefNo;

	@Column(name = "TOTAL_ITEM")
	private Integer totalItem;

	@Column(name = "CURRENCY")
	private String currency;

	@Column(name = "TOTAL_AMOUNT")
	private Double totalAmount;

	@Column(name = "PMT_BY")
	private String pmtBy;

	@JsonSerialize(using = JsonTimestampSerializer.class)
	@JsonDeserialize(using = JsonTimestampDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH_TIME_S)
	@Column(name = "PMT_DT")
	private Timestamp pmtDt;

	@Column(name = "PMT_BY_LEVEL")
	private String pmtByLevel;

	@Column(name = "PMT_GW_DT")
	private Timestamp pmtGwDt;

	@Column(name = "PMT_STATE_CD")
	private String pmtStateCd;

	@Column(name = "PMT_DIVISION_CD")
	private String pmtDivisionCd;

	@Column(name = "PMT_BRANCH_CD")
	private String pmtBranchCd;

	@Column(name = "STATUS_ID")
	private Integer statusId;

	@OneToOne
	@JoinColumn(name = "STATUS_ID", insertable = false, updatable = false)
	private RefStatus status;

	@Column(name = "BATCH_ID")
	private Integer batchId;

	@Column(name = "CHANNEL_MTDT_ID")
	private Integer channelMtdtId;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;

	@OneToMany(mappedBy = "payment", cascade = { CascadeType.ALL })
	private List<BePaymentDtl> paymentDtlList;

	@OneToMany(mappedBy = "payment", cascade = { CascadeType.ALL })
	private List<BePaymentGateway> paymentGatewayList;


	public Integer getPmtId() {
		return pmtId;
	}


	public void setPmtId(Integer pmtId) {
		this.pmtId = pmtId;
	}


	public String getTxnId() {
		return txnId;
	}


	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}


	public Integer getPmtTypeMtdtId() {
		return pmtTypeMtdtId;
	}


	public void setPmtTypeMtdtId(Integer pmtTypeMtdtId) {
		this.pmtTypeMtdtId = pmtTypeMtdtId;
	}


	public String getPmtRefNo() {
		return pmtRefNo;
	}


	public void setPmtRefNo(String pmtRefNo) {
		this.pmtRefNo = pmtRefNo;
	}


	public Integer getTotalItem() {
		return totalItem;
	}


	public void setTotalItem(Integer totalItem) {
		this.totalItem = totalItem;
	}


	public Double getTotalAmount() {
		return totalAmount;
	}


	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}


	public String getPmtBy() {
		return pmtBy;
	}


	public void setPmtBy(String pmtBy) {
		this.pmtBy = pmtBy.toUpperCase();
	}


	public Timestamp getPmtDt() {
		return pmtDt;
	}


	public void setPmtDt(Timestamp pmtDt) {
		this.pmtDt = pmtDt;
	}


	public String getPmtStateCd() {
		return pmtStateCd;
	}


	public void setPmtStateCd(String pmtStateCd) {
		this.pmtStateCd = pmtStateCd;
	}


	public String getPmtDivisionCd() {
		return pmtDivisionCd;
	}


	public void setPmtDivisionCd(String pmtDivisionCd) {
		this.pmtDivisionCd = pmtDivisionCd;
	}


	public String getPmtBranchCd() {
		return pmtBranchCd;
	}


	public void setPmtBranchCd(String pmtBranchCd) {
		this.pmtBranchCd = pmtBranchCd;
	}


	public Integer getStatusId() {
		return statusId;
	}


	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public RefStatus getStatus() {
		return status;
	}


	public void setStatus(RefStatus status) {
		this.status = status;
	}


	public Integer getBatchId() {
		return batchId;
	}


	public void setBatchId(Integer batchId) {
		this.batchId = batchId;
	}


	public Timestamp getPmtGwDt() {
		return pmtGwDt;
	}


	public void setPmtGwDt(Timestamp pmtGwDt) {
		this.pmtGwDt = pmtGwDt;
	}


	public List<BePaymentDtl> getPaymentDtlList() {
		return paymentDtlList;
	}


	public void setPaymentDtlList(List<BePaymentDtl> paymentDtlList) {
		this.paymentDtlList = paymentDtlList;
	}


	public List<BePaymentGateway> getPaymentGatewayList() {
		return paymentGatewayList;
	}


	public void setPaymentGatewayList(List<BePaymentGateway> paymentGatewayList) {
		this.paymentGatewayList = paymentGatewayList;
	}


	public void addBePaymentDtlList(List<BePaymentDtl> paymentDtlList) {
		paymentDtlList.forEach(pmtDtl -> {
			pmtDtl.setPayment(this);
		});
		setPaymentDtlList(paymentDtlList);
	}


	public void addBePaymentGateway(BePaymentGateway paymentGateway) {
		paymentGateway.setPayment(this);
		List<BePaymentGateway> paymentGatewayList = new ArrayList<>();
		paymentGatewayList.add(paymentGateway);
		setPaymentGatewayList(paymentGatewayList);
	}


	public Integer getChannelMtdtId() {
		return channelMtdtId;
	}


	public void setChannelMtdtId(Integer channelMtdtId) {
		this.channelMtdtId = channelMtdtId;
	}


	public String getPmtByLevel() {
		return pmtByLevel;
	}


	public void setPmtByLevel(String pmtByLevel) {
		this.pmtByLevel = pmtByLevel.toUpperCase();
	}

}
