/**
 * Copyright 2019
 */
package com.be.core;


import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletRequest;

import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AdviceMode;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.be.config.SimpleDataAccess;
import com.be.constants.QualifierConstants;
import com.be.model.RefDocument;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.dm.sdk.client.DmServiceClient;
import com.dm.sdk.model.Documents;
import com.idm.sdk.client.IdmServiceClient;
import com.notify.sdk.client.NotServiceClient;
import com.report.sdk.client.ReportServiceClient;
import com.report.sdk.model.Report;
import com.util.constants.BaseConstants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 17, 2018
 */
@EnableTransactionManagement(mode = AdviceMode.PROXY, proxyTargetClass = true)
@Transactional(QualifierConstants.TRANS_MANAGER)
public abstract class AbstractService<S> implements SimpleDataAccess<S> {

	@Autowired
	protected Mapper dozerMapper;

	@Autowired
	@Qualifier(QualifierConstants.TRANS_MANAGER)
	protected PlatformTransactionManager transactionManager;


	public abstract GenericRepository<S> primaryDao();


	public abstract List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria);


	@Autowired
	private IdmServiceClient idmService;

	@Autowired
	private NotServiceClient notifyService;

	@Autowired
	private ReportServiceClient reportService;

	@Autowired
	private DmServiceClient dmService;


	@Override
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = BeException.class)
	public S create(S s) {
		try {
			this.primaryDao().save(s);
			return s;
		} catch (Exception e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	@Override
	@Modifying(clearAutomatically = true)
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = BeException.class)
	public S update(S s) {
		try {
			this.primaryDao().saveAndFlush(s);
			return s;
		} catch (Exception e) {
			throw new BeException(BeErrorCodeEnum.E500C002);
		}
	}


	@Override
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = true, rollbackFor = BeException.class)
	public S find(java.lang.Integer id) {
		try {
			return this.primaryDao().findOne(id);
		} catch (Exception e) {
			throw new BeException(BeErrorCodeEnum.E500C004);
		}

	}


	@Override
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = true, rollbackFor = BeException.class)
	public List<S> findAll() {
		try {
			return this.primaryDao().findAll();
		} catch (Exception e) {
			throw new BeException(BeErrorCodeEnum.E500C004);
		}
	}


	@Override
	@Modifying(clearAutomatically = true)
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = BeException.class)
	public boolean delete(java.lang.Integer id) {
		try {
			this.primaryDao().delete(id);
			return true;
		} catch (Exception e) {
			throw new BeException(BeErrorCodeEnum.E500C003);
		}
	}


	@Override
	@Modifying(clearAutomatically = true)
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = BeException.class)
	public Collection<S> updateAll(Collection<S> s) {
		try {
			this.primaryDao().save(s);
			return s;
		} catch (Exception e) {
			throw new BeException(BeErrorCodeEnum.E500C002);
		}
	}


	@Override
	@Modifying(clearAutomatically = true)
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = BeException.class)
	public Collection<S> deleteAll(Collection<S> s) {
		try {
			this.primaryDao().delete(s);
			return s;
		} catch (Exception e) {
			throw new BeException(BeErrorCodeEnum.E500C002);
		}
	}


	protected Timestamp getSQLTimestamp() {
		Calendar calendar = Calendar.getInstance();
		java.util.Date now = calendar.getTime();
		return new java.sql.Timestamp(now.getTime());
	}


	protected String getCurrUserId(HttpServletRequest request) {
		return String.valueOf(request.getAttribute("currUserId"));
	}


	protected IdmServiceClient getIdmService(HttpServletRequest request) {
		idmService.setAuthToken(request.getHeader(BaseConstants.HEADER_AUTHORIZATION));
		idmService.setMessageId(StringUtils.hasText(request.getHeader(BaseConstants.HEADER_MESSAGE_ID))
				? request.getHeader(BaseConstants.HEADER_MESSAGE_ID)
				: String.valueOf(UUID.randomUUID()));
		if (StringUtils.hasText(request.getHeader(BaseConstants.HEADER_SYSTEM_TYPE))) {
			idmService.setSystemType(request.getHeader(BaseConstants.HEADER_SYSTEM_TYPE));
		}
		return idmService;
	}


	public NotServiceClient getNotifyService(HttpServletRequest request) {
		notifyService.setAuthToken(request.getHeader(BaseConstants.HEADER_AUTHORIZATION));
		notifyService.setMessageId(StringUtils.hasText(request.getHeader(BaseConstants.HEADER_MESSAGE_ID))
				? request.getHeader(BaseConstants.HEADER_MESSAGE_ID)
				: String.valueOf(UUID.randomUUID()));
		return notifyService;
	}


	public ReportServiceClient getReportService(HttpServletRequest request) {
		reportService.setAuthToken(request.getHeader(BaseConstants.HEADER_AUTHORIZATION));
		reportService.setMessageId(StringUtils.hasText(request.getHeader(BaseConstants.HEADER_MESSAGE_ID))
				? request.getHeader(BaseConstants.HEADER_MESSAGE_ID)
				: String.valueOf(UUID.randomUUID()));
		return reportService;
	}


	public DmServiceClient getDmService(HttpServletRequest request, String bucket) {
		if (bucket != null) {
			dmService.setProjId(bucket);
		}
		dmService.setAuthToken(request.getHeader(BaseConstants.HEADER_AUTHORIZATION));
		dmService.setMessageId(StringUtils.hasText(request.getHeader(BaseConstants.HEADER_MESSAGE_ID))
				? request.getHeader(BaseConstants.HEADER_MESSAGE_ID)
				: String.valueOf(UUID.randomUUID()));
		return dmService;
	}


	public Documents upload(RefDocument refDoc, Report report, String refNo, HttpServletRequest request) {
		Documents doc = new Documents();
		doc.setContentType(refDoc.getType());
		doc.setFilename(refDoc.getDocDesc());
		doc.setDocid(refDoc.getDocId());
		doc.setLength(report.getReportBytes().length);
		doc.setRefno(refNo);
		doc.setContent(report.getReportBytes());
		return getDmService(request, refDoc.getDmBucket()).upload(doc);
	}

}