package com.bestpay.pgw.sdk.model;


import java.math.BigDecimal;


public class StaticQuotaCal {

	private int seatChair;

	private String jobCategory;

	private String yearlySales;

	private int noOfResidents;

	private int noOfMachine;

	private int noOfDoorFloor;

	private String contractValue;

	private int noOfChairSeat;

	private int roomChalet;

	private int itemsProposed;

	private String premiseDesc;

	private String cropsTypes;

	private BigDecimal landArea;

	private String systemValue;

	private String liveStockType;

	private String mgmtSystem;

	private String wrkType;

	private String type;

	private String fisheryType;

	private int poolArea;

	private int wrkrEstimation;

	private int wrkrTotal;

	private int wrkrEligible;

	private String mrktTypeLoc = "Local";

	private BigDecimal mrktValueLoc;

	private int mrktPercentageLoc;

	private String mrktTypeExp = "Export";

	private BigDecimal mrktValueExp;

	private int mrktPercentageExp;

	private String materialImported = "Imported";

	private String materialLocal = "Local";

	private Double bprjctCost;


	public Double getBprjctCost() {
		return bprjctCost;
	}


	public void setBprjctCost(Double double1) {
		bprjctCost = double1;
	}


	public String getImported() {
		return materialImported;
	}


	public void setImported(String materialImported) {
		this.materialImported = materialImported;
	}


	public String getLocal() {
		return materialLocal;
	}


	public void setLocal(String materialLocal) {
		this.materialLocal = materialLocal;
	}


	public String getSystemValue() {
		return systemValue;
	}


	public String getMrktTypeLoc() {
		return mrktTypeLoc;
	}


	public void setMrktTypeLoc(String mrktTypeLoc) {
		this.mrktTypeLoc = mrktTypeLoc;
	}


	public BigDecimal getMrktValueLoc() {
		return mrktValueLoc;
	}


	public void setMrktValueLoc(BigDecimal mrktValueLoc) {
		this.mrktValueLoc = mrktValueLoc;
	}


	public int getMrktPercentageLoc() {
		return mrktPercentageLoc;
	}


	public void setMrktPercentageLoc(int mrktPercentageLoc) {
		this.mrktPercentageLoc = mrktPercentageLoc;
	}


	public String getMrktTypeExp() {
		return mrktTypeExp;
	}


	public void setMrktTypeExp(String mrktTypeExp) {
		this.mrktTypeExp = mrktTypeExp;
	}


	public BigDecimal getMrktValueExp() {
		return mrktValueExp;
	}


	public void setMrktValueExp(BigDecimal bigDecimal) {
		mrktValueExp = bigDecimal;
	}


	public int getMrktPercentageExp() {
		return mrktPercentageExp;
	}


	public void setMrktPercentageExp(int mrktPercentageExp) {
		this.mrktPercentageExp = mrktPercentageExp;
	}


	public void setSystemValue(String systemValue) {
		this.systemValue = systemValue;
	}


	public String getLiveStockType() {
		return liveStockType;
	}


	public void setLiveStockType(String liveStockType) {
		this.liveStockType = liveStockType;
	}


	public String getMgmtSystem() {
		return mgmtSystem;
	}


	public void setMgmtSystem(String mgmtSystem) {
		this.mgmtSystem = mgmtSystem;
	}


	public String getWrkType() {
		return wrkType;
	}


	public void setWrkType(String wrkType) {
		this.wrkType = wrkType;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getFisheryType() {
		return fisheryType;
	}


	public void setFisheryType(String fisheryType) {
		this.fisheryType = fisheryType;
	}


	public int getPoolArea() {
		return poolArea;
	}


	public void setPoolArea(int poolArea) {
		this.poolArea = poolArea;
	}


	public int getSeatChair() {
		return seatChair;
	}


	public void setSeatChair(int seatChair) {
		this.seatChair = seatChair;
	}


	public String getJobCategory() {
		return jobCategory;
	}


	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}


	public String getCropsTypes() {
		return cropsTypes;
	}


	public void setCropsTypes(String cropsTypes) {
		this.cropsTypes = cropsTypes;
	}


	public BigDecimal getLandArea() {
		return landArea;
	}


	public void setLandArea(BigDecimal landArea) {
		this.landArea = landArea;
	}


	public void setNoOfChairSeat(int noOfChairSeat) {
		this.noOfChairSeat = noOfChairSeat;
	}


	public String getYearlySales() {
		return yearlySales;
	}


	public void setYearlySales(String yearlySales) {
		this.yearlySales = yearlySales;
	}


	public int getNoOfResidents() {
		return noOfResidents;
	}


	public void setNoOfResidents(int noOfResidents) {
		this.noOfResidents = noOfResidents;
	}


	public int getNoOfMachine() {
		return noOfMachine;
	}


	public void setNoOfMachine(int noOfMachine) {
		this.noOfMachine = noOfMachine;
	}


	public int getNoOfDoorFloor() {
		return noOfDoorFloor;
	}


	public void setNoOfDoorFloor(int noOfDoorFloor) {
		this.noOfDoorFloor = noOfDoorFloor;
	}


	public String getContractValue() {
		return contractValue;
	}


	public void setContractValue(String contractValue) {
		this.contractValue = contractValue;
	}


	public int getNoOfChairSeat() {
		return noOfChairSeat;
	}


	public void setNoOfChairSeat(Integer integer) {
		noOfChairSeat = integer;
	}


	public int getRoomChalet() {
		return roomChalet;
	}


	public void setRoomChalet(int roomChalet) {
		this.roomChalet = roomChalet;
	}


	public int getItemsProposed() {
		return itemsProposed;
	}


	public void setItemsProposed(int itemsProposed) {
		this.itemsProposed = itemsProposed;
	}


	public String getPremiseDesc() {
		return premiseDesc;
	}


	public void setPremiseDesc(String premiseDesc) {
		this.premiseDesc = premiseDesc;
	}


	public int getWrkrEstimation() {
		return wrkrEstimation;
	}


	public void setWrkrEstimation(int wrkrEstimation) {
		this.wrkrEstimation = wrkrEstimation;
	}


	public int getWrkrTotal() {
		return wrkrTotal;
	}


	public void setWrkrTotal(int wrkrTotal) {
		this.wrkrTotal = wrkrTotal;
	}


	public int getWrkrEligible() {
		return wrkrEligible;
	}


	public void setWrkrEligible(int wrkrEligible) {
		this.wrkrEligible = wrkrEligible;
	}

}
