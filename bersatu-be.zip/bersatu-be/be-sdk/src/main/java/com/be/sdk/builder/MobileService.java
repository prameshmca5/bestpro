package com.be.sdk.builder;


import java.util.Arrays;
import java.util.List;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.MemberProfile;
import com.be.sdk.model.Otp;
import com.be.sdk.model.Payment;
import com.be.sdk.model.PaymentBreakdown;
import com.be.sdk.model.PreReg;


public class MobileService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public MobileService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	public Otp genRegOtp(Otp dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE);
		sb.append(BeUrlConstants.GEN_REG_OTP);

		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Otp.class);
	}


	public Otp verifyRegOtp(Otp dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE);
		sb.append(BeUrlConstants.VER_REG_OTP);

		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Otp.class);
	}


	public List<PaymentBreakdown> searchPaymentBreakdown(PaymentBreakdown dto) {
		List<PaymentBreakdown> paymentBreakdownList = null;
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE);
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.BREAKDOWN);
		PaymentBreakdown[] array = restTemplate().postForObject(getServiceURI(sb.toString()), dto,
				PaymentBreakdown[].class);
		if (array != null && array.length > 0) {
			paymentBreakdownList = Arrays.asList(array);
		}
		return paymentBreakdownList;
	}


	public MemberProfile searchMemberProfile(MemberProfile dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE);
		sb.append(BeUrlConstants.MEMBER);
		sb.append(BeUrlConstants.SEARCH);

		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, MemberProfile.class);
	}


	public Payment searchPayment(Payment dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE);
		sb.append(BeUrlConstants.PAYMENT);
		sb.append(BeUrlConstants.SEARCH);

		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, Payment.class);
	}


	// use to search for unique column only, or else return latest data in db
	public PreReg searchPreReg(PreReg dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MOBILE);
		sb.append(BeUrlConstants.REGISTER);
		sb.append(BeUrlConstants.SEARCH);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, PreReg.class);
	}
}
