/**
 * Copyright 2019
 */
package com.be.sdk.constants;


/**
 * Constants for Mail Template Code
 *
 * @author mary.jane
 * @since Dec 21, 2018
 */
public class MailTemplateConstants {

	private MailTemplateConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String CMN_OTP = "CMN_OTP";

	public static final String IDM_REG_SUCCESS = "IDM_REGISTER_SUCCESS";

	public static final String OTP_REG = "OTP_REG";

	public static final String MEMBER_REG_RESULT_EMAIL = "MEMBER_REG_RESULT_EMAIL";

	public static final String MEMBER_REG_RESULT_SMS = "MEMBER_REG_RESULT_SMS";

	public static final String MEMBER_REG_RESULT_FCM = "MEMBER_REG_RESULT_FCM";

	public static final String MEMBER_SET_PWD_EMAIL = "MEMBER_SET_PWD_EMAIL";

	public static final String MEMBER_SET_PWD_SMS = "MEMBER_SET_PWD_SMS";

	public static final String MEMBER_SET_PWD_FCM = "MEMBER_SET_PWD_FCM";

	public static final String MEMBER_ELECTION_LIST_EMAIL = "MEMBER_ELECTION_LIST_EMAIL";

	public static final String MEMBER_ELECTION_LIST_SMS = "MEMBER_ELECTION_LIST_SMS";

	public static final String MEMBER_ELECTION_LIST_FCM = "MEMBER_ELECTION_LIST_FCM";

	public static final String PUBLIC_REG_RESULT_EMAIL = "PUBLIC_REG_RESULT_EMAIL";

	public static final String PUBLIC_REG_RESULT_SMS = "PUBLIC_REG_RESULT_SMS";

	public static final String PUBLIC_REG_RESULT_FCM = "PUBLIC_REG_RESULT_FCM";

	public static final String PAYMENT_SUCCESSFUL_EMAIL = "PAYMENT_SUCCESSFUL_EMAIL";

	public static final String PAYMENT_SUCCESSFUL_SMS = "PAYMENT_SUCCESSFUL_SMS";

	public static final String PAYMENT_SUCCESSFUL_FCM = "PAYMENT_SUCCESSFUL_FCM";

	public static final String DIV_MEMBER_ELECTION_LIST_EMAIL = "DIV_MEMBER_ELECTION_LIST_EMAIL";

	public static final String DIV_MEMBER_ELECTION_LIST_SMS = "DIV_MEMBER_ELECTION_LIST_SMS";

	public static final String DIV_MEMBER_ELECTION_LIST_FCM = "DIV_MEMBER_ELECTION_LIST_FCM";

	public static final String DIV_REMINDER_REGISTRATION_APPROVAL = "DIV_REMINDER_REGISTRATION_APPROVAL";

	public static final String HQ_REMINDER_REGISTRATION_APPROVAL = "HQ_REMINDER_REGISTRATION_APPROVAL";

	public static final String MEMBER_REG_RESULT_EMAIL_REJECT = "MEMBER_REG_RESULT_EMAIL_REJECT";

	public static final String MEMBER_REG_RESULT_SMS_REJECT = "MEMBER_REG_RESULT_SMS_REJECT";

	public static final String MEMBER_REG_RESULT_SMS_VERIFY = "MEMBER_REG_RESULT_SMS_VERIFY";

	public static final String MEMBER_REG_RESULT_EMAIL_VERIFY = "MEMBER_REG_RESULT_EMAIL_VERIFY";
	
	public static final String MEMBER_BLAST_MESSAGE_EMAIL = "MEMBER_BLAST_MESSAGE_EMAIL";

	public static final String MEMBER_BLAST_MESSAGE_SMS = "MEMBER_BLAST_MESSAGE_SMS";

	public static final String MEMBER_BLAST_MESSAGE_FCM = "MEMBER_BLAST_MESSAGE_FCM";
	
	
}
