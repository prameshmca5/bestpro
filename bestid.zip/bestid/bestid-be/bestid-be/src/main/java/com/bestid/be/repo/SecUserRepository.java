/**
 * 
 */
package com.bestid.be.repo;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.SecUser;

/**
 * @author roziana
 * @since  Nov 19, 2018
 */
@Repository
@RepositoryDefinition(domainClass = SecUser.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.SEC_USER_REPOSITORY)
public interface SecUserRepository  extends GenericRepository<SecUser>{
	
	@Query("select u from SecUser u where u.userName= :userName")
	public SecUser findUserName(@Param("userName") String userName);
	
	@Query("select u from SecUser u where u.userName= :userName and u.pinCd= :pinCd")
	public SecUser findUserNamePinCd(@Param("userName") String userName, @Param("pinCd") String pinCd);
	
	@Query("select u from SecUser u where u.profileId = :profileId")
	public SecUser findProfileId(@Param("profileId") String profileId);
	
	@Query("select u from SecUser u where u.userId= :userId and u.profileId = :profileId")
	public SecUser findUserIdProfileId(@Param("userId") int userId, @Param("profileId") String profileId);
}
