/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.RefPmtGatewayResp;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.PmtGatewayResp;
import com.util.BaseUtil;
import com.util.JsonUtil;


/**
 * @author nurul.naimma
 *
 * @since Apr 19, 2021
 */

@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_PMT_GATEWAY_RESP_QF)
public class RefPmtGatewayRespQf extends QueryFactory<RefPmtGatewayResp> {

	@PersistenceContext
	private EntityManager em;


	@Override
	public Specification<RefPmtGatewayResp> searchByProperty(RefPmtGatewayResp t) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<RefPmtGatewayResp> searchAllByProperty(RefPmtGatewayResp t) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<RefPmtGatewayResp> cq = cb.createQuery(RefPmtGatewayResp.class);
		Root<RefPmtGatewayResp> parliamentRoot = cq.from(RefPmtGatewayResp.class);
		List<Predicate> predicates = generateCriteria(cb, parliamentRoot, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			PmtGatewayResp dto = JsonUtil.transferToObject(criteria, PmtGatewayResp.class);

			if (!BaseUtil.isObjNull(dto)) {

				if (!BaseUtil.isObjNull(dto.getPmtGatewayRespId())) {
					predicates.add(cb.equal(from.get("pmtGatewayRespId"), dto.getPmtGatewayRespId()));
				}

				if (!BaseUtil.isObjNull(dto.getStatusCd())) {
					predicates.add(cb.equal(from.get("statusCd"), dto.getStatusCd()));
				}

				if (!BaseUtil.isObjNull(dto.getRespCd())) {
					predicates.add(cb.equal(from.get("respCd"), dto.getRespCd()));
				}

			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

}
