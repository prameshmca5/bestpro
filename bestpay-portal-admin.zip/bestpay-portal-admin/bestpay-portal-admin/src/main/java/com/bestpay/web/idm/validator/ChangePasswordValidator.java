/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.idm.validator;


import static com.bestpay.web.constants.MessageConstants.ERROR_FIELDS_CURRPASS;
import static com.bestpay.web.constants.MessageConstants.ERROR_FIELDS_NEWPASS;
import static com.bestpay.web.constants.MessageConstants.ERROR_FIELDS_PWORD_MATCH;
import static com.bestpay.web.constants.MessageConstants.ERROR_FIELDS_PWORD_NOT_MATCH;
import static com.bestpay.web.constants.MessageConstants.ERROR_FIELDS_RNEWPASS;
import static com.bestpay.web.constants.MessageConstants.ERROR_LENGTH_NEWPASS;
import static com.bestpay.web.constants.MessageConstants.ERROR_LENGTH_RNEWPASS;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.idm.sdk.model.ChangePassword;
import com.bestpay.web.util.ValidationUtil;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
@Component("changePasswordValidator")
public class ChangePasswordValidator implements Validator {

	private static final String NEW_PSWRD = "newPword";

	private static final String REP_NEW_PSWRD = "repNewPword";


	@Override
	public boolean supports(Class<?> clazz) {
		return ChangePassword.class.equals(clazz);
	}


	@Override
	public void validate(Object object, Errors errors) {
		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "currPword", ERROR_FIELDS_CURRPASS);
		ValidationUtil.rejectIfEmptyOrWhitespace(errors, NEW_PSWRD, ERROR_FIELDS_NEWPASS);
		ValidationUtil.rejectIfEmptyOrWhitespace(errors, REP_NEW_PSWRD, ERROR_FIELDS_RNEWPASS);

		if (!errors.hasErrors()) {
			ValidationUtil.rejectIfLengthIsInvalid(errors, NEW_PSWRD, ERROR_LENGTH_NEWPASS, 7, 20);
			ValidationUtil.rejectIfLengthIsInvalid(errors, REP_NEW_PSWRD, ERROR_LENGTH_RNEWPASS, 7, 20);
		}

		// Validate password and repeat password if the same
		ValidationUtil.compareTwoStrings(errors, NEW_PSWRD, REP_NEW_PSWRD, ERROR_FIELDS_PWORD_NOT_MATCH);

		// Validate current password and new password not the same
		ValidationUtil.rejectSameTwoStrings(errors, "currPword", NEW_PSWRD, ERROR_FIELDS_PWORD_MATCH);
	}

}