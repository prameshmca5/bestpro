/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Md Asif Aftab
 * @since 13th March 2018
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class Nationality implements Serializable {

	private static final long serialVersionUID = -6255425222614429634L;

	private String ntnltyId;
	private String ntnltyCode;
	private String ntnltyDescEn;
	private String ntnltyDescMy;

	public String getNtnltyId() {
		return ntnltyId;
	}

	public void setNtnltyId(String ntnltyId) {
		this.ntnltyId = ntnltyId;
	}

	public String getNtnltyCode() {
		return ntnltyCode;
	}

	public void setNtnltyCode(String ntnltyCode) {
		this.ntnltyCode = ntnltyCode;
	}

	public String getNtnltyDescEn() {
		return ntnltyDescEn;
	}

	public void setNtnltyDescEn(String ntnltyDescEn) {
		this.ntnltyDescEn = ntnltyDescEn;
	}

	public String getNtnltyDescMy() {
		return ntnltyDescMy;
	}

	public void setNtnltyDescMy(String ntnltyDescMy) {
		this.ntnltyDescMy = ntnltyDescMy;
	}

}