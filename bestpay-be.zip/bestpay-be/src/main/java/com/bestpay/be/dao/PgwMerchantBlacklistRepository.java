package com.bestpay.be.dao;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.PgwMerchantBlacklist;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Afif Saman
 * @since 5th June 2018
 */

@Repository
@RepositoryDefinition(domainClass = PgwMerchantBlacklist.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_MERBLCKLST_DAO)
public interface PgwMerchantBlacklistRepository extends GenericRepository<PgwMerchantBlacklist> {

	@Query("select u from PgwMerchantBlacklist u where u.ino = :ino ")
	public PgwMerchantBlacklist findByBlacklistId(@Param("ino") int blcklstId);


	@Query("select u from PgwMerchantBlacklist u where u.value = :value ")
	public PgwMerchantBlacklist findBlacklistByValue(@Param("value") String value);


	@Query("select count(u) from PgwMerchantBlacklist u ")
	public int totalRecords();

}