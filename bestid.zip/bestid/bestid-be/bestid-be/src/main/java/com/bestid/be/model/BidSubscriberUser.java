package com.bestid.be.model;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author mukhlis.hamzah
 * @since 1 Mar 2019
 */
@Entity
@Table(name = "BID_SUBSCRIBER_USER")
public class BidSubscriberUser implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 735244180220203237L;

	@Id
	@Column(name = "SUBSCR_USER_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer subscrUsrId;

	@Column(name = "SEC_USER_ID")
	private Integer secUserId;

	@Column(name = "SUBSCR_ID")
	private Integer subscrId;

	@Column(name = "MOBILE_NO")
	private String mobileNo;

	@Column(name = "DEVICE_ID")
	private Integer deviceId;

	@Column(name = "INVITATION_CD")
	private String invitationCd;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getSubscrUsrId() {
		return subscrUsrId;
	}


	public void setSubscrUsrId(Integer subscrUsrId) {
		this.subscrUsrId = subscrUsrId;
	}


	public Integer getSecUserId() {
		return secUserId;
	}


	public void setSecUserId(Integer secUserId) {
		this.secUserId = secUserId;
	}


	public Integer getSubscrId() {
		return subscrId;
	}


	public void setSubscrId(Integer subscrId) {
		this.subscrId = subscrId;
	}


	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public Integer getDeviceId() {
		return deviceId;
	}


	public void setDeviceId(Integer deviceId) {
		this.deviceId = deviceId;
	}


	public String getInvitationCd() {
		return invitationCd;
	}


	public void setInvitationCd(String invitationCd) {
		this.invitationCd = invitationCd;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}

}
