/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwMerchantContact;
import com.bestpay.be.model.PgwReportSubscribe;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerRepSet;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.DateUtil;
import com.bstsb.util.MediaType;

/**
 * @author Afif Saman
 * @since July 23, 2018
 */
@RestController
@RequestMapping(BeUrlConstants.RPT_SET)
public class ReportSettingRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReportSettingRestController.class);

	@GetMapping(value = "/{merchantId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerRepSet getMerRepSetById(@PathVariable String merchantId) {

		PgwReportSubscribe pgwReportSubscribe = pgwReportSubscribeService.findReportSubscribeByMerchantId(merchantId);
		PgwMerchantContact pgwMerchantContact = pgwMerchantContactService.findMerContactByMerchantId(merchantId);
		MerRepSet merRepSet = new MerRepSet();
		if (!BaseUtil.isObjNull(pgwReportSubscribe)) {
			merRepSet = dozerMapper.map(pgwReportSubscribe, MerRepSet.class);
		}
		if (!BaseUtil.isObjNull(pgwMerchantContact)) {
			if (!BaseUtil.isObjNull(pgwMerchantContact.getEmail())) {
				merRepSet.setEmail1(pgwMerchantContact.getEmail());
			}
			if (!BaseUtil.isObjNull(pgwMerchantContact.getEmail2())) {
				merRepSet.setEmail2(pgwMerchantContact.getEmail2());
			}
			if (!BaseUtil.isObjNull(pgwMerchantContact.getEmailMisc())) {
				merRepSet.setEmailMisc(pgwMerchantContact.getEmailMisc());
			}
		}
		return merRepSet;
	}

	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public boolean updateReportSetting(@Valid @RequestBody MerRepSet merRepSet, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		LOGGER.info("Create/update new report setting ... ");
		if (merRepSet == null) {// Report setting null
			throw new BeException(BeErrorCodeEnum.E404RSC001);
		}

		PgwReportSubscribe pgwReportSubscribe = pgwReportSubscribeService
				.findReportSubscribeByMerchantId(merRepSet.getMerchantId());

		if (BaseUtil.isObjNull(pgwReportSubscribe)) {
			PgwReportSubscribe newReportSubscribe = dozerMapper.map(merRepSet, PgwReportSubscribe.class);
			newReportSubscribe.setFreqH(0);
			newReportSubscribe.setReportName("Transaction Report");
			newReportSubscribe.setSetupDate(DateUtil.convertDate2SqlTimeStamp(new Date()));
			newReportSubscribe.setCreateId(merRepSet.getUserId());
			newReportSubscribe.setUpdateId(merRepSet.getUserId());

			super.pgwReportSubscribeService.create(newReportSubscribe);
		} else {
			pgwReportSubscribe.setStatus(merRepSet.getStatus());
			pgwReportSubscribe.setFreqD(merRepSet.getFreqD());
			pgwReportSubscribe.setFreqW(merRepSet.getFreqW());
			pgwReportSubscribe.setFreqM(merRepSet.getFreqM());
			pgwReportSubscribe.setEmailProfile(merRepSet.getEmailProfile());
			pgwReportSubscribe.setEmailTo(merRepSet.getEmailTo());
			pgwReportSubscribe.setEmailCc(merRepSet.getEmailCc());
			pgwReportSubscribe.setEmailBcc(merRepSet.getEmailBcc());
			pgwReportSubscribe.setUpdateId(merRepSet.getUserId());
			super.pgwReportSubscribeService.update(pgwReportSubscribe);
		}

		return true;
	}

}
