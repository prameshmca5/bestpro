package com.bestpay.pgw.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.model.PgwMerchantCompany;
import com.bestpay.pgw.util.QualifierConstants;
 
	@Repository
	@RepositoryDefinition(domainClass = PgwMerchantCompany.class, idClass = String.class)
	@Scope(QualifierConstants.SCOPE_PROTOTYPE)
	@Qualifier(QualifierConstants.PGW_MERCHANT_COMPANY_DAO)
 	public interface PgwMerchantCompanyRepository extends GenericRepository<PgwMerchantCompany> {

	
	@Query("select u from PgwMerchantCompany u ")
	public List<PgwMerchantCompany> findAllMerchantCompany();


	@Query("select count(u) from PgwMerchantCompany u ")
	public int totalRecords();


	@Query("select u from PgwMerchantCompany u where u.companyId = :companyId")
	public PgwMerchantCompany findCompanyByCompanyId(@Param("companyId") Integer companyId);
 
	@Query("select u from PgwMerchantCompany u where u.compRefId=:compRefId")
	public PgwMerchantCompany findCompanyByCompRefId(@Param("compRefId") String compRefId);
	
}
