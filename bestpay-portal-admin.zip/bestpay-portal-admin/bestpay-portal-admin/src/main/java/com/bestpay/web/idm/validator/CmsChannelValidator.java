package com.bestpay.web.idm.validator;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.be.sdk.model.Channel;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ValidationUtil;


@Component("cmsChannelValidator")
public class CmsChannelValidator extends AbstractController implements Validator {

	private static final Logger LOGGER = LoggerFactory.getLogger(CmsChannelValidator.class);

	private static final String PUBLICNAME = "publicName";


	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}


	@Override
	public void validate(Object object, Errors errors) {

		if (object instanceof Channel) {
			Channel channel = (Channel) object;

			// Validate if fields are empty or a whitespace

			ValidationUtil.rejectIfEmptyOrWhitespace(errors, PUBLICNAME, MessageConstants.ERROR_FIELDS_CHNL_PBLNAME);
			// ValidationUtil.rejectIfEmptyOrWhitespace(errors,
			// "privateName",
			// MessageConstants.ERROR_FIELDS_CHNL_PRVNAME);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "type", MessageConstants.ERROR_FIELDS_CHNL_TYP);
			// ValidationUtil.rejectIfEmptyOrWhitespace(errors, "minCur",
			// MessageConstants.ERROR_FIELDS_CHNL_MINCUR);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "minAmt", MessageConstants.ERROR_FIELDS_CHNL_MINAMT);
			// ValidationUtil.rejectIfEmptyOrWhitespace(errors, "maxCur",
			// MessageConstants.ERROR_FIELDS_CHNL_MAXCUR);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "maxAmt", MessageConstants.ERROR_FIELDS_CHNL_MAXAMT);
			// ValidationUtil.rejectIfEmptyOrWhitespace(errors, "currency",
			// MessageConstants.ERROR_FIELDS_CHNL_CUR);
			ValidationUtil.rejectIfEmptyOrWhitespace(errors, "name", MessageConstants.ERROR_FIELDS_CHNL_NAME);
			// ValidationUtil.rejectIfEmptyOrWhitespace(errors, "expiryTime",
			// MessageConstants.ERROR_FIELDS_CHNL_EXPYTIME);
			if (channel.getPublicName() != null) {
				String publicName = channel.getPublicName();
				if (publicName.indexOf(' ') != -1) {
					ValidationUtil.rejectIfInvalidAgeLessFormat(errors, PUBLICNAME,
							MessageConstants.ERROR_FIELDS_CHNL_PBLNAME_SPC);
				}
				try {
					Channel channel1 = getBeService().getChannelByPublicName(publicName);
					if (channel1 != null) {
						ValidationUtil.rejectIfInvalidAgeLessFormat(errors, PUBLICNAME,
								MessageConstants.ERROR_FIELDS_CHNL_PBLNAME_DB);
					}
				} catch (Exception e) {
					LOGGER.debug("{}", e.getMessage());
				}
			}
		}

	}

}
