/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import java.util.Date;
import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.PgwSettlementRepository;
import com.bestpay.be.dao.SettlementCustomDao;
import com.bestpay.be.dao.SettlementRptInfoCustomDao;
import com.bestpay.be.model.PgwMerchantProfile;
import com.bestpay.be.model.PgwSettlement;
import com.bestpay.be.sdk.model.SettlementInfo;
import com.bestpay.be.sdk.model.SettlementRptInfo;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Afif Saman
 * @since June 5, 2018
 */
@Transactional
@Service(QualifierConstants.PGW_SETTLEMENT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_SETTLEMENT_SVC)
public class PgwSettlementService extends AbstractService<PgwSettlement> {

	@Autowired
	private PgwSettlementRepository settlementDao;

	@Autowired
	private SettlementRptInfoCustomDao sttlmntRptInfoDao;

	@Autowired
	private SettlementCustomDao settlementCustomDao;


	@Override
	public GenericRepository<PgwSettlement> primaryDao() {
		return settlementDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwSettlement> searchSettlementReport(SettlementRptInfo settlementRptInfo,
			DataTableRequest dataTableInRQ, PgwMerchantProfile pgwMerchantProfile) {
		return sttlmntRptInfoDao.searchByPagination(settlementRptInfo, dataTableInRQ, pgwMerchantProfile);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwSettlement> searchSettlement(SettlementInfo settlementInfo,
			DataTableRequest dataTableInRQ) {
		return settlementCustomDao.searchSettlementList(settlementInfo, dataTableInRQ);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwSettlement findRecentSettlementByMerchId(String merchantId) {
		return settlementCustomDao.findRecentSettlementByMerchId(merchantId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwSettlement findNextSettlementByMerchId(String merchantId) {
		return settlementCustomDao.findNextSettlementByMerchId(merchantId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public int findSettlementId(String merchantId, Date date) {
		return settlementDao.findSetId(merchantId, date);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwSettlement> loadSettleRptInfo(SettlementRptInfo settlementRptInfo,
			PgwMerchantProfile pgwMerchantProfile) {
		return settlementCustomDao.loadSettleRptInfo(settlementRptInfo, pgwMerchantProfile);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwSettlement findSettlementBySetId(Integer settlementId) {
		return settlementDao.findSettlementBySetId(settlementId);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwSettlement> searchRemittenceSettlement(SettlementInfo settlementInfo,
			DataTableRequest dataTableInRQ) {
		return settlementCustomDao.searchRemittenceSettlementList(settlementInfo, dataTableInRQ);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public int findSettlementIdByChannel(String channel, Date date) {
		return settlementDao.findSetIdByChannel(channel, date);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwSettlement> searchRemitSettlementReport(SettlementRptInfo settlementRptInfo,
			DataTableRequest dataTableInRQ) {
		return sttlmntRptInfoDao.searchRemitSettlementReportByPagination(settlementRptInfo, dataTableInRQ);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<PgwSettlement> loadRemitSettleRptInfo(SettlementRptInfo settlementRptInfo) {
		return settlementCustomDao.loadRemitSettleRptInfo(settlementRptInfo);
	}

}