/**
 *
 */
package com.be.controller;


import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlProfile;
import com.be.service.BeTvlProfileService;
import com.be.service.BeTvlService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;
import com.util.pagination.DataTableRequest;
import com.util.pagination.DataTableResults;


/**
 * @author michelle.angela
 *
 */
@Lazy
@RestController
@RequestMapping(BeUrlConstants.TRAVEL)
public class TravelRestController extends AbstractRestController {

	// @Autowired
	// private BeAcctTravellerService acctTravellerSvc;

	@Autowired
	private BeTvlProfileService beTvlProfileSvc;

	@Autowired
	private BeTvlService beTvlSvc;


	@PostMapping(value = BeUrlConstants.TRAVEL + BeUrlConstants.SEARCH_PAGINATION, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DataTableResults<Tvl> searchTravelPaginated(@RequestBody Tvl dto, HttpServletRequest request)
			throws IOException {

		DataTableRequest<Tvl> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) beTvlSvc.getCount(dto);
		List<Tvl> filtered = beTvlSvc.searchTravelPagination(dto, dataTableInRQ);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("ALL DATA: {}", totalCount);
			LOGGER.debug("ALL filtered DATA : {}", filtered);
		}

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.TRAVEL + BeUrlConstants.GET_DETAIL, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public Tvl getTravelDetail(@RequestBody Tvl dto, HttpServletRequest request) throws IOException {
		return JsonUtil.transferToObject(beTvlSvc.searchBeTravel(dto), Tvl.class);
	}


	@PostMapping(value = BeUrlConstants.SEARCH_ATTENDANCE_PAGINATION, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DataTableResults<TvlProfile> searchBeTvlProfilePagination(@RequestBody TvlProfile dto,
			HttpServletRequest request) throws IOException {

		DataTableRequest<TvlProfile> dataTableInRQ = new DataTableRequest<>(request.getParameterMap());
		int totalCount = (int) beTvlProfileSvc.getCount(dto);
		List<TvlProfile> filtered = beTvlProfileSvc.searchBeTvlProfilePagination(dto, dataTableInRQ);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("ALL DATA: {}", totalCount);
			LOGGER.debug("ALL filtered DATA : {}", filtered);
		}

		return new DataTableResults<>(dataTableInRQ, totalCount, filtered);
	}


	@PostMapping(value = BeUrlConstants.GET_MC_ATTENDANCE_DETAIL, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public TvlProfile getMcAttendanceDetail(@RequestBody TvlProfile dto, HttpServletRequest request)
			throws IOException {
		return JsonUtil.transferToObject(beTvlProfileSvc.searchBeTvlProfile(dto), TvlProfile.class);
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public Tvl updateTravel(@RequestBody Tvl dto, HttpServletRequest request) throws IOException {

		if (BaseUtil.isObjNull(dto) && !BaseUtil.isObjNull(dto.getTvlProfId())
				&& !BaseUtil.isObjNull(dto.getStatusId())) {
			throw new BeException(BeErrorCodeEnum.E400C003);
		}

		try {
			return JsonUtil.transferToObject(
					beTvlSvc.updateStatus(dto.getTvlProfId(), dto.getStatusId()), Tvl.class);

		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C002);
		}
	}

}
