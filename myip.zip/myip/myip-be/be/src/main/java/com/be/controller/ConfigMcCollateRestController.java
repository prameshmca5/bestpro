/**
 *
 */
package com.be.controller;


import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.model.BeConfigMcCollate;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.ConfigMcCollate;
import com.be.sdk.model.Country;
import com.be.service.BeConfigMcCollateService;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;


/**
 * @author Atiqah KHairuddin
 *
 */
@Lazy
@RestController
@RequestMapping(BeUrlConstants.CONFIG_MC_COLLATE)
public class ConfigMcCollateRestController extends AbstractRestController {

	@Autowired
	private BeConfigMcCollateService beConfigMcCollateSvc;


	@SuppressWarnings("unchecked")
	@PostMapping(value = BeUrlConstants.GET_CONFIG_MC_COLLATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<ConfigMcCollate> getConfigMcCollate(@RequestBody ConfigMcCollate configMcCollate,
			HttpServletRequest request) throws IOException {
		if (BaseUtil.isObjNull(configMcCollate)) {
			throw new BeException(BeErrorCodeEnum.E400C913);
		}

		BeConfigMcCollate beConfigMcCollate = JsonUtil.transferToObject(configMcCollate, BeConfigMcCollate.class);
		return JsonUtil.transferToList(beConfigMcCollateSvc.searchAllByProperty(beConfigMcCollate), Country.class);
	}

	/*
	 * // ConfigMcAttendance services
	 *
	 * @PostMapping(value = BeUrlConstants.GET_CONFIG_MC_COLLATE, consumes = {
	 * MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	 * public List<BeConfigMcCollate> getAllConfigCollateByStatus(Integer
	 * status, HttpServletRequest request) { return
	 * beConfigMcCollateSvc.searchAllByProperty(status); }
	 */

}
