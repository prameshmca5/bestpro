/**
 *
 */
package com.be.sdk.builder;


import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.AckSlip;
import com.be.sdk.model.PreReg;
import com.util.pagination.DataTableResults;


/**
 * @author mohd.naem
 *
 */
public class RegistrationService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;


	public RegistrationService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}


	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	@Override
	public String url() {
		return url;
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<PreReg> searchPaginated(PreReg dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REGISTER);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<PreReg> searchPaginatedList(PreReg dto, Map<String, Object> pagination) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REGISTER);
		sb.append(BeUrlConstants.SEARCH_PAGINATIONS);
		return restTemplate().postForObject(getServiceURI(sb.toString(), pagination), dto, DataTableResults.class);
	}


	// use to search for unique column only, or else return latest data in db
	public PreReg searchPreReg(PreReg dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REGISTER);
		sb.append(BeUrlConstants.SEARCH);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, PreReg.class);
	}


	public List<PreReg> searchPreRegList(PreReg dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REGISTER);
		sb.append(BeUrlConstants.SEARCH_LIST);
		PreReg[] preRegArray = restTemplate().postForObject(getServiceURI(sb.toString()), dto, PreReg[].class);
		return Arrays.asList(preRegArray);
	}


	public PreReg createPreReg(PreReg dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REGISTER);
		sb.append(BeUrlConstants.CREATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, PreReg.class);
	}


	public PreReg createPreRegPublic(PreReg dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REGISTER);
		sb.append(BeUrlConstants.PUBLIC);
		sb.append(BeUrlConstants.CREATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, PreReg.class);
	}


	public PreReg createPreRegPublicNew(PreReg dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REGISTER);
		sb.append(BeUrlConstants.PUBLIC);
		sb.append(BeUrlConstants.CREATE);
		sb.append(BeUrlConstants.NEW);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, PreReg.class);
	}


	public PreReg updatePreReg(PreReg dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REGISTER);
		sb.append(BeUrlConstants.UPDATE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, PreReg.class);
	}


	public PreReg updateRejStatusPreReg(PreReg dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REGISTER);
		sb.append(BeUrlConstants.UPDATE_REJ);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, PreReg.class);
	}


	public PreReg createPreRegPublicComb(PreReg dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REGISTER);
		sb.append(BeUrlConstants.PUBLIC);
		sb.append(BeUrlConstants.CREATE);
		sb.append(BeUrlConstants.COMBINE);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, PreReg.class);
	}


	public AckSlip searchAcknowledgementSlip(PreReg dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REGISTER);
		sb.append(BeUrlConstants.ACK_SLIP);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, AckSlip.class);
	}
}