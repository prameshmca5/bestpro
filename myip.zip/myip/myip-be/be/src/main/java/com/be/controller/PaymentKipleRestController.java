/**
 * 
 */
package com.be.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.be.core.AbstractRestController;
import com.be.model.BeTvlPaymentKiple;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.PaymentKiple;
import com.be.sdk.model.TvlRefund;
import com.be.service.BeTvlPaymentKipleService;
import com.dm.sdk.exception.DmException;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.MediaType;

/**
 * @author Ramesh Pongianann
 *
 */
@Lazy
@RestController
@RequestMapping(BeUrlConstants.PAYMENT_KIPLE)
public class PaymentKipleRestController extends AbstractRestController {

	@Autowired
	BeTvlPaymentKipleService beTvlPaymentKiplesvc;
	
	
	@PostMapping(value = BeUrlConstants.INFO_ADD, consumes = { MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
 	public PaymentKiple addPaymentKipleInfo(@RequestBody PaymentKiple dto, HttpServletRequest request) throws IOException {
		BeTvlPaymentKiple beTvlPaymentKiple = null;
		try {
			if(BaseUtil.isObjNull(dto)) {
				throw new BeException(BeErrorCodeEnum.I409C001);
			}
			beTvlPaymentKiple = JsonUtil.transferToObject(beTvlPaymentKiplesvc.addPaymentKipleInfo(dto, getCurrUserId(request)), BeTvlPaymentKiple.class);
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		} catch (DmException e) {
			throw new BeException(BeErrorCodeEnum.E500C010);
		}catch (Exception e) {
			throw new BeException(BeErrorCodeEnum.E500C011);
		}
		
		return JsonUtil.transferToObject(beTvlPaymentKiple, PaymentKiple.class);
	}
	
}
