/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.core;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class AbstractService extends GenericAbstract {

}
