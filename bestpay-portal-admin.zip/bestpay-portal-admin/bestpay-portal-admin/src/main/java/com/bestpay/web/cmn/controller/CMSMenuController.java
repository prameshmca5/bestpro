package com.bestpay.web.cmn.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.idm.sdk.model.MenuDto;
import com.bestpay.idm.sdk.pagination.DataTableResults;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bstsb.util.PopupBox;
import com.google.gson.Gson;


@Controller
@RequestMapping(value = PageConstants.PAGE_CMS_MENU)
public class CMSMenuController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CMSMenuController.class);

	private static final String MENU = "menu";

	private static final String MENU_LIST_SCRIPT = "menu-list-script";


	@GetMapping
	public ModelAndView menu(MenuDto menu, BindingResult result, HttpServletRequest request, HttpSession session) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMS_MENU, MENU, null, MENU_LIST_SCRIPT);
		mav.addObject(MENU, menu);
		return mav;
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String searchPaginated(@ModelAttribute(MENU) MenuDto menu, HttpServletRequest request) {
		LOGGER.info("GET PAGINATED MENU LIST....");
		getDefaultMav(PageTemplate.TEMP_CMS_MENU, MENU, null, MENU_LIST_SCRIPT);
		DataTableResults<MenuDto> tasks = getIdmService().searchMenu(menu, getPaginationRequest(request, true));
		LOGGER.info("Task List ==> {}", tasks);
		return new Gson().toJson(tasks);
	}


	@PostMapping(params = "search")
	public ModelAndView search(MenuDto menu, HttpServletRequest request) {
		LOGGER.info("WELCOME MENU LIST ===> Test");
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMS_MENU, MENU, null, MENU_LIST_SCRIPT);
		mav.addObject(MENU, menu);
		return mav;
	}


	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute(MENU) MenuDto menu, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		MenuDto menuLocal = new MenuDto();
		return menu(menuLocal, result, request, session);
	}


	@GetMapping(value = "/new")
	public ModelAndView newMenu(MenuDto menu, BindingResult result, HttpServletRequest request, HttpSession session) {
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_CMS_MENU_NEW);
		MenuDto cmsMenu = new MenuDto();
		mav.addObject(MENU, cmsMenu);
		return mav;
	}


	@PostMapping(value = "/addMenu")
	public ModelAndView addNewMenu(@ModelAttribute(MENU) MenuDto menu, BindingResult result,
			HttpServletRequest request, HttpSession session) {
		ModelAndView mav;
		if (!result.hasErrors()) {
			getIdmService().createMenu(menu);
			String msg;
			if (menu.getMenuCode() != null) {
				msg = messageService.getMessage(MessageConstants.SUCC_UPDATE_MENU);
			} else {
				msg = messageService.getMessage(MessageConstants.SUCC_CREATE_MENU);
			}
			mav = getDefaultMav(PageTemplate.TEMP_CMS_MENU, MENU, null, MENU_LIST_SCRIPT);
			menu = new MenuDto();
			mav.addAllObjects(PopupBox.success(MENU, null, msg));
			mav.addAllObjects(PopupBox.success(null, null, msg, PageConstants.PAGE_CMS_MENU_LST));
		} else {
			mav = new ModelAndView(PageTemplate.TEMP_CMS_MENU_NEW);
		}
		mav.addObject(MENU, menu);
		return mav;
	}


	@PostMapping(value = "/addMenu", params = "reset")
	public ModelAndView resetInfo(@ModelAttribute(MENU) MenuDto menu, BindingResult result, HttpServletRequest request,
			HttpSession session) {
		if (menu.getMenuCode() == null) {
			return newMenu(menu, result, request, session);
		} else {
			return updateMenu(menu.getMenuCode(), request, session);
		}
	}


	@GetMapping(value = "/update/{menuCode}")
	public ModelAndView updateMenu(@PathVariable("menuCode") String menuCode, HttpServletRequest request,
			HttpSession session) {
		MenuDto menu = getIdmService().findMenuByMenuCode(menuCode);
		ModelAndView mav = new ModelAndView(PageTemplate.TEMP_CMS_MENU_NEW);
		mav.addObject(MENU, menu);
		return mav;
	}


	@GetMapping(value = "/delete/{menuCode}")
	public ModelAndView deleteMenu(@PathVariable("menuCode") String menuCode, HttpServletRequest request,
			HttpSession session) {
		boolean isDeleted = getIdmService().deleteMenu(menuCode);
		LOGGER.info("Delete Menu {}", isDeleted);
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_CMS_MENU, MENU, null, MENU_LIST_SCRIPT);
		mav.addAllObjects(PopupBox.success(MENU, null, messageService.getMessage(MessageConstants.SUCC_DELETE_MENU)));
		mav.addAllObjects(PopupBox.success(null, null, messageService.getMessage(MessageConstants.SUCC_DELETE_MENU),
				PageConstants.PAGE_CMS_MENU_LST));
		MenuDto menu = new MenuDto();
		mav.addObject(MENU, menu);
		return mav;
	}

}
