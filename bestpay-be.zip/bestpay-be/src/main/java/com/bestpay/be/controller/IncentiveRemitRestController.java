package com.bestpay.be.controller;


import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.model.RegisterBeneficiaryRequest;
import com.bestpay.be.sdk.model.RegisterBeneficiaryResult;
import com.bestpay.be.sdk.model.RegisterCustomerRequest;
import com.bestpay.be.sdk.model.RegisterCustomerResult;
import com.bstsb.util.MediaType;


@RestController
@RequestMapping(BeUrlConstants.INCENTIVEREMIT_SERVICE)
public class IncentiveRemitRestController extends AbstractRestController {

	private static final Logger logger = LoggerFactory.getLogger(IncentiveRemitRestController.class);
 
	private static final String IR_URL = "https://imtpay.com/mobileAPI/websiteAPI.asmx";

	private static final String AGENT_CODE = "BESTINETHQ";

	private static final String USER_ID = "bestinet";

	private static final String AGENT_SESSION_ID = "bstpmtgateway";

	private static final String PWORD = "BestineT(8)";

	private static final String CONTENT_TYPE = "Content-Type";

	private static final String TEXT_XML = "text/xml";

	private static final String SIGNATURE = "Signature string: {}";

	private static final String FINAL_HASH = "finalHash: {}";

	private static final String AGENT_CODE_XML = "<AGENT_CODE>" + AGENT_CODE + "</AGENT_CODE> ";

	private static final String USER_ID_XML = "<USER_ID>" + USER_ID + "</USER_ID> ";

	private static final String AGENT_SESSION_ID_XML = "<AGENT_SESSION_ID>" + AGENT_SESSION_ID
			+ "</AGENT_SESSION_ID> ";

	private static final String SPACE_STRING = "{} {} {}";

	private static final String CLOSE_SENDERCUSTOMERID = "</SenderCustomerID> ";

	private static final String OPEN_SENDERCUSTOMERID = "<SenderCustomerID>";

	private static final String OPEN_SIGNATURE = "<SIGNATURE>";
 

	@PostMapping(value = "/registerCustomer", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public RegisterCustomerResult registerCustomer(@RequestBody RegisterCustomerRequest registerCustomerRequest) {
		try {
			logger.info("In registerCustomer method");
			if (registerCustomerRequest.getSenderIdType2() == null) {
				registerCustomerRequest.setSenderIdType2("");
			}
			if (registerCustomerRequest.getSenderIdNumber2() == null) {
				registerCustomerRequest.setSenderIdNumber2("");
			}
			URL obj = new URL(IR_URL);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty(CONTENT_TYPE, TEXT_XML);
			String signature = AGENT_CODE + USER_ID + AGENT_SESSION_ID + getSignature(registerCustomerRequest)
					+ PWORD;
			logger.info(SIGNATURE, signature);
			String finalHash = DigestUtils.sha256Hex(signature);
			logger.info(FINAL_HASH, finalHash);
			String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <RegisterCustomer xmlns=\"iRemitWebservice\"> <AGENT_CODE>"
					+ AGENT_CODE + "</AGENT_CODE> <USER_ID>" + USER_ID + "</USER_ID>" + AGENT_SESSION_ID_XML
					+ " <SenderFirstName>" + registerCustomerRequest.getSenderFirstName()
					+ "</SenderFirstName> <SenderMiddleName>" + registerCustomerRequest.getSenderMiddleName()
					+ "</SenderMiddleName>" + " <SenderLastName>" + registerCustomerRequest.getSenderLastName()
					+ "</SenderLastName> <SenderGender>" + registerCustomerRequest.getSenderGender()
					+ "</SenderGender> <SenderAddress>" + registerCustomerRequest.getSenderAddress()
					+ "</SenderAddress> <SenderCity>" + registerCustomerRequest.getSenderCity() + "</SenderCity>"
					+ " <SenderState>" + registerCustomerRequest.getSenderState()
					+ "</SenderState> <SenderCountry>" + registerCustomerRequest.getSenderCountry()
					+ "</SenderCountry> <SenderZipCode>" + registerCustomerRequest.getSenderZipCode()
					+ "</SenderZipCode> <SenderMobile>" + registerCustomerRequest.getSenderMobile()
					+ "</SenderMobile>" + "<SenderIDType>" + registerCustomerRequest.getSenderIDType()
					+ "</SenderIDType> <SenderIDNumber>" + registerCustomerRequest.getSenderIDNumber()
					+ "</SenderIDNumber> <IDIssuePlace>" + registerCustomerRequest.getIdIssuePlace()
					+ "</IDIssuePlace> <IDIssueDate>" + registerCustomerRequest.getIdIssueDate() + "</IDIssueDate>"
					+ "<IDExpireDate>" + registerCustomerRequest.getIdExpireDate()
					+ "</IDExpireDate> <SenderIDType2>" + registerCustomerRequest.getSenderIdType2()
					+ "</SenderIDType2> <SenderIDNumber2>" + registerCustomerRequest.getSenderIdNumber2()
					+ "</SenderIDNumber2> <SenderNativeCountry>" + registerCustomerRequest.getSenderNativeCountry()
					+ "</SenderNativeCountry> " + "<SenderDateOfBirth>"
					+ registerCustomerRequest.getSenderDateOfBirth() + "</SenderDateOfBirth> <SenderOccupation>"
					+ registerCustomerRequest.getSenderOccupation() + "</SenderOccupation> <SenderEmployerName>"
					+ registerCustomerRequest.getSenderEmployerName()
					+ "</SenderEmployerName> <SenderEmployerType>"
					+ registerCustomerRequest.getSenderEmployerType() + "</SenderEmployerType> "
					+ "<SenderFundSource>" + registerCustomerRequest.getSenderFundSource()
					+ "</SenderFundSource> <SenderPhoto>" + registerCustomerRequest.getSenderPhoto()
					+ "</SenderPhoto> <SenderPhoto1>" + registerCustomerRequest.getSenderPhoto1()
					+ "</SenderPhoto1>" + " <SIGNATURE>" + finalHash
					+ "</SIGNATURE> </RegisterCustomer> </soap:Body> </soap:Envelope>";
			con.setDoOutput(true);
			logger.info(xml);

			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(xml);
			wr.flush();
			wr.close();
			String responseStatus = con.getResponseMessage();
			logger.info(responseStatus);
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			String soapBody = response.substring(response.indexOf("<RegisterCustomerResult>"),
					response.indexOf("</RegisterCustomerResult>") + 25);
			logger.info(soapBody);
			JAXBContext jaxbContext = JAXBContext.newInstance(RegisterCustomerResult.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(soapBody);
			RegisterCustomerResult registerCustomer = (RegisterCustomerResult) jaxbUnmarshaller.unmarshal(reader);
			logger.info(registerCustomer.getMessage() + " " + registerCustomer.getCode() + " "
					+ registerCustomer.getSenderCustomerId());
			return registerCustomer;
		} catch (Exception e) {
			logger.info("{} ", e);
		}
		return new RegisterCustomerResult();
	}


	private String getSignature(Object registerCustomerRequest) throws IllegalAccessException, NoSuchFieldException {
		Field[] allFields = registerCustomerRequest.getClass().getDeclaredFields();
		StringBuilder signature = new StringBuilder();

		for (Field each : allFields) {

			Field field = registerCustomerRequest.getClass().getDeclaredField(each.getName());
			field.setAccessible(true);
			Object value = field.get(registerCustomerRequest);
			if (value != null && !field.getName().contains("Photo")) {
				signature.append(value);
			}

		}

		return signature.toString();
	}


	@PostMapping(value = "/registerBeneficiary", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public RegisterBeneficiaryResult registerBeneficiary(
			@RequestBody RegisterBeneficiaryRequest registerBeneficiaryRequest) {
		try {
			logger.info("In registerBeneficiary method");
			URL obj = new URL(IR_URL);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty(CONTENT_TYPE, TEXT_XML);
			String signature = AGENT_CODE + USER_ID + AGENT_SESSION_ID + getSignature(registerBeneficiaryRequest)
					+ PWORD;
			logger.info(SIGNATURE, signature);
			String finalHash = DigestUtils.sha256Hex(signature);
			logger.info(FINAL_HASH, finalHash);
			String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <RegisterBeneficiary xmlns=\"iRemitWebservice\"> "
					+ AGENT_CODE_XML + USER_ID_XML + AGENT_SESSION_ID_XML + OPEN_SENDERCUSTOMERID
					+ registerBeneficiaryRequest.getSenderCustomerId() + CLOSE_SENDERCUSTOMERID
					+ "<BeneficiaryFirstName>" + registerBeneficiaryRequest.getFirstName()
					+ "</BeneficiaryFirstName> " + "<BeneficiaryMiddleName>"
					+ registerBeneficiaryRequest.getMiddleName() + "</BeneficiaryMiddleName> "
					+ "<BeneficiaryLastName>" + registerBeneficiaryRequest.getLastName()
					+ "</BeneficiaryLastName> " + "<BeneficiaryAddress>" + registerBeneficiaryRequest.getAddress()
					+ "</BeneficiaryAddress> " + "<BeneficiaryCity>" + registerBeneficiaryRequest.getCity()
					+ "</BeneficiaryCity> " + "<BeneficiaryCountry>" + registerBeneficiaryRequest.getCountry()
					+ "</BeneficiaryCountry> " + "<BeneficiaryMobile>" + registerBeneficiaryRequest.getMobile()
					+ "</BeneficiaryMobile> " + "<BeneficiaryEmail>" + registerBeneficiaryRequest.getEmail()
					+ "</BeneficiaryEmail> " + "<BeneficeryRelationship>"
					+ registerBeneficiaryRequest.getRelationShip() + "</BeneficeryRelationship> " + OPEN_SIGNATURE
					+ finalHash + "</SIGNATURE> </RegisterBeneficiary> </soap:Body> </soap:Envelope>";
			con.setDoOutput(true);
			logger.info(xml);

			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(xml);
			wr.flush();
			wr.close();
			String responseStatus = con.getResponseMessage();
			logger.info(responseStatus);
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			String soapBody = response.substring(response.indexOf("<RegisterBeneficiaryResult>"),
					response.indexOf("</RegisterBeneficiaryResult>") + 28);
			logger.info(soapBody);
			JAXBContext jaxbContext = JAXBContext.newInstance(RegisterBeneficiaryResult.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(soapBody);
			RegisterBeneficiaryResult registerBeneficiary = (RegisterBeneficiaryResult) jaxbUnmarshaller
					.unmarshal(reader);
			logger.info(SPACE_STRING, registerBeneficiary.getMessage(), registerBeneficiary.getBeneficiarySno(),
					registerBeneficiary.getSenderCustomerId());
			return registerBeneficiary;
		} catch (Exception e) {
			logger.info("{}", e);
		}
		return new RegisterBeneficiaryResult();
	}

 
}
