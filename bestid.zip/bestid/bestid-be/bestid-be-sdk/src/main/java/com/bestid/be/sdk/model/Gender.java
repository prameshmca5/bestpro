package com.bestid.be.sdk.model;

import java.io.Serializable;


public class Gender implements Serializable {

	private static final long serialVersionUID = -7233477964645693155L;
	
	private String genderCd;
	private String genderDesc;
	
	public String getGenderCd() {
		return genderCd;
	}
	
	public void setGenderCd(String genderCd) {
		this.genderCd = genderCd;
	}
	
	public String getGenderDesc() {
		return genderDesc;
	}
	
	public void setGenderDesc(String genderDesc) {
		this.genderDesc = genderDesc;
	}

}
