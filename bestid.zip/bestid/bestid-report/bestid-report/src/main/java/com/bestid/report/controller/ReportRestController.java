package com.bestid.report.controller;


import javax.transaction.Transactional;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestid.report.core.AbstractRestController;
import com.bestid.report.sdk.constants.ReportConstants;


@Transactional
@RestController
@RequestMapping(value = ReportConstants.REPORT_URL)
public class ReportRestController extends AbstractRestController {

}
