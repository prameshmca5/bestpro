/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author michelle.angela
 *
 */
@Entity
@Table(name = "BE_TVL_PAYMENT_INFO")
public class BeTvlPaymentInfo extends AbstractEntity implements Serializable {

	private static final long serialVersionUID = -8576835570208887961L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TVL_PMT_INFO_ID")
	private Integer tvlPmtInfoId;

	@JsonIgnoreProperties("tvlPaymentInfos")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TVL_PMT_DTL_ID")
	private BeTvlPaymentDtl tvlPaymentDtl;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "PMT_BREAKDOWN_ID")
	private BeConfigPaymentBreakdown pmtBreakdown;

	@Column(name = "AMOUNT")
	private double amount;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getTvlPmtInfoId() {
		return tvlPmtInfoId;
	}


	public void setTvlPmtInfoId(Integer tvlPmtInfoId) {
		this.tvlPmtInfoId = tvlPmtInfoId;
	}


	public BeTvlPaymentDtl getTvlPaymentDtl() {
		return tvlPaymentDtl;
	}


	public void setTvlPaymentDtl(BeTvlPaymentDtl tvlPaymentDtl) {
		this.tvlPaymentDtl = tvlPaymentDtl;
	}


	public BeConfigPaymentBreakdown getPmtBreakdown() {
		return pmtBreakdown;
	}


	public void setPmtBreakdown(BeConfigPaymentBreakdown pmtBreakdown) {
		this.pmtBreakdown = pmtBreakdown;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}
