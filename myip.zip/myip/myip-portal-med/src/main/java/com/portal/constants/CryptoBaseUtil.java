package com.portal.constants;

import org.apache.commons.codec.binary.Base64;

import com.util.CryptoUtil;

public class CryptoBaseUtil {
	
	public static String ToUrlSafeBase64(String data)
	{
	    return data.replace('+', '-').replace('/', '_');
	}

	public static String FromUrlSafeBase64(String s)
	{
	    return s.replace('-', '+').replace('_', '/');
//	    return s;
	}
	
	public static String encrypt(Object data,String secret) {
		String encrypt = "";
		String encrptString = "";
		
		try {
			if (data instanceof Integer)
				encrypt = String.valueOf(data);
		    else if(data instanceof Double)
				encrypt = String.valueOf(data);
		    else if(data instanceof Float)
				encrypt = String.valueOf(data);
		    else if(data instanceof String)
				encrypt = String.valueOf(data);
		    	
			encrptString = CryptoUtil.encrypt(encrypt, secret);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return ToUrlSafeBase64(encrptString);
	}
	
	public static String decrypt(String encrypt,String secret) {
		String decryptString ="";
		try {
			decryptString = CryptoUtil.decrypt(FromUrlSafeBase64(encrypt), secret);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return decryptString;
	}
	
	public static Integer decryptInteger(String encrypt,String secret) {
		return Integer.parseInt(decrypt(encrypt, secret));	
	}
	
	public static Double decryptDouble(String encrypt,String secret) {
		return Double.parseDouble(decrypt(encrypt, secret));	
	}
	
	public static Float decryptFloat(String encrypt,String secret) {
		return Float.parseFloat(decrypt(encrypt, secret));	
	}
}
