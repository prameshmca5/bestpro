package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;


public class PaymentDtl implements Serializable, IQfCriteria<PaymentDtl> {

	/**
	 *
	 */
	private static final long serialVersionUID = 6723281272583273849L;

	private Integer pmtDtlId;

	private String pmtDtlRefNo;

	private Integer pmtId;

	private String itemId;

	private Double itemAmount;

	private String currency;

	private List<MemberProfile> memberProfileList;

	private Timestamp pmtGwDt;

	private MemberProfile memberProfile;

	private Timestamp createDt;

	private PreReg preReg;

	// private Payment payment;


	public Integer getPmtDtlId() {
		return pmtDtlId;
	}


	public void setPmtDtlId(Integer pmtDtlId) {
		this.pmtDtlId = pmtDtlId;
	}


	public Integer getPmtId() {
		return pmtId;
	}


	public void setPmtId(Integer pmtId) {
		this.pmtId = pmtId;
	}


	public String getItemId() {
		return itemId;
	}


	public void setItemId(String itemId) {
		this.itemId = itemId;
	}


	public Double getItemAmount() {
		return itemAmount;
	}


	public void setItemAmount(Double itemAmount) {
		this.itemAmount = itemAmount;
	}


	public String getCurrency() {
		return currency;
	}


	public void setCurrency(String currency) {
		this.currency = currency;
	}


	public String getPmtDtlRefNo() {
		return pmtDtlRefNo;
	}


	public void setPmtDtlRefNo(String pmtDtlRefNo) {
		this.pmtDtlRefNo = pmtDtlRefNo;
	}


	public List<MemberProfile> getMemberProfileList() {
		return memberProfileList;
	}


	public void setMemberProfileList(List<MemberProfile> memberProfileList) {
		this.memberProfileList = memberProfileList;
	}


	public Timestamp getPmtGwDt() {
		return pmtGwDt;
	}


	public void setPmtGwDt(Timestamp pmtGwDt) {
		this.pmtGwDt = pmtGwDt;
	}


	/**
	 * @return the memberProfile
	 */
	public MemberProfile getMemberProfile() {
		return memberProfile;
	}


	/**
	 * @param memberProfile
	 *             the memberProfile to set
	 */
	public void setMemberProfile(MemberProfile memberProfile) {
		this.memberProfile = memberProfile;
	}


	/**
	 * @return the createDt
	 */
	public Timestamp getCreateDt() {
		return createDt;
	}


	/**
	 * @param createDt
	 *             the createDt to set
	 */
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	/**
	 * @return the preReg
	 */
	public PreReg getPreReg() {
		return preReg;
	}


	/**
	 * @param preReg
	 *             the preReg to set
	 */
	public void setPreReg(PreReg preReg) {
		this.preReg = preReg;
	}

	// /**
	// * @return the payment
	// */
	// public Payment getPayment() {
	// return payment;
	// }
	//
	//
	// /**
	// * @param payment
	// * the payment to set
	// */
	// public void setPayment(Payment payment) {
	// this.payment = payment;
	// }

}
