/**
 * Copyright 2016. Bestinet Sdn. Bhd.
 */
package com.bestpay.pgw.config;


import java.util.Enumeration;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpHeaders;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.dozer.Mapper;
import org.jboss.logging.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.bestpay.idm.sdk.client.IdmServiceClient;
import com.bestpay.idm.sdk.util.AuthCredentials;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.pgw.model.PgwAuditTrail;
import com.bestpay.pgw.model.PgwTransaction;
import com.bestpay.pgw.sdk.constants.PgwErrorCodeEnum;
import com.bestpay.pgw.sdk.exception.PgwException;
import com.bestpay.pgw.sdk.model.PgwAuditTrailDto;
import com.bestpay.pgw.service.PgwAuditTrailService;
import com.bestpay.pgw.service.PgwTransactionService;
import com.bestpay.pgw.util.WebUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 26, 2016
 */
@Aspect
@Component
public class AspectController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AspectController.class);

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	protected Mapper dozerMapper;

	@Autowired
	public PgwAuditTrailService pgwAuditService;

	@Autowired
	IdmServiceClient idmService;

	@Autowired
	protected PgwTransactionService pgwTransactionService;

	private String newline = System.lineSeparator();

	public static final String HEADER_MESSAGE_ID = "X-Message-Id";

	public static final String HEADER_AUTHORIZATION = "Authorization";


	@Pointcut("execution(* " + ConfigConstants.BASE_PACKAGE_CONTROLLER
			+ ".CommonRestController.maxmoneyOrderStatus(..))")
	public void maxmoneyOrderStatus() {
		// controller method
	}


	@Pointcut("execution(* " + ConfigConstants.BASE_PACKAGE_CONTROLLER + ".*.*(..))")
	public void controllerMethods() {
		// controller method
	}


	@Around("controllerMethods()")
	public Object profile(ProceedingJoinPoint pjp) throws Throwable {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();
		StopWatch stopwatch = new StopWatch();
		stopwatch.start();

		String trxnNo = null;

		Object[] obj = pjp.getArgs();
		if (!BaseUtil.isObjNull(obj) && obj.length > 0) {
			trxnNo = BaseUtil.getStr(obj[0]);
		}

		String messageId = request.getHeader(HEADER_MESSAGE_ID);
		String auth = request.getHeader(HttpHeaders.AUTHORIZATION);

		MDC.put("TraceId", messageId);

		StringBuffer sb = new StringBuffer();
		Enumeration<String> en = request.getParameterNames();
		while (en.hasMoreElements()) {
			String name = en.nextElement();
			String[] value = request.getParameterValues(name);
			sb.append(newline + "\t" + name + " = " + value[0]);
		}

		if (auth == null) {
			throw new PgwException(PgwErrorCodeEnum.E400APJ011);
		}

		AuthCredentials authCredentials = AuthCredentials.createCredentialsFromHeader(auth,
				AuthCredentials.TOKEN_TYPE_STATIC);
		String clientId = authCredentials.getClient();
		String className = pjp.getSignature().getDeclaringTypeName();
		String methodName = pjp.getSignature().getName();
		String reqBody = WebUtil.getRequestBody(request.getInputStream());

		StringBuffer sbUrl = new StringBuffer();
		sbUrl.append(request.getMethod()).append(" ").append(request.getRequestURL());
		if (!BaseUtil.isObjNull(request.getQueryString())) {
			sbUrl.append('?').append(request.getQueryString());
		}

		String reqParams = sb.toString();
		sb = new StringBuffer();
		sb.append(newline + newline + newline + "APJ Request received for " + request.getMethod() + " '"
				+ request.getRequestURI() + "'" + newline + newline + newline + "Authorization : " + auth + newline
				+ "X-Message-Id : " + messageId + newline + "Request Parameters : " + reqParams + newline
				+ "Request Body : " + reqBody + newline + newline + "Client Id : " + clientId + newline
				+ "Secret Key : " + authCredentials.getSecKey() + newline + newline + "Service Class : " + className
				+ "." + methodName + newline + "Service Trxn No : " + trxnNo);

		request.setAttribute("aspectLog", sb);
		request.setAttribute("aspectWatch", stopwatch);

		Object output = pjp.proceed();
		sb.append(newline + "Response Success: " + objectMapper.valueToTree(output));
		sb.append(newline + "Response Success! ");
		log(sb, stopwatch);
		return output;
	}


	@AfterThrowing(value = "controllerMethods()", throwing = "error")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable error) {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();

		StringBuffer sb = new StringBuffer();
		sb.append(request.getAttribute("aspectLog"));
		StopWatch stopwatch = (StopWatch) request.getAttribute("aspectWatch");
		sb.append(newline + "Response Fail: " + WebUtil.getStackTrace(error));
		log(sb, stopwatch);
	}


	@AfterReturning(pointcut = "maxmoneyOrderStatus()", returning = "result")
	public void maxMoneyBeforeredirect(JoinPoint joinPoint, Object result) {
		try {

			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
					.getRequest();
			JsonNode node1 = new ObjectMapper().valueToTree(result);
			JsonNode ecode = node1.get("errorCode");
			String errorcde = ecode.asText();
			if (!BaseUtil.isEquals("76", errorcde)) {
				StringBuffer sb = new StringBuffer();
				Enumeration<String> en = request.getParameterNames();
				String orderid = null;
				while (en.hasMoreElements()) {
					String name = en.nextElement();
					String[] value = request.getParameterValues(name);
					sb.append(newline + "\t" + name + " = " + value[0]);
					orderid = value[0];
				}

				StringBuffer sbUrl = new StringBuffer();
				sbUrl.append(request.getMethod()).append(" ").append(request.getRequestURL());
				if (!BaseUtil.isObjNull(request.getQueryString())) {
					sbUrl.append('?').append(request.getQueryString());
				}

				PgwTransaction transaction = pgwTransactionService.findByMerOrderDetails(orderid);

				PgwAuditTrailDto pgwAudit = new PgwAuditTrailDto();
				String reqParams = sb.toString();

				JsonNode node = new ObjectMapper().valueToTree(transaction);
				pgwAudit.setReqData(node.toString());
				pgwAudit.setMessageId("BPAY-MM-SCH");
				pgwAudit.setOrderId(orderid);
				pgwAudit.setRefNo(transaction.getRefId());
				pgwAudit.setTxnNo(transaction.getTransId());
				sb = new StringBuffer();
				sb.append(newline + newline + newline + "FPX Response received for " + request.getMethod() + " '"
						+ request.getRequestURI() + "'" + newline + newline + "Request Parameters : " + reqParams
						+ newline + "Service Trxn No : ");

				savePgwAudit(pgwAudit);
			}
		} catch (Exception e) {
			LOGGER.info("Error in Aspect val : {}", e.getMessage());
		}
	}


	private void log(StringBuffer sb, StopWatch stopwatch) {
		if (!BaseUtil.isObjNull(stopwatch) && stopwatch.isRunning()) {
			stopwatch.stop();
		}
		long millis = !BaseUtil.isObjNull(stopwatch) ? stopwatch.getLastTaskTimeMillis() : 0;
		sb.append(newline + newline + "Process completed within (" + millis + "ms) "
				+ String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(millis),
						TimeUnit.MILLISECONDS.toMinutes(millis)
								- TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)),
						TimeUnit.MILLISECONDS.toSeconds(millis)
								- TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis))));
		sb.append(newline + newline + newline + newline);
		String str = sb.toString();
		LOGGER.info(str);
	}


	private void savePgwAudit(PgwAuditTrailDto pgwAudit) {
		try {
			PgwAuditTrail p = dozerMapper.map(pgwAudit, PgwAuditTrail.class);
			p.setCreateId("system");
			pgwAuditService.create(p);
		} catch (Exception e1) {
			LOGGER.info(e1.getMessage());
		}
	}

}