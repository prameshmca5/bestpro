package com.bestpay.be.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.config.ConfigConstants;
import com.bestpay.be.core.AbstractService;
import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.dao.RefBankRepository;
import com.bestpay.be.model.RefBank;
import com.bestpay.be.sdk.constants.BeCacheConstants;
import com.bestpay.be.util.QualifierConstants;


@Service(QualifierConstants.REF_BANK_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_BANK_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
@Transactional
public class RefBankService extends AbstractService<RefBank> {

	@Autowired
	private RefBankRepository refBankRepository;


	@Cacheable(key = ConfigConstants.CACHE_JAVA_FILE
			+ ".CACHE_KEY_BANK_ALL", unless = "#result != null and #result.size() == 0")
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	@Override
	public List<RefBank> findAll() {
		return refBankRepository.findAll();
	}


	@Override
	public GenericRepository<RefBank> primaryDao() {
		return refBankRepository;
	}

}