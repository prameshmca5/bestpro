/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.be.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwMerchantCompany;
import com.bestpay.be.model.PgwMerchantCompanyBankDetails;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.MerCompBankDetails;
import com.bestpay.be.sdk.model.MerCompany;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;


/**
 * @author Atiqah Khairuddin
 * @since March 25, 2019
 */
@RestController
@RequestMapping(BeUrlConstants.MERCHANT_COMPANY)
public class MerchantCompanyRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MerchantCompanyRestController.class);

	String skipValues = "[-+.^:,()*@/]";

	@Autowired
	protected ReferenceRestController referenceRestController;


	@PostMapping(value = BeUrlConstants.MERCHANT_COMPANY_PAGINATION, consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DataTableResults<MerCompany> searchMerchantCompanyPaginated(@Valid @RequestBody MerCompany merchantCompany,
			HttpServletRequest request) {
		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwMerchantCompany> result = pgwMerchantCompanyService.searchMerchantCompany(merchantCompany,
				dataTableInRQ);
		DataTableResults<MerCompany> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			dataTableInResp.setDraw(result.getDraw());
			dataTableInResp.setError(result.getError());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<MerCompany> bpLst = new ArrayList<>();
				for (PgwMerchantCompany bbp : result.getData()) {
					MerCompany trustee = dozerMapper.map(bbp, MerCompany.class);
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		LOGGER.info("Merchant company referral registration = {}", dataTableInResp.getData());
		return dataTableInResp;
	}


	@GetMapping(consumes = { MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MerCompany getCompByCompanyId(@RequestParam(value = "companyId", required = false) Integer companyId) {
		PgwMerchantCompany merchantCompany = super.pgwMerchantCompanyService.findCompanyByCompanyId(companyId);

		MerCompany compRef = new MerCompany();
		if (!BaseUtil.isObjNull(merchantCompany)) {
			compRef = dozerMapper.map(merchantCompany, MerCompany.class);
		}
		return compRef;
	}


	@PostMapping(value = BeUrlConstants.CREATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerCompany create(@Valid @RequestBody MerCompany merCompany, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		if (merCompany == null) {// restriction null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}

		PgwMerchantCompany pgwMerchantCompany = new PgwMerchantCompany();

		String compRefId = null;
		compRefId = super.genUserName(merCompany.getCompanyName().replaceAll(skipValues, ""));

		pgwMerchantCompany.setCompRefId(compRefId);
		pgwMerchantCompany.setCompanyName(merCompany.getCompanyName());
		pgwMerchantCompany.setEmail(merCompany.getEmail());
		pgwMerchantCompany.setPhone(merCompany.getPhone());
		pgwMerchantCompany.setCountry(merCompany.getCountry());
		pgwMerchantCompany.setAddress1(merCompany.getAddress1());
		pgwMerchantCompany.setAddress2(merCompany.getAddress2());
		pgwMerchantCompany.setAddress3(merCompany.getAddress3());
		pgwMerchantCompany.setAddress3(merCompany.getAddress3());
		if (BaseUtil.isEquals(merCompany.getCountry(), "MYS")) {
			pgwMerchantCompany.setState(merCompany.getStateMy());
			pgwMerchantCompany.setCity(merCompany.getCityMy());
		} else {
			pgwMerchantCompany.setState(merCompany.getStateNonMy());
			pgwMerchantCompany.setCity(merCompany.getCityNonMy());
		}

		pgwMerchantCompany.setPostcode(merCompany.getPostcode());
		pgwMerchantCompany.setPicName(merCompany.getPicName());
		pgwMerchantCompany.setPicEmail(merCompany.getPicEmail());
		pgwMerchantCompany.setPicPhone(merCompany.getPicPhone());
		if ((merCompany.getProtocolCallbackUrl() != null) && (merCompany.getCallbackUrl() != null)) {
			pgwMerchantCompany.setCallbackUrl(merCompany.getProtocolCallbackUrl() + merCompany.getCallbackUrl());
		}
		pgwMerchantCompany.setCreateId(merCompany.getCreateId());
		super.pgwMerchantCompanyService.create(pgwMerchantCompany);

		MerCompany restr = new MerCompany();
		PgwMerchantCompany pgwMerComp = super.pgwMerchantCompanyService
				.findCompanyByCompRefId(pgwMerchantCompany.getCompRefId());
		if (!BaseUtil.isObjNull(pgwMerComp)) {
			restr = dozerMapper.map(pgwMerComp, MerCompany.class);
		}
		return restr;
	}


	@GetMapping(value = "/{compRefId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerCompany getCompanyByCompRefId(@PathVariable String compRefId) {

		PgwMerchantCompany pgwMerchantCompany = super.pgwMerchantCompanyService.findCompanyByCompRefId(compRefId);

		MerCompany merCompany = new MerCompany();
		if (!BaseUtil.isObjNull(pgwMerchantCompany)) {
			merCompany = dozerMapper.map(pgwMerchantCompany, MerCompany.class);
		}

		if (BaseUtil.isEqualsCaseIgnore(merCompany.getCountry(), "MYS")) {
			merCompany.setStateMy(merCompany.getState());
			merCompany.setCityMy(merCompany.getCity());
		} else {
			merCompany.setStateNonMy(merCompany.getState());
			merCompany.setCityNonMy(merCompany.getCity());
		}

		return merCompany;
	}


	@PostMapping(value = BeUrlConstants.UPDATE, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerCompany updateMerchantCompany(@Valid @RequestBody MerCompany merCompany, HttpServletRequest request,
			HttpServletResponse response) throws BeException {

		LOGGER.info("Create new merchant profile ... ");
		if (merCompany == null) {// merchantCompany null
			throw new BeException(BeErrorCodeEnum.E404BLC002);
		}

		PgwMerchantCompany pgwMerchantCompany = super.pgwMerchantCompanyService
				.findCompanyByCompRefId(merCompany.getCompRefId());

		if (!BaseUtil.isObjNull(pgwMerchantCompany)) {
			pgwMerchantCompany.setCompanyName(merCompany.getCompanyName());
			pgwMerchantCompany.setEmail(merCompany.getEmail());
			pgwMerchantCompany.setPhone(merCompany.getPhone());
			pgwMerchantCompany.setCountry(merCompany.getCountry());
			pgwMerchantCompany.setAddress1(merCompany.getAddress1());
			pgwMerchantCompany.setAddress2(merCompany.getAddress2());
			pgwMerchantCompany.setAddress3(merCompany.getAddress3());
			pgwMerchantCompany.setAddress3(merCompany.getAddress3());
			if (BaseUtil.isEquals(merCompany.getCountry(), "MYS")) {
				pgwMerchantCompany.setState(merCompany.getStateMy());
				pgwMerchantCompany.setCity(merCompany.getCityMy());
			} else {
				pgwMerchantCompany.setState(merCompany.getStateNonMy());
				pgwMerchantCompany.setCity(merCompany.getCityNonMy());
			}

			pgwMerchantCompany.setPostcode(merCompany.getPostcode());
			pgwMerchantCompany.setPicName(merCompany.getPicName());
			pgwMerchantCompany.setPicEmail(merCompany.getPicEmail());
			pgwMerchantCompany.setPicPhone(merCompany.getPicPhone());
			if ((merCompany.getProtocolCallbackUrl() != null) && (merCompany.getCallbackUrl() != null)) {
				pgwMerchantCompany
						.setCallbackUrl(merCompany.getProtocolCallbackUrl() + merCompany.getCallbackUrl());
			}
			pgwMerchantCompany.setUpdateId(merCompany.getUpdateId());
			super.pgwMerchantCompanyService.update(pgwMerchantCompany);
		} else {
			throw new BeException(BeErrorCodeEnum.I404APJ110);
		}

		MerCompany merComp = new MerCompany();
		PgwMerchantCompany pgwmerComp = super.pgwMerchantCompanyService
				.findCompanyByCompanyId(merCompany.getCompanyId());
		if (!BaseUtil.isObjNull(pgwmerComp)) {
			merComp = dozerMapper.map(pgwmerComp, MerCompany.class);
		}
		return merComp;
	}


	@GetMapping(value = BeUrlConstants.CNT_MER_STATUS, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<String> getCountByMerchantStatus(HttpServletRequest request) {
		return pgwMerchantProfileService.getCountByStatus();
	}


	@GetMapping(value = BeUrlConstants.GET_COMP_REF_BANK_DETAILS + "/{compRefId}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public MerCompBankDetails getCompRefBankDetailsByCompRefId(@PathVariable String compRefId,
			HttpServletRequest request) {
		PgwMerchantCompanyBankDetails pgwMerchantCompanyBankDetails = super.pgwMerchantCompanyBankDetailsService
				.findBeneficiaryByCompRefId(compRefId);
		if (pgwMerchantCompanyBankDetails != null) {
			return dozerMapper.map(pgwMerchantCompanyBankDetails, MerCompBankDetails.class);
		}
		return null;
	}


	@GetMapping(value = BeUrlConstants.GET_MER_COMP_LIST, consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public List<MerCompany> getMerchantCompanyList(HttpServletRequest request) {
		List<PgwMerchantCompany> pgwMerchantCompanyList = super.pgwMerchantCompanyService.getMerchantCompanyList();
		List<MerCompany> merchantCompanyList = new ArrayList<>();
		for (PgwMerchantCompany pgwMerchantCompany : pgwMerchantCompanyList) {
			MerCompany merCompany = dozerMapper.map(pgwMerchantCompany, MerCompany.class);
			merchantCompanyList.add(merCompany);
		}
		return merchantCompanyList;
	}

}
