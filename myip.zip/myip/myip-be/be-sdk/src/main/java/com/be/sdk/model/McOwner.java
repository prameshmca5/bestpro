/**
 * 
 */
package com.be.sdk.model;

import java.io.Serializable;

/**
 * @author michelle.angela
 *
 */
public class McOwner implements Serializable {

	private static final long serialVersionUID = -4786201487760622449L;

	private Integer mcOwnerId;

	private McProfile mcProfile;
	 
	private Metadata mcTypeMtdt;
	
	private String fullName;
	
	private String contactNo;
	
	private String email;
	
	private Boolean isActive;

	public Integer getMcOwnerId() {
		return mcOwnerId;
	}

	public void setMcOwnerId(Integer mcOwnerId) {
		this.mcOwnerId = mcOwnerId;
	}

	public McProfile getMcProfile() {
		return mcProfile;
	}

	public void setMcProfile(McProfile mcProfile) {
		this.mcProfile = mcProfile;
	}

	public Metadata getMcTypeMtdt() {
		return mcTypeMtdt;
	}

	public void setMcTypeMtdt(Metadata mcTypeMtdt) {
		this.mcTypeMtdt = mcTypeMtdt;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
}
