/**
 * Copyright 2018 Bestinet Sdn Bhd
 */
package com.bestpay.web.idm.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.form.MerchantLogoPaymentSettingForm;
import com.bestpay.web.util.ValidationUtil;

/**
 * @author Afif Saman
 * @since July 17, 2018
 */
@Component("payPageSettingValidator")
public class PayPageSettingValidator extends AbstractController implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return MerchantLogoPaymentSettingForm.class.equals(clazz);
	}

	@Override
	public void validate(Object object, Errors errors) {
		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "verifyKey", MessageConstants.ERROR_FIELDS_VERIFY_KEY);
		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "returnUrl", MessageConstants.ERROR_FIELDS_RETURN_URL);
		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "callbackUrl", MessageConstants.ERROR_FIELDS_CALLBACK_URL);
	}
}
