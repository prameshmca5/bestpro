/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.builder;


import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bestpay.pgw.sdk.client.PgwRestTemplate;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
public abstract class AbstractService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractService.class);


	public abstract Properties prop();


	public abstract String url();


	protected String getServiceURI(String serviceName) {
		if (serviceName.contains("${prefix}")) {
			serviceName = serviceName.replace("${prefix}", prop().getProperty("prefix"));
		}
		if (serviceName.contains("${version}")) {
			serviceName = serviceName.replace("${version}", prop().getProperty("version"));
		}
		String uri = url() + serviceName;
		LOGGER.info("Service Rest URL: {}", uri);
		return uri;
	}


	public PgwRestTemplate restTemplate() {
		return null;
	}

}
