
function resetSearching() {
	$('#cmpnyRegNoId').val('');
}

$(document).ready(function() {	
	$('#tblSubscriberList').dataTable({
			dom : '<"top"i>tr<"bottom"p><"clear">',
			responsive: true
	});
	
	
	$('#tblSubscriberList tbody').on('click', 'tr', function () {
		
	});
	
	$('#tblSubscriberList tbody').on( 'mouseover', 'tr', function () {
		
    });
})