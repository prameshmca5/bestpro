/**
 * Copyright 2019. Bestinet Sdn Bhd
 */

package com.bestid.web.cmn.controller;


import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestid.be.sdk.model.RefBidConfig;
import com.bestid.core.AbstractController;
import com.bestid.web.util.constants.PageConstants;
import com.bestid.web.util.constants.PageTemplate;
import com.bstsb.util.BaseUtil;
import com.bstsb.util.PopupBox;
import com.bstsb.util.pagination.DataTableResults;
import com.google.gson.Gson;


@Controller
@RequestMapping(value = PageConstants.PAGE_MAINTENANCE)
public class MaintenanceController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MaintenanceController.class);

	private static final String PORTAL_MODULE = "maintenance";

	private static final String PORTAL_TRANS_ID = "maintenance-bid-config";

	private static final String PORTAL_SCRIPT = "maintenance-bid-config-script";

	private static final String PORTAL_SCRIPT_JS = "maintenance-js";

	private static final String CREATE = "create";

	private static final String CONFIG = "refBidConfig";

	private static final String DATA_CREATED_SUCCESS = "Record Created Success";

	private static final String DATA_CREATED_UNSUCCESS = "Record Already Exist";

	private static final String DATA_UPDATED_SUCCESS = "Record Update Success";

	private static final String DATA_DELETED_SUCCESS = "Record Delete Success";


	@GetMapping(value = PageConstants.PAGE_BID_CONFIG)
	public ModelAndView listViewBidConfig(@ModelAttribute RefBidConfig config, BindingResult result,
			HttpServletRequest request) {
		ModelAndView mav = getDefaultMav(PageTemplate.BID_CONFIG, PORTAL_MODULE, PORTAL_TRANS_ID, PORTAL_SCRIPT,
				PORTAL_SCRIPT_JS);

		mav.addObject(CONFIG, config);
		return mav;
	}


	// search
	@PostMapping(value = PageConstants.PAGE_BID_CONFIG)
	public ModelAndView searchBidConfig(@ModelAttribute RefBidConfig config, BindingResult result,
			HttpServletRequest request) {

		return listViewBidConfig(config, result, request);
	}


	// reset
	@PostMapping(value = PageConstants.PAGE_BID_CONFIG, params = "reset")
	public ModelAndView resetBidConfig(@ModelAttribute RefBidConfig config, BindingResult result,
			HttpServletRequest request) {

		ModelAndView mav = listViewBidConfig(new RefBidConfig(), result, request);
		mav.addObject("isView", false);
		return mav;
	}


	// paginated
	@GetMapping(value = PageConstants.PAGE_BID_CONFIG + "/paginated")
	public @ResponseBody String maintenanceBidConfig(@ModelAttribute RefBidConfig config, HttpServletRequest request) {
		DataTableResults<RefBidConfig> task = getBeService().maintenanceService().listBidConfigPaginated(config,
				getPaginationRequest(request, true));

		return new Gson().toJson(task);
	}


	// edit form
	@GetMapping(value = PageConstants.PAGE_BID_CONFIG + "/{configId}")
	public ModelAndView detailsBidConfig(@PathVariable String configId, @ModelAttribute RefBidConfig config,
			BindingResult result, HttpServletRequest request) {

		ModelAndView mav = getDefaultMav(PageTemplate.BID_CONFIG_EDIT, PORTAL_MODULE, PORTAL_TRANS_ID, null,
				PORTAL_SCRIPT_JS);

		if (!BaseUtil.isEqualsCaseIgnore(configId, CREATE)) {
			Integer intconfigId = config.getConfigId();
			config = dozerMapper.map(getBeService().maintenanceService().getConfigById(intconfigId),
					RefBidConfig.class);
		}
		mav.addObject("isView", false);
		mav.addObject(CONFIG, config);
		return mav;
	}


	// register form
	@GetMapping(value = PageConstants.PAGE_BID_CONFIG_REG)
	public ModelAndView viewBidConfig(@ModelAttribute RefBidConfig config, BindingResult result,
			HttpServletRequest request) {
		ModelAndView mav = getDefaultMav(PageTemplate.BID_CONFIG_EDIT, PORTAL_MODULE, null, null, PORTAL_SCRIPT_JS);
		mav.addObject("isView", true);
		mav.addObject(CONFIG, config);
		return mav;
	}


	// create
	@PostMapping(value = PageConstants.PAGE_BID_CONFIG + "/{configId}", params = "createData")
	public ModelAndView createDataBidConfig(@PathVariable String configId,
			@RequestParam(required = false, value = "createData") String createData,
			@Valid @ModelAttribute("config") RefBidConfig config, BindingResult result, HttpServletRequest request) {
		ModelAndView mav = getDefaultMav(PageTemplate.BID_CONFIG, PORTAL_MODULE, null, null, PORTAL_SCRIPT_JS);

		try {

			getBeService().maintenanceService().createBidConfig(config);
			mav.addAllObjects(PopupBox.success(null, "Success", messageService.getMessage(DATA_CREATED_SUCCESS),
					PageConstants.PAGE_MAINTENANCE + PageConstants.PAGE_BID_CONFIG));

		} catch (Exception e) {

			mav.addAllObjects(PopupBox.error(null, "Error", messageService.getMessage(DATA_CREATED_UNSUCCESS),
					PageConstants.PAGE_MAINTENANCE + PageConstants.PAGE_BID_CONFIG + "/register"));

		}

		mav.addObject(CONFIG, config);
		return mav;

	}


	// update
	@PostMapping(value = PageConstants.PAGE_BID_CONFIG + "/{configId}", params = "updateData")
	public ModelAndView updateDataBidConfig(@RequestParam(required = false, value = "updateData") String updateData,
			@Valid @ModelAttribute("config") RefBidConfig config, BindingResult result, HttpServletRequest request) {
		getDefaultMav(PageTemplate.BID_CONFIG, PORTAL_MODULE, null, null, PORTAL_SCRIPT_JS);
		getBeService().maintenanceService().updateBidConfig(config);
		ModelAndView mav = listViewBidConfig(new RefBidConfig(), result, request);
		mav.addAllObjects(PopupBox.success(null, messageService.getMessage(DATA_UPDATED_SUCCESS)));
		return mav;
	}


	// reset data
	@PostMapping(value = PageConstants.PAGE_BID_CONFIG + "/{configId}", params = "resetData")
	public ModelAndView resetDataBidConfig(@RequestParam(required = false, value = "resetData") String resetData,
			@PathVariable(value = "configId") String id, RefBidConfig config, BindingResult result,
			HttpServletRequest request) {

		ModelAndView mav = detailsBidConfig(id, config, result, request);
		mav.addObject("isView", false);
		return mav;

	}


	// delete data
	@PostMapping(value = PageConstants.PAGE_BID_CONFIG + "/{configId}", params = "deleteData")
	public ModelAndView deleteDataBidConfig(@RequestParam(required = false, value = "deleteData") String deleteData,
			@PathVariable(value = "configId") String id, RefBidConfig config, BindingResult result,
			HttpServletRequest request) {

		getBeService().maintenanceService().deleteBidConfig(config);

		ModelAndView mav = listViewBidConfig(new RefBidConfig(), result, request);
		mav.addAllObjects(PopupBox.success(null, messageService.getMessage(DATA_DELETED_SUCCESS)));
		mav.addObject("isView", false);
		return mav;
	}
}
