/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.RefBankFpxRepository;
import com.bestpay.pgw.model.RefBank;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.pgw.util.QualifierConstants;
 

/**
 * @author Sridhar Kapidi
 * @since 20/11/2017
 */
@Service(QualifierConstants.REF_BANK_FPX_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_BANK_FPX_SVC)
@Transactional
public class RefBankService extends AbstractService<RefBank>{

	@Autowired
	private RefBankFpxRepository refBankFpxDao;
	
	@Override
	public GenericRepository<RefBank> primaryDao() {
		return refBankFpxDao;
	}
	
	public RefBank findByBankCode(String bankCode){
		List<RefBank> lst = refBankFpxDao.findByBankCode(bankCode);//should be get only one record
		if(BaseUtil.isListNull(lst)){
			return null;
		}
		return lst.get(0);
	}
	
	public List<RefBank> findByBankCodeList(List<String> bankCode, String type){
		return  refBankFpxDao.findByBankCodeList(bankCode, type);
	}

}