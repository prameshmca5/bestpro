/**
 * 
 */
package com.be.sdk.builder;

import java.util.Map;

import com.be.sdk.client.BeRestTemplate;
import com.be.sdk.constants.BeUrlConstants;
import com.be.sdk.model.ConfigPaymentStage;
import com.be.sdk.model.Payment;
import com.be.sdk.model.PaymentKiple;
import com.util.pagination.DataTableResults;

/**
 * @author Ramesh Pongiannan
 *
 */
public class PaymentKipleService extends AbstractService {

	private BeRestTemplate restTemplate;

	private String url;
	
	public PaymentKipleService(BeRestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
	}
	
	@Override
	public BeRestTemplate restTemplate() {
		return restTemplate;
	}

	@Override
	public String url() {
		return url;
	}

 	public PaymentKiple addPaymentKipleInfo(PaymentKiple dto) {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT_KIPLE);
		sb.append(BeUrlConstants.INFO_ADD);
		return restTemplate().postForObject(getServiceURI(sb.toString()), dto, PaymentKiple.class);
	}
}
