/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.util.constants.BaseConstants;
import com.util.serializer.JsonDateDeserializer;
import com.util.serializer.JsonDateSerializer;


/**
 * @author michelle.angela
 *
 */
public class AcctProfile implements Serializable, IQfCriteria<AcctProfile> {

	private static final long serialVersionUID = 4484528769852221123L;

	private Integer acctProfId;

	private String fullName;

	private String email;

	private String contactNo;

	private String gender;

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BaseConstants.DT_YYYY_MM_DD_SLASH)
	private Date dob;

	private Country nationality;

	private AcctPassport acctPassport;

	private Country birthPlace;

	private Country residentPlace;

	private String addr1;

	private String addr2;

	private String addr3;

	private String addr4;

	private String cityDesc;

	private String stateDesc;

	private Country country;

	private String zipcode;

	private String emrgncyCntctName;

	private String emrgncyCntctNo;

	private Metadata ecRelationMtdt;

	private Metadata acctTypeMtdt;

	private String createId;

	private Timestamp createDt;

	private boolean isView;

	private Metadata appsMtdt;


	public Integer getAcctProfId() {
		return acctProfId;
	}


	public void setAcctProfId(Integer acctProfId) {
		this.acctProfId = acctProfId;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender.toUpperCase();
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public Country getNationality() {
		return nationality;
	}


	public void setNationality(Country nationality) {
		this.nationality = nationality;
	}


	public AcctPassport getAcctPassport() {
		return acctPassport;
	}


	public void setAcctPassport(AcctPassport acctPassport) {
		this.acctPassport = acctPassport;
	}


	public Country getBirthPlace() {
		return birthPlace;
	}


	public void setBirthPlace(Country birthPlace) {
		this.birthPlace = birthPlace;
	}


	public Country getResidentPlace() {
		return residentPlace;
	}


	public void setResidentPlace(Country residentPlace) {
		this.residentPlace = residentPlace;
	}


	public String getAddr1() {
		return addr1;
	}


	public void setAddr1(String addr1) {
		this.addr1 = addr1.toUpperCase();
	}


	public String getAddr2() {
		return addr2;
	}


	public void setAddr2(String addr2) {
		this.addr2 = addr2.toUpperCase();
	}


	public String getAddr3() {
		return addr3;
	}


	public void setAddr3(String addr3) {
		this.addr3 = addr3.toUpperCase();
	}


	public String getAddr4() {
		return addr4;
	}


	public void setAddr4(String addr4) {
		this.addr4 = addr4.toUpperCase();
	}


	public String getCityDesc() {
		return cityDesc;
	}


	public void setCityDesc(String cityDesc) {
		this.cityDesc = cityDesc.toUpperCase();
	}


	public String getStateDesc() {
		return stateDesc;
	}


	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc.toUpperCase();
	}


	public Country getCountry() {
		return country;
	}


	public void setCountry(Country country) {
		this.country = country;
	}


	public String getZipcode() {
		return zipcode;
	}


	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}


	public String getEmrgncyCntctName() {
		return emrgncyCntctName;
	}


	public void setEmrgncyCntctName(String emrgncyCntctName) {
		this.emrgncyCntctName = emrgncyCntctName.toUpperCase();
	}


	public String getEmrgncyCntctNo() {
		return emrgncyCntctNo;
	}


	public void setEmrgncyCntctNo(String emrgncyCntctNo) {
		this.emrgncyCntctNo = emrgncyCntctNo;
	}


	public Metadata getEcRelationMtdt() {
		return ecRelationMtdt;
	}


	public void setEcRelationMtdt(Metadata ecRelationMtdt) {
		this.ecRelationMtdt = ecRelationMtdt;
	}


	public Metadata getAcctTypeMtdt() {
		return acctTypeMtdt;
	}


	public void setAcctTypeMtdt(Metadata acctTypeMtdt) {
		this.acctTypeMtdt = acctTypeMtdt;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public boolean isView() {
		return isView;
	}


	public void setView(boolean isView) {
		this.isView = isView;
	}


	public Metadata getAppsMtdt() {
		return appsMtdt;
	}


	public void setAppsMtdt(Metadata appsMtdt) {
		this.appsMtdt = appsMtdt;
	}

}
