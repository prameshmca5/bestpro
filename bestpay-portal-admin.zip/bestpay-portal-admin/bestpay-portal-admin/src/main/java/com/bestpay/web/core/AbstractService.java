/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.core;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class AbstractService extends GenericAbstract {

}
