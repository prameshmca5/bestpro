/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.client;


import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.http.impl.client.CloseableHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bestpay.be.sdk.builder.CommonService;
import com.bestpay.be.sdk.builder.ReferenceService;
import com.bestpay.be.sdk.constants.BeErrorCodeEnum;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.constants.ServiceConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.ApsProfile;
import com.bestpay.be.sdk.model.ApsProfileResponse;
import com.bestpay.be.sdk.model.BlacklistInfo;
import com.bestpay.be.sdk.model.Category;
import com.bestpay.be.sdk.model.Channel;
import com.bestpay.be.sdk.model.Country;
import com.bestpay.be.sdk.model.IRProfile;
import com.bestpay.be.sdk.model.IRProfileResponse;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.model.MerAccSet;
import com.bestpay.be.sdk.model.MerBusCat;
import com.bestpay.be.sdk.model.MerChanSet;
import com.bestpay.be.sdk.model.MerChanSetWrapper;
import com.bestpay.be.sdk.model.MerCompBankDetails;
import com.bestpay.be.sdk.model.MerCompany;
import com.bestpay.be.sdk.model.MerFraudSet;
import com.bestpay.be.sdk.model.MerGenInfo;
import com.bestpay.be.sdk.model.MerPayPageSet;
import com.bestpay.be.sdk.model.MerRepSet;
import com.bestpay.be.sdk.model.MerRestriction;
import com.bestpay.be.sdk.model.MerSettlementSet;
import com.bestpay.be.sdk.model.MerSubscriptionPlan;
import com.bestpay.be.sdk.model.MerchantBeneficiary;
import com.bestpay.be.sdk.model.MerchantPid;
import com.bestpay.be.sdk.model.PaymentConfig;
import com.bestpay.be.sdk.model.PaymentLinkInfo;
import com.bestpay.be.sdk.model.Provider;
import com.bestpay.be.sdk.model.RefStatus;
import com.bestpay.be.sdk.model.ReferralMultiChannel;
import com.bestpay.be.sdk.model.ServiceCheck;
import com.bestpay.be.sdk.model.SettlementInfo;
import com.bestpay.be.sdk.model.SettlementRptInfo;
import com.bestpay.be.sdk.model.StaticList;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.sdk.model.SubscriptionPlan;
import com.bestpay.be.sdk.model.Ticket;
import com.bestpay.be.sdk.model.Transaction;
import com.bestpay.be.sdk.model.TransactionRptInfo;
import com.bestpay.be.sdk.model.TrxnDocuments;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.UriUtil;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BeServiceClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(BeServiceClient.class);

	private static BeServiceClient instance = null;

	private static BeRestTemplate restTemplate;

	private static Properties prop;

	private String url;

	private String clientId;

	private String token;

	private String authToken;

	private String messageId;

	private int readTimeout;


	private BeServiceClient() {
	}


	public BeServiceClient(String url) {
		this.url = url;
		initialize();
	}


	public BeServiceClient(String url, int readTimeout) {
		this.url = url;
		this.readTimeout = readTimeout;
		initialize();
	}


	public BeServiceClient(String url, String clientId, int readTimeout) {
		this.url = url;
		this.clientId = clientId;
		this.readTimeout = readTimeout;
		initialize();
	}


	private static BeServiceClient getInstance() {
		if (instance == null) {
			instance = new BeServiceClient();
		}

		return instance;
	}


	private static void initialize() {
		restTemplate = new BeRestTemplate();
		loadProperty();
	}


	private BeRestTemplate getRestTemplate() throws BeException {
		CloseableHttpClient httpClient = null;
		if (messageId == null) {
			throw new BeException(BeErrorCodeEnum.E400APJ011);
		}
		if (authToken != null) {
			httpClient = new HttpAuthClient(authToken, messageId, readTimeout).getHttpClient();
		} else {
			httpClient = new HttpAuthClient(clientId, token, messageId, readTimeout).getHttpClient();
		}
		restTemplate.setHttpClient(httpClient);
		return restTemplate;
	}


	private String getServiceURI(String serviceName) {
		if (serviceName.contains("${prefix}")) {
			serviceName = serviceName.replace("${prefix}", prop.getProperty("prefix"));
		}
		if (serviceName.contains("${version}")) {
			serviceName = serviceName.replace("${version}", prop.getProperty("version"));
		}
		String uri = url + serviceName;
		LOGGER.info("Service Rest URL: {} ", uri);
		return uri;
	}


	protected String getServiceURI(String serviceName, Object obj) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);

		JsonNode jnode = mapper.valueToTree(obj);
		boolean isFirst = true;
		StringBuilder sb = new StringBuilder();
		sb.append(getServiceURI(serviceName));

		if (!BaseUtil.isObjNull(obj)) {
			try {
				Map<String, Object> maps = mapper.readValue(jnode.toString(),
						new TypeReference<Map<String, Object>>() {
						});
				for (Map.Entry<String, Object> entry : maps.entrySet()) {
					String mKey = entry.getKey();
					Object mValue = entry.getValue();
					if (!BaseUtil.isObjNull(mValue) && !BaseUtil.isEquals(mKey, "serialVersionUID")) {
						if (isFirst) {
							sb.append("?");
							isFirst = false;
						}
						if (mValue instanceof String) {
							mValue = UriUtil.getVariableValueAsString(mValue);
						}
						sb.append(mKey + "=" + mValue + "&");
					}
				}
			} catch (IOException e) {
				LOGGER.info("context", e);

			}
		}
		return !isFirst ? (sb.toString()).substring(0, sb.length() - 1) : sb.toString();
	}


	private static void loadProperty() {
		prop = new Properties();
		String propFileName = "bestpay-be-sdk.properties";
		InputStream is = getInstance().getClass().getClassLoader().getResourceAsStream(propFileName);
		if (is != null) {
			try {
				prop.load(is);
			} catch (IOException e) {
				LOGGER.error(e.getMessage());
			}
		} else {
			LOGGER.info("NO PROPERTY FOUND");
		}
	}


	public void setClientId(String clientId) {
		this.clientId = clientId;
	}


	public void setToken(String token) {
		this.token = token;
	}


	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}


	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public static void setRestTemplate(BeRestTemplate restTemplate) {
		BeServiceClient.restTemplate = restTemplate;
	}


	public String checkConnection() throws BeException {
		return getRestTemplate().getForObject(getServiceURI(BeUrlConstants.SERVICE_CHECK + "/test"), String.class);
	}


	public ServiceCheck serviceTest() throws BeException {
		return getRestTemplate().getForObject(getServiceURI(BeUrlConstants.SERVICE_CHECK), ServiceCheck.class);
	}


	public ReferenceService reference() throws BeException {
		return new ReferenceService(getRestTemplate(), prop, url);
	}


	public CommonService commonService() throws BeException {
		return new CommonService(getRestTemplate(), prop, url);
	}


	public BeRestTemplate restTemplate() {
		return restTemplate;
	}


	public StaticList getStaticList() throws BeException {
		return reference().all();
	}


	public StaticList getStaticList(String staticlistType) throws BeException {

		StaticList staticLst = new StaticList();

		if (staticlistType.equalsIgnoreCase(ServiceConstants.STAT_LST_CITY)) {
			staticLst.setCityList(reference().findByAllCities());
		} else if (staticlistType.equalsIgnoreCase(ServiceConstants.STAT_LST_RELATIONSHIP)) {
			staticLst.setRelationList(reference().findAllRelationShips());
		}
		return staticLst;
	}


	public List<RefStatus> getRefStatusStaticList(String refCode) throws BeException {
		List<RefStatus> refStatusList = new ArrayList<>();
		if (!BaseUtil.isObjNull(refCode)) {
			refStatusList = reference().getRefStatus(refCode);
		}
		return refStatusList;
	}


	// Transaction Listing
	@SuppressWarnings("unchecked")
	public DataTableResults<Transaction> searchTransList(Transaction transactionList, Map<String, Object> pagination)
			throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRANSACTION);
		sb.append(BeUrlConstants.TRANSACTION_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), transactionList,
				DataTableResults.class);
	}


	// Top 10 Listing
	@SuppressWarnings("unchecked")
	public DataTableResults<Transaction> searchTop10List(Transaction transactionList, Map<String, Object> pagination)
			throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRANSACTION);
		sb.append(BeUrlConstants.TOP10_TRANSLIST);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), transactionList,
				DataTableResults.class);
	}


	/**
	 * Search Settlement Report by pagination
	 *
	 * @param settlementRptInfo
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<SettlementRptInfo> searchSettlementReport(SettlementRptInfo settlementRptInfo,
			Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.STTLMNT_REPORT);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), settlementRptInfo,
				DataTableResults.class);
	}


	/**
	 * Get paginated blacklistListing
	 *
	 * @param blacklistInfo
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<BlacklistInfo> searchBlacklist(BlacklistInfo blacklistInfo, Map<String, Object> pagination)
			throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.BLCKLST);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), blacklistInfo,
				DataTableResults.class);
	}


	/**
	 * Create Blacklist
	 *
	 * @param blacklistInfo
	 * @return @
	 * @throws BeException
	 */
	public BlacklistInfo createBlacklist(BlacklistInfo blacklistInfo) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.BLCKLST);
		sb.append(BeUrlConstants.CREATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), blacklistInfo, BlacklistInfo.class);
	}


	/**
	 * Delete Blacklist
	 *
	 * @param blacklist
	 *             ino
	 * @return @
	 * @throws BeException
	 */
	public boolean deleteBlacklist(String id) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.BLCKLST);
		sb.append("/" + id);
		return getRestTemplate().deleteForObject(getServiceURI(sb.toString()));
	}


	/**
	 * Search Transaction Report Info by pagination
	 *
	 * @param settlementRptInfo
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<TransactionRptInfo> searchTransactionReport(TransactionRptInfo transactionRptInfo,
			Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRANSACTION_REPORT);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), transactionRptInfo,
				DataTableResults.class);
	}


	/**
	 * Search Settlement List by pagination
	 *
	 * @param settlement
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<SettlementInfo> searchsettlement(SettlementInfo settlementInfo,
			Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.SETTLEMENT);
		sb.append(BeUrlConstants.SETTLEMENT_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), settlementInfo,
				DataTableResults.class);
	}


	/**
	 * Search Transaction Report Info list
	 *
	 * @param settlementRptInfo
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	public List<TransactionRptInfo> getTransRptInfo(TransactionRptInfo transactionRptInfo) throws BeException {
		StringBuilder sb = new StringBuilder();

		sb.append(BeUrlConstants.TRANSACTION_REPORT);
		sb.append(BeUrlConstants.TRANS_RPT_INFO);
		TransactionRptInfo[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), transactionRptInfo,
				TransactionRptInfo[].class);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * Search Settlement Report Info list
	 *
	 * @param settlementRptInfo
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	public List<SettlementRptInfo> getSettlementRptInfo(SettlementRptInfo settlementRptInfo) throws BeException {
		StringBuilder sb = new StringBuilder();

		sb.append(BeUrlConstants.STTLMNT_REPORT);
		sb.append(BeUrlConstants.SETTLEMENT_RPT_INFO);
		SettlementRptInfo[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), settlementRptInfo,
				SettlementRptInfo[].class);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * Search Settlements List merchantId, start and end dates
	 *
	 * @param transactionRptInfo
	 * @return @
	 * @throws BeException
	 */

	public List<Transaction> generateSettlements(TransactionRptInfo transactionRptInfo) throws BeException {
		StringBuilder sb = new StringBuilder();

		sb.append(BeUrlConstants.STTLMNT_SET);
		sb.append(BeUrlConstants.MER_STMNS_DETAILS);
		Transaction[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), transactionRptInfo,
				Transaction[].class);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * Create Merchant Account Info
	 *
	 * @param merAccInfo
	 * @return @
	 * @throws BeException
	 */
	public MerAccInfo createMerAccInfo(MerAccInfo merAccInfo) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.CREATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merAccInfo, MerAccInfo.class);
	}


	/**
	 * Search Merchant List by pagination
	 *
	 * @param merchant
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<MerAccInfo> searchmerchant(MerAccInfo merAccInfo, Map<String, Object> pagination)
			throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.MERCHANT_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), merAccInfo,
				DataTableResults.class);
	}


	public MerAccInfo getAccInfoById(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append("/");
		sb.append(merchantId);

		Map<String, Object> params = new HashMap<>();
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerAccInfo.class, params);
	}


	/**
	 * Update Merchant Account Info
	 *
	 * @param merAccInfo
	 * @return @
	 * @throws BeException
	 */
	public MerAccInfo updateMerAccInfo(MerAccInfo merAccInfo) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merAccInfo, MerAccInfo.class);
	}


	public MerAccInfo getMerchantByProfId(Integer merProfId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append("?merProfId={merProfId}");
		Map<String, Object> params = new HashMap<>();
		params.put("merProfId", merProfId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerAccInfo.class, params);
	}


	/**
	 * Update Merchant Channel Setting
	 *
	 * @param merChanSetWrapper
	 * @return @
	 * @throws BeException
	 */

	// get TransactionList by Month
	public List<String> getTransListByMonth(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRANSACTION);
		sb.append(BeUrlConstants.TRANS_MONTHLIST);
		sb.append("/" + merchantId);
		String[] values = getRestTemplate().getForObject(getServiceURI(sb.toString()), String[].class);
		return Arrays.asList(values);
	}


	public String getSumAndCountOfTransOfMonth(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRANSACTION);
		sb.append(BeUrlConstants.TRANS_SUCC_MNTHLY_SUM);
		sb.append("/" + merchantId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), String.class);
	}


	public List<String> getCountByMerchantStatus() throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.CNT_MER_STATUS);
		String[] values = getRestTemplate().getForObject(getServiceURI(sb.toString()), String[].class);
		return Arrays.asList(values);
	}


	public long getTodaysCountSuccessfulTransactions(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRANSACTION);
		sb.append(BeUrlConstants.TRANS_SUCC_TODAY_CNT);
		sb.append("/" + merchantId);
		String value = getRestTemplate().getForObject(getServiceURI(sb.toString()), String.class);
		return Long.valueOf(value);
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<Transaction> getTodaysSuccessfulTransactions(String merchantId,
			Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRANSACTION);
		sb.append(BeUrlConstants.TRANS_SUCC_TODAY_LIST);
		if (merchantId == null) {
			merchantId = "null";
		}
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), merchantId,
				DataTableResults.class);
	}


	@SuppressWarnings("unchecked")
	public DataTableResults<Transaction> getMonthlySuccessfulTransactions(String merchantId,
			Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRANSACTION);
		sb.append(BeUrlConstants.TRANS_SUCC_MNTHLY_LIST);
		if (merchantId == null) {
			merchantId = "null";
		}
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), merchantId,
				DataTableResults.class);
	}


	public double getSumOfBillAmt() throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRANSACTION);
		sb.append(BeUrlConstants.TRANS_SUM_BILLAMT);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), Double.class);
	}


	public List<String> getCountAllStatusOfTickets(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TICKET);
		sb.append(BeUrlConstants.TKT_CNT_ALLSTATUS);
		sb.append("/" + merchantId);
		String[] values = getRestTemplate().getForObject(getServiceURI(sb.toString()), String[].class);
		return Arrays.asList(values);
	}


	public boolean updateChannelSetting(MerChanSetWrapper merChanSetWrapper) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.CHAN_SET);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merChanSetWrapper, boolean.class);
	}


	public MerChanSetWrapper getMerChanSetWrapperById(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.CHAN_SET);
		sb.append("/");
		sb.append(merchantId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerChanSetWrapper.class);
	}


	// Channel Details
	@SuppressWarnings("unchecked")
	public DataTableResults<Channel> searchChannel(Channel channel, Map<String, Object> pagination)
			throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.CHAN_SET);
		sb.append(BeUrlConstants.CHANNEL_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), channel,
				DataTableResults.class);
	}


	// Search Channel Details by Id
	public Channel getChannelById(Integer channelId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.CHAN_SET);
		sb.append(BeUrlConstants.GET_CHANNEL);
		sb.append("/" + channelId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), Channel.class);
	}


	// Search Channel Details by PublicName
	public Channel getChannelByPublicName(String publicName) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.CHAN_SET);
		sb.append(BeUrlConstants.GET_CHANNEL_BYNAME);
		sb.append("/" + publicName);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), Channel.class);
	}


	// AddChannel Details
	public boolean addChannel(Channel channel) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.CHAN_SET);
		sb.append(BeUrlConstants.ADD_CHANNEL);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), channel, boolean.class);
	}


	// Delete Channel
	public boolean deleteChannel(Integer channelId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.CHAN_SET);
		sb.append(BeUrlConstants.DEL_CHANNEL);
		sb.append("/" + channelId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), boolean.class);
	}


	// Transaction Details
	public Transaction getTransDtlsById(String transId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRANSACTION);
		sb.append("/");
		sb.append(transId);

		Map<String, Object> params = new HashMap<>();
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), Transaction.class, params);
	}


	/**
	 * Update Transaction Details - Memo
	 *
	 * @param transaction
	 * @return @
	 * @throws BeException
	 */
	public boolean updateMerTransDtls(Transaction transaction) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRANSACTION);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), transaction, boolean.class);
	}


	public MerPayPageSet getMerPayPageSetById(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAY_PAGE_SET);
		sb.append("/");
		sb.append(merchantId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerPayPageSet.class);
	}


	public boolean updatePaymentPageSetting(MerPayPageSet merPayPageSet) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAY_PAGE_SET);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merPayPageSet, boolean.class);
	}


	/**
	 * Update Merchant General Info
	 *
	 * @param merGenInfo
	 * @return @
	 * @throws BeException
	 */

	public MerGenInfo updateGeneralInfo(MerGenInfo merGenInfo) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_GENG_INFO);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merGenInfo, MerGenInfo.class);
	}


	public MerGenInfo getGenInfoById(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_GENG_INFO);
		sb.append("/");
		sb.append(merchantId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerGenInfo.class);
	}


	/**
	 * Update Merchant Fraud Setting
	 *
	 * @param merFraudSet
	 * @return @
	 * @throws BeException
	 */

	public MerFraudSet updateFraudSet(MerFraudSet merFraudSet) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_FRAUD_SET);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merFraudSet, MerFraudSet.class);
	}


	public MerFraudSet getFraudSetById(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_FRAUD_SET);
		sb.append("/");
		sb.append(merchantId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerFraudSet.class);
	}


	/**
	 * Update Merchant Account Setting
	 *
	 * @param merAccSet
	 * @return @
	 * @throws BeException
	 */

	public MerAccSet updateAccSet(MerAccSet merAccSet) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_SET);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merAccSet, MerAccSet.class);
	}


	public MerAccSet getAccSetById(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_SET);
		sb.append("/");
		sb.append(merchantId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerAccSet.class);
	}


	public MerBusCat getMerBusCatById(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.BUS_CAT);
		sb.append("/");
		sb.append(merchantId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerBusCat.class);
	}


	/**
	 * Update Merchant Business Category
	 *
	 * @param merBusCat
	 * @return boolean @
	 * @throws BeException
	 */
	public boolean updateBusinessCategory(MerBusCat merBusCat) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.BUS_CAT);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merBusCat, boolean.class);
	}


	public List<Category> getLatestCategory() throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_ALL_CAT);
		Category[] catArray = restTemplate().getForObject(getServiceURI(sb.toString()), Category[].class);

		return Arrays.asList(catArray);
	}


	public MerRepSet getMerRepSetById(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.RPT_SET);
		sb.append("/");
		sb.append(merchantId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerRepSet.class);
	}


	/**
	 * Update Merchant Business Category
	 *
	 * @param merRepSet
	 * @return boolean @
	 * @throws BeException
	 */
	public boolean updateReportSetting(MerRepSet merRepSet) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.RPT_SET);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merRepSet, boolean.class);
	}


	/**
	 * Update Merchant Restriction
	 *
	 * @param merChanSetWrapper
	 * @return @
	 * @throws BeException
	 */

	public MerRestriction updateRestriction(MerRestriction merRestriction) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_RESTRICTION);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merRestriction, MerRestriction.class);
	}


	public MerRestriction getRestrictionById(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_RESTRICTION);
		sb.append("/");
		sb.append(merchantId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerRestriction.class);
	}


	public MerSettlementSet getMerSettlementSetById(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.STTLMNT_SET);
		sb.append("/");
		sb.append(merchantId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerSettlementSet.class);
	}


	/**
	 * Update Merchant Settlement Setting
	 *
	 * @param merRepSet
	 * @return boolean @
	 * @throws BeException
	 */
	public boolean updateSettlementSetting(MerSettlementSet merSettlementSet) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.STTLMNT_SET);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merSettlementSet, boolean.class);
	}


	public MerGenInfo getMerchantForBlacklist(String tag, String value) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_GENG_INFO);
		sb.append("?tag={tag}");
		sb.append("&value={value}");
		Map<String, Object> params = new HashMap<>();
		params.put("tag", tag);
		params.put("value", value);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerGenInfo.class, params);
	}


	/**
	 * Search Payment Link by pagination
	 *
	 * @param Payment
	 *             Link
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<PaymentLinkInfo> searchpaymentlink(PaymentLinkInfo paymentLinkInfo,
			Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT_LINK);
		sb.append(BeUrlConstants.PAYMENT_LINK_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), paymentLinkInfo,
				DataTableResults.class);
	}


	/**
	 * Create Payment Link Info
	 *
	 * @param generate
	 * @return @
	 * @throws BeException
	 */
	public PaymentLinkInfo generatePayLinkInfo(PaymentLinkInfo paylinkinfo) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT_LINK);
		sb.append(BeUrlConstants.GENERATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), paylinkinfo, PaymentLinkInfo.class);
	}


	/**
	 * Create Payment Link View Info
	 *
	 * @param view_email_link
	 * @return @
	 * @throws BeException
	 */
	public PaymentLinkInfo getPaylinkByOrderId(String orderId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT_LINK);
		sb.append("/");
		sb.append(orderId);

		Map<String, Object> params = new HashMap<>();
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), PaymentLinkInfo.class, params);
	}


	/**
	 * Create Merchant Subscription Plan
	 *
	 * @param merSubscriptionPlan
	 * @return @
	 * @throws BeException
	 */
	public MerSubscriptionPlan createMerSubPlan(MerSubscriptionPlan merSubscriptionPlan) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_SUBSCRIPTION_PLAN);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merSubscriptionPlan,
				MerSubscriptionPlan.class);
	}


	public MerSubscriptionPlan getMerSubPlanById(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_SUBSCRIPTION_PLAN);
		sb.append("/");
		sb.append(merchantId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerSubscriptionPlan.class);
	}


	/**
	 * Select All merchant List with Status Active
	 *
	 * @param merChanSet
	 *
	 * @param merchantId
	 * @return @
	 * @throws BeException
	 */
	public List<MerAccInfo> getAllMerChantList(MerAccInfo merAccInfo) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.ALL_MER_LIST);
		MerAccInfo[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), merAccInfo,
				MerAccInfo[].class);

		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * Select All merchant List from Payment Setting
	 *
	 *
	 * @param merchantId
	 * @return @
	 * @throws BeException
	 */
	public List<MerPayPageSet> getAllMerChantpaymentList(MerPayPageSet merPayPageSet) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAY_PAGE_SET);
		sb.append(BeUrlConstants.ALL_MER_PAYSET_LIST);
		MerPayPageSet[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), merPayPageSet,
				MerPayPageSet[].class);

		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * Create Settlement View Info
	 *
	 * @param settlement
	 *             view
	 * @return @
	 * @throws BeException
	 */
	public List<Transaction> getTransSettleList(Transaction transaction) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TRANSACTION);
		sb.append(BeUrlConstants.TRANS_SETTLELIST);
		Transaction[] setlmtListValue = getRestTemplate().postForObject(getServiceURI(sb.toString()), transaction,
				Transaction[].class);
		return Arrays.asList(setlmtListValue);
	}


	/**
	 * Select MerchantId with Status Active
	 *
	 * @param merChanSet
	 *
	 * @param merchantId
	 * @return @
	 * @throws BeException
	 */
	public List<MerChanSet> getMerChantWrapperByStatus(MerChanSet merChanSet) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.CHAN_SET);
		sb.append(BeUrlConstants.CHAL_LIST);
		MerChanSet[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), merChanSet,
				MerChanSet[].class);

		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * Search Settlement Report Info list
	 *
	 * @param settlementRptInfo
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	public List<SettlementRptInfo> getSetmtReportInfo(SettlementRptInfo settlementRptInfo) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.SETTLEMENT);
		sb.append(BeUrlConstants.SETTLEMENT_REPORT);
		SettlementRptInfo[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), settlementRptInfo,
				SettlementRptInfo[].class);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * Create Payment Link View Info and send email
	 *
	 * @param view_email_link
	 * @return @
	 * @throws BeException
	 */
	public PaymentLinkInfo paylinkByOrderIdAndSendEmail(String orderId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT_LINK);
		sb.append("/");
		sb.append(orderId);
		sb.append("/email");

		Map<String, Object> params = new HashMap<>();
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), PaymentLinkInfo.class, params);
	}


	/**
	 * Create Ticket
	 *
	 * @param create
	 * @return @
	 * @throws BeException
	 */

	public Ticket createTicket(Ticket ticket) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TICKET);
		sb.append(BeUrlConstants.CREATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), ticket, Ticket.class);
	}


	/**
	 * Get paginated ticketListing
	 *
	 * @param ticket
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<Ticket> searchTicket(Ticket ticket, Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TICKET);
		sb.append(BeUrlConstants.SEARCH_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), ticket,
				DataTableResults.class);
	}


	/**
	 * Get settlement details
	 *
	 * @param setId
	 * @return @
	 * @throws BeException
	 */
	public SettlementInfo getSettlementInfoById(Integer settlementId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.SETTLEMENT);
		sb.append("/");
		sb.append(settlementId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), SettlementInfo.class);
	}


	/**
	 * Update Settlement Status
	 *
	 * @param settlementInfo
	 * @return @
	 * @throws BeException
	 */

	public SettlementInfo updateSettlementStatus(SettlementInfo settlementInfo) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.SETTLEMENT);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), settlementInfo, SettlementInfo.class);
	}


	/**
	 * get country description by country code
	 *
	 * @param country
	 * @return @
	 * @throws BeException
	 */

	public Country getCountryDescByCountryCode(String country) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_COUNTRY_BY_CODE);
		sb.append("/");
		sb.append(country);

		Map<String, Object> params = new HashMap<>();
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), Country.class, params);
	}


	/**
	 * Get ticket details
	 *
	 * @param ticketId
	 * @return @
	 * @throws BeException
	 */
	public Ticket getTicketById(Integer ticketId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TICKET);
		sb.append("/");
		sb.append(ticketId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), Ticket.class);
	}


	/**
	 * get status description by status code and type
	 *
	 * @param country
	 * @return @
	 * @throws BeException
	 */

	public Status getStatusDescByStatusCodeAndType(String statusType, String statusCode) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_STATUS_BY_CODE);
		sb.append("/");
		sb.append(statusType);
		sb.append("/");
		sb.append(statusCode);

		Map<String, Object> params = new HashMap<>();
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), Status.class, params);
	}


	/**
	 * Update Ticket
	 *
	 * @param ticketId
	 * @return @
	 * @throws BeException
	 */

	public Ticket updateTicket(Ticket ticket) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.TICKET);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), ticket, Ticket.class);
	}


	/**
	 * Get paginated SubscriptionPlan Listing
	 *
	 * @param subctionPlan
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<SubscriptionPlan> searchSubscriptionPlan(SubscriptionPlan subscriptionPlan,
			Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.SUBSCRIPTION_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), subscriptionPlan,
				DataTableResults.class);
	}


	/**
	 * add Subscription Plan
	 *
	 * @param SubscriptionPlan
	 * @return @
	 * @throws BeException
	 */

	public boolean addSubscriptionPlan(SubscriptionPlan subscriptionPlan) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.ADD_SUBSCRIPTION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), subscriptionPlan, boolean.class);
	}


	/**
	 * get Subscription Plan by Id
	 *
	 * @param SubscriptionPlanId
	 * @return SubscriptionPlan
	 * @throws BeException
	 */

	public SubscriptionPlan getSubscriptionPlanById(Integer subscriptionPlanId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_SUBSCRIPTION);
		sb.append("/" + subscriptionPlanId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), SubscriptionPlan.class);
	}


	/**
	 * delete Subscription Plan by Id
	 *
	 * @param SubscriptionPlanId
	 * @return boolean
	 * @throws BeException
	 */

	public boolean deleteSubsciption(Integer subscriptionPlanId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.DEL_SUBSCRIPTION);
		sb.append("/" + subscriptionPlanId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), boolean.class);
	}


	/**
	 * Get paginated Status Listing
	 *
	 * @param RefStatus
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	public DataTableResults<RefStatus> searchStatus(RefStatus refStatus, Map<String, Object> pagination)
			throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.STATUS_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), refStatus,
				DataTableResults.class);
	}


	/**
	 * add Subscription Plan
	 *
	 * @param SubscriptionPlan
	 * @return @
	 * @throws BeException
	 */

	public boolean addStatus(RefStatus refStatus) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.ADD_STATUS);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), refStatus, boolean.class);
	}


	/**
	 * get Status by Id
	 *
	 * @param statusId
	 * @return RefStatus
	 * @throws BeException
	 */

	public RefStatus getStatusById(Integer statusId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_STATUS);
		sb.append("/" + statusId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), RefStatus.class);
	}


	/**
	 * delete Status by Id
	 *
	 * @param statusId
	 * @return boolean
	 * @throws BeException
	 */

	public boolean deleteStatus(Integer statusId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.DEL_STATUS);
		sb.append("/" + statusId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), boolean.class);
	}


	/**
	 * save ApsProfile
	 *
	 * @param ApsProfile
	 * @return @
	 * @throws BeException
	 */

	public ApsProfileResponse saveApsProfile(ApsProfile apsProfile) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.SAVE_APS_PROFILE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), apsProfile, ApsProfileResponse.class);
	}


	/**
	 * Search Remittence Settlement List by pagination
	 *
	 * @param settlement
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<SettlementInfo> searchRemittenceSettlement(SettlementInfo settlementInfo,
			Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REMITTENCE_SETTLEMENT);
		sb.append(BeUrlConstants.SETTLEMENT_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), settlementInfo,
				DataTableResults.class);
	}


	/**
	 * save Trxn Document
	 *
	 * @param TrxnDocuments
	 * @return @
	 * @throws BeException
	 */

	public TrxnDocuments saveTrxnDocument(TrxnDocuments trxnDocuments) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.SAVE_TRXN_DOCUMENT);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), trxnDocuments, TrxnDocuments.class);
	}


	/**
	 * Get paginated Company Referral
	 *
	 * @param MerchantCompany
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<MerCompany> searchMerchantCompany(MerCompany merchantCompany,
			Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MERCHANT_COMPANY);
		sb.append(BeUrlConstants.MERCHANT_COMPANY_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), merchantCompany,
				DataTableResults.class);
	}


	/**
	 * Get Merchant Company
	 *
	 * @param companyName
	 * @return @
	 * @throws BeException
	 */

	public MerCompany getMerchantCompanyByCompanyId(String companyRefId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MERCHANT_COMPANY);
		sb.append("/" + companyRefId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerCompany.class);
	}


	public MerchantPid findMerchantPidByMerchantId(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_PID);
		sb.append("/merchantpid");
		sb.append("/" + merchantId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerchantPid.class);
	}


	public MerchantPid findMerchantPidByMerchantIdUsingMTOID(String merchantId, String mtotype) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_PID);
		sb.append("/merchantpid");
		sb.append("/" + merchantId);
		sb.append("/" + mtotype);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerchantPid.class);
	}


	public MerchantPid createMerchantPid(MerchantPid merchantPid) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_PID);
		sb.append("/create");
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merchantPid, MerchantPid.class);
	}


	/**
	 * Search PID List by pagination
	 *
	 * @param merchant
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<MerchantPid> getMtoMappingByMerchant(String merchantId, Map<String, Object> pagination)
			throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_PID);
		sb.append(BeUrlConstants.PAGINATED_BY_MERCHANT_ID);
		sb.append("/");
		sb.append(merchantId);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), null,
				DataTableResults.class);
	}


	/**
	 * Get Provider By Id
	 *
	 * @param provider
	 *             id
	 * @return @
	 * @throws BeException
	 */
	public Provider getProviderById(Integer providerId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROVIDER);
		sb.append("/providerId/");
		sb.append(providerId);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), Provider.class);
	}


	/**
	 * Get Provider By Channel
	 *
	 * @param channel
	 * @return @
	 * @throws BeException
	 */
	public Provider findProviderByChannel(String channel) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROVIDER);
		sb.append("/channel/");
		sb.append(channel);

		return getRestTemplate().getForObject(getServiceURI(sb.toString()), Provider.class);
	}


	/**
	 * update BeneficiaryId
	 *
	 * @param merchantId,
	 *             beneficiaryId
	 * @return @
	 * @throws BeException
	 */

	public int updateBeneficiaryIdByMerchantId(String merchantId, String beneficiaryId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.UPD_BEN_BY_MERID);
		sb.append("/?merchantId=").append(merchantId);
		sb.append("&beneficiaryId=").append(beneficiaryId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), Integer.class);
	}


	/**
	 * create company referral
	 *
	 * @param MerCompany
	 * @return @
	 * @throws BeException
	 */

	public MerCompany createCompRef(MerCompany merCompany) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MERCHANT_COMPANY);
		sb.append(BeUrlConstants.CREATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merCompany, MerCompany.class);
	}


	/**
	 * Get merchant company details
	 *
	 * @param companyId
	 * @return @
	 * @throws BeException
	 */
	public MerCompany getCompanyByCompanyId(Integer companyId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MERCHANT_COMPANY);
		sb.append("/");
		sb.append(companyId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerCompany.class);
	}


	/**
	 * Update Company
	 *
	 * @param companyId
	 * @return @
	 * @throws BeException
	 */

	public MerCompany updateCompany(MerCompany merCompany) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MERCHANT_COMPANY);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merCompany, MerCompany.class);
	}


	/**
	 * Get Merchant Company Bank Details
	 *
	 * @param companyName
	 * @return @
	 * @throws BeException
	 */

	public MerCompBankDetails getCompRefBankDetailsByCompRefId(String compRefId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_COMP_BANK_DETAILS);
		sb.append("/" + compRefId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerCompBankDetails.class);
	}


	/**
	 * Get merchant company details
	 *
	 * @param compRefId
	 * @return @
	 * @throws BeException
	 */
	public MerCompany getCompanyByCompRefId(String compRefId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MERCHANT_COMPANY);
		sb.append("/");
		sb.append(compRefId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerCompany.class);
	}


	/**
	 * Get merchant company beneficiary details
	 *
	 * @param compRefId
	 * @return @
	 * @throws BeException
	 */
	public MerchantBeneficiary getBeneficiaryByCompRefId(String compRefId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_COMP_BANK_DETAILS);
		sb.append("/" + compRefId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerchantBeneficiary.class);
	}


	/**
	 * Get Merchant Company Details
	 *
	 *
	 * @return @
	 * @throws BeException
	 */

	public List<MerCompany> getMerchantCompanyDetails() throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MERCHANT_COMPANY);
		sb.append(BeUrlConstants.GET_MER_COMP_LIST);
		MerCompany[] resp = getRestTemplate().getForObject(getServiceURI(sb.toString()), MerCompany[].class);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * Get referral channel
	 *
	 * @param compRefId
	 * @return @
	 * @throws BeException
	 */
	public MerChanSetWrapper getRefChannelByCompRefId(String compRefId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFFERAL_MULTI_CHANNEL);
		sb.append("/" + compRefId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerChanSetWrapper.class);
	}


	// Provider Details
	@SuppressWarnings("unchecked")
	public DataTableResults<Provider> searchProvider(Provider provider, Map<String, Object> pagination)
			throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROVIDER);
		sb.append(BeUrlConstants.PROVIDER_PAGINATION);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), provider,
				DataTableResults.class);
	}


	public List<Channel> getRefChannelList() throws BeException {
		List<Channel> refChannelList = new ArrayList<>();
		if (!BaseUtil.isObjNull(refChannelList)) {
			refChannelList = reference().getAllChannel();
		}
		return refChannelList;
	}


	// Add Provider Details
	public Provider addProvider(Provider provider) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROVIDER);
		sb.append(BeUrlConstants.ADD_PROVIDER);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), provider, Provider.class);
	}


	// Delete Provider
	public boolean deleteProvider(Integer provId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROVIDER);
		sb.append(BeUrlConstants.DEL_PROVIDER);
		sb.append("/" + provId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), boolean.class);
	}


	/**
	 * Create Merchant Company Bank Details
	 *
	 * @param merCompBankDetails
	 * @return @
	 * @throws BeException
	 */

	public MerCompBankDetails createBeneficiary(MerCompBankDetails merCompBankDetails) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_COMP_BANK_DETAILS);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merCompBankDetails,
				MerCompBankDetails.class);
	}


	/**
	 * Get paginated Company Referral Beneficiary
	 *
	 * @param MerCompBankDetails
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<MerCompBankDetails> searchReferralBeneficiary(MerCompBankDetails merCompBankDetails,
			Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_COMP_BANK_DETAILS);
		sb.append(BeUrlConstants.PAGINATED);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), merCompBankDetails,
				DataTableResults.class);
	}


	/**
	 * Get Merchant Company Bank Details by company bank id
	 *
	 * @param compBankId
	 * @return @
	 * @throws BeException
	 */

	public MerCompBankDetails getCompRefBankDetailsByCompBankId(Integer compBankId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_COMP_BANK_DETAILS);
		sb.append(BeUrlConstants.GET_BANK_DETAILS_BY_COMPBANKID);
		sb.append("/");
		sb.append(compBankId);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), MerCompBankDetails.class);
	}


	public boolean updateRefChannelSetting(MerChanSetWrapper merChanSetWrapper) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFFERAL_MULTI_CHANNEL);
		sb.append(BeUrlConstants.UPDATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merChanSetWrapper, boolean.class);
	}


	/**
	 * save ApsProfile
	 *
	 * @param ApsProfile
	 * @return @
	 * @throws BeException
	 */

	public IRProfileResponse saveIRProfile(IRProfile irProfile) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.SAVE_IR_PROFILE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), irProfile, IRProfileResponse.class);
	}


	public IRProfileResponse saveIRInternalProfile(IRProfile irProfile) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.SAVE_INTER_IR_PROFILE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), irProfile, IRProfileResponse.class);
	}


	public List<MerAccInfo> getOwenerNationalId(MerAccInfo merAccInfo) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.GET_OWNERID);
		MerAccInfo[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), merAccInfo,
				MerAccInfo[].class);

		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * Search Remittance Settlement Report by pagination
	 *
	 * @param settlementRptInfo
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<SettlementRptInfo> searchRemittanceSettlementReport(SettlementRptInfo settlementRptInfo,
			Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.STTLMNT_REPORT);
		sb.append(BeUrlConstants.SET_RPT_PAGINATED_BY_REMIT);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), settlementRptInfo,
				DataTableResults.class);
	}


	/**
	 * Search Remittance Settlement Report Info list
	 *
	 * @param settlementRptInfo
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	public List<SettlementRptInfo> getRemitSettlementRptInfo(SettlementRptInfo settlementRptInfo) throws BeException {
		StringBuilder sb = new StringBuilder();

		sb.append(BeUrlConstants.STTLMNT_REPORT);
		sb.append(BeUrlConstants.REMIT_SETTLEMENT_RPT_INFO);
		SettlementRptInfo[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), settlementRptInfo,
				SettlementRptInfo[].class);
		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	public ApsProfileResponse saveMMInternalProfile(ApsProfile apsProfile) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.SAVE_INTER_MM_PROFILE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), apsProfile, ApsProfileResponse.class);
	}


	/**
	 * Payment Configuration Paginated
	 *
	 * @param PaymentConfig
	 * @param pagination
	 * @return @
	 * @throws BeException
	 */
	@SuppressWarnings("unchecked")
	public DataTableResults<PaymentConfig> searchPaymentConfig(PaymentConfig paymentConfig,
			Map<String, Object> pagination) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT_CONFIG);
		sb.append(BeUrlConstants.PAGINATED);
		return getRestTemplate().postForObject(getServiceURI(sb.toString(), pagination), paymentConfig,
				DataTableResults.class);
	}


	/**
	 * create Payment Configuration
	 *
	 * @param PaymentConfig
	 * @return @
	 * @throws BeException
	 */
	public PaymentConfig createPaymentConfig(PaymentConfig paymentConfig) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT_CONFIG);
		sb.append(BeUrlConstants.CREATE);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), paymentConfig, PaymentConfig.class);
	}


	/**
	 * view Payment Configuration
	 *
	 * @param PaymentConfig
	 * @param id
	 * @return @
	 * @throws BeException
	 */
	public PaymentConfig getPaymentConfigById(Integer id) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAYMENT_CONFIG);
		sb.append(BeUrlConstants.GET_PAYMENT_CONFIG);
		sb.append("/" + id);
		return getRestTemplate().getForObject(getServiceURI(sb.toString()), PaymentConfig.class);
	}


	/**
	 * get SSM ID
	 *
	 * @param Provider
	 * @param id
	 * @return @
	 * @throws BeException
	 */
	public List<Provider> getProviderSsmId(Provider provider) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROVIDER);
		sb.append(BeUrlConstants.GET_SSM_ID);
		Provider[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), provider, Provider[].class);

		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * get Provider Public Name
	 *
	 * @param Provider
	 * @param id
	 * @return @
	 * @throws BeException
	 */
	public List<Provider> getProviderPublicName(Provider provider) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PROVIDER);
		sb.append(BeUrlConstants.GET_PROVIDER_PUBLIC_NAME);
		Provider[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), provider, Provider[].class);

		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * get Channel Code
	 *
	 * @param Channel
	 * @param id
	 * @return @
	 * @throws BeException
	 */
	public List<Channel> getChannelPublicName(Channel channel) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.CHAN_SET);
		sb.append(BeUrlConstants.GET_CHANNEL_PUBLIC_NAME);
		Channel[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), channel, Channel[].class);

		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * get Channel Name
	 *
	 * @param Channel
	 * @param id
	 * @return @
	 * @throws BeException
	 */
	public List<Channel> getChannelName(Channel channel) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.CHAN_SET);
		sb.append(BeUrlConstants.GET_CHANNEL_NAME);
		Channel[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), channel, Channel[].class);

		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}


	/**
	 * send Activation Email
	 *
	 * @param merchantId
	 *
	 * @return @
	 * @throws BeException
	 */
	public MerAccInfo sendActivationEmail(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.SEND_ACTIVATION_EMAIL);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merchantId, MerAccInfo.class);
	}


	/**
	 * send Approval Email
	 *
	 * @param merchantId
	 *
	 * @return @
	 * @throws BeException
	 */
	public MerAccInfo sendApprovalnEmail(String merchantId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_INFO);
		sb.append(BeUrlConstants.SEND_APPROVALN_EMAIL);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merchantId, MerAccInfo.class);
	}


	public List<ReferralMultiChannel> getMultiChannelList() throws BeException {
		List<ReferralMultiChannel> channelList = new ArrayList<>();
		channelList = reference().getRefMultiChannelLst();
		return channelList;
	}


	public List<ReferralMultiChannel> getMultiChannelListByCompRefId(String compRefId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.REFERENCE);
		sb.append(BeUrlConstants.GET_REF_MULTI_CHANNEL_BY_COMPREFID);
		// sb.append("/" + compRefId);
		/*
		 * List<ReferralMultiChannel> channelList = new ArrayList<>();
		 * channelList = reference().getRefMultiChannelLst();
		 */
		ReferralMultiChannel[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), compRefId,
				ReferralMultiChannel[].class);

		if (!BaseUtil.isObjNull(resp)) {
			return new ArrayList<>(Arrays.asList(resp));
		}
		return Collections.emptyList();

	}


	public Boolean isAccSetExistsByIcTypeAndIcNum(MerAccSet merAccSet) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.MER_ACC_SET);
		sb.append(BeUrlConstants.EXISTS);
		return getRestTemplate().postForObject(getServiceURI(sb.toString()), merAccSet, Boolean.class);
	}
	
	/**
	 * Select All merchant List from Payment Setting
	 *
	 *
	 * @param compRefId
	 * @return @
	 * @throws BeException
	 */
	public List<MerPayPageSet> getMerChantpaymentListByCompRefId(String compRefId) throws BeException {
		StringBuilder sb = new StringBuilder();
		sb.append(BeUrlConstants.PAY_PAGE_SET);
		sb.append(BeUrlConstants.ALL_MER_PAYSET_LIST_BY_COMPREFID);
		MerPayPageSet[] resp = getRestTemplate().postForObject(getServiceURI(sb.toString()), compRefId,
				MerPayPageSet[].class);

		if (!BaseUtil.isObjNull(resp)) {
			return Arrays.asList(resp);
		}
		return Collections.emptyList();
	}

}