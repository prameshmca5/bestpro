package com.bestpay.pgw.sdk.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class MerchantPid implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6645623423283005357L;
	
	
	private Integer pidId;
	private String merchantId;
	private String mtoId;
	private String pid;
	private Timestamp createDt;
	private String createID;
	private Timestamp updateDt;
	private String updateID;
	
	public Integer getPidId() {
		return pidId;
	}
	public void setPidId(Integer pidId) {
		this.pidId = pidId;
	}
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public String getMtoId() {
		return mtoId;
	}
	public void setMtoId(String mtoId) {
		this.mtoId = mtoId;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public Timestamp getCreateDt() {
		return createDt;
	}
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}
	public String getCreateID() {
		return createID;
	}
	public void setCreateID(String createID) {
		this.createID = createID;
	}
	public Timestamp getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}
	public String getUpdateID() {
		return updateID;
	}
	public void setUpdateID(String updateID) {
		this.updateID = updateID;
	}
	
	
	

}
