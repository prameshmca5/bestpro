/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.be.service;


import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import com.be.constants.ConfigConstants;
import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeMemberProfileRepository;
import com.be.dao.BePaymentQf;
import com.be.dao.BePaymentRepository;
import com.be.dao.BePreRegRepository;
import com.be.model.BeMemberProfile;
import com.be.model.BePayment;
import com.be.model.BePaymentDtl;
import com.be.model.BePreReg;
import com.be.model.RefDocument;
import com.be.model.RefMetadata;
import com.be.model.RefStatus;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.constants.MailTemplateConstants;
import com.be.sdk.constants.ReferenceConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.MemberProfile;
import com.be.sdk.model.Payment;
import com.be.sdk.model.PaymentDtl;
import com.be.sdk.model.PreReg;
import com.idm.sdk.exception.IdmException;
import com.idm.sdk.model.Fcm;
import com.idm.sdk.model.FcmDevice;
import com.idm.sdk.model.UserProfile;
import com.notify.sdk.constants.MailTypeEnum;
import com.notify.sdk.model.Attachment;
import com.notify.sdk.model.ByteAttachment;
import com.notify.sdk.model.Notification;
import com.notify.sdk.util.MailUtil;
import com.report.sdk.constants.ReportTypeEnum;
import com.report.sdk.model.Report;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.JsonUtil;
import com.util.constants.BaseConstants;
import com.util.pagination.DataTableRequest;


/**
 * @author mohd.naem
 * @since March 31 , 2021
 */
@Service(QualifierConstants.BE_PAYMENT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_PAYMENT_SVC)
@Transactional
public class BePaymentService extends AbstractService<BePayment> {

	protected static Logger logger = LoggerFactory.getLogger(BePaymentService.class);

	@Autowired
	private BePaymentRepository bePaymentDao;

	@Autowired
	private BePaymentQf bePaymentQf;

	@Autowired
	private BeMemberProfileRepository beMemberProfileDao;

	@Autowired
	private BePreRegRepository bePreRegDao;

	@Autowired
	private BePreRegService bePreRegSvc;

	@Autowired
	private BeMemberProfileService beMemberProfileSvc;
	
	@Autowired
	private MessageService messageService;

	private static DecimalFormat df = new DecimalFormat("0.00");


	@Override
	public GenericRepository<BePayment> primaryDao() {
		return bePaymentDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return null;
	}


	public long getCount(Payment dto) {
		return bePaymentQf.getCount(dto);
	}


	@SuppressWarnings("unchecked")
	public List<Payment> searchPagination(Payment dto, DataTableRequest<?> dataTableInRQ) throws IOException {
		return JsonUtil.transferToList(bePaymentQf.searchAllByProperty(dto, dataTableInRQ), Payment.class);
	}


	@SuppressWarnings("unchecked")
	public Payment search(Payment dto) throws IOException {
		List<BePayment> bePaymentList = bePaymentQf.searchAllByProperty(dto, null);
		Payment payment = null;
		if (!BaseUtil.isListNull(bePaymentList)) {
			BePayment bePayment = bePaymentList.stream()
					.sorted(Comparator.comparingInt(BePayment::getPmtId).reversed()).findFirst().orElse(null);
			if (!BaseUtil.isObjNull(bePayment)) {
				payment = JsonUtil.transferToObject(bePayment, Payment.class);
				payment.setPaymentDtlList(
						JsonUtil.transferToList(bePayment.getPaymentDtlList(), BePaymentDtl.class));
			}
		}
		return payment;
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public BePayment updatePostPayment(BePayment bePayment, List<Integer> memberIdList, Integer statusIdMember,
			List<BeMemberProfile> beMemberProfileList, List<BePreReg> bePreRegs) {
		if (!BaseUtil.isListNull(memberIdList) && statusIdMember == 3) {
			bePreRegDao.updateStatusIdByPreRegId(statusIdMember, memberIdList);
			if (!BaseUtil.isListNull(beMemberProfileList)) {
				for (BeMemberProfile mbprof : beMemberProfileList) {
					Integer countprof = beMemberProfileDao.totalMemberProfRecords(mbprof.getPreRegId());
					if (countprof == 0) {
						beMemberProfileDao.saveAndFlush(mbprof);
					}
				}
			}
		} else {
			bePreRegDao.save(bePreRegs);
		}
		bePreRegDao.flush();

		return bePaymentDao.saveAndFlush(bePayment);
	}


	@SuppressWarnings("unchecked")
	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public Payment updatePostPayment2(BePayment bePayment, Integer statusIdMember,
			List<BeMemberProfile> beMemberProfileList, List<BePreReg> bePreRegs) throws IOException {
		List<PreReg> preRegList = null;
		if (!BaseUtil.isListNull(bePreRegs)) {
			preRegList = JsonUtil.transferToList(bePreRegSvc.updatePreRegList(bePreRegs), PreReg.class);
		}
		List<MemberProfile> memberProfileList = new ArrayList<>();
		if (!BaseUtil.isListNull(beMemberProfileList) && statusIdMember == 3) {
			for (BeMemberProfile mbprof : beMemberProfileList) {
				Integer countprof = beMemberProfileDao.totalMemberProfRecords(mbprof.getPreRegId());
				if (countprof == 0) {
					memberProfileList.add(
							JsonUtil.transferToObject(beMemberProfileSvc.create(mbprof), MemberProfile.class));
				}
			}
		}

		Payment payment = JsonUtil.transferToObject(update(bePayment), Payment.class);
		payment.setMemberProfileList(memberProfileList);
		payment.setPreRegList(preRegList);

		return payment;
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class })
	public void processNotification(Payment payment, RefStatus refStatus, RefMetadata channelMtdt,
			HttpServletRequest request) {

		if (!BaseUtil.isObjNull(payment) && BaseUtil.isEqualsCaseIgnore("PD", refStatus.getStatusCd())) {
			// notification
			if (BaseUtil.isEqualsCaseIgnore(channelMtdt.getMtdtCd(), ReferenceConstants.MTDT_CD_WEB_CNTR)) {
				if (!BaseUtil.isEquals(payment.getPmtBy(), "")) {
					try {

						MemberProfile memProf = new MemberProfile();
						memProf.setIdNo(payment.getPmtBy());
						memProf = beMemberProfileSvc.search(memProf);

						if (!BaseUtil.isObjNull(memProf)) {
							Map<String, Object> map = new HashMap<>();
							map.put("paymentDate",
									!BaseUtil.isObjNull(payment.getPmtDt()) ? DateUtil.convertDate(
											payment.getPmtDt(), BaseConstants.DT_DD_MM_YYYY_SLASH) : null);

							if (payment.getPaymentDtlList().size() != 0) {
								map.put("memberCount", payment.getPaymentDtlList().size());
								for (PaymentDtl paymentDtl : payment.getPaymentDtlList()) {
									int itemId = Integer.parseInt(paymentDtl.getItemId());

									for (MemberProfile memberPro : payment.getMemberProfileList()) {
										if (itemId == memberPro.getPreRegId()) {
											// email official receipt
											if (!BaseUtil.isObjNull(memberPro.getEmail())) {
												map.put("fullName", memberPro.getFullName());
												map.put("summaryReceiptNo", paymentDtl.getPmtDtlRefNo());
												map.put("summaryCurrency", paymentDtl.getCurrency());
												map.put("summaryAmount",
														df.format(paymentDtl.getItemAmount()));

												Notification notification = new Notification();
												notification.setNotifyTo(memberPro.getEmail());
												notification.setMetaData(MailUtil.convertMapToJson(map));
												notification.setAttachments(new ArrayList<>());

												Report officialReceipt = null;
												RefDocument officialReceiptDoc = new RefDocument();

												MemberProfile memberProfile = new MemberProfile();

												memberProfile.setFullName(memberPro.getFullName());
												memberProfile.setIdNo(memberPro.getIdNo());
												memberProfile.setPmtDtlRefNo(paymentDtl.getPmtDtlRefNo());
												memberProfile.setItemAmount(paymentDtl.getItemAmount());
												memberProfile.setCurrency(paymentDtl.getCurrency());
												paymentDtl.setMemberProfile(memberProfile);
												paymentDtl.setCreateDt(payment.getPmtDt());

												// summary receipt
												officialReceiptDoc.setDocDesc("Official Receipt");
												officialReceiptDoc
														.setType(ReportTypeEnum.PDF.getMimeType());

												officialReceipt = getReportService(request).report()
														.genIndividualPaymentSlip(paymentDtl,
																ReportTypeEnum.PDF);

												if (!BaseUtil.isObjNull(officialReceipt)) {
													notification.setAttachments(new ArrayList<>());
													notification.getAttachments()
															.add(setNotificationAttachments(
																	officialReceipt,
																	officialReceiptDoc));
												}
												notification.setContent(payment.getPmtBy());
												getNotifyService(request).addNotification(notification,
														MailTemplateConstants.PAYMENT_SUCCESSFUL_EMAIL);
											}

											// sms
											if (!BaseUtil.isObjNull(memberPro.getContactNo())) {
												map.put("fullName", memberPro.getFullName());

												Notification notification = new Notification();
												notification.setNotifyTo(memberPro.getContactNo());
												notification.setMetaData(MailUtil.convertMapToJson(map));
												notification.setNotifyType(MailTypeEnum.SMS.getType());
												notification.setContent(payment.getPmtBy());

												getNotifyService(request).addNotification(notification,
														MailTemplateConstants.PAYMENT_SUCCESSFUL_SMS);
											}

											// fcm
											if (!BaseUtil.isObjNull(memberPro.getMemberId())) {

												UserProfile userProfile = new UserProfile();
												try {
													userProfile = getIdmService(request)
															.getUserProfileByProfId(
																	memberPro.getMemberId(), false,
																	false);
												} catch (Exception e) {

												}

												if (!BaseUtil.isObjNull(userProfile)) {
													Map<String, Object> datamap = new LinkedHashMap<>();
													datamap.put("invoiceNo", payment.getPmtRefNo());
													datamap.put("paymentAmount",
															df.format(payment.getTotalAmount()));
													datamap.put("noOfMember", 1);
													List<FcmDevice> devices = searchAllDevice(userProfile,
															request);

													addFCMNotification(devices, userProfile, datamap,
															MailTemplateConstants.PAYMENT_SUCCESSFUL_FCM,
															request);
												}

											}

										}
									}

								}

							}

							// sms
							if (!BaseUtil.isObjNull(memProf.getContactNo())) {
								map.put("fullName", memProf.getFullName());

								Notification notification = new Notification();
								notification.setNotifyTo(memProf.getContactNo());
								notification.setMetaData(MailUtil.convertMapToJson(map));
								notification.setNotifyType(MailTypeEnum.SMS.getType());
								notification.setContent(payment.getPmtBy());

								getNotifyService(request).addNotification(notification,
										MailTemplateConstants.PAYMENT_SUCCESSFUL_SMS);
							}

							// email summary receipt
							if (!BaseUtil.isObjNull(memProf.getEmail())) {
								map.put("fullName", memProf.getFullName());
								map.put("summaryReceiptNo", payment.getPmtRefNo());
								map.put("summaryCurrency", payment.getCurrency());
								map.put("summaryAmount", df.format(payment.getTotalAmount()));

								Notification notification = new Notification();
								notification.setNotifyTo(memProf.getEmail());
								notification.setMetaData(MailUtil.convertMapToJson(map));
								notification.setAttachments(new ArrayList<>());

								Report summaryReceipt = null;
								RefDocument summaryReceiptDoc = new RefDocument();
								Payment paySummaryReceipt = new Payment();
								paySummaryReceipt.setTxnId(payment.getTxnId());

								// summary receipt
								summaryReceiptDoc.setDocDesc("Summary Receipt");
								summaryReceiptDoc.setType(ReportTypeEnum.PDF.getMimeType());

								summaryReceipt = getReportService(request).report()
										.genPaymentSlip(paySummaryReceipt, ReportTypeEnum.PDF);

								if (!BaseUtil.isObjNull(summaryReceipt)) {
									notification.setAttachments(new ArrayList<>());
									notification.getAttachments().add(
											setNotificationAttachments(summaryReceipt, summaryReceiptDoc));
								}
								notification.setContent(payment.getPmtBy());

								getNotifyService(request).addNotification(notification,
										MailTemplateConstants.PAYMENT_SUCCESSFUL_EMAIL);
							}

							// fcm
							if (!BaseUtil.isObjNull(memProf.getMemberId())) {

								UserProfile userProfile = new UserProfile();
								try {
									userProfile = getIdmService(request)
											.getUserProfileByProfId(memProf.getMemberId(), false, false);
								} catch (Exception e) {

								}
								if (!BaseUtil.isObjNull(userProfile)) {
									Map<String, Object> datamap = new LinkedHashMap<>();
									datamap.put("invoiceNo", payment.getPmtRefNo());
									datamap.put("paymentAmount", df.format(payment.getTotalAmount()));
									datamap.put("noOfMember", payment.getPaymentDtlList().size());
									List<FcmDevice> devices = searchAllDevice(userProfile, request);

									addFCMNotification(devices, userProfile, datamap,
											MailTemplateConstants.PAYMENT_SUCCESSFUL_FCM, request);
								}

							}

						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} else {

				try {

					Map<String, Object> map = new HashMap<>();
					map.put("paymentDate", !BaseUtil.isObjNull(payment.getPmtDt())
							? DateUtil.convertDate(payment.getPmtDt(), BaseConstants.DT_DD_MM_YYYY_SLASH)
							: null);

					// sms
					if (!BaseUtil.isObjNull(payment.getPreRegList().get(0).getContactNo())) {
						map.put("fullName", payment.getPreRegList().get(0).getFullName());

						Notification notification = new Notification();
						notification.setNotifyTo(payment.getPreRegList().get(0).getContactNo());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setNotifyType(MailTypeEnum.SMS.getType());
						notification.setContent(payment.getPmtBy());

						getNotifyService(request).addNotification(notification,
								MailTemplateConstants.PAYMENT_SUCCESSFUL_SMS);
					}

					// email summary receipt
					if (!BaseUtil.isObjNull(payment.getPreRegList().get(0).getEmail())) {
						map.put("fullName", payment.getPreRegList().get(0).getFullName());
						map.put("summaryReceiptNo", payment.getPmtRefNo());
						map.put("summaryCurrency", payment.getCurrency());
						map.put("summaryAmount", df.format(payment.getTotalAmount()));

						Notification notification = new Notification();
						notification.setNotifyTo(payment.getPreRegList().get(0).getEmail());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setAttachments(new ArrayList<>());

						Report officialReceipt = null;
						RefDocument officialReceiptDoc = new RefDocument();
						PaymentDtl payOfficialReceipt = new PaymentDtl();
						payOfficialReceipt.setItemId(payment.getPaymentDtlList().get(0).getItemId());

						MemberProfile memberProfile = new MemberProfile();

						memberProfile.setFullName(payment.getPreRegList().get(0).getFullName());
						memberProfile.setIdNo(payment.getPreRegList().get(0).getIdNo());
						memberProfile.setPmtDtlRefNo(payment.getPaymentDtlList().get(0).getPmtDtlRefNo());
						memberProfile.setItemAmount(payment.getPaymentDtlList().get(0).getItemAmount());
						memberProfile.setCurrency(payment.getPaymentDtlList().get(0).getCurrency());
						payOfficialReceipt.setMemberProfile(memberProfile);
						payOfficialReceipt.setCreateDt(payment.getPmtDt());

						officialReceiptDoc.setDocDesc("Official Receipt");
						officialReceiptDoc.setType(ReportTypeEnum.PDF.getMimeType());

						officialReceipt = getReportService(request).report()
								.genIndividualPaymentSlip(payOfficialReceipt, ReportTypeEnum.PDF);

						if (!BaseUtil.isObjNull(officialReceipt)) {
							notification.setAttachments(new ArrayList<>());
							notification.getAttachments()
									.add(setNotificationAttachments(officialReceipt, officialReceiptDoc));
						}
						notification.setContent(payment.getPmtBy());

						getNotifyService(request).addNotification(notification,
								MailTemplateConstants.PAYMENT_SUCCESSFUL_EMAIL);
					}

				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		}
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class,
			BeException.class })
	public BePayment createPayment(BePayment bePayment, List<Integer> memberIdList, Integer statusIdMember) {
		if (!BaseUtil.isListNull(memberIdList)) {
			bePreRegDao.updateStatusIdByPreRegId(statusIdMember, memberIdList);
		}
		return bePaymentDao.save(bePayment);
	}


	@Transactional(rollbackFor = Exception.class)
	public BePayment updatePaymentInfo(@RequestBody Payment dto, BePayment beTvlPayment, HttpServletRequest request,
			Integer refStatusMember) throws Exception {

		BePayment bvlPayment = new BePayment();

		try {
			List<PaymentDtl> pmtlist = dto.getPaymentDtlList();
			List<Integer> memberIdList = new ArrayList<>();
			for (PaymentDtl ptlist : pmtlist) {
				memberIdList.add(Integer.parseInt(ptlist.getItemId()));
			}
			if (!BaseUtil.isListNull(memberIdList)) {
				bePreRegDao.updateStatusIdByPreRegId(refStatusMember, memberIdList);
			}

			bePaymentDao.updatePaymentStatusId(dto.getStatusId(), dto.getPmtId(), "System", null);
			return bvlPayment;
		} catch (BeException e) {
			throw new BeException(BeErrorCodeEnum.E500C001);
		}
	}


	public List<FcmDevice> searchAllDevice(UserProfile userProfile, HttpServletRequest request) throws IdmException {
		FcmDevice fcmDevice = new FcmDevice();
		fcmDevice.setStatus(true);

		Fcm fcm = new Fcm();
		fcm.setUserId(userProfile.getUserId());
		fcm.setStatus(true);
		fcmDevice.setFcm(fcm);

		return getIdmService(request).searchFcmDevice(fcmDevice);
	}


	public void addFCMNotification(List<FcmDevice> devices, UserProfile userProfile, Map<String, Object> map,
			String template, HttpServletRequest request) {
		if (!BaseUtil.isObjNull(userProfile)) {
			if (!BaseUtil.isListNull(devices)) {
				for (FcmDevice device : devices) {
					if (!BaseUtil.isObjNull(device.getFcmToken())) {

						Notification notification = new Notification();
						notification.setNotifyTo(userProfile.getUserId());
						notification.setNotifyCc(device.getFcmToken());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setNotifyType(MailTypeEnum.FCM.getType());

						getNotifyService(request).addNotification(notification, template);
					}
				}
			}

		}
	}


	public Attachment setNotificationAttachments(Report report, RefDocument refDoc) {
		ByteAttachment attachment = new ByteAttachment();
		if (!BaseUtil.isObjNull(report)) {
			attachment.setFile(report.getReportBytes());
			attachment.setFileName(refDoc.getDocDesc());
			attachment.setMimeType(refDoc.getType());
		}
		return attachment;
	}


	public void sendNotificationPaymentSuccess(Payment payment, RefStatus refStatus, RefMetadata channelMtdt,
			HttpServletRequest request) {
		Map<String, Object> map = new HashMap<>();
		map.put("url", messageService.getMessage(ConfigConstants.PORTAL_APP_URL) + "/self-registration");
		
		for (PreReg memberPro : payment.getPreRegList()) {
			map.put("passcode", memberPro.getPasscode());
			// sms
			if (!BaseUtil.isObjNull(memberPro.getContactNo())) {
				Notification notification = new Notification();
				notification.setNotifyTo(memberPro.getContactNo());
				notification.setMetaData(MailUtil.convertMapToJson(map));
				notification.setNotifyType(MailTypeEnum.SMS.getType());
				notification.setContent(memberPro.getIdNo());
				getNotifyService(request).addNotification(notification, MailTemplateConstants.PUBLIC_REG_RESULT_SMS);
			}
			
			// email
			if (!BaseUtil.isObjNull(memberPro.getEmail())) {
				Notification notification = new Notification();
				notification.setNotifyTo(memberPro.getEmail());
				notification.setMetaData(MailUtil.convertMapToJson(map));
				notification.setNotifyType(MailTypeEnum.MAIL.getType());
				notification.setContent(memberPro.getIdNo());
				getNotifyService(request).addNotification(notification, MailTemplateConstants.PUBLIC_REG_RESULT_EMAIL);
			}
			// fcm
			sendFcmNotification(memberPro.getIdNo(), memberPro.getIdNo(), map,
					MailTemplateConstants.PUBLIC_REG_RESULT_FCM, request);
		}
		 
		
		  
	}
	
	protected void sendFcmNotification(String userId, String createId, Map<String, Object> map, String fcmTemplate,
			HttpServletRequest request) {
		FcmDevice fcmDevice = new FcmDevice();
		fcmDevice.setStatus(true);
		fcmDevice.setFcm(new Fcm());
		fcmDevice.getFcm().setUserId(userId);
		fcmDevice.getFcm().setStatus(true);
		List<FcmDevice> devices = getIdmService(request).searchFcmDevice(fcmDevice);
		if (!BaseUtil.isListNull(devices)) {
			for (FcmDevice device : devices) {
				if (!BaseUtil.isObjNull(device.getFcmToken())) {
					Notification notification = new Notification();
					notification.setNotifyTo(userId);
					notification.setNotifyCc(device.getFcmToken());
					notification.setMetaData(MailUtil.convertMapToJson(map));
					notification.setNotifyType(MailTypeEnum.FCM.getType());
					notification.setContent(createId);
					getNotifyService(request).addNotification(notification, fcmTemplate);
				}
			}
		}
	}

}