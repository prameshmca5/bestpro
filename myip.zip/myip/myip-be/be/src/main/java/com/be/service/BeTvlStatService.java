/**
 *
 */
package com.be.service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeTvlStatRepository;
import com.be.dao.RefMetadataRepository;
import com.be.model.BeTvl;
import com.be.model.BeTvlProfile;
import com.be.model.BeTvlStat;
import com.be.model.BeTvlTrip;
import com.be.model.RefDocument;
import com.be.model.RefMetadata;
import com.be.sdk.constants.FileUploadConstants;
import com.be.sdk.constants.MailTemplateConstants;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.DigitalSigning;
import com.be.sdk.model.IQfCriteria;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlProfile;
import com.be.sdk.model.TvlStat;
import com.dm.sdk.model.Documents;
import com.idm.sdk.exception.IdmException;
import com.idm.sdk.model.Fcm;
import com.idm.sdk.model.FcmDevice;
import com.idm.sdk.model.UserProfile;
import com.notify.sdk.constants.MailTypeEnum;
import com.notify.sdk.exception.NotificationException;
import com.notify.sdk.model.Notification;
import com.notify.sdk.util.MailUtil;
import com.report.sdk.constants.ReportTypeEnum;
import com.report.sdk.model.Report;
import com.util.BaseUtil;
import com.util.DateUtil;
import com.util.UidGenerator;


/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_TVL_STAT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_TVL_STAT_SVC)
public class BeTvlStatService extends AbstractService<BeTvlStat> {

	@Autowired
	BeTvlStatRepository beTvlStatDao;

	@Autowired
	BeTvlService beTvlSvc;

	@Autowired
	BeTvlProfileService beTvlProfileSvc;

	@Autowired
	RefMetadataRepository refMetadataDao;

	@Autowired
	RefDocumentService documentSvc;

	@Autowired
	BeTrxnDocumentService trxnDocumentSvc;

	@Autowired
	IntegrationService integrationSvc;

	@Autowired
	RefMetadataService refMetadataService;


	@Override
	public GenericRepository<BeTvlStat> primaryDao() {
		return beTvlStatDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}


	@Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { BeException.class,
			Exception.class })
	public BeTvlStat createUpdate(TvlStat dto, BeTvl beTvl, String userId, HttpServletRequest request)
			throws Exception {

		BeTvlStat beTvlStat = beTvlStatDao.findByTvlId(beTvl.getTvlId(), dto.getStatusInd());
		if (BaseUtil.isObjNull(beTvlStat)) {
			beTvlStat = new BeTvlStat();
			beTvlStat.setStatusInd(dto.getStatusInd());
			beTvlStat.setTvl(beTvl);
			beTvlStat.setCreateId(userId);
		}
		RefMetadata refMetadata = new RefMetadata();
		refMetadata.setMtdtId(dto.getDqStatMtdt().getMtdtId());
		beTvlStat.setDqStatMtdt(refMetadata);
		beTvlStat.setRemarks(dto.getRemarks());
		beTvlStat.setUpdateId(userId);

		if (!BaseUtil.isObjNull(dto.getRemarksMtdtId())) {
			beTvlStat.setRemarksMtdtId(dto.getRemarksMtdtId());
		}

		beTvlSvc.update(beTvl);
		BeTvlStat beTvlStatUpd = update(beTvlStat);
		if (!BaseUtil.isObjNull(beTvlStatUpd)) {
			try {
				/** Save MyUp Slip doc */
				List<RefDocument> myIpDoc = new ArrayList<>();
				Report myIPReport = null;
				if (BaseUtil.isEquals("TRIP_APR", beTvl.getStatus().getStatusCd())) {
					List<Documents> docList = new ArrayList<>();
					myIpDoc = documentSvc.findAllByTrxnNo(FileUploadConstants.DOC_TRXN_MYIP_SLIP);
					// Map<String, Object> params = new HashMap<>();
					// params.put("tvlProfId",
					// beTvl.getTvlProfile().getTvlProfId());
					Tvl tvlDto = new Tvl();
					tvlDto.setTvlProfile(new TvlProfile());
					tvlDto.getTvlProfile().setTvlProfId(beTvl.getTvlProfile().getTvlProfId());

					if (!BaseUtil.isObjNull(beTvl.getTvlProfile())
							&& BaseUtil.isObjNull(beTvl.getTvlProfile().getDocRefNo())) {
						beTvl.getTvlProfile()
								.setDocRefNo(UidGenerator.generateUid(FileUploadConstants.PREFIX_DOC));
					}

					if (!BaseUtil.isListNull(myIpDoc)) {
						// myIPReport =
						// getReportService(request).generateReport(myIpDoc.get(0).getDocTrxnNo(),
						// "pdf", FileUploadConstants.REPORT_FOLDER,
						// params);
						myIPReport = getReportService(request).report().genMyipSlip(tvlDto, ReportTypeEnum.PDF);
						if (!BaseUtil.isObjNull(myIPReport.getReportBytes())) {
							DigitalSigning digitalSigning = integrationSvc.docDigitalSigning(
									myIPReport.getReportBytes(), myIpDoc.get(0).getDocDesc(), "M");
							myIPReport.setReportBytes(digitalSigning.getContent());
							docList.add(trxnDocumentSvc.upload(myIpDoc.get(0), myIPReport,
									beTvl.getTvlProfile().getTrxnRefNo(), request));
							trxnDocumentSvc.createUpdateDoc(docList, getCurrUserId(request),
									beTvl.getTvlProfile().getDocRefNo());
						}
					}
				}
				beTvl.getTvlProfile().setTrxnDt(getSQLTimestamp());
				beTvl.getTvlProfile().setUpdateId(getCurrUserId(request));
				beTvlProfileSvc.update(beTvl.getTvlProfile());

				/** Send email notification */
				BeTvlProfile beTvlProfile = beTvl.getTvlProfile();
				if (!BaseUtil.isObjNull(beTvlStatUpd.getDqStatMtdt())) {
					RefMetadata dqMtdt = refMetadataDao.findOne(beTvlStatUpd.getDqStatMtdt().getMtdtId());
					if (!BaseUtil.isObjNull(dqMtdt)
							&& BaseUtil.isEquals(dqMtdt.getMtdtType(), "DQ_OVERALL_STATUS")) {
						String templateCode = null;
						BeTvlTrip tvlTrip = beTvl.getTvlTrip();

						String remarksAllDq = "";
						if (!BaseUtil.isObjNull(beTvlStatUpd.getRemarksMtdtId())) {
							RefMetadata dqRemarks = refMetadataService.find(beTvlStatUpd.getRemarksMtdtId());
							remarksAllDq = dqRemarks.getMtdtDesc();
						}

						Map<String, Object> map = new HashMap<>();

						map.put("fullName", beTvlProfile.getFullName());
						map.put("tahssNo", beTvlProfile.getTrxnRefNo());
						if (!BaseUtil.isObjNull(tvlTrip)) {
							map.put("refNo", tvlTrip.getTvlTripCodeNo());
							map.put("submitDt",
									!BaseUtil.isObjNull(tvlTrip.getSubmitDt())
											? DateUtil.getFormatBigEndianWithSlash(tvlTrip.getSubmitDt())
											: null);
						}

						map.put("passportNo",
								!BaseUtil.isObjNull(beTvlProfile.getAcctPassport())
										? beTvlProfile.getAcctPassport().getPassportNo()
										: null);
						map.put("nationality",
								!BaseUtil.isObjNull(beTvlProfile.getAcctPassport().getNationality())
										? beTvlProfile.getAcctPassport().getNationality().getCntryDesc()
										: null);
						map.put("gender", BaseUtil.isEquals(beTvlProfile.getGender(), "M") ? "MALE" : "FEMALE");
						map.put("resultDt",
								!BaseUtil.isObjNull(beTvlProfile.getTrxnDt())
										? DateUtil.getFormatBigEndianWithSlash(beTvlProfile.getTrxnDt())
										: null);
						map.put("remarks", remarksAllDq);

						if (BaseUtil.isEquals(dqMtdt.getMtdtCd(), "A")) {
							templateCode = MailTemplateConstants.TRAVEL_DQ_APPROVE;
							if (!BaseUtil.isObjNull(tvlTrip)) {
								map.put("departDt",
										!BaseUtil.isObjNull(tvlTrip.getDepartureDt()) ? DateUtil
												.getFormatBigEndianWithSlash(tvlTrip.getDepartureDt())
												: null);
								map.put("departFrom",
										!BaseUtil.isObjNull(tvlTrip.getDepartureAirport())
												? tvlTrip.getDepartureAirport().getAirportName()
												: null);
							}
						} else if (BaseUtil.isEquals(dqMtdt.getMtdtCd(), "RT")) {
							templateCode = MailTemplateConstants.TRAVEL_DQ_RETURN;
							Map<Integer, String> sectionName = new HashMap<>();
							sectionName.put(1, "Traveller Profile");
							sectionName.put(2, "Travel Information");
							sectionName.put(3, "Itenary Information");
							sectionName.put(4, "Medical Result");

							List<Map<String, String>> sectionList = new ArrayList<>();
							List<BeTvlStat> tvlStatList = beTvlStatDao
									.findByTvlId(beTvlStatUpd.getTvl().getTvlId());
							if (!BaseUtil.isListNull(tvlStatList)) {
								for (BeTvlStat stat : tvlStatList) {
									if (BaseUtil.isEquals(stat.getDqStatMtdt().getMtdtCd(), "F")) {
										Map<String, String> sectMap = new HashMap<>();
										sectMap.put("section", sectionName.get(stat.getStatusInd()));
										sectMap.put("reason", stat.getRemarks());
										sectionList.add(sectMap);
									}
								}
							}
							map.put("sectionList", sectionList);

						} else if (BaseUtil.isEquals(dqMtdt.getMtdtCd(), "RJ")) {
							templateCode = MailTemplateConstants.TRAVEL_DQ_REJECT;
						}

						if (!BaseUtil.isObjNull(beTvl.getAcctProfile()) && !BaseUtil.isObjNull(templateCode)) {
							Notification notification = new Notification();
							notification.setNotifyTo(beTvl.getAcctProfile().getEmail());
							notification.setMetaData(MailUtil.convertMapToJson(map));
							if (!BaseUtil.isObjNull(myIPReport) && !BaseUtil.isListNull(myIpDoc)) {
								notification.setAttachments(new ArrayList<>());
								notification.getAttachments()
										.add(setNotificationAttachments(myIPReport, myIpDoc.get(0)));
							}
							getNotifyService(request).addNotification(notification, templateCode);

							sendingNotification(beTvl, beTvlProfile, dqMtdt, request);
						}
					}
				}
			} catch (NotificationException e) {
				e.printStackTrace();
				throw e;
			}
		}
		return beTvlStatUpd;
	}


	private List<FcmDevice> searchAllDevice(UserProfile userProfile, HttpServletRequest request) throws IdmException {
		FcmDevice fcmDevice = new FcmDevice();
		fcmDevice.setStatus(true);

		Fcm fcm = new Fcm();
		fcm.setUserId(userProfile.getUserId());
		fcm.setStatus(true);
		fcmDevice.setFcm(fcm);

		return getIdmService(request).searchFcmDevice(fcmDevice);
	}


	private void addFCMNotification(List<FcmDevice> devices, UserProfile userProfile, Map<String, Object> map,
			String template, HttpServletRequest request) {
		if (!BaseUtil.isObjNull(userProfile)) {
			if (!BaseUtil.isListNull(devices)) {
				for (FcmDevice device : devices) {
					if (!BaseUtil.isObjNull(device.getFcmToken())) {

						Notification notification = new Notification();
						notification.setNotifyTo(userProfile.getUserId());
						notification.setNotifyCc(device.getFcmToken());
						notification.setMetaData(MailUtil.convertMapToJson(map));
						notification.setNotifyType(MailTypeEnum.FCM.getType());

						getNotifyService(request).addNotification(notification, template);
					}
				}
			}

		}
	}


	private void sendingNotification(BeTvl beTvl, BeTvlProfile beTvlProfile, RefMetadata dqMtdt,
			HttpServletRequest request) {
		try {
			String statusdq = dqMtdt.getMtdtCd();
			String fcmtemplate = null;
			if (BaseUtil.isEquals("A", statusdq)) {
				fcmtemplate = MailTemplateConstants.FCM_TRAVEL_TRIP_APPROVED;
			} else if (BaseUtil.isEquals("RJ", statusdq)) {
				fcmtemplate = MailTemplateConstants.FCM_TRAVEL_TRIP_REJECTED;
			} else if (BaseUtil.isEquals("RT", statusdq)) {
				fcmtemplate = MailTemplateConstants.FCM_TRAVEL_TRIP_RETURNED;
			}

			// Tvl tvlDto = new Tvl();
			// tvlDto.setTvlProfId(beTvl.getTvlProfile().getTvlProfId());
			// tvlDto.setEmbedTraveller(true);
			// BeTvl beTvl = beTvlSvc.searchBeTravel(tvlDto);
			if (!BaseUtil.isObjNull(fcmtemplate)) {
				Integer profId = beTvl.getAcctProfile().getAcctProfId();
				String userType = "TVL";
				// UserProfile profile =
				// getIdmService(request).getUserProfileByProfId(profId,
				// false, false);
				UserProfile profile = getIdmService(request).getUserProfileByProfIdUserType(profId, userType, false,
						false);

				Map<String, Object> datamap = new LinkedHashMap<>();
				datamap.put("tripCodeNo", beTvl.getTvlTrip().getTvlTripCodeNo());
				datamap.put("passportNo",
						beTvl.getTvlProfile().getAcctPassport().getPassportNo() != null
								? beTvl.getTvlProfile().getAcctPassport().getPassportNo()
								: "xxx");

				List<FcmDevice> devices = searchAllDevice(profile, request);
				addFCMNotification(devices, profile, datamap, fcmtemplate, request);

			}

		} catch (Exception e) {
			// safety reason : ignore and check if payload created
		}

	}
}
