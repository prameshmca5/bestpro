/**
 * Copyright 2020. Bestinet Sdn Bhd
 */
package com.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * @author nurul.naimma
 *
 * @since Jul 17, 2020
 */
public class DashsyncTokenResp implements Serializable {

	private static final long serialVersionUID = -7577919504047153305L;

	@JsonProperty(value = "Token")
	String token;

	@JsonProperty(value = "Status")
	String status;

	@JsonProperty(value = "Message")
	String message;


	public String getToken() {
		return token;
	}


	public void setToken(String token) {
		this.token = token;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}

}
