/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.model;


import java.io.Serializable;


/**
 * @author Chaithanya
 * @since 09/07/2018
 */
public class MultiChannel implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 6645623423283005357L;

	private Integer mulChannelId;

	private String merchantId;

	private String channel;

	private Double rate;

	private Double cost;
	
	private String pid;


	public Integer getMulChannelId() {
		return mulChannelId;
	}


	public void setMulChannelId(Integer mulChannelId) {
		this.mulChannelId = mulChannelId;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public Double getRate() {
		return rate;
	}


	public void setRate(Double rate) {
		this.rate = rate;
	}


	public Double getCost() {
		return cost;
	}


	public void setCost(Double cost) {
		this.cost = cost;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getPid() {
		return pid;
	}


	public void setPid(String pid) {
		this.pid = pid;
	}
 
}