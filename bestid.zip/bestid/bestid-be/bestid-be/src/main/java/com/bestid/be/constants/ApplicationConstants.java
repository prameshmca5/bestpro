/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bestid.be.constants;


/**
 * @author mary.jane
 * @since Nov 12, 2018
 */
public final class ApplicationConstants {

	private ApplicationConstants() {
		throw new IllegalStateException("ApplicationConstants Utility class");
	}


	public static final String ENCODING = "UTF-8";

	public static final String ICE_GATEWAY_USER_KEY = "gw-username";

	public static final String ICE_GATEWAY_PASS_KEY = "gw-password";

	public static final String ICE_GATEWAY_TO_CONTACT_KEY = "gw-to";

	public static final String ICE_GATEWAY_FROM_CONTACT_KEY = "gw-from";

	public static final String ICE_GATEWAY_CODING_KEY = "gw-coding";

	public static final String ICE_GATEWAY_CODING_VAL = "1";

	public static final String ICE_GATEWAY_MSG_KEY = "gw-text";

	public static final String CHARACTER_ENCODE_FORMAT_UTF = "UTF-8";

	public static final String ICE_GATEWAY_FROM_VAL = "SPPA";

	public static final String AMPERSAND_STRING_SEPERATOR = "&";

	public static final String EQUALS_STRING_SEPERATOR = "=";

	public static final String STATUS_PREFIX = "STATUS_";

	public static final String OTP_SUCCESS_STATUS = "SMS Sent Successfully";

	public static final String PORTAL_MODULE = "portalModule";

	public static final String PORTAL_TYPE = "portalType";

	public static final String PORTAL_TRANS_ID = "portalTransId";

	public static final String PORTAL_SCRIPT = "portalScript";

	public static final String PORTAL_SCRIPT_JS = "portalScriptJs";

	public static final String PAGE_TITLE = "pageTitle";

	public static final String FORCE_LOGOUT = "FORCE_LOGOUT";

	public static final String ACTIVE = "A";

	public static final String INACTIVE = "I";

	public static final String MISIGNET_STATUS_SUCCESS = "1000";

	public static final String CERT_BEGIN_STR = "-----BEGIN CERTIFICATE-----";

	public static final String CERT_END_STR = "-----END CERTIFICATE-----";

	public static final String ICAO_RESULT_FAIL = "fail";

	public static final String CERT_SRC_MSCTG = "1";

	public static final String CERT_SRC_CS2 = "2";

}