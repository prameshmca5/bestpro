/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public class BeConfigConstants {

	private BeConfigConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String SMS_SWITCH = "SMS_SWITCH";

	public static final String GOV_PORTAL_ACCESS_FROM = "GOV_PORTAL_ACCESS_FROM";

	public static final String GOV_PORTAL_ACCESS_TO = "GOV_PORTAL_ACCESS_TO";

	// Quota Allocation
	public static final String QUOTA_ASSIGN_REMAINDER = "QUOTA_ASSIGN_REMAINDER";

	public static final String MAX_QUOTA_ASSIGN_SUPERCORE = "MAX_QUOTA_ASSIGN_SUPERCORE";

	public static final String MAX_QUOTA_ASSIGN_CORE = "MAX_QUOTA_ASSIGN_CORE";

	public static final String MAX_QUOTA_ASSIGN_NONCORE = "MAX_QUOTA_ASSIGN_NONCORE";

	public static final String MAX_CYCLE_SUPERCORE = "MAX_CYCLE_SUPERCORE";

	public static final String MAX_CYCLE_CORE = "MAX_CYCLE_CORE";

	public static final String MAX_CYCLE_NONCORE = "MAX_CYCLE_NONCORE";

	public static final String MAX_DAYS_AUTO_ABORT_NNS = "MAX_DAYS_AUTO_ABORT_NNS";

	public static final String QUOTA_NNS_KDN_PREFIX = "QUOTA_NNS_KDN_PREFIX";

	public static final String QUOTA_NNS_CREATE_ID = "QUOTA_NNS_CREATE_ID";

	public static final String QUOTA_APP_PREFIX = "QUOTA_APP_PREFIX";

	public static final String DAYS_OF_DIFF = "DAYS_OF_DIFF";

	public static final String EA_PMT_MAX_DAYS = "EA_PMT_MAX_DAYS";

	public static final String NOT_MI_COUNTRY_CODE = "MI_COUNTRY_CODE";

	public static final String STCK_DEF_STCK_PER_ROLL = "STCK_DEF_STCK_PER_ROLL";

}