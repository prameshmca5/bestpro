/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author Atiqah Khairuddin
 * @since Sept 13, 2018
 */
public class SubscriptionPlan implements Serializable {

	private static final long serialVersionUID = 607657392585361232L;

	private Integer subPlanId;

	private String planType;

	private String planDesc;

	private String planRatio;

	private String planValue;

	private String planDataType;

	private String remarks;

	private String status;

	private String createId;

	private Timestamp createDt;

	private String updateId;

	private Timestamp updateDt;


	public Integer getSubPlanId() {
		return subPlanId;
	}


	public void setSubPlanId(Integer subPlanId) {
		this.subPlanId = subPlanId;
	}


	public String getPlanType() {
		return planType;
	}


	public void setPlanType(String planType) {
		this.planType = planType;
	}


	public String getPlanDesc() {
		return planDesc;
	}


	public void setPlanDesc(String planDesc) {
		this.planDesc = planDesc;
	}


	public String getPlanRatio() {
		return planRatio;
	}


	public void setPlanRatio(String planRatio) {
		this.planRatio = planRatio;
	}


	public String getPlanValue() {
		return planValue;
	}


	public void setPlanValue(String planValue) {
		this.planValue = planValue;
	}


	public String getPlanDataType() {
		return planDataType;
	}


	public void setPlanDataType(String planDataType) {
		this.planDataType = planDataType;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

}