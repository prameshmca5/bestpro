package com.portal.web.mc.controller;


import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.be.sdk.model.AcctPassport;
import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.Country;
import com.be.sdk.model.MRZdata;
import com.be.sdk.model.McAttendance;
import com.be.sdk.model.Metadata;
import com.be.sdk.model.Payment;
import com.be.sdk.model.Status;
import com.be.sdk.model.Tvl;
import com.be.sdk.model.TvlProfile;
import com.camvi.sdk.client.CamviServiceClient;
import com.camvi.sdk.model.CamviResponse;
import com.camvi.sdk.model.PersonDto;
import com.dm.sdk.model.Documents;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.icao.sdk.client.IcaoServiceClient;
import com.icao.sdk.model.IcaoInfo;
import com.icao.sdk.model.IcaoResponse;
import com.idm.sdk.exception.IdmException;
import com.idm.sdk.model.UserProfile;
import com.portal.constants.CryptoBaseUtil;
import com.portal.constants.MessageConstants;
import com.portal.constants.PageConstants;
import com.portal.constants.PageTemplate;
import com.portal.constants.ProjectEnum;
import com.portal.core.AbstractController;
import com.portal.web.idm.form.FaceEnrollForm;
import com.portal.web.mc.form.PersonFormDto;
import com.portal.web.util.WebUtil;
import com.util.BaseUtil;
import com.util.CryptoUtil;
import com.util.DateUtil;
import com.util.JsonUtil;
import com.util.MediaType;
import com.util.PopupBox;
import com.util.constants.BaseConstants;
import com.util.pagination.DataTableResults;


@Controller
@RequestMapping(value = PageConstants.PAGE_MC_VERIFY_ATT)
public class McVerifyAttendanceController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(McVerifyAttendanceController.class);

	private static final String JS_FILENAME = "mc-verify";

	private static final String MODULE = "mc-verify_att";

	@Autowired
	private CamviServiceClient camviService;

	@Autowired
	private IcaoServiceClient icaoService;

	@Autowired
	@Qualifier("travellerInfoValidator")
	private Validator validator;


	@Override
	public void bindingPreparation(WebDataBinder binder) {
		binder.setValidator(validator);
		super.bindingPreparation(binder);
	}


	@GetMapping()
	public ModelAndView view(Tvl tvl, BindingResult result) {
		ModelAndView mav = getDefaultMav(PageTemplate.MEDICAL_VERIFY_ATT_LIST, MODULE, MODULE, null, JS_FILENAME);

		
		String keySecret = staticData.beConfig("HASH_SECRET_KEY");
		mav.addObject("tvl", tvl);
		return mav;
	}


	@GetMapping(value = "/paginated")
	public @ResponseBody String getApplicationInfoPaginated(@ModelAttribute("tvl") Tvl tvl, BindingResult result,
			HttpServletRequest request) {
		LOGGER.info("GET PAGINATED USER LIST....");
		DataTableResults<Tvl> travlr = null;
		UserProfile currentUser = getCurrentUser();
		try {
			tvl.setEmbedMedical(true);
			tvl.setEmbedPayment(true);
			tvl.setEmbedPaymentDtl(true);

			if (BaseUtil.isObjNull(tvl.getStatusCd())) {
				tvl.setStatusIdList(new ArrayList<Integer>());
				tvl.getStatusIdList().add(staticData.statusByStatusType("PS", "PMT").getStatusId());
				// tvl.getStatusIdList().add(staticData.statusByStatusType("AT_VER",
				// "MC").getStatusId());
			} else {
				List<Status> statusLst = staticData.findByStatusCd(tvl.getStatusCd());
				tvl.setStatusId(statusLst.get(0).getStatusId());
			}

			if (!BaseUtil.isObjNull(tvl.getPmtDtFrom()) && !BaseUtil.isObjNull(tvl.getPmtDtTo())) {
				Payment payment = new Payment();
				payment.setPmtDtFrom(tvl.getPmtDtFrom());
				payment.setPmtDtTo(tvl.getPmtDtTo());
				tvl.setTvlPayment(payment);
			}

			// to filter based on countryCd of the OPERATOR/DOCTOR
			tvl.setCountryCd(currentUser.getCntryCd());

			TvlProfile tvlProfile = new TvlProfile();

			if (!BaseUtil.isObjNull(tvl.getPassportNo())) {
				AcctPassport acctPassport = new AcctPassport();
				acctPassport.setPassportNo(tvl.getPassportNo());
				tvlProfile.setAcctPassport(acctPassport);
			}

			if (!BaseUtil.isObjNull(tvl.getFullName())) {
				tvlProfile.setFullName(tvl.getFullName());
			}

			tvl.setTvlProfile(tvlProfile);

			// tvl.setAcctProfId(getCurrentUser().getProfId());
			travlr = getBeService().travelService().searchTravelPagination(tvl, getPaginationRequest(request, true));

			String keySecret = staticData.beConfig("HASH_SECRET_KEY");
			
			try {
				List<Tvl> tempListTvl = JsonUtil.objectMapper().convertValue(travlr.getData(), new TypeReference<List<Tvl>>() {
				});
				
				tempListTvl = tempListTvl.stream().map(tvlObj->{
					String cyptString = CryptoBaseUtil.encrypt(tvlObj.getTvlProfile().getTvlProfId(),keySecret );
					tvlObj.setSecCdId(cyptString);
					return tvlObj;
				}).collect(Collectors.toList());
				travlr.setData(tempListTvl);

			} catch (IdmException e) {
				LOGGER.error(BaseConstants.LOG_IDM_EXCEPTION, e.getMessage());
				if (WebUtil.checkTokenError(e) || WebUtil.checkSystemDown(e)) {
					throw e;
				}
			} catch (Exception e) {
				LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
			}

		} catch (Exception e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(e.getMessage());
		}

		return new Gson().toJson(travlr);
	}


	@RequestMapping(value = "/updateStatus/{profileProfId}", method = RequestMethod.GET)
	public ModelAndView mcAttUpdate(@PathVariable String profileProfId) {
		ModelAndView mav = getDefaultMav(PageTemplate.MEDICAL_VERIFY_PHOTO_ATT, MODULE, MODULE, null, "camera");
		boolean isView = false;
		Tvl trvlProf = null;
		int alreadySuccess = 0;
		String profileProfIdCrypted = profileProfId;
		
		try {
			profileProfId = CryptoBaseUtil.decrypt(profileProfId, staticData.beConfig("HASH_SECRET_KEY"));
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		LOGGER.info("mc att Update Page::::::::");
		try {
			Tvl tvlRsult = new Tvl();
			TvlProfile tvlProfile = new TvlProfile();
			tvlProfile.setTvlProfId(Integer.parseInt(profileProfId));
			tvlRsult.setTvlProfile(tvlProfile);
			tvlRsult.setEmbedMedical(true);
			tvlRsult.setEmbedTrip(true);
			tvlRsult.setEmbedMcCollates(true);
			trvlProf = getBeService().travelService().getTravel(tvlRsult);
			trvlProf.setSecCdId(profileProfIdCrypted);
			TvlProfile prof = new TvlProfile();
			if (BaseUtil.isEqualsCaseIgnore(trvlProf.getTvlProfile().getGender(), "F")) {
				prof.setGender("Female");
			} else {
				prof.setGender("Male");
			}

			if (!BaseUtil.isObjNull(trvlProf.getStatus())) {
				alreadySuccess = trvlProf.getStatus().getStatusId() == 105 ? 1 : 0;
				if (BaseUtil.isEquals(trvlProf.getStatus().getStatusCd(), "AT_VER")) {
					isView = true;
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
		mav.addObject("trvlProf", trvlProf);

		mav.addObject("edit_mc_attendace", true);
		mav.addObject("isView", isView);
		mav.addObject("alreadySuccess", alreadySuccess);
		mav.addObject("tvl", new Tvl());
		return mav;
	}


	@PostMapping(value = "/updateStatus/{profileProfId}", params = "update")
	public ModelAndView update(@PathVariable String profileProfId, @ModelAttribute("tvl") Tvl tvl,
			BindingResult result, HttpSession session, HttpServletRequest request) {
		int alreadySuccess = 0;
		ModelAndView mav = getDefaultMav(PageTemplate.MEDICAL_VERIFY_PHOTO_ATT, MODULE, MODULE, null, "camera");
		LOGGER.info("SUBMIT------------------------");
		

		
		try {
			profileProfId = CryptoBaseUtil.decrypt(profileProfId, staticData.beConfig("HASH_SECRET_KEY"));
		} catch (Exception e) {
			// TODO: handle exception
		}

		Tvl trvlProf = null;
		Tvl tvlRsult = new Tvl();

		TvlProfile tvlProfile = new TvlProfile();
		tvlProfile.setTvlProfId(Integer.parseInt(profileProfId));
		tvlRsult.setTvlProfile(tvlProfile);
		tvlRsult.setEmbedMedical(true);
		trvlProf = getBeService().travelService().getTravel(tvlRsult);
		UserProfile mcProfId = getCurrentUser();
		// McProfile mcProfId =getBeService().
		String imgDocStr = genBase64ImgStrByRefNo(trvlProf.getTvlProfile().getPhotoId());

		boolean resp = camviService.compareFaceImage(imgDocStr, tvl.getImageLv());
		if (resp == true) {
			McAttendance mcAtt = new McAttendance();
			mcAtt.setMcProfId(mcProfId.getProfId());
			mcAtt.setTvlProfId(trvlProf.getTvlProfile().getTvlProfId());
			mcAtt.setStatusId(105);
			alreadySuccess = 1;
			mcAtt = getBeService().addAttendanceInfo(mcAtt);

			if (!BaseUtil.isObjNull(mcAtt)) {
				trvlProf.setStatusMcAttndace("PASS");
			} else {
				trvlProf.setStatusMcAttndace("FAILED");
			}
		} else {
			trvlProf.setStatusMcAttndace("FAILED");
			/*
			 * mav.addAllObjects(PopupBox.success(MessageConstants.
			 * ERROR_MISMATCH_PHOTO, null,
			 * messageService.getMessage(MessageConstants.
			 * ERROR_MISMATCH_PHOTO),PageConstants.PAGE_MC_VERIFY_ATT));
			 */
		}

		// return this.mcAttUpdate(profileProfId, tvlRsult, result, session);

		mav.addObject("trvlProf", trvlProf);
		// mav.addObject("edit_mc_attendace", true);
		mav.addObject("edit_mc_attendace", true);
		mav.addObject("isView", true);
		mav.addObject("alreadySuccess", alreadySuccess);
		return mav;
	}


	public String genBase64ImgStrByRefNo(@RequestParam(required = true) String img) {

		try {

			Documents doc = getDmService(ProjectEnum.MYIP).download(img);
			if (!BaseUtil.isObjNull(doc) && !BaseUtil.isObjNull(doc.getContent())) {
				byte[] rawByte = doc.getContent();
				return Base64.encodeBase64String(rawByte);
			}

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
		}
		return null;
	}


	@GetMapping(params = "acctTvlrId")
	public ModelAndView view(@RequestParam String acctTvlrId, UserProfile userProfile, BindingResult result) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_IDM_FACE, MODULE, MODULE, null, JS_FILENAME);
		mav.addObject("acctTvlrId", "EMP000341");
		mav.addObject("edit_mc_attendace", true);
		return mav;
	}


	/**
	 * Check Image Quality
	 *
	 * @param quality
	 * @param faceEnroll
	 * @param result
	 * @return
	 */
	@PostMapping(params = "quality")
	public @ResponseBody CamviResponse checkQuality(@RequestParam String quality, FaceEnrollForm faceEnroll,
			BindingResult result) {
		// Check Image Quality

		CamviResponse response = camviService.checkQuality(faceEnroll.getImage());
		LOGGER.info("Check Photo Quality Response: {}", new ObjectMapper().valueToTree(response));
		return response;
	}


	/**
	 * Face Detection
	 *
	 * @param detect
	 * @param faceEnroll
	 * @param result
	 * @return
	 */
	@PostMapping(params = "detect")
	public @ResponseBody PersonDto detect(@RequestParam String detect, FaceEnrollForm faceEnroll,
			BindingResult result) {
		return camviService.detectFaceImage(faceEnroll.getEmail(), faceEnroll.getImage());
	}


	/**
	 * Register Face ID
	 *
	 * @param enroll
	 * @param faceEnroll
	 * @param result
	 * @return
	 */
	/* @PostMapping(params = "enrollverify") */
	public PersonDto enrollverify(@RequestParam String enroll, FaceEnrollForm faceEnroll, BindingResult result) {
		PersonDto person = null;

		// if(!BaseUtil.isObjNull(faceEnroll.getImage())) {
		// imgLv = faceEnroll.getImage();
		// }

		byte[] raw;
		raw = Base64.decodeBase64(faceEnroll.getImage());

		Documents photo = new Documents();
		photo.setContent(raw);
		photo.setDocid(1);
		photo.setContentType(MediaType.IMAGE_PNG);
		photo.setRefno(faceEnroll.getStaffId());
		// photo = getDmService(ProjectEnum.MYIP).upload(photo);
		LOGGER.info("PersonDto: {}", new ObjectMapper().valueToTree(photo));

		LOGGER.info("PersonDto: {}", new ObjectMapper().valueToTree(person));
		return person;
	}


	/**
	 * Register Face ID
	 *
	 * @param enroll
	 * @param faceEnroll
	 * @param result
	 * @return
	 */
	@PostMapping(params = "enroll")
	public @ResponseBody PersonFormDto enroll(@RequestParam String enroll, FaceEnrollForm faceEnroll,
			BindingResult result) {
		PersonDto person = null;
		PersonFormDto personForm = new PersonFormDto();

		/*
		 * if (!BaseUtil.isObjNull(faceEnroll.getFaceId())) { person =
		 * camviService.appendFaceByPersonId(faceEnroll.getFaceId(),
		 * faceEnroll.getImage()); } else { person =
		 * camviService.createPerson("0", faceEnroll.getImage());
		 *
		 * }
		 */

		if (enroll.equalsIgnoreCase("")) {
			enrollverify(enroll, faceEnroll, result);
			// personForm
			return personForm;
		}

		person = camviService.createPerson("0", faceEnroll.getImage());
		byte[] raw;
		raw = Base64.decodeBase64(faceEnroll.getImage());

		Documents photo = new Documents();
		photo.setContent(raw);

		photo.setDocid(1);
		photo.setContentType(MediaType.IMAGE_PNG);
		photo.setRefno(faceEnroll.getStaffId());
		photo = getDmService(ProjectEnum.MYIP).upload(photo);
		LOGGER.info("PersonDto: {}", new ObjectMapper().valueToTree(photo));

		Documents photoInfo = dozerMapper.map(photo, Documents.class);
		PersonDto personInfo = dozerMapper.map(person, PersonDto.class);

		if (enroll.equals("profile")) {
			// faceId= personInfo.getFaceId();
			// mgmtDocId = photoInfo.getId();

			personForm.setFaceId(personInfo.getFaceId());
			personForm.setPhotoId(photoInfo.getId());
		} else {
			byte[] encodeBase64;
			MRZdata mrZdata = new MRZdata();
			encodeBase64 = Base64.decodeBase64(faceEnroll.getImage());
			mrZdata.setScan_image_base64(encodeBase64);
			mrZdata.setCard_code("MRZ");
			mrZdata.setCountry_code("MYS");
			try {
				mrZdata = getBeService().travellerService().readPassport(mrZdata);
			} catch (Exception e) {
				LOGGER.info(e.getMessage());
			}

			if (BaseUtil.isObjNull(mrZdata.getFirstname())) {
				// mrZdata.setFirstname("MUHAMAD LALA");
				// mrZdata.setCountry("MYS");
				// mrZdata.setNationality("MYS");
				// mrZdata.setExpiryDate("210801");
				// mrZdata.setDob("210801");
			}

			LOGGER.info("mrZdata ", mrZdata);
			// passMgmtDocId = photoInfo.getId();
			personForm.setId(photoInfo.getId());
			personForm.setmRZdata(mrZdata);
		}

		LOGGER.info("photoId::{}", photoInfo.getId());
		LOGGER.info("FaceId::{}", personInfo.getFaceId());

		// personForm.getPhotoId()

		LOGGER.info("PersonDto: {}", new ObjectMapper().valueToTree(person));
		return personForm;
	}


	/**
	 * ICAO Checking
	 *
	 * @param icao
	 * @param faceEnroll
	 * @param result
	 * @return
	 */
	@PostMapping(params = "icao")
	public @ResponseBody IcaoResponse icaoCheck(@RequestParam String icao, FaceEnrollForm faceEnroll,
			BindingResult result) {
		IcaoResponse response = null;
		try {
			LOGGER.info("ICAO Criteria: {}", new ObjectMapper().valueToTree(faceEnroll.getIcaoCriteria()));
			List<IcaoInfo> icaoInfo = IcaoInfo.findListByCriteria(faceEnroll.getIcaoCriteria());
			List<IcaoInfo> icaoInfoRequired = IcaoInfo.findListByCriteria(faceEnroll.getIcaoCriteriaRequired());
			LOGGER.info("ICAO Criteria: {}", icaoInfo);
			response = icaoService.verifyPhoto2(faceEnroll.getImage(), icaoInfo,icaoInfoRequired);
			LOGGER.info("ICAO Checking Response: {}", new ObjectMapper().valueToTree(response));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			LOGGER.error(e.getMessage());

		}

		return response;
	}


	@RequestMapping(value = "/{id}/update")
	public ModelAndView edit(@PathVariable("id") String ids, @ModelAttribute("acctTraveller") AcctTraveller acctTraveller,
			UserProfile userProfile, Model model) {
		
		int id = 0;
		
		try {
			id = CryptoBaseUtil.decryptInteger(ids, staticData.beConfig("HASH_SECRET_KEY"));
		} catch (Exception e) {
			// TODO: handle exception
		}
		

		String url_path_string = "trvler-verify";
		String statusDesc = "";

		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TRAVELLER_INFO_UPD, url_path_string, url_path_string, null,
				"traveller");
		boolean isView = false;
		AcctTraveller dto = new AcctTraveller();
		dto.setAcctTvlrId(id);
		dto.setView(true);
		Tvl trvlProf = new Tvl();
		try {
			Tvl tvlRsult = new Tvl();
			TvlProfile tvlProfile = new TvlProfile();
			tvlProfile.setTvlProfId(id);
			tvlRsult.setTvlProfile(tvlProfile);
			tvlRsult.setEmbedMedical(true);
			tvlRsult.setEmbedTraveller(true);
			trvlProf = getBeService().travelService().getTravel(tvlRsult);
			dto.setAcctTvlrId(trvlProf.getTvlProfile().getAcctTraveller().getAcctTvlrId());
			acctTraveller = getBeService().travellerService().getAcctTraveller(dto);
			if (!BaseUtil.isObjNull(acctTraveller.getDob())) {
				acctTraveller.setDobStr(DateUtil.getFormatDateWithSlash(acctTraveller.getDob()));
			}

			if (!BaseUtil.isObjNull(acctTraveller.getAcctPassport().getPassportExpiryDt())) {
				acctTraveller.setPassportExpStr(
						DateUtil.getFormatDateWithSlash(acctTraveller.getAcctPassport().getPassportExpiryDt()));
			}

			if (BaseUtil.isEqualsCaseIgnore(acctTraveller.getRelationMtdt().getMtdtCd(), "SLF")) {
				Metadata relationMtdt = new Metadata();
				relationMtdt.setMtdtDesc("SELF");
				List<Metadata> types = staticData.findByMetadataCd("SLF");
				relationMtdt.setMtdtId(types.get(0).getMtdtId());
				relationMtdt.setMtdtCd(types.get(0).getMtdtCd());
				acctTraveller.setRelationMtdt(relationMtdt);
				mav.addObject("self", "true");
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

		if (!BaseUtil.isObjNull(trvlProf.getStatus())) {
			statusDesc = trvlProf.getStatus().getStatusDesc();
			if (BaseUtil.isEquals(trvlProf.getStatus().getStatusCd(), "AT_VER")) {
				isView = true;
			}
		}

		mav.addObject("acctTraveller", acctTraveller);
		mav.addObject("acctTravel", acctTraveller);
		mav.addObject("status", statusDesc);
		model.addAttribute("showRelation", true);
		model.addAttribute("saveCloseStatus", true);
		model.addAttribute("saveNextStatus", false);
		mav.addObject("addType", false);
		mav.addObject("edit_mc_attendace", true);
		mav.addObject("isView", isView);
		return mav;

	}


	@RequestMapping(value = "/{id}/update", method = RequestMethod.POST)
	public ModelAndView update(@PathVariable("id") String ids,
			@ModelAttribute("acctTraveller") @Valid @Validated AcctTraveller acctTraveller, BindingResult result,
			Model model, HttpServletRequest request) throws ParseException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TRAVELLER_INFO_UPD, MODULE, null, null, "traveller");

		
		int id = 0;
		
		try {
			id = CryptoBaseUtil.decryptInteger(ids, staticData.beConfig("HASH_SECRET_KEY"));
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		boolean isView = false;
		AcctTraveller dto = new AcctTraveller();
		dto.setAcctTvlrId(id);
		dto.setView(true);
		Tvl trvlProf = new Tvl();
		Tvl tvlRsult = new Tvl();
		String statusDesc = "";

		if (!result.hasErrors()) {
			try {

				TvlProfile tvlProfile = new TvlProfile();
				tvlProfile.setTvlProfId(id);
				tvlRsult.setTvlProfile(tvlProfile);
				tvlRsult.setEmbedMedical(true);
				tvlRsult.setEmbedTraveller(true);
				trvlProf = getBeService().travelService().getTravel(tvlRsult);

				dto.setAcctTvlrId(trvlProf.getTvlProfile().getAcctTraveller().getAcctTvlrId());

				AcctTraveller acctTravellerTemp = getBeService().travellerService().getAcctTraveller(dto);
				AcctPassport acctPassport = acctTraveller.getAcctPassport();

				acctTraveller.setAcctTvlrId(acctTravellerTemp.getAcctTvlrId());
				acctPassport.setPassportId(acctTravellerTemp.getAcctPassport().getPassportId());

				Country country = new Country();
				country.setCntryCd(acctTraveller.getAcctPassport().getNationality().getCntryCd());

				acctPassport.setNationality(country);

				if (!BaseUtil.isObjNull(acctTraveller.getPassportExpStr())) {
					acctPassport.setPassportExpiryDt(DateUtil.getFormatDate(acctTraveller.getPassportExpStr(),
							BaseConstants.DT_DD_MM_YYYY_SLASH));
				}
				acctTraveller.setAcctPassport(acctPassport);
				acctTraveller.setRelationMtdt(checkValueRelation(acctTraveller.getRelationMtdt()));
				acctTraveller.setEcRelationMtdt(checkValueRelation(acctTraveller.getEcRelationMtdt()));

				acctTraveller.setTypeMtdt(checkValueType(acctTraveller.getTypeMtdt()));

				// set date dob
				if (!BaseUtil.isObjNull(acctTraveller.getDobStr())) {
					acctTraveller.setDob(DateUtil.getFormatDate(acctTraveller.getDobStr(),
							BaseConstants.DT_DD_MM_YYYY_SLASH));
				}

				acctTraveller = getBeService().travellerService().addTravellerInfo(acctTraveller,
						getCurrentUser().getProfId());

				if (!BaseUtil.isObjNull(acctTraveller)) {
					return new ModelAndView(
							PageConstants.getRedirectUrl("/mcVerifyAttendance/updateStatus/" + ids));

				} else {
					mav.addAllObjects(PopupBox.error(MessageConstants.ERR_UPDATE_TRAVELLER, null,
							messageService.getMessage(MessageConstants.ERR_UPDATE_TRAVELLER)));
				}
			} catch (Exception e) {
				// TODO: handle exception
				LOGGER.info("error add proceed");
				e.printStackTrace();
				LOGGER.info(e.getMessage());
				mav.addAllObjects(PopupBox.error(MessageConstants.ERR_UPDATE_TRAVELLER, null,
						messageService.getMessage(MessageConstants.ERR_UPDATE_TRAVELLER)));
			}
			mav.addObject("acctTraveller", acctTraveller);

		} else {
			tvlRsult.setTvlProfId(id);
			tvlRsult.setEmbedMedical(true);
			tvlRsult.setEmbedTraveller(true);
			trvlProf = getBeService().travelService().getTravel(tvlRsult);
			dto.setAcctTvlrId(trvlProf.getTvlProfile().getAcctTraveller().getAcctTvlrId());
			acctTraveller = getBeService().travellerService().getAcctTraveller(dto);
			AcctPassport acctPassport = acctTraveller.getAcctPassport();

			if (!BaseUtil.isObjNull(acctTraveller.getPassportExpStr())) {
				acctPassport.setPassportExpiryDt(DateUtil.getFormatDate(acctTraveller.getPassportExpStr(),
						BaseConstants.DT_DD_MM_YYYY_SLASH));
				acctTraveller.setAcctPassport(acctPassport);
			}

			// set date dob
			if (!BaseUtil.isObjNull(acctTraveller.getDobStr())) {
				acctTraveller.setDob(
						DateUtil.getFormatDate(acctTraveller.getDobStr(), BaseConstants.DT_DD_MM_YYYY_SLASH));
			}

			if (!BaseUtil.isObjNull(trvlProf.getStatus())) {
				statusDesc = trvlProf.getStatus().getStatusDesc();
				if (BaseUtil.isEquals(trvlProf.getStatus().getStatusCd(), "AT_VER")) {
					isView = true;
				}
			}

			if (BaseUtil.isEqualsCaseIgnore(acctTraveller.getRelationMtdt().getMtdtCd(), "SLF")) {
				Metadata relationMtdt = new Metadata();
				relationMtdt.setMtdtDesc("SELF");
				List<Metadata> types = staticData.findByMetadataCd("SLF");
				relationMtdt.setMtdtId(types.get(0).getMtdtId());
				acctTraveller.setRelationMtdt(relationMtdt);
				mav.addObject("self", "true");
			}

			mav.addObject("acctTravel", acctTraveller);
			mav.addObject("status", statusDesc);

		}

		mav.addObject("edit_mc_attendace", true);
		model.addAttribute("showRelation", true);
		model.addAttribute("saveCloseStatus", true);
		model.addAttribute("saveNextStatus", false);
		mav.addObject("isView", isView);
		return mav;

	}


	@PostMapping(value = "/getType", params = "type")
	public @ResponseBody String getPaginated(@RequestParam String type, HttpServletRequest request) throws Exception {

		if (BaseUtil.isObjNull(type)) {
			return null;
		}

		try {
			// checking valid integer using parseInt() method
			Integer.parseInt(type);
		} catch (NumberFormatException e) {
			return "";
		}

		int num = Integer.parseInt(type);
		String text = null;

		if (num >= 12) {
			text = "A";
		} else if (num >= 2) {
			text = "C";
		} else {
			text = "I";
		}

		Metadata desc = null;

		try {
			for (Metadata typeMeta : getTypeList()) {
				if (typeMeta.getMtdtCd().contains(text)) {
					desc = typeMeta;
					break;
				}
			}

			return new Gson().toJson(desc);
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}

	}


	@ModelAttribute("getTypeList")
	public List<Metadata> getTypeList() {

		List<Metadata> types = null;
		try {
			types = staticData.findByMetadataType("TRAVELLER");
		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
		}

		return types;
	}


	private Metadata checkValueRelation(Metadata data) {
		Metadata tempdata = null;
		if (data != null) {
			LOGGER.info("status luar " + data.getMtdtCd());
			if (data.getMtdtCd() != null && data.getMtdtCd() != "") {
				tempdata = staticData.findByMetadataType("RELATION", data.getMtdtCd());
			}
		}

		return tempdata;
	}


	private Metadata checkValueType(Metadata data) {
		Metadata tempdata = null;
		if (data != null) {
			LOGGER.info("status luar " + data.getMtdtCd());
			if (data.getMtdtCd() != null && data.getMtdtCd() != "") {
				tempdata = staticData.findByMetadataType("TRAVELLER", data.getMtdtCd());
			}
		}

		return tempdata;
	}


	/**
	 * Passport Photo ID
	 *
	 * @param enroll
	 * @param passportEnroll
	 * @param result
	 * @return
	 */
	@PostMapping(params = "enrollPassport")
	public @ResponseBody PersonDto enrollPassport(@RequestParam String enroll, FaceEnrollForm faceEnroll,
			BindingResult result) {
		PersonDto person = null;
		if (!BaseUtil.isObjNull(faceEnroll.getFaceId())) {
			person = camviService.appendFaceByPersonId(faceEnroll.getFaceId(), faceEnroll.getImage());
		} else {
			person = camviService.createPerson(faceEnroll.getEmail(), faceEnroll.getImage());

		}
		byte[] raw;
		raw = Base64.decodeBase64(faceEnroll.getImage());

		Documents photo = new Documents();
		photo.setContent(raw);
		photo.setId(null);
		photo.setDocid(86);
		photo.setContentType(MediaType.IMAGE_PNG);
		photo.setRefno(faceEnroll.getStaffId());
		photo = getDmService(ProjectEnum.MYIP).upload(photo);
		LOGGER.info("PhotoDto: {}", new ObjectMapper().valueToTree(photo));
		LOGGER.info("PersonDto: {}", new ObjectMapper().valueToTree(person));

		dozerMapper.map(photo, Documents.class);
		// passMgmtDocId = photoInfo.getId();
		return person;
	}


	@ModelAttribute("getStatusList")
	public List<Status> getStatusList() {

		List<Status> types = null;
		List<Status> statLst = new ArrayList<>();
		try {
			types = staticData.findAllStatus();

			if (!BaseUtil.isListNull(types)) {
				for (Status stat : types) {
					if (BaseUtil.isEquals(stat.getStatusCd(), "PS")) {
						statLst.add(stat);
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
		}
		return statLst;
	}


	@ModelAttribute("getCountryList")
	public List<Country> getCountryList() {
		List<Country> list = new ArrayList<>();

		try {
			list = staticData.countryList();
			LOGGER.debug("country sizes " + list.size());
		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
		}

		return list;
	}


	@ModelAttribute("getRelationList")
	public List<Metadata> getRelationList() {
		List<Metadata> types = null;
		List<Metadata> newtypes = new ArrayList<>();
		try {
			types = staticData.findByMetadataType("RELATION");
			for (Metadata mtdt : types) {
				if (!BaseUtil.isEqualsCaseIgnore(mtdt.getMtdtCd(), "SLF")) {
					newtypes.add(mtdt);
				}

			}
		} catch (Exception e) {
			LOGGER.error(BaseConstants.LOG_EXCEPTION, e.getMessage());
		}
		LOGGER.debug("size " + newtypes.size());

		return newtypes;
	}

}