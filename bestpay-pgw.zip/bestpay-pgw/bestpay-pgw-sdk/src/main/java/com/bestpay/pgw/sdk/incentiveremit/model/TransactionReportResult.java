package com.bestpay.pgw.sdk.incentiveremit.model;


import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "TransactionReportResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class TransactionReportResult {

	@XmlElement(name = "Return_TRANSREPORT")
	private List<TransactionReport> transactionReports;


	public List<TransactionReport> getTransactionReports() {
		return transactionReports;
	}


	public void setTransactionReports(List<TransactionReport> transactionReports) {
		this.transactionReports = transactionReports;
	}

}
