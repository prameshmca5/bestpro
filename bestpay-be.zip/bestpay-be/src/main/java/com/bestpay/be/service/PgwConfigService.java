/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.service;


import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.be.core.AbstractService;
import com.bestpay.be.dao.PgwConfigCustomDao;
import com.bestpay.be.dao.PgwConfigRepository;
import com.bestpay.be.model.PgwConfig;
import com.bestpay.be.sdk.constants.BeCacheConstants;
import com.bestpay.be.sdk.model.PaymentConfig;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since Aug 22, 2019
 */
@Transactional
@Service(QualifierConstants.PGW_CONFIG_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_CONFIG_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
public class PgwConfigService extends AbstractService<PgwConfig> {

	@Autowired
	PgwConfigRepository pgwConfigDao;

	@Autowired
	PgwConfigCustomDao pgwConfigCustomDao;


	@Override
	public PgwConfigRepository primaryDao() {
		return pgwConfigDao;
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwConfig findPgwConfigById(Integer id) {
		return pgwConfigDao.findPgwConfigById(id);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public PgwConfig findPgwConfigByConfigDesc(String configDesc) {
		return pgwConfigDao.findPgwConfigByConfigDesc(configDesc);
	}


	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public DataTableResults<PgwConfig> searchPgwConfigByPagination(PaymentConfig paymentConfig,
			DataTableRequest dataTableInRQ) {
		return pgwConfigCustomDao.searchPgwConfigByPagination(paymentConfig, dataTableInRQ);
	}

}
