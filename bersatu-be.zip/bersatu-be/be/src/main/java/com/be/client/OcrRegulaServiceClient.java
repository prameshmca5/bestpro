/**
 * Copyright 2021. Bestinet Sdn Bhd
 */
package com.be.client;


import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

import org.apache.http.Header;
import org.apache.http.HttpHeaders;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.be.sdk.constants.BeConfigConstants;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author nurul.naimma
 *
 * @since Jun 3, 2021
 */
public class OcrRegulaServiceClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(OcrRegulaServiceClient.class);

	private String url;

	private String key;

	private int readTimeout;

	PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();


	public OcrRegulaServiceClient(String url, String key, int readTimeOut) {
		this.url = url;
		this.key = key;
		this.readTimeout = readTimeOut;
	}


	public Object ocrIdCardDetails(Object obj) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			String jsonStr = objectMapper.writeValueAsString(obj);

			StringBuilder sbUrl = new StringBuilder();
			sbUrl.append(url);

			LOGGER.info("Regular OCR >> URL: {}", sbUrl);
			LOGGER.debug("Regular OCR >> Entity: {}", jsonStr);

			HttpPost httpPost = new HttpPost(sbUrl.toString());
			StringEntity input = new StringEntity(jsonStr);
			input.setContentType(BeConfigConstants.APPLICATION_JSON);
			httpPost.setEntity(input);

			CloseableHttpResponse httpResponse = getHttpClient().execute(httpPost);
			LOGGER.info("Regular OCR >> Status: {}", httpResponse.getStatusLine().getStatusCode());

			String result = EntityUtils.toString(httpResponse.getEntity());
			LOGGER.info("Regular OCR >> Response: {}", result);
			JsonNode ocrNode = objectMapper.readTree(result);
			LOGGER.info("REGULAR OCR RESPONSE FROM SDK: {}", new ObjectMapper().valueToTree(ocrNode));

			return ocrNode;
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
			throw new BeException(BeErrorCodeEnum.E503C005, new Object[] { url });
		}
	}


	private CloseableHttpClient getHttpClient() {
		TrustManagerFactory trustManagerFactory;
		TrustManager[] trustAllCerts = null;
		HttpClientBuilder builder = HttpClientBuilder.create();
		builder.setConnectionManager(cm);

		try {
			trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			trustManagerFactory.init((KeyStore) null);
			trustAllCerts = trustManagerFactory.getTrustManagers();

			HostnameVerifier hostnameVerifier = new HostnameVerifier() {

				@Override
				public boolean verify(String hostname, SSLSession session) {
					LOGGER.info("SSLConnectionSocketFactory: {}", hostname);
					return true;
				}

			};

			SSLContext sc = SSLContext.getInstance("TLSv1.2");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			HttpsURLConnection.setDefaultHostnameVerifier(hostnameVerifier);

			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sc, new String[] { "TLSv1.2" }, null,
					hostnameVerifier);

			RequestConfig rc = RequestConfig.custom().setAuthenticationEnabled(true)
					.setConnectTimeout(readTimeout * 1000).setConnectionRequestTimeout(readTimeout * 1000)
					.setSocketTimeout(readTimeout * 1000).build();

			builder.setDefaultRequestConfig(rc);
			builder.setSSLContext(sc);
			builder.setSSLSocketFactory(sslsf);
			builder.setSSLHostnameVerifier(hostnameVerifier);

		} catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException e) {
			LOGGER.error("{}", e.getMessage());
		}

		String messageId = UUID.randomUUID().toString();

		List<Header> headers = new ArrayList<>();
		headers.add(new BasicHeader(HttpHeaders.AUTHORIZATION, key));
		headers.add(new BasicHeader(HttpHeaders.CONTENT_TYPE, BeConfigConstants.APPLICATION_JSON));
		headers.add(new BasicHeader(BeConfigConstants.MESSAGE_ID, messageId));

		return builder.build();

	}

}
