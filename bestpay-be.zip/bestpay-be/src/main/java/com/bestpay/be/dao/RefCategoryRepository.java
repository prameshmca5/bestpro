/**
 * Copyright 2017. Bestinet Sdn Bhd
 */
package com.bestpay.be.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.RefCategory;
import com.bestpay.be.util.QualifierConstants;

/**
 * @author Afif saman
 * @since Jul 10, 2018
 */
@Repository
@RepositoryDefinition(domainClass = RefCategory.class, idClass = Integer.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_CATEGORY_DAO)
public interface RefCategoryRepository extends
		GenericRepository<RefCategory> {

}