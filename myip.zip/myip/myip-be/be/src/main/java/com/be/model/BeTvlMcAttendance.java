/**
 *
 */
package com.be.model;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.be.core.AbstractEntity;
import com.be.sdk.model.IQfCriteria;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author Atiqah Khairuddin
 *
 */

@Entity
@Table(name = "BE_TVL_MC_ATTENDANCE")
public class BeTvlMcAttendance extends AbstractEntity implements Serializable, IQfCriteria<BeTvlMcAttendance> {

	private static final long serialVersionUID = -6606855235977856401L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TVL_MC_ATTD_ID")
	private Integer tvlMcAttdId;

	@Column(name = "MC_PROF_ID")
	private Integer mcProfId;

	@JsonIgnoreProperties("tvlMcAttendances")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TVL_PROF_ID")
	private BeTvlProfile tvlProfile;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATUS_ID")
	private RefStatus status;

	@Column(name = "CREATE_ID")
	private String createId;

	@Column(name = "CREATE_DT")
	private Timestamp createDt;

	@Column(name = "UPDATE_ID")
	private String updateId;

	@Column(name = "UPDATE_DT")
	private Timestamp updateDt;


	public Integer getTvlMcAttdId() {
		return tvlMcAttdId;
	}


	public void setTvlMcAttdId(Integer tvlMcAttdId) {
		this.tvlMcAttdId = tvlMcAttdId;
	}


	public Integer getMcProfId() {
		return mcProfId;
	}


	public void setMcProfId(Integer mcProfId) {
		this.mcProfId = mcProfId;
	}


	public BeTvlProfile getTvlProfile() {
		return tvlProfile;
	}


	public void setTvlProfile(BeTvlProfile tvlProfile) {
		this.tvlProfile = tvlProfile;
	}


	public RefStatus getStatus() {
		return status;
	}


	public void setStatus(RefStatus status) {
		this.status = status;
	}


	@Override
	public String getCreateId() {
		return createId;
	}


	@Override
	public void setCreateId(String createId) {
		this.createId = createId;
	}


	@Override
	public Timestamp getCreateDt() {
		return createDt;
	}


	@Override
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	@Override
	public String getUpdateId() {
		return updateId;
	}


	@Override
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}


	@Override
	public Timestamp getUpdateDt() {
		return updateDt;
	}


	@Override
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}
}
