package com.bestid.be.service;

import java.util.List;

import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.constants.QualifierConstants;
import com.bestid.be.model.RefDocument;
import com.bestid.be.repo.GenericRepository;
import com.bestid.be.repo.RefDocumentRepository;

@Transactional
@Service(QualifierConstants.REF_DOCUMENT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_DOCUMENT_SVC)
public class RefDocumentService extends AbstractService<RefDocument> {

	@Autowired
	private RefDocumentRepository refDocumentDao;


	@Override
	public GenericRepository<RefDocument> primaryDao() {
		return refDocumentDao;
	}

	@javax.transaction.Transactional(value = TxType.SUPPORTS, rollbackOn = Exception.class)
	public List<RefDocument> findAllByTrxnNo(@Param("trxnNo") String trxnNo) {
		return refDocumentDao.findAllByTrxnNo(trxnNo);
	}

	@Transactional(readOnly=true,rollbackFor=Exception.class)
	public RefDocument findTrxnDocumentsByDocId(Integer docId){
		return refDocumentDao.findTrxnDocumentsByDocId(docId);
	}
	
	@Transactional(readOnly=true,rollbackFor=Exception.class)
	public RefDocument findTrxnDocumentsByTrxnNo(@Param("trxnNo") String trxnNo){
		return refDocumentDao.findTrxnDocumentsByTrxnNo(trxnNo);
	}
	
	@Transactional(readOnly=true,rollbackFor=Exception.class)
	public RefDocument findTrxnDocumentsByTrxnNoTitleDocDesc(@Param("trxnNo") String trxnNo,@Param("title") String title,@Param("docDescEn") String docDescEn){
		return refDocumentDao.findTrxnDocumentsByTrxnNoTitleDocDesc(trxnNo,title,docDescEn);
	}
	

}