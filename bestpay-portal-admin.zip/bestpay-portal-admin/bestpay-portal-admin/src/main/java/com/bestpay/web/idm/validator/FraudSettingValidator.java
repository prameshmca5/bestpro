/**
 * Copyright 2018 Bestinet Sdn Bhd
 */
package com.bestpay.web.idm.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bestpay.be.sdk.model.MerFraudSet;
import com.bestpay.web.constants.MessageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.ValidationUtil;

/**
 * @author Afif Saman
 * @since July 17, 2018
 */
@Component("fraudSettingValidator")
public class FraudSettingValidator extends AbstractController implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return MerFraudSet.class.equals(clazz);
	}

	@Override
	public void validate(Object object, Errors errors) {
		// Validate if fields are empty or a whitespace
		ValidationUtil.rejectIfEmptyOrWhitespace(errors, "maxallowFraudscore",
				MessageConstants.ERROR_FIELDS_MAX_FRAUD_SCORE);

	}
}
