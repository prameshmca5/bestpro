/**
 * Copyright 2019
 */
package com.be.sdk.model;


import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */
public class Position implements Serializable, IQfCriteria<Position> {

	private static final long serialVersionUID = 607657392585361232L;

	private Integer positionId;

	private Timestamp createDt;

	private String createId;

	private Boolean status;

	private String positionCd;

	private String positionDesc;

	private Timestamp updateDt;

	private String updateId;


	public Integer getPositionId() {
		return positionId;
	}


	public void setPositiobId(Integer positionId) {
		this.positionId = positionId;
	}


	public Timestamp getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}


	public String getCreateId() {
		return createId;
	}


	public void setCreateId(String createId) {
		this.createId = createId;
	}


	public Boolean isActive() {
		return status;
	}


	public void setActive(Boolean status) {
		this.status = status;
	}


	public String getPositionCd() {
		return positionCd;
	}


	public void setPositionCd(String positionCd) {
		this.positionCd = positionCd;
	}


	public String getPositionDesc() {
		return positionDesc;
	}


	public void setStatusDesc(String positionDesc) {
		this.positionDesc = positionDesc;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}


	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public String getUpdateId() {
		return updateId;
	}


	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	
}