/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.portal.web.controller;


import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.portal.constants.PageConstants;
import com.icao.sdk.client.IcaoServiceClient;
import com.icao.sdk.model.IcaoInfo;
import com.icao.sdk.model.IcaoResponse;
import com.idm.sdk.model.UserProfile;
import com.portal.constants.PageTemplate;
import com.portal.constants.ProjectEnum;
import com.portal.core.AbstractController;
import com.portal.web.idm.form.FaceEnrollForm;
import com.util.BaseUtil;
import com.util.MediaType;
import com.camvi.sdk.client.CamviServiceClient;
import com.camvi.sdk.model.CamviResponse;
import com.camvi.sdk.model.PersonDto;
import com.dm.sdk.model.Documents;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * This class is for Face Registration and Authorized only for TMS_ADMIN users
 *
 * 1) Check Photo Quality 2) ICAO Checking 3) CAMVI Registration
 *
 * @author mary.jane
 * @since Nov 26, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_TVL_FACE_PAGE)
public class FaceEnrollmentController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(FaceEnrollmentController.class);

	private static final String JS_FILENAME = "camera";

	private static final String MODULE = "user_mgmt";

	@Autowired
	private CamviServiceClient camviService;

	@Autowired
	private IcaoServiceClient icaoService;


	@Override
	protected void bindingPreparation(WebDataBinder binder) {
		binder.setBindEmptyMultipartFiles(false);
		super.bindingPreparation(binder);
	}


	@GetMapping(params = "acctTvlrId")
	public ModelAndView view(@RequestParam String acctTvlrId, UserProfile userProfile, BindingResult result) {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_IDM_FACE, MODULE, null, null, JS_FILENAME);
		//mav.addObject("staffId", staffId);
		mav.addObject("acctTvlrId", "EMP000341");
		return mav;
	}


	/**
	 * Check Image Quality
	 *
	 * @param quality
	 * @param faceEnroll
	 * @param result
	 * @return
	 */
	@PostMapping(params = "quality")
	public @ResponseBody CamviResponse checkQuality(@RequestParam String quality, FaceEnrollForm faceEnroll,
			BindingResult result) {
		// Check Image Quality
		CamviResponse response = camviService.checkQuality(faceEnroll.getImage());
		LOGGER.info("Check Photo Quality Response: {}", new ObjectMapper().valueToTree(response));
		return response;
	}


	/**
	 * Face Detection
	 *
	 * @param detect
	 * @param faceEnroll
	 * @param result
	 * @return
	 */
	@PostMapping(params = "detect")
	public @ResponseBody PersonDto detect(@RequestParam String detect, FaceEnrollForm faceEnroll,
			BindingResult result) {
		return camviService.detectFaceImage(faceEnroll.getEmail(), faceEnroll.getImage());
	}


	/**
	 * Register Face ID
	 *
	 * @param enroll
	 * @param faceEnroll
	 * @param result
	 * @return
	 */
	@PostMapping(params = "enroll")
	public @ResponseBody PersonDto enroll(@RequestParam String enroll, FaceEnrollForm faceEnroll,
			BindingResult result) {
		PersonDto person = null;
		if (!BaseUtil.isObjNull(faceEnroll.getFaceId())) {
			person = camviService.appendFaceByPersonId(faceEnroll.getFaceId(), faceEnroll.getImage());
		} else {
			person = camviService.createPerson(faceEnroll.getEmail(), faceEnroll.getImage());
			
		}
		byte[] raw;
		raw = Base64.decodeBase64(faceEnroll.getImage());
		
		Documents photo = new Documents();
		photo.setContent(raw);
		/*if (!BaseUtil.isObjNull(faceEnroll.getPhotoId())
				&& !BaseUtil.isEqualsCaseIgnore(faceEnroll.getPhotoId(), "null")) {
			photo.setId(faceEnroll.getPhotoId());
		}*/
		photo.setDocid(1);
		photo.setContentType(MediaType.IMAGE_PNG);
		photo.setRefno(faceEnroll.getStaffId());
		photo = getDmService(ProjectEnum.MYIP).upload(photo);
		LOGGER.info("PersonDto: {}", new ObjectMapper().valueToTree(photo));

		//waiting for model from be -  06/07/2020
		/*try {
			EmployeeProfile empProf = getBeService().getTmsProfile(faceEnroll.getStaffId());
			if (!BaseUtil.isObjNull(empProf)) {
				empProf.setFaceId(person.getPersonId());
				empProf.setPhotoId(photo.getId());
				getBeService().updateTmsProfile(empProf);
			}
		} catch (Exception e) {
			LOGGER.error("Exception: {}", e);
		}*/

		LOGGER.info("PersonDto: {}", new ObjectMapper().valueToTree(person));
		return person;
	}


	/**
	 * ICAO Checking
	 *
	 * @param icao
	 * @param faceEnroll
	 * @param result
	 * @return
	 */
	@PostMapping(params = "icao")
	public @ResponseBody IcaoResponse icaoCheck(@RequestParam String icao, FaceEnrollForm faceEnroll,
			BindingResult result) {

		LOGGER.info("ICAO Criteria: {}", new ObjectMapper().valueToTree(faceEnroll.getIcaoCriteria()));
		List<IcaoInfo> icaoInfo = IcaoInfo.findListByCriteria(faceEnroll.getIcaoCriteria());
		LOGGER.info("ICAO Criteria: {}", icaoInfo);
		IcaoResponse response = icaoService.verifyPhoto(faceEnroll.getImage(), icaoInfo);
		LOGGER.info("ICAO Checking Response: {}", new ObjectMapper().valueToTree(response));
		return response;
	}

}
