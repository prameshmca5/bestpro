/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.be.sdk.model.Channel;
import com.bestpay.be.sdk.model.MerAccInfo;
import com.bestpay.be.sdk.model.Status;
import com.bestpay.be.sdk.model.Transaction;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.constants.PageTemplate;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.WebUtil;
import com.google.gson.Gson;

/**
 * @author N.N.Shuhada
 * @since June 01, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_TRANSACTION)
public class TransactionController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionController.class);

	private static final String TRANSTAT = "TRANSTAT";

	private static final String CHANNEL_LIST = "channelList";

	private static final String STATUS_LIST = "statusList";

	private static final String TRANSACTION_LIST_SCRIPT = "transaction-list-script";

	private static final String TRANS_LIST = "translist";

	// for view transaction list
	@GetMapping
	public ModelAndView view(@ModelAttribute("transactionList") Transaction transactionList, BindingResult result)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TRANSACTION, TRANS_LIST, null, TRANSACTION_LIST_SCRIPT);
		List<Status> status = staticData.status(TRANSTAT);
		List<Channel> channel = staticData.channelList();
		MerAccInfo merAccInfo = new MerAccInfo();

		List<MerAccInfo> merchatdet = getBeService().getAllMerChantList(merAccInfo);
		mav.addObject(STATUS_LIST, status);
		mav.addObject(CHANNEL_LIST, channel);
		mav.addObject("merchantlst", merchatdet);
		return mav;

	}

	@PostMapping(params = "search")
	public ModelAndView search(@ModelAttribute("transactionList") Transaction transactionList, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TRANSACTION, TRANS_LIST, null, TRANSACTION_LIST_SCRIPT);
		mav.addObject("transactionList", transactionList);
		List<Status> status = staticData.status(TRANSTAT);
		List<Channel> channel = staticData.channelList();
		MerAccInfo merAccInfo = new MerAccInfo();
		List<MerAccInfo> merchatdet = getBeService().getAllMerChantList(merAccInfo);
		mav.addObject("merchantlst", merchatdet);
		mav.addObject(STATUS_LIST, status);
		mav.addObject(CHANNEL_LIST, channel);
		return mav;
	}

	@GetMapping(value = "/paginated")
	public @ResponseBody String getApplicationInfoPaginated(
			@ModelAttribute("transactionList") Transaction transactionList, HttpServletRequest request) {
		LOGGER.info("GET PAGINATED BILLING LIST....");
		DataTableResults<Transaction> tasks = new DataTableResults<>();
		try {
			Transaction transaction = dozerMapper.map(transactionList, Transaction.class);
			tasks = getBeService().searchTransList(transaction, getPaginationRequest(request, true));
		} catch (IdmException e) {
			if (WebUtil.checkSystemDown(e)) {
				throw e;
			}
			LOGGER.error(e.getMessage());
			tasks.setError(e.getMessage());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			tasks.setError(e.getMessage());
		}

		return new Gson().toJson(tasks);
	}

	@PostMapping(params = "reset")
	public ModelAndView reset(@ModelAttribute("transactionList") @Validated Transaction transactionList,
			BindingResult result, HttpServletRequest request, HttpSession session) throws BeException {
		Transaction transListInfo = new Transaction();
		return view(transListInfo, result);
	}

	@GetMapping(value = "/tag")
	public ModelAndView getBlacklistTransactionList(@ModelAttribute("transactionList") Transaction transactionList,
			@RequestParam(value = "tag", required = true) String tag,
			@RequestParam(value = "value", required = true) String value, HttpServletRequest request)
			throws BeException {
		ModelAndView mav = getDefaultMav(PageTemplate.TEMP_TRANSACTION, TRANS_LIST, null, TRANSACTION_LIST_SCRIPT);
		mav.addObject("transactionList", transactionList);
		List<Status> status = staticData.status(TRANSTAT);
		List<Channel> channel = staticData.channelList();
		mav.addObject(STATUS_LIST, status);
		mav.addObject(CHANNEL_LIST, channel);
		mav.addObject("tag", tag);
		mav.addObject("tagVal", value);
		return mav;
	}

}