/**
 * Copyright 2018. Bestinet Sdn. Bhd.
 */
package com.bestid.be.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
public class QualifierConstants {

	private QualifierConstants() {
		throw new IllegalStateException("QualifierConstants Utility class");
	}


	public static final String SCOPE_PROTOTYPE = "prototype";

	public static final String AUTHORIZATION_DAO = "authDao";

	public static final String AUTHORIZATION_SVC = "authSvc";

	public static final String AUDIT_TRAIL_DAO = "auditTrailDao";

	public static final String AUDIT_TRAIL_SVC = "auditTrailSbv";

	public static final String NOT_CONFIG_DAO = "notConfigDao";

	public static final String NOT_CONFIG_SVC = "notConfigSvc";

	public static final String NOTIFICATION_DAO = "notificationDao";

	public static final String NOTIFICATION_SVC = "notificationSvc";

	public static final String NOT_EMAIL_TEMPLATE_DAO = "notEmailTemplateDao";

	public static final String NOT_EMAIL_TEMPLATE_SVC = "notEmailTemplateSvc";

	public static final String IDM_AUDIT_ACTION_DAO = "idmAuditActionDao";

	public static final String IDM_AUDIT_ACTION_SVC = "idmAuditActionSvc";

	public static final String IDM_AUDIT_TRAIL_DAO = "idmAuditTrailDao";

	public static final String IDM_AUDIT_TRAIL_SVC = "idmAuditTrailSvc";

	public static final String IDM_CONFIG_DAO = "idmConfigDao";

	public static final String IDM_CONFIG_SVC = "idmConfigSvc";

	public static final String IDMPROFILE_REPOSITORY = "idmProfileDao";

	public static final String IDMPROFILE_SERVICE = "idmProfileSvc";

	public static final String IDMPROFILE_CUSTOM_REPOSITORY = "userProfileCustomDao";

	public static final String IDMROLE_SERVICE = "idmRoleSvc";

	public static final String IDMROLE_REPOSITORY = "idmRoleDao";

	public static final String IDMROLEMENU_SERVICE = "idmRoleMenuSvc";

	public static final String IDMROLEMENU_REPOSITORY = "idmRoleMenuDao";

	public static final String IDMMENU_SERVICE = "idmMenuSvc";

	public static final String IDMMENU_REPOSITORY = "idmMenuDao";

	public static final String IDM_USER_GROUP_SVC = "idmUserGroupSvc";

	public static final String IDM_USER_GROUP_DAO = "idmUserGroupDao";

	public static final String IDM_USER_GROUP_ROLES_SERVICE = "idmUserGroupRoleSvc";

	public static final String IDM_USER_GROUP_ROLES_REPOSITORY = "idmUserGroupRoleDao";

	public static final String IDM_USER_GROUP_ROLE_GROUP_SVC = "idmUserGroupRoleGroupSvc";

	public static final String IDM_USER_GROUP_ROLE_GROUP_DAO = "idmUserGroupRoleGroupDao";

	public static final String IDM_USER_TYPE_SERVICE = "idmUserTypeSvc";

	public static final String IDM_USER_TYPE_REPOSITORY = "idmUserTypeDao";

	public static final String IDMDELEGATE_REPOSITORY = "idmDelegateDao";

	public static final String IDMDELEGATE_SERVICE = "idmDelegateSvc";

	public static final String TRXN_DOCUMENTS_DAO = "idmTrxnDocumentsDao";

	public static final String TRXN_DOCUMENTS_SVC = "idmTrxnDocumentsSvc";

	public static final String MESSAGE_SVC = "messageService";

	public static final String SEC_USER_REPOSITORY = "secUserDao";

	public static final String SEC_USER_SVC = "secUserSvc";

	public static final String SEC_USER_DEVICE_REPOSITORY = "secUserDeviceDao";

	public static final String SEC_USER_DEVICE_SVC = "secUserDeviceSvc";

	public static final String CAMVI_SERVICE = "camviSvc";

	public static final String BID_USER_PROFILE_REPOSITORY = "bidUserProfileDao";

	public static final String BID_USER_PROFILE_SVC = "bidUserProfileSvc";

	public static final String BID_ENROLL_APPL_REPOSITORY = "bidEnrollApplDao";

	public static final String BID_ENROLL_APPL_SVC = "bidEnrollApplSvc";

	public static final String BID_CERT_INFO_REPOSITORY = "bidCertInfoDao";

	public static final String BID_CERT_INFO_SVC = "bidCertInfoSvc";

	public static final String BID_CONFIG_REPOSITORY = "bidConfigDao";

	public static final String BID_CONFIG_SVC = "bidConfigSvc";

	public static final String BID_CONFIG_QF = "bidConfigQf";

	public static final String BID_ICAO_CONFIG_REPOSITORY = "bidIcaoConfigDao";

	public static final String BID_ICAO_CONFIG_SVC = "bidIcaoConfigSvc";

	public static final String BID_SUBSCRIBER_USER_REPOSITORY = "bidSubscriberUserDao";

	public static final String BID_SUBSCRIBER_USER_SVC = "bidSubscriberUserSvc";

	public static final String BID_CMPNY_SVC = "bidCmpnySvc";

	public static final String BID_CMPNY_REPOSITORY = "bidCmpnyDao";

	public static final String BID_SUBSCRIBER_SVC = "bidSubscriberSvc";

	public static final String BID_SUBSCRIBER_REPOSITORY = "bidSubscriberDao";

	public static final String SUBSCRIBER_DAO = "subscriberDao";

	public static final String SEC_USER_DEVICE_QF = "secUserDeviceQf";

	public static final String BID_SUBSCRIBER_USER_QF = "bidSubscriberUserQf";

	public static final String BID_SUBSCRIBER_QF = "bidSubscriberQf";

	public static final String BID_ENROLL_APPL_QF = "bidEnrollApplQf";
	
	public static final String REF_DOCUMENT_DAO = "refDocumentDao";
	
	public static final String REF_DOCUMENT_SVC = "refDocumentSvc";
}