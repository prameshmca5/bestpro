/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.portal.config;


import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.be.sdk.client.BeServiceClient;
import com.camvi.sdk.client.CamviServiceClient;
import com.dm.sdk.client.DmServiceClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.icao.sdk.client.IcaoServiceClient;
import com.idm.sdk.client.IdmServiceClient;
import com.notify.sdk.client.NotServiceClient;
import com.portal.constants.ConfigConstants;
import com.portal.web.util.StaticData;
import com.report.sdk.client.ReportServiceClient;
import com.util.constants.BaseConfigConstants;
import com.util.constants.BaseConstants;


/**
 * @author Mary Jane Buenaventura
 * @since May 17, 2018
 */
@Configuration
public class ServiceConfig implements InitializingBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceConfig.class);

	@Value("${" + BaseConfigConstants.SVC_IDM_URL + "}")
	private String idmUrl;

	@Value("${" + BaseConfigConstants.SVC_IDM_TIMEOUT + "}")
	private int idmTimeout;

	@Value("${" + BaseConfigConstants.SVC_NOT_URL + "}")
	private String notUrl;

	@Value("${" + BaseConfigConstants.SVC_NOT_TIMEOUT + "}")
	private int notTimeout;

	@Value("${" + ConfigConstants.SVC_BE_URL + "}")
	private String beUrl;

	@Value("${" + ConfigConstants.SVC_BE_TIMEOUT + "}")
	private int beTimeout;

	@Value("${" + BaseConfigConstants.SVC_DM_URL + "}")
	private String dmUrl;

	@Value("${" + BaseConfigConstants.SVC_DM_TIMEOUT + "}")
	private int dmTimeout;

	@Value("${" + BaseConfigConstants.SVC_WFW_TIMEOUT + "}")
	private int wfwTimeout;
	
	@Value("${" + BaseConfigConstants.SVC_RPT_TIMEOUT + "}")
	private int rptTimeout;
	
	@Value("${" + BaseConfigConstants.SVC_RPT_URL + "}")
	private String rptUrl;

	@Value("${" + BaseConfigConstants.SVC_ICAO_URL + "}")
	private String icaoUrl;
	
	@Value("${" + BaseConfigConstants.SVC_ICAO_KEY + "}")
	private String icaoKey;

	@Value("${" + BaseConfigConstants.SVC_ICAO_TIMEOUT + "}")
	private int icaoTimeout;
	
	@Value("${" + ConfigConstants.SVC_CAMVI_URL + "}")
	private String camviUrl;

	@Value("${" + ConfigConstants.SVC_CAMVI_UNAME + "}")
	private String camviUname;

	@Value("${" + ConfigConstants.SVC_CAMVI_PWORD + "}")
	private String camviPword;

	@Value("${" + ConfigConstants.SVC_CAMVI_FACE_MIN_VAL + "}")
	private double camviFaceMinVal;
	
	@Value("${" + BaseConfigConstants.SYSTEM_TYPE + "}")
	private String systemType;
	@Autowired
	MessageSource messageSource;

	@Bean
	public Mapper dozerMapper() {
		return new DozerBeanMapper();
	}


	@Bean
	public ObjectMapper objectMapper() {
		return new ObjectMapper();
	}


	@Bean
	public com.portal.web.util.StaticData staticData() {
		return new StaticData();
	}


	@Bean
	public IdmServiceClient idmService() {
		IdmServiceClient idmServiceClient = new IdmServiceClient(idmUrl, idmTimeout);
		idmServiceClient.setSystemType(systemType);
		return idmServiceClient;
	}


	@Bean
	public NotServiceClient notifyService() {
		return new NotServiceClient(notUrl, notTimeout);
	}


	@Bean
	public BeServiceClient apjatiService() {
		BeServiceClient beServiceClient = new BeServiceClient(beUrl, beTimeout);
		beServiceClient.setSystemType(systemType);
		return beServiceClient;
	}


	@Bean
	public DmServiceClient dmService() {
		return new DmServiceClient(dmUrl, dmTimeout);
	}
	
	@Bean
	public IcaoServiceClient icaoService() {
		return new IcaoServiceClient(icaoUrl, icaoKey, icaoTimeout);
	}
	
	@Bean
	public CamviServiceClient camviService() {
		return new CamviServiceClient(camviUrl, camviUname, camviPword, camviFaceMinVal);
	}

	@Bean public ReportServiceClient reportService() { return new ReportServiceClient(rptUrl); }
	
	@Override
	public void afterPropertiesSet() throws Exception {
		final String TIMEOUT = "\t- Timeout (seconds): ";
		StringBuilder sb = new StringBuilder();
		sb.append(BaseConstants.NEW_LINE + BaseConstants.NEW_LINE);
		sb.append(BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("Integration Service");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("IDM Service URL: " + idmUrl + TIMEOUT + idmTimeout + BaseConstants.NEW_LINE);
		sb.append("DM Service URL:  " + dmUrl + TIMEOUT + dmTimeout + BaseConstants.NEW_LINE);
		sb.append("NOT Service URL: " + notUrl + TIMEOUT + notTimeout + BaseConstants.NEW_LINE);
		sb.append("BE Service URL:  " + beUrl + TIMEOUT + beTimeout + BaseConstants.NEW_LINE);
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("ICAO Credentials");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("URL:  " + icaoUrl + BaseConstants.NEW_LINE);
		sb.append("Key:  " + icaoKey + BaseConstants.NEW_LINE);
		sb.append("Timeout: " + icaoTimeout);
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("CAMVI Credentials");
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		sb.append("URL : " + camviUrl + BaseConstants.NEW_LINE);
		sb.append("Username : " + camviUname + BaseConstants.NEW_LINE);
		sb.append("Password : " + camviPword);
		sb.append(BaseConstants.NEW_LINE + BaseConstants.LOG_SEPARATOR + BaseConstants.NEW_LINE);
		LOGGER.info("{}", sb);
	}

}