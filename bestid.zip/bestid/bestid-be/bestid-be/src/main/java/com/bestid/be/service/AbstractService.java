/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestid.be.service;


import java.util.List;

import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AdviceMode;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.bestid.be.repo.GenericRepository;
import com.bestid.be.sdk.exception.BeException;


/**
 * @author Mary Jane Buenaventura
 * @since Jun 12, 2018
 */
@EnableTransactionManagement(mode = AdviceMode.PROXY, proxyTargetClass = true)
@Transactional
public abstract class AbstractService<S> implements SimpleDataAccess<S> {

	protected Logger LOGGER = LoggerFactory.getLogger(AbstractService.class);

	@Autowired
	protected Mapper dozerMapper;

	@Autowired
	protected PlatformTransactionManager transactionManager;


	public abstract GenericRepository<S> primaryDao();


	@Override
	@Transactional(readOnly = false, rollbackFor = BeException.class)
	public <T> S create(S s) {
		try {
			this.primaryDao().save(s);
			return s;
		} catch (Throwable e) {
			LOGGER.error("create Exception", e);
			return null;
		}
	}


	@Override
	@Modifying(clearAutomatically = true)
	@Transactional(readOnly = false, rollbackFor = BeException.class)
	public <T> S update(S s) {
		try {
			this.primaryDao().saveAndFlush(s);
			return s;
		} catch (Throwable e) {
			LOGGER.error("update Exception", e);
			return null;
		}
	}


	@Override
	@Transactional(readOnly = true, rollbackFor = BeException.class)
	public <T> S find(java.lang.Integer id) {
		try {
			return this.primaryDao().findOne(id);
		} catch (Throwable e) {
			LOGGER.error("find Exception", e);
			return null;
		}
	}


	@Override
	@Transactional(readOnly = true, rollbackFor = BeException.class)
	public <T> List<S> findAll() {
		try {
			return this.primaryDao().findAll();
		} catch (Throwable e) {
			LOGGER.error("findAll Exception", e);
			return null;
		}
	}


	@Override
	@Modifying(clearAutomatically = true)
	@Transactional(readOnly = false, rollbackFor = BeException.class)
	public boolean delete(java.lang.Integer id) {
		try {
			this.primaryDao().delete(id);
			return true;
		} catch (Throwable e) {
			LOGGER.error("delete Exception", e);
			return false;
		}
	}

}