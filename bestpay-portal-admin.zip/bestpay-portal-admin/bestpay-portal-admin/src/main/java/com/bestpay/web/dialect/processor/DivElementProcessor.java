/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dialect.processor;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.thymeleaf.Arguments;
import org.thymeleaf.dom.Element;
import org.thymeleaf.processor.ProcessorResult;
import org.thymeleaf.spring4.context.SpringWebContext;

import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.dialect.AbstractBstElement;
import com.bestpay.web.dialect.constants.AttributeConstants;
import com.bestpay.web.dialect.constants.ElementConstants;
import com.bestpay.web.dialect.constants.ElementEnum;
import com.bestpay.web.dialect.constants.ElementHelper;
import com.bestpay.web.util.MessageService;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class DivElementProcessor extends AbstractBstElement {

	private static final Logger LOGGER = LoggerFactory.getLogger(DivElementProcessor.class);


	public DivElementProcessor(String elementName) {
		super(elementName);
	}


	@Override
	protected ProcessorResult processElement(Arguments arguments, Element element) {
		String elementNm = getElementName(element);
		
		final ApplicationContext appCtx = ((SpringWebContext) arguments.getContext()).getApplicationContext();
		MessageService messageService = appCtx.getBean(MessageService.class);
		
		Element newElement = element.cloneElementNodeWithNewName(element.getParent(), ElementConstants.HTML_DIV,
				false);
		newElement.setRecomputeProcessorsImmediately(true);

		String attrClass = ElementEnum.findStyleByName(elementNm);
		
		if(!BaseUtil.isObjNull(element.getAttributeValue(AttributeConstants.ATTR_CLASS))) {
			attrClass = element.getAttributeValue(AttributeConstants.ATTR_CLASS) + " " + attrClass;
		} else if(!BaseUtil.isObjNull(element.getAttributeValue(AttributeConstants.ATTR_TH_CLASSAPPEND))) {
			attrClass = attrClass + " " + element.getAttributeValue(AttributeConstants.ATTR_TH_CLASSAPPEND);
		} else {
			attrClass = ElementEnum.findStyleByName(elementNm);
		}
		
		newElement.setAttribute(AttributeConstants.ATTR_CLASS, attrClass);

		if (elementNm.contains(ElementEnum.ALERT.getName())) {
			if (element.getAttributeValue(AttributeConstants.ATTR_TYPE) != null
					&& "dismissible".equalsIgnoreCase(element.getAttributeValue(AttributeConstants.ATTR_TYPE))) {
				final Element eClose = new Element(ElementConstants.HTML_ANCHOR);
				eClose.setRecomputeProcessorsImmediately(true);
				eClose.setAttribute(AttributeConstants.ATTR_CLASS, "close");
				eClose.setAttribute("data-dismiss", ElementEnum.ALERT.getName());
				eClose.setAttribute("href", "#");
				eClose.setAttribute("aria-hidden", "true");
				eClose.setAttribute("th:text", "#{×}");
				newElement.removeAttribute(AttributeConstants.ATTR_TYPE);
				newElement.insertChild(0, eClose);
				newElement.setRecomputeProcessorsImmediately(true);
			}
		} else if (elementNm.equalsIgnoreCase(ElementEnum.OTP.getName())) {
			newElement = ElementHelper.processOTP(newElement, messageService);
		} else if (elementNm.equalsIgnoreCase(ElementEnum.OTP_EMAIL.getName())) {
			newElement = ElementHelper.processOTPEmail(newElement, messageService);
		} else if (elementNm.equalsIgnoreCase(ElementEnum.FILE.getName())) {
			try {
				newElement = ElementHelper.processFile(newElement, messageService);
			} catch (Exception e) {
				LOGGER.error("Exception: {}", e.getMessage());
			}
		} else if(elementNm.equalsIgnoreCase(ElementEnum.FILE_THUMBNAIL.getName())) {
	        	try {
				newElement = ElementHelper.processFileThumbnail(newElement,messageService);
			} catch (Exception e) {
				LOGGER.error("Exception: {}", e.getMessage());
			}
	     } else if(elementNm.equalsIgnoreCase(ElementEnum.FILE_THUMB_VIEW.getName())) {
			newElement = ElementHelper.processFileThumbnailView(newElement);
		} else if (elementNm.equalsIgnoreCase(ElementEnum.FILE_VIEW.getName())) {
			newElement = ElementHelper.processFileView(newElement);
		} else if (elementNm.equalsIgnoreCase(ElementEnum.FILE_BUTTON.getName())) {
			newElement = ElementHelper.processFileButton(newElement, messageService);
		} else if (elementNm.contains(ElementEnum.PORTLET.getName())) {
			newElement = ElementHelper.processPortlet(newElement);
		}

		element.getParent().insertAfter(element, newElement);
		element.getParent().removeChild(element);

		return ProcessorResult.OK;
	}


	@Override
	public int getPrecedence() {
		return 100000;
	}

}