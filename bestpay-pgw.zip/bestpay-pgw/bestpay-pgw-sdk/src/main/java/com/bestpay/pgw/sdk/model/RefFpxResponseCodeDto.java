/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.sdk.model;

import java.io.Serializable;
import java.sql.Timestamp;
 


public class RefFpxResponseCodeDto implements Serializable {

	private static final long serialVersionUID = -3186445980890420147L;

 
	private int id;
	private String fpxCode;
	private String fpxDescription;
	private String bestpayCode;
	private String channel;
	
	private String createId;
	private Timestamp createDt;
	private Timestamp updateDt;
	private String updateId;
	private String respCode;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	
	/**
	 * @return the fpxCode
	 */
	public String getFpxCode() {
		return fpxCode;
	}

	/**
	 * @param fpxCode the fpxCode to set
	 */
	public void setFpxCode(String fpxCode) {
		this.fpxCode = fpxCode;
	}

	/**
	 * @return the fpxDescription
	 */
	public String getFpxDescription() {
		return fpxDescription;
	}

	/**
	 * @param fpxDescription the fpxDescription to set
	 */
	public void setFpxDescription(String fpxDescription) {
		this.fpxDescription = fpxDescription;
	}
	
	public String getBestpayCode() {
		return bestpayCode;
	}

	public void setBestpayCode(String bestpayCode) {
		this.bestpayCode = bestpayCode;
	}

	/**
	 * @return the createId
	 */
	public String getCreateId() {
		return createId;
	}

	/**
	 * @param createId the createId to set
	 */
	public void setCreateId(String createId) {
		this.createId = createId;
	}

	/**
	 * @return the createDt
	 */
	public Timestamp getCreateDt() {
		return createDt;
	}

	/**
	 * @param createDt the createDt to set
	 */
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	/**
	 * @return the updateDt
	 */
	public Timestamp getUpdateDt() {
		return updateDt;
	}

	/**
	 * @param updateDt the updateDt to set
	 */
	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	/**
	 * @return the updateId
	 */
	public String getUpdateId() {
		return updateId;
	}

	/**
	 * @param updateId the updateId to set
	 */
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

}
