/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.web.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import com.bestpay.report.sdk.constants.ReportConstants;

/**
 * @author Mary Jane Buenaventura
 * @since Nov 4, 2016
 */

public class ReportUtil {

	private ReportUtil() {
		throw new IllegalStateException("Utility class");
	}

	public static Map<String, Object> getDefaultSettings(String realPath) {
		Map<String, Object> jasperParams = new HashMap<>();
		jasperParams.put("IMAGE_DIR", realPath + ReportConstants.RPT_IMG_PATH);
		jasperParams.put("RPT_LOGO", ReportConstants.RPT_IMG_LOGO_BESTPAY);
		jasperParams.put("REPORT_DIR", realPath + ReportConstants.PATH_REPORT);
		return jasperParams;
	}

	public static HttpHeaders getHttpHeadersPDF(String fileName, int contentLength) {
		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.parseMediaType("application/pdf"));
		header.setContentDispositionFormData(fileName, fileName);
		header.setContentLength(contentLength);
		header.setCacheControl("must-revalidate, post-check=0, pre-check=0");
		header.setExpires(0);
		header.setPragma("");
		return header;
	}

	public static HttpHeaders getHttpHeadersExcel(String fileName, int contentLength) {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Disposition", "inline;filename=" + fileName + "." + "xls");
		header.setContentType(MediaType.parseMediaType("application/vnd.ms-excel"));
		header.setContentLength(contentLength);
		header.setCacheControl("no-cache");
		header.setExpires(0);
		header.setPragma("");
		return header;
	}

	public static HttpHeaders getHttpHeadersCSV(String fileName, int contentLength) {
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Disposition", "inline;filename=" + fileName + "." + "csv");
		header.setContentType(MediaType.parseMediaType("application/vnd.ms-excel"));
		header.setContentLength(contentLength);
		header.setCacheControl("no-cache");
		header.setExpires(0);
		header.setPragma("");
		return header;
	}

}