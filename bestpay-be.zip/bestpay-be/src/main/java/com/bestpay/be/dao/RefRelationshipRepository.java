package com.bestpay.be.dao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bestpay.be.core.GenericRepository;
import com.bestpay.be.model.RefRelationship;
import com.bestpay.be.util.QualifierConstants;

/**
 * @author Md Asif Aftab
 * @since 3rd April 2018
 */

@Repository
@RepositoryDefinition(domainClass = RefRelationship.class, idClass = String.class)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_RELATIONSHIP_DAO)
public interface RefRelationshipRepository extends
		GenericRepository<RefRelationship> {

	@Query("select u from RefRelationship u where u.relationCode = :relationCode ")
	public RefRelationship findByRelationCode(
			@Param("relationCode") String relationCode);

}