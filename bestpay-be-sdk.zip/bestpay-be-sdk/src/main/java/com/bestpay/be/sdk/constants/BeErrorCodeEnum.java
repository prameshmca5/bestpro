/**
 * Copyright 2016. Bestinet Sdn Bhd
 */
package com.bestpay.be.sdk.constants;


/**
 * @author Mary Jane Buenaventura
 * @since Nov 1, 2016
 */
public enum BeErrorCodeEnum {

	E503APJ000(503, "SST service at {0} unreachable"),
	E503APJ001(503, "IDM service at {0} unreachable"),
	E408APJ002(408, "Request timed out connecting to IDM after <response time>/<timeout duration>"),
	E500APJ003(500, "Exception thrown from IDM service. {0}"),
	E500APJ004(504, "Exception thrown from SST service. {0}"),
	E503APJ004(503, "Mongo service at {0} unreachable"),
	E408APJ005(408, "Request timed out connecting to Mongo after <response time>/<timeout duration>"),
	E500APJ006(500, "MongoException occured. {0}"),
	E404APJ007(404, "Cache service at {0} unreachable"),
	E408APJ008(408, "Request timed out connecting to Cache service after <response time>/<timeout duration>"),
	E500APJ009(500, "Exception thrown from Cache service. {0}"),
	E500APJ010(500, "Document Upload failed."),
	E500APJ011(500, "Bank Statement Upload failed."),
	E400IDM913(400, "Invalid Request Body"),
	E400APJ011(400, "X-Message-Id Header is missing"),
	E400APJ012(400, "Authorization Header is missing"),
	E400APJ013(400, "Invalid Request Body"),
	E400APJ014(400, "Bad Request"),
	E400APJ015(400, "{0} is required."),
	E400APJ016(400, "Invalid Date Format {0}."),
	I404APJ109(405, "The record doesn't exists"),
	I404APJ110(405, "The record already exists"),
	I404APJ111(405, "Payment Transaction already exists."),
	E404APJ008(404, "Creation failed."),
	E404APJ009(404, "Relation {0} not found"),
	E400APJ246(400, "Missing value for compulsary fields {0}"),
	E409CMN914(409, "Relation {0} already exist"),
	E409APJ917(410, "KTP / National ID Already Exists"),
	E404BLC001(404, "Blacklist {0} not found"),
	E404BLC002(404, "Blacklist Create failed"),
	E404BCC001(404, "Business Category Update/Create failed"),
	E404PPSC001(404, "Payment page Update failed"),
	E404RSC001(404, "Report Setting Update/Create failed"),
	E404SSC001(404, "Settlement Setting Update/Create failed"),
	E404PLC001(404, "Payment Link is create failed"),
	E400PGW012(400, "Mechant not found with Id {0}"),
	I400IDM137(400, "Missing value for compulsary fields {0} to create {1}");

	private final int code;

	private final String message;


	BeErrorCodeEnum(int code, String message) {
		this.code = code;
		this.message = message;
	}


	public static BeErrorCodeEnum findByName(String name) {
		for (BeErrorCodeEnum v : BeErrorCodeEnum.values()) {
			if (v.name().equals(name)) {
				return v;
			}
		}

		return null;
	}


	public static int findInternalCode(String name) {
		for (BeErrorCodeEnum v : BeErrorCodeEnum.values()) {
			if (v.name().equals(name)) {
				return v.getCode();
			}
		}

		return 0;
	}


	public String getMessage() {
		return message;
	}


	public int getCode() {
		return code;
	}
}
