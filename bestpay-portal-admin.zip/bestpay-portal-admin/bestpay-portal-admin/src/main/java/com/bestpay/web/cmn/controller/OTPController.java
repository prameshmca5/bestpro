/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.cmn.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bestpay.be.sdk.constants.BeConfigConstants;
import com.bestpay.be.sdk.exception.BeException;
import com.bestpay.idm.sdk.exception.IdmException;
import com.bestpay.idm.sdk.util.BaseUtil;
import com.bestpay.web.constants.PageConstants;
import com.bestpay.web.core.AbstractController;
import com.bestpay.web.util.WebUtil;
import com.bstsb.util.DateUtil;

/**
 * @author Mary Jane Buenaventura
 * @since May 17, 2018
 */
@Controller
@RequestMapping(value = PageConstants.PAGE_CMN_OTP)
public class OTPController extends AbstractController {

	private static final Logger LOGGER = LoggerFactory.getLogger(OTPController.class);

	private static final String EMAIL_OTP_NO = "EMAIL_OTP_NO";

	private static final String EMAIL_OTP_TIME = "EMAIL_OTP_TIME";

	@GetMapping(value = "/generate")
	public @ResponseBody String generateOtp(@RequestParam String emailAddress,
			@RequestParam(value = "mobile", required = false) String mobile, HttpSession session) throws BeException {
		LOGGER.debug("emailAddress : {}", emailAddress);
		session.removeAttribute(EMAIL_OTP_NO);
		String otp = null;

		boolean hasSmsNotif = Boolean.parseBoolean(staticData.sstConfig().get(BeConfigConstants.SMS_SWITCH));
		LOGGER.debug("SMS NOTIFICATION: {}", hasSmsNotif);
		if (mobile != null && hasSmsNotif) {
			String newmobile = mobile;

			try {
				String content = messageService.getMessage("lbl.otp.msg.mobile", new String[] { otp });
				getNotifyService().sendSms(newmobile, content);
				LOGGER.debug("SMS Sent: {} - {}", newmobile, content);
			} catch (IdmException e) {
				if (WebUtil.checkSystemDown(e)) {
					throw e;
				}
				LOGGER.error("IdmException: {}", e.getMessage());
			} catch (Exception e) {
				LOGGER.error("Exception: {}", e.getMessage());
			}
		}

		LOGGER.debug("Generated OTP: {}", otp);
		if (!BaseUtil.isObjNull(otp)) {
			session.setAttribute(EMAIL_OTP_NO, otp);
			session.setAttribute(EMAIL_OTP_TIME, String.valueOf(DateUtil.getSQLTimestamp().getTime()));
			return messageService.getMessage("lbl.otp.gen.succ", new String[] { emailAddress }) + "*^*1";
		} else {
			return messageService.getMessage("lbl.otp.gen.fail") + "*^*0";
		}

	}

	/**
	 * Validate OTP
	 *
	 * @param code
	 * @param session
	 * @return 2 = expired, 1 = valid, 0 = failed
	 */
	@PostMapping(value = "/validate/{code}")
	public @ResponseBody String validate(@PathVariable String code, HttpSession session) {
		String sessionOtp = (String) session.getAttribute(EMAIL_OTP_NO);

		LOGGER.debug("Validate OTP: {} - session: {}", code, sessionOtp);

		if (sessionOtp.equalsIgnoreCase(code)) {
			int timeDiff = timeDiffMins(session);
			LOGGER.debug("Time Diff: {}", timeDiff);

			// if more than 15 mins expired
			if (timeDiff > (15 * 60)) {
				session.removeAttribute(EMAIL_OTP_NO);
				return messageService.getMessage("lbl.otp.exprd.regen") + "*^*2";
			}

			session.removeAttribute(EMAIL_OTP_NO);
			session.removeAttribute(EMAIL_OTP_TIME);
			return messageService.getMessage("lbl.otp.vrfy.succ") + "*^*1";
		} else {
			return messageService.getMessage("lbl.otp.vrfy.fail") + "*^*0";
		}
	}

	private int timeDiffMins(HttpSession session) {
		String otpGenTime = (String) session.getAttribute(EMAIL_OTP_TIME);
		long genTime = 0;

		if (!BaseUtil.isObjNull(otpGenTime)) {
			genTime = Long.parseLong(otpGenTime);
		}

		long currTime = DateUtil.getSQLTimestamp().getTime();

		long timeDiff = currTime - genTime;

		LOGGER.debug("timeDiff: {}", timeDiff);

		timeDiff = timeDiff / 1000;

		return (int) timeDiff;
	}

}