/**
 * Copyright 2016. Bestinet Sdn. Bhd.
 */
package com.bestpay.be.sdk.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author Mary Jane Buenaventura
 * @since 20/07/2015
 */
@JsonIgnoreProperties(ignoreUnknown = false)
@JsonInclude(Include.NON_NULL)
public class DocumentsCdc implements Serializable {

	private static final long serialVersionUID = 106316930304813799L;

	private Long imageId;

	private byte[] imageContent;

	private String imageTypeCode;

	private Integer documentPageNum;

	private String contentType;

	private String docName;

	private Long length;


	public DocumentsCdc() {
		// documentsCdc dto model
	}


	public Long getImageId() {
		return imageId;
	}


	public void setImageId(Long imageId) {
		this.imageId = imageId;
	}


	public byte[] getImageContent() {
		return imageContent;
	}


	public void setImageContent(byte[] imageContent) {
		this.imageContent = imageContent;
	}


	public String getImageTypeCode() {
		return imageTypeCode;
	}


	public void setImageTypeCode(String imageTypeCode) {
		this.imageTypeCode = imageTypeCode;
	}


	public Integer getDocumentPageNum() {
		return documentPageNum;
	}


	public void setDocumentPageNum(Integer documentPageNum) {
		this.documentPageNum = documentPageNum;
	}


	public String getContentType() {
		return contentType;
	}


	public void setContentType(String contentType) {
		this.contentType = contentType;
	}


	public String getDocName() {
		return docName;
	}


	public void setDocName(String docName) {
		this.docName = docName;
	}


	public Long getLength() {
		return length;
	}


	public void setLength(Long length) {
		this.length = length;
	}

}