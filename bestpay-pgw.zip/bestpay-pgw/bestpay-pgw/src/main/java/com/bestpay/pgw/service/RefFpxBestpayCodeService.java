/**
 * Copyright 2015. Bestinet Sdn Bhd
 */
package com.bestpay.pgw.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.FpxBestpayCodeRepository;
import com.bestpay.pgw.model.RefFpxBestpayCode;
import com.bestpay.pgw.util.QualifierConstants;

/**
 * @author Atiqah Khairuddin
 * @since 22/02/2019
 */
@Service(QualifierConstants.FPX_BESTPAY_CODE_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.FPX_BESTPAY_CODE_SVC)
@Transactional
public class RefFpxBestpayCodeService extends AbstractService<RefFpxBestpayCode> {

	@Autowired
	private FpxBestpayCodeRepository fpxBestpayCodeDao;

	@Override
	public GenericRepository<RefFpxBestpayCode> primaryDao() {
		return fpxBestpayCodeDao;
	}
	public RefFpxBestpayCode findBestpayCodeDescr(String bestpayCode) {
		return fpxBestpayCodeDao.findBestpayCodeDescr(bestpayCode);
	}

}