package com.bestpay.pgw.sdk.incentiveremit.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "SearchCustomerResult")
@XmlAccessorType(XmlAccessType.FIELD)
public class SearchCustomerResult {

	@XmlElement(name = "CODE")
	private String code;

	@XmlElement(name = "MESSAGE")
	private String message;

	@XmlElement(name = "SenderCustomerID")
	private String senderCustomerId;

	@XmlElement(name = "SenderFirstName")
	private String senderFirstName;

	@XmlElement(name = "SenderMiddleName")
	private String senderMiddleName;

	@XmlElement(name = "SenderLastName")
	private String senderLastName;

	@XmlElement(name = "SenderAddress")
	private String senderAddress;

	@XmlElement(name = "SenderCity")
	private String senderCity;

	@XmlElement(name = "SenderState")
	private String senderState;

	@XmlElement(name = "SenderCountry")
	private String senderCountry;

	@XmlElement(name = "SenderZipCode")
	private String senderZipCode;

	@XmlElement(name = "SenderPhoneno")
	private String senderPhoneNo;

	@XmlElement(name = "SenderMobile")
	private String senderMobile;

	@XmlElement(name = "SenderIDType")
	private String senderIdType;

	@XmlElement(name = "SenderIDNumber")
	private String senderIdNumber;

	@XmlElement(name = "IDIssuePlace")
	private String idIssuePlace;

	@XmlElement(name = "IDIssueDate")
	private String idIssueDate;

	@XmlElement(name = "IDExpireDate")
	private String idExpireDate;

	@XmlElement(name = "SenderEmail")
	private String senderEmail;

	@XmlElement(name = "SenderNativeCountry")
	private String senderNativeCountry;

	@XmlElement(name = "SenderOccupation")
	private String senderOccupation;

	@XmlElement(name = "SenderDateOfBirth")
	private String senderDateOfBirth;

	@XmlElement(name = "SenderSourceOfIncome")
	private String senderSourceOfIncome;

	@XmlElement(name = "SenderNatureOfBusiness")
	private String senderNatureOfBusiness;

	@XmlElement(name = "CustomerRiskScore")
	private String customerRiskScore;

	@XmlElement(name = "CustomerRiskStatus")
	private String customerRiskStatus;

	@XmlElement(name = "TXN_24Hour")
	private String txn24Hour;

	@XmlElement(name = "TXN_30Days")
	private String txn30Days;

	@XmlElement(name = "NOS_TXN_30Days")
	private String nosTxn30Days;

	@XmlElement(name = "NOS_TXN_30Days")
	private String nosBranch30Days;

	@XmlElement(name = "CustomerDetailInformation")
	private String customerDetailInformation;

	@XmlElement(name = "isAllowSend")
	private String isAllowSend;


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public String getSenderCustomerId() {
		return senderCustomerId;
	}


	public void setSenderCustomerId(String senderCustomerId) {
		this.senderCustomerId = senderCustomerId;
	}


	public String getSenderFirstName() {
		return senderFirstName;
	}


	public void setSenderFirstName(String senderFirstName) {
		this.senderFirstName = senderFirstName;
	}


	public String getSenderMiddleName() {
		return senderMiddleName;
	}


	public void setSenderMiddleName(String senderMiddleName) {
		this.senderMiddleName = senderMiddleName;
	}


	public String getSenderLastName() {
		return senderLastName;
	}


	public void setSenderLastName(String senderLastName) {
		this.senderLastName = senderLastName;
	}


	public String getSenderAddress() {
		return senderAddress;
	}


	public void setSenderAddress(String senderAddress) {
		this.senderAddress = senderAddress;
	}


	public String getSenderCity() {
		return senderCity;
	}


	public void setSenderCity(String senderCity) {
		this.senderCity = senderCity;
	}


	public String getSenderState() {
		return senderState;
	}


	public void setSenderState(String senderState) {
		this.senderState = senderState;
	}


	public String getSenderCountry() {
		return senderCountry;
	}


	public void setSenderCountry(String senderCountry) {
		this.senderCountry = senderCountry;
	}


	public String getSenderZipCode() {
		return senderZipCode;
	}


	public void setSenderZipCode(String senderZipCode) {
		this.senderZipCode = senderZipCode;
	}


	public String getSenderPhoneNo() {
		return senderPhoneNo;
	}


	public void setSenderPhoneNo(String senderPhoneNo) {
		this.senderPhoneNo = senderPhoneNo;
	}


	public String getSenderMobile() {
		return senderMobile;
	}


	public void setSenderMobile(String senderMobile) {
		this.senderMobile = senderMobile;
	}


	public String getSenderIdType() {
		return senderIdType;
	}


	public void setSenderIdType(String senderIdType) {
		this.senderIdType = senderIdType;
	}


	public String getSenderIdNumber() {
		return senderIdNumber;
	}


	public void setSenderIdNumber(String senderIdNumber) {
		this.senderIdNumber = senderIdNumber;
	}


	public String getIdIssuePlace() {
		return idIssuePlace;
	}


	public void setIdIssuePlace(String idIssuePlace) {
		this.idIssuePlace = idIssuePlace;
	}


	public String getIdIssueDate() {
		return idIssueDate;
	}


	public void setIdIssueDate(String idIssueDate) {
		this.idIssueDate = idIssueDate;
	}


	public String getIdExpireDate() {
		return idExpireDate;
	}


	public void setIdExpireDate(String idExpireDate) {
		this.idExpireDate = idExpireDate;
	}


	public String getSenderEmail() {
		return senderEmail;
	}


	public void setSenderEmail(String senderEmail) {
		this.senderEmail = senderEmail;
	}


	public String getSenderNativeCountry() {
		return senderNativeCountry;
	}


	public void setSenderNativeCountry(String senderNativeCountry) {
		this.senderNativeCountry = senderNativeCountry;
	}


	public String getSenderOccupation() {
		return senderOccupation;
	}


	public void setSenderOccupation(String senderOccupation) {
		this.senderOccupation = senderOccupation;
	}


	public String getSenderDateOfBirth() {
		return senderDateOfBirth;
	}


	public void setSenderDateOfBirth(String senderDateOfBirth) {
		this.senderDateOfBirth = senderDateOfBirth;
	}


	public String getSenderSourceOfIncome() {
		return senderSourceOfIncome;
	}


	public void setSenderSourceOfIncome(String senderSourceOfIncome) {
		this.senderSourceOfIncome = senderSourceOfIncome;
	}


	public String getSenderNatureOfBusiness() {
		return senderNatureOfBusiness;
	}


	public void setSenderNatureOfBusiness(String senderNatureOfBusiness) {
		this.senderNatureOfBusiness = senderNatureOfBusiness;
	}


	public String getCustomerRiskScore() {
		return customerRiskScore;
	}


	public void setCustomerRiskScore(String customerRiskScore) {
		this.customerRiskScore = customerRiskScore;
	}


	public String getCustomerRiskStatus() {
		return customerRiskStatus;
	}


	public void setCustomerRiskStatus(String customerRiskStatus) {
		this.customerRiskStatus = customerRiskStatus;
	}


	public String getTxn24Hour() {
		return txn24Hour;
	}


	public void setTxn24Hour(String txn24Hour) {
		this.txn24Hour = txn24Hour;
	}


	public String getTxn30Days() {
		return txn30Days;
	}


	public void setTxn30Days(String txn30Days) {
		this.txn30Days = txn30Days;
	}


	public String getNosTxn30Days() {
		return nosTxn30Days;
	}


	public void setNosTxn30Days(String nosTxn30Days) {
		this.nosTxn30Days = nosTxn30Days;
	}


	public String getNosBranch30Days() {
		return nosBranch30Days;
	}


	public void setNosBranch30Days(String nosBranch30Days) {
		this.nosBranch30Days = nosBranch30Days;
	}


	public String getCustomerDetailInformation() {
		return customerDetailInformation;
	}


	public void setCustomerDetailInformation(String customerDetailInformation) {
		this.customerDetailInformation = customerDetailInformation;
	}


	public String getIsAllowSend() {
		return isAllowSend;
	}


	public void setIsAllowSend(String isAllowSend) {
		this.isAllowSend = isAllowSend;
	}

}
