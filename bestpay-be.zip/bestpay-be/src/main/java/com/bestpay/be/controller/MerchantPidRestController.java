package com.bestpay.be.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestpay.be.core.AbstractRestController;
import com.bestpay.be.model.PgwMerchantPid;
import com.bestpay.be.model.RefChannel;
import com.bestpay.be.sdk.constants.BeUrlConstants;
import com.bestpay.be.sdk.model.MerchantPid;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bstsb.util.MediaType;


@RestController
@RequestMapping(BeUrlConstants.MER_PID)
public class MerchantPidRestController extends AbstractRestController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BlacklistRestController.class);


	@PostMapping(value = BeUrlConstants.PAGINATED_BY_MERCHANT_ID + "/{merchantId}", consumes = {
			MediaType.APPLICATION_JSON }, produces = { MediaType.APPLICATION_JSON })
	public DataTableResults<PgwMerchantPid> providerListPaginatedByMerchant(@PathVariable String merchantId,
			HttpServletRequest request) {

		DataTableRequest dataTableInRQ = new DataTableRequest(request.getParameterMap());
		DataTableResults<PgwMerchantPid> result = pgwMerchantPidService.searchPaginationByMerchantId(merchantId,
				dataTableInRQ);

		DataTableResults<PgwMerchantPid> dataTableInResp = new DataTableResults<>();
		if (!BaseUtil.isObjNull(result)) {
			dataTableInResp.setRecordsFiltered(result.getRecordsFiltered());
			dataTableInResp.setRecordsTotal(result.getRecordsTotal());
			if (!BaseUtil.isListNullZero(result.getData())) {
				List<PgwMerchantPid> bpLst = new ArrayList<>();
				for (PgwMerchantPid bbp : result.getData()) {
					RefChannel channel = refChannelSvc.findRefChannelByPublicName(bbp.getMtoId());
					bbp.setMtoId(channel.getName());
					PgwMerchantPid trustee = dozerMapper.map(bbp, PgwMerchantPid.class);
					LOGGER.info("getUpdateDt - {}", bbp.getUpdateDt());
					bpLst.add(trustee);
				}
				dataTableInResp.setData(bpLst);
			}
		}
		return dataTableInResp;
	}


	@GetMapping(value = "/merchantpid/{merchantId}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerchantPid getMerchantPidByMerchantId(@PathVariable String merchantId) {
		MerchantPid merchantPid = new MerchantPid();
		PgwMerchantPid pgwMerchantPid = pgwMerchantPidService.findByMerchantId(merchantId);
		if (pgwMerchantPid != null) {
			merchantPid = dozerMapper.map(pgwMerchantPid, MerchantPid.class);
		}
		return merchantPid;
	}

	@GetMapping(value = "/merchantpid/{merchantId}/{mtotype}", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerchantPid getMerchantPidByMerchantIdMTOtype(@PathVariable String merchantId,@PathVariable String mtotype) {
		MerchantPid merchantPid = new MerchantPid();
		PgwMerchantPid pgwMerchantPid = pgwMerchantPidService.findByMerchantIdUsingMTO(merchantId, mtotype);
		if (pgwMerchantPid != null) {
			merchantPid = dozerMapper.map(pgwMerchantPid, MerchantPid.class);
		}
		return merchantPid;
	}

	@PostMapping(value = "/create", consumes = { MediaType.APPLICATION_JSON }, produces = {
			MediaType.APPLICATION_JSON })
	public MerchantPid create(@RequestBody MerchantPid merchantPid) {
		merchantPid.setMtoId("MAX_MONEY");
		PgwMerchantPid pgwMerchantPid = pgwMerchantPidService
				.create(dozerMapper.map(merchantPid, PgwMerchantPid.class));
		return dozerMapper.map(pgwMerchantPid, MerchantPid.class);
	}

}
