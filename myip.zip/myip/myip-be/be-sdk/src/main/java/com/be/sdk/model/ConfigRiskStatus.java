/**
 *
 */
package com.be.sdk.model;


import java.io.Serializable;


/**
 * @author rushidi.lateh
 *
 */
public class ConfigRiskStatus implements Serializable, IQfCriteria<ConfigRiskStatus> {

	private static final long serialVersionUID = 6780024058447378010L;

	private Integer id;

	private String condition;

	private Metadata riskStatusMtdt;


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getCondition() {
		return condition;
	}


	public void setCondition(String condition) {
		this.condition = condition;
	}


	public Metadata getRiskStatusMtdt() {
		return riskStatusMtdt;
	}


	public void setRiskStatusMtdt(Metadata riskStatusMtdt) {
		this.riskStatusMtdt = riskStatusMtdt;
	}

}
