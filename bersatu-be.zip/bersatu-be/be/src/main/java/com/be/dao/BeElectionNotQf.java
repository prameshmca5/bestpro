/**
 *
 */
package com.be.dao;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.QueryFactory;
import com.be.model.BeElectionNot;
import com.be.sdk.constants.BeErrorCodeEnum;
import com.be.sdk.exception.BeException;
import com.be.sdk.model.ElectionNot;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;
import com.util.pagination.PaginationCriteria;


/**
 * @author michelle.angela
 *
 */
@Repository
@Transactional
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_ELECTION_NOT_QF)
public class BeElectionNotQf extends QueryFactory<BeElectionNot> {

	@PersistenceContext
	private EntityManager em;

	private CriteriaBuilder cb;


	@PostConstruct
	private void init() {
		cb = em.getCriteriaBuilder();
	}


	@Override
	public Specification<BeElectionNot> searchByProperty(BeElectionNot t) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<BeElectionNot> searchAllByProperty(BeElectionNot t) {
		CriteriaQuery<BeElectionNot> cq = cb.createQuery(BeElectionNot.class);
		Root<BeElectionNot> root = cq.from(BeElectionNot.class);
		List<Predicate> predicates = generateCriteria(cb, root, t);
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getResultList();
	}


	public Long getCount(ElectionNot dto) {
		List<Predicate> predicates = new ArrayList<>();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BeElectionNot> root = cq.from(BeElectionNot.class);
		predicates.addAll(generateCriteria(cb, root, dto));

		cq.select(cb.count(root));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));
		return em.createQuery(cq).getSingleResult();
	}


	public List<BeElectionNot> searchAllByProperty(ElectionNot dto, DataTableRequest<?> dataTableInRQ) {

		List<BeElectionNot> result = new ArrayList<>();
		CriteriaQuery<BeElectionNot> cq = cb.createQuery(BeElectionNot.class);
		List<Predicate> predicates = new ArrayList<>();
		if (cq != null) {
			Root<BeElectionNot> root = cq.from(BeElectionNot.class);
			predicates.addAll(generateCriteria(cb, root, dto));

			cq.select(root);
			cq.where(predicates.toArray(new Predicate[predicates.size()]));

			// Generate order by clause
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					List<Order> orders = getOrderByClause(cb, root, pagination);
					cq.orderBy(orders);
				}
			}

			TypedQuery<BeElectionNot> tQuery = em.createQuery(cq);

			// first result & max Results
			if (!BaseUtil.isObjNull(dataTableInRQ)) {
				PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
				if (!BaseUtil.isObjNull(pagination)) {
					tQuery.setFirstResult(pagination.getPageNumber());
					tQuery.setMaxResults(pagination.getPageSize());
				}
			}

			result = tQuery.getResultList();
		}
		return result;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			ElectionNot dto = JsonUtil.transferToObject(criteria, ElectionNot.class);
			if (!BaseUtil.isObjNull(dto.getElectionNotId())) {
				predicates.add(cb.equal(from.get("electionNotId"), dto.getElectionNotId()));
			}

			if (!BaseUtil.isObjNull(dto.getTxnId())) {
				predicates.add(cb.equal(from.get("txnId"), dto.getTxnId()));
			}

			if (!BaseUtil.isObjNull(dto.getOrgStateCd())) {
				predicates.add(cb.equal(from.get("orgStateCd"), dto.getOrgStateCd()));
			}

			if (!BaseUtil.isObjNull(dto.getOrgDivisionCd())) {
				predicates.add(cb.equal(from.get("orgDivisionCd"), dto.getOrgDivisionCd()));
			}

			if (!BaseUtil.isObjNull(dto.getParliamentCode())) {
				predicates.add(cb.equal(from.get("parliamentCode"), dto.getParliamentCode()));
			}

			if (!BaseUtil.isObjNull(dto.getDunCode())) {
				predicates.add(cb.equal(from.get("dunCode"), dto.getDunCode()));
			}

			if (!BaseUtil.isObjNull(dto.getMemberCtrgyMtdtId())) {
				predicates.add(cb.equal(from.get("memberCtrgyMtdtId"), dto.getMemberCtrgyMtdtId()));
			}

			if (!BaseUtil.isObjNull(dto.getApplyLevel())) {
				predicates.add(cb.equal(from.get("applyLevel"), dto.getApplyLevel()));
			}

			if (!BaseUtil.isObjNull(dto.getApplyOrgStateCd())) {
				predicates.add(cb.equal(from.get("applyOrgStateCd"), dto.getApplyOrgStateCd()));
			}

			if (!BaseUtil.isObjNull(dto.getApplyOrgDivisionCd())) {
				predicates.add(cb.equal(from.get("applyOrgDivisionCd"), dto.getApplyOrgDivisionCd()));
			}

			if (!BaseUtil.isObjNull(dto.getNotifyInd())) {
				predicates.add(cb.equal(from.get("notifyInd"), dto.getNotifyInd()));
			}

			if (!BaseUtil.isObjNull(dto.getApplyDtFrom())) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(dto.getApplyDtFrom());
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				Date srcDt = cal.getTime();
				predicates.add(cb.greaterThanOrEqualTo(from.get("applyDt"), srcDt));
			}

			if (!BaseUtil.isObjNull(dto.getApplyDtTo())) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(dto.getApplyDtTo());
				cal.set(Calendar.HOUR_OF_DAY, 23);
				cal.set(Calendar.MINUTE, 59);
				cal.set(Calendar.SECOND, 59);
				Date srcDt = cal.getTime();
				predicates.add(cb.lessThanOrEqualTo(from.get("applyDt"), srcDt));
			}
		} catch (IOException e) {
			throw new BeException(BeErrorCodeEnum.E400C912);
		}

		return predicates;
	}

}
