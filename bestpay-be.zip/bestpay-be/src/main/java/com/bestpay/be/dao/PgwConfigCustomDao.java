package com.bestpay.be.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.bestpay.be.model.PgwConfig;
import com.bestpay.be.sdk.model.PaymentConfig;
import com.bestpay.be.sdk.pagination.DataTableRequest;
import com.bestpay.be.sdk.pagination.DataTableResults;
import com.bestpay.be.sdk.pagination.PaginationCriteria;
import com.bestpay.be.sdk.util.BaseUtil;
import com.bestpay.be.util.QualifierConstants;


/**
 * @author Atiqah Khairuddin
 * @since Aug 22, 2019
 */
@Repository
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.PGW_CONFIG_DAO)
public class PgwConfigCustomDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(PgwConfigCustomDao.class);

	@Autowired
	private PgwConfigRepository pgwConfigRepository;

	@PersistenceContext
	private EntityManager entityManager;


	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}


	public DataTableResults<PgwConfig> searchPgwConfigByPagination(PaymentConfig paymentConfig,
			DataTableRequest dataTableInRQ) {
		StringBuilder sb = new StringBuilder("select r ");
		sb.append("from PgwConfig r ");
		sb.append(" where 1=1 ");

		if (!BaseUtil.isObjNull(paymentConfig.getConfigCode())) {
			sb.append(" and r.configCode LIKE :configCode ");
		}

		if (!BaseUtil.isObjNull(paymentConfig.getConfigDesc())) {
			sb.append(" and r.configDesc LIKE :configDesc ");
		}

		sb.append(" order by r.createDt desc ");

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				sb.append(pagination.getOrderByClause("r"));
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(sb.toString());
		}

		// Filtered Query by pagination
		TypedQuery<PgwConfig> query = entityManager.createQuery(sb.toString(), PgwConfig.class);
		// Original Query
		TypedQuery<PgwConfig> query2 = entityManager.createQuery(sb.toString(), PgwConfig.class);

		if (!BaseUtil.isObjNull(paymentConfig.getConfigCode())) {
			query.setParameter("configCode", paymentConfig.getConfigCode());
			query2.setParameter("configCode", paymentConfig.getConfigCode());
		}

		if (!BaseUtil.isObjNull(paymentConfig.getConfigDesc())) {
			query.setParameter("configDesc", "%" + paymentConfig.getConfigDesc() + "%");
			query2.setParameter("configDesc", "%" + paymentConfig.getConfigDesc() + "%");
		}

		if (!BaseUtil.isObjNull(dataTableInRQ)) {
			PaginationCriteria pagination = dataTableInRQ.getPaginationRequest();
			if (!BaseUtil.isObjNull(pagination)) {
				query.setFirstResult(pagination.getPageNumber());
				query.setMaxResults(pagination.getPageSize());
			}
		}

		DataTableResults<PgwConfig> dataTableResult = new DataTableResults<>();
		List<PgwConfig> svcResp = query.getResultList();
		List<PgwConfig> svcResp2 = query2.getResultList();
		LOGGER.debug("Filtered Size: {}", svcResp.size());
		LOGGER.debug("Original Size: {}", svcResp2.size());

		// Get max total records in table
		int totalRecords = dataTableInRQ.isInitSearch() ? svcResp2.size() : pgwConfigRepository.totalRecords();
		dataTableResult.setDraw(dataTableInRQ.getDraw());
		dataTableResult.setData(svcResp);
		LOGGER.debug("isFilterByEmpty: {}", dataTableInRQ.getPaginationRequest().isFilterByEmpty());
		dataTableResult.setRecordsTotal(BaseUtil.getStr(totalRecords));
		if (dataTableInRQ.getPaginationRequest().isFilterByEmpty()) {
			dataTableResult.setRecordsFiltered(BaseUtil.getStr(totalRecords));
		} else {
			dataTableResult.setRecordsFiltered(Integer.toString(svcResp2.size()));
		}
		return dataTableResult;
	}

}
