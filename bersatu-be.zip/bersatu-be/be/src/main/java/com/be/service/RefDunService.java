/**
 *
 */
package com.be.service;


import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.RefDunQf;
import com.be.dao.RefDunRepository;
import com.be.model.RefDun;
import com.be.sdk.constants.BeCacheConstants;
import com.be.sdk.model.IQfCriteria;


/**
 * @author Ramesh Pongianann
 *
 */
@Lazy
@Transactional
@Service(QualifierConstants.REF_DUN_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_DUN_SVC)
@CacheConfig(cacheNames = BeCacheConstants.CACHE_BUCKET)
public class RefDunService extends AbstractService<RefDun> {

	@Autowired
	RefDunRepository refDunDao;

	@Autowired
	RefDunQf refDunQf;


	@Override
	public GenericRepository<RefDun> primaryDao() {
		return refDunDao;
	}


	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}


	public List<RefDun> getAll() {
		return refDunDao.findAll();
	}


	public RefDun findByDunCd(String dunCd) {
		return refDunDao.findByDunCd(dunCd);
	}


	public List<RefDun> searchAllByProperty(RefDun dto) {
		return refDunQf.searchAllByProperty(dto);
	}
}
