package com.bestpay.pgw.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestpay.pgw.core.AbstractService;
import com.bestpay.pgw.core.GenericRepository;
import com.bestpay.pgw.dao.RefCountryRepository;
import com.bestpay.pgw.model.RefCountry;
import com.bestpay.pgw.sdk.util.BaseUtil;
import com.bestpay.pgw.util.QualifierConstants;


@Service(QualifierConstants.REF_COUNTRY_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.REF_COUNTRY_SVC)
@Transactional
public class RefCountryService extends AbstractService<RefCountry> {

	@Autowired
	private RefCountryRepository refCountryRepository;


	@Override
	public GenericRepository<RefCountry> primaryDao() {
		return refCountryRepository;
	}


	public String getCntryDescByCntry2Cd(String cntry2Cd) {
		RefCountry refCountry = refCountryRepository.getcountryByCntry2Cd(cntry2Cd);
		if (!BaseUtil.isObjNull(refCountry)) {
			return refCountry.getCntryDesc();
		} else {
			return null;
		}
	}

}