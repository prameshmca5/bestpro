/**
 * 
 */
package com.be.service;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeAcctPassportQf;
import com.be.dao.BeAcctPassportRepository;
import com.be.model.BeAcctPassport;
import com.be.model.BeAcctTraveller;
import com.be.sdk.model.AcctTraveller;
import com.be.sdk.model.IQfCriteria;
import com.util.BaseUtil;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_ACCT_PASSPORT_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_ACCT_PASSPORT_SVC)
public class BeAcctPassportService extends AbstractService<BeAcctPassport> {

	@Autowired
	private BeAcctPassportRepository beAcctPassportDao;
	
	@Autowired
	BeAcctPassportQf beAcctPassportQf;
	
	@Override
	public GenericRepository<BeAcctPassport> primaryDao() {
		return beAcctPassportDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		return beAcctPassportQf.generateCriteria(cb, from, criteria);
	}
	
	public BeAcctPassport createUpdate(BeAcctPassport passport, String userId) {
		
		BeAcctPassport beAcctPassport = beAcctPassportDao.findByPassportNo(passport.getPassportNo());
		if(BaseUtil.isObjNull(beAcctPassport)) {
			beAcctPassport = new BeAcctPassport();
			beAcctPassport.setIsActive(true);
			beAcctPassport.setCreateId(userId);
		}else {
			if (!BaseUtil.isObjNull(passport.getIsActive())) {
				beAcctPassport.setIsActive(passport.getIsActive());
	        }
		}	
		beAcctPassport.setNationality(passport.getNationality());
		beAcctPassport.setPassportNo(passport.getPassportNo());
		beAcctPassport.setPassportExpiryDt(passport.getPassportExpiryDt());
		beAcctPassport.setUpdateId(userId);
		beAcctPassport.setUpdateDt(getSQLTimestamp());
		return update(beAcctPassport);
	}
	
	public BeAcctPassport searchBeAcctPassport(BeAcctPassport dto) {
		return beAcctPassportQf.searchBeAcctPassport(dto);
	}

}
