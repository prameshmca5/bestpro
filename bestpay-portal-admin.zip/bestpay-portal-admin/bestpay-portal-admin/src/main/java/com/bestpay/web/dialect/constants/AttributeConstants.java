/**
 * Copyright 2018. Bestinet Sdn Bhd
 */
package com.bestpay.web.dialect.constants;


/**
 * @author Mary Jane Buenaventura
 * @since May 18, 2018
 */
public class AttributeConstants {

	private AttributeConstants() {
		throw new IllegalStateException("Utility class");
	}


	public static final String ATTR_CLASS = "class";

	public static final String ATTR_DATA_DISMISS = "data-dismiss";

	public static final String ATTR_DATA_PROVIDES = "data-provides";

	public static final String ATTR_DATA_TOGGLE = "data-toggle";

	public static final String ATTR_DATA_HOVER = "data-hover";

	public static final String ATTR_DATA_PAGING = "data-paging";

	public static final String ATTR_DATA_PAGE_LEN = "data-page-length";

	public static final String ATTR_METHOD = "method";

	public static final String ATTR_ROLE = "role";

	public static final String ATTR_NAME = "name";

	public static final String ATTR_HREF = "href";

	public static final String ATTR_ID = "id";

	public static final String ATTR_TYPE = "type";

	public static final String ATTR_TYPE_CHECKBOX = "checkbox";

	public static final String ATTR_TYPE_DATE = "date";

	public static final String ATTR_TYPE_HIDDEN = "hidden";

	public static final String ATTR_TYPE_NUMBER = "number";

	public static final String ATTR_TYPE_PWORD = "password";

	public static final String ATTR_TYPE_RADIO = "radio";

	public static final String ATTR_TYPE_TEXT = "text";

	public static final String ATTR_TYPE_TIME = "time";

	public static final String ATTR_TITLE = "title";

	public static final String ATTR_ICON = "icon";

	public static final String ATTR_VALUE = "value";

	public static final String ATTR_TH_ID = "th:id";

	public static final String ATTR_TH_VALUE = "th:value";

	public static final String ATTR_TH_SRC = "th:src";

	public static final String ATTR_TH_TEXT = "th:text";

	public static final String ATTR_TH_HREF = "th:href";

	public static final String ATTR_TH_FIELD = "th:field";

	public static final String ATTR_TH_CLASSAPPEND = "th:classappend";

	public static final String ATTR_STYLE = "style";

	public static final String ATTR_ARIA_HIDDEN = "aria-hidden";

}