/**
 * 
 */
package com.be.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.be.constants.QualifierConstants;
import com.be.core.AbstractService;
import com.be.core.GenericRepository;
import com.be.dao.BeConfigPaymentBreakdownQf;
import com.be.dao.BeConfigPaymentBreakdownRepository;
import com.be.model.BeConfigPaymentBreakdown;
import com.be.sdk.model.ConfigPaymentBreakdown;
import com.be.sdk.model.IQfCriteria;
import com.util.JsonUtil;
import com.util.pagination.DataTableRequest;

/**
 * @author michelle.angela
 *
 */
@Transactional
@Service(QualifierConstants.BE_CONFIG_PAYMENT_BREAKDOWN_SVC)
@Scope(QualifierConstants.SCOPE_PROTOTYPE)
@Qualifier(QualifierConstants.BE_CONFIG_PAYMENT_BREAKDOWN_SVC)
public class BeConfigPaymentBreakdownService extends AbstractService<BeConfigPaymentBreakdown> {

	@Autowired
	private BeConfigPaymentBreakdownRepository beConfigPaymentBreakdownDao;
	
	@Autowired
	BeConfigPaymentBreakdownQf beConfigPaymentBreakdownQf;
	
	@Override
	public GenericRepository<BeConfigPaymentBreakdown> primaryDao() {
		return beConfigPaymentBreakdownDao;
	}

	@Override
	public List<Predicate> generateCriteria(CriteriaBuilder cb, From<?, ?> from, IQfCriteria<?> criteria) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public long getCount(ConfigPaymentBreakdown dto) {
		return beConfigPaymentBreakdownQf.getCount(dto);
	}

	public BeConfigPaymentBreakdown searchBeTvlPaymentBreakdown(ConfigPaymentBreakdown dto) {
		Integer bachId = beConfigPaymentBreakdownDao.max();
		dto.setBatchId(bachId);
		return beConfigPaymentBreakdownQf.searchBeTvlPaymentBreakdown(dto);
	}

	@SuppressWarnings("unchecked")
	public List<ConfigPaymentBreakdown> searchBeTvlPaymentbrkdownPagination(ConfigPaymentBreakdown dto, DataTableRequest<?> dataTableInRQ) 
			throws IOException {
		return JsonUtil.transferToList(beConfigPaymentBreakdownQf.searchBeTvlPaymentbrkdownPagination(dto, dataTableInRQ), ConfigPaymentBreakdown.class);
	}
 
	 @Transactional(value = QualifierConstants.TRANS_MANAGER, readOnly = false, rollbackFor = { Exception.class})
		public List<BeConfigPaymentBreakdown> addPaymentInfo(List<BeConfigPaymentBreakdown> dtoList,  String pmtRefNo){
			
			List<BeConfigPaymentBreakdown> beTvlPayment = new ArrayList<>();
			for(BeConfigPaymentBreakdown payment : dtoList) {
				
				/*if(BaseUtil.isObjNull(payment.getPmtRefNo())) {
					payment.setPmtRefNo(pmtRefNo);
				}*/
 
				beTvlPayment.add(payment);
			}
			
			return beConfigPaymentBreakdownDao.save(beTvlPayment);
		}


}
